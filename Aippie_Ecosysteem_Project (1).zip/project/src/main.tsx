import { StrictMode, Component, type ReactNode } from 'react';
import { createRoot } from 'react-dom/client';
import App from './App.tsx';
import { AuthProvider } from './contexts/AuthContext.tsx';
import './index.css';

class ErrorBoundary extends Component<{ children: ReactNode }, { error: Error | null }> {
  constructor(props: { children: ReactNode }) {
    super(props);
    this.state = { error: null };
  }
  static getDerivedStateFromError(error: Error) {
    return { error };
  }
  render() {
    if (this.state.error) {
      return (
        <div style={{
          display: 'flex', flexDirection: 'column', alignItems: 'center',
          justifyContent: 'center', height: '100vh', background: '#0a0f1e',
          color: '#fff', fontFamily: 'sans-serif', padding: '2rem', textAlign: 'center'
        }}>
          <h2 style={{ marginBottom: '1rem' }}>Aippie failed to load</h2>
          <p style={{ color: '#94a3b8', marginBottom: '1.5rem' }}>
            Clear cache and try again.
          </p>
          <button
            onClick={() => {
              if ('caches' in window) {
                caches.keys().then(keys => Promise.all(keys.map(k => caches.delete(k)))).then(() => location.reload());
              } else {
                location.reload();
              }
            }}
            style={{
              padding: '0.75rem 1.5rem', background: '#2563eb', color: '#fff',
              border: 'none', borderRadius: '8px', fontSize: '1rem', cursor: 'pointer'
            }}
          >
            Clear cache & reload
          </button>
          <p style={{ marginTop: '1rem', fontSize: '0.75rem', color: '#475569' }}>
            {this.state.error.message}
          </p>
        </div>
      );
    }
    return this.props.children;
  }
}

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <ErrorBoundary>
      <AuthProvider>
        <App />
      </AuthProvider>
    </ErrorBoundary>
  </StrictMode>
);

// Signal to index.html that React has mounted — cancels the loading overlay timer
(window as unknown as Record<string, unknown>).reactMounted = true;

// Unregister any existing service workers to prevent stale cache issues
if ('serviceWorker' in navigator) {
  navigator.serviceWorker.getRegistrations().then(regs => {
    regs.forEach(r => r.unregister());
  });
  // Also clear all caches
  if ('caches' in window) {
    caches.keys().then(keys => Promise.all(keys.map(k => caches.delete(k))));
  }
}

if (typeof (window as unknown as Record<string, unknown>).Capacitor !== 'undefined') {
  window.addEventListener('load', () => {
    const cap = (window as unknown as Record<string, unknown>).Capacitor as Record<string, unknown>;
    const plugins = cap?.Plugins as Record<string, unknown> | undefined;
    const AppPlugin = plugins?.App as { addListener?: (event: string, cb: (d: { canGoBack: boolean }) => void) => void; exitApp?: () => void } | undefined;
    AppPlugin?.addListener?.('backButton', ({ canGoBack }) => {
      if (canGoBack) window.history.back();
      else AppPlugin.exitApp?.();
    });
  });
}
