import { useEffect, useRef, useState, lazy, Suspense, Component, startTransition, type ReactNode } from 'react';

// Silently catches per-module render errors so one crashed tab never kills the app
class ErrorBoundary extends Component<{ children: ReactNode }, { hasError: boolean }> {
  state = { hasError: false };
  static getDerivedStateFromError() { return { hasError: true }; }
  componentDidCatch() { this.setState({ hasError: false }); }
  render() { return this.state.hasError ? null : this.props.children; }
}
import {
  Mic, Wifi, Car, Headphones, Hand, TrendingUp, Settings,
  X, Building2, HeartHandshake, Glasses, ShieldCheck, Stethoscope, Home,
  MessageSquare, Phone, Code2, GraduationCap, Radar, Cpu, Radio, Wallet, Scale, Heart, Zap, Landmark, BrainCircuit, Lock, Video, FolderLock, MailOpen, Globe, LayoutGrid
} from 'lucide-react';
import { supabase, type Subscription } from './lib/supabase';
import { useAuth } from './contexts/AuthContext';
import { getStoredLang, storeLang, detectGeoLang, type LangCode } from './lib/i18n';
import { withVoicesReady, selectPremiumVoice, normalizeForTTS } from './lib/ttsVoice';

// Critical: always loaded (appear before first interaction)
import BoardroomLanding from './components/BoardroomLanding';
import MatrixCodeBackground from './components/MatrixCodeBackground';

// Type-only imports (zero runtime cost)
import type { OnboardingTokens } from './components/OnboardingModal';
import type { AippiePresenterHandle, PresenterEmotion } from './components/AippiePresenter';
import type { PermissionSet } from './components/PermissionGatewayModal';
import type { AccessGranted } from './components/ClientAccessGate';

// Lazy: all modals and sidebars — loaded only when shown
const OnboardingModal        = lazy(() => import('./components/OnboardingModal'));
const SofiaNotification      = lazy(() => import('./components/SofiaNotification'));
const AippiePresenter        = lazy(() => import('./components/AippiePresenter'));
const GlobalLangSelector     = lazy(() => import('./components/GlobalLangSelector'));
const PermissionGatewayModal = lazy(() => import('./components/PermissionGatewayModal'));
const ClientAccessGate       = lazy(() => import('./components/ClientAccessGate'));
const AppSidebar             = lazy(() => import('./components/AppSidebar'));

// Lazy: loaded on demand when the user navigates to that tab
const ClientView             = lazy(() => import('./components/ClientView'));
const TranslatorView         = lazy(() => import('./components/TranslatorView'));
const ParkingView            = lazy(() => import('./components/ParkingView'));
const WiFiView               = lazy(() => import('./components/WiFiView'));
const SilentVoiceView        = lazy(() => import('./components/SilentVoiceView'));
const LivingAvatarView       = lazy(() => import('./components/LivingAvatarView'));
const PartnerPortalView      = lazy(() => import('./components/PartnerPortalView'));
const AippieTaxView          = lazy(() => import('./components/AippieTaxView'));
const CompanionView          = lazy(() => import('./components/CompanionView'));
const WearableLinkView       = lazy(() => import('./components/WearableLinkView'));
const SafeCheckInView        = lazy(() => import('./components/SafeCheckInView'));
const AippieDoctorView       = lazy(() => import('./components/AippieDoctorView'));
const AippieTrustDashboard   = lazy(() => import('./components/AippieTrustDashboard'));
const AippieEnergyView       = lazy(() => import('./components/AippieEnergyView'));
const RealEstateView         = lazy(() => import('./components/RealEstateView'));
const AdminLicenseView       = lazy(() => import('./components/AdminLicenseView'));
const AippieAssistantView    = lazy(() => import('./components/AippieAssistantView'));
const VoipScriptView         = lazy(() => import('./components/VoipScriptView'));
const QuantumTimeMachineView = lazy(() => import('./components/QuantumTimeMachineView'));
const EnterpriseClinicHub    = lazy(() => import('./components/EnterpriseClinicHub'));
const AippieDevView          = lazy(() => import('./components/AippieDevView'));
const AippieAcademyView      = lazy(() => import('./components/AippieAcademyView'));
const CompanionRadarView     = lazy(() => import('./components/CompanionRadarView'));
const AippieRoboticsView     = lazy(() => import('./components/AippieRoboticsView'));
const AippieCyberSuitView    = lazy(() => import('./components/AippieCyberSuitView'));
const AippieLiveStageView    = lazy(() => import('./components/AippieLiveStageView'));
const AippieVoiceNavView     = lazy(() => import('./components/AippieVoiceNavView'));
const DigitalWalletView      = lazy(() => import('./components/DigitalWalletView'));
const AippieLegalView        = lazy(() => import('./components/AippieLegalView'));
const AippieReunionView      = lazy(() => import('./components/AippieReunionView'));
const AippieB2BView          = lazy(() => import('./components/AippieB2BView'));
const AippieTradingView      = lazy(() => import('./components/AippieTradingView'));
const PrivacyPolicyView      = lazy(() => import('./components/PrivacyPolicyView'));
const AippieMorningBriefingView = lazy(() => import('./components/AippieMorningBriefingView'));
const AippieUnifiedDashboard = lazy(() => import('./components/AippieUnifiedDashboard'));
const AippieTournamentView   = lazy(() => import('./components/AippieTournamentView'));
const AippieSignalRadarView  = lazy(() => import('./components/AippieSignalRadarView'));
const AippieAccountingView   = lazy(() => import('./components/AippieAccountingView'));
const AippieLifeAssistantView = lazy(() => import('./components/AippieLifeAssistantView'));
const AippieSecureChatView   = lazy(() => import('./components/AippieSecureChatView'));
const AippieVideoVaultView   = lazy(() => import('./components/AippieVideoVaultView'));
const AippieDocumentVaultView = lazy(() => import('./components/AippieDocumentVaultView'));
const AippieMailView         = lazy(() => import('./components/AippieMailView'));
const PricingView            = lazy(() => import('./components/PricingView'));
const EnterpriseDashboard    = lazy(() => import('./components/EnterpriseDashboard'));
const CommercialAIPowerpack  = lazy(() => import('./components/CommercialAIPowerpack'));
const AippiePowerPulse       = lazy(() => import('./components/AippiePowerPulse'));
const AippieBoardroomView    = lazy(() => import('./components/AippieBoardroomView'));
const AippieEnterpriseWizardView = lazy(() => import('./components/AippieEnterpriseWizardView'));
const PaywallGate               = lazy(() => import('./components/PaywallGate'));

import type { User } from '@supabase/supabase-js';

// V98: single source of truth for all contextual speech scripts.
// Used by bottom-nav, handleLandingNavigate, and AippiePresenter initialScript.
// Keyed by AppTab. Tabs absent from this map fall back to the generic welcome.

// Safe storage wrappers — localStorage/sessionStorage throw in iOS private mode
function storageGet(key: string): string | null {
  try { return localStorage.getItem(key); } catch { return null; }
}
function storageSet(key: string, val: string): void {
  try { localStorage.setItem(key, val); } catch { /* noop */ }
}

// BoardroomLanding is the permanent homepage — always shown on fresh page load.
// The only way to skip it is via ?tab= (deep-link from the landing's own CTA).
const alreadyBoarded = false;

// Deep-link: BoardroomLanding writes ?tab=X then hard-reloads.
// Read once at module load, strip param, skip landing for this session only.
const _urlParams   = new URLSearchParams(window.location.search);
const urlTabParam  = _urlParams.get('tab');
if (urlTabParam) {
  // Also persist the tab so the app opens on the right screen
  try { localStorage.setItem('aippie_tab', urlTabParam); } catch { /* noop */ }
  // Strip the ?tab= from the URL so browser history is clean
  const cleanUrl = window.location.pathname;
  window.history.replaceState(null, '', cleanUrl);
}
function storageRemove(key: string): void {
  try { localStorage.removeItem(key); } catch { /* noop */ }
}
function sessionGet(key: string): string | null {
  try { return sessionStorage.getItem(key); } catch { return null; }
}
function sessionSet(key: string, val: string): void {
  try { sessionStorage.setItem(key, val); } catch { /* noop */ }
}

const TAB_SCRIPTS: Partial<Record<string, [string, PresenterEmotion]>> = {
  tax:        [
    'Welcome to your AippieAccounts portal. I am live and ready for you. Upload your documents or enter your VAT number, and I will manage your global accounting, payroll, and Nominas salary administration directly.',
    'authoritative',
  ],
  voice:      [
    'This is your AippieVoice Document Scanner. Upload or scan your official letters and PDF files here, and I will translate them instantly and read them aloud to you in your preferred language.',
    'focused',
  ],
  doctor:     [
    'Welcome to Aippie Doctor. Please describe any symptoms you are experiencing, or place your fingertip on the camera for a live stress and heart rate scan. I am an AI health guide, not a licensed physician. Always consult your own doctor for official medical diagnoses.',
    'warm',
  ],
  trading:    [
    'The Trading Alpha quant algorithms are active. You can see real-time market and order signals here to autonomously and intelligently optimize your positions.',
    'authoritative',
  ],
  realestate: [
    'Welcome to your Aippie Real Estate portfolio portal. Register your Spanish or global properties here for real-time market valuations and automated rental management.',
    'authoritative',
  ],
  wifi:       ['The AippieWiFi Data Sharing module is active. Configure your node, set your price per gigabyte, and start earning from your internet connection.', 'neutral'],
  parking:    ['AippieParking 3D Maps is open. Real-time parking availability is displayed across the Costa del Sol. Enable AR View for live computer vision street mapping.', 'neutral'],
  silentvoice:['Autism AI Signal Radar is active. The 5-signal computer vision scanner is ready. Gesture and facial expression recognition will translate signals into immediate spoken output.', 'authoritative'],
  wearable:   ['Smart Glass and Chrono-Cinema is active. Select your era, enter your name, and I will narrate your personalized cinematic story live.', 'neutral'],
  safecheckin:['Aippie Guardian Shield Timer is ready. Set your safety check-in window and activate it when entering an unsecured environment.', 'authoritative'],
  assistant:  ['This is your Aippie AI Message Assistant. Paste or type any message, letter, or contract here, and I will read it to you and help you draft a professional reply.', 'warm'],
  voipscript: ['This is the Aippie Call Script Generator. Fill in the details and I will generate a complete word-for-word phone script for a hotel, restaurant, doctor, or service appointment. I will read each sentence aloud during your live call.', 'focused'],
  quantumcinema: ['Welcome to Aippie Chrono-Cinema. Choose an era — from ancient Egypt to the year 3000 — and I will narrate your personalized cinematic film live. All story content is entirely fictional and created strictly for entertainment purposes.', 'focused'],
  aippiedev: ['Welcome to AippieDev Ultra-Wide — your fully autonomous multimodal AI engine. Four pipeline nodes take your idea from canvas design through serverless AWS injection, binary compilation, and direct-to-store deployment. Activate for $299 per month.', 'authoritative'],
  academy:         ['Welcome to Aippie AI Academy — the intelligent education hub by AIPPIETAX S.A. Choose the Kids Learning plan at five Euros per month for AI-guided courses that auto-terminate on completion, or activate the School Enterprise Portal at one hundred and ninety-nine Euros per month for a full white-label school management system with live grading analytics.', 'warm'],
  companionradar:  ['Welcome to Aippie Companionship and Matchmaker Radar — Module 17. Choose your role: The Seeker at five Euros per month to find your match, or The Provider to earn through companionship with a secured payout ledger. AI live face verification is active.', 'warm'],
  robotics:        ['Welcome to Aippie Humanoid Robotics and Cybernetic Interface — Module 18. This is the engineering staging blueprint environment. Cloud-to-hardware telemetry streams are active over five-G and six-G uplinks. Computer vision navigation is integrated with a live three-dimensional spatial core. All core directives and safety protocols are one hundred percent compliant under the immutable system safety override. Physical hardware is currently in pre-production staging.', 'authoritative'],
  alphatrade:      ['Alpha Trading Engine is live. Dark-pool order flows, institutional buy blocks, and autonomous rebalancing are all active across Crypto, Stocks, and Derivatives. Connect your broker API keys to activate live multi-market execution.', 'authoritative'],
  morning:         ['Good morning. I have prepared your personalized market briefing. Let me walk you through todays top opportunities, risk alerts, and portfolio health in detail.', 'warm'],
  unified:         ['Welcome to your Unified Finance Command Center. Your portfolio, tax engine, and legal shield are all active and synchronized in one view. This is your complete financial overview.', 'authoritative'],
  tournament:      ['The Aippie AI Trading Championship is live. You are currently ranked number seven out of two thousand eight hundred and forty seven competing strategies. Your AI is executing trades autonomously.', 'focused'],
  signalradar:     ['Mission Control is online. The Signal Radar is scanning forty seven live news sources and converting breaking stories into trade signals in under three seconds. Current accuracy rate is eighty nine percent.', 'authoritative'],
  lifeassist:      ['Welcome to Aippie Life Assistant — your personal AI that runs in the background of your life. Grant me permissions and I will read your emails, announce your calls, and remind you of your appointments, all hands-free.', 'warm'],
  boardroom:       ['Welcome to the AIPPIE Autonomous Boardroom. Your four cabinet secretaries — Tax, Commerce, Defense, and Health — are standing by. Convene a session to receive your strategic directives and monthly Emperor Briefing.', 'authoritative'],
};

const GENERIC_WELCOME: [string, PresenterEmotion] = [
  'Welcome to Aippie. All ten modules are live and fully secured.',
  'warm',
];

// V61: active avatar session type — 'presenter' = AippiePresenter owns audio,
//      'companion' = CompanionView owns audio exclusively.
type ActiveAvatarSession = 'presenter' | 'companion';

type AppTab = 'voice' | 'wifi' | 'parking' | 'silentvoice' | 'trading' | 'tax' | 'companion' | 'wearable' | 'safecheckin' | 'doctor' | 'realestate' | 'assistant' | 'voipscript' | 'quantumcinema' | 'aippiedev' | 'academy' | 'companionradar' | 'robotics' | 'cybersuit' | 'livestage' | 'voicenav' | 'wallet' | 'legal' | 'reunion' | 'b2b' | 'alphatrade' | 'privacy' | 'morning' | 'unified' | 'tournament' | 'signalradar' | 'accounting' | 'lifeassist' | 'securechat' | 'videovault' | 'docvault' | 'aippiemail' | 'pricing' | 'trustdashboard' | 'trust' | 'energy' | 'aimanager' | 'powerpack' | 'powerpulse';
type VoiceMode = 'client' | 'translator';

// ── V209: CinematicIntroGate — mandatory full-screen AI face intro ────────────
const CINEMATIC_SPEECH = 'Welcome. I am Aippie. From this moment, I run your life.';

function useTypewriter(text: string, active: boolean, intervalMs = 80) {
  const [displayed, setDisplayed] = useState('');
  const idxRef = useRef(0);
  const tmrRef = useRef<ReturnType<typeof setInterval> | null>(null);

  useEffect(() => {
    if (tmrRef.current) { clearInterval(tmrRef.current); tmrRef.current = null; }
    setDisplayed('');
    idxRef.current = 0;
    if (!active || !text) return;
    tmrRef.current = setInterval(() => {
      idxRef.current++;
      setDisplayed(text.slice(0, idxRef.current));
      if (idxRef.current >= text.length && tmrRef.current) {
        clearInterval(tmrRef.current);
        tmrRef.current = null;
      }
    }, intervalMs);
    return () => { if (tmrRef.current) { clearInterval(tmrRef.current); tmrRef.current = null; } };
  }, [text, active, intervalMs]);

  return displayed;
}

function CinematicNeonWaveform({ active }: { active: boolean }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const frameRef  = useRef<number>(0);
  const tickRef   = useRef(0);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const draw = () => {
      tickRef.current++;
      const tk = tickRef.current;
      const W = canvas.width, H = canvas.height;
      ctx.clearRect(0, 0, W, H);

      const bars = 48;
      const gap = W / bars;
      const barW = Math.max(2, gap - 3);

      for (let i = 0; i < bars; i++) {
        const phase = (i / bars) * Math.PI * 2;
        const rawH = active
          ? (0.08 + 0.92 * Math.abs(Math.sin(tk * 0.06 + phase + Math.sin(tk * 0.02 + i * 0.4) * 1.2))) * H
          : (0.03 + 0.06 * Math.abs(Math.sin(tk * 0.012 + phase))) * H;
        const x = i * gap + (gap - barW) / 2;
        const y = (H - rawH) / 2;

        // Neon blue gradient per bar
        const grad = ctx.createLinearGradient(0, y, 0, y + rawH);
        grad.addColorStop(0,   active ? 'rgba(56,189,248,0.9)' : 'rgba(56,189,248,0.15)');
        grad.addColorStop(0.5, active ? 'rgba(14,165,233,1)'   : 'rgba(14,165,233,0.2)');
        grad.addColorStop(1,   active ? 'rgba(56,189,248,0.9)' : 'rgba(56,189,248,0.15)');
        ctx.fillStyle = grad;

        if (active) {
          ctx.shadowColor  = '#38bdf8';
          ctx.shadowBlur   = 8;
        } else {
          ctx.shadowBlur = 0;
        }

        ctx.beginPath();
        if (ctx.roundRect) {
          ctx.roundRect(x, y, barW, rawH, Math.min(barW / 2, 5));
        } else {
          ctx.rect(x, y, barW, rawH);
        }
        ctx.fill();
      }
      ctx.shadowBlur = 0;
      frameRef.current = requestAnimationFrame(draw);
    };

    frameRef.current = requestAnimationFrame(draw);
    return () => cancelAnimationFrame(frameRef.current);
  }, [active]);

  return (
    <canvas
      ref={canvasRef}
      width={520}
      height={56}
      aria-hidden="true"
      className="cig-waveform"
    />
  );
}

function CinematicIntroGate({ onEnter, onAlreadyCustomer }: { onEnter: () => void; onAlreadyCustomer: () => void }) {
  const [speaking, setSpeaking]   = useState(false);
  const [exiting,  setExiting]    = useState(false);
  const cancelRef = useRef(false);
  const subtitle  = useTypewriter(CINEMATIC_SPEECH, speaking, 55);

  // V210: Premium English voice initialization — 800ms viewport-settle delay
  useEffect(() => {
    cancelRef.current = false;
    if (!('speechSynthesis' in window)) return;
    window.speechSynthesis.cancel();

    let delayTimer: ReturnType<typeof setTimeout> | null = null;

    // withVoicesReady handles: voices-already-loaded, voiceschanged event,
    // 50ms poll fallback, and a 3s hard timeout — fully race-safe.
    withVoicesReady(() => {
      if (cancelRef.current) return;

      // 800ms settle delay: ensures the cinematic face grid and neon waveform
      // have fully painted before the audio context is primed.
      // Opening speech removed per product decision — typewriter runs silently
      delayTimer = setTimeout(() => {
        if (cancelRef.current) return;
        setSpeaking(true);
        // Auto-clear speaking state after the typewriter would have finished
        const wordCount = CINEMATIC_SPEECH.split(' ').length;
        setTimeout(() => setSpeaking(false), wordCount * 400 + 1000);
      }, 800);
    });

    return () => {
      cancelRef.current = true;
      if (delayTimer) clearTimeout(delayTimer);
      window.speechSynthesis?.cancel();
    };
  }, []);

  const handleEnter = () => {
    window.speechSynthesis?.cancel();
    setExiting(true);
    // Fade-out duration matches CSS transition (600ms)
    setTimeout(onEnter, 600);
  };

  return (
    <div className={`cig-root${exiting ? ' cig-root--exit' : ''}`}>
      {/* Ambient background particles */}
      <div className="cig-bg" aria-hidden="true">
        <div className="cig-bg__grid" />
        <div className="cig-bg__glow cig-bg__glow--left"  />
        <div className="cig-bg__glow cig-bg__glow--right" />
      </div>

      <div className="cig-content w-full max-w-[1600px] mx-auto px-6">
        {/* Aippie logo */}
        <div className="cig-logo-wrap">
          <img
            src="/Jouw_alineatekst_(2).png"
            alt="Aippie"
            className="cig-logo-img"
            onError={e => { (e.currentTarget as HTMLImageElement).style.display = 'none'; }}
          />
        </div>

        {/* Version tag */}
        <div className="cig-version-tag">
          <span className="cig-version-tag__dot" />
          AIPPIETAX S.A. · v214 · Cinematic AI Face Mode
        </div>

        {/* Avatar — 300×300, centered */}
        <div className="cig-avatar-wrap">
          <div className="cig-avatar-ring cig-avatar-ring--1" />
          <div className="cig-avatar-ring cig-avatar-ring--2" />
          <div className="cig-avatar-ring cig-avatar-ring--3" />
          <img
            src="/Jouw_alineatekst_(2).png"
            alt="Aippie"
            className={`cig-avatar-img${speaking ? ' cig-avatar-img--speaking' : ''}`}
            onError={e => {
              (e.currentTarget as HTMLImageElement).src =
                'https://images.pexels.com/photos/1858175/pexels-photo-1858175.jpeg?auto=compress&cs=tinysrgb&w=600&h=800&fit=crop&crop=faces';
            }}
          />
        </div>

        {/* Neon blue waveform — directly below the face */}
        <div className="cig-wave-wrap">
          <CinematicNeonWaveform active={speaking} />
        </div>

        {/* Typewriter subtitle */}
        <div className="cig-subtitle-wrap">
          <span className="cig-subtitle">
            {subtitle || <span className="cig-subtitle__placeholder">Initializing Aippie AI…</span>}
          </span>
          {speaking && <span className="cig-subtitle__cursor" aria-hidden="true" />}
        </div>

        {/* CTA button */}
        <button className="cig-enter-btn" onClick={handleEnter}>
          ENTER AIPPIE ECOSYSTEM
          <span className="cig-enter-btn__arrow">➡</span>
        </button>

        {/* Returning customer fast-access */}
        <button className="cig-customer-btn" onClick={() => { window.speechSynthesis?.cancel(); onAlreadyCustomer(); }}>
          <Lock size={13} />
          I am already a customer — Direct access
        </button>

        {/* Bottom branding strip */}
        <div className="cig-brand-strip">
          <Building2 size={10} />
          <span>AIPPIETAX S.A.</span>
          <span className="cig-brand-strip__sep">·</span>
          <span>18 Autonomous AI Modules</span>
          <span className="cig-brand-strip__sep">·</span>
          <span>E2E Encrypted</span>
          <span className="cig-brand-strip__sep">·</span>
          <span>v214</span>
        </div>
      </div>
    </div>
  );
}

// ── V207: FaceModeOverlay — full-screen Interactive AI Avatar Welcome Mode ────
const FACE_MODE_NAV_BUTTONS = [
  { tab: 'tax',           label: 'Launch AippieAccounts', sub: 'AI Tax & Accounting', color: '#38bdf8', icon: '📊' },
  { tab: 'doctor',        label: 'Open Aippie Doctor · Autism Care',  sub: 'Medical Suite',          color: '#4ade80', icon: '🏥' },
  { tab: 'academy',       label: 'Enter AI Academy',    sub: '12-Week Curriculum',     color: '#f59e0b', icon: '🏫' },
  { tab: 'companionradar',label: 'Companion Radar',     sub: 'Matchmaker · Module 17', color: '#fb7185', icon: '📡' },
] as const;

function FaceModeOverlay({ onNavigate, onClose }: {
  onNavigate: (tab: AppTab) => void;
  onClose: () => void;
}) {
  const cancelRef = useRef(false);

  useEffect(() => {
    cancelRef.current = false;
    if (!('speechSynthesis' in window)) return;
    window.speechSynthesis.cancel();

    const fire = () => {
      if (cancelRef.current) return;
      const u = new SpeechSynthesisUtterance('Hello, I am Aippie, nice meeting you.');
      u.rate  = 0.82;
      u.pitch = 1.02;
      // Prefer a high-quality English voice
      const voices = window.speechSynthesis.getVoices();
      const preferred = voices.find(v => /google.*us english/i.test(v.name))
        ?? voices.find(v => /en[-_]US/i.test(v.lang) && v.localService === false)
        ?? voices.find(v => /en/i.test(v.lang));
      if (preferred) u.voice = preferred;
      window.speechSynthesis.speak(u);
    };

    // Voices may not be loaded yet
    if (window.speechSynthesis.getVoices().length > 0) {
      fire();
    } else {
      const handler = () => { fire(); window.speechSynthesis.removeEventListener('voiceschanged', handler); };
      window.speechSynthesis.addEventListener('voiceschanged', handler);
    }

    return () => {
      cancelRef.current = true;
      window.speechSynthesis?.cancel();
    };
  }, []);

  const handleNav = (tab: AppTab) => {
    window.speechSynthesis?.cancel();
    onNavigate(tab);
  };

  return (
    <div className="fmo-root" role="dialog" aria-modal="true" aria-label="Aippie AI Welcome Mode">
      {/* Backdrop — click to close */}
      <div className="fmo-backdrop" onClick={onClose} />

      <div className="fmo-panel w-full max-w-[1600px] mx-auto px-6">
        {/* Close */}
        <button className="fmo-close" onClick={onClose} aria-label="Close">
          <X size={20} />
        </button>

        {/* Header */}
        <div className="fmo-header">
          <span className="fmo-header__dot" />
          <span className="fmo-header__title">Aippie AI · Interactive Welcome Mode · v214</span>
          <span className="fmo-header__badge">AIPPIETAX S.A.</span>
        </div>

        {/* Avatar — 300×300 upper center */}
        <div className="fmo-avatar-wrap">
          <div className="fmo-avatar-ring fmo-avatar-ring--1" />
          <div className="fmo-avatar-ring fmo-avatar-ring--2" />
          <img
            src="/Jouw_alineatekst_(2).png"
            alt="Aippie"
            className="fmo-avatar-img"
            onError={e => {
              (e.currentTarget as HTMLImageElement).src =
                'https://images.pexels.com/photos/1858175/pexels-photo-1858175.jpeg?auto=compress&cs=tinysrgb&w=600&h=800&fit=crop&crop=faces';
            }}
          />
        </div>

        {/* Synchronized subtitle bar */}
        <div className="fmo-subtitle">
          Hello, I am Aippie — nice meeting you.
        </div>
        <div className="fmo-subtitle-hint">Select a module below or close to explore the full dashboard.</div>

        {/* 2×2 product nav grid */}
        <div className="fmo-grid">
          {FACE_MODE_NAV_BUTTONS.map(btn => (
            <button
              key={btn.tab}
              className="fmo-btn"
              style={{ '--fmo-color': btn.color } as React.CSSProperties}
              onClick={() => handleNav(btn.tab as AppTab)}
            >
              <span className="fmo-btn__emoji">{btn.icon}</span>
              <span className="fmo-btn__label">{btn.label}</span>
              <span className="fmo-btn__sub">{btn.sub}</span>
            </button>
          ))}
        </div>

        {/* Footer */}
        <div className="fmo-footer">
          <Building2 size={9} />
          AIPPIETAX S.A. · v214 · Interactive AI Avatar Welcome Mode · E2EE
          <span className="fmo-footer__sep">·</span>
          <button className="fmo-footer__link" onClick={() => onNavigate('privacy')}>Privacy Policy</button>
        </div>
      </div>
    </div>
  );
}

// ── Settings dropdown ─────────────────────────────────────────────────────────
function SettingsMenu({
  onOpenPartnerPortal,
  onOpenLicenseAdmin,
  onOpenEnterpriseHub,
}: {
  onOpenPartnerPortal: () => void;
  onOpenLicenseAdmin: () => void;
  onOpenEnterpriseHub: () => void;
}) {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  return (
    <div className="settings-menu" ref={ref}>
      <button
        className="settings-menu__gear"
        onClick={() => setOpen(o => !o)}
        aria-label="Settings"
      >
        <Settings size={16}/>
      </button>
      {open && (
        <div className="settings-menu__dropdown">
          <button
            className="settings-menu__item"
            onClick={() => { setOpen(false); onOpenPartnerPortal(); }}
          >
            <span className="settings-menu__item-icon">💼</span>
            B2B Partner Portal
          </button>
          <button
            className="settings-menu__item"
            onClick={() => { setOpen(false); onOpenLicenseAdmin(); }}
          >
            <span className="settings-menu__item-icon">🔑</span>
            License Manager
          </button>
          <button
            className="settings-menu__item settings-menu__item--enterprise"
            onClick={() => { setOpen(false); onOpenEnterpriseHub(); }}
          >
            <span className="settings-menu__item-icon">🏥</span>
            Enterprise Clinic Hub
          </button>
          <div className="settings-menu__divider"/>
          <button
            className="settings-menu__item settings-menu__item--license-link"
            onClick={() => { setOpen(false); onOpenLicenseAdmin(); }}
          >
            <span className="settings-menu__item-icon" style={{ fontSize: 11 }}>🎓</span>
            <span style={{ fontSize: 11, color: '#64748b' }}>Do you have a license code from a school or partner? Click here to activate it manually.</span>
          </button>
          <div className="settings-menu__version">Aippie v214 · AIPPIETAX S.A.</div>
        </div>
      )}
    </div>
  );
}

// ── Main App ──────────────────────────────────────────────────────────────────
export default function App() {
  const { user: authUser } = useAuth();
  const DEV_EMAILS = ['elvin@aippietax.com', 'aippieai@gmail.com'];
  const isSubscribed =
    DEV_EMAILS.includes(authUser?.email ?? '') ||
    authUser?.user_metadata?.is_subscribed === true ||
    authUser?.user_metadata?.subscription_type === 'lifetime' ||
    authUser?.user_metadata?.subscription_type === 'annual';
  const [user, setUser]                         = useState<User | null>(null);
  const [subscription, setSubscription]         = useState<Subscription | null>(null);
  const [tab, setTab]                           = useState<AppTab>(() => {
    if (urlTabParam) return urlTabParam as AppTab;
    const saved = storageGet('aippie_tab') as AppTab | null;
    return saved ?? 'trading';
  });
  // Tab navigation history — enables back button to return to previous tab
  const [tabHistory, setTabHistory]             = useState<AppTab[]>([]);

  const navigateTo = (newTab: AppTab) => {
    setTabHistory(prev => [...prev.slice(-19), tab]);
    setTab(newTab);
    if (typeof window !== 'undefined' && (window as unknown as { gc?: () => void }).gc) {
      (window as unknown as { gc: () => void }).gc();
    }
  };
  const [voiceMode, setVoiceMode]               = useState<VoiceMode>('client');
  const [authReady, setAuthReady]               = useState(true);
  const [showOnboarding, setShowOnboarding]     = useState(false);
  const [showPartnerPortal, setShowPartnerPortal] = useState(false);
  const [lang, setLang]                         = useState<LangCode>(getStoredLang());
  const [freeSilentVoice, setFreeSilentVoice]   = useState(() =>
    storageGet('aippie_free_silent_voice') === '1'
  );
  const [voiceToken, setVoiceToken]             = useState(false);
  const [voiceTokenLoading, setVoiceTokenLoading] = useState(false);
  const [showAippieOverlay, setShowAippieOverlay] = useState(false);
  const [showLicenseAdmin, setShowLicenseAdmin]   = useState(false);
  const [showEnterpriseHub, setShowEnterpriseHub] = useState(false);
  // Life Assistant: auto-starts on login, dismissed state persisted in localStorage
  const [showLifeAssist, setShowLifeAssist] = useState(false);

  // V207: Interactive AI Avatar Welcome Mode
  const [showFaceMode, setShowFaceMode]           = useState(false);
  const [showSidebar,  setShowSidebar]             = useState(false);

  // V61: active avatar session controller — blocks cross-talk between modules

  // Customer direct-access gate — shown when license key exists, URL ?key= param, or user clicks "I am already a customer"
  const [showAccessGate, setShowAccessGate]       = useState(() => {
    // If this is a Supabase auth callback (password reset / email confirm), never show the
    // access gate — let Supabase handle the token and land on the main app.
    const hash = window.location.hash;
    const hashParams = new URLSearchParams(hash.startsWith('#') ? hash.slice(1) : hash);
    const isAuthCallback = hashParams.get('type') === 'recovery'
      || hashParams.get('type') === 'signup'
      || hashParams.get('type') === 'magiclink'
      || hashParams.get('access_token') != null;

    if (isAuthCallback) {
      // Strip the hash so the token isn't leaked to analytics
      window.history.replaceState(null, '', window.location.pathname + window.location.search);
      return false;
    }

    // Support ?key=AIPP-XXXX-XXXX-XXXX in the URL for cross-device bookmarking
    const urlKey = new URLSearchParams(window.location.search).get('key');
    if (urlKey) {
      storageSet('aippie_license_key', urlKey.toUpperCase());
      storageRemove('aippie_license_validated'); // force re-validate on new key
      const clean = window.location.pathname + window.location.hash;
      window.history.replaceState(null, '', clean);
      return true; // always show gate for new key so it validates
    }

    const storedKey = storageGet('aippie_license_key');
    if (!storedKey) return false;

    // If this key was already validated and user has a saved tab, skip the gate.
    // This prevents the 10-second spinner on every return visit.
    const validatedKey = storageGet('aippie_license_validated');
    if (validatedKey === storedKey && storageGet('aippie_tab')) {
      // Also mark the cinematic intro as seen so showCinema stays false.
      // Without this, license-key users never see CinematicIntroGate and
      // aippie_intro_seen is never set, causing the gate to re-render and
      // "throw the user outside" on every session.
      storageSet('aippie_intro_seen', '1');
      return false;
    }

    return true;
  });

  // V122: permission gateway — shown once after first onboarding completion
  const [showPermissions, setShowPermissions]     = useState(false);

  // BoardroomLanding is permanent homepage — only skip it when arriving via ?tab= deep link
  const [showLanding, setShowLanding] = useState(!urlTabParam);
  const [isTransitioning, setIsTransitioning] = useState(false);
  // True when user entered via a boardroom circle CTA — enables focused fullscreen mode
  const [fromLanding, setFromLanding] = useState(false);
  const [focusSidebarOpen, setFocusSidebarOpen] = useState(false);

  // Cinematic intro permanently disabled — always false
  const [showCinema] = useState(false);
  const [activeAvatarSession, setActiveAvatarSession] = useState<ActiveAvatarSession>('presenter');

  // V98: script to play when AippiePresenter first mounts after landing exit.
  // Set by handleLandingComplete / handleLandingNavigate before setShowLanding(false).
  const [initialScript,  setInitialScript]  = useState<string>(GENERIC_WELCOME[0]);
  const [initialEmotion, setInitialEmotion] = useState<PresenterEmotion>(GENERIC_WELCOME[1]);

  const mountedRef   = useRef(true);
  const presenterRef = useRef<AippiePresenterHandle>(null);

  // Persist tab + landing state in localStorage so they survive tab kills on mobile
  useEffect(() => { storageSet('aippie_tab', tab); }, [tab]);
  useEffect(() => { if (!showLanding) storageSet('aippie_landed', '1'); }, [showLanding]);

  // Anti-Tab-Close Guard — serialize full workspace state on every unload so no
  // session data is lost on sudden tab close, hard refresh, or mobile kill.
  useEffect(() => {
    const handleBeforeUnload = () => {
      try {
        const existing = localStorage.getItem('aippie_ai_account_secure_state_v1');
        const base = existing ? JSON.parse(existing) : {};
        localStorage.setItem('aippie_ai_account_secure_state_v1', JSON.stringify({
          ...base,
          activeTab: tab,
          showLanding,
          lang,
          timestamp: Date.now(),
        }));
      } catch { /* noop — private browsing may block storage */ }
    };
    window.addEventListener('beforeunload', handleBeforeUnload);
    return () => window.removeEventListener('beforeunload', handleBeforeUnload);
  }, [tab, showLanding, lang]);

  // ── Auth / subscription ────────────────────────────────────────────────────
  const fetchSubscription = async (userId: string) => {
    const { data } = await supabase
      .from('subscriptions')
      .select('*')
      .eq('user_id', userId)
      .eq('status', 'active')
      .order('created_at', { ascending: false })
      .limit(1)
      .maybeSingle();
    if (mountedRef.current) setSubscription(data as Subscription | null);
  };

  const loadVoiceToken = async () => {
    const deviceKey = storageGet('aippie_device_key') ?? '';
    if (!deviceKey) {
      if (mountedRef.current) { setVoiceToken(false); setVoiceTokenLoading(false); }
      return;
    }
    // Hard timeout: never block the app more than 1.5 seconds for this query
    const timer = setTimeout(() => {
      if (mountedRef.current) { setVoiceToken(false); setVoiceTokenLoading(false); }
    }, 1500);
    try {
      const { data } = await supabase
        .from('client_profiles')
        .select('voice_token')
        .eq('device_key', deviceKey)
        .maybeSingle();
      clearTimeout(timer);
      if (mountedRef.current) {
        setVoiceToken(data?.voice_token === true);
        setVoiceTokenLoading(false);
      }
    } catch {
      clearTimeout(timer);
      if (mountedRef.current) { setVoiceToken(false); setVoiceTokenLoading(false); }
    }
  };

  useEffect(() => {
    mountedRef.current = true;

    // Auto-detect language from IP on first visit (no stored preference)
    if (!storageGet('aippie_lang')) {
      detectGeoLang().then(geoLang => {
        if (geoLang && mountedRef.current) {
          setLang(geoLang);
          storeLang(geoLang);
        }
      });
    }

    if (!storageGet('aippie_onboarded')) {
      setShowOnboarding(true);
      setVoiceTokenLoading(false);
    } else if (storageGet('aippie_license_key')) {
      // License-key users don't use the voice token — skip the DB query entirely
      setVoiceTokenLoading(false);
    } else {
      loadVoiceToken();
    }

    // Sync user from AuthContext (which handles TOKEN_REFRESHED, SIGNED_IN, etc.)
    setUser(authUser);
    if (authUser) fetchSubscription(authUser.id);
    else setSubscription(null);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [authUser]);

  useEffect(() => {
    // Listen for PASSWORD_RECOVERY and SIGNED_IN events
    const { data: listener } = supabase.auth.onAuthStateChange((event) => {
      if (event === 'PASSWORD_RECOVERY') {
        setShowAccessGate(false);
        setShowLanding(false);
        setTab('securechat');
      }
      if (event === 'SIGNED_IN') {
        setShowAccessGate(false);
        setShowLanding(false);
      }
    });
    return () => listener.subscription.unsubscribe();
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // The user can access it any time from the bottom nav "Life AI" button.
  const lifeAssistShownRef = useRef(false);
  useEffect(() => {
    if (user) {
      if (!lifeAssistShownRef.current && storageGet('aippie_lifeassist_dismissed') !== '1' && storageGet('aippie_lifeassist_autoshown') !== '1') {
        lifeAssistShownRef.current = true;
        storageSet('aippie_lifeassist_autoshown', '1');
        setShowLifeAssist(true);
      }
    } else {
      lifeAssistShownRef.current = false;
      setShowLifeAssist(false);
    }
  }, [user]);

  // V206: Listen for product-nav CustomEvents dispatched by AippieVoiceOverlay welcome buttons
  useEffect(() => {
    const handler = (e: Event) => {
      const tab = (e as CustomEvent<string>).detail as AppTab;
      if (tab) {
        setShowLanding(false);
        navigateTo(tab);
        setActiveAvatarSession('presenter');
        const script = TAB_SCRIPTS[tab];
        if (script) presenterRef.current?.speak(script[0], script[1] as PresenterEmotion);
      }
    };
    window.addEventListener('aippie:navigate', handler);
    return () => window.removeEventListener('aippie:navigate', handler);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleOnboardingComplete = (selectedLang: LangCode, tokens: OnboardingTokens) => {
    setLang(selectedLang);
    if (tokens.voiceToken)      setVoiceToken(true);
    if (tokens.freeSilentVoice) {
      storageSet('aippie_free_silent_voice', '1');
      setFreeSilentVoice(true);
    }
    setShowOnboarding(false);
    // Show permission gateway once after first onboarding
    if (!storageGet('aippie_permissions_shown')) {
      setShowPermissions(true);
    }
  };

  const handlePermissionsComplete = (_perms: PermissionSet) => {
    setShowPermissions(false);
  };

  // ── V114: Language switch handler ─────────────────────────────────────────
  const handleLangChange = (l: LangCode) => {
    storeLang(l);
    setLang(l);
    window.speechSynthesis?.cancel();
  };

  // ── V121: Back handler — always return to BoardroomLanding ──────────────
  const handleBackToMenu = () => {
    window.speechSynthesis?.cancel();
    window.location.href = '/';
  };

  // ── Landing motor complete ─────────────────────────────────────────────────
  // V98: cancel any residual landing speech, set the initial script for the
  // presenter that is about to mount, then flip the gate — no setTimeout speak().
  const handleLandingComplete = () => {
    window.speechSynthesis?.cancel();
    setInitialScript(GENERIC_WELCOME[0]);
    setInitialEmotion(GENERIC_WELCOME[1]);
    setIsTransitioning(true);
    setTimeout(() => {
      setFromLanding(true);
      startTransition(() => { setShowLanding(false); });
      setIsTransitioning(false);
    }, 200);
  };

  // ── Deep-link from Landing "Go to Product" CTA ────────────────────────────
  // V98: cancel landing audio, set contextual initialScript, then unmount.
  // AippiePresenter receives the script as a prop and plays it on mount —
  // no competing speech from anywhere else.
  const handleLandingNavigate = (appTab: string) => {
    // Resolve user-facing aliases to canonical AppTab names
    const aliases: Record<string, string> = {
      accounts:   'accounting',
      aippie:     'unified',
      trust:      'trustdashboard',
      trustfund:  'trustdashboard',
    };
    const resolved = aliases[appTab] ?? appTab;

    const validTabs: AppTab[] = [
      'voice','wifi','parking','silentvoice','trading','tax',
      'companion','wearable','safecheckin','doctor','realestate',
      'assistant','voipscript','quantumcinema','aippiedev','academy','robotics','cybersuit','livestage','voicenav','wallet','legal','reunion','b2b','alphatrade',
      'morning','unified','tournament','signalradar',
      'securechat','videovault','docvault','aippiemail','accounting','lifeassist',
      'trust','trustdashboard','powerpack','powerpulse',
    ];
    if (!validTabs.includes(resolved as AppTab)) return;

    window.speechSynthesis?.cancel();
    navigateTo(resolved as AppTab);

    if (resolved === 'companion') {
      setActiveAvatarSession('companion');
      setInitialScript(GENERIC_WELCOME[0]);
      setInitialEmotion(GENERIC_WELCOME[1]);
    } else {
      setActiveAvatarSession('presenter');
      const entry = TAB_SCRIPTS[resolved] ?? GENERIC_WELCOME;
      setInitialScript(entry[0]);
      setInitialEmotion(entry[1]);
    }

    setIsTransitioning(true);
    setTimeout(() => {
      setFromLanding(true);
      startTransition(() => { setShowLanding(false); });
      setIsTransitioning(false);
    }, 200);
  };

  // ── Customer direct-access gate ───────────────────────────────────────────
  if (showAccessGate) {
    const storedKey = storageGet('aippie_license_key');
    return (
      <ClientAccessGate
        autoKey={storedKey}
        onAccess={(granted: AccessGranted) => {
          window.speechSynthesis?.cancel();
          storageSet('aippie_license_validated', granted.licenseKey);
          storageSet('aippie_intro_seen', '1');
          storageSet('aippie_landed', '1');
          setShowAccessGate(false);
          setShowLanding(false);
          navigateTo(granted.appTab as AppTab);
          setActiveAvatarSession('presenter');
          const entry = TAB_SCRIPTS[granted.appTab] ?? GENERIC_WELCOME;
          setInitialScript(entry[0]);
          setInitialEmotion(entry[1]);
        }}
        onGoToLanding={() => {
          setShowAccessGate(false);
        }}
      />
    );
  }

  if (isTransitioning) {
    return <div style={{ position: 'fixed', inset: 0, background: '#000', zIndex: 9999 }} />;
  }

  // ── V60: Landing gate — always renders first, no session skip ──────────────
  if (showLanding) {
    return (
      <div className="v60-landing-gate">
        <MatrixCodeBackground />
        <BoardroomLanding
          onComplete={handleLandingComplete}
          onNavigate={handleLandingNavigate}
          lang={lang}
          onLangChange={handleLangChange}
          user={user}
        />
      </div>
    );
  }

  // ── Focused fullscreen mode (entered via Boardroom CTA) ──────────────────
  if (fromLanding) {
    const FOCUS_MODULES = [
      { tab: 'accounting' as AppTab,  label: 'AippieAccounts',   color: '#1D9E75' },
      { tab: 'trading'    as AppTab,  label: 'AippieTrading',    color: '#EF9F27' },
      { tab: 'securechat' as AppTab,  label: 'AippieSecureChat', color: '#7F77DD' },
      { tab: 'doctor'     as AppTab,  label: 'Doctor · Autism Care',        color: '#38bdf8' },
      { tab: 'lifeassist' as AppTab,  label: 'AippieLifeAssist', color: '#D4537E' },
      { tab: 'unified'    as AppTab,  label: 'Aippie',           color: '#378ADD' },
    ];
    const activeModule = FOCUS_MODULES.find(m => m.tab === tab) ?? FOCUS_MODULES[0];

    return (
      <div style={{
        position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.92)',
        fontFamily: "'Inter', -apple-system, sans-serif",
        display: 'flex', flexDirection: 'column',
      }}>
        <MatrixCodeBackground />
        {/* Focused header bar */}
        <div style={{
          height: 48, flexShrink: 0,
          display: 'flex', alignItems: 'center', gap: 12,
          padding: '0 16px',
          background: 'rgba(0,0,0,0.92)',
          borderBottom: '1px solid rgba(255,255,255,0.06)',
          zIndex: 50,
        }}>
          {/* Hamburger */}
          <button
            onClick={() => setFocusSidebarOpen(o => !o)}
            aria-label="Toggle module menu"
            style={{
              display: 'flex', flexDirection: 'column', gap: 4,
              background: 'none', border: 'none', cursor: 'pointer', padding: 6, flexShrink: 0,
            }}
          >
            <span style={{ width: 18, height: 2, background: activeModule.color, borderRadius: 2, display: 'block', transition: 'transform 0.2s' }} />
            <span style={{ width: 13, height: 2, background: activeModule.color, borderRadius: 2, display: 'block' }} />
            <span style={{ width: 18, height: 2, background: activeModule.color, borderRadius: 2, display: 'block' }} />
          </button>

          {/* Module name */}
          <span style={{
            color: activeModule.color, fontWeight: 700, fontSize: 13,
            letterSpacing: '0.04em', flex: 1,
          }}>
            {activeModule.label}
          </span>

          {/* Back to Boardroom */}
          <button
            onClick={() => {
              setFromLanding(false);
              setFocusSidebarOpen(false);
              startTransition(() => { setShowLanding(true); });
            }}
            style={{
              background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.1)',
              color: '#94a3b8', fontSize: 10, fontWeight: 600,
              padding: '5px 12px', borderRadius: 16, cursor: 'pointer',
              letterSpacing: '0.04em', flexShrink: 0,
            }}
          >
            ← Boardroom
          </button>
        </div>

        {/* Sidebar drawer — full AppSidebar for authenticated users */}
        <AppSidebar
          open={focusSidebarOpen}
          currentTab={tab}
          onClose={() => setFocusSidebarOpen(false)}
          onNavigate={(t) => {
            navigateTo(t as AppTab);
            setFocusSidebarOpen(false);
            const entry = TAB_SCRIPTS[t] ?? GENERIC_WELCOME;
            presenterRef.current?.speak(entry[0], entry[1] as PresenterEmotion);
          }}
        />

        {/* Module content — fullscreen */}
        <div style={{ flex: 1, overflowY: 'auto', WebkitOverflowScrolling: 'touch' as React.CSSProperties['WebkitOverflowScrolling'], height: 'calc(100vh - 52px)', position: 'relative' }}>
          <Suspense fallback={
            <div style={{ display:'flex', alignItems:'center', justifyContent:'center', height:'100%' }}>
              <div style={{ width:24, height:24, borderRadius:'50%', border:'2px solid rgba(255,255,255,0.1)', borderTopColor: activeModule.color, animation:'spin 0.9s linear infinite' }} />
            </div>
          }>
            <ErrorBoundary>
              {tab === 'accounting'  && <PaywallGate module="accounting"><AippieAccountingView user={user} /></PaywallGate>}
              {tab === 'trading'     && <PaywallGate module="trading"><AippieTradingView user={user} /></PaywallGate>}
              {tab === 'alphatrade'  && <PaywallGate module="alphatrade"><AippieTradingView user={user} /></PaywallGate>}
              {tab === 'securechat'  && <AippieSecureChatView user={user} onStartVideoCall={() => { navigateTo('videovault'); }} onOpenLifeAssist={() => { storageRemove('aippie_lifeassist_dismissed'); storageRemove('aippie_lifeassist_autoshown'); setShowLifeAssist(true); }} />}
              {tab === 'doctor'      && <AippieDoctorView />}
              {tab === 'trustdashboard' && <AippieTrustDashboard user={user} />}
              {tab === 'trust'          && <AippieTrustDashboard user={user} />}
              {tab === 'energy'         && <AippieEnergyView />}
              {tab === 'lifeassist'  && <ErrorBoundary><AippieLifeAssistantView /></ErrorBoundary>}
              {tab === 'unified'     && <AippieUnifiedDashboard user={user} />}
              {tab === 'tax'         && <AippieTaxView />}
              {tab === 'wifi'        && <WiFiView />}
              {tab === 'parking'     && <ParkingView user={user} />}
              {tab === 'wearable'    && <WearableLinkView />}
              {tab === 'safecheckin' && <SafeCheckInView user={user} />}
              {tab === 'realestate'  && <RealEstateView />}
              {tab === 'assistant'   && <AippieAssistantView />}
              {tab === 'voipscript'  && <VoipScriptView />}
              {tab === 'quantumcinema' && <QuantumTimeMachineView />}
              {tab === 'aippiedev'   && <AippieDevView />}
              {tab === 'academy'     && <AippieAcademyView />}
              {tab === 'companionradar' && <CompanionRadarView />}
              {tab === 'robotics'    && <AippieRoboticsView />}
              {tab === 'cybersuit'   && <AippieCyberSuitView />}
              {tab === 'livestage'   && <PaywallGate module="livestage"><AippieLiveStageView /></PaywallGate>}
              {tab === 'voicenav'    && <AippieVoiceNavView />}
              {tab === 'wallet'      && <DigitalWalletView user={user} />}
              {tab === 'legal'       && <AippieLegalView user={user} />}
              {tab === 'reunion'     && <AippieReunionView user={user} />}
              {tab === 'b2b'         && <AippieB2BView user={user} />}
              {tab === 'morning'     && <AippieMorningBriefingView user={user} />}
              {tab === 'tournament'  && <AippieTournamentView />}
              {tab === 'signalradar' && <AippieSignalRadarView />}
              {tab === 'videovault'  && <AippieVideoVaultView user={user} onNavigateToChat={() => { navigateTo('securechat'); }} />}
              {tab === 'docvault'    && <AippieDocumentVaultView user={user} />}
              {tab === 'aippiemail'  && <AippieMailView user={user} />}
              {tab === 'pricing'     && <PricingView />}
              {tab === 'privacy'     && <PrivacyPolicyView />}
              {tab === 'silentvoice' && <SilentVoiceView freeSilentVoice={freeSilentVoice} onNavigateToDoctor={() => { navigateTo('doctor'); }} />}
              {tab === 'aimanager'   && <ErrorBoundary><EnterpriseDashboard userId={user?.id} onNavigate={(t) => navigateTo(t as AppTab)} /></ErrorBoundary>}
              {tab === 'powerpack'   && <ErrorBoundary><CommercialAIPowerpack userId={user?.id} onNavigate={(t) => navigateTo(t as AppTab)} /></ErrorBoundary>}
              {tab === 'powerpulse'  && <ErrorBoundary><AippiePowerPulse /></ErrorBoundary>}
            </ErrorBoundary>
          </Suspense>
        </div>
      </div>
    );
  }

  // ── Main app shell ─────────────────────────────────────────────────────────
  return (
    <div className="superapp-root v60-root">
      <MatrixCodeBackground />
      {/* ─── Global sidebar — all modules ───────────────────────────────────── */}
      <AppSidebar
        open={showSidebar}
        currentTab={tab}
        onClose={() => setShowSidebar(false)}
        onNavigate={(t) => {
          window.speechSynthesis?.cancel();
          navigateTo(t as AppTab);
          setActiveAvatarSession('presenter');
          const entry = TAB_SCRIPTS[t] ?? GENERIC_WELCOME;
          presenterRef.current?.speak(entry[0], entry[1] as PresenterEmotion);
        }}
      />
      {/* ─────────────────────────────────────────────────────────────────────
          V60/V61: OMNIPRESENT AVATAR BAR
          Collapses and freezes audio when CompanionView owns the session.
      ───────────────────────────────────────────────────────────────────── */}
      <AippiePresenter
        ref={presenterRef}
        collapsed={activeAvatarSession === 'companion'}
        initialScript={initialScript}
        initialEmotion={initialEmotion}
      />

      {/* ─── Modals / overlays ────────────────────────────────────────────── */}
      {showOnboarding && (
        <OnboardingModal onComplete={handleOnboardingComplete} />
      )}

      {/* ─── V122: Permission Gateway ─────────────────────────────────────── */}
      {showPermissions && !showOnboarding && (
        <PermissionGatewayModal onComplete={handlePermissionsComplete} />
      )}

      {!showOnboarding && <SofiaNotification lang={lang} />}

      {!showOnboarding && (
        <div className="superapp-top-bar">
          {/* Sidebar hamburger menu */}
          <button
            onClick={() => setShowSidebar(true)}
            aria-label="Open module menu"
            style={{
              display: 'flex', alignItems: 'center', gap: 5,
              background: 'rgba(55,138,221,0.1)', border: '1px solid rgba(55,138,221,0.25)',
              borderRadius: 8, padding: '5px 10px', cursor: 'pointer', color: '#94a3b8',
              fontSize: 10, fontWeight: 600, letterSpacing: '0.04em', flexShrink: 0,
            }}
          >
            <span style={{ display: 'flex', flexDirection: 'column', gap: 3 }}>
              <span style={{ width: 14, height: 1.5, background: '#94a3b8', borderRadius: 2, display: 'block' }} />
              <span style={{ width: 10, height: 1.5, background: '#94a3b8', borderRadius: 2, display: 'block' }} />
              <span style={{ width: 14, height: 1.5, background: '#94a3b8', borderRadius: 2, display: 'block' }} />
            </span>
            Menu
          </button>
          {/* Prominent Home button — resets to full cinematic intro */}
          <button
            className="topbar-home-btn"
            onClick={() => {
              window.speechSynthesis?.cancel();
              navigateTo('voice');
              setActiveAvatarSession('presenter');
            }}
            aria-label="Go to home"
          >
            <LayoutGrid size={14} />
            <span>Home</span>
          </button>
          <SettingsMenu
            onOpenPartnerPortal={() => setShowPartnerPortal(true)}
            onOpenLicenseAdmin={() => setShowLicenseAdmin(true)}
            onOpenEnterpriseHub={() => setShowEnterpriseHub(true)}
          />
          {/* V207: Activate Live AI Face Mode trigger */}
          <button
            className="fmo-trigger-btn"
            onClick={() => setShowFaceMode(true)}
            aria-label="Activate Live AI Face Mode"
          >
            <span className="fmo-trigger-btn__dot" />
            🎥 Activate Live AI Face Mode
          </button>
          <GlobalLangSelector lang={lang} onLangChange={handleLangChange} />
          {/* Live Channel indicator */}
          <button
            onClick={() => setTab('morning' as AppTab)}
            style={{
              display: 'flex', alignItems: 'center', gap: 5,
              background: 'rgba(239,68,68,0.12)', border: '1px solid rgba(239,68,68,0.35)',
              borderRadius: 20, padding: '4px 10px', cursor: 'pointer', color: '#f87171',
              fontSize: 10, fontWeight: 700, letterSpacing: '0.06em',
            }}
            title="Live Channel — click to open"
          >
            <span style={{
              width: 7, height: 7, borderRadius: '50%', background: '#ef4444',
              display: 'inline-block',
              animation: 'live-ping 1.2s cubic-bezier(0,0,0.2,1) infinite',
              boxShadow: '0 0 0 0 rgba(239,68,68,0.7)',
            }} />
            LIVE
          </button>
        </div>
      )}

      {/* ─── V121: Universal Back-to-Cockpit button ──────────────────────── */}
      {!showOnboarding && (
        <button
          className="back-to-menu-btn"
          onClick={handleBackToMenu}
          aria-label="Back to Menu"
        >
          <span className="back-to-menu-btn__arrow">←</span>
          <span className="back-to-menu-btn__label">Back to Menu</span>
        </button>
      )}

      {showPartnerPortal && (
        <Suspense fallback={null}><PartnerPortalView onClose={() => setShowPartnerPortal(false)} /></Suspense>
      )}

      {showLicenseAdmin && (
        <Suspense fallback={null}><AdminLicenseView onClose={() => setShowLicenseAdmin(false)} /></Suspense>
      )}

      {showEnterpriseHub && (
        <Suspense fallback={null}><EnterpriseClinicHub onClose={() => setShowEnterpriseHub(false)} /></Suspense>
      )}

      {/* V207: Interactive AI Avatar Welcome Mode overlay */}
      {showFaceMode && (
        <FaceModeOverlay
          onNavigate={(tab) => {
            setShowFaceMode(false);
            navigateTo(tab);
            setActiveAvatarSession('presenter');
            const script = TAB_SCRIPTS[tab];
            if (script) presenterRef.current?.speak(script[0], script[1] as PresenterEmotion);
          }}
          onClose={() => setShowFaceMode(false)}
        />
      )}

      {showAippieOverlay && (
        <div className="aippie-overlay">
          <button
            className="aippie-overlay__close"
            onClick={() => setShowAippieOverlay(false)}
            aria-label="Close Aippie"
          >
            <X size={18}/>
          </button>
          <LivingAvatarView subscription={subscription} />
        </div>
      )}

      {/* ─── Life Assistant persistent overlay ──────────────────────────── */}
      {showLifeAssist && user && (
        <div className="life-assist-panel">
          <Suspense fallback={null}>
            <AippieLifeAssistantView onClose={() => {
              setShowLifeAssist(false);
              storageSet('aippie_lifeassist_dismissed', '1');
            }} />
          </Suspense>
        </div>
      )}

      {/* ─── Global Life Assistant floating trigger button ────────────────── */}
      {fromLanding && tab !== 'lifeassist' && !showLifeAssist && (
        <button
          onClick={() => setShowLifeAssist(true)}
          style={{
            position: 'fixed', bottom: '16px', right: '16px',
            borderRadius: '40px', padding: '10px 18px',
            background: 'linear-gradient(135deg, #EC4899, #8B5CF6)',
            border: 'none', cursor: 'pointer', zIndex: 9998,
            boxShadow: '0 0 20px rgba(236,72,153,0.4)',
            display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '7px',
            animation: 'pulse 2s infinite', whiteSpace: 'nowrap',
          }}
          aria-label="Open Life Assistant"
        >
          <span style={{ fontSize: '16px' }}>🤖</span>
          <span style={{ fontSize: '12px', fontWeight: 700, color: '#fff', letterSpacing: '0.03em' }}>AI Assistant ↗</span>
        </button>
      )}

      {/* ─── Voice mode switcher ──────────────────────────────────────────── */}
      {tab === 'voice' && (
        <div className="voice-mode-switcher">
          <button
            className={`voice-mode-btn${voiceMode === 'client' ? ' voice-mode-btn--active' : ''}`}
            onClick={() => setVoiceMode('client')}
          >
            <Mic size={12} /> Client
          </button>
          <button
            className={`voice-mode-btn${voiceMode === 'translator' ? ' voice-mode-btn--active' : ''}`}
            onClick={() => setVoiceMode('translator')}
          >
            <Headphones size={12} /> Interpreter
          </button>
        </div>
      )}

      {/* ─── V157: Horizontal metrics telemetry banner (desktop only) ──────── */}
      {!showOnboarding && (
        <div className="v157-metrics-banner" aria-hidden="true">
          <div className="v157-metrics-banner__track">
            {[
              { label: 'Active Modules',   val: '18',        cls: 'v157-metrics-banner__item--blue'  },
              { label: 'Subscribers',      val: '2,847',     cls: 'v157-metrics-banner__item--green' },
              { label: 'API Uptime',       val: '99.98%',    cls: 'v157-metrics-banner__item--green' },
              { label: 'TLS',              val: '256-bit',   cls: 'v157-metrics-banner__item--blue'  },
              { label: 'Builds / 24h',     val: '1,203',     cls: 'v157-metrics-banner__item--amber' },
              { label: 'Edge Latency',     val: '< 11ms',    cls: 'v157-metrics-banner__item--green' },
              { label: 'Store Dispatches', val: '318',       cls: 'v157-metrics-banner__item--pink'  },
              { label: 'Trust Score',      val: 'AAA',       cls: 'v157-metrics-banner__item--green' },
              { label: 'GDPR',             val: 'Compliant', cls: 'v157-metrics-banner__item--blue'  },
              { label: 'HIPAA',            val: 'Compliant', cls: 'v157-metrics-banner__item--blue'  },
              { label: 'PCI-DSS',          val: 'Level 1',   cls: 'v157-metrics-banner__item--green' },
              { label: 'Version',          val: 'v214',      cls: 'v157-metrics-banner__item--amber' },
            ].concat([
              { label: 'Active Modules',   val: '18',        cls: 'v157-metrics-banner__item--blue'  },
              { label: 'Subscribers',      val: '2,847',     cls: 'v157-metrics-banner__item--green' },
              { label: 'API Uptime',       val: '99.98%',    cls: 'v157-metrics-banner__item--green' },
              { label: 'TLS',              val: '256-bit',   cls: 'v157-metrics-banner__item--blue'  },
              { label: 'Builds / 24h',     val: '1,203',     cls: 'v157-metrics-banner__item--amber' },
              { label: 'Edge Latency',     val: '< 11ms',    cls: 'v157-metrics-banner__item--green' },
              { label: 'Store Dispatches', val: '318',       cls: 'v157-metrics-banner__item--pink'  },
              { label: 'Trust Score',      val: 'AAA',       cls: 'v157-metrics-banner__item--green' },
              { label: 'GDPR',             val: 'Compliant', cls: 'v157-metrics-banner__item--blue'  },
              { label: 'HIPAA',            val: 'Compliant', cls: 'v157-metrics-banner__item--blue'  },
              { label: 'PCI-DSS',          val: 'Level 1',   cls: 'v157-metrics-banner__item--green' },
              { label: 'Version',          val: 'v214',      cls: 'v157-metrics-banner__item--amber' },
            ]).map((m, i) => (
              <div key={i} className={`v157-metrics-banner__item ${m.cls}`}>
                {m.label} <span className="v157-val">{m.val}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ─── Main content ─────────────────────────────────────────────────── */}
      <div className="superapp-content">
        <Suspense fallback={
          <div style={{ display:'flex', alignItems:'center', justifyContent:'center', height:'60vh', opacity: 0.4 }}>
            <div style={{ width:24, height:24, borderRadius:'50%', border:'2px solid rgba(37,99,235,0.25)', borderTopColor:'#2563eb', animation:'spin 0.9s linear infinite' }} />
          </div>
        }>
        {tab === 'voice' && voiceMode === 'client' && (
          <ErrorBoundary><ClientView user={user} subscription={subscription} voiceToken={isSubscribed || voiceToken} onVoiceTokenGranted={() => setVoiceToken(true)} /></ErrorBoundary>
        )}
        {tab === 'voice' && voiceMode === 'translator' && (
          user
            ? <ErrorBoundary><TranslatorView user={user} /></ErrorBoundary>
            : <div className="app"><div className="app__bg" /><div className="auth-required"><p className="auth-required__text">Sign in as a client first to access the interpreter portal.</p></div></div>
        )}
        {tab === 'wifi'        && <ErrorBoundary><WiFiView /></ErrorBoundary>}
        {tab === 'parking'     && <ErrorBoundary><ParkingView user={user} /></ErrorBoundary>}
        {tab === 'silentvoice' && (
          <ErrorBoundary><SilentVoiceView freeSilentVoice={freeSilentVoice} onNavigateToDoctor={() => { window.speechSynthesis?.cancel(); navigateTo('doctor'); setActiveAvatarSession('presenter'); presenterRef.current?.speak('Connecting you to the Aippie Doctor specialist consultation. Please have your payment card ready to begin your telehealth session.', 'warm'); }} /></ErrorBoundary>
        )}
        {tab === 'trading'     && <ErrorBoundary><PaywallGate module="trading"><AippieTradingView user={user} /></PaywallGate></ErrorBoundary>}
        {tab === 'tax'         && <ErrorBoundary><AippieTaxView /></ErrorBoundary>}
        {tab === 'wearable'    && <ErrorBoundary><WearableLinkView /></ErrorBoundary>}
        {tab === 'safecheckin' && <ErrorBoundary><SafeCheckInView user={user} /></ErrorBoundary>}
        {tab === 'doctor'      && <ErrorBoundary><AippieDoctorView /></ErrorBoundary>}
        {tab === 'trustdashboard' && <ErrorBoundary><AippieTrustDashboard user={user} /></ErrorBoundary>}
        {tab === 'trust'          && <ErrorBoundary><AippieTrustDashboard user={user} /></ErrorBoundary>}
        {tab === 'energy'         && <ErrorBoundary><AippieEnergyView /></ErrorBoundary>}
        {tab === 'realestate'  && <ErrorBoundary><RealEstateView /></ErrorBoundary>}
        {tab === 'assistant'      && <ErrorBoundary><AippieAssistantView /></ErrorBoundary>}
        {tab === 'voipscript'     && <ErrorBoundary><VoipScriptView /></ErrorBoundary>}
        {tab === 'quantumcinema'  && <ErrorBoundary><QuantumTimeMachineView /></ErrorBoundary>}
        {tab === 'aippiedev'   && <ErrorBoundary><AippieDevView /></ErrorBoundary>}
        {tab === 'academy'        && <ErrorBoundary><AippieAcademyView /></ErrorBoundary>}
        {tab === 'companionradar' && <ErrorBoundary><CompanionRadarView /></ErrorBoundary>}
        {tab === 'robotics'       && <ErrorBoundary><AippieRoboticsView /></ErrorBoundary>}
        {tab === 'cybersuit'      && <ErrorBoundary><AippieCyberSuitView /></ErrorBoundary>}
        {tab === 'livestage'      && <ErrorBoundary><PaywallGate module="livestage"><AippieLiveStageView /></PaywallGate></ErrorBoundary>}
        {tab === 'voicenav'       && <ErrorBoundary><AippieVoiceNavView /></ErrorBoundary>}
        {tab === 'wallet'         && <ErrorBoundary><DigitalWalletView user={user} /></ErrorBoundary>}
        {tab === 'legal'          && <ErrorBoundary><AippieLegalView user={user} /></ErrorBoundary>}
        {tab === 'reunion'        && <ErrorBoundary><AippieReunionView user={user} /></ErrorBoundary>}
        {tab === 'b2b'            && <ErrorBoundary><AippieB2BView user={user} /></ErrorBoundary>}
        {tab === 'alphatrade'     && <ErrorBoundary><PaywallGate module="alphatrade"><AippieTradingView user={user} /></PaywallGate></ErrorBoundary>}
        {tab === 'privacy'        && <ErrorBoundary><PrivacyPolicyView /></ErrorBoundary>}
        {tab === 'morning'        && <ErrorBoundary><AippieMorningBriefingView user={user} /></ErrorBoundary>}
        {tab === 'unified'        && <ErrorBoundary><AippieUnifiedDashboard user={user} /></ErrorBoundary>}
        {tab === 'tournament'     && <ErrorBoundary><AippieTournamentView /></ErrorBoundary>}
        {tab === 'signalradar'    && <ErrorBoundary><AippieSignalRadarView /></ErrorBoundary>}
        {tab === 'accounting'     && <ErrorBoundary><PaywallGate module="accounting"><AippieAccountingView user={user} /></PaywallGate></ErrorBoundary>}
        {tab === 'lifeassist'     && <ErrorBoundary><AippieLifeAssistantView /></ErrorBoundary>}
        {tab === 'aimanager'      && <ErrorBoundary><Suspense fallback={null}><EnterpriseDashboard userId={user?.id} onNavigate={(t) => navigateTo(t as AppTab)} /></Suspense></ErrorBoundary>}
        {tab === 'powerpack'      && <ErrorBoundary><Suspense fallback={null}><CommercialAIPowerpack userId={user?.id} onNavigate={(t) => navigateTo(t as AppTab)} /></Suspense></ErrorBoundary>}
        {tab === 'powerpulse'     && <ErrorBoundary><Suspense fallback={null}><AippiePowerPulse /></Suspense></ErrorBoundary>}
        {tab === 'securechat'     && <ErrorBoundary><AippieSecureChatView user={user} onStartVideoCall={() => { navigateTo('videovault'); setActiveAvatarSession('presenter'); }} onOpenLifeAssist={() => { storageRemove('aippie_lifeassist_dismissed'); storageRemove('aippie_lifeassist_autoshown'); setShowLifeAssist(true); }} /></ErrorBoundary>}
        {tab === 'videovault'     && <ErrorBoundary><AippieVideoVaultView user={user} onNavigateToChat={() => { navigateTo('securechat'); setActiveAvatarSession('presenter'); }} /></ErrorBoundary>}
        {tab === 'docvault'       && <ErrorBoundary><AippieDocumentVaultView user={user} /></ErrorBoundary>}
        {tab === 'aippiemail'     && <ErrorBoundary><AippieMailView user={user} /></ErrorBoundary>}
        {tab === 'pricing'        && <ErrorBoundary><PricingView /></ErrorBoundary>}
        {tab === 'boardroom'      && <ErrorBoundary><PaywallGate module="boardroom"><AippieBoardroomView /></PaywallGate></ErrorBoundary>}
        {tab === 'enterprise'     && <ErrorBoundary><AippieEnterpriseWizardView /></ErrorBoundary>}
        {tab === 'companion'   && (
          <ErrorBoundary>
          <CompanionView
            onAvatarSessionStart={() => {
              presenterRef.current?.stopSpeech();
              setActiveAvatarSession('companion');
            }}
            onAvatarSessionEnd={() => {
              setActiveAvatarSession('presenter');
            }}
          />
          </ErrorBoundary>
        )}
        </Suspense>
      </div>

      {/* ─── Bottom navigation ────────────────────────────────────────────── */}
      <nav className="bottom-nav">
        <button
          className="bottom-nav__tab bottom-nav__tab--home"
          onClick={() => {
            window.speechSynthesis?.cancel();
            navigateTo('voice');
            setActiveAvatarSession('presenter');
          }}
          aria-label="Go to home"
        >
          <div className="bottom-nav__icon-wrap bottom-nav__icon-wrap--home">
            <LayoutGrid size={18} />
          </div>
          <span className="bottom-nav__label">Home</span>
        </button>

        <div className="bottom-nav__divider" aria-hidden="true" />

        <button
          className="bottom-nav__tab bottom-nav__tab--world"
          onClick={() => { window.open('https://aippie-world.netlify.app', '_blank'); }}
        >
          <div className="bottom-nav__icon-wrap bottom-nav__icon-wrap--world">
            <Globe size={18} />
          </div>
          <span className="bottom-nav__label">Open World</span>
        </button>
        <button
          className={`bottom-nav__tab${tab === 'voice' ? ' bottom-nav__tab--active' : ''}`}
          onClick={() => { navigateTo('voice'); setActiveAvatarSession('presenter'); presenterRef.current?.speak('This is your AippieVoice Document Scanner. Upload or scan your official letters and PDF files, and I will translate them instantly and read them aloud in your preferred language.','focused'); }}
        >
          <div className={`bottom-nav__icon-wrap${tab === 'voice' ? ' bottom-nav__icon-wrap--active' : ''}`}>
            <Mic size={18} />
          </div>
          <span className="bottom-nav__label">Interpreter</span>
        </button>

        <button
          className={`bottom-nav__tab bottom-nav__tab--lifeassist${tab === 'lifeassist' ? ' bottom-nav__tab--active' : ''}`}
          onClick={() => { navigateTo('lifeassist'); setActiveAvatarSession('presenter'); presenterRef.current?.speak('Welcome to Aippie Life Assistant. I am your personal AI that runs in the background of your life. Grant me permissions and I will read your emails, announce your calls, and remind you of your appointments.', 'warm'); }}
        >
          <div className={`bottom-nav__icon-wrap bottom-nav__icon-wrap--lifeassist${tab === 'lifeassist' ? ' bottom-nav__icon-wrap--active' : ''}`}>
            <BrainCircuit size={18} />
          </div>
          <span className="bottom-nav__label">Life AI</span>
        </button>

        <button
          className={`bottom-nav__tab${tab === 'wifi' ? ' bottom-nav__tab--active' : ''}`}
          onClick={() => { navigateTo('wifi'); setActiveAvatarSession('presenter'); presenterRef.current?.speak('The WiFi Share module is open. You can generate and share access codes from here.','neutral'); }}
        >
          <div className={`bottom-nav__icon-wrap${tab === 'wifi' ? ' bottom-nav__icon-wrap--active' : ''}`}>
            <Wifi size={18} />
          </div>
          <span className="bottom-nav__label">WiFi Share</span>
        </button>

        <button
          className={`bottom-nav__tab${tab === 'parking' ? ' bottom-nav__tab--active' : ''}`}
          onClick={() => { navigateTo('parking'); setActiveAvatarSession('presenter'); presenterRef.current?.speak('The Parking module is open. You can find, reserve, and manage parking spots from here.','neutral'); }}
        >
          <div className={`bottom-nav__icon-wrap${tab === 'parking' ? ' bottom-nav__icon-wrap--active' : ''}`}>
            <Car size={18} />
          </div>
          <span className="bottom-nav__label">Parking</span>
        </button>

        <button
          className={`bottom-nav__tab${tab === 'silentvoice' ? ' bottom-nav__tab--active' : ''}`}
          onClick={() => { navigateTo('silentvoice'); setActiveAvatarSession('presenter'); presenterRef.current?.speak('Silent Voice is active. Your messages are transmitted securely without any audio output.','authoritative'); }}
        >
          <div className={`bottom-nav__icon-wrap${tab === 'silentvoice' ? ' bottom-nav__icon-wrap--active' : ''}`}>
            <Hand size={18} />
          </div>
          <span className="bottom-nav__label">Silent Voice</span>
        </button>

        <div className="bottom-nav__divider" aria-hidden="true" />

        <button
          className={`bottom-nav__tab bottom-nav__tab--trading${tab === 'trading' ? ' bottom-nav__tab--active' : ''}`}
          onClick={() => { navigateTo('trading'); setActiveAvatarSession('presenter'); presenterRef.current?.speak('Trading Alpha quant algorithms are active. Real-time market and order signals are displayed here to autonomously optimize your portfolio positions.','authoritative'); }}
        >
          <div className={`bottom-nav__icon-wrap${tab === 'trading' ? ' bottom-nav__icon-wrap--active' : ''}`}>
            <TrendingUp size={18} />
          </div>
          <span className="bottom-nav__label">Trading</span>
        </button>

        <button
          className={`bottom-nav__tab bottom-nav__tab--tax${tab === 'tax' ? ' bottom-nav__tab--active' : ''}`}
          onClick={() => { navigateTo('tax'); setActiveAvatarSession('presenter'); presenterRef.current?.speak('Welcome to your AippieAccounts portal. Upload your documents or enter your VAT number, and I will manage your global accounting and payroll administration directly.','authoritative'); }}
        >
          <div className={`bottom-nav__icon-wrap bottom-nav__icon-wrap--tax${tab === 'tax' ? ' bottom-nav__icon-wrap--active' : ''}`}>
            <Building2 size={18} />
          </div>
          <span className="bottom-nav__label">Accounts</span>
        </button>

        <button
          className={`bottom-nav__tab bottom-nav__tab--wearable${tab === 'quantumcinema' ? ' bottom-nav__tab--active' : ''}`}
          onClick={() => { navigateTo('quantumcinema'); setActiveAvatarSession('presenter'); presenterRef.current?.speak('Welcome to Aippie Chrono-Cinema. Choose an era and I will narrate your personalized cinematic story live. All content is entirely fictional and for entertainment purposes only.','focused'); }}
        >
          <div className={`bottom-nav__icon-wrap bottom-nav__icon-wrap--wearable${tab === 'quantumcinema' ? ' bottom-nav__icon-wrap--active' : ''}`}>
            <Glasses size={18} />
          </div>
          <span className="bottom-nav__label">Chrono-Cinema</span>
        </button>

        <button
          className={`bottom-nav__tab bottom-nav__tab--safecheckin${tab === 'safecheckin' ? ' bottom-nav__tab--active' : ''}`}
          onClick={() => { navigateTo('safecheckin'); setActiveAvatarSession('presenter'); presenterRef.current?.speak('Safe Check-in Timer is ready. Set your timer window and activate when entering an unsecure environment.', 'authoritative'); }}
        >
          <div className={`bottom-nav__icon-wrap bottom-nav__icon-wrap--safecheckin${tab === 'safecheckin' ? ' bottom-nav__icon-wrap--active' : ''}`}>
            <ShieldCheck size={18} />
          </div>
          <span className="bottom-nav__label">Safe</span>
        </button>

        <button
          className={`bottom-nav__tab bottom-nav__tab--companion${tab === 'companion' ? ' bottom-nav__tab--active' : ''}`}
          onClick={() => {
            navigateTo('companion');
            presenterRef.current?.stopSpeech();
            setActiveAvatarSession('companion');
          }}
        >
          <div className={`bottom-nav__icon-wrap bottom-nav__icon-wrap--companion${tab === 'companion' ? ' bottom-nav__icon-wrap--active' : ''}`}>
            <HeartHandshake size={18} />
          </div>
          <span className="bottom-nav__label">Companion</span>
        </button>

        <div className="bottom-nav__divider" aria-hidden="true" />

        <button
          className={`bottom-nav__tab bottom-nav__tab--doctor${tab === 'doctor' ? ' bottom-nav__tab--active' : ''}`}
          onClick={() => { navigateTo('doctor'); setActiveAvatarSession('presenter'); presenterRef.current?.speak('Welcome to Aippie Doctor. Please describe your symptoms or place your fingertip on the camera for a live heart rate scan. I am an AI health guide, not a licensed physician. Always consult your own doctor for official medical diagnoses.', 'warm'); }}
        >
          <div className={`bottom-nav__icon-wrap bottom-nav__icon-wrap--doctor${tab === 'doctor' ? ' bottom-nav__icon-wrap--active' : ''}`}>
            <Stethoscope size={18} />
          </div>
          <span className="bottom-nav__label">Doctor · Autism Care</span>
        </button>

        <button
          className={`bottom-nav__tab bottom-nav__tab--realestate${tab === 'realestate' ? ' bottom-nav__tab--active' : ''}`}
          onClick={() => { navigateTo('realestate'); setActiveAvatarSession('presenter'); presenterRef.current?.speak('Welcome to your Aippie Real Estate Portfolio Manager. Register your Spanish or global properties here for real-time market valuations and automated rental management.', 'authoritative'); }}
        >
          <div className={`bottom-nav__icon-wrap bottom-nav__icon-wrap--realestate${tab === 'realestate' ? ' bottom-nav__icon-wrap--active' : ''}`}>
            <Home size={18} />
          </div>
          <span className="bottom-nav__label">Real Estate</span>
        </button>

        <button
          className={`bottom-nav__tab bottom-nav__tab--assistant${tab === 'assistant' ? ' bottom-nav__tab--active' : ''}`}
          onClick={() => { navigateTo('assistant'); setActiveAvatarSession('presenter'); presenterRef.current?.speak('This is your Aippie AI Message Assistant. Paste or type any message, letter, or contract and I will read it aloud and help you draft a professional reply.', 'warm'); }}
        >
          <div className={`bottom-nav__icon-wrap bottom-nav__icon-wrap--assistant${tab === 'assistant' ? ' bottom-nav__icon-wrap--active' : ''}`}>
            <MessageSquare size={18} />
          </div>
          <span className="bottom-nav__label">Assistant</span>
        </button>

        <button
          className={`bottom-nav__tab bottom-nav__tab--voipscript${tab === 'voipscript' ? ' bottom-nav__tab--active' : ''}`}
          onClick={() => { navigateTo('voipscript'); setActiveAvatarSession('presenter'); presenterRef.current?.speak('This is the Aippie Call Script Generator. Fill in the details and I will generate a complete word-for-word phone script for a hotel, restaurant, doctor, or service appointment. I will read each sentence aloud during your live call.', 'focused'); }}
        >
          <div className={`bottom-nav__icon-wrap bottom-nav__icon-wrap--voipscript${tab === 'voipscript' ? ' bottom-nav__icon-wrap--active' : ''}`}>
            <Phone size={18} />
          </div>
          <span className="bottom-nav__label">Call Script</span>
        </button>

        <div className="bottom-nav__divider" aria-hidden="true" />

        <button
          className={`bottom-nav__tab bottom-nav__tab--aippiedev${tab === 'aippiedev' ? ' bottom-nav__tab--active' : ''}`}
          onClick={() => { navigateTo('aippiedev'); setActiveAvatarSession('presenter'); presenterRef.current?.speak('Welcome to AippieDev Cloud Factory — the Ultra-Wide Multimodal AI Engine by AIPPIETAX S.A. Four fully autonomous pipeline nodes take your project from multimodal canvas design through serverless AWS injection, binary compilation, and direct-to-store deployment. Activate your $299 monthly subscription to start building.', 'authoritative'); }}
        >
          <div className={`bottom-nav__icon-wrap bottom-nav__icon-wrap--aippiedev${tab === 'aippiedev' ? ' bottom-nav__icon-wrap--active' : ''}`}>
            <Code2 size={18} />
          </div>
          <span className="bottom-nav__label">Cloud Factory</span>
        </button>

        <button
          className={`bottom-nav__tab bottom-nav__tab--academy${tab === 'academy' ? ' bottom-nav__tab--active' : ''}`}
          onClick={() => { navigateTo('academy'); setActiveAvatarSession('presenter'); presenterRef.current?.speak('Welcome to Aippie AI Academy. Select the Kids Learning plan at five Euros per month or the School Enterprise Portal at one ninety-nine per month.', 'warm'); }}
        >
          <div className={`bottom-nav__icon-wrap bottom-nav__icon-wrap--academy${tab === 'academy' ? ' bottom-nav__icon-wrap--active' : ''}`}>
            <GraduationCap size={18} />
          </div>
          <span className="bottom-nav__label">Academy</span>
        </button>

        <button
          className={`bottom-nav__tab bottom-nav__tab--radar${tab === 'companionradar' ? ' bottom-nav__tab--active' : ''}`}
          onClick={() => { navigateTo('companionradar'); setActiveAvatarSession('presenter'); presenterRef.current?.speak('Welcome to Aippie Companion Radar. Choose your role as Seeker or Provider, and activate live face verification to connect.', 'warm'); }}
        >
          <div className={`bottom-nav__icon-wrap bottom-nav__icon-wrap--radar${tab === 'companionradar' ? ' bottom-nav__icon-wrap--active' : ''}`}>
            <Radar size={18} />
          </div>
          <span className="bottom-nav__label">Radar</span>
        </button>

        <button
          className={`bottom-nav__tab bottom-nav__tab--robotics${tab === 'robotics' ? ' bottom-nav__tab--active' : ''}`}
          onClick={() => { navigateTo('robotics'); setActiveAvatarSession('presenter'); presenterRef.current?.speak('Welcome to Aippie Humanoid Robotics and Cybernetic Interface. Module eighteen — engineering staging blueprint. Cloud-to-hardware telemetry, computer vision navigation, and safety protocols are all active.', 'authoritative'); }}
        >
          <div className={`bottom-nav__icon-wrap bottom-nav__icon-wrap--robotics${tab === 'robotics' ? ' bottom-nav__icon-wrap--active' : ''}`}>
            <Cpu size={18} />
          </div>
          <span className="bottom-nav__label">Robotics</span>
        </button>

        <button
          className={`bottom-nav__tab bottom-nav__tab--cybersuit${tab === 'cybersuit' ? ' bottom-nav__tab--active' : ''}`}
          onClick={() => { navigateTo('cybersuit'); setActiveAvatarSession('presenter'); presenterRef.current?.speak('Welcome to the Aippie Cyber-Suit. Module nineteen — your personal physical guardian. Bio-filtration, real-time diagnostics, and neural translation are in Fase 3 development.', 'authoritative'); }}
        >
          <div className={`bottom-nav__icon-wrap bottom-nav__icon-wrap--cybersuit${tab === 'cybersuit' ? ' bottom-nav__icon-wrap--active' : ''}`}>
            <ShieldCheck size={18} />
          </div>
          <span className="bottom-nav__label">Cyber-Suit</span>
        </button>

        <button
          className={`bottom-nav__tab bottom-nav__tab--livestage${tab === 'livestage' ? ' bottom-nav__tab--active' : ''}`}
          onClick={() => { navigateTo('livestage'); setActiveAvatarSession('presenter'); presenterRef.current?.speak('Welcome to Aippie Live Stage. Module twenty — decentralized artist-to-fan concert streaming. Enter your secure digital ticket code to unlock the live broadcast.', 'warm'); }}
        >
          <div className={`bottom-nav__icon-wrap bottom-nav__icon-wrap--livestage${tab === 'livestage' ? ' bottom-nav__icon-wrap--active' : ''}`}>
            <Radio size={18} />
          </div>
          <span className="bottom-nav__label">Live Stage</span>
        </button>

        <button
          className={`bottom-nav__tab bottom-nav__tab--voicenav${tab === 'voicenav' ? ' bottom-nav__tab--active' : ''}`}
          onClick={() => { navigateTo('voicenav'); setActiveAvatarSession('presenter'); presenterRef.current?.speak('Opening Voice Navigation Core. Module twenty-one — full-screen AI avatar navigation interface. Real-time system paths are fully automated.', 'authoritative'); }}
        >
          <div className={`bottom-nav__icon-wrap bottom-nav__icon-wrap--voicenav${tab === 'voicenav' ? ' bottom-nav__icon-wrap--active' : ''}`}>
            <Mic size={18} />
          </div>
          <span className="bottom-nav__label">Voice Nav</span>
        </button>

        <button
          className={`bottom-nav__tab bottom-nav__tab--wallet${tab === 'wallet' ? ' bottom-nav__tab--active' : ''}`}
          onClick={() => { navigateTo('wallet'); setActiveAvatarSession('presenter'); presenterRef.current?.speak('Welcome to your Aippie Digital Wallet. Manage your Aippie Coins balance, send money by mobile number, and access your virtual prepaid card here.', 'authoritative'); }}
        >
          <div className={`bottom-nav__icon-wrap bottom-nav__icon-wrap--wallet${tab === 'wallet' ? ' bottom-nav__icon-wrap--active' : ''}`}>
            <Wallet size={18} />
          </div>
          <span className="bottom-nav__label">Wallet</span>
        </button>

        <button
          className={`bottom-nav__tab bottom-nav__tab--legal${tab === 'legal' ? ' bottom-nav__tab--active' : ''}`}
          onClick={() => { navigateTo('legal'); setActiveAvatarSession('presenter'); presenterRef.current?.speak('Welcome to Aippie Legal AI — your Green Badge verified juridical platform. Browse licensed lawyers, scan documents with AI, and open secure communication channels directly.', 'authoritative'); }}
        >
          <div className={`bottom-nav__icon-wrap bottom-nav__icon-wrap--legal${tab === 'legal' ? ' bottom-nav__icon-wrap--active' : ''}`}>
            <Scale size={18} />
          </div>
          <span className="bottom-nav__label">Legal AI</span>
        </button>

        <button
          className={`bottom-nav__tab bottom-nav__tab--reunion${tab === 'reunion' ? ' bottom-nav__tab--active' : ''}`}
          onClick={() => { navigateTo('reunion'); setActiveAvatarSession('presenter'); presenterRef.current?.speak('Welcome to Aippie Reunion — the consent-based legal family reunification platform. Create a legal dossier, register your name in the opt-in registry, or search for someone who has chosen to be found. All data is submitted directly to official legal authorities.', 'warm'); }}
        >
          <div className={`bottom-nav__icon-wrap bottom-nav__icon-wrap--reunion${tab === 'reunion' ? ' bottom-nav__icon-wrap--active' : ''}`}>
            <Heart size={18} />
          </div>
          <span className="bottom-nav__label">Reunion</span>
        </button>

        <button
          className={`bottom-nav__tab bottom-nav__tab--b2b${tab === 'b2b' ? ' bottom-nav__tab--active' : ''}`}
          onClick={() => { navigateTo('b2b'); setActiveAvatarSession('presenter'); presenterRef.current?.speak('Welcome to the Aippie B2B Enterprise Automation Hub. Trigger multilingual AI greetings for new client arrivals, manage inbound leads across four languages, generate secure API license keys for local enterprise deployments, and monitor your bi-weekly billing cycles with 48-hour lockout protection.', 'authoritative'); }}
        >
          <div className={`bottom-nav__icon-wrap bottom-nav__icon-wrap--b2b${tab === 'b2b' ? ' bottom-nav__icon-wrap--active' : ''}`}>
            <Zap size={18} />
          </div>
          <span className="bottom-nav__label">B2B Hub</span>
        </button>

        <button
          className={`bottom-nav__tab bottom-nav__tab--alphatrade${tab === 'alphatrade' ? ' bottom-nav__tab--active' : ''}`}
          onClick={() => { navigateTo('alphatrade'); setActiveAvatarSession('presenter'); presenterRef.current?.speak('Alpha Trading Engine is live. Dark-pool order flows, institutional buy blocks, and autonomous rebalancing are all active. Connect your broker API keys to activate live multi-market execution.', 'authoritative'); }}
        >
          <div className={`bottom-nav__icon-wrap bottom-nav__icon-wrap--alphatrade${tab === 'alphatrade' ? ' bottom-nav__icon-wrap--active' : ''}`}>
            <TrendingUp size={18} />
          </div>
          <span className="bottom-nav__label">Alpha Trade</span>
        </button>

        <button
          className={`bottom-nav__tab bottom-nav__tab--morning${tab === 'morning' ? ' bottom-nav__tab--active' : ''}`}
          onClick={() => { navigateTo('morning'); setActiveAvatarSession('presenter'); presenterRef.current?.speak('Good morning. I have prepared your personalized market briefing for today.', 'warm'); }}
        >
          <div className={`bottom-nav__icon-wrap bottom-nav__icon-wrap--morning${tab === 'morning' ? ' bottom-nav__icon-wrap--active' : ''}`}>
            <Radio size={18} />
          </div>
          <span className="bottom-nav__label">Briefing</span>
        </button>

        <button
          className={`bottom-nav__tab bottom-nav__tab--unified${tab === 'unified' ? ' bottom-nav__tab--active' : ''}`}
          onClick={() => { navigateTo('unified'); setActiveAvatarSession('presenter'); presenterRef.current?.speak('Welcome to your Unified Finance Command Center. Portfolio, tax, and legal shield all in one view.', 'authoritative'); }}
        >
          <div className={`bottom-nav__icon-wrap bottom-nav__icon-wrap--unified${tab === 'unified' ? ' bottom-nav__icon-wrap--active' : ''}`}>
            <Zap size={18} />
          </div>
          <span className="bottom-nav__label">Finance Hub</span>
        </button>

        <button
          className={`bottom-nav__tab bottom-nav__tab--tournament${tab === 'tournament' ? ' bottom-nav__tab--active' : ''}`}
          onClick={() => { navigateTo('tournament'); setActiveAvatarSession('presenter'); presenterRef.current?.speak('The Aippie AI Trading Championship is live. You are ranked number seven. Your strategy is executing autonomously.', 'focused'); }}
        >
          <div className={`bottom-nav__icon-wrap bottom-nav__icon-wrap--tournament${tab === 'tournament' ? ' bottom-nav__icon-wrap--active' : ''}`}>
            <TrendingUp size={18} />
          </div>
          <span className="bottom-nav__label">Tournament</span>
        </button>

        <button
          className={`bottom-nav__tab bottom-nav__tab--signalradar${tab === 'signalradar' ? ' bottom-nav__tab--active' : ''}`}
          onClick={() => { navigateTo('signalradar'); setActiveAvatarSession('presenter'); presenterRef.current?.speak('Mission Control is online. Signal Radar is scanning live news sources. Current accuracy eighty nine percent.', 'authoritative'); }}
        >
          <div className={`bottom-nav__icon-wrap bottom-nav__icon-wrap--signalradar${tab === 'signalradar' ? ' bottom-nav__icon-wrap--active' : ''}`}>
            <Radar size={18} />
          </div>
          <span className="bottom-nav__label">Signal Radar</span>
        </button>

        <div className="bottom-nav__divider" aria-hidden="true" />

        <button
          className={`bottom-nav__tab bottom-nav__tab--securechat${tab === 'securechat' ? ' bottom-nav__tab--active' : ''}`}
          onClick={() => { navigateTo('securechat'); setActiveAvatarSession('presenter'); presenterRef.current?.speak('Welcome to Aippie SecureChat. Anonymous PIN-based messaging with disappearing messages, screenshot protection, and live AI translation. No phone number required.', 'authoritative'); }}
        >
          <div className={`bottom-nav__icon-wrap bottom-nav__icon-wrap--securechat${tab === 'securechat' ? ' bottom-nav__icon-wrap--active' : ''}`}>
            <Lock size={18} />
          </div>
          <span className="bottom-nav__label">SecureChat</span>
        </button>

        <button
          className={`bottom-nav__tab bottom-nav__tab--videovault${tab === 'videovault' ? ' bottom-nav__tab--active' : ''}`}
          onClick={() => { navigateTo('videovault'); setActiveAvatarSession('presenter'); presenterRef.current?.speak('Welcome to Aippie Video Vault. Peer-to-peer encrypted video calls. Your video never passes through our servers. Start a room and share the 6-character code with your contact.', 'authoritative'); }}
        >
          <div className={`bottom-nav__icon-wrap bottom-nav__icon-wrap--videovault${tab === 'videovault' ? ' bottom-nav__icon-wrap--active' : ''}`}>
            <Video size={18} />
          </div>
          <span className="bottom-nav__label">Video Vault</span>
        </button>

        <button
          className={`bottom-nav__tab bottom-nav__tab--docvault${tab === 'docvault' ? ' bottom-nav__tab--active' : ''}`}
          onClick={() => { navigateTo('docvault'); setActiveAvatarSession('presenter'); presenterRef.current?.speak('Welcome to Aippie Document Vault. Upload sensitive PDFs and documents into a sandboxed viewer. Every view is watermarked with your IP address, GPS location, and Aippie PIN — making unauthorized sharing fully traceable.', 'authoritative'); }}
        >
          <div className={`bottom-nav__icon-wrap bottom-nav__icon-wrap--docvault${tab === 'docvault' ? ' bottom-nav__icon-wrap--active' : ''}`}>
            <FolderLock size={18} />
          </div>
          <span className="bottom-nav__label">Doc Vault</span>
        </button>

        <div className="bottom-nav__divider" aria-hidden="true" />

        <button
          className={`bottom-nav__tab bottom-nav__tab--accounting${tab === 'accounting' ? ' bottom-nav__tab--active' : ''}`}
          onClick={() => { navigateTo('accounting'); setActiveAvatarSession('presenter'); presenterRef.current?.speak('Welcome to the AippieAccounts Autonomous Accounting Suite. I am managing your international ledgers, payroll, and government tax submissions for Spain, Netherlands, and the United States — fully automated, zero manual intervention required.', 'authoritative'); }}
        >
          <div className={`bottom-nav__icon-wrap bottom-nav__icon-wrap--accounting${tab === 'accounting' ? ' bottom-nav__icon-wrap--active' : ''}`}>
            <Landmark size={18} />
          </div>
          <span className="bottom-nav__label">Accounting</span>
        </button>

        <button
          className={`bottom-nav__tab bottom-nav__tab--aippiemail${tab === 'aippiemail' ? ' bottom-nav__tab--active' : ''}`}
          onClick={() => { navigateTo('aippiemail'); setActiveAvatarSession('presenter'); presenterRef.current?.speak('Welcome to Aippie Shield Mail. End-to-end encrypted internal mail between Aippie users. Every mail requires PIN verification to read, features a self-destruct timer, and is protected by the DLP scanner.', 'authoritative'); }}
        >
          <div className={`bottom-nav__icon-wrap bottom-nav__icon-wrap--aippiemail${tab === 'aippiemail' ? ' bottom-nav__icon-wrap--active' : ''}`}>
            <MailOpen size={18} />
          </div>
          <span className="bottom-nav__label">Aippie Mail</span>
        </button>

      </nav>

      {/* ─── FAB ──────────────────────────────────────────────────────────── */}
      {!showOnboarding && (
        <button
          className={`fab-aippie${showAippieOverlay ? ' fab-aippie--active' : ''}`}
          onClick={() => setShowAippieOverlay(o => !o)}
          aria-label="Talk to Aippie"
        >
          <span className="fab-aippie__ring fab-aippie__ring--1" />
          <span className="fab-aippie__ring fab-aippie__ring--2" />
          <Mic size={20} className="fab-aippie__icon" />
        </button>
      )}

      {/* ─── Juridical sticky disclaimer ─────────────────────────────────── */}
      <div className="fixed bottom-0 left-0 right-0 bg-black/70 backdrop-blur-sm border-t border-white/10 text-gray-400 text-[10px] text-center py-1.5 z-[9999] px-4">
        AI-generated content may contain errors · Not a substitute for professional, medical, legal or financial advice · AIPPIETAX S.A. © 2026
      </div>
    </div>
  );
}
