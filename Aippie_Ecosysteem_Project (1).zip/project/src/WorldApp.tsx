import { StrictMode, useState } from 'react';
import { createRoot } from 'react-dom/client';
import { AuthProvider } from './contexts/AuthContext';
import AippieOpenWorldView from './components/AippieOpenWorldView';
import AippieWorldGamesView from './components/AippieWorldGamesView';
import './index.css';

function WorldApp() {
  const [showGames, setShowGames] = useState(false);

  return (
    <>
      <AippieOpenWorldView
        displayName="Aippie User"
        avatarColor="#38bdf8"
        badge="none"
        onClose={() => window.close()}
        onNavigate={(action) => {
          if (action === 'games') setShowGames(true);
        }}
      />
      {showGames && (
        <AippieWorldGamesView
          onClose={() => setShowGames(false)}
          onApcEarned={() => {}}
        />
      )}
    </>
  );
}

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <AuthProvider>
      <WorldApp />
    </AuthProvider>
  </StrictMode>
);
