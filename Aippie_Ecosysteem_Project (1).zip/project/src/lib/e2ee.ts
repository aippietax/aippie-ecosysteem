const DB_NAME = 'aippie_e2ee';
const DB_VERSION = 1;
const STORE = 'keys';

function openDb(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onupgradeneeded = () => req.result.createObjectStore(STORE);
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

function dbGet<T>(db: IDBDatabase, key: string): Promise<T | undefined> {
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE, 'readonly');
    const req = tx.objectStore(STORE).get(key);
    req.onsuccess = () => resolve(req.result as T);
    req.onerror = () => reject(req.error);
  });
}

function dbPut(db: IDBDatabase, key: string, value: unknown): Promise<void> {
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE, 'readwrite');
    const req = tx.objectStore(STORE).put(value, key);
    req.onsuccess = () => resolve();
    req.onerror = () => reject(req.error);
  });
}

function dbDelete(db: IDBDatabase, key: string): Promise<void> {
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE, 'readwrite');
    const req = tx.objectStore(STORE).delete(key);
    req.onsuccess = () => resolve();
    req.onerror = () => reject(req.error);
  });
}

function bufferToB64(buf: ArrayBuffer): string {
  return btoa(String.fromCharCode(...new Uint8Array(buf)));
}

function b64ToBuffer(b64: string): ArrayBuffer {
  const bin = atob(b64);
  const buf = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) buf[i] = bin.charCodeAt(i);
  return buf.buffer;
}

export async function getOrCreatePublicKey(pin: string): Promise<string> {
  const db = await openDb();
  const existingPriv = await dbGet<CryptoKey>(db, `${pin}_priv`);
  const existingPubBytes = await dbGet<ArrayBuffer>(db, `${pin}_pub`);

  if (existingPriv && existingPubBytes) {
    return bufferToB64(existingPubBytes);
  }

  const pair = await crypto.subtle.generateKey(
    { name: 'ECDH', namedCurve: 'P-256' },
    false,
    ['deriveKey'],
  );
  const pubBytes = await crypto.subtle.exportKey('spki', pair.publicKey);

  await dbPut(db, `${pin}_priv`, pair.privateKey);
  await dbPut(db, `${pin}_pub`, pubBytes);

  return bufferToB64(pubBytes);
}

export async function hasPrivateKey(pin: string): Promise<boolean> {
  const db = await openDb();
  const key = await dbGet<CryptoKey>(db, `${pin}_priv`);
  return key !== undefined;
}

export async function clearKeys(pin: string): Promise<void> {
  const db = await openDb();
  await dbDelete(db, `${pin}_priv`);
  await dbDelete(db, `${pin}_pub`);
}

async function deriveSharedKey(myPin: string, theirPublicKeyB64: string): Promise<CryptoKey | null> {
  try {
    const db = await openDb();
    const myPriv = await dbGet<CryptoKey>(db, `${myPin}_priv`);
    if (!myPriv) return null;

    const theirPub = await crypto.subtle.importKey(
      'spki',
      b64ToBuffer(theirPublicKeyB64),
      { name: 'ECDH', namedCurve: 'P-256' },
      false,
      [],
    );

    return await crypto.subtle.deriveKey(
      { name: 'ECDH', public: theirPub },
      myPriv,
      { name: 'AES-GCM', length: 256 },
      false,
      ['encrypt', 'decrypt'],
    );
  } catch {
    return null;
  }
}

export async function encryptMessage(plaintext: string, myPin: string, theirPublicKeyB64: string): Promise<string> {
  const sharedKey = await deriveSharedKey(myPin, theirPublicKeyB64);
  if (!sharedKey) throw new Error('No shared key available');

  const iv = crypto.getRandomValues(new Uint8Array(12));
  const encoded = new TextEncoder().encode(plaintext);
  const ciphertext = await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, sharedKey, encoded);

  const combined = new Uint8Array(12 + ciphertext.byteLength);
  combined.set(iv, 0);
  combined.set(new Uint8Array(ciphertext), 12);
  return bufferToB64(combined.buffer);
}

export async function decryptMessage(
  cipherB64: string,
  myPin: string,
  theirPublicKeyB64: string,
): Promise<string | null> {
  try {
    const sharedKey = await deriveSharedKey(myPin, theirPublicKeyB64);
    if (!sharedKey) return null;

    const combined = new Uint8Array(b64ToBuffer(cipherB64));
    if (combined.length < 13) return null;

    const plaintext = await crypto.subtle.decrypt(
      { name: 'AES-GCM', iv: combined.slice(0, 12) },
      sharedKey,
      combined.slice(12),
    );
    return new TextDecoder().decode(plaintext);
  } catch {
    return null;
  }
}
