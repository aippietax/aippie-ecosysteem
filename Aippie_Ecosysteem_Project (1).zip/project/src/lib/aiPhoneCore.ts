// AI Phone System Core Engine — AIPPIETAX S.A. | CEO Elvin Thomasa
import { supabase } from './supabase';

// Persistent device ID — survives page reloads, scoped per browser/device
function getDeviceId(): string {
  let id = localStorage.getItem('aippie_device_id');
  if (!id) {
    id = crypto.randomUUID();
    localStorage.setItem('aippie_device_id', id);
  }
  return id;
}

// ── MODULE 1: Device Manager & Remote Control ────────────────────────────────

export interface DeviceHeartbeat {
  userId: string;
  batteryLevel: number;
  isKioskLocked: boolean;
  systemVersion: string;
}

export async function sendDeviceHeartbeat(heartbeat: DeviceHeartbeat): Promise<boolean> {
  const deviceId = getDeviceId();
  const { error } = await supabase.from('aippie_devices').upsert([{
    device_id:        deviceId,
    user_id:          heartbeat.userId,
    battery_level:    heartbeat.batteryLevel,
    is_kiosk_locked:  heartbeat.isKioskLocked,
    system_version:   heartbeat.systemVersion,
    last_seen:        new Date().toISOString(),
  }]);
  if (error) console.error('Device heartbeat failed:', error.message);
  return !error;
}

// ── MODULE 2: Life Assistant Config (HeyGen WebRTC Fullscreen Overlay) ────────

export interface LifeAssistantConfig {
  avatarId: string;
  voiceId: string;
  isAlwaysActive: boolean;
}

export const AI_PHONE_AVATAR_CONFIG: LifeAssistantConfig = {
  avatarId: '2dd4792b4f1348a6bcd547d2170ac584',
  voiceId: 'en-US-AndrewNeural',
  isAlwaysActive: true,
};

export async function triggerAutonomeAction(command: string): Promise<string> {
  const lower = command.toLowerCase();
  if (lower.includes('regel mijn huur') || lower.includes('betaal huur')) {
    return 'Qonto API geactiveerd. Huurbuffer van EUR 3.000,00 is autonoom overgemaakt.';
  }
  if (lower.includes('verkoop certificaten') || lower.includes('groene stroom')) {
    return 'Aippie Energy Exchange API aangeroepen. 10 MWh direct verkocht tegen live marktkoers.';
  }
  return 'Aippie Life Assistant analyseert de opdracht via de neurale netwerken...';
}

// ── MODULE 3: Dead Hand Protocol & Total Zeroization ─────────────────────────

export interface DeadHandStatus {
  isTriggered: boolean;
  reason: 'DURESS' | 'HONEY_POT' | 'REMOTE_COMMAND' | 'NONE';
  timestamp: string | null;
}

export async function triggerAippieZeroization(
  reason: 'DURESS' | 'HONEY_POT' | 'REMOTE_COMMAND'
): Promise<DeadHandStatus> {
  const deviceId = getDeviceId();
  const timestamp = new Date().toISOString();

  // Mark device as wiped in cloud before clearing local state
  await supabase.from('aippie_devices').update({
    dead_hand_triggered: true,
    dead_hand_reason:    reason,
    dead_hand_at:        timestamp,
  }).eq('device_id', deviceId);

  // Wipe all local storage
  localStorage.clear();
  sessionStorage.clear();

  // Fragment in-memory crypto key material via IndexedDB wipe
  try {
    const dbs = await indexedDB.databases();
    dbs.forEach(db => { if (db.name) indexedDB.deleteDatabase(db.name); });
  } catch { /* IndexedDB.databases() not available in all runtimes */ }

  console.warn(`DEAD HAND ACTIVATED — reason: ${reason} — all local data zeroized.`);
  return { isTriggered: true, reason, timestamp };
}
