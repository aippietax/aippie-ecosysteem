// Aippie AI-OS Database Logging Engine — AIPPIETAX S.A.
import { supabase } from './supabase';

export interface AIOSLog {
  user_id: string;
  raw_text: string;
  intent: string;
  confidence: number;
  status: 'SUCCESS' | 'FAILED';
  action_taken: string;
}

export async function logAIOSActivity(log: AIOSLog): Promise<boolean> {
  const { error } = await supabase.from('aippie_os_logs').insert([{
    user_id:      log.user_id,
    raw_text:     log.raw_text,
    intent:       log.intent,
    confidence:   log.confidence,
    status:       log.status,
    action_taken: log.action_taken,
  }]);
  if (error) console.error('AI-OS log write failed:', error.message);
  return !error;
}
