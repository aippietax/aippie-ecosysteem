/**
 * notificationService — V123 Web Notifications API Engine
 * AIPPIETAX S.A.
 *
 * Dispatches internal app alerts via the browser Web Notifications API.
 * All notifications are strictly first-party (originate from this app only).
 * No third-party message content is read or intercepted.
 *
 * Usage:
 *   import { notifyTaxReminder, notifySafeCheckIn, notifyScriptReady } from '../lib/notificationService';
 */

const ICON = '/Jouw_alineatekst_(2).png';
const APP_NAME = 'Aippie · AIPPIETAX S.A.';

// ── Permission helpers ────────────────────────────────────────────────────────

export function notificationsSupported(): boolean {
  return 'Notification' in window;
}

export function notificationsGranted(): boolean {
  return notificationsSupported() && Notification.permission === 'granted';
}

/**
 * Request notification permission if not already granted/denied.
 * Returns the resulting PermissionState string.
 */
export async function requestNotificationPermission(): Promise<NotificationPermission> {
  if (!notificationsSupported()) return 'denied';
  if (Notification.permission !== 'default') return Notification.permission;
  return Notification.requestPermission();
}

// ── Core dispatcher ────────────────────────────────────────────────────────────

interface NotifyOptions {
  title:   string;
  body:    string;
  tag?:    string;
  /** ms after which the notification auto-closes (0 = no auto-close) */
  ttl?:    number;
  onClick?: () => void;
}

function dispatch({ title, body, tag, ttl = 0, onClick }: NotifyOptions): Notification | null {
  if (!notificationsGranted()) return null;

  const n = new Notification(title, {
    body,
    icon:      ICON,
    badge:     ICON,
    tag:       tag ?? `aippie-${Date.now()}`,
    silent:    false,
    requireInteraction: ttl === 0,
  });

  if (onClick) n.onclick = () => { window.focus(); onClick(); n.close(); };
  if (ttl > 0) setTimeout(() => n.close(), ttl);

  return n;
}

// ── Named dispatchers ─────────────────────────────────────────────────────────

/**
 * Tax AI reminder — e.g. BTW deadline approaching
 */
export function notifyTaxReminder(params: {
  subject:  string;
  deadline: string;
  onOpen?:  () => void;
}): void {
  dispatch({
    title:   `${APP_NAME} · Tax AI`,
    body:    `${params.subject} — deadline: ${params.deadline}. Open AippieTax to handle this immediately.`,
    tag:     'aippie-tax-reminder',
    ttl:     0,
    onClick: params.onOpen,
  });
}

/**
 * Safe Check-in alert — timer expired without check-in confirmation
 */
export function notifySafeCheckInExpired(params: {
  location?: string;
  onOpen?:   () => void;
}): void {
  const loc = params.location ? ` at ${params.location}` : '';
  dispatch({
    title:   `${APP_NAME} · Safe Check-in`,
    body:    `Timer expired${loc}. No confirmation received. Check status immediately.`,
    tag:     'aippie-safecheckin-alert',
    ttl:     0,
    onClick: params.onOpen,
  });
}

/**
 * Safe Check-in success — user checked in on time
 */
export function notifySafeCheckInConfirmed(params: { location?: string }): void {
  const loc = params.location ? ` at ${params.location}` : '';
  dispatch({
    title:   `${APP_NAME} · Safe Check-in`,
    body:    `Check-in confirmed${loc}. All clear.`,
    tag:     'aippie-safecheckin-ok',
    ttl:     6000,
  });
}

/**
 * VoIP / Reservation script ready
 */
export function notifyScriptReady(params: {
  scriptType: string;
  target:     string;
  onOpen?:    () => void;
}): void {
  dispatch({
    title:   `${APP_NAME} · Call Script`,
    body:    `${params.scriptType} script for ${params.target} is ready. Tap to play.`,
    tag:     'aippie-voip-script',
    ttl:     12000,
    onClick: params.onOpen,
  });
}

/**
 * Assistant — Aippie has finished reading a message
 */
export function notifyReadComplete(params: { preview: string }): void {
  dispatch({
    title:   `${APP_NAME} · Assistant`,
    body:    `Message read: "${params.preview.slice(0, 60)}…". Draft a reply?`,
    tag:     'aippie-assistant-read',
    ttl:     8000,
  });
}

/**
 * Generic informational toast via notification
 */
export function notifyInfo(title: string, body: string, ttl = 8000): void {
  dispatch({ title: `${APP_NAME} · ${title}`, body, ttl });
}
