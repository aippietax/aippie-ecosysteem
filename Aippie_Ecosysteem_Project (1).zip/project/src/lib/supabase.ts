import { createClient } from '@supabase/supabase-js';

const supabaseUrl = (import.meta.env.VITE_SUPABASE_URL as string) || 'https://placeholder.supabase.co';
const supabaseAnonKey = (import.meta.env.VITE_SUPABASE_ANON_KEY as string) || 'placeholder-anon-key';

export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
    detectSessionInUrl: true,
    storage: typeof window !== 'undefined' ? window.localStorage : undefined,
    storageKey: 'aippie-auth-token',
    flowType: 'pkce',
  },
  global: {
    headers: {
      'x-application-name': 'AippieAccounts',
    },
  },
  realtime: {
    params: {
      eventsPerSecond: 2,
    },
  },
});

// ── Plan tiers ────────────────────────────────────────────────────────────────

export type PlanTier = 'turista_basic' | 'corporate_b2b' | 'premium_jurado' | 'trading_alpha';

export type ClientProfile = {
  id: string;
  full_name: string;
  phone: string;
  device_key: string;
  voice_token: boolean;
  onboarded_at: string;
  created_at: string;
};

export const PLAN_CONFIG: Record<PlanTier, {
  label: string;
  price: number;
  includedMinutes: number;
  overageRate: number;
  tagline: string;
  badge: string;
  corridors: string[];
}> = {
  turista_basic: {
    label: 'Turista Basic',
    price: 14.99,
    includedMinutes: 40,
    overageRate: 0.50,
    tagline: 'Perfect for expats & tourists across Spain',
    badge: 'Most Popular',
    corridors: ['en-es', 'nl-es'],
  },
  corporate_b2b: {
    label: 'Corporate B2B',
    price: 79.99,
    includedMinutes: 200,
    overageRate: 0.50,
    tagline: 'For real estate agencies, law firms & clinics',
    badge: 'Business',
    corridors: ['en-es', 'nl-es'],
  },
  premium_jurado: {
    label: 'Premium Jurado',
    price: 29.99,
    includedMinutes: 60,
    overageRate: 0.50,
    tagline: 'Certified court & notary interpreters',
    badge: 'Certified',
    corridors: ['en-es', 'nl-es'],
  },
};

export type Subscription = {
  id: string;
  user_id: string;
  email: string;
  status: 'active' | 'cancelled' | 'expired';
  plan: string;
  plan_tier: PlanTier;
  included_minutes: number;
  overage_rate: number;
  amount: number;
  currency: string;
  started_at: string;
  expires_at: string;
  created_at: string;
};

export type TranslatorSession = {
  id: string;
  user_id: string;
  corridor: string;
  status: 'online' | 'offline' | 'busy';
  updated_at: string;
};

export type CallRequest = {
  id: string;
  client_user_id: string;
  corridor: string;
  status: 'pending' | 'accepted' | 'fallback' | 'ended';
  translator_user_id: string | null;
  accepted_at: string | null;
  fallback_at: string | null;
  created_at: string;
};

export type UserRole = 'client' | 'translator'; // kept for TranslatorView internals

export type TranslatorProfile = {
  id: string;
  user_id: string;
  full_name: string;
  iban: string;
  bic: string;
  country: string;
  kyc_status: 'pending' | 'verified' | 'rejected';
  submitted_at: string | null;
  verified_at: string | null;
  created_at: string;
};

export type CallMinutes = {
  id: string;
  call_request_id: string | null;
  translator_user_id: string;
  minutes: number;
  rate_per_minute: number;
  earned: number;
  month_start: string;
  created_at: string;
};

export type ClientUsage = {
  id: string;
  user_id: string;
  month_start: string;
  minutes_used: number;
  updated_at: string;
};

export const RATE_PER_MINUTE = 0.25;

export function currentMonthStart(): string {
  const now = new Date();
  return new Date(now.getFullYear(), now.getMonth(), 1).toISOString().slice(0, 10);
}

export function splitPrice(price: number): { whole: number; cents: string } {
  return { whole: Math.floor(price), cents: price.toFixed(2).split('.')[1] };
}

export type ParkingSlot = {
  id: string;
  name: string;
  location: 'Mijas' | 'Fuengirola' | 'Marbella';
  slot_type: 'garage' | 'street';
  total_spots: number | null;
  vacant_spots: number | null;
  status: 'available' | 'full' | 'reporting';
  reported_free_at: string | null;
  reported_by: string | null;
  lat: number;
  lng: number;
  updated_at: string;
  created_at: string;
};

export type WiFiNode = {
  id: string;
  node_id: string;
  node_name: string;
  owner_user_id: string | null;
  owner_iban: string;
  location: 'Mijas' | 'Fuengirola' | 'Marbella';
  status: 'online' | 'offline';
  total_gb_served: number;
  session_gb: number;
  owner_earnings: number;
  platform_margin: number;
  connected_users: number;
  signal_strength: number;
  updated_at: string;
  created_at: string;
};

export const WIFI_OWNER_RATE   = 0.03;
export const WIFI_PLATFORM_RATE = 0.02;
export const COSTA_LOCATIONS = ['Fuengirola', 'Marbella', 'Mijas'] as const;
export type CostaLocation = typeof COSTA_LOCATIONS[number];
