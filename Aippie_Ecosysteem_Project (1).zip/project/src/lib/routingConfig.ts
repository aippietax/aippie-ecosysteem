export type LanguageCorridor = {
  from: { code: string; label: string; flag: string };
  to:   { code: string; label: string; flag: string };
};

export const CORRIDORS: LanguageCorridor[] = [
  {
    from: { code: 'en', label: 'English', flag: '🇬🇧' },
    to:   { code: 'es', label: 'Spanish', flag: '🇪🇸' },
  },
  {
    from: { code: 'nl', label: 'Dutch',   flag: '🇳🇱' },
    to:   { code: 'es', label: 'Spanish', flag: '🇪🇸' },
  },
];

// Read from build-time env — the value is injected by the CI/CD pipeline,
// never hardcoded in source. Falls back to empty string if unset.
export const ADMIN_ROUTING_PHONE: string =
  import.meta.env.VITE_ADMIN_PHONE ?? '';

export type CallRoutingParams = {
  corridor: LanguageCorridor;
  adminPhone: string;
};

export function buildRoutingParams(corridorIndex: number): CallRoutingParams {
  return {
    corridor:   CORRIDORS[corridorIndex] ?? CORRIDORS[0],
    adminPhone: ADMIN_ROUTING_PHONE,
  };
}

export function corridorCode(c: LanguageCorridor): string {
  return `${c.from.code}-${c.to.code}`;
}
