// Aippie AI-OS Core Engine — AIPPIETAX S.A. | Elvin Thomasa

export type Intent = 'FINANCE' | 'PLATFORM' | 'COMMUNICATION' | 'DEVICE' | 'HEALTH' | 'UNKNOWN';

export interface AIOSCommand {
  rawText: string;
  timestamp: number;
  source: 'voice' | 'text' | 'auto';
}

export interface AIOSResult {
  intent: Intent;
  confidence: number;
  actionTaken: string;
  status: 'SUCCESS' | 'FAILED' | 'PENDING';
  module?: string;
  navigateTab?: string;
  data?: Record<string, unknown>;
}

// Official Intent Map
const INTENT_MAP: Record<Exclude<Intent, 'UNKNOWN'>, string[]> = {
  FINANCE:       ['qonto', 'sabadell', 'saldo', 'bank', 'betaling', 'factuur', 'huur', 'euro', 'mrr', 'rekening', 'accounting', 'boekhoud', 'belasting', 'tax', 'trading', 'wallet', 'certific'],
  PLATFORM:      ['aippie', 'module', 'securechat', 'boardroom', 'doctor', 'life', 'assistant', 'radar', 'academy', 'energy', 'legal', 'reunion', 'b2b', 'open', 'ga naar', 'navigate'],
  COMMUNICATION: ['stuur bericht', 'email', 'whatsapp', 'bel', 'notificatie', 'chat', 'sms', 'mail', 'bericht'],
  DEVICE:        ['batterij', 'opladen', 'scherm', 'volume', 'wifi', 'bluetooth', 'camera', 'herstart', 'battery', 'screen'],
  HEALTH:        ['health', 'gezondheid', 'pols', 'stappen', 'slaap', 'hartslag', 'dokter', 'medicijn', 'vitals', 'pulse'],
};

// Tab navigation keywords — maps spoken words to app tab IDs
const NAV_MAP: Record<string, string> = {
  'dokter':      'doctor',
  'doctor':      'doctor',
  'belasting':   'tax',
  'tax':         'tax',
  'trading':     'trading',
  'securechat':  'securechat',
  'chat':        'securechat',
  'bank':        'accounting',
  'accounting':  'accounting',
  'wallet':      'wallet',
  'legal':       'legal',
  'reunion':     'reunion',
  'academy':     'academy',
  'b2b':         'b2b',
  'energy':      'energy',
  'energie':     'energy',
  'life assist': 'lifeassist',
  'life':        'lifeassist',
  'radar':       'signalradar',
  'morning':     'morning',
  'board':       'unified',
};

function detectIntent(text: string): { intent: Intent; confidence: number } {
  const lower = text.toLowerCase();
  let bestIntent: Intent = 'UNKNOWN';
  let bestScore = 0;

  for (const [intent, keywords] of Object.entries(INTENT_MAP) as [Exclude<Intent, 'UNKNOWN'>, string[]][]) {
    const matches = keywords.filter(kw => lower.includes(kw)).length;
    const score = matches / keywords.length;
    if (score > bestScore) {
      bestScore = score;
      bestIntent = intent;
    }
  }

  return {
    intent: bestIntent,
    confidence: Math.min(bestScore * 10, 1),
  };
}

function detectNavigation(text: string): string | undefined {
  const lower = text.toLowerCase();
  for (const [keyword, tab] of Object.entries(NAV_MAP)) {
    if (lower.includes(keyword)) return tab;
  }
  return undefined;
}

async function executeAction(command: AIOSCommand, intent: Intent): Promise<AIOSResult> {
  const navigateTab = detectNavigation(command.rawText);

  switch (intent) {
    case 'FINANCE':
      return {
        intent,
        confidence: 0.9,
        actionTaken: navigateTab
          ? `Navigeer naar ${navigateTab} module`
          : 'Financieel overzicht geladen. Qonto: EUR 230,25 · Sabadell: EUR 20.941,58',
        status: 'SUCCESS',
        module: 'AippieAccountsView',
        navigateTab,
        data: { qonto: 230.25, sabadell: 20941.58 },
      };

    case 'PLATFORM':
      return {
        intent,
        confidence: 0.85,
        actionTaken: navigateTab
          ? `Navigeer naar ${navigateTab} module`
          : 'Aippie platform geopend. 83+ modules actief.',
        status: 'SUCCESS',
        module: navigateTab ? `${navigateTab}View` : 'AippieLifeAssistantView',
        navigateTab,
      };

    case 'COMMUNICATION':
      return {
        intent,
        confidence: 0.8,
        actionTaken: 'Communicatiemodule geactiveerd. SecureChat klaar voor gebruik.',
        status: 'SUCCESS',
        module: 'AippieSecureChatView',
        navigateTab: navigateTab ?? 'securechat',
      };

    case 'HEALTH':
      return {
        intent,
        confidence: 0.85,
        actionTaken: 'Gezondheidsdata geladen. Dokter module beschikbaar.',
        status: 'SUCCESS',
        module: 'AippieDoctorView',
        navigateTab: navigateTab ?? 'doctor',
      };

    case 'DEVICE':
      return {
        intent,
        confidence: 1.0,
        actionTaken: 'Apparaatstatus gecontroleerd. Alle systemen operationeel.',
        status: 'SUCCESS',
        module: 'AippieDeviceView',
        navigateTab,
      };

    default:
      return {
        intent: 'UNKNOWN',
        confidence: 0,
        actionTaken: 'Opdracht niet herkend. Schakel over naar cloud AI.',
        status: 'FAILED',
      };
  }
}

export async function processAIOSCommand(command: AIOSCommand): Promise<AIOSResult> {
  const { intent, confidence } = detectIntent(command.rawText);
  const result = await executeAction(command, intent);
  return { ...result, confidence };
}
