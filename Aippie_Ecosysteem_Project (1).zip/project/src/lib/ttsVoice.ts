/**
 * AIPPIETAX S.A. — Natural Voice Engine
 *
 * Priority chain (best → fallback):
 *   1. ElevenLabs neural TTS via Edge Function (natural, multilingual)
 *   2. Web Speech API with best available browser voice (robotic fallback)
 *
 * Callers use `speakNatural(text, options)` — it handles everything.
 * Legacy `applyPremiumVoice` / `selectPremiumVoice` are kept for
 * components that still call them directly.
 */

const EL_FUNCTION_URL = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/tts-elevenlabs`;

// ── Active audio player (one at a time) ─────────────────────────────────────
let activeAudio: HTMLAudioElement | null = null;
let activeUtterance: SpeechSynthesisUtterance | null = null;

function stopAll() {
  if (activeAudio) {
    activeAudio.pause();
    try { URL.revokeObjectURL(activeAudio.src); } catch { /* ignore */ }
    activeAudio = null;
  }
  if ('speechSynthesis' in window) {
    window.speechSynthesis.cancel();
    activeUtterance = null;
  }
}

// ── ElevenLabs neural TTS ────────────────────────────────────────────────────
async function speakElevenLabs(
  text: string,
  lang: string,
  onStart: () => void,
  onEnd: () => void,
): Promise<boolean> {
  try {
    const res = await fetch(EL_FUNCTION_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ text: normalizeForTTS(text), lang }),
    });

    if (!res.ok) return false;

    const blob = await res.blob();
    const url  = URL.createObjectURL(blob);
    const audio = new Audio(url);
    activeAudio = audio;

    audio.onplay  = onStart;
    audio.onended = () => {
      URL.revokeObjectURL(url);
      activeAudio = null;
      onEnd();
    };
    audio.onerror = () => {
      URL.revokeObjectURL(url);
      activeAudio = null;
      onEnd();
    };

    await audio.play();
    return true;
  } catch {
    return false;
  }
}

// ── Web Speech API fallback ──────────────────────────────────────────────────
function speakWebSpeech(
  text: string,
  lang: string,
  onStart: () => void,
  onEnd: () => void,
) {
  if (!('speechSynthesis' in window)) { onEnd(); return; }

  window.speechSynthesis.cancel();

  withVoicesReady(() => {
    const voices = window.speechSynthesis.getVoices();
    const { voice } = selectPremiumVoice(voices, lang);
    const u = new SpeechSynthesisUtterance(normalizeForTTS(text));
    u.rate  = 0.92;
    u.pitch = 1.0;
    u.lang  = lang.startsWith('nl') ? 'nl-NL' : 'en-US';
    if (voice) u.voice = voice;
    u.onstart = onStart;
    u.onend   = onEnd;
    u.onerror = onEnd;
    activeUtterance = u;
    window.speechSynthesis.speak(u);
  });
}

/**
 * Main speak function. Tries ElevenLabs neural TTS, falls back to Web Speech.
 *
 * @param text     Raw display text (brand normalization applied internally)
 * @param options  lang: 'en' | 'nl' | 'es' etc, onStart/onEnd callbacks
 */
export async function speakNatural(
  text: string,
  options: {
    lang?: string;
    onStart?: () => void;
    onEnd?: () => void;
    cancelPrevious?: boolean;
  } = {},
): Promise<void> {
  const {
    lang = 'en',
    onStart = () => {},
    onEnd   = () => {},
    cancelPrevious = true,
  } = options;

  if (cancelPrevious) stopAll();

  // Try ElevenLabs first
  const ok = await speakElevenLabs(text, lang, onStart, onEnd);
  if (!ok) {
    // Fall back to browser TTS
    speakWebSpeech(text, lang, onStart, onEnd);
  }
}

/** Stops all speech (ElevenLabs + Web Speech API). */
export function cancelSpeech() {
  stopAll();
}

// ── Legacy Web Speech API helpers (kept for backward compatibility) ───────────

const TIER1: RegExp[] = [/google us english/i];
const TIER2: RegExp[] = [/microsoft aria/i, /microsoft zira/i];
const TIER3: RegExp[] = [/\bsamantha\b/i, /\bsiri\b/i, /\bkaren\b/i];
const TIER4: RegExp = /female|woman|girl|fiona|moira|victoria|serena|jenny|emma|claire|joanna|amy|natasha|charlotte|ivy|allison|ava|susan|catherine|helena|veena|nora|tessa|kate|sandy/i;

function matchesAny(name: string, tiers: RegExp[]): boolean {
  return tiers.some(r => r.test(name));
}

export function selectPremiumVoice(
  voices: SpeechSynthesisVoice[],
  preferredLang?: string,
): { voice: SpeechSynthesisVoice | null; isFallback: boolean } {
  void preferredLang;
  if (voices.length === 0) return { voice: null, isFallback: true };
  const t1 = voices.find(v => matchesAny(v.name, TIER1));
  if (t1) return { voice: t1, isFallback: false };
  const t2 = voices.find(v => matchesAny(v.name, TIER2));
  if (t2) return { voice: t2, isFallback: false };
  const t3 = voices.find(v => matchesAny(v.name, TIER3));
  if (t3) return { voice: t3, isFallback: false };
  const t4 = voices.find(v => (v.lang === 'en-US' || v.lang === 'en_US') && TIER4.test(v.name));
  if (t4) return { voice: t4, isFallback: false };
  const t5 = voices.find(v => v.lang === 'en-US' || v.lang === 'en_US');
  if (t5) return { voice: t5, isFallback: true };
  return { voice: voices[0], isFallback: true };
}

export function applyPremiumVoice(
  u: SpeechSynthesisUtterance,
  preferredLang?: string,
): void {
  const voices = window.speechSynthesis.getVoices();
  const { voice, isFallback } = selectPremiumVoice(voices, preferredLang);
  if (voice) u.voice = voice;
  if (isFallback) { u.lang = 'en-US'; u.pitch = 1.05; u.rate = 0.92; }
}

export function normalizeForTTS(text: string): string {
  return text.replace(
    /AIPPIETAX\s+S\.A\.|AIPPIETAX|AippieTax|AippieVoice|AippieWiFi|Aippie/g,
    (match) => {
      const m = match.trim();
      if (/^AIPPIETAX\s+S\.A\.$/i.test(m)) return 'eye-pee TAX S.A.';
      if (/^AIPPIETAX$/i.test(m))           return 'eye-pee TAX';
      if (/^AippieTax$/i.test(m))           return 'eye-pee Tax';
      if (/^AippieVoice$/i.test(m))         return 'eye-pee Voice';
      if (/^AippieWiFi$/i.test(m))          return 'eye-pee WiFi';
      return 'eye-pee';
    }
  );
}

export function withVoicesReady(callback: () => void): void {
  if (!('speechSynthesis' in window)) return;
  if (window.speechSynthesis.getVoices().length > 0) { callback(); return; }
  let called = false;
  const once = () => {
    if (called) return;
    called = true;
    clearInterval(poll);
    window.speechSynthesis.onvoiceschanged = null;
    callback();
  };
  window.speechSynthesis.onvoiceschanged = once;
  const poll = setInterval(() => {
    if (window.speechSynthesis.getVoices().length > 0) once();
  }, 50);
  setTimeout(() => { if (!called) { called = true; clearInterval(poll); callback(); } }, 3000);
}
