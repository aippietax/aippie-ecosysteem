import { useState, useEffect, useCallback } from 'react';
import {
  Building2, Users, Plus, Calculator, Download, Trash2,
  ChevronDown, ChevronUp, AlertCircle, CheckCircle2, Loader2,
} from 'lucide-react';
import { supabase } from '../lib/supabase';
import { jsPDF } from 'jspdf';

type Jurisdiction = 'ES' | 'NL' | 'US';

interface PayrollClient {
  id: string;
  company_name: string;
  jurisdiction: Jurisdiction;
  tax_id: string | null;
  contact_email: string | null;
  active: boolean;
}

interface PayrollEmployee {
  id: string;
  client_id: string;
  full_name: string;
  role: string;
  jurisdiction: Jurisdiction;
  gross_annual: number;
  currency: string;
  bsn: string | null;
  apply_loonheffingskorting: boolean;
  national_id: string | null;
  us_state: string | null;
  iban: string | null;
  active: boolean;
}

interface Payslip {
  id: string;
  employee_id: string;
  period: string;
  gross_salary: number;
  deduction_1_label: string; deduction_1_amount: number; deduction_1_pct: number;
  deduction_2_label: string; deduction_2_amount: number; deduction_2_pct: number;
  deduction_3_label: string; deduction_3_amount: number; deduction_3_pct: number;
  net_salary: number;
  currency: string;
  status: 'draft' | 'finalized' | 'paid';
}

// ── NL: loonheffing with heffingskortingen ────────────────────────────────────
const NL_BRACKETS_2026: [number, number, number][] = [
  [0, 38441, 0.3582],
  [38441, 76817, 0.3748],
  [76817, Infinity, 0.495],
];

function bracketTax(brackets: [number, number, number][], gross: number): number {
  let tax = 0;
  for (const [lo, hi, rate] of brackets) {
    if (gross <= lo) break;
    tax += (Math.min(gross, hi) - lo) * rate;
  }
  return tax;
}

function calcAlgemeneHeffingskorting(g: number): number {
  const MAX = 3070, S = 24812, E = 75518;
  if (g <= S) return MAX;
  if (g >= E) return 0;
  return Math.max(0, MAX * (1 - (g - S) / (E - S)));
}

function calcArbeidskorting(g: number): number {
  if (g <= 0) return 0;
  if (g <= 12169) return g * 0.08425;
  if (g <= 26288) return 1025 + (g - 12169) * 0.31433;
  if (g <= 43071) return 5460;
  if (g <= 129078) return Math.max(0, 5460 - (g - 43071) * 0.0635);
  return 0;
}

function calcNL(emp: PayrollEmployee): Omit<Payslip, 'id' | 'employee_id' | 'period' | 'status'> {
  const g = emp.gross_annual;
  const m = g / 12;
  const rawTax = bracketTax(NL_BRACKETS_2026, g);
  const credits = emp.apply_loonheffingskorting ? calcAlgemeneHeffingskorting(g) + calcArbeidskorting(g) : 0;
  const annualTax = Math.max(0, rawTax - credits);
  const pct = g > 0 ? annualTax / g : 0;
  const loon = annualTax / 12;
  const aof = m * 0.0056;
  const pen = m * 0.055;
  return {
    gross_salary: m,
    deduction_1_label: 'Loonheffing', deduction_1_amount: loon, deduction_1_pct: pct,
    deduction_2_label: 'AOF-premie werknemersdeel', deduction_2_amount: aof, deduction_2_pct: 0.0056,
    deduction_3_label: 'Pensioenpremie', deduction_3_amount: pen, deduction_3_pct: 0.055,
    net_salary: m - loon - aof - pen,
    currency: emp.currency,
  };
}

// ── ES: IRPF (estatal + autonómica Andalucía) + SS ───────────────────────────
const IRPF_ESTATAL_2026: [number, number, number][] = [
  [0, 12450, 0.19], [12450, 20200, 0.24], [20200, 35200, 0.30],
  [35200, 60000, 0.37], [60000, 300000, 0.45], [300000, Infinity, 0.47],
];
const IRPF_ANDALUCIA_2026: [number, number, number][] = [
  [0, 13000, 0.095], [13000, 21000, 0.12], [21000, 35200, 0.15],
  [35200, 60000, 0.185], [60000, 120000, 0.225], [120000, Infinity, 0.245],
];

function calcES(emp: PayrollEmployee): Omit<Payslip, 'id' | 'employee_id' | 'period' | 'status'> {
  const g = emp.gross_annual;
  const m = g / 12;
  const annualIRPF = Math.max(0, bracketTax(IRPF_ESTATAL_2026, g) - bracketTax(IRPF_ESTATAL_2026, 5550))
                   + Math.max(0, bracketTax(IRPF_ANDALUCIA_2026, g) - bracketTax(IRPF_ANDALUCIA_2026, 5790));
  const irpfPct = g > 0 ? annualIRPF / g : 0;
  const irpf = annualIRPF / 12;
  const ss = m * 0.0628;
  return {
    gross_salary: m,
    deduction_1_label: 'IRPF (retención)', deduction_1_amount: irpf, deduction_1_pct: irpfPct,
    deduction_2_label: 'Seguridad Social (trabajador)', deduction_2_amount: ss, deduction_2_pct: 0.0628,
    deduction_3_label: '—', deduction_3_amount: 0, deduction_3_pct: 0,
    net_salary: m - irpf - ss,
    currency: emp.currency,
  };
}

// ── US: Federal + State + FICA ────────────────────────────────────────────────
const US_FEDERAL_2026: [number, number, number][] = [
  [0, 11600, 0.10], [11600, 47150, 0.12], [47150, 100525, 0.22],
  [100525, 191950, 0.24], [191950, 243725, 0.32], [243725, 609350, 0.35], [609350, Infinity, 0.37],
];
const US_STATE_FLAT_RATES: Record<string, number> = {
  CA: 0.093, NY: 0.0685, TX: 0, FL: 0, WA: 0, NV: 0,
  IL: 0.0495, PA: 0.0307, MA: 0.05, NJ: 0.0637,
};

function calcUS(emp: PayrollEmployee): Omit<Payslip, 'id' | 'employee_id' | 'period' | 'status'> {
  const g = emp.gross_annual;
  const m = g / 12;
  const state = emp.us_state ?? 'CA';
  const fedAnnual = bracketTax(US_FEDERAL_2026, g);
  const fedPct = g > 0 ? fedAnnual / g : 0;
  const stateRate = US_STATE_FLAT_RATES[state] ?? 0;
  const fica = Math.min(m, 160200 / 12) * 0.062 + m * 0.0145;
  const net = m - fedAnnual / 12 - m * stateRate - fica;
  return {
    gross_salary: m,
    deduction_1_label: 'Federal income tax', deduction_1_amount: fedAnnual / 12, deduction_1_pct: fedPct,
    deduction_2_label: `State income tax (${state})`, deduction_2_amount: m * stateRate, deduction_2_pct: stateRate,
    deduction_3_label: 'FICA (SS + Medicare)', deduction_3_amount: fica, deduction_3_pct: m > 0 ? fica / m : 0,
    net_salary: net,
    currency: emp.currency,
  };
}

function computePayslip(emp: PayrollEmployee): Omit<Payslip, 'id' | 'employee_id' | 'period' | 'status'> {
  if (emp.jurisdiction === 'NL') return calcNL(emp);
  if (emp.jurisdiction === 'ES') return calcES(emp);
  return calcUS(emp);
}

const JURIS_LABEL: Record<Jurisdiction, { name: string; idLabel: string; currency: string }> = {
  ES: { name: 'Spanje', idLabel: 'DNI/NIE', currency: 'EUR' },
  NL: { name: 'Nederland', idLabel: 'BSN', currency: 'EUR' },
  US: { name: 'Verenigde Staten', idLabel: 'SSN (laatste 4 cijfers)', currency: 'USD' },
};

const fmt = (n: number, currency = 'EUR') =>
  new Intl.NumberFormat('nl-NL', { style: 'currency', currency }).format(n);

const currentPeriod = () => {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
};

function generatePayslipPDF(
  client: PayrollClient,
  emp: PayrollEmployee,
  slip: Omit<Payslip, 'id' | 'employee_id' | 'period' | 'status'>,
  period: string,
) {
  const doc = new jsPDF();
  const [year, month] = period.split('-');
  const monthNames = ['januari','februari','maart','april','mei','juni','juli','augustus','september','oktober','november','december'];
  const periodLabel = `${monthNames[parseInt(month, 10) - 1]} ${year}`;
  const title = emp.jurisdiction === 'ES' ? 'Nómina' : emp.jurisdiction === 'US' ? 'Pay stub' : 'Loonstrook';

  doc.setFontSize(16); doc.setFont('helvetica', 'bold');
  doc.text(title, 20, 20);
  doc.setFontSize(10); doc.setFont('helvetica', 'normal');
  doc.text(`Periode: ${periodLabel}`, 20, 28);

  doc.setFont('helvetica', 'bold');
  doc.text(emp.jurisdiction === 'ES' ? 'Empresa' : emp.jurisdiction === 'US' ? 'Employer' : 'Werkgever', 20, 42);
  doc.setFont('helvetica', 'normal');
  doc.text(client.company_name, 20, 48);
  if (client.tax_id) doc.text(`${emp.jurisdiction === 'ES' ? 'NIF' : emp.jurisdiction === 'US' ? 'EIN' : 'KVK/BTW'}: ${client.tax_id}`, 20, 54);

  doc.setFont('helvetica', 'bold');
  doc.text(emp.jurisdiction === 'ES' ? 'Trabajador' : emp.jurisdiction === 'US' ? 'Employee' : 'Werknemer', 120, 42);
  doc.setFont('helvetica', 'normal');
  doc.text(emp.full_name, 120, 48);
  doc.text(emp.role, 120, 54);
  if (emp.national_id) doc.text(`${JURIS_LABEL[emp.jurisdiction].idLabel}: ${emp.national_id}`, 120, 60);
  if (emp.bsn) doc.text(`BSN: ${emp.bsn}`, 120, 60);

  let y = 76;
  doc.setFont('helvetica', 'bold');
  doc.text(emp.jurisdiction === 'US' ? 'Description' : 'Omschrijving', 20, y);
  doc.text(emp.jurisdiction === 'US' ? 'Amount' : 'Bedrag', 160, y, { align: 'right' });
  y += 4; doc.setLineWidth(0.3); doc.line(20, y, 190, y); y += 8;

  doc.setFont('helvetica', 'normal');
  const row = (label: string, amount: number, currency: string, neg = false) => {
    doc.text(label, 20, y);
    doc.text(`${neg ? '-' : ''}${fmt(amount, currency)}`, 160, y, { align: 'right' });
    y += 8;
  };
  row(emp.jurisdiction === 'US' ? 'Gross pay' : emp.jurisdiction === 'ES' ? 'Salario bruto' : 'Bruto salaris', slip.gross_salary, slip.currency);
  if (slip.deduction_1_amount > 0) row(`${slip.deduction_1_label} (${(slip.deduction_1_pct * 100).toFixed(1)}%)`, slip.deduction_1_amount, slip.currency, true);
  if (slip.deduction_2_amount > 0) row(`${slip.deduction_2_label} (${(slip.deduction_2_pct * 100).toFixed(1)}%)`, slip.deduction_2_amount, slip.currency, true);
  if (slip.deduction_3_amount > 0) row(`${slip.deduction_3_label} (${(slip.deduction_3_pct * 100).toFixed(1)}%)`, slip.deduction_3_amount, slip.currency, true);

  y += 2; doc.line(20, y, 190, y); y += 8;
  doc.setFont('helvetica', 'bold');
  doc.text(emp.jurisdiction === 'US' ? 'Net pay' : emp.jurisdiction === 'ES' ? 'Salario neto' : 'Netto salaris', 20, y);
  doc.text(fmt(slip.net_salary, slip.currency), 160, y, { align: 'right' });

  y += 16;
  if (emp.iban) {
    doc.setFont('helvetica', 'normal'); doc.setFontSize(9);
    doc.text(`${emp.jurisdiction === 'US' ? 'Paid to' : 'Uitbetaling op'}: ${emp.iban}`, 20, y);
  }

  doc.setFontSize(8); doc.setTextColor(120);
  const disclaimer = emp.jurisdiction === 'ES'
    ? 'Esta nómina es un cálculo indicativo basado en las tablas de IRPF y Seguridad Social vigentes para Andalucía 2026.'
    : emp.jurisdiction === 'US'
    ? 'This pay stub is an indicative calculation based on 2026 federal and state tax tables. Verify with your accountant before filing.'
    : 'Deze loonstrook is een indicatieve berekening op basis van de Nederlandse loonbelastingtabellen 2026.';
  doc.text(disclaimer, 20, 270, { maxWidth: 170 });
  doc.save(`${title.replace(/\s+/g, '_')}_${emp.full_name.replace(/\s+/g, '_')}_${period}.pdf`);
}

export default function PayrollClientsView({ user }: { user: { id: string } | null }) {
  const [clients, setClients] = useState<PayrollClient[]>([]);
  const [employees, setEmployees] = useState<PayrollEmployee[]>([]);
  const [payslips, setPayslips] = useState<Payslip[]>([]);
  const [activeClientId, setActiveClientId] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [processing, setProcessing] = useState(false);
  const [showNewClient, setShowNewClient] = useState(false);
  const [showNewEmployee, setShowNewEmployee] = useState(false);
  const [expandedEmp, setExpandedEmp] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const [newClient, setNewClient] = useState<{ company_name: string; jurisdiction: Jurisdiction; tax_id: string; contact_email: string }>({
    company_name: '', jurisdiction: 'NL', tax_id: '', contact_email: '',
  });
  const [newEmployee, setNewEmployee] = useState({
    full_name: '', role: '', gross_annual: '', national_id: '', iban: '',
    apply_loonheffingskorting: true, us_state: 'CA',
  });

  const loadData = useCallback(async () => {
    if (!user) return;
    setLoading(true);
    const [cr, er, sr] = await Promise.all([
      supabase.from('payroll_clients').select('*').eq('user_id', user.id).order('company_name'),
      supabase.from('payroll_employees').select('*').eq('user_id', user.id).order('full_name'),
      supabase.from('payslips').select('*').eq('user_id', user.id).order('period', { ascending: false }),
    ]);
    if (cr.data) setClients(cr.data as PayrollClient[]);
    if (er.data) setEmployees(er.data as PayrollEmployee[]);
    if (sr.data) setPayslips(sr.data as unknown as Payslip[]);
    if (cr.data && cr.data.length > 0 && !activeClientId) setActiveClientId(cr.data[0].id);
    setLoading(false);
  }, [user, activeClientId]);

  useEffect(() => { loadData(); }, [loadData]);

  const activeClient = clients.find(c => c.id === activeClientId) ?? null;
  const clientEmployees = employees.filter(e => e.client_id === activeClientId && e.active);

  const addClient = async () => {
    if (!user || !newClient.company_name.trim()) return;
    setError(null);
    const { data, error: e } = await supabase.from('payroll_clients').insert({
      user_id: user.id,
      company_name: newClient.company_name.trim(),
      jurisdiction: newClient.jurisdiction,
      tax_id: newClient.tax_id.trim() || null,
      contact_email: newClient.contact_email.trim() || null,
    }).select().single();
    if (e) { setError(e.message); return; }
    if (data) { setClients(prev => [...prev, data as PayrollClient]); setActiveClientId(data.id); }
    setNewClient({ company_name: '', jurisdiction: 'NL', tax_id: '', contact_email: '' });
    setShowNewClient(false);
  };

  const addEmployee = async () => {
    if (!user || !activeClientId || !activeClient || !newEmployee.full_name.trim() || !newEmployee.gross_annual) return;
    setError(null);
    const grossAnnual = parseFloat(newEmployee.gross_annual);
    if (isNaN(grossAnnual) || grossAnnual <= 0) { setError('Bruto jaarsalaris is ongeldig'); return; }
    const { data, error: e } = await supabase.from('payroll_employees').insert({
      user_id: user.id, client_id: activeClientId,
      full_name: newEmployee.full_name.trim(),
      role: newEmployee.role.trim() || 'Medewerker',
      jurisdiction: activeClient.jurisdiction,
      gross_annual: grossAnnual,
      currency: JURIS_LABEL[activeClient.jurisdiction].currency,
      bsn: activeClient.jurisdiction === 'NL' ? (newEmployee.national_id.trim() || null) : null,
      national_id: activeClient.jurisdiction !== 'NL' ? (newEmployee.national_id.trim() || null) : null,
      us_state: activeClient.jurisdiction === 'US' ? newEmployee.us_state : null,
      iban: newEmployee.iban.trim() || null,
      apply_loonheffingskorting: newEmployee.apply_loonheffingskorting,
      active: true,
    }).select().single();
    if (e) { setError(e.message); return; }
    if (data) setEmployees(prev => [...prev, data as PayrollEmployee]);
    setNewEmployee({ full_name: '', role: '', gross_annual: '', national_id: '', iban: '', apply_loonheffingskorting: true, us_state: 'CA' });
    setShowNewEmployee(false);
  };

  const removeEmployee = async (id: string) => {
    await supabase.from('payroll_employees').update({ active: false }).eq('id', id);
    setEmployees(prev => prev.filter(e => e.id !== id));
  };

  const runPayroll = async () => {
    if (!user || !activeClient) return;
    setProcessing(true); setError(null);
    const period = currentPeriod();
    try {
      for (const emp of clientEmployees) {
        const calc = computePayslip(emp);
        const { data: existing } = await supabase.from('payslips').select('id').eq('employee_id', emp.id).eq('period', period).maybeSingle();
        const row = {
          gross_salary: calc.gross_salary,
          loonheffing_pct: calc.deduction_1_pct,
          loonheffing_amount: calc.deduction_1_amount,
          aof_premium_amount: calc.deduction_2_amount,
          pension_amount: calc.deduction_3_amount,
          net_salary: calc.net_salary,
          currency: calc.currency,
        };
        if (existing) {
          await supabase.from('payslips').update({ ...row, status: 'finalized' }).eq('id', existing.id);
        } else {
          await supabase.from('payslips').insert({ user_id: user.id, client_id: activeClient.id, employee_id: emp.id, period, ...row, status: 'finalized' });
        }
      }
      await loadData();
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Verwerken mislukt');
    } finally {
      setProcessing(false);
    }
  };

  const downloadPayslip = (emp: PayrollEmployee) => {
    if (!activeClient) return;
    generatePayslipPDF(activeClient, emp, computePayslip(emp), currentPeriod());
  };

  if (loading) {
    return <div className="pcv-loading"><Loader2 size={20} className="pcv-spin"/><span>Laden…</span></div>;
  }

  return (
    <div className="pcv-root">
      <div className="pcv-clients-bar">
        {clients.map(c => (
          <button key={c.id} className={`pcv-client-pill${c.id === activeClientId ? ' pcv-client-pill--active' : ''}`} onClick={() => setActiveClientId(c.id)}>
            <Building2 size={13}/> {c.company_name} <span className="pcv-juris-tag">{c.jurisdiction}</span>
          </button>
        ))}
        <button className="pcv-client-pill pcv-client-pill--new" onClick={() => setShowNewClient(v => !v)}>
          <Plus size={13}/> Nieuwe klant
        </button>
      </div>

      {showNewClient && (
        <div className="pcv-form-card">
          <input placeholder="Bedrijfsnaam" value={newClient.company_name} onChange={e => setNewClient(s => ({ ...s, company_name: e.target.value }))}/>
          <select value={newClient.jurisdiction} onChange={e => setNewClient(s => ({ ...s, jurisdiction: e.target.value as Jurisdiction }))}>
            <option value="NL">Nederland</option>
            <option value="ES">Spanje</option>
            <option value="US">Verenigde Staten</option>
          </select>
          <input placeholder={newClient.jurisdiction === 'ES' ? 'NIF' : newClient.jurisdiction === 'US' ? 'EIN' : 'KVK / BTW-nummer'} value={newClient.tax_id} onChange={e => setNewClient(s => ({ ...s, tax_id: e.target.value }))}/>
          <input placeholder="Contact e-mail (optioneel)" value={newClient.contact_email} onChange={e => setNewClient(s => ({ ...s, contact_email: e.target.value }))}/>
          <button className="pcv-btn-primary" onClick={addClient}>Klant toevoegen</button>
        </div>
      )}

      {error && <div className="pcv-error"><AlertCircle size={14}/> {error}</div>}

      {activeClient && (
        <>
          <div className="pcv-section-head">
            <h3><Users size={15}/> Werknemers — {activeClient.company_name} ({JURIS_LABEL[activeClient.jurisdiction].name})</h3>
            <button className="pcv-btn-secondary" onClick={() => setShowNewEmployee(v => !v)}>
              <Plus size={13}/> Werknemer toevoegen
            </button>
          </div>

          {showNewEmployee && (
            <div className="pcv-form-card">
              <input placeholder="Volledige naam" value={newEmployee.full_name} onChange={e => setNewEmployee(s => ({ ...s, full_name: e.target.value }))}/>
              <input placeholder="Functie" value={newEmployee.role} onChange={e => setNewEmployee(s => ({ ...s, role: e.target.value }))}/>
              <input placeholder={`Bruto jaarsalaris (${JURIS_LABEL[activeClient.jurisdiction].currency})`} type="number" value={newEmployee.gross_annual} onChange={e => setNewEmployee(s => ({ ...s, gross_annual: e.target.value }))}/>
              <input placeholder={`${JURIS_LABEL[activeClient.jurisdiction].idLabel} (optioneel)`} value={newEmployee.national_id} onChange={e => setNewEmployee(s => ({ ...s, national_id: e.target.value }))}/>
              {activeClient.jurisdiction === 'US' && (
                <select value={newEmployee.us_state} onChange={e => setNewEmployee(s => ({ ...s, us_state: e.target.value }))}>
                  {Object.keys(US_STATE_FLAT_RATES).map(st => <option key={st} value={st}>{st}{US_STATE_FLAT_RATES[st] === 0 ? ' (geen staatsbelasting)' : ''}</option>)}
                </select>
              )}
              <input placeholder={activeClient.jurisdiction === 'US' ? 'Bank account / payout details (optioneel)' : 'IBAN voor uitbetaling (optioneel)'} value={newEmployee.iban} onChange={e => setNewEmployee(s => ({ ...s, iban: e.target.value }))}/>
              {activeClient.jurisdiction === 'NL' && (
                <label className="pcv-checkbox-row">
                  <input type="checkbox" checked={newEmployee.apply_loonheffingskorting} onChange={e => setNewEmployee(s => ({ ...s, apply_loonheffingskorting: e.target.checked }))}/>
                  Loonheffingskorting toepassen (hoofdwerkgever)
                </label>
              )}
              <button className="pcv-btn-primary" onClick={addEmployee}>Werknemer toevoegen</button>
            </div>
          )}

          <div className="pcv-employee-list">
            {clientEmployees.length === 0 && <div className="pcv-empty">Nog geen werknemers voor {activeClient.company_name}.</div>}
            {clientEmployees.map(emp => {
              const slip = payslips.find(s => s.employee_id === emp.id && s.period === currentPeriod());
              const liveCalc = computePayslip(emp);
              const expanded = expandedEmp === emp.id;
              return (
                <div key={emp.id} className="pcv-emp-card">
                  <div className="pcv-emp-row" onClick={() => setExpandedEmp(expanded ? null : emp.id)}>
                    <div>
                      <div className="pcv-emp-name">{emp.full_name}</div>
                      <div className="pcv-emp-role">{emp.role} · {fmt(emp.gross_annual, emp.currency)}/jr</div>
                    </div>
                    <div className="pcv-emp-right">
                      {slip ? <span className="pcv-status pcv-status--ok"><CheckCircle2 size={12}/> Verwerkt {currentPeriod()}</span>
                            : <span className="pcv-status pcv-status--pending">Nog niet verwerkt</span>}
                      {expanded ? <ChevronUp size={15}/> : <ChevronDown size={15}/>}
                    </div>
                  </div>
                  {expanded && (
                    <div className="pcv-emp-detail">
                      <div className="pcv-detail-row"><span>Bruto</span><span>{fmt(liveCalc.gross_salary, liveCalc.currency)}</span></div>
                      {liveCalc.deduction_1_amount > 0 && <div className="pcv-detail-row"><span>{liveCalc.deduction_1_label} ({(liveCalc.deduction_1_pct * 100).toFixed(1)}%)</span><span>− {fmt(liveCalc.deduction_1_amount, liveCalc.currency)}</span></div>}
                      {liveCalc.deduction_2_amount > 0 && <div className="pcv-detail-row"><span>{liveCalc.deduction_2_label} ({(liveCalc.deduction_2_pct * 100).toFixed(1)}%)</span><span>− {fmt(liveCalc.deduction_2_amount, liveCalc.currency)}</span></div>}
                      {liveCalc.deduction_3_amount > 0 && <div className="pcv-detail-row"><span>{liveCalc.deduction_3_label} ({(liveCalc.deduction_3_pct * 100).toFixed(1)}%)</span><span>− {fmt(liveCalc.deduction_3_amount, liveCalc.currency)}</span></div>}
                      <div className="pcv-detail-row pcv-detail-row--net"><span>Netto</span><span>{fmt(liveCalc.net_salary, liveCalc.currency)}</span></div>
                      <div className="pcv-detail-actions">
                        <button className="pcv-btn-secondary" onClick={() => downloadPayslip(emp)}>
                          <Download size={13}/> Download {emp.jurisdiction === 'ES' ? 'nómina' : emp.jurisdiction === 'US' ? 'pay stub' : 'loonstrook'} PDF
                        </button>
                        <button className="pcv-btn-danger" onClick={() => removeEmployee(emp.id)}>
                          <Trash2 size={13}/> Werknemer verwijderen
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>

          {clientEmployees.length > 0 && (
            <button className="pcv-run-btn" onClick={runPayroll} disabled={processing}>
              {processing ? <Loader2 size={15} className="pcv-spin"/> : <Calculator size={15}/>}
              {processing ? 'Verwerken…' : `Salarissen verwerken — ${currentPeriod()}`}
            </button>
          )}
        </>
      )}

      <style>{`
        .pcv-root { display: flex; flex-direction: column; gap: 16px; padding: 4px; }
        .pcv-loading { display: flex; align-items: center; gap: 8px; padding: 32px; color: var(--color-text-secondary); font-size: 13px; }
        .pcv-spin { animation: pcv-spin 1s linear infinite; }
        @keyframes pcv-spin { to { transform: rotate(360deg); } }
        .pcv-clients-bar { display: flex; gap: 8px; flex-wrap: wrap; }
        .pcv-client-pill { display: flex; align-items: center; gap: 6px; padding: 7px 12px; border-radius: var(--border-radius-lg); border: 1px solid var(--color-border-tertiary); background: var(--color-background-secondary); color: var(--color-text-secondary); font-size: 13px; cursor: pointer; }
        .pcv-client-pill--active { border-color: var(--color-text-info); color: var(--color-text-info); }
        .pcv-client-pill--new { color: var(--color-text-tertiary); }
        .pcv-juris-tag { font-size: 10px; opacity: 0.6; }
        .pcv-form-card { display: flex; flex-direction: column; gap: 8px; padding: 14px; border-radius: var(--border-radius-lg); border: 1px solid var(--color-border-tertiary); background: var(--color-background-secondary); }
        .pcv-form-card input, .pcv-form-card select { padding: 8px 10px; border-radius: 8px; border: 1px solid var(--color-border-tertiary); background: var(--color-background-primary); color: var(--color-text-primary); font-size: 13px; }
        .pcv-checkbox-row { display: flex; align-items: center; gap: 8px; font-size: 12px; color: var(--color-text-secondary); }
        .pcv-btn-primary, .pcv-btn-secondary, .pcv-btn-danger { display: flex; align-items: center; justify-content: center; gap: 6px; padding: 8px 14px; border-radius: 8px; font-size: 13px; cursor: pointer; border: none; }
        .pcv-btn-primary { background: var(--color-text-info); color: white; }
        .pcv-btn-secondary { background: var(--color-background-tertiary); color: var(--color-text-primary); border: 1px solid var(--color-border-tertiary); }
        .pcv-btn-danger { background: transparent; color: var(--color-text-danger); border: 1px solid var(--color-border-tertiary); }
        .pcv-error { display: flex; gap: 6px; align-items: center; color: var(--color-text-danger); font-size: 12px; }
        .pcv-section-head { display: flex; align-items: center; justify-content: space-between; }
        .pcv-section-head h3 { display: flex; align-items: center; gap: 6px; font-size: 14px; margin: 0; }
        .pcv-employee-list { display: flex; flex-direction: column; gap: 8px; }
        .pcv-empty { color: var(--color-text-tertiary); font-size: 12px; padding: 12px; text-align: center; }
        .pcv-emp-card { border: 1px solid var(--color-border-tertiary); border-radius: var(--border-radius-lg); overflow: hidden; }
        .pcv-emp-row { display: flex; align-items: center; justify-content: space-between; padding: 12px 14px; cursor: pointer; }
        .pcv-emp-name { font-size: 13px; font-weight: 500; }
        .pcv-emp-role { font-size: 12px; color: var(--color-text-secondary); }
        .pcv-emp-right { display: flex; align-items: center; gap: 10px; }
        .pcv-status { display: flex; align-items: center; gap: 4px; font-size: 11px; padding: 3px 8px; border-radius: 12px; }
        .pcv-status--ok { background: var(--color-background-success); color: var(--color-text-success); }
        .pcv-status--pending { background: var(--color-background-tertiary); color: var(--color-text-tertiary); }
        .pcv-emp-detail { padding: 0 14px 14px; border-top: 1px solid var(--color-border-tertiary); }
        .pcv-detail-row { display: flex; justify-content: space-between; padding: 6px 0; font-size: 12px; color: var(--color-text-secondary); }
        .pcv-detail-row--net { font-weight: 500; color: var(--color-text-primary); border-top: 1px solid var(--color-border-tertiary); margin-top: 4px; padding-top: 8px; }
        .pcv-detail-actions { display: flex; gap: 8px; margin-top: 10px; }
        .pcv-run-btn { display: flex; align-items: center; justify-content: center; gap: 8px; padding: 12px; border-radius: var(--border-radius-lg); border: none; background: var(--color-text-info); color: white; font-size: 13px; cursor: pointer; }
        .pcv-run-btn:disabled { opacity: 0.6; cursor: not-allowed; }
      `}</style>
    </div>
  );
}
