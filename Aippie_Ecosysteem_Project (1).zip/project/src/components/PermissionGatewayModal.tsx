/**
 * PermissionGatewayModal — V122 Browser Permission Framework
 * AIPPIETAX S.A.
 *
 * Requests Microphone, Camera, and Notifications permissions through the
 * standard browser APIs. Each permission has an individual toggle. The user
 * can grant, deny, or revoke any permission at any time. State is persisted
 * in localStorage so the modal only shows once on first launch.
 */
import { useCallback, useEffect, useRef, useState } from 'react';
import {
  Mic, Camera, Bell, ShieldCheck, X, ChevronRight,
  CheckCircle2, AlertCircle, XCircle, RefreshCw, Lock
} from 'lucide-react';

export type PermissionState = 'unknown' | 'granted' | 'denied' | 'prompt' | 'requesting';

export interface PermissionSet {
  microphone: PermissionState;
  camera:     PermissionState;
  notifications: PermissionState;
}

const STORAGE_KEY = 'aippie_permissions_v122';

function loadStoredPermissions(): PermissionSet {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) return JSON.parse(raw) as PermissionSet;
  } catch { /* ignore */ }
  return { microphone: 'unknown', camera: 'unknown', notifications: 'unknown' };
}

function savePermissions(p: PermissionSet) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(p));
}

interface Props {
  onComplete: (permissions: PermissionSet) => void;
}

const PERMISSION_META = [
  {
    key: 'microphone' as const,
    icon: <Mic size={18} />,
    label: 'Microphone',
    description: 'Voice recognition for reading messages and the reservation script.',
    detail: 'Only active when you are speaking. No background recording.',
    accentColor: '#38bdf8',
  },
  {
    key: 'camera' as const,
    icon: <Camera size={18} />,
    label: 'Camera',
    description: 'Face-to-face avatar session and vitals monitoring via camera.',
    detail: 'Only active in the Aippie Doctor module. No image storage.',
    accentColor: '#4ade80',
  },
  {
    key: 'notifications' as const,
    icon: <Bell size={18} />,
    label: 'Notifications',
    description: 'Aippie can notify you of time-sensitive updates and reminders.',
    detail: 'You decide which notification categories you receive.',
    accentColor: '#fbbf24',
  },
];

function StatusBadge({ state }: { state: PermissionState }) {
  if (state === 'granted') return (
    <span className="pgm-badge pgm-badge--granted">
      <CheckCircle2 size={10} /> Granted
    </span>
  );
  if (state === 'denied') return (
    <span className="pgm-badge pgm-badge--denied">
      <XCircle size={10} /> Denied
    </span>
  );
  if (state === 'requesting') return (
    <span className="pgm-badge pgm-badge--requesting">
      <RefreshCw size={10} className="pgm-spin" /> Requesting…
    </span>
  );
  return (
    <span className="pgm-badge pgm-badge--prompt">
      <AlertCircle size={10} /> Not configured
    </span>
  );
}

async function requestMicPermission(): Promise<PermissionState> {
  try {
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    stream.getTracks().forEach(t => t.stop());
    return 'granted';
  } catch {
    return 'denied';
  }
}

async function requestCameraPermission(): Promise<PermissionState> {
  try {
    const stream = await navigator.mediaDevices.getUserMedia({ video: true });
    stream.getTracks().forEach(t => t.stop());
    return 'granted';
  } catch {
    return 'denied';
  }
}

async function requestNotificationPermission(): Promise<PermissionState> {
  if (!('Notification' in window)) return 'denied';
  const result = await Notification.requestPermission();
  return result === 'granted' ? 'granted' : 'denied';
}

export default function PermissionGatewayModal({ onComplete }: Props) {
  const [permissions, setPermissions] = useState<PermissionSet>(loadStoredPermissions);
  const mountedRef = useRef(true);

  useEffect(() => {
    mountedRef.current = true;
    // Sync actual browser permission states on mount
    (async () => {
      if (!navigator.permissions) return;
      const checks: Array<[keyof PermissionSet, string]> = [
        ['microphone', 'microphone'],
        ['camera',     'camera'],
      ];
      for (const [key, name] of checks) {
        try {
          const status = await navigator.permissions.query({ name: name as PermissionName });
          if (mountedRef.current) {
            setPermissions(prev => {
              const next = { ...prev, [key]: status.state as PermissionState };
              savePermissions(next);
              return next;
            });
            status.onchange = () => {
              if (mountedRef.current) {
                setPermissions(prev => {
                  const next = { ...prev, [key]: status.state as PermissionState };
                  savePermissions(next);
                  return next;
                });
              }
            };
          }
        } catch { /* browser may not support querying this name */ }
      }
      // Notification state
      if ('Notification' in window && mountedRef.current) {
        const notifState: PermissionState =
          Notification.permission === 'granted' ? 'granted' :
          Notification.permission === 'denied'  ? 'denied'  : 'prompt';
        setPermissions(prev => {
          const next = { ...prev, notifications: notifState };
          savePermissions(next);
          return next;
        });
      }
    })();
    return () => { mountedRef.current = false; };
  }, []);

  const requestPermission = useCallback(async (key: keyof PermissionSet) => {
    setPermissions(prev => ({ ...prev, [key]: 'requesting' }));
    let result: PermissionState;
    if (key === 'microphone')    result = await requestMicPermission();
    else if (key === 'camera')   result = await requestCameraPermission();
    else                         result = await requestNotificationPermission();
    if (mountedRef.current) {
      setPermissions(prev => {
        const next = { ...prev, [key]: result };
        savePermissions(next);
        return next;
      });
    }
  }, []);

  const handleContinue = () => {
    savePermissions(permissions);
    localStorage.setItem('aippie_permissions_shown', '1');
    onComplete(permissions);
  };

  const allReviewed = Object.values(permissions).every(s => s !== 'unknown' && s !== 'prompt');

  return (
    <div className="pgm-overlay">
      <div className="pgm-modal">

        {/* Header */}
        <div className="pgm-header">
          <div className="pgm-header__icon-ring">
            <ShieldCheck size={24} style={{ color: '#60a5fa' }} />
          </div>
          <div className="pgm-header__text">
            <div className="pgm-header__title">System Permissions</div>
            <div className="pgm-header__sub">AIPPIETAX S.A. · Privacy-compliant · GDPR Art. 6</div>
          </div>
        </div>

        <p className="pgm-intro">
          Aippie requests access to the following browser features. You decide what you allow — every permission can be revoked at any time via your browser settings or the buttons below.
        </p>

        {/* Permission rows */}
        <div className="pgm-permissions">
          {PERMISSION_META.map(meta => {
            const state = permissions[meta.key];
            const isGranted = state === 'granted';
            const isRequesting = state === 'requesting';
            return (
              <div
                key={meta.key}
                className={`pgm-row${isGranted ? ' pgm-row--granted' : ''}`}
                style={isGranted ? { borderColor: meta.accentColor + '44' } : undefined}
              >
                <div className="pgm-row__icon" style={{ color: meta.accentColor, background: meta.accentColor + '12', borderColor: meta.accentColor + '33' }}>
                  {meta.icon}
                </div>
                <div className="pgm-row__body">
                  <div className="pgm-row__top">
                    <span className="pgm-row__label">{meta.label}</span>
                    <StatusBadge state={state} />
                  </div>
                  <div className="pgm-row__desc">{meta.description}</div>
                  <div className="pgm-row__detail">{meta.detail}</div>
                </div>
                <button
                  className={`pgm-row__btn${isGranted ? ' pgm-row__btn--revoke' : ''}`}
                  style={!isGranted ? { borderColor: meta.accentColor + '66', color: meta.accentColor } : undefined}
                  disabled={isRequesting}
                  onClick={() => {
                    if (isGranted) {
                      // Instruct user — browser handles revocation
                      window.open('about:preferences#privacy', '_blank');
                    } else {
                      requestPermission(meta.key);
                    }
                  }}
                >
                  {isRequesting
                    ? <RefreshCw size={12} className="pgm-spin" />
                    : isGranted
                    ? <><X size={11} /> Revoke</>
                    : <><ChevronRight size={11} /> Allow</>
                  }
                </button>
              </div>
            );
          })}
        </div>

        {/* GDPR notice */}
        <div className="pgm-gdpr">
          <Lock size={10} style={{ color: '#334155', flexShrink: 0 }} />
          <span>All permissions are stored locally. No data is sent to external servers without your explicit consent. See our <span style={{ color: '#60a5fa' }}>privacy policy</span> for details.</span>
        </div>

        {/* Actions */}
        <div className="pgm-actions">
          <button
            className="pgm-btn-secondary"
            onClick={handleContinue}
          >
            Skip
          </button>
          <button
            className={`pgm-btn-primary${allReviewed ? ' pgm-btn-primary--ready' : ''}`}
            onClick={handleContinue}
          >
            <ShieldCheck size={13} />
            Continue to Aippie
          </button>
        </div>

      </div>
    </div>
  );
}
