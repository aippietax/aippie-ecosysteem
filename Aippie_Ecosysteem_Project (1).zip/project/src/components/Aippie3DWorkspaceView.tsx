// @ts-nocheck
import { useCallback, useEffect, useRef, useState } from 'react';
import {
  X, Mic, MicOff, Zap, Users, ShieldCheck, TrendingUp, BookOpen,
  Music, Building2, Coins, Send, Eye, EyeOff, Lock, Globe, Star,
  Map, MessageSquare, ShoppingBag, RefreshCw, CheckCircle, Gamepad2,
} from 'lucide-react';
import { supabase } from '../lib/supabase';
import AippieWorldGamesView from './AippieWorldGamesView';

// ── Types ────────────────────────────────────────────────────────────────────
interface AvatarNode {
  id: string; name: string; pin: string;
  x: number; z: number; tx: number; tz: number;
  color: string; isMe: boolean; isAI: boolean;
  verifiedType: 'none' | 'gold' | 'platinum';
  speaking: boolean; bubble: string; bubbleTs: number;
  glowColor?: string; titleLabel?: string;
}
interface ChatMsg { sender: string; text: string; isAI: boolean; ts: number; }
interface Particle { x: number; y: number; vx: number; vy: number; life: number; color: string; size: number; }
interface ShopItem { slug: string; name: string; description: string; price_apc: number; category: string; icon: string; }

interface Props {
  roomId: string; userPin: string; displayName: string; avatarColor: string;
  verifiedType?: 'none' | 'gold' | 'platinum';
  peerPins?: { pin: string; name: string; color: string; verified?: 'none' | 'gold' | 'platinum' }[];
  onClose: () => void;
}

// ── World zones ──────────────────────────────────────────────────────────────
const ZONES = [
  { id: 'plaza',    name: 'Aippie Plaza',   wx: 0,    wz: 0,    color: '#0ea5e9', glow: '#38bdf8', r: 110, icon: '⬡', desc: 'Social hub · meet everyone' },
  { id: 'trading',  name: 'Trading Floor',   wx: -220, wz: -140, color: '#22c55e', glow: '#86efac', r: 85,  icon: '📈', desc: 'Live markets · trading' },
  { id: 'tower',    name: 'Business Tower',  wx: 220,  wz: -140, color: '#f59e0b', glow: '#fcd34d', r: 85,  icon: '🏢', desc: 'Boardroom · meetings' },
  { id: 'academy',  name: 'Aippie Academy', wx: -220, wz: 160,  color: '#a855f7', glow: '#d8b4fe', r: 85,  icon: '📚', desc: 'Learn · AI certificates' },
  { id: 'stage',    name: 'Live Stage',      wx: 220,  wz: 160,  color: '#ec4899', glow: '#f9a8d4', r: 85,  icon: '🎭', desc: 'Events · live shows' },
  { id: 'vault',    name: 'Secure Vault',    wx: 0,    wz: 200,  color: '#475569', glow: '#94a3b8', r: 65,  icon: '🔒', desc: 'Document vault · encrypted' },
];

const AI_WAYPOINTS = [
  { x: 0, z: 0 }, { x: -1.8, z: -1.2 }, { x: 1.8, z: -1.2 },
  { x: -1.8, z: 1.4 }, { x: 1.8, z: 1.4 }, { x: 0, z: 1.7 },
];

const AI_GREETINGS = [
  'Welcome to the Aippie Virtual World! Explore all 6 zones.',
  'Spin the daily wheel for free APC coins!',
  'You earn APC coins by being active in each zone.',
  'Visit the shop — buy glow effects and titles!',
  'In the Business Tower start boardrooms with no time limit.',
  'All communication is E2EE encrypted. 100% private.',
  'Zone King boost: dominate a zone and earn 2x more!',
];

const SPIN_PRIZES = [2, 5, 10, 3, 25, 1, 50, 8];
const SPIN_COLORS = ['#0ea5e9','#22c55e','#f59e0b','#ec4899','#fcd34d','#a855f7','#ef4444','#38bdf8'];

const SHOP_GLOW: Record<string, string> = {
  glow_gold: '#f59e0b', glow_cyan: '#22d3ee', glow_pink: '#ec4899',
};

function badgeCol(v: 'none' | 'gold' | 'platinum') {
  if (v === 'gold') return '#f59e0b';
  if (v === 'platinum') return '#e2e8f0';
  return 'transparent';
}
function initials(n: string) { return n.split(' ').map(w => w[0]).join('').toUpperCase().slice(0, 2); }
function wToS(wx: number, wz: number, cam: { x: number; z: number }, W: number, H: number) {
  return { sx: W / 2 + (wx - cam.x), sy: H / 2 + (wz - cam.z) };
}

export default function Aippie3DWorkspaceView({
  roomId, userPin, displayName, avatarColor, verifiedType = 'none',
  peerPins = [], onClose,
}: Props) {
  const canvasRef    = useRef<HTMLCanvasElement>(null);
  const animRef      = useRef(0);
  const tickRef      = useRef(0);
  const avatarsRef   = useRef<AvatarNode[]>([]);
  const particlesRef = useRef<Particle[]>([]);
  const chatEndRef   = useRef<HTMLDivElement>(null);

  const [avatars, setAvatars]         = useState<AvatarNode[]>([]);
  const [chat, setChat]               = useState<ChatMsg[]>([]);
  const [input, setInput]             = useState('');
  const [muted, setMuted]             = useState(false);
  const [hudVisible, setHudVisible]   = useState(true);
  const [miniMap, setMiniMap]         = useState(true);
  const [apc, setApc]                 = useState(0);
  const [walletId, setWalletId]       = useState<string | null>(null);
  const [currentZone, setCurrentZone] = useState('Aippie Plaza');
  const [zoneDesc, setZoneDesc]       = useState('Social hub · meet everyone');
  const [blackout, setBlackout]       = useState(false);
  const [cam, setCam]                 = useState({ x: 0, z: 0 });
  const camRef = useRef({ x: 0, z: 0 });
  const aiWpRef    = useRef(0);
  const aiTimerRef = useRef(0);

  // Shop & Spin
  const [showShop, setShowShop]         = useState(false);
  const [showGames, setShowGames]       = useState(false);
  const [shopItems, setShopItems]       = useState<ShopItem[]>([]);
  const [ownedSlugs, setOwnedSlugs]     = useState<Set<string>>(new Set());
  const [shopTab, setShopTab]           = useState<'spin'|'shop'|'owned'>('spin');
  const [spinning, setSpinning]         = useState(false);
  const [spinDeg, setSpinDeg]           = useState(0);
  const [spinPrize, setSpinPrize]       = useState<number | null>(null);
  const [spinDone, setSpinDone]         = useState(false);
  const [spinUsedToday, setSpinUsedToday] = useState(false);
  const [buyMsg, setBuyMsg]             = useState('');
  const [equippedGlow, setEquippedGlow] = useState<string | undefined>(undefined);
  const [equippedTitle, setEquippedTitle] = useState<string | undefined>(undefined);

  useEffect(() => { avatarsRef.current = avatars; }, [avatars]);
  useEffect(() => { camRef.current = cam; }, [cam]);

  // ── Load APC wallet + daily spin state ───────────────────────────────────
  useEffect(() => {
    const load = async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      // Load wallet
      const { data: wallet } = await supabase
        .from('apc_wallets').select('id, balance_apc').eq('user_id', user.id).maybeSingle();
      if (wallet) { setApc(Math.floor(wallet.balance_apc)); setWalletId(wallet.id); }

      // Check daily spin
      const today = new Date().toISOString().slice(0, 10);
      const { data: spin } = await supabase
        .from('world_daily_spins').select('id').eq('user_id', user.id).eq('spin_date', today).maybeSingle();
      if (spin) setSpinUsedToday(true);

      // Load owned items
      const { data: owned } = await supabase.from('world_owned_items').select('item_slug, equipped').eq('user_id', user.id);
      if (owned) {
        setOwnedSlugs(new Set(owned.map(o => o.item_slug)));
        const glow = owned.find(o => o.equipped && o.item_slug.startsWith('glow_'));
        const title = owned.find(o => o.equipped && o.item_slug.startsWith('title_'));
        if (glow) setEquippedGlow(SHOP_GLOW[glow.item_slug]);
        if (title) {
          const { data: ti } = await supabase.from('world_shop_items').select('icon,name').eq('slug', title.item_slug).maybeSingle();
          if (ti) setEquippedTitle(`${ti.icon} ${ti.name.split(' ')[0]}`);
        }
      }
    };
    load();
  }, []);

  // ── Load shop items ───────────────────────────────────────────────────────
  useEffect(() => {
    supabase.from('world_shop_items').select('*').order('price_apc').then(({ data }) => {
      if (data) setShopItems(data as ShopItem[]);
    });
  }, []);

  // ── Apply equipped items to my avatar ────────────────────────────────────
  useEffect(() => {
    setAvatars(prev => prev.map(av =>
      av.isMe ? { ...av, glowColor: equippedGlow, titleLabel: equippedTitle } : av
    ));
    avatarsRef.current = avatarsRef.current.map(av =>
      av.isMe ? { ...av, glowColor: equippedGlow, titleLabel: equippedTitle } : av
    );
  }, [equippedGlow, equippedTitle]);

  // ── Blur blackout for Vault ───────────────────────────────────────────────
  useEffect(() => {
    const onBlur  = () => { if (currentZone === 'Secure Vault') setBlackout(true); };
    const onFocus = () => setBlackout(false);
    window.addEventListener('blur', onBlur); window.addEventListener('focus', onFocus);
    return () => { window.removeEventListener('blur', onBlur); window.removeEventListener('focus', onFocus); };
  }, [currentZone]);

  // ── Initialize world ──────────────────────────────────────────────────────
  useEffect(() => {
    const nodes: AvatarNode[] = [
      { id:'ai', name:'AIPPIE ORACLE', pin:'AI-01', x:0, z:-50, tx:0, tz:-50,
        color:'#ec4899', isMe:false, isAI:true, verifiedType:'platinum',
        speaking:false, bubble:'', bubbleTs:0 },
      { id:'me', name:displayName, pin:userPin, x:0, z:40, tx:0, tz:40,
        color:avatarColor, isMe:true, isAI:false, verifiedType,
        speaking:false, bubble:'', bubbleTs:0,
        glowColor: equippedGlow, titleLabel: equippedTitle },
      ...peerPins.map((p, i) => ({
        id:p.pin, name:p.name, pin:p.pin,
        x:(i%2===0?-70:70)+i*12, z:-30+(i%3)*30, tx:(i%2===0?-70:70)+i*12, tz:-30+(i%3)*30,
        color:p.color, isMe:false, isAI:false,
        verifiedType:(p.verified??'none') as 'none'|'gold'|'platinum',
        speaking:false, bubble:'', bubbleTs:0,
      })),
    ];
    setAvatars(nodes); avatarsRef.current = nodes;
    setChat([{ sender:'AIPPIE ORACLE',
      text:`Welcome ${displayName}! Spin the daily wheel for APC coins. Buy avatar upgrades in the Shop!`,
      isAI:true, ts:Date.now() }]);
    setTimeout(() => {
      const msg = AI_GREETINGS[0];
      setAvatars(prev => prev.map(av => av.isAI ? { ...av, bubble:msg, bubbleTs:Date.now(), speaking:true } : av));
      avatarsRef.current = avatarsRef.current.map(av => av.isAI ? { ...av, bubble:msg, bubbleTs:Date.now(), speaking:true } : av);
    }, 1800);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // ── Supabase presence ─────────────────────────────────────────────────────
  useEffect(() => {
    const ch = supabase.channel(`aippie-world:${roomId}`)
      .on('presence', { event: 'sync' }, () => {
        const state = ch.presenceState();
        const others = Object.values(state).flat() as unknown as { pin:string; x:number; z:number }[];
        setAvatars(prev => {
          const upd = prev.map(av => {
            const peer = others.find(o => o.pin === av.id && o.pin !== userPin);
            return peer ? { ...av, tx:peer.x, tz:peer.z } : av;
          });
          avatarsRef.current = upd; return upd;
        });
      })
      .subscribe(async status => {
        if (status === 'SUBSCRIBED') await ch.track({ pin:userPin, name:displayName, x:0, z:40 });
      });
    return () => { supabase.removeChannel(ch); };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [roomId]);

  // ── APC presence earning (every 30s) ─────────────────────────────────────
  useEffect(() => {
    const id = setInterval(async () => {
      const earn = 1 + Math.floor(Math.random() * 3);
      setApc(prev => prev + earn);
      // DB credit
      const { data: { user } } = await supabase.auth.getUser();
      if (user) {
        supabase.from('apc_wallets').upsert({ user_id:user.id, balance_apc:earn }, { onConflict:'user_id' });
        supabase.rpc('apc_transfer_by_chat_pin', { p_to_pin:'WORLD', p_amount:0 }).then(() => {});
        supabase.from('apc_wallets').update({ balance_apc: supabase.rpc('apc_transfer_by_chat_pin', { p_to_pin:'X', p_amount:0 }) as unknown as number });
        // Simpler: just increment in DB
        await supabase.rpc('world_earn_apc', { p_amount: earn }).catch(() => {
          supabase.from('apc_wallets')
            .update({ balance_apc: apc + earn })
            .eq('user_id', user.id);
        });
        supabase.from('world_presence_log').insert({ user_id:user.id, zone_id:currentZone, apc_earned:earn });
      }
      // Coin burst on canvas
      const me = avatarsRef.current.find(a => a.isMe);
      if (!me) return;
      const W = canvasRef.current?.width ?? 720, H = canvasRef.current?.height ?? 480;
      const { sx, sy } = wToS(me.x, me.z, camRef.current, W, H);
      for (let i = 0; i < 12; i++) {
        particlesRef.current.push({ x:sx, y:sy, vx:(Math.random()-.5)*4, vy:-Math.random()*4-.5, life:1, color:'#fcd34d', size:2+Math.random()*3 });
      }
    }, 30000);
    return () => clearInterval(id);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [currentZone]);

  // ── AI Oracle roaming ─────────────────────────────────────────────────────
  useEffect(() => {
    const id = setInterval(() => {
      aiTimerRef.current++;
      const wp = AI_WAYPOINTS[aiWpRef.current % AI_WAYPOINTS.length];
      const tx = wp.x * 95, tz = wp.z * 95;
      setAvatars(prev => prev.map(av => av.isAI ? { ...av, tx, tz } : av));
      avatarsRef.current = avatarsRef.current.map(av => av.isAI ? { ...av, tx, tz } : av);
      if (aiTimerRef.current % 2 === 0) {
        const msg = AI_GREETINGS[Math.floor(Math.random()*AI_GREETINGS.length)];
        setAvatars(prev => prev.map(av => av.isAI ? { ...av, bubble:msg, bubbleTs:Date.now(), speaking:true } : av));
        avatarsRef.current = avatarsRef.current.map(av => av.isAI ? { ...av, bubble:msg, bubbleTs:Date.now(), speaking:true } : av);
        setChat(prev => [...prev.slice(-50), { sender:'AIPPIE ORACLE', text:msg, isAI:true, ts:Date.now() }]);
        setTimeout(() => setAvatars(prev => prev.map(av => av.isAI ? { ...av, speaking:false } : av)), 5500);
      }
      aiWpRef.current++;
    }, 7000);
    return () => clearInterval(id);
  }, []);

  // ── Canvas render loop ────────────────────────────────────────────────────
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    const lerp = (a:number, b:number, t:number) => a+(b-a)*t;

    const draw = () => {
      tickRef.current++;
      const tk = tickRef.current;
      const W = canvas.width, H = canvas.height;

      avatarsRef.current = avatarsRef.current.map(av => ({
        ...av, x:lerp(av.x,av.tx,.07), z:lerp(av.z,av.tz,.07),
      }));
      if (tk%4===0) setAvatars([...avatarsRef.current]);

      const me = avatarsRef.current.find(a=>a.isMe);
      if (me) {
        camRef.current = { x:lerp(camRef.current.x,me.x,.08), z:lerp(camRef.current.z,me.z,.08) };
        if (tk%4===0) setCam({...camRef.current});
      }
      const cam = camRef.current;

      // Sky
      const sky = ctx.createRadialGradient(W/2,H/2,0,W/2,H/2,W*.9);
      sky.addColorStop(0,'#030d20'); sky.addColorStop(.65,'#020710'); sky.addColorStop(1,'#000207');
      ctx.fillStyle=sky; ctx.fillRect(0,0,W,H);

      // Stars
      for (let i=0;i<100;i++) {
        const sx=(i*173.3%W+W)%W, sy=(i*97.7%H+H)%H;
        const fl=.2+.8*Math.abs(Math.sin(tk*.015+i*.4));
        ctx.globalAlpha=fl*.5;
        ctx.fillStyle=i%7===0?'#a5f3fc':'#fff';
        ctx.beginPath(); ctx.arc(sx,sy,i%5===0?1.2:.7,0,Math.PI*2); ctx.fill();
      }
      ctx.globalAlpha=1;

      // Zone paths
      ctx.setLineDash([5,12]);
      ZONES.forEach(z=>{
        const {sx:zx,sy:zy}=wToS(z.wx,z.wz,cam,W,H), {sx:px,sy:py}=wToS(0,0,cam,W,H);
        ctx.strokeStyle=z.color+'28'; ctx.lineWidth=1.5;
        ctx.beginPath(); ctx.moveTo(px,py); ctx.lineTo(zx,zy); ctx.stroke();
      });
      ctx.setLineDash([]);

      // Zones
      ZONES.forEach(zone=>{
        const {sx,sy}=wToS(zone.wx,zone.wz,cam,W,H);
        const pulse=.5+.5*Math.sin(tk*.035+zone.wx*.01);
        const og=ctx.createRadialGradient(sx,sy,zone.r*.6,sx,sy,zone.r+28+pulse*14);
        og.addColorStop(0,zone.glow+'18'); og.addColorStop(1,'transparent');
        ctx.fillStyle=og; ctx.beginPath(); ctx.arc(sx,sy,zone.r+28+pulse*14,0,Math.PI*2); ctx.fill();
        const zg=ctx.createRadialGradient(sx,sy,0,sx,sy,zone.r);
        zg.addColorStop(0,zone.color+'38'); zg.addColorStop(.7,zone.color+'18'); zg.addColorStop(1,zone.color+'06');
        ctx.fillStyle=zg; ctx.beginPath(); ctx.arc(sx,sy,zone.r,0,Math.PI*2); ctx.fill();
        ctx.strokeStyle=zone.glow+(Math.floor(55+pulse*70)).toString(16).padStart(2,'0');
        ctx.lineWidth=1.8; ctx.beginPath(); ctx.arc(sx,sy,zone.r,0,Math.PI*2); ctx.stroke();
        ctx.strokeStyle=zone.color+'1a'; ctx.lineWidth=.5;
        for(let r=1;r<=3;r++){ctx.beginPath();ctx.arc(sx,sy,zone.r*r/3.8,0,Math.PI*2);ctx.stroke();}
        ctx.fillStyle=zone.glow; ctx.font='bold 11px sans-serif'; ctx.textAlign='center';
        ctx.shadowColor=zone.glow; ctx.shadowBlur=6;
        ctx.fillText(zone.name,sx,sy-zone.r+20); ctx.shadowBlur=0;
        ctx.font='24px sans-serif'; ctx.fillText(zone.icon,sx,sy+12);
        if(me){
          const dist=Math.sqrt((me.x-zone.wx)**2+(me.z-zone.wz)**2);
          if(dist<zone.r*.85){
            ctx.fillStyle='#cbd5e1'; ctx.font='9px sans-serif'; ctx.fillText(zone.desc,sx,sy+zone.r-10);
          }
        }
        ctx.textAlign='left';
      });

      // Particles
      particlesRef.current=particlesRef.current.filter(p=>p.life>.02);
      particlesRef.current.forEach(p=>{
        p.x+=p.vx; p.y+=p.vy; p.vy+=.06; p.life*=.93;
        ctx.globalAlpha=p.life; ctx.fillStyle=p.color;
        ctx.beginPath(); ctx.arc(p.x,p.y,p.size,0,Math.PI*2); ctx.fill();
      });
      ctx.globalAlpha=1;

      // Avatars
      avatarsRef.current.forEach(av=>{
        const {sx,sy}=wToS(av.x,av.z,cam,W,H);
        ctx.fillStyle='rgba(0,0,0,.35)';
        ctx.beginPath(); ctx.ellipse(sx,sy+19,17,6,0,0,Math.PI*2); ctx.fill();

        // Custom glow (shop item)
        if (av.glowColor) {
          const p=.4+.6*Math.abs(Math.sin(tk*.065));
          const ag=ctx.createRadialGradient(sx,sy,10,sx,sy,36+p*14);
          ag.addColorStop(0,av.glowColor+'60'); ag.addColorStop(1,'transparent');
          ctx.fillStyle=ag; ctx.beginPath(); ctx.arc(sx,sy,36+p*14,0,Math.PI*2); ctx.fill();
        } else if (av.isAI) {
          const p=.4+.6*Math.abs(Math.sin(tk*.065));
          const ag=ctx.createRadialGradient(sx,sy,10,sx,sy,36+p*14);
          ag.addColorStop(0,'#ec489945'); ag.addColorStop(1,'transparent');
          ctx.fillStyle=ag; ctx.beginPath(); ctx.arc(sx,sy,36+p*14,0,Math.PI*2); ctx.fill();
        }

        if(av.verifiedType!=='none'){
          ctx.strokeStyle=badgeCol(av.verifiedType); ctx.lineWidth=2.5;
          ctx.shadowColor=badgeCol(av.verifiedType); ctx.shadowBlur=5;
          ctx.beginPath(); ctx.arc(sx,sy,20,0,Math.PI*2); ctx.stroke(); ctx.shadowBlur=0;
        }
        if(av.speaking){
          for(let r=0;r<3;r++){
            const rp=((tk*.065+r*.33)%1);
            ctx.strokeStyle=`rgba(255,255,255,${(1-rp)*.45})`; ctx.lineWidth=1.5;
            ctx.beginPath(); ctx.arc(sx,sy,21+rp*24,0,Math.PI*2); ctx.stroke();
          }
        }
        const bg=ctx.createRadialGradient(sx-4,sy-4,2,sx,sy,18);
        bg.addColorStop(0,av.color+'ff'); bg.addColorStop(1,av.color+'99');
        ctx.fillStyle=bg; ctx.shadowColor=av.color; ctx.shadowBlur=av.isMe?10:4;
        ctx.beginPath(); ctx.arc(sx,sy,18,0,Math.PI*2); ctx.fill(); ctx.shadowBlur=0;
        ctx.fillStyle='#fff'; ctx.font=av.isAI?'bold 9px monospace':'bold 11px sans-serif';
        ctx.textAlign='center'; ctx.textBaseline='middle';
        ctx.fillText(av.isAI?'AI':initials(av.name),sx,sy); ctx.textBaseline='alphabetic';

        // Name tag (wider if has title)
        const hasTitle = !!av.titleLabel;
        const nw = hasTitle ? 110 : 98;
        ctx.fillStyle='rgba(2,8,24,.9)';
        ctx.beginPath(); ctx.roundRect(sx-nw/2,sy-(hasTitle?60:53),nw,hasTitle?33:26,4); ctx.fill();
        ctx.strokeStyle=av.isAI?'#ec489970':av.color+'50'; ctx.lineWidth=1;
        ctx.beginPath(); ctx.roundRect(sx-nw/2,sy-(hasTitle?60:53),nw,hasTitle?33:26,4); ctx.stroke();
        ctx.fillStyle=av.isAI?'#f9a8d4':'#e2e8f0'; ctx.font='bold 9px sans-serif'; ctx.textAlign='center';
        ctx.fillText(av.name.length>13?av.name.slice(0,12)+'…':av.name,sx,sy-(hasTitle?50:44));
        if (hasTitle && av.titleLabel) {
          ctx.fillStyle='#fcd34d'; ctx.font='bold 8px sans-serif';
          ctx.fillText(av.titleLabel,sx,sy-38);
        } else if(av.verifiedType!=='none'){
          ctx.fillStyle=badgeCol(av.verifiedType); ctx.font='8px sans-serif';
          ctx.fillText(av.verifiedType==='platinum'?'✦ PLT':'★ GOLD',sx,sy-34);
        } else if(av.isMe){
          ctx.fillStyle='#38bdf8'; ctx.font='8px monospace'; ctx.fillText('YOU',sx,sy-34);
        }

        // Bubble
        const bAge=Date.now()-av.bubbleTs;
        if(av.bubble&&bAge<6000){
          const alpha=bAge>4500?1-(bAge-4500)/1500:1;
          const bTxt=av.bubble.length>46?av.bubble.slice(0,45)+'…':av.bubble;
          const bW=Math.min(165,bTxt.length*5.3+22);
          ctx.globalAlpha=alpha;
          ctx.fillStyle='rgba(2,8,28,.93)'; ctx.strokeStyle=av.isAI?'#ec4899':av.color; ctx.lineWidth=1;
          ctx.beginPath(); ctx.roundRect(sx-bW/2,sy-92,bW,29,7); ctx.fill(); ctx.stroke();
          ctx.fillStyle='rgba(2,8,28,.93)';
          ctx.beginPath(); ctx.moveTo(sx-5,sy-63);ctx.lineTo(sx+5,sy-63);ctx.lineTo(sx,sy-55);ctx.fill();
          ctx.fillStyle=av.isAI?'#f9a8d4':'#e2e8f0'; ctx.font='8.5px sans-serif'; ctx.textAlign='center';
          ctx.fillText(bTxt,sx,sy-73); ctx.globalAlpha=1;
        }
        ctx.textAlign='left';
      });

      // Minimap
      if(miniMap){
        const mm={x:12,y:H-122,w:110,h:110},SC=mm.w/560;
        ctx.fillStyle='rgba(2,8,24,.88)'; ctx.beginPath(); ctx.roundRect(mm.x,mm.y,mm.w,mm.h,8); ctx.fill();
        ctx.strokeStyle='#1e3a5f'; ctx.lineWidth=1; ctx.beginPath(); ctx.roundRect(mm.x,mm.y,mm.w,mm.h,8); ctx.stroke();
        ZONES.forEach(z=>{
          const mx=mm.x+mm.w/2+z.wx*SC, my=mm.y+mm.h/2+z.wz*SC;
          ctx.fillStyle=z.color+'90'; ctx.beginPath(); ctx.arc(mx,my,9,0,Math.PI*2); ctx.fill();
          ctx.font='6.5px sans-serif'; ctx.textAlign='center'; ctx.fillStyle=z.glow; ctx.fillText(z.icon,mx,my+2);
        });
        avatarsRef.current.forEach(av=>{
          const mx=Math.max(mm.x+4,Math.min(mm.x+mm.w-4,mm.x+mm.w/2+av.x*SC));
          const my=Math.max(mm.y+4,Math.min(mm.y+mm.h-4,mm.y+mm.h/2+av.z*SC));
          ctx.fillStyle=av.isAI?'#ec4899':av.color;
          ctx.shadowColor=av.isMe?av.color:'transparent'; ctx.shadowBlur=av.isMe?5:0;
          ctx.beginPath(); ctx.arc(mx,my,av.isMe?4.5:3,0,Math.PI*2); ctx.fill(); ctx.shadowBlur=0;
        });
        ctx.textAlign='left';
      }

      // Zone detection
      if(me&&tk%30===0){
        let nearest=ZONES[0],nearDist=Infinity;
        ZONES.forEach(z=>{const d=Math.sqrt((me.x-z.wx)**2+(me.z-z.wz)**2);if(d<nearDist){nearDist=d;nearest=z;}});
        if(nearest.name!==currentZone){setCurrentZone(nearest.name);setZoneDesc(nearest.desc);}
      }

      animRef.current=requestAnimationFrame(draw);
    };

    draw();
    return () => cancelAnimationFrame(animRef.current);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // ── Movement ─────────────────────────────────────────────────────────────
  const move = useCallback((dx:number,dz:number)=>{
    setAvatars(prev=>{
      const upd=prev.map(av=>av.isMe?{...av,tx:av.tx+dx*26,tz:av.tz+dz*26}:av);
      avatarsRef.current=upd; return upd;
    });
  },[]);

  useEffect(()=>{
    const keys:Record<string,boolean>={};
    const dn=(e:KeyboardEvent)=>{ keys[e.key]=true; };
    const up=(e:KeyboardEvent)=>{ keys[e.key]=false; };
    const loop=setInterval(()=>{
      if(keys['ArrowUp']   ||keys['w'])move(0,-1);
      if(keys['ArrowDown'] ||keys['s'])move(0,1);
      if(keys['ArrowLeft'] ||keys['a'])move(-1,0);
      if(keys['ArrowRight']||keys['d'])move(1,0);
    },50);
    window.addEventListener('keydown',dn); window.addEventListener('keyup',up);
    return ()=>{clearInterval(loop);window.removeEventListener('keydown',dn);window.removeEventListener('keyup',up);};
  },[move]);

  // ── Chat ─────────────────────────────────────────────────────────────────
  const sendMsg = useCallback(()=>{
    if(!input.trim())return;
    const txt=input.trim();
    setChat(prev=>[...prev.slice(-50),{sender:displayName,text:txt,isAI:false,ts:Date.now()}]);
    setAvatars(prev=>prev.map(av=>av.isMe?{...av,bubble:txt,bubbleTs:Date.now(),speaking:true}:av));
    avatarsRef.current=avatarsRef.current.map(av=>av.isMe?{...av,bubble:txt,bubbleTs:Date.now(),speaking:true}:av);
    setInput('');
    setTimeout(()=>setAvatars(prev=>prev.map(av=>av.isMe?{...av,speaking:false}:av)),5000);
    setTimeout(()=>chatEndRef.current?.scrollIntoView({behavior:'smooth'}),50);
  },[input,displayName]);

  useEffect(()=>{chatEndRef.current?.scrollIntoView({behavior:'smooth'});},[chat]);

  // ── Daily Spin ────────────────────────────────────────────────────────────
  const doSpin = useCallback(async () => {
    if (spinning || spinUsedToday) return;
    setSpinning(true); setSpinPrize(null); setSpinDone(false);
    const prizeIdx = Math.floor(Math.random() * SPIN_PRIZES.length);
    const prize = SPIN_PRIZES[prizeIdx];
    // Spin to land on prize: each segment = 360/8 = 45deg, prize is at center of segment
    const segDeg = 360 / SPIN_PRIZES.length;
    const targetDeg = 360 * 5 + (360 - (prizeIdx * segDeg + segDeg / 2)); // 5 full rotations
    setSpinDeg(targetDeg);
    setTimeout(async () => {
      setSpinPrize(prize); setSpinDone(true); setSpinning(false); setSpinUsedToday(true);
      setApc(prev => prev + prize);
      const { data: { user } } = await supabase.auth.getUser();
      if (user) {
        await supabase.from('world_daily_spins').insert({ user_id:user.id, apc_won:prize });
        await supabase.from('apc_wallets').upsert(
          { user_id:user.id, balance_apc:prize },
          { onConflict:'user_id' }
        );
        await supabase.from('world_presence_log').insert({ user_id:user.id, zone_id:'spin_wheel', apc_earned:prize });
      }
      // Burst particles
      const W = canvasRef.current?.width ?? 720, H = canvasRef.current?.height ?? 480;
      for (let i = 0; i < 30; i++) {
        particlesRef.current.push({ x:W/2, y:H/2, vx:(Math.random()-.5)*8, vy:(Math.random()-.5)*8, life:1, color:SPIN_COLORS[Math.floor(Math.random()*SPIN_COLORS.length)], size:3+Math.random()*4 });
      }
    }, 3500);
  }, [spinning, spinUsedToday]);

  // ── Buy item ─────────────────────────────────────────────────────────────
  const buyItem = useCallback(async (item: ShopItem) => {
    if (ownedSlugs.has(item.slug)) { setBuyMsg('Already owned!'); setTimeout(()=>setBuyMsg(''),2000); return; }
    if (apc < item.price_apc) { setBuyMsg('Not enough APC!'); setTimeout(()=>setBuyMsg(''),2000); return; }
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) { setBuyMsg('Log in first'); setTimeout(()=>setBuyMsg(''),2000); return; }
    setApc(prev => prev - item.price_apc);
    await supabase.from('world_owned_items').insert({ user_id:user.id, item_slug:item.slug, equipped:false });
    await supabase.from('apc_wallets').update({ balance_apc: apc - item.price_apc }).eq('user_id', user.id);
    setOwnedSlugs(prev => new Set([...prev, item.slug]));
    setBuyMsg(`${item.icon} ${item.name} bought!`); setTimeout(()=>setBuyMsg(''),3000);
  }, [apc, ownedSlugs]);

  // ── Equip item ────────────────────────────────────────────────────────────
  const equipItem = useCallback(async (item: ShopItem) => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;
    if (item.category === 'avatar' && item.slug.startsWith('glow_')) {
      const g = SHOP_GLOW[item.slug];
      setEquippedGlow(g);
      await supabase.from('world_owned_items').update({ equipped:false }).eq('user_id',user.id).like('item_slug','glow_%');
      await supabase.from('world_owned_items').update({ equipped:true }).eq('user_id',user.id).eq('item_slug',item.slug);
    }
    if (item.category === 'title') {
      setEquippedTitle(`${item.icon} ${item.name.split(' ')[0]}`);
      await supabase.from('world_owned_items').update({ equipped:false }).eq('user_id',user.id).like('item_slug','title_%');
      await supabase.from('world_owned_items').update({ equipped:true }).eq('user_id',user.id).eq('item_slug',item.slug);
    }
    if (item.category === 'boost') {
      setChat(prev => [...prev.slice(-50), { sender:'SYSTEM', text:`${item.icon} ${item.name} activated!`, isAI:true, ts:Date.now() }]);
    }
    if (item.category === 'emote') {
      const me = avatarsRef.current.find(a => a.isMe);
      if (me) {
        const W = canvasRef.current?.width??720, H = canvasRef.current?.height??480;
        const { sx, sy } = wToS(me.x, me.z, camRef.current, W, H);
        for (let i = 0; i < 25; i++) {
          particlesRef.current.push({ x:sx, y:sy, vx:(Math.random()-.5)*6, vy:-Math.random()*5-1, life:1, color:SPIN_COLORS[Math.floor(Math.random()*SPIN_COLORS.length)], size:4+Math.random()*4 });
        }
      }
    }
    setBuyMsg(`${item.icon} ${item.name} equipped!`); setTimeout(()=>setBuyMsg(''),2500);
  }, []);

  return (
    <div className="vw-root">
      {blackout && (
        <div className="vw-blackout">
          <Lock size={34}/><h2>AippieShield Active</h2>
          <p>Secure Vault hidden — go back.</p>
          <button className="vw-blackout__btn" onClick={()=>setBlackout(false)}>Resume</button>
        </div>
      )}

      {/* Games overlay */}
      {showGames && (
        <AippieWorldGamesView
          onClose={()=>setShowGames(false)}
          onApcEarned={n=>setApc(prev=>prev+n)}
        />
      )}

      {/* Coin shop overlay */}
      {showShop && (
        <div className="vw-shop-overlay" onClick={()=>setShowShop(false)}>
          <div className="vw-shop-modal" onClick={e=>e.stopPropagation()}>
            <div className="vw-shop-header">
              <div className="vw-shop-title">
                <Coins size={16} style={{color:'#fcd34d'}}/>
                <span>APC Shop</span>
                <span className="vw-shop-bal">{apc} APC</span>
              </div>
              <button className="vw-icon-btn" onClick={()=>setShowShop(false)}><X size={14}/></button>
            </div>

            {/* Tabs */}
            <div className="vw-shop-tabs">
              {(['spin','shop','owned'] as const).map(t=>(
                <button key={t} className={`vw-shop-tab${shopTab===t?' vw-shop-tab--active':''}`} onClick={()=>setShopTab(t)}>
                  {t==='spin'&&<><RefreshCw size={11}/> Daily Wheel</>}
                  {t==='shop'&&<><ShoppingBag size={11}/> Shop</>}
                  {t==='owned'&&<><Star size={11}/> My Items</>}
                </button>
              ))}
            </div>

            {/* Spin tab */}
            {shopTab==='spin'&&(
              <div className="vw-spin-tab">
                <p className="vw-spin-desc">Spin once per day and win APC coins!</p>
                <div className="vw-spin-wheel-wrap">
                  {/* Wheel */}
                  <div className="vw-spin-pointer">▼</div>
                  <div className="vw-spin-wheel" style={{ transform:`rotate(${spinDeg}deg)`, transition:spinning?'transform 3.5s cubic-bezier(0.17,0.67,0.12,1)':'none' }}>
                    {SPIN_PRIZES.map((prize,i)=>{
                      const seg=360/SPIN_PRIZES.length;
                      const rot=i*seg;
                      return (
                        <div key={i} className="vw-spin-segment" style={{
                          transform:`rotate(${rot}deg)`,
                          background:`conic-gradient(${SPIN_COLORS[i]} 0deg ${seg}deg, transparent ${seg}deg)`
                        }}>
                          <span className="vw-spin-prize" style={{ transform:`rotate(${rot+seg/2}deg) translateY(-58px) rotate(-${rot+seg/2}deg)` }}>
                            {prize}
                          </span>
                        </div>
                      );
                    })}
                  </div>
                </div>
                {spinDone && spinPrize !== null && (
                  <div className="vw-spin-result">
                    <CheckCircle size={18} style={{color:'#22c55e'}}/>
                    <span>You won <strong>{spinPrize} APC</strong>!</span>
                  </div>
                )}
                {spinUsedToday && !spinning && !spinDone && (
                  <p className="vw-spin-used">You already spun today. Come back tomorrow!</p>
                )}
                <button
                  className={`vw-spin-btn${spinUsedToday||spinning?' vw-spin-btn--disabled':''}`}
                  onClick={doSpin}
                  disabled={spinUsedToday||spinning}
                >
                  {spinning?'Spinning…':spinUsedToday?'Come back tomorrow':'Spin the wheel!'}
                </button>
              </div>
            )}

            {/* Shop tab */}
            {shopTab==='shop'&&(
              <div className="vw-shop-grid">
                {shopItems.map(item=>{
                  const owned = ownedSlugs.has(item.slug);
                  return (
                    <div key={item.slug} className={`vw-shop-item${owned?' vw-shop-item--owned':''}`}>
                      <div className="vw-shop-item__icon">{item.icon}</div>
                      <div className="vw-shop-item__info">
                        <div className="vw-shop-item__name">{item.name}</div>
                        <div className="vw-shop-item__desc">{item.description}</div>
                        <div className="vw-shop-item__cat">{item.category}</div>
                      </div>
                      <div className="vw-shop-item__right">
                        <div className="vw-shop-item__price"><Coins size={10}/>{item.price_apc}</div>
                        {owned
                          ? <button className="vw-shop-equip-btn" onClick={()=>equipItem(item)}>Equip</button>
                          : <button className="vw-shop-buy-btn" onClick={()=>buyItem(item)} disabled={apc<item.price_apc}>Buy</button>
                        }
                      </div>
                    </div>
                  );
                })}
              </div>
            )}

            {/* Owned tab */}
            {shopTab==='owned'&&(
              <div className="vw-shop-grid">
                {shopItems.filter(i=>ownedSlugs.has(i.slug)).length===0
                  ? <p className="vw-shop-empty">No items yet. Buy something in the Shop!</p>
                  : shopItems.filter(i=>ownedSlugs.has(i.slug)).map(item=>(
                    <div key={item.slug} className="vw-shop-item vw-shop-item--owned">
                      <div className="vw-shop-item__icon">{item.icon}</div>
                      <div className="vw-shop-item__info">
                        <div className="vw-shop-item__name">{item.name}</div>
                        <div className="vw-shop-item__desc">{item.description}</div>
                      </div>
                      <button className="vw-shop-equip-btn" onClick={()=>equipItem(item)}>Activate</button>
                    </div>
                  ))
                }
              </div>
            )}

            {buyMsg && <div className="vw-shop-buymsg">{buyMsg}</div>}
          </div>
        </div>
      )}

      {/* Top bar */}
      <div className="vw-topbar">
        <div className="vw-topbar__left">
          <div className="vw-live-dot"/>
          <Globe size={13} style={{color:'#38bdf8'}}/>
          <span className="vw-topbar__title">Aippie Virtual World</span>
          <span className="vw-topbar__zone">{currentZone}</span>
          <span className="vw-topbar__desc">{zoneDesc}</span>
        </div>
        <div className="vw-topbar__right">
          <button className="vw-apc-badge" onClick={()=>{setShowShop(true);setShopTab('spin');}}>
            <Coins size={12} style={{color:'#fcd34d'}}/><span>{apc} APC</span>
            <ShoppingBag size={10} style={{color:'#fcd34d',opacity:.7}}/>
          </button>
          <button className="vw-icon-btn vw-icon-btn--games" onClick={()=>setShowGames(true)} title="Games">
            <Gamepad2 size={14}/>
          </button>
          <div className="vw-user-count"><Users size={12}/><span>{avatars.filter(a=>!a.isAI).length}</span></div>
          <button className="vw-icon-btn" onClick={()=>setMuted(m=>!m)}>{muted?<MicOff size={13}/>:<Mic size={13}/>}</button>
          <button className="vw-icon-btn" onClick={()=>setMiniMap(m=>!m)}><Map size={13}/></button>
          <button className="vw-icon-btn" onClick={()=>setHudVisible(h=>!h)}>{hudVisible?<Eye size={13}/>:<EyeOff size={13}/>}</button>
          <button className="vw-icon-btn vw-icon-btn--close" onClick={onClose}><X size={15}/></button>
        </div>
      </div>

      {/* Body */}
      <div className="vw-body">
        <div className="vw-viewport">
          <canvas ref={canvasRef} width={720} height={480} className="vw-canvas"/>
          <div className="vw-shield-badge"><ShieldCheck size={9}/><span>E2EE · Anti-deepfake · AippieShield</span></div>
          <div className="vw-dpad">
            <button className="vw-dpad__btn" style={{gridColumn:2}} onClick={()=>move(0,-1)}>▲</button>
            <button className="vw-dpad__btn" style={{gridColumn:1,gridRow:2}} onClick={()=>move(-1,0)}>◀</button>
            <button className="vw-dpad__btn vw-dpad__center" style={{gridColumn:2,gridRow:2}}><Zap size={10}/></button>
            <button className="vw-dpad__btn" style={{gridColumn:3,gridRow:2}} onClick={()=>move(1,0)}>▶</button>
            <button className="vw-dpad__btn" style={{gridColumn:2,gridRow:3}} onClick={()=>move(0,1)}>▼</button>
          </div>
        </div>

        {hudVisible&&(
          <div className="vw-hud">
            <div className="vw-hud__block">
              <div className="vw-hud__label"><Globe size={10}/> Zones</div>
              <div className="vw-zones-grid">
                {ZONES.map(z=>(
                  <div key={z.id} className="vw-zone-chip" style={{borderColor:z.color+'55'}}>
                    <span>{z.icon}</span><span style={{color:z.glow}}>{z.name.split(' ')[0]}</span>
                  </div>
                ))}
              </div>
            </div>
            <div className="vw-hud__block">
              <div className="vw-hud__label"><Star size={10} style={{color:'#fcd34d'}}/> Unique in Aippie World</div>
              <div className="vw-features">
                {[
                  [<ShieldCheck size={9}/>,'E2EE + anti-screenshot'],
                  [<Coins size={9}/>,'Earn APC coins + play'],
                  [<Gamepad2 size={9}/>,'3 mini-games: Catcher, Memory, Quiz'],
                  [<ShoppingBag size={9}/>,'Avatar Shop & upgrades'],
                  [<RefreshCw size={9}/>,'Daily spin wheel'],
                  [<TrendingUp size={9}/>,'Trading Floor in-world'],
                  [<BookOpen size={9}/>,'AI Academy live courses'],
                  [<Building2 size={9}/>,'Boardroom with no time limit'],
                  [<Music size={9}/>,'Live Stage events'],
                ].map(([ico,lbl],i)=>(
                  <div key={i} className="vw-feature-row">
                    <span className="vw-feature-icon">{ico}</span><span>{lbl}</span>
                  </div>
                ))}
              </div>
            </div>
            <div className="vw-hud__block vw-hud__block--chat">
              <div className="vw-hud__label"><MessageSquare size={10}/> World Chat</div>
              <div className="vw-chat-msgs">
                {chat.slice(-20).map((m,i)=>(
                  <div key={i} className={`vw-chat-msg${m.isAI?' vw-chat-msg--ai':''}`}>
                    <span className="vw-chat-sender">{m.sender.length>12?m.sender.slice(0,11)+'…':m.sender}</span>
                    <span className="vw-chat-text">{m.text}</span>
                  </div>
                ))}
                <div ref={chatEndRef}/>
              </div>
              <div className="vw-chat-row">
                <input className="vw-chat-input" value={input} onChange={e=>setInput(e.target.value)}
                  onKeyDown={e=>e.key==='Enter'&&sendMsg()} placeholder="Write in the world…"/>
                <button className="vw-chat-send" onClick={sendMsg}><Send size={12}/></button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
