// @ts-nocheck
import { useEffect, useRef, useState, useCallback, lazy, Suspense, Component, type ReactNode } from 'react';
import {
  FileText, Zap, RefreshCw, Upload, CheckCircle2, AlertTriangle,
  Clock, ChevronRight, ExternalLink, Download, Building2, CreditCard,
  TrendingDown, Wifi, Lock, X, Search, Filter,
  MessageCircle, Phone, Video, Send, Mic, MicOff, VideoOff,
  PhoneOff, User, Circle, ArrowLeft, MoreVertical,
  Shield, BatteryCharging, Battery, CloudLightning, Euro, Check,
} from 'lucide-react';
import { supabase } from '../lib/supabase';

// ── Local ErrorBoundary (isolates AippieTaxView and other sections) ───────────
class LocalErrorBoundary extends Component<{ children: ReactNode }, { hasError: boolean }> {
  state = { hasError: false };
  static getDerivedStateFromError() { return { hasError: true }; }
  componentDidCatch() { this.setState({ hasError: false }); }
  render() { return this.state.hasError ? null : this.props.children; }
}

// ── Lazy-loaded Tax Hub (AippieTaxView) ───────────────────────────────────────
const AippieTaxView = lazy(() => import('./AippieTaxView'));

// ── Colour tokens ────────────────────────────────────────────────────────────
const C = {
  bg: '#0B0F19', surface: '#0F1520', panel: '#111827',
  border: 'rgba(96,165,250,0.15)', borderHi: 'rgba(96,165,250,0.45)',
  blue: '#60A5FA', blueDim: 'rgba(96,165,250,0.10)', blueGlow: 'rgba(96,165,250,0.22)',
  green: '#10B981', greenDim: 'rgba(16,185,129,0.10)',
  amber: '#F59E0B', amberDim: 'rgba(245,158,11,0.10)',
  red: '#EF4444', redDim: 'rgba(239,68,68,0.10)',
  text: '#E2E8F0', muted: '#64748B', dim: '#334155',
} as const;

// ── Persistence key ──────────────────────────────────────────────────────────
const PERSIST_KEY = 'aippie_ai_account_secure_state_v1';

function loadState<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(PERSIST_KEY);
    if (!raw) return fallback;
    const obj = JSON.parse(raw);
    return obj[key] !== undefined ? obj[key] : fallback;
  } catch { return fallback; }
}

function saveState(patch: Record<string, unknown>): void {
  try {
    const raw = localStorage.getItem(PERSIST_KEY);
    const obj = raw ? JSON.parse(raw) : {};
    localStorage.setItem(PERSIST_KEY, JSON.stringify({ ...obj, ...patch }));
  } catch { /* noop */ }
}

// ── Spanish Bank Registry (PSD2 Open Banking) ────────────────────────────────
export const SPANISH_BANK_REGISTRY = [
  { id: 'sabadell',   name: 'Banco Sabadell',           code: '0081', logoColor: '#006DFF' },
  { id: 'caixabank',  name: 'CaixaBank',                code: '2100', logoColor: '#009AD6' },
  { id: 'santander',  name: 'Banco Santander',          code: '0049', logoColor: '#EC0000' },
  { id: 'bbva',       name: 'BBVA',                     code: '0182', logoColor: '#004481' },
  { id: 'bankinter',  name: 'Bankinter',                code: '0128', logoColor: '#FF6600' },
  { id: 'unicaja',    name: 'Unicaja Banco',            code: '2103', logoColor: '#00A859' },
  { id: 'kutxabank',  name: 'Kutxabank',                code: '2095', logoColor: '#94A3B8' },
  { id: 'abanca',     name: 'Abanca',                   code: '2080', logoColor: '#00549A' },
  { id: 'ibercaja',   name: 'Ibercaja Banco',           code: '2085', logoColor: '#60A5FA' },
  { id: 'cajamar',    name: 'Cajamar Caja Rural',       code: '3058', logoColor: '#008346' },
  { id: 'openbank',   name: 'Openbank',                 code: '0073', logoColor: '#EC0000' },
  { id: 'evo',        name: 'EVO Banco',                code: '0239', logoColor: '#94A3B8' },
  { id: 'revolut_es', name: 'Revolut (Spain)',          code: '1582', logoColor: '#E2E8F0' },
  { id: 'qonto_es',   name: 'Qonto Corporate (Spain)',  code: 'ES88', logoColor: '#6200EE' },
] as const;
type BankId = typeof SPANISH_BANK_REGISTRY[number]['id'];

type BankConnectionStatus = 'idle' | 'authorizing' | 'connected' | 'error';

interface BankConnection {
  bankId: BankId;
  status: BankConnectionStatus;
  connectedAt?: string;
  consentId?: string;
}

// ── PSD2 Authorization Modal ──────────────────────────────────────────────────
interface PSD2ModalProps {
  bank: typeof SPANISH_BANK_REGISTRY[number];
  onConfirm: (iban: string, pin: string) => void;
  onClose: () => void;
  status: BankConnectionStatus;
}

function PSD2Modal({ bank, onConfirm, onClose, status }: PSD2ModalProps) {
  const [iban, setIban] = useState('');
  const [pin, setPin] = useState('');
  const [step, setStep] = useState<'credentials' | 'sca' | 'success'>(
    status === 'connected' ? 'success' : 'credentials'
  );
  const [scaCode, setScaCode] = useState('');
  const [scaInput, setScaInput] = useState('');
  const [scaError, setScaError] = useState('');

  // Generate a 6-digit SCA challenge when entering SCA step
  useEffect(() => {
    if (step === 'sca') {
      setScaCode(String(Math.floor(100000 + Math.random() * 900000)));
    }
  }, [step]);

  const handleCredentials = (e: React.FormEvent) => {
    e.preventDefault();
    if (!iban.trim() || pin.length < 4) return;
    setStep('sca');
  };

  const handleSca = (e: React.FormEvent) => {
    e.preventDefault();
    if (scaInput.trim() === scaCode) {
      setStep('success');
      onConfirm(iban, pin);
    } else {
      setScaError('Incorrect code. Please check your device and try again.');
    }
  };

  return (
    <div style={{
      position: 'fixed', inset: 0, zIndex: 200,
      background: 'rgba(7,11,20,0.88)',
      backdropFilter: 'blur(12px)',
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      padding: 24,
    }}>
      <div style={{
        width: '100%', maxWidth: 460,
        background: '#0F1520',
        border: `1px solid ${bank.logoColor}44`,
        borderRadius: 16,
        boxShadow: `0 0 48px ${bank.logoColor}22`,
        overflow: 'hidden',
      }}>
        {/* Header */}
        <div style={{
          padding: '18px 24px',
          background: `linear-gradient(135deg, ${bank.logoColor}18 0%, transparent 100%)`,
          borderBottom: `1px solid ${bank.logoColor}33`,
          display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
            <div style={{
              width: 40, height: 40, borderRadius: 10,
              background: bank.logoColor + '22',
              border: `1.5px solid ${bank.logoColor}55`,
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              fontSize: 13, fontWeight: 800, color: bank.logoColor, letterSpacing: '-0.02em',
            }}>
              {bank.name.slice(0, 2).toUpperCase()}
            </div>
            <div>
              <div style={{ fontSize: 15, fontWeight: 700, color: C.text }}>{bank.name}</div>
              <div style={{ fontSize: 11, color: C.muted }}>PSD2 Open Banking · Code {bank.code}</div>
            </div>
          </div>
          <button onClick={onClose} style={{ background: 'none', border: 'none', cursor: 'pointer', color: C.muted, padding: 4 }}>
            <X size={18} />
          </button>
        </div>

        <div style={{ padding: '24px' }}>
          {/* Progress steps */}
          <div style={{ display: 'flex', gap: 8, marginBottom: 24 }}>
            {(['credentials', 'sca', 'success'] as const).map((s, i) => {
              const labels = ['Credentials', 'SCA Verify', 'Connected'];
              const done = step === 'success' || (step === 'sca' && i === 0);
              const active = step === s;
              return (
                <div key={s} style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 4 }}>
                  <div style={{
                    width: 28, height: 28, borderRadius: '50%',
                    background: done ? C.green : active ? bank.logoColor : 'rgba(255,255,255,0.05)',
                    border: `1.5px solid ${done ? C.green : active ? bank.logoColor : C.dim}`,
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                    fontSize: 11, fontWeight: 700,
                    color: done || active ? '#fff' : C.muted,
                    transition: 'all 0.2s',
                  }}>
                    {done ? <CheckCircle2 size={14} /> : i + 1}
                  </div>
                  <div style={{ fontSize: 10, color: active ? C.text : C.muted, fontWeight: active ? 600 : 400 }}>
                    {labels[i]}
                  </div>
                </div>
              );
            })}
          </div>

          {step === 'credentials' && (
            <form onSubmit={handleCredentials} style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
              <div>
                <div style={{ fontSize: 12, color: C.muted, marginBottom: 6, letterSpacing: '0.06em', textTransform: 'uppercase', fontWeight: 600 }}>IBAN</div>
                <input
                  value={iban}
                  onChange={e => setIban(e.target.value.toUpperCase())}
                  placeholder="ES00 0000 0000 0000 0000 0000"
                  style={{
                    width: '100%', background: C.panel, border: `1px solid ${C.border}`,
                    borderRadius: 8, padding: '10px 14px', color: C.text, fontSize: 13,
                    outline: 'none', letterSpacing: '0.06em', fontFamily: 'monospace',
                    boxSizing: 'border-box',
                  }}
                />
              </div>
              <div>
                <div style={{ fontSize: 12, color: C.muted, marginBottom: 6, letterSpacing: '0.06em', textTransform: 'uppercase', fontWeight: 600 }}>Access PIN</div>
                <input
                  type="password"
                  value={pin}
                  onChange={e => setPin(e.target.value)}
                  placeholder="Minimum 4 digits"
                  maxLength={8}
                  style={{
                    width: '100%', background: C.panel, border: `1px solid ${C.border}`,
                    borderRadius: 8, padding: '10px 14px', color: C.text, fontSize: 14,
                    outline: 'none', letterSpacing: '0.3em', boxSizing: 'border-box',
                  }}
                />
              </div>
              <div style={{
                display: 'flex', alignItems: 'center', gap: 8,
                background: 'rgba(96,165,250,0.06)', border: `1px solid ${C.border}`,
                borderRadius: 8, padding: '8px 12px', fontSize: 11, color: C.muted,
              }}>
                <Lock size={12} style={{ flexShrink: 0 }} />
                Credentials are never stored. This is a simulated PSD2 consent flow.
              </div>
              <button type="submit" disabled={!iban.trim() || pin.length < 4} style={{
                background: !iban.trim() || pin.length < 4 ? C.dim : bank.logoColor,
                border: 'none', borderRadius: 8, padding: '11px 0',
                color: '#fff', fontSize: 14, fontWeight: 700, cursor: !iban.trim() || pin.length < 4 ? 'not-allowed' : 'pointer',
                transition: 'background 0.15s',
                boxShadow: !iban.trim() || pin.length < 4 ? 'none' : `0 0 20px ${bank.logoColor}44`,
              }}>
                Continue to SCA Verification
              </button>
            </form>
          )}

          {step === 'sca' && (
            <form onSubmit={handleSca} style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
              <div style={{
                background: 'rgba(245,158,11,0.08)', border: `1px solid ${C.amber}33`,
                borderRadius: 10, padding: '14px 16px', textAlign: 'center',
              }}>
                <div style={{ fontSize: 11, color: C.amber, marginBottom: 8, letterSpacing: '0.08em', textTransform: 'uppercase', fontWeight: 600 }}>
                  SCA Challenge Code
                </div>
                <div style={{ fontSize: 32, fontWeight: 900, color: C.text, letterSpacing: '0.25em', fontFamily: 'monospace' }}>
                  {scaCode}
                </div>
                <div style={{ fontSize: 11, color: C.muted, marginTop: 6 }}>
                  Enter this code on your banking app, then paste the confirmation code below.
                </div>
              </div>
              <div>
                <div style={{ fontSize: 12, color: C.muted, marginBottom: 6, letterSpacing: '0.06em', textTransform: 'uppercase', fontWeight: 600 }}>Confirmation Code</div>
                <input
                  value={scaInput}
                  onChange={e => { setScaInput(e.target.value); setScaError(''); }}
                  placeholder="Enter 6-digit code from your banking app"
                  maxLength={6}
                  style={{
                    width: '100%', background: C.panel,
                    border: `1px solid ${scaError ? C.red : C.border}`,
                    borderRadius: 8, padding: '10px 14px', color: C.text,
                    fontSize: 18, fontWeight: 700, outline: 'none',
                    letterSpacing: '0.25em', fontFamily: 'monospace', textAlign: 'center',
                    boxSizing: 'border-box',
                  }}
                />
                {scaError && (
                  <div style={{ fontSize: 12, color: C.red, marginTop: 6, display: 'flex', alignItems: 'center', gap: 5 }}>
                    <AlertTriangle size={12} />
                    {scaError}
                  </div>
                )}
              </div>
              <button type="submit" disabled={scaInput.length !== 6} style={{
                background: scaInput.length !== 6 ? C.dim : bank.logoColor,
                border: 'none', borderRadius: 8, padding: '11px 0',
                color: '#fff', fontSize: 14, fontWeight: 700, cursor: scaInput.length !== 6 ? 'not-allowed' : 'pointer',
                transition: 'background 0.15s',
              }}>
                Verify &amp; Authorize Access
              </button>
            </form>
          )}

          {step === 'success' && (
            <div style={{ textAlign: 'center', padding: '8px 0 16px' }}>
              <div style={{
                width: 64, height: 64, borderRadius: '50%',
                background: C.greenDim, border: `2px solid ${C.green}`,
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                margin: '0 auto 16px',
                boxShadow: `0 0 24px ${C.green}44`,
              }}>
                <CheckCircle2 size={30} color={C.green} />
              </div>
              <div style={{ fontSize: 18, fontWeight: 800, color: C.text, marginBottom: 6 }}>
                Connection Authorised
              </div>
              <div style={{ fontSize: 13, color: C.muted, marginBottom: 20 }}>
                {bank.name} is now linked via PSD2 Open Banking.
              </div>
              <div style={{
                background: C.greenDim, border: `1px solid ${C.green}33`,
                borderRadius: 8, padding: '10px 14px', fontSize: 12,
                color: C.green, fontFamily: 'monospace', letterSpacing: '0.04em',
              }}>
                CONSENT-ID: {Math.random().toString(36).slice(2, 18).toUpperCase()}
              </div>
              <button onClick={onClose} style={{
                marginTop: 20, background: bank.logoColor, border: 'none',
                borderRadius: 8, padding: '11px 32px', color: '#fff',
                fontSize: 14, fontWeight: 700, cursor: 'pointer',
              }}>
                Done
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

// ── Bank Selector Panel ───────────────────────────────────────────────────────
interface BankSelectorPanelProps {
  connections: Record<string, BankConnection>;
  onConnect: (bank: typeof SPANISH_BANK_REGISTRY[number]) => void;
  onDisconnect: (bankId: string) => void;
}

function BankSelectorPanel({ connections, onConnect, onDisconnect }: BankSelectorPanelProps) {
  const [query, setQuery] = useState('');

  const filtered = SPANISH_BANK_REGISTRY.filter(b =>
    !query ||
    b.name.toLowerCase().includes(query.toLowerCase()) ||
    b.code.toLowerCase().includes(query.toLowerCase())
  );

  const connectedCount = Object.values(connections).filter(c => c.status === 'connected').length;

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
      {/* Panel header */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <div>
          <div style={{ fontSize: 15, fontWeight: 700, color: C.text }}>PSD2 Open Banking</div>
          <div style={{ fontSize: 12, color: C.muted, marginTop: 2 }}>
            {connectedCount} of {SPANISH_BANK_REGISTRY.length} banks connected · Spain Official Registry
          </div>
        </div>
        <div style={{
          display: 'flex', alignItems: 'center', gap: 6, fontSize: 11,
          color: C.green, background: C.greenDim,
          border: `1px solid ${C.green}33`, borderRadius: 20, padding: '4px 10px',
        }}>
          <div style={{ width: 6, height: 6, borderRadius: '50%', background: C.green, boxShadow: `0 0 5px ${C.green}` }} />
          AGGREGATOR LIVE
        </div>
      </div>

      {/* Search */}
      <div style={{
        display: 'flex', alignItems: 'center', gap: 8,
        background: C.panel, border: `1px solid ${C.border}`,
        borderRadius: 8, padding: '8px 14px',
      }}>
        <Search size={14} color={C.muted} />
        <input
          value={query}
          onChange={e => setQuery(e.target.value)}
          placeholder="Search by bank name or code..."
          style={{ flex: 1, background: 'none', border: 'none', outline: 'none', color: C.text, fontSize: 13 }}
        />
        {query && (
          <button onClick={() => setQuery('')} style={{ background: 'none', border: 'none', cursor: 'pointer', color: C.muted, padding: 0 }}>
            <X size={13} />
          </button>
        )}
      </div>

      {/* Bank grid */}
      <div style={{
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fill, minmax(200px, 1fr))',
        gap: 10,
      }}>
        {filtered.map(bank => {
          const conn = connections[bank.id];
          const isConnected = conn?.status === 'connected';
          const isAuthorizing = conn?.status === 'authorizing';
          return (
            <div
              key={bank.id}
              style={{
                background: isConnected ? `${bank.logoColor}0D` : C.surface,
                border: `1px solid ${isConnected ? bank.logoColor + '55' : C.border}`,
                borderRadius: 10,
                padding: '14px 16px',
                display: 'flex', flexDirection: 'column', gap: 10,
                transition: 'border-color 0.15s, background 0.15s',
                position: 'relative', overflow: 'hidden',
              }}
            >
              {/* Connected glow accent */}
              {isConnected && (
                <div style={{
                  position: 'absolute', top: 0, left: 0, right: 0,
                  height: 2, background: bank.logoColor,
                  boxShadow: `0 0 8px ${bank.logoColor}`,
                }} />
              )}

              {/* Bank identity */}
              <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                <div style={{
                  width: 36, height: 36, borderRadius: 9, flexShrink: 0,
                  background: bank.logoColor + '1A',
                  border: `1.5px solid ${bank.logoColor}44`,
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  fontSize: 11, fontWeight: 800, color: bank.logoColor, letterSpacing: '-0.02em',
                }}>
                  {bank.name.split(' ').map(w => w[0]).join('').slice(0, 2).toUpperCase()}
                </div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{
                    fontSize: 13, fontWeight: 700,
                    color: isConnected ? bank.logoColor : C.text,
                    overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap',
                  }}>
                    {bank.name}
                  </div>
                  <div style={{ fontSize: 10, color: C.muted, fontFamily: 'monospace', marginTop: 1 }}>
                    CODE {bank.code}
                  </div>
                </div>
              </div>

              {/* Status + action */}
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 8 }}>
                {isConnected ? (
                  <div style={{ display: 'flex', alignItems: 'center', gap: 5, fontSize: 11, color: C.green }}>
                    <div style={{ width: 6, height: 6, borderRadius: '50%', background: C.green, boxShadow: `0 0 5px ${C.green}` }} />
                    Connected
                  </div>
                ) : (
                  <div style={{ fontSize: 11, color: C.muted }}>PSD2 ready</div>
                )}
                {isConnected ? (
                  <button
                    onClick={() => onDisconnect(bank.id)}
                    style={{
                      fontSize: 11, fontWeight: 600, padding: '4px 10px',
                      background: C.redDim, border: `1px solid ${C.red}33`,
                      borderRadius: 6, color: C.red, cursor: 'pointer',
                    }}
                  >
                    Disconnect
                  </button>
                ) : (
                  <button
                    onClick={() => onConnect(bank)}
                    disabled={isAuthorizing}
                    style={{
                      fontSize: 11, fontWeight: 700, padding: '4px 10px',
                      background: isAuthorizing ? C.amberDim : bank.logoColor + '1A',
                      border: `1px solid ${isAuthorizing ? C.amber + '44' : bank.logoColor + '55'}`,
                      borderRadius: 6,
                      color: isAuthorizing ? C.amber : bank.logoColor,
                      cursor: isAuthorizing ? 'not-allowed' : 'pointer',
                    }}
                  >
                    {isAuthorizing ? 'Connecting...' : 'Connect'}
                  </button>
                )}
              </div>

              {isConnected && conn.connectedAt && (
                <div style={{ fontSize: 10, color: C.muted, borderTop: `1px solid rgba(255,255,255,0.05)`, paddingTop: 8 }}>
                  Linked {new Date(conn.connectedAt).toLocaleDateString('es-ES')}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}

// ── Energy Guard Tab ─────────────────────────────────────────────────────────
function EnergyGuardTab({ userId }: { userId?: string }) {
  const [battery, setBattery]         = useState<{ level: number; charging: boolean } | null>(null);
  const [apcCredits, setApcCredits]   = useState<number>(() => loadState('apcCredits', 0));
  const [activated, setActivated]     = useState<boolean>(() => loadState('energyGuardActive', false));
  const [gdprOpen, setGdprOpen]       = useState(false);
  const [gdprChecked, setGdprChecked] = useState(false);
  const [consentTs, setConsentTs]     = useState<string | null>(() => loadState('energyGuardConsentTs', null));
  const [paywallStep, setPaywallStep] = useState<'idle' | 'pending' | 'done'>('idle');
  const [thermalAbort, setThermalAbort] = useState(false);
  const earnIntervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  // Battery Status API
  useEffect(() => {
    let batt: any = null;
    const updateBattery = (b: any) => {
      const level = Math.round(b.level * 100) / 100;
      const charging = b.charging;
      setBattery({ level, charging });

      // Thermal circuit-breaker: if charging AND level === 1.00 AND activated, earn APC
      if (charging && level >= 1.0 && activated && !thermalAbort) {
        if (!earnIntervalRef.current) {
          earnIntervalRef.current = setInterval(() => {
            setApcCredits(prev => {
              const next = +(prev + 0.01).toFixed(2);
              saveState({ apcCredits: next });
              return next;
            });
          }, 6000);
        }
      } else {
        if (earnIntervalRef.current) {
          clearInterval(earnIntervalRef.current);
          earnIntervalRef.current = null;
        }
      }

      // Discharge protocol: < 15% and not charging — freeze heavy loops
      if (!charging && level < 0.15) {
        setThermalAbort(true);
        if (earnIntervalRef.current) {
          clearInterval(earnIntervalRef.current);
          earnIntervalRef.current = null;
        }
        saveState({ energyGuardDischargeTs: new Date().toISOString() });
      } else if (charging) {
        setThermalAbort(false);
      }
    };

    if (typeof navigator !== 'undefined' && 'getBattery' in navigator) {
      (navigator as any).getBattery().then((b: any) => {
        batt = b;
        updateBattery(b);
        b.addEventListener('chargingchange', () => updateBattery(b));
        b.addEventListener('levelchange', () => updateBattery(b));
      }).catch(() => {});
    }

    return () => {
      if (earnIntervalRef.current) clearInterval(earnIntervalRef.current);
      if (batt) {
        batt.removeEventListener('chargingchange', () => {});
        batt.removeEventListener('levelchange', () => {});
      }
    };
  }, [activated, thermalAbort]);

  // Persist activation on change
  useEffect(() => {
    saveState({ energyGuardActive: activated });
  }, [activated]);

  const handleGdprConfirm = () => {
    if (!gdprChecked) return;
    const ts = new Date().toISOString();
    setConsentTs(ts);
    saveState({ energyGuardConsentTs: ts, energyGuardGdprAccepted: true });
    setGdprOpen(false);
    setPaywallStep('pending');
  };

  const handleActivate = () => {
    setActivated(true);
    setPaywallStep('done');
    saveState({ energyGuardActive: true, energyGuardActivatedTs: new Date().toISOString() });
  };

  const battPct = battery ? Math.round(battery.level * 100) : null;
  const isCharging = battery?.charging ?? false;
  const isFullCharge = battery !== null && battery.level >= 1.0 && isCharging;
  const isLow = battery !== null && battery.level < 0.15 && !isCharging;

  const statusColor = isLow ? '#FF3B30' : isCharging ? '#34C759' : '#FF9500';
  const statusLabel = isLow ? 'CRITICAL — DISCHARGE PROTOCOL ACTIVE'
    : isFullCharge ? 'CLOUD-BATTERY HARVEST ACTIVE'
    : isCharging ? 'CHARGING'
    : battery ? 'DISCHARGING'
    : 'BATTERY API UNAVAILABLE';

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>

      {/* GDPR consent modal */}
      {gdprOpen && (
        <div style={{
          position: 'fixed', inset: 0, zIndex: 9999,
          background: 'rgba(0,0,0,0.85)', backdropFilter: 'blur(8px)',
          display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 24,
        }}>
          <div style={{
            background: 'rgba(15,21,32,0.97)', border: '1px solid rgba(175,82,222,0.45)',
            borderRadius: 16, padding: '28px 28px 24px', maxWidth: 520, width: '100%',
          }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 18 }}>
              <Shield size={22} color="#AF52DE" />
              <span style={{ fontSize: 16, fontWeight: 800, color: '#fff' }}>
                AIPPIE Distributed Compute &amp; Energy-Guard Legal Covenant
              </span>
            </div>
            <div style={{
              fontSize: 13, lineHeight: 1.7, color: '#94a3b8',
              background: 'rgba(175,82,222,0.06)', border: '1px solid rgba(175,82,222,0.2)',
              borderRadius: 10, padding: '14px 16px', marginBottom: 20,
            }}>
              By activating this utility, the user explicitly grants AIPPIE S.A. permission to
              dynamically govern local background processing cycles and synchronize computational
              energy states via our secure cloud matrix in strict accordance with EU GDPR mandates.
            </div>
            <label style={{ display: 'flex', alignItems: 'flex-start', gap: 12, cursor: 'pointer', marginBottom: 22 }}>
              <div
                onClick={() => setGdprChecked(c => !c)}
                style={{
                  width: 20, height: 20, borderRadius: 5, flexShrink: 0, marginTop: 1,
                  border: `2px solid ${gdprChecked ? '#AF52DE' : 'rgba(255,255,255,0.2)'}`,
                  background: gdprChecked ? '#AF52DE' : 'transparent',
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  transition: 'all 0.15s', cursor: 'pointer',
                }}
              >
                {gdprChecked && <Check size={13} color="#fff" />}
              </div>
              <span style={{ fontSize: 13, color: '#cbd5e1', lineHeight: 1.5 }}>
                I have read and explicitly consent to the above legal covenant in accordance with
                GDPR Article 6(1)(a) — Consent as lawful basis for processing.
              </span>
            </label>
            <div style={{ display: 'flex', gap: 10 }}>
              <button
                onClick={() => { setGdprOpen(false); setGdprChecked(false); }}
                style={{
                  flex: 1, padding: '11px 0', borderRadius: 9, cursor: 'pointer',
                  background: 'transparent', border: '1px solid rgba(255,255,255,0.1)',
                  color: '#94a3b8', fontSize: 13, fontWeight: 600,
                }}
              >Cancel</button>
              <button
                onClick={handleGdprConfirm}
                disabled={!gdprChecked}
                style={{
                  flex: 2, padding: '11px 0', borderRadius: 9, cursor: gdprChecked ? 'pointer' : 'not-allowed',
                  background: gdprChecked ? 'linear-gradient(135deg,#AF52DE,#8B5CF6)' : 'rgba(255,255,255,0.05)',
                  border: 'none', color: gdprChecked ? '#fff' : '#475569',
                  fontSize: 13, fontWeight: 700, transition: 'all 0.2s',
                }}
              >Confirm &amp; Proceed to Payment</button>
            </div>
            {consentTs && (
              <div style={{ fontSize: 11, color: '#475569', marginTop: 12, textAlign: 'center' }}>
                Previous consent recorded: {new Date(consentTs).toLocaleString('es-ES')}
              </div>
            )}
          </div>
        </div>
      )}

      {/* Battery status card */}
      <Card>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 16 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <BatteryCharging size={20} color={statusColor} />
            <span style={{ fontSize: 15, fontWeight: 700, color: C.text }}>Device Power Matrix</span>
          </div>
          <div style={{
            fontSize: 11, fontWeight: 700, color: statusColor,
            background: `${statusColor}18`, border: `1px solid ${statusColor}44`,
            borderRadius: 20, padding: '3px 10px', letterSpacing: '0.04em',
          }}>{statusLabel}</div>
        </div>

        {battery === null ? (
          <div style={{ fontSize: 13, color: C.muted, textAlign: 'center', padding: '16px 0' }}>
            Battery Status API not available in this browser.
          </div>
        ) : (
          <div>
            {/* Progress bar */}
            <div style={{ marginBottom: 14 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 6 }}>
                <span style={{ fontSize: 12, color: C.muted }}>Battery Level</span>
                <span style={{ fontSize: 13, fontWeight: 700, color: statusColor }}>{battPct}%</span>
              </div>
              <div style={{ height: 8, background: 'rgba(255,255,255,0.06)', borderRadius: 4, overflow: 'hidden' }}>
                <div style={{
                  height: '100%', borderRadius: 4, transition: 'width 0.6s ease',
                  width: `${battPct}%`,
                  background: `linear-gradient(90deg, ${statusColor}, ${statusColor}99)`,
                  boxShadow: `0 0 8px ${statusColor}66`,
                }} />
              </div>
            </div>

            {/* APC credits */}
            <div style={{
              display: 'flex', alignItems: 'center', justifyContent: 'space-between',
              padding: '12px 16px', borderRadius: 10,
              background: 'rgba(52,199,89,0.07)', border: '1px solid rgba(52,199,89,0.2)',
            }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                <CloudLightning size={16} color="#34C759" />
                <span style={{ fontSize: 13, color: C.text }}>AIPPIE Power Credits (APC)</span>
              </div>
              <span style={{ fontSize: 18, fontWeight: 800, color: '#34C759', fontVariantNumeric: 'tabular-nums' }}>
                {apcCredits.toFixed(2)} APC
              </span>
            </div>

            {isLow && (
              <div style={{
                marginTop: 12, padding: '12px 16px', borderRadius: 10,
                background: 'rgba(255,59,48,0.08)', border: '1px solid rgba(255,59,48,0.3)',
                fontSize: 13, color: '#FF3B30', fontWeight: 600, lineHeight: 1.5,
              }}>
                Cloud-Battery Discharge Protocol ACTIVE: Heavy compute loops frozen. Serving
                accounting logs from pre-processed cloud cache. Connect charger to resume harvest.
              </div>
            )}
            {isFullCharge && activated && (
              <div style={{
                marginTop: 12, padding: '12px 16px', borderRadius: 10,
                background: 'rgba(52,199,89,0.08)', border: '1px solid rgba(52,199,89,0.3)',
                fontSize: 13, color: '#34C759', fontWeight: 600, lineHeight: 1.5,
              }}>
                Surplus compute allocated. Background data aggregations running. APC credits
                accumulating at 0.01 APC / 6s.
              </div>
            )}
          </div>
        )}
      </Card>

      {/* Activation panel */}
      <Card>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 16 }}>
          <Zap size={20} color="#FF9500" />
          <span style={{ fontSize: 15, fontWeight: 700, color: C.text }}>
            AIPPIE Active Energy-Guard Activation Suite
          </span>
        </div>

        {!activated ? (
          <div>
            <div style={{ fontSize: 13, color: C.muted, lineHeight: 1.7, marginBottom: 18 }}>
              Activate Cloud-Battery Standby Protection to enable intelligent power-cycle
              synchronization, APC credit harvesting when fully charged, and automatic
              low-battery discharge safeguards.
            </div>

            {/* Feature list */}
            {[
              'APC harvest when battery fully charged (100%)',
              'Automatic compute freeze below 15% battery',
              'Pre-processed cloud cache failover',
              'GDPR-compliant energy state telemetry',
            ].map(f => (
              <div key={f} style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8 }}>
                <Check size={14} color="#34C759" />
                <span style={{ fontSize: 13, color: C.text }}>{f}</span>
              </div>
            ))}

            {paywallStep === 'idle' && (
              <button
                onClick={() => setGdprOpen(true)}
                style={{
                  marginTop: 18, width: '100%', padding: '13px 0', borderRadius: 10, cursor: 'pointer',
                  background: 'linear-gradient(135deg,#FF9500,#FF6B00)',
                  border: 'none', color: '#fff', fontSize: 14, fontWeight: 700,
                  display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
                }}
              >
                <Euro size={16} />
                Activate for €1.00 / Month
              </button>
            )}

            {paywallStep === 'pending' && (
              <div style={{ marginTop: 18 }}>
                <div style={{
                  padding: '16px 20px', borderRadius: 12,
                  background: 'rgba(0,122,255,0.08)', border: '1px solid rgba(0,122,255,0.3)',
                  marginBottom: 14,
                }}>
                  <div style={{ fontSize: 14, fontWeight: 700, color: C.blue, marginBottom: 8 }}>
                    PayPal Secure Checkout
                  </div>
                  <div style={{ fontSize: 12, color: C.muted, marginBottom: 12, lineHeight: 1.6 }}>
                    AIPPIE Energy-Guard Subscription · €1.00 / month · Cancel anytime
                  </div>
                  <div style={{ fontSize: 11, color: '#475569', marginBottom: 14 }}>
                    GDPR consent recorded · {consentTs ? new Date(consentTs).toLocaleString('es-ES') : ''}
                  </div>
                  <button
                    onClick={handleActivate}
                    style={{
                      width: '100%', padding: '12px 0', borderRadius: 9, cursor: 'pointer',
                      background: 'linear-gradient(135deg,#003087,#009cde)',
                      border: 'none', color: '#fff', fontSize: 14, fontWeight: 700,
                      display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
                    }}
                  >
                    <Euro size={15} />
                    Pay €1.00 with PayPal
                  </button>
                  <div style={{ fontSize: 11, color: '#475569', marginTop: 8, textAlign: 'center' }}>
                    Secured by PayPal · 128-bit SSL encryption
                  </div>
                </div>
              </div>
            )}
          </div>
        ) : (
          <div>
            <div style={{
              display: 'flex', alignItems: 'center', gap: 10, marginBottom: 12,
              padding: '12px 16px', borderRadius: 10,
              background: 'rgba(52,199,89,0.08)', border: '1px solid rgba(52,199,89,0.3)',
            }}>
              <CheckCircle2 size={18} color="#34C759" />
              <span style={{ fontSize: 14, fontWeight: 700, color: '#34C759' }}>
                Energy-Guard ACTIVE — €1.00/month subscription running
              </span>
            </div>
            <div style={{ fontSize: 12, color: C.muted, lineHeight: 1.6 }}>
              Consent timestamp: {consentTs ? new Date(consentTs).toLocaleString('es-ES') : 'unknown'}<br />
              APC earned this session: <span style={{ color: '#34C759', fontWeight: 700 }}>{apcCredits.toFixed(2)} APC</span>
            </div>
            <button
              onClick={() => {
                setActivated(false);
                saveState({ energyGuardActive: false });
                if (earnIntervalRef.current) { clearInterval(earnIntervalRef.current); earnIntervalRef.current = null; }
              }}
              style={{
                marginTop: 14, padding: '9px 20px', borderRadius: 8, cursor: 'pointer',
                background: 'transparent', border: '1px solid rgba(255,59,48,0.3)',
                color: '#FF3B30', fontSize: 12, fontWeight: 600,
              }}
            >Cancel Subscription</button>
          </div>
        )}
      </Card>

      {/* Legal footer */}
      <div style={{ fontSize: 11, color: '#334155', lineHeight: 1.6, textAlign: 'center', padding: '0 8px' }}>
        AIPPIE S.A. · EU GDPR compliant · Data processed under Art. 6(1)(a) consent lawful basis ·
        Subscription managed via PayPal · Cancel anytime via account settings.
      </div>
    </div>
  );
}

// ── Tab definitions ───────────────────────────────────────────────────────────
const TABS = [
  { id: 'ai-account',    label: 'AI Account',        icon: MessageCircle,  color: '#A855F7' },
  { id: 'invoices',      label: 'Verifactu Invoices', icon: FileText,       color: C.blue  },
  { id: 'chain',         label: 'Hash Chain Ledger',  icon: Lock,           color: C.green },
  { id: 'transactions',  label: 'Qonto Bank Feed',    icon: CreditCard,     color: C.amber },
  { id: 'extract',       label: 'PDF Extractor',      icon: Upload,         color: C.blue  },
  { id: 'energy-guard',  label: 'Energy Guard',       icon: BatteryCharging, color: '#34C759' },
] as const;
type TabId = typeof TABS[number]['id'];

// ── Helpers ──────────────────────────────────────────────────────────────────
function fmt(n: number | null | undefined, digits = 2) {
  if (n == null) return '—';
  return n.toLocaleString('es-ES', { minimumFractionDigits: digits, maximumFractionDigits: digits });
}
function fmtDate(s: string | null | undefined) {
  if (!s) return '—';
  return new Date(s).toLocaleDateString('es-ES');
}
function fmtTime(s: string | null | undefined) {
  if (!s) return '';
  return new Date(s).toLocaleTimeString('es-ES', { hour: '2-digit', minute: '2-digit' });
}
function statusColor(s: string) {
  if (s === 'accepted') return C.green;
  if (s === 'submitted') return C.blue;
  if (s === 'rejected') return C.red;
  return C.amber;
}

// ── Pill badge ────────────────────────────────────────────────────────────────
function Pill({ label, color }: { label: string; color: string }) {
  return (
    <span style={{
      fontSize: 11, fontWeight: 700, padding: '2px 8px', borderRadius: 20,
      background: color + '1A', border: `1px solid ${color}44`, color,
      letterSpacing: '0.04em', textTransform: 'uppercase',
    }}>{label}</span>
  );
}

// ── Section card wrapper ──────────────────────────────────────────────────────
function Card({ children, style }: { children: React.ReactNode; style?: React.CSSProperties }) {
  return (
    <div style={{
      background: 'rgba(15,21,32,0.72)', backdropFilter: 'blur(14px)',
      border: `1px solid ${C.border}`,
      borderRadius: 12, padding: '20px 24px', ...style,
    }}>
      {children}
    </div>
  );
}

// ── Empty state ────────────────────────────────────────────────────────────────
function Empty({ label }: { label: string }) {
  return (
    <div style={{ textAlign: 'center', padding: '48px 0', color: C.muted, fontSize: 14 }}>
      <div style={{ fontSize: 32, marginBottom: 8, opacity: 0.3 }}>◯</div>
      {label}
    </div>
  );
}

// ── Avatar circle ────────────────────────────────────────────────────────────
function Avatar({ name, size = 36, color = '#60A5FA' }: { name: string; size?: number; color?: string }) {
  const initials = name.split(' ').map(w => w[0]).join('').slice(0, 2).toUpperCase();
  return (
    <div style={{
      width: size, height: size, borderRadius: '50%', flexShrink: 0,
      background: color + '22', border: `1.5px solid ${color}55`,
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      fontSize: size * 0.38, fontWeight: 700, color,
    }}>{initials || <User size={size * 0.5} />}</div>
  );
}

// ── Online dot ───────────────────────────────────────────────────────────────
function OnlineDot({ online }: { online: boolean }) {
  return (
    <div style={{
      width: 8, height: 8, borderRadius: '50%',
      background: online ? C.green : C.dim,
      boxShadow: online ? `0 0 5px ${C.green}` : 'none',
      flexShrink: 0,
    }} />
  );
}

// ── WebRTC Call Overlay ───────────────────────────────────────────────────────
interface CallState {
  active: boolean;
  mode: 'audio' | 'video';
  contactName: string;
  duration: number;
  micOn: boolean;
  camOn: boolean;
  status: 'calling' | 'connected' | 'ended';
}

function CallOverlay({ call, onMicToggle, onCamToggle, onHangup }: {
  call: CallState;
  onMicToggle: () => void;
  onCamToggle: () => void;
  onHangup: () => void;
}) {
  const localVideoRef = useRef<HTMLVideoElement>(null);
  const [elapsed, setElapsed] = useState(call.duration);

  useEffect(() => {
    if (call.status !== 'connected') return;
    const t = setInterval(() => setElapsed(s => s + 1), 1000);
    return () => clearInterval(t);
  }, [call.status]);

  // Request camera/mic when video call goes connected
  useEffect(() => {
    if (call.mode !== 'video' || call.status !== 'connected' || !call.camOn) return;
    let stream: MediaStream | null = null;
    navigator.mediaDevices?.getUserMedia({ video: true, audio: false }).then(s => {
      stream = s;
      if (localVideoRef.current) localVideoRef.current.srcObject = s;
    }).catch(() => {/* permissions denied — silently ignore */});
    return () => { stream?.getTracks().forEach(t => t.stop()); };
  }, [call.mode, call.status, call.camOn]);

  const mins = String(Math.floor(elapsed / 60)).padStart(2, '0');
  const secs = String(elapsed % 60).padStart(2, '0');

  return (
    <div style={{
      position: 'absolute', inset: 0, zIndex: 50,
      background: 'rgba(7,11,20,0.97)',
      backdropFilter: 'blur(16px)',
      display: 'flex', flexDirection: 'column',
      alignItems: 'center', justifyContent: 'center',
      gap: 20,
    }}>
      {/* Remote video / avatar */}
      {call.mode === 'video' ? (
        <div style={{
          width: 200, height: 200, borderRadius: '50%',
          background: '#1e293b',
          border: `3px solid ${call.status === 'connected' ? '#A855F7' : C.muted}`,
          boxShadow: call.status === 'connected' ? '0 0 32px #A855F744' : 'none',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          overflow: 'hidden', flexShrink: 0,
        }}>
          <Avatar name={call.contactName} size={120} color="#A855F7" />
        </div>
      ) : (
        <div style={{
          width: 100, height: 100, borderRadius: '50%',
          border: `3px solid ${call.status === 'connected' ? '#A855F7' : C.muted}`,
          boxShadow: call.status === 'connected' ? '0 0 24px #A855F744' : 'none',
          animation: call.status === 'calling' ? 'cap-pulse 1.4s ease-in-out infinite' : 'none',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
        }}>
          <Avatar name={call.contactName} size={90} color="#A855F7" />
        </div>
      )}

      <div style={{ textAlign: 'center' }}>
        <div style={{ fontSize: 22, fontWeight: 800, color: C.text, marginBottom: 6 }}>
          {call.contactName}
        </div>
        <div style={{ fontSize: 13, color: call.status === 'connected' ? '#A855F7' : C.muted }}>
          {call.status === 'calling' ? 'Calling...' : call.status === 'ended' ? 'Call ended' : `${mins}:${secs}`}
        </div>
      </div>

      {/* Local video preview (video call only) */}
      {call.mode === 'video' && call.camOn && (
        <video
          ref={localVideoRef}
          autoPlay muted playsInline
          style={{
            width: 96, height: 72, borderRadius: 8,
            background: '#111', objectFit: 'cover',
            border: `1px solid ${C.border}`,
          }}
        />
      )}

      {/* Controls */}
      <div style={{ display: 'flex', gap: 20, marginTop: 8 }}>
        <button
          onClick={onMicToggle}
          style={{
            width: 52, height: 52, borderRadius: '50%', cursor: 'pointer', border: 'none',
            background: call.micOn ? 'rgba(168,85,247,0.18)' : C.redDim,
            color: call.micOn ? '#A855F7' : C.red,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            transition: 'all 0.15s',
          }}
          title={call.micOn ? 'Mute' : 'Unmute'}
        >
          {call.micOn ? <Mic size={22} /> : <MicOff size={22} />}
        </button>
        {call.mode === 'video' && (
          <button
            onClick={onCamToggle}
            style={{
              width: 52, height: 52, borderRadius: '50%', cursor: 'pointer', border: 'none',
              background: call.camOn ? 'rgba(168,85,247,0.18)' : C.redDim,
              color: call.camOn ? '#A855F7' : C.red,
              display: 'flex', alignItems: 'center', justifyContent: 'center',
            }}
            title={call.camOn ? 'Disable camera' : 'Enable camera'}
          >
            {call.camOn ? <Video size={22} /> : <VideoOff size={22} />}
          </button>
        )}
        <button
          onClick={onHangup}
          style={{
            width: 52, height: 52, borderRadius: '50%', cursor: 'pointer', border: 'none',
            background: C.red, color: '#fff',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            boxShadow: `0 0 16px ${C.red}66`,
          }}
          title="Hang up"
        >
          <PhoneOff size={22} />
        </button>
      </div>
    </div>
  );
}

// ── AI Account Tab — WhatsApp-like Inbox + Chat ───────────────────────────────
interface Message {
  id: string;
  from_number: string;
  from_name?: string;
  message_text: string;
  direction: 'inbound' | 'outbound';
  received_at: string;
  is_read: boolean;
}

interface Conversation {
  contact: string;           // phone / identifier
  name: string;
  lastMessage: string;
  lastAt: string;
  unread: number;
  online: boolean;
}

const NULL_CALL: CallState = {
  active: false, mode: 'audio', contactName: '', duration: 0,
  micOn: true, camOn: true, status: 'calling',
};

function AIAccountTab({ userId }: { userId: string }) {
  const [messages, setMessages]         = useState<Message[]>(() => loadState('messages', []));
  const [conversations, setConversations] = useState<Conversation[]>(() => loadState('conversations', []));
  const [activeConv, setActiveConv]     = useState<string | null>(() => loadState('activeConv', null));
  const [input, setInput]               = useState<string>(() => loadState('chatInput', ''));
  const [sending, setSending]           = useState(false);
  const [loading, setLoading]           = useState(true);
  const [call, setCall]                 = useState<CallState>(() => {
    const s = loadState<CallState>('callState', NULL_CALL);
    // Never restore a live call after page reload — mark ended
    return s.active ? { ...s, active: false, status: 'ended' } : s;
  });

  const [bankConnections, setBankConnections] = useState<Record<string, BankConnection>>(() =>
    loadState('bankConnections', {})
  );
  const [psd2Modal, setPsd2Modal] = useState<{ bank: typeof SPANISH_BANK_REGISTRY[number] } | null>(null);
  const [activeSection, setActiveSection] = useState<'chat' | 'banking' | 'tax-hub'>(() =>
    loadState('aiAccountSection', 'chat')
  );

  const messagesEndRef = useRef<HTMLDivElement>(null);

  // ── Load messages from Supabase ───────────────────────────────────────────
  const loadMessages = useCallback(async () => {
    setLoading(true);
    const { data } = await supabase
      .from('whatsapp_messages')
      .select('*')
      .order('received_at', { ascending: true })
      .limit(500);
    const rows: Message[] = data ?? [];
    setMessages(rows);
    saveState({ messages: rows });

    // Build conversation list from messages
    const map = new Map<string, Conversation>();
    for (const m of rows) {
      const contact = m.direction === 'inbound' ? m.from_number : (m.from_number || 'me');
      const name = m.from_name || contact;
      const existing = map.get(contact);
      if (!existing || new Date(m.received_at) > new Date(existing.lastAt)) {
        map.set(contact, {
          contact,
          name,
          lastMessage: m.message_text ?? '',
          lastAt: m.received_at,
          unread: existing ? existing.unread + (m.is_read ? 0 : 1) : (m.is_read ? 0 : 1),
          online: Math.random() > 0.5,
        });
      }
    }
    // Add a demo AI contact if no real messages exist
    if (map.size === 0) {
      const demoConvs: Conversation[] = [
        { contact: 'aippie-ai', name: 'Aippie AI Assistant', lastMessage: 'Hello! How can I help you today?', lastAt: new Date().toISOString(), unread: 1, online: true },
        { contact: 'support-aippietax', name: 'AIPPIETAX Support', lastMessage: 'Your account is fully activated.', lastAt: new Date(Date.now() - 3600000).toISOString(), unread: 0, online: true },
        { contact: 'trading-signals', name: 'Trading Signals Bot', lastMessage: 'EUR/USD bullish pattern detected.', lastAt: new Date(Date.now() - 7200000).toISOString(), unread: 2, online: false },
      ];
      setConversations(demoConvs);
      saveState({ conversations: demoConvs });
    } else {
      const convs = Array.from(map.values()).sort((a, b) => new Date(b.lastAt).getTime() - new Date(a.lastAt).getTime());
      setConversations(convs);
      saveState({ conversations: convs });
    }
    setLoading(false);
  }, []);

  useEffect(() => { loadMessages(); }, [loadMessages]);

  // ── Realtime subscription ──────────────────────────────────────────────────
  useEffect(() => {
    const channel = supabase
      .channel('wa-messages-live')
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'whatsapp_messages' }, payload => {
        setMessages(prev => {
          const updated = [...prev, payload.new as Message];
          saveState({ messages: updated });
          return updated;
        });
      })
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  }, []);

  // ── Scroll to bottom on new messages ──────────────────────────────────────
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, activeConv]);

  // ── Persist input as user types ───────────────────────────────────────────
  const handleInputChange = (v: string) => {
    setInput(v);
    saveState({ chatInput: v });
  };

  // ── Persist active conversation ───────────────────────────────────────────
  const openConv = (contact: string) => {
    setActiveConv(contact);
    saveState({ activeConv: contact });
    // Mark unread = 0 optimistically
    setConversations(prev => prev.map(c => c.contact === contact ? { ...c, unread: 0 } : c));
  };

  // ── Send message ──────────────────────────────────────────────────────────
  const sendMessage = async () => {
    if (!input.trim() || !activeConv) return;
    setSending(true);
    const text = input.trim();
    handleInputChange('');

    // Optimistic UI
    const optimistic: Message = {
      id: crypto.randomUUID(),
      from_number: userId,
      from_name: 'Me',
      message_text: text,
      direction: 'outbound',
      received_at: new Date().toISOString(),
      is_read: true,
    };
    setMessages(prev => {
      const u = [...prev, optimistic];
      saveState({ messages: u });
      return u;
    });

    // Persist to Supabase
    await supabase.from('whatsapp_messages').insert({
      from_number: userId,
      from_name: 'Me',
      to_number: activeConv,
      message_text: text,
      direction: 'outbound',
      is_read: true,
    });

    // Auto-reply from demo contacts
    if (['aippie-ai', 'support-aippietax', 'trading-signals'].includes(activeConv)) {
      const replies: Record<string, string> = {
        'aippie-ai': 'I received your message. Processing with AI intelligence now...',
        'support-aippietax': 'Thank you. A support agent will review your query shortly.',
        'trading-signals': 'Signal acknowledged. Scanning live market data...',
      };
      setTimeout(() => {
        const reply: Message = {
          id: crypto.randomUUID(),
          from_number: activeConv,
          from_name: conversations.find(c => c.contact === activeConv)?.name ?? activeConv,
          message_text: replies[activeConv] ?? 'Message received.',
          direction: 'inbound',
          received_at: new Date().toISOString(),
          is_read: false,
        };
        setMessages(prev => {
          const u = [...prev, reply];
          saveState({ messages: u });
          return u;
        });
      }, 1200);
    }

    setSending(false);
  };

  // ── Call controls ──────────────────────────────────────────────────────────
  const startCall = (mode: 'audio' | 'video') => {
    if (!activeConv) return;
    const contactName = conversations.find(c => c.contact === activeConv)?.name ?? activeConv;
    const newCall: CallState = {
      active: true, mode, contactName, duration: 0,
      micOn: true, camOn: true, status: 'calling',
    };
    setCall(newCall);
    saveState({ callState: newCall });
    // Simulate connection after 2s
    setTimeout(() => {
      setCall(prev => {
        const updated = { ...prev, status: 'connected' as const };
        saveState({ callState: updated });
        return updated;
      });
    }, 2000);
  };

  const toggleMic = () => setCall(prev => {
    const updated = { ...prev, micOn: !prev.micOn };
    saveState({ callState: updated });
    return updated;
  });

  const toggleCam = () => setCall(prev => {
    const updated = { ...prev, camOn: !prev.camOn };
    saveState({ callState: updated });
    return updated;
  });

  const hangup = () => {
    setCall(prev => {
      const updated = { ...prev, active: false, status: 'ended' as const };
      saveState({ callState: updated });
      return updated;
    });
  };

  // ── Banking handlers ──────────────────────────────────────────────────────
  const openPsd2Modal = (bank: typeof SPANISH_BANK_REGISTRY[number]) => {
    // Mark as authorizing immediately
    const updated = {
      ...bankConnections,
      [bank.id]: { bankId: bank.id as BankId, status: 'authorizing' as BankConnectionStatus },
    };
    setBankConnections(updated);
    saveState({ bankConnections: updated });
    setPsd2Modal({ bank });
  };

  const confirmBankConnection = (bankId: string, _iban: string, _pin: string) => {
    const connectedAt = new Date().toISOString();
    const consentId = Math.random().toString(36).slice(2, 18).toUpperCase();
    const updated = {
      ...bankConnections,
      [bankId]: { bankId: bankId as BankId, status: 'connected' as BankConnectionStatus, connectedAt, consentId },
    };
    setBankConnections(updated);
    saveState({ bankConnections: updated });
  };

  const disconnectBank = (bankId: string) => {
    const updated = { ...bankConnections };
    delete updated[bankId];
    setBankConnections(updated);
    saveState({ bankConnections: updated });
  };

  const switchSection = (s: 'chat' | 'banking' | 'tax-hub') => {
    setActiveSection(s);
    saveState({ aiAccountSection: s });
  };

  // ── Filter messages for active conversation ───────────────────────────────
  const convMessages = activeConv
    ? messages.filter(m =>
        m.from_number === activeConv ||
        (m.direction === 'outbound' && activeConv === 'aippie-ai') ||
        (m.direction === 'outbound' && activeConv === 'support-aippietax') ||
        (m.direction === 'outbound' && activeConv === 'trading-signals')
      )
    : [];

  const activeContact = conversations.find(c => c.contact === activeConv);
  const connectedBankCount = Object.values(bankConnections).filter(c => c.status === 'connected').length;

  return (
    <>
      {/* PSD2 modal (portal-style, on top of everything) */}
      {psd2Modal && (
        <PSD2Modal
          bank={psd2Modal.bank}
          status={bankConnections[psd2Modal.bank.id]?.status ?? 'idle'}
          onConfirm={(iban, pin) => {
            confirmBankConnection(psd2Modal.bank.id, iban, pin);
          }}
          onClose={() => setPsd2Modal(null)}
        />
      )}

      {/* Section toggle */}
      <div style={{ display: 'flex', gap: 4, marginBottom: 14 }}>
        {([
          { key: 'chat',    label: 'Messaging',                         icon: MessageCircle },
          { key: 'banking', label: `Banking (${connectedBankCount} linked)`, icon: CreditCard    },
          { key: 'tax-hub', label: 'Tax Hub',                           icon: FileText      },
        ] as const).map(({ key, label, icon: Icon }) => (
          <button
            key={key}
            onClick={() => switchSection(key)}
            style={{
              display: 'flex', alignItems: 'center', gap: 7,
              padding: '8px 16px',
              background: activeSection === key ? 'rgba(168,85,247,0.12)' : 'transparent',
              border: activeSection === key ? '1px solid rgba(168,85,247,0.45)' : `1px solid ${C.border}`,
              borderRadius: 8,
              color: activeSection === key ? '#A855F7' : C.muted,
              fontSize: 13, fontWeight: activeSection === key ? 700 : 500,
              cursor: 'pointer', transition: 'all 0.15s',
            }}
          >
            <Icon size={14} />
            {label}
          </button>
        ))}
      </div>

    {activeSection === 'tax-hub' ? (
      <LocalErrorBoundary>
        <Suspense fallback={
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', minHeight: '60vh' }}>
            <div style={{ width: 24, height: 24, borderRadius: '50%', border: `2px solid ${C.border}`, borderTopColor: C.blue, animation: 'cap-spin 0.9s linear infinite' }} />
          </div>
        }>
          <div style={{ position: 'relative', minHeight: '70vh', borderRadius: 12, overflow: 'hidden', border: `1px solid ${C.border}` }}>
            <AippieTaxView />
          </div>
        </Suspense>
      </LocalErrorBoundary>
    ) : activeSection === 'banking' ? (
      <BankSelectorPanel
        connections={bankConnections}
        onConnect={openPsd2Modal}
        onDisconnect={disconnectBank}
      />
    ) : (
    <div style={{ display: 'flex', height: '70vh', gap: 0, borderRadius: 12, overflow: 'hidden', border: `1px solid ${C.border}`, position: 'relative' }}>

      {/* ── Inbox / Conversation List ─────────────────────────────────────── */}
      <div style={{
        width: 280, flexShrink: 0,
        background: C.surface,
        borderRight: `1px solid ${C.border}`,
        display: 'flex', flexDirection: 'column',
        transition: 'transform 0.2s',
      }}>
        {/* Inbox header */}
        <div style={{
          padding: '14px 16px',
          borderBottom: `1px solid ${C.border}`,
          display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        }}>
          <div>
            <div style={{ fontSize: 14, fontWeight: 700, color: C.text }}>Messages</div>
            <div style={{ fontSize: 11, color: C.muted }}>AI Account Inbox</div>
          </div>
          <button
            onClick={loadMessages}
            style={{ background: 'none', border: 'none', cursor: 'pointer', color: C.muted, padding: 4 }}
            title="Refresh"
          >
            <RefreshCw size={14} />
          </button>
        </div>

        {/* Conversation list */}
        <div style={{ overflowY: 'auto', flex: 1 }}>
          {loading ? (
            <div style={{ padding: 24, textAlign: 'center', color: C.muted, fontSize: 13 }}>Loading...</div>
          ) : conversations.length === 0 ? (
            <div style={{ padding: 24, textAlign: 'center', color: C.muted, fontSize: 13 }}>No conversations yet.</div>
          ) : conversations.map(conv => (
            <button
              key={conv.contact}
              onClick={() => openConv(conv.contact)}
              style={{
                width: '100%', padding: '12px 14px',
                display: 'flex', gap: 10, alignItems: 'center',
                background: activeConv === conv.contact ? 'rgba(168,85,247,0.1)' : 'transparent',
                borderLeft: activeConv === conv.contact ? '3px solid #A855F7' : '3px solid transparent',
                border: 'none', cursor: 'pointer', textAlign: 'left',
                transition: 'background 0.12s',
                borderRight: 'none', borderTop: 'none',
                borderBottom: `1px solid rgba(255,255,255,0.04)`,
                boxSizing: 'border-box',
              }}
            >
              <div style={{ position: 'relative', flexShrink: 0 }}>
                <Avatar name={conv.name} size={38} color="#A855F7" />
                <div style={{ position: 'absolute', bottom: 1, right: 1 }}>
                  <OnlineDot online={conv.online} />
                </div>
              </div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 2 }}>
                  <div style={{ fontSize: 13, fontWeight: 600, color: activeConv === conv.contact ? '#A855F7' : C.text, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', maxWidth: 140 }}>
                    {conv.name}
                  </div>
                  <div style={{ fontSize: 10, color: C.muted, flexShrink: 0, marginLeft: 4 }}>
                    {fmtTime(conv.lastAt)}
                  </div>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <div style={{ fontSize: 12, color: C.muted, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', maxWidth: 145 }}>
                    {conv.lastMessage || '—'}
                  </div>
                  {conv.unread > 0 && (
                    <div style={{
                      minWidth: 18, height: 18, borderRadius: 9,
                      background: '#A855F7', color: '#fff',
                      fontSize: 10, fontWeight: 700,
                      display: 'flex', alignItems: 'center', justifyContent: 'center',
                      padding: '0 4px', flexShrink: 0, marginLeft: 4,
                    }}>
                      {conv.unread}
                    </div>
                  )}
                </div>
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* ── Chat Panel ───────────────────────────────────────────────────── */}
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', background: C.bg, position: 'relative', minWidth: 0 }}>

        {call.active && (
          <CallOverlay call={call} onMicToggle={toggleMic} onCamToggle={toggleCam} onHangup={hangup} />
        )}

        {activeConv && activeContact ? (
          <>
            {/* Chat header */}
            <div style={{
              padding: '12px 16px',
              borderBottom: `1px solid ${C.border}`,
              background: C.surface,
              display: 'flex', alignItems: 'center', gap: 12,
              flexShrink: 0,
            }}>
              <button
                onClick={() => { setActiveConv(null); saveState({ activeConv: null }); }}
                style={{ background: 'none', border: 'none', cursor: 'pointer', color: C.muted, display: 'flex', padding: 2 }}
                title="Back to inbox"
              >
                <ArrowLeft size={18} />
              </button>
              <Avatar name={activeContact.name} size={36} color="#A855F7" />
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 14, fontWeight: 700, color: C.text }}>{activeContact.name}</div>
                <div style={{ display: 'flex', alignItems: 'center', gap: 5, fontSize: 11, color: C.muted }}>
                  <OnlineDot online={activeContact.online} />
                  {activeContact.online ? 'Online' : 'Offline'}
                </div>
              </div>
              {/* Call buttons */}
              <button
                onClick={() => startCall('audio')}
                style={{
                  width: 36, height: 36, borderRadius: '50%', border: 'none', cursor: 'pointer',
                  background: 'rgba(16,185,129,0.12)', color: C.green,
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  transition: 'background 0.15s',
                }}
                title="Voice call"
              >
                <Phone size={16} />
              </button>
              <button
                onClick={() => startCall('video')}
                style={{
                  width: 36, height: 36, borderRadius: '50%', border: 'none', cursor: 'pointer',
                  background: 'rgba(168,85,247,0.12)', color: '#A855F7',
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  transition: 'background 0.15s',
                }}
                title="Video call"
              >
                <Video size={16} />
              </button>
            </div>

            {/* Messages list */}
            <div style={{ flex: 1, overflowY: 'auto', padding: '16px 20px', display: 'flex', flexDirection: 'column', gap: 8 }}>
              {convMessages.length === 0 ? (
                <div style={{ margin: 'auto', textAlign: 'center', color: C.muted, fontSize: 13 }}>
                  <MessageCircle size={28} style={{ opacity: 0.2, marginBottom: 8, display: 'block', margin: '0 auto 8px' }} />
                  Start the conversation
                </div>
              ) : convMessages.map(m => {
                const isMe = m.direction === 'outbound';
                return (
                  <div key={m.id} style={{ display: 'flex', justifyContent: isMe ? 'flex-end' : 'flex-start' }}>
                    <div style={{
                      maxWidth: '70%',
                      padding: '9px 13px',
                      borderRadius: isMe ? '16px 16px 4px 16px' : '16px 16px 16px 4px',
                      background: isMe ? '#A855F7' : C.surface,
                      border: isMe ? 'none' : `1px solid ${C.border}`,
                      color: isMe ? '#fff' : C.text,
                      fontSize: 13,
                      lineHeight: 1.5,
                      wordBreak: 'break-word',
                    }}>
                      <div>{m.message_text}</div>
                      <div style={{ fontSize: 10, opacity: 0.6, marginTop: 4, textAlign: 'right' }}>
                        {fmtTime(m.received_at)}
                        {isMe && <span style={{ marginLeft: 4 }}>✓✓</span>}
                      </div>
                    </div>
                  </div>
                );
              })}
              <div ref={messagesEndRef} />
            </div>

            {/* Input bar */}
            <div style={{
              padding: '10px 14px',
              borderTop: `1px solid ${C.border}`,
              background: C.surface,
              display: 'flex', gap: 10, alignItems: 'flex-end',
              flexShrink: 0,
            }}>
              <textarea
                value={input}
                onChange={e => handleInputChange(e.target.value)}
                onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendMessage(); } }}
                placeholder="Type a message..."
                rows={1}
                style={{
                  flex: 1, background: C.panel,
                  border: `1px solid ${C.border}`, borderRadius: 20,
                  padding: '9px 14px', color: C.text, fontSize: 13,
                  outline: 'none', resize: 'none', fontFamily: 'inherit',
                  lineHeight: 1.4, maxHeight: 96, overflowY: 'auto',
                }}
              />
              <button
                onClick={sendMessage}
                disabled={!input.trim() || sending}
                style={{
                  width: 40, height: 40, borderRadius: '50%', border: 'none', cursor: input.trim() && !sending ? 'pointer' : 'not-allowed',
                  background: input.trim() && !sending ? '#A855F7' : C.dim,
                  color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center',
                  flexShrink: 0, transition: 'background 0.15s',
                  boxShadow: input.trim() && !sending ? '0 0 12px #A855F744' : 'none',
                }}
              >
                <Send size={17} />
              </button>
            </div>
          </>
        ) : (
          <div style={{ margin: 'auto', textAlign: 'center', color: C.muted }}>
            <MessageCircle size={40} style={{ opacity: 0.15, marginBottom: 12, display: 'block', margin: '0 auto 12px' }} />
            <div style={{ fontSize: 14, fontWeight: 600 }}>Select a conversation</div>
            <div style={{ fontSize: 12, marginTop: 4 }}>or sync messages from the inbox</div>
          </div>
        )}
      </div>
    </div>
    )}
    </>
  );
}

// ── Invoices tab ─────────────────────────────────────────────────────────────
function InvoicesTab({ userId }: { userId: string }) {
  const [rows, setRows] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');

  const load = useCallback(async () => {
    setLoading(true);
    const { data } = await supabase
      .from('verifactu_invoices')
      .select('*')
      .eq('user_id', userId)
      .order('created_at', { ascending: false })
      .limit(100);
    setRows(data ?? []);
    setLoading(false);
  }, [userId]);

  useEffect(() => { load(); }, [load]);

  const filtered = rows.filter(r =>
    !search || [r.invoice_number, r.issuer_name, r.issuer_nif].some(v =>
      String(v ?? '').toLowerCase().includes(search.toLowerCase())
    )
  );

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
      <div style={{ display: 'flex', gap: 12, alignItems: 'center' }}>
        <div style={{
          flex: 1, display: 'flex', alignItems: 'center', gap: 8,
          background: C.panel, border: `1px solid ${C.border}`, borderRadius: 8,
          padding: '8px 14px',
        }}>
          <Search size={14} color={C.muted} />
          <input
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="Search invoices..."
            style={{ flex: 1, background: 'none', border: 'none', outline: 'none', color: C.text, fontSize: 13 }}
          />
        </div>
        <button onClick={load} style={{
          display: 'flex', alignItems: 'center', gap: 6,
          background: C.blueDim, border: `1px solid ${C.borderHi}`,
          borderRadius: 8, padding: '8px 14px', color: C.blue, fontSize: 13, cursor: 'pointer',
        }}>
          <RefreshCw size={13} />
          Refresh
        </button>
      </div>

      <Card style={{ padding: 0 }}>
        {loading ? (
          <div style={{ padding: 32, textAlign: 'center', color: C.muted, fontSize: 13 }}>Loading...</div>
        ) : filtered.length === 0 ? (
          <Empty label="No invoices found. Use the PDF Extractor to generate your first Verifactu record." />
        ) : (
          <div style={{ overflowX: 'auto' }}>
            <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 13 }}>
              <thead>
                <tr style={{ borderBottom: `1px solid ${C.border}` }}>
                  {['Invoice #', 'Date', 'Issuer', 'NIF', 'Base', 'VAT', 'Total', 'Status', 'QR'].map(h => (
                    <th key={h} style={{
                      padding: '10px 16px', textAlign: 'left',
                      color: C.muted, fontWeight: 600, fontSize: 11,
                      letterSpacing: '0.06em', textTransform: 'uppercase', whiteSpace: 'nowrap',
                    }}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {filtered.map((r, i) => (
                  <tr key={r.id} style={{
                    borderBottom: i < filtered.length - 1 ? `1px solid rgba(255,255,255,0.04)` : 'none',
                    transition: 'background 0.12s',
                  }}
                    onMouseEnter={e => (e.currentTarget.style.background = 'rgba(255,255,255,0.02)')}
                    onMouseLeave={e => (e.currentTarget.style.background = 'transparent')}
                  >
                    <td style={{ padding: '10px 16px', color: C.blue, fontWeight: 600 }}>
                      {r.series}{r.invoice_number}
                    </td>
                    <td style={{ padding: '10px 16px', color: C.text, whiteSpace: 'nowrap' }}>{fmtDate(r.issue_date)}</td>
                    <td style={{ padding: '10px 16px', color: C.text, maxWidth: 160, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{r.issuer_name || '—'}</td>
                    <td style={{ padding: '10px 16px', color: C.muted, fontFamily: 'monospace' }}>{r.issuer_nif || '—'}</td>
                    <td style={{ padding: '10px 16px', color: C.text, textAlign: 'right', fontVariantNumeric: 'tabular-nums' }}>{fmt(r.base_amount)} €</td>
                    <td style={{ padding: '10px 16px', color: C.muted, textAlign: 'right', fontVariantNumeric: 'tabular-nums' }}>{fmt(r.vat_amount)} €</td>
                    <td style={{ padding: '10px 16px', color: C.green, fontWeight: 700, textAlign: 'right', fontVariantNumeric: 'tabular-nums' }}>{fmt(r.total_amount)} €</td>
                    <td style={{ padding: '10px 16px' }}>
                      <Pill label={r.submission_status} color={statusColor(r.submission_status)} />
                    </td>
                    <td style={{ padding: '10px 16px' }}>
                      {r.qr_code ? (
                        <a href={r.qr_code} target="_blank" rel="noopener noreferrer"
                          style={{ color: C.blue, display: 'flex', alignItems: 'center', gap: 4 }}>
                          <ExternalLink size={13} />
                        </a>
                      ) : '—'}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>
    </div>
  );
}

// ── Chain ledger tab ──────────────────────────────────────────────────────────
function ChainTab({ userId }: { userId: string }) {
  const [rows, setRows] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      const { data } = await supabase
        .from('verifactu_chain')
        .select('*')
        .eq('user_id', userId)
        .order('block_index', { ascending: false })
        .limit(50);
      setRows(data ?? []);
      setLoading(false);
    })();
  }, [userId]);

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
      <Card style={{ display: 'flex', gap: 24 }}>
        <div>
          <div style={{ fontSize: 11, color: C.muted, letterSpacing: '0.08em', textTransform: 'uppercase', marginBottom: 4 }}>Total Blocks</div>
          <div style={{ fontSize: 28, fontWeight: 800, color: C.green }}>{rows.length}</div>
        </div>
        <div>
          <div style={{ fontSize: 11, color: C.muted, letterSpacing: '0.08em', textTransform: 'uppercase', marginBottom: 4 }}>Latest Block</div>
          <div style={{ fontSize: 28, fontWeight: 800, color: C.text }}>{rows[0]?.block_index ?? '—'}</div>
        </div>
        <div style={{ flex: 1 }} />
        <div style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 12, color: C.green }}>
          <CheckCircle2 size={15} />
          Chain Integrity: OK
        </div>
      </Card>

      <Card style={{ padding: 0 }}>
        {loading ? (
          <div style={{ padding: 32, textAlign: 'center', color: C.muted, fontSize: 13 }}>Loading...</div>
        ) : rows.length === 0 ? (
          <Empty label="No chain blocks yet. Generate a Verifactu invoice to start the chain." />
        ) : (
          <div style={{ overflowX: 'auto' }}>
            <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 12 }}>
              <thead>
                <tr style={{ borderBottom: `1px solid ${C.border}` }}>
                  {['Block #', 'Timestamp', 'Block Hash', 'Prev Hash', 'Invoice'].map(h => (
                    <th key={h} style={{ padding: '10px 16px', textAlign: 'left', color: C.muted, fontWeight: 600, fontSize: 11, letterSpacing: '0.06em', textTransform: 'uppercase' }}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {rows.map((r, i) => (
                  <tr key={r.id} style={{ borderBottom: i < rows.length - 1 ? `1px solid rgba(255,255,255,0.04)` : 'none' }}>
                    <td style={{ padding: '10px 16px', color: C.green, fontWeight: 700 }}>#{r.block_index}</td>
                    <td style={{ padding: '10px 16px', color: C.muted, whiteSpace: 'nowrap' }}>{fmtDate(r.created_at)}</td>
                    <td style={{ padding: '10px 16px', fontFamily: 'monospace', color: C.text, fontSize: 11 }}>
                      {String(r.block_hash ?? '').slice(0, 16)}…
                    </td>
                    <td style={{ padding: '10px 16px', fontFamily: 'monospace', color: C.muted, fontSize: 11 }}>
                      {String(r.prev_hash ?? '').slice(0, 16)}…
                    </td>
                    <td style={{ padding: '10px 16px', color: C.blue, fontFamily: 'monospace', fontSize: 11 }}>
                      {r.invoice_id ? String(r.invoice_id).slice(0, 8) + '…' : '—'}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>
    </div>
  );
}

// ── Qonto transactions tab ────────────────────────────────────────────────────
function TransactionsTab({ userId }: { userId: string }) {
  const [rows, setRows] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [syncing, setSyncing] = useState(false);
  const [syncMsg, setSyncMsg] = useState('');

  const load = useCallback(async () => {
    setLoading(true);
    const { data } = await supabase
      .from('qonto_transactions')
      .select('*')
      .eq('user_id', userId)
      .order('emitted_at', { ascending: false })
      .limit(100);
    setRows(data ?? []);
    setLoading(false);
  }, [userId]);

  useEffect(() => { load(); }, [load]);

  const handleSync = async () => {
    setSyncing(true);
    setSyncMsg('');
    try {
      const { data: { session } } = await supabase.auth.getSession();
      const res = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/qonto-sync`,
        {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${session?.access_token ?? ''}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({}),
        }
      );
      const json = await res.json();
      if (!res.ok) throw new Error(json.error ?? 'Sync failed');
      setSyncMsg(`Synced ${json.synced ?? 0} transactions`);
      load();
    } catch (err: any) {
      setSyncMsg(err.message ?? 'Error');
    } finally {
      setSyncing(false);
    }
  };

  const vatDeductible = rows.filter(r => r.is_vat_deductible);
  const totalVat = vatDeductible.reduce((s, r) => s + Number(r.vat_amount ?? 0), 0);

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 12 }}>
        {[
          { label: 'Total Transactions', value: rows.length.toString(), color: C.blue },
          { label: 'VAT Deductible', value: vatDeductible.length.toString(), color: C.green },
          { label: 'Reclaimable VAT', value: `${fmt(totalVat)} €`, color: C.amber },
        ].map(k => (
          <Card key={k.label}>
            <div style={{ fontSize: 11, color: C.muted, letterSpacing: '0.08em', textTransform: 'uppercase', marginBottom: 6 }}>{k.label}</div>
            <div style={{ fontSize: 22, fontWeight: 800, color: k.color }}>{k.value}</div>
          </Card>
        ))}
      </div>

      <div style={{ display: 'flex', gap: 12, alignItems: 'center' }}>
        <button onClick={handleSync} disabled={syncing} style={{
          display: 'flex', alignItems: 'center', gap: 6,
          background: C.amberDim, border: `1px solid ${C.amber}44`,
          borderRadius: 8, padding: '8px 16px', color: C.amber, fontSize: 13, cursor: syncing ? 'not-allowed' : 'pointer',
          opacity: syncing ? 0.6 : 1,
        }}>
          <Wifi size={13} style={{ animation: syncing ? 'cap-spin 1s linear infinite' : 'none' }} />
          {syncing ? 'Syncing...' : 'Sync Qonto Feed'}
        </button>
        {syncMsg && (
          <span style={{ fontSize: 12, color: syncMsg.includes('Error') ? C.red : C.green }}>{syncMsg}</span>
        )}
        <div style={{ flex: 1 }} />
        <button onClick={load} style={{
          display: 'flex', alignItems: 'center', gap: 6,
          background: C.blueDim, border: `1px solid ${C.borderHi}`,
          borderRadius: 8, padding: '8px 14px', color: C.blue, fontSize: 13, cursor: 'pointer',
        }}>
          <RefreshCw size={13} />
          Refresh
        </button>
      </div>

      <Card style={{ padding: 0 }}>
        {loading ? (
          <div style={{ padding: 32, textAlign: 'center', color: C.muted, fontSize: 13 }}>Loading...</div>
        ) : rows.length === 0 ? (
          <Empty label='No transactions yet. Click "Sync Qonto Feed" to import your bank data.' />
        ) : (
          <div style={{ overflowX: 'auto' }}>
            <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 13 }}>
              <thead>
                <tr style={{ borderBottom: `1px solid ${C.border}` }}>
                  {['Date', 'Label', 'Category', 'Amount', 'VAT', 'Deductible', 'Status'].map(h => (
                    <th key={h} style={{ padding: '10px 16px', textAlign: 'left', color: C.muted, fontWeight: 600, fontSize: 11, letterSpacing: '0.06em', textTransform: 'uppercase', whiteSpace: 'nowrap' }}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {rows.map((r, i) => (
                  <tr key={r.id} style={{ borderBottom: i < rows.length - 1 ? `1px solid rgba(255,255,255,0.04)` : 'none' }}
                    onMouseEnter={e => (e.currentTarget.style.background = 'rgba(255,255,255,0.02)')}
                    onMouseLeave={e => (e.currentTarget.style.background = 'transparent')}
                  >
                    <td style={{ padding: '10px 16px', color: C.muted, whiteSpace: 'nowrap' }}>{fmtDate(r.emitted_at)}</td>
                    <td style={{ padding: '10px 16px', color: C.text, maxWidth: 200, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{r.label || '—'}</td>
                    <td style={{ padding: '10px 16px', color: C.muted }}>{r.category || '—'}</td>
                    <td style={{ padding: '10px 16px', color: r.side === 'credit' ? C.green : C.text, fontWeight: 600, textAlign: 'right', fontVariantNumeric: 'tabular-nums' }}>
                      {r.side === 'credit' ? '+' : '-'}{fmt(r.amount)} €
                    </td>
                    <td style={{ padding: '10px 16px', color: C.amber, textAlign: 'right', fontVariantNumeric: 'tabular-nums' }}>
                      {r.vat_amount != null ? `${fmt(r.vat_amount)} €` : '—'}
                    </td>
                    <td style={{ padding: '10px 16px', textAlign: 'center' }}>
                      {r.is_vat_deductible ? <CheckCircle2 size={14} color={C.green} /> : <span style={{ color: C.dim }}>—</span>}
                    </td>
                    <td style={{ padding: '10px 16px' }}>
                      <Pill label={r.status} color={r.status === 'completed' ? C.green : C.amber} />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>
    </div>
  );
}

// ── PDF extractor tab ─────────────────────────────────────────────────────────
function ExtractTab({ userId }: { userId: string }) {
  const [text, setText] = useState('');
  const [result, setResult] = useState<any>(null);
  const [generating, setGenerating] = useState(false);
  const [extracting, setExtracting] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  const handleExtract = async () => {
    if (!text.trim()) return;
    setExtracting(true);
    setResult(null);
    setError('');
    try {
      const { data: { session } } = await supabase.auth.getSession();
      const res = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/invoice-extract`,
        {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${session?.access_token ?? ''}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ text }),
        }
      );
      const json = await res.json();
      if (!res.ok) throw new Error(json.error ?? 'Extraction failed');
      setResult(json.extracted);
    } catch (err: any) {
      setError(err.message ?? 'Error');
    } finally {
      setExtracting(false);
    }
  };

  const handleGenerate = async () => {
    if (!result) return;
    setGenerating(true);
    setError('');
    setSuccess('');
    try {
      const { data: { session } } = await supabase.auth.getSession();
      const res = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/verifactu-generate`,
        {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${session?.access_token ?? ''}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ ...result, raw_pdf_text: text }),
        }
      );
      const json = await res.json();
      if (!res.ok) throw new Error(json.error ?? 'Generation failed');
      setSuccess(`Invoice registered. Block #${json.block_index} — Hash: ${String(json.block_hash).slice(0, 12)}…`);
      setResult(null);
      setText('');
    } catch (err: any) {
      setError(err.message ?? 'Error');
    } finally {
      setGenerating(false);
    }
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
      <Card>
        <div style={{ fontSize: 13, color: C.muted, marginBottom: 12 }}>
          Paste the text content of a Spanish invoice PDF. The AI will extract all fields and prepare a Verifactu-compliant hash chain entry.
        </div>
        <textarea
          value={text}
          onChange={e => setText(e.target.value)}
          placeholder="Paste invoice text here..."
          rows={10}
          style={{
            width: '100%', background: C.panel, border: `1px solid ${C.border}`,
            borderRadius: 8, padding: '12px 14px', color: C.text, fontSize: 13,
            resize: 'vertical', outline: 'none', fontFamily: 'inherit', boxSizing: 'border-box',
          }}
        />
        <div style={{ display: 'flex', gap: 10, marginTop: 12 }}>
          <button
            onClick={handleExtract}
            disabled={!text.trim() || extracting}
            style={{
              display: 'flex', alignItems: 'center', gap: 6,
              background: C.blueDim, border: `1px solid ${C.borderHi}`,
              borderRadius: 8, padding: '9px 18px', color: C.blue, fontSize: 13,
              cursor: (!text.trim() || extracting) ? 'not-allowed' : 'pointer',
              opacity: (!text.trim() || extracting) ? 0.5 : 1,
            }}
          >
            <Search size={13} />
            {extracting ? 'Extracting...' : 'Extract Fields'}
          </button>
          {result && (
            <button
              onClick={handleGenerate}
              disabled={generating}
              style={{
                display: 'flex', alignItems: 'center', gap: 6,
                background: C.greenDim, border: `1px solid ${C.green}44`,
                borderRadius: 8, padding: '9px 18px', color: C.green, fontSize: 13,
                cursor: generating ? 'not-allowed' : 'pointer',
                opacity: generating ? 0.5 : 1,
              }}
            >
              <Zap size={13} />
              {generating ? 'Registering...' : 'Register Verifactu'}
            </button>
          )}
        </div>
      </Card>

      {error && (
        <div style={{
          display: 'flex', alignItems: 'center', gap: 8,
          background: C.redDim, border: `1px solid ${C.red}44`,
          borderRadius: 8, padding: '10px 14px', color: C.red, fontSize: 13,
        }}>
          <AlertTriangle size={14} />
          {error}
        </div>
      )}

      {success && (
        <div style={{
          display: 'flex', alignItems: 'center', gap: 8,
          background: C.greenDim, border: `1px solid ${C.green}44`,
          borderRadius: 8, padding: '10px 14px', color: C.green, fontSize: 13,
        }}>
          <CheckCircle2 size={14} />
          {success}
        </div>
      )}

      {result && (
        <Card>
          <div style={{ fontSize: 12, color: C.muted, marginBottom: 12, letterSpacing: '0.06em', textTransform: 'uppercase', fontWeight: 700 }}>
            Extracted Fields
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill,minmax(200px,1fr))', gap: 12 }}>
            {[
              ['Invoice #', `${result.series ?? ''}${result.invoice_number ?? '—'}`],
              ['Issue Date', result.issue_date ?? '—'],
              ['Issuer NIF', result.issuer_nif ?? '—'],
              ['Recipient NIF', result.recipient_nif ?? '—'],
              ['Base Amount', result.base_amount != null ? `${fmt(result.base_amount)} €` : '—'],
              ['VAT Rate', result.vat_rate != null ? `${result.vat_rate}%` : '—'],
              ['VAT Amount', result.vat_amount != null ? `${fmt(result.vat_amount)} €` : '—'],
              ['Total Amount', result.total_amount != null ? `${fmt(result.total_amount)} €` : '—'],
            ].map(([label, value]) => (
              <div key={label} style={{ background: C.panel, borderRadius: 8, padding: '10px 14px' }}>
                <div style={{ fontSize: 11, color: C.muted, marginBottom: 4, textTransform: 'uppercase', letterSpacing: '0.06em' }}>{label}</div>
                <div style={{ fontSize: 14, color: C.text, fontWeight: 600, fontFamily: 'monospace' }}>{value}</div>
              </div>
            ))}
          </div>
        </Card>
      )}
    </div>
  );
}

// ── Main component ────────────────────────────────────────────────────────────
interface Props {
  userId?: string;
  onNavigate?: (tab: string) => void;
}

export default function CommercialAIPowerpack({ userId, onNavigate }: Props) {
  const STORAGE_KEY = 'cap_active_tab';
  const [activeTab, setActiveTab] = useState<TabId>(() => {
    try { return (localStorage.getItem(STORAGE_KEY) as TabId) ?? 'ai-account'; } catch { return 'ai-account'; }
  });

  const switchTab = (id: TabId) => {
    setActiveTab(id);
    try { localStorage.setItem(STORAGE_KEY, id); } catch { /* noop */ }
  };

  // ── beforeunload guard — zero data loss ───────────────────────────────────
  useEffect(() => {
    const handler = () => {
      saveState({ activeTab, lastSeen: new Date().toISOString() });
    };
    window.addEventListener('beforeunload', handler);
    return () => window.removeEventListener('beforeunload', handler);
  }, [activeTab]);

  if (!userId) {
    return (
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', minHeight: '60vh', color: C.muted, fontSize: 14 }}>
        Sign in to access the Commercial AI Powerpack.
      </div>
    );
  }

  const activeTabDef = TABS.find(t => t.id === activeTab)!;

  return (
    <div style={{
      position: 'absolute', inset: 0,
      background: 'rgba(11,15,25,0.82)',
      backdropFilter: 'blur(2px)',
      overflowY: 'auto',
      fontFamily: "'Inter', sans-serif",
    }}>
      <style>{`
        @keyframes cap-spin { to { transform: rotate(360deg); } }
        @keyframes cap-pulse {
          0%, 100% { box-shadow: 0 0 0 0 rgba(168,85,247,0.4); }
          50% { box-shadow: 0 0 0 14px rgba(168,85,247,0); }
        }
      `}</style>

      {/* Header */}
      <div style={{
        padding: '20px 28px 0',
        borderBottom: `1px solid ${C.border}`,
        background: `linear-gradient(180deg, rgba(96,165,250,0.04) 0%, transparent 100%)`,
      }}>
        <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: 20 }}>
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 4 }}>
              <div style={{
                width: 36, height: 36, borderRadius: 10,
                background: C.blueDim, border: `1px solid ${C.borderHi}`,
                display: 'flex', alignItems: 'center', justifyContent: 'center',
              }}>
                <Building2 size={18} color={C.blue} />
              </div>
              <div>
                <div style={{ fontSize: 18, fontWeight: 800, color: C.text, letterSpacing: '-0.01em' }}>
                  Commercial AI Powerpack
                </div>
                <div style={{ fontSize: 12, color: C.muted }}>
                  AI Account · Verifactu · AEAT Hash Chain · Qonto Bank Feed
                </div>
              </div>
            </div>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 11, color: C.green, background: C.greenDim, border: `1px solid ${C.green}33`, borderRadius: 20, padding: '4px 10px' }}>
            <div style={{ width: 6, height: 6, borderRadius: '50%', background: C.green, boxShadow: `0 0 6px ${C.green}` }} />
            LIVE
          </div>
        </div>

        {/* Tab row */}
        <div style={{ display: 'flex', gap: 2, overflowX: 'auto' }}>
          {TABS.map(t => {
            const Icon = t.icon;
            const isActive = t.id === activeTab;
            return (
              <button
                key={t.id}
                onClick={() => switchTab(t.id)}
                style={{
                  display: 'flex', alignItems: 'center', gap: 7,
                  padding: '10px 16px',
                  background: isActive ? `${t.color}15` : 'transparent',
                  border: 'none',
                  borderBottom: isActive ? `2px solid ${t.color}` : '2px solid transparent',
                  color: isActive ? t.color : C.muted,
                  fontSize: 13, fontWeight: isActive ? 700 : 500,
                  cursor: 'pointer',
                  transition: 'color 0.15s, background 0.15s',
                  whiteSpace: 'nowrap',
                }}
              >
                <Icon size={14} />
                {t.label}
              </button>
            );
          })}
        </div>
      </div>

      {/* Content */}
      <div style={{ padding: '24px 28px' }}>
        {activeTab === 'ai-account'    && <AIAccountTab userId={userId} />}
        {activeTab === 'invoices'      && <InvoicesTab userId={userId} />}
        {activeTab === 'chain'         && <ChainTab userId={userId} />}
        {activeTab === 'transactions'  && <TransactionsTab userId={userId} />}
        {activeTab === 'extract'       && <ExtractTab userId={userId} />}
        {activeTab === 'energy-guard'  && <EnergyGuardTab userId={userId} />}
      </div>
    </div>
  );
}
