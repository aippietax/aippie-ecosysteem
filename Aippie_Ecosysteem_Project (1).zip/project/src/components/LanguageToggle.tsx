import { useState } from 'react';
import { ArrowLeftRight } from 'lucide-react';
import { CORRIDORS, type LanguageCorridor } from '../lib/routingConfig';

type Props = {
  onCorridorChange?: (corridor: LanguageCorridor, flipped: boolean) => void;
};

export default function LanguageToggle({ onCorridorChange }: Props) {
  const [corridorIndex, setCorridorIndex] = useState(0);
  const [flipped, setFlipped] = useState(false);

  const corridor = CORRIDORS[corridorIndex];
  const from = flipped ? corridor.to   : corridor.from;
  const to   = flipped ? corridor.from : corridor.to;

  const selectCorridor = (idx: number, flip = false) => {
    setCorridorIndex(idx);
    setFlipped(flip);
    onCorridorChange?.(CORRIDORS[idx], flip);
  };

  const swap = () => {
    const next = !flipped;
    setFlipped(next);
    onCorridorChange?.(corridor, next);
  };

  return (
    <div className="lang-toggle-wrap">
      {/* Active pair pill */}
      <div className="lang-toggle">
        <div className="lang-pair">
          <span className="lang-pair__flag">{from.flag}</span>
          <span className="lang-pair__label">{from.label}</span>
        </div>

        <button className="lang-toggle__swap" onClick={swap} aria-label="Swap direction">
          <ArrowLeftRight size={14} strokeWidth={2.5} />
        </button>

        <div className="lang-pair">
          <span className="lang-pair__flag">{to.flag}</span>
          <span className="lang-pair__label">{to.label}</span>
        </div>
      </div>

      {/* Corridor selector tabs */}
      <div className="corridor-tabs">
        {CORRIDORS.map((c, i) => (
          <button
            key={c.from.code}
            className={`corridor-tab${corridorIndex === i ? ' corridor-tab--active' : ''}`}
            onClick={() => selectCorridor(i, false)}
          >
            <span>{c.from.flag}</span>
            <span className="corridor-tab__label">{c.from.label}</span>
            <span className="corridor-tab__arrow">⇄</span>
            <span>{c.to.flag}</span>
            <span className="corridor-tab__label">ES</span>
          </button>
        ))}
      </div>
    </div>
  );
}
