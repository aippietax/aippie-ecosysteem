/**
 * AippiePresenter — V98 Omnipresent Live Video Avatar Bar
 * Renders Aippie's proprietary half-human/half-AI face, animated lip-sync
 * ring, 28-bar waveform, and scrolling word-subtitle on every view.
 * Never unmounts. Image: /Jouw_alineatekst_(2).png (Pexels fallback).
 *
 * V98 — "Welcome" loop elimination:
 *   The hardcoded startup greeting has been removed entirely.
 *   App.tsx passes `initialScript` and `initialEmotion` — the exact
 *   contextual speech for whichever tab the user lands on first.
 *   This guarantees:
 *     1. No "Welcome to Aippie" ever plays on an inner dashboard.
 *     2. The speech queue is always correct on first mount.
 *     3. Landing → dashboard transition cancels residual landing audio
 *        at the App level before AippiePresenter mounts.
 *
 * V96 fix retained: setSpeaking(true) fires synchronously on speak()
 * to bypass the Chrome onstart-never-fires bug.
 */
import { useEffect, useRef, useState, useCallback, forwardRef, useImperativeHandle } from 'react';
import { Lock, Mic, MicOff, Sparkles, Radio } from 'lucide-react';
import { applyPremiumVoice, withVoicesReady, normalizeForTTS } from '../lib/ttsVoice';

// ─── Types ────────────────────────────────────────────────────────────────────
export type PresenterEmotion = 'neutral' | 'focused' | 'pleased' | 'concerned' | 'warm' | 'authoritative';

export type AippiePresenterHandle = {
  speak: (text: string, emotion?: PresenterEmotion) => void;
  stopSpeech: () => void;
  setEmotion: (e: PresenterEmotion) => void;
  isSpeaking: () => boolean;
};

type Props = {
  collapsed?: boolean;
  initialScript?: string;
  initialEmotion?: PresenterEmotion;
};

// ─── Emotion config ───────────────────────────────────────────────────────────
const EMOTION_CFG: Record<PresenterEmotion, {
  ringColor: string; waveColor: string;
  pitch: number; rate: number; label: string;
}> = {
  neutral:       { ringColor: '#38bdf8', waveColor: '#38bdf8', pitch: 1.1,  rate: 1.05, label: 'Ready'          },
  focused:       { ringColor: '#60a5fa', waveColor: '#60a5fa', pitch: 1.05, rate: 1.0,  label: 'Analyzing'      },
  pleased:       { ringColor: '#4ade80', waveColor: '#4ade80', pitch: 1.2,  rate: 1.08, label: 'Confirmed'       },
  concerned:     { ringColor: '#f87171', waveColor: '#f87171', pitch: 1.0,  rate: 1.0,  label: 'Alert'           },
  warm:          { ringColor: '#fb7185', waveColor: '#fb7185', pitch: 1.15, rate: 1.05, label: 'Warm'            },
  authoritative: { ringColor: '#fbbf24', waveColor: '#fbbf24', pitch: 1.05, rate: 1.0,  label: 'Filing Mode'     },
};

// ─── 28-bar waveform ──────────────────────────────────────────────────────────
function Waveform({ active, color }: { active: boolean; color: string }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const frameRef  = useRef<number>(0);
  const tickRef   = useRef(0);

  useEffect(() => {
    const canvas = canvasRef.current; if (!canvas) return;
    const ctx = canvas.getContext('2d'); if (!ctx) return;
    const BARS = 28;
    const draw = () => {
      tickRef.current++;
      const tk = tickRef.current, W = canvas.width, H = canvas.height;
      ctx.clearRect(0, 0, W, H);
      const gap = W / BARS, barW = Math.max(2, gap - 2);
      for (let i = 0; i < BARS; i++) {
        const phase = (i / BARS) * Math.PI * 2;
        const rawH  = active
          ? (0.1 + 0.9 * Math.abs(Math.sin(tk * 0.06 + phase))) * H
          : (0.08 + 0.04 * Math.abs(Math.sin(tk * 0.02 + phase))) * H;
        const x = i * gap + (gap - barW) / 2, y = (H - rawH) / 2;
        ctx.fillStyle = color + (active ? 'ee' : '44');
        ctx.beginPath();
        ctx.roundRect(x, y, barW, rawH, Math.min(barW / 2, 4));
        ctx.fill();
      }
      frameRef.current = requestAnimationFrame(draw);
    };
    frameRef.current = requestAnimationFrame(draw);
    return () => cancelAnimationFrame(frameRef.current);
  }, [active, color]);

  return (
    <canvas
      ref={canvasRef}
      width={280}
      height={32}
      className="apr-waveform"
      aria-hidden="true"
    />
  );
}

// ─── Word subtitle hook ───────────────────────────────────────────────────────
function useWordSubtitle(text: string, active: boolean) {
  const [sub, setSub] = useState('');
  const tmr = useRef<ReturnType<typeof setInterval> | null>(null);
  const idx = useRef(0);
  useEffect(() => {
    if (tmr.current) { clearInterval(tmr.current); tmr.current = null; }
    setSub('');
    if (!active || !text.trim()) return;
    const words = text.split(/\s+/);
    idx.current = 0;
    tmr.current = setInterval(() => {
      idx.current++;
      setSub(words.slice(Math.max(0, idx.current - 9), idx.current).join(' '));
      if (idx.current >= words.length && tmr.current) {
        clearInterval(tmr.current); tmr.current = null;
      }
    }, 430);
    return () => { if (tmr.current) { clearInterval(tmr.current); tmr.current = null; } };
  }, [text, active]);
  return sub;
}


function LipSyncMouth({ active, color }: { active: boolean; color: string }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const frameRef  = useRef<number>(0);
  const s = useRef({ open: 0, target: 0, nextAt: 0 });

  useEffect(() => {
    const canvas = canvasRef.current; if (!canvas) return;
    const ctx = canvas.getContext('2d'); if (!ctx) return;
    const W = canvas.width, H = canvas.height;

    const draw = (ts: number) => {
      if (ts > s.current.nextAt) {
        s.current.target = active ? 0.15 + Math.random() * 0.75 : 0;
        s.current.nextAt = ts + (active ? 55 + Math.random() * 95 : 300);
      }
      s.current.open += (s.current.target - s.current.open) * (active ? 0.38 : 0.22);

      ctx.clearRect(0, 0, W, H);
      const op = s.current.open;
      if (op > 0.03) {
        const mw = W * 0.82, mh = Math.max(1, H * op);
        const cx = W / 2, cy = H * 0.52;
        // dark mouth interior
        ctx.beginPath();
        ctx.ellipse(cx, cy, mw/2, mh/2, 0, 0, Math.PI*2);
        ctx.fillStyle = 'rgba(15,5,5,0.82)';
        ctx.fill();
        // lower lip gleam
        ctx.beginPath();
        ctx.ellipse(cx, cy + mh*0.28, mw*0.42, mh*0.18, 0, 0, Math.PI);
        ctx.fillStyle = color + '28';
        ctx.fill();
      }
      // closed lip line
      ctx.beginPath();
      ctx.moveTo(W*0.1, H*0.5);
      ctx.bezierCurveTo(W*0.3, H*0.5 - H*op*0.3, W*0.7, H*0.5 - H*op*0.3, W*0.9, H*0.5);
      ctx.strokeStyle = 'rgba(80,40,40,0.55)';
      ctx.lineWidth = 1.2;
      ctx.stroke();

      frameRef.current = requestAnimationFrame(draw);
    };
    frameRef.current = requestAnimationFrame(draw);
    return () => cancelAnimationFrame(frameRef.current);
  }, [active, color]);

  return (
    <canvas
      ref={canvasRef}
      width={22}
      height={9}
      className="apr-mouth-canvas"
      aria-hidden="true"
    />
  );
}

function LipSyncRing({ active, color }: { active: boolean; color: string }) {
  return (
    <div className="apr-lipsync-ring" aria-hidden="true"
      style={{ '--ring-color': color } as React.CSSProperties}>
      {[1,2,3].map(n => (
        <span
          key={n}
          className={`apr-lipsync-ring__arc apr-lipsync-ring__arc--${n}${active ? ' apr-lipsync-ring__arc--active' : ''}`}
        />
      ))}
    </div>
  );
}

// ─── Main presenter component ─────────────────────────────────────────────────
const AippiePresenter = forwardRef<AippiePresenterHandle, Props>(
  function AippiePresenter({ collapsed = false, initialScript, initialEmotion = 'warm' }, ref) {
    const [speaking,  setSpeaking]  = useState(false);
    const [listening, setListening] = useState(false);
    const [emotion,   setEmotionSt] = useState<PresenterEmotion>('neutral');
    const [currentText, setCurrentText] = useState(
      initialScript ?? 'Aippie · AIPPIETAX S.A.'
    );

    const ecfg     = EMOTION_CFG[emotion];
    const subtitle = useWordSubtitle(currentText, speaking);
    const synthRef = useRef(speaking);
    synthRef.current = speaking;

    // ─── TTS — V96: setSpeaking(true) fires synchronously, not on onstart ──
    // Chrome bug: onstart is skipped for some utterances. Activating the
    // visual state here ensures rings/waveform/subtitle are ALWAYS live.
    const speak = useCallback((text: string, em: PresenterEmotion = 'neutral') => {
      if (!('speechSynthesis' in window) || collapsed) return;

      window.speechSynthesis.cancel();
      const cfg = EMOTION_CFG[em];
      setEmotionSt(em);
      setCurrentText(text);

      // Activate avatar visuals immediately on every speak() call
      setSpeaking(true);

      const fire = () => {
        const u = new SpeechSynthesisUtterance(normalizeForTTS(text));
        u.pitch = cfg.pitch;
        u.rate  = cfg.rate;
        applyPremiumVoice(u);
        u.onstart = () => setSpeaking(true);   // secondary guard
        u.onend   = () => setSpeaking(false);
        u.onerror = () => setSpeaking(false);
        window.speechSynthesis.speak(u);
      };

      withVoicesReady(fire);
    }, [collapsed]);

    const stopSpeech = useCallback(() => {
      window.speechSynthesis?.cancel();
      setSpeaking(false);
    }, []);

    // Expose handle to parent
    useImperativeHandle(ref, () => ({
      speak,
      stopSpeech,
      setEmotion: (e: PresenterEmotion) => setEmotionSt(e),
      isSpeaking: () => synthRef.current,
    }), [speak, stopSpeech]);

    // V98: play initialScript on mount — no hardcoded welcome string.
    // App.tsx is responsible for passing the correct contextual script.
    // If no initialScript is provided the avatar mounts silently (ready state).
    useEffect(() => {
      if (!initialScript) return;
      withVoicesReady(() => setTimeout(() => speak(initialScript, initialEmotion), 300));
      return () => { window.speechSynthesis?.cancel(); };
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    return (
      <div
        className={`apr-bar${collapsed ? ' apr-bar--collapsed' : ''}`}
        style={{ '--apr-ring-color': ecfg.ringColor } as React.CSSProperties}
        aria-label="Aippie Live Avatar"
      >
        {/* Portrait */}
        <div className="apr-portrait-cell">
          <div className="apr-portrait-wrap">
            <img
              src="/Jouw_alineatekst_(2).png"
              alt="Aippie"
              className={`apr-portrait${speaking ? ' apr-portrait--speaking' : ''}`}
              draggable={false}
              onError={e => {
                (e.currentTarget as HTMLImageElement).src =
                  'https://images.pexels.com/photos/1858175/pexels-photo-1858175.jpeg?auto=compress&cs=tinysrgb&w=600&h=700&fit=crop&crop=faces';
              }}
            />
            <div className="apr-portrait__fade" />
            <LipSyncMouth active={speaking} color={ecfg.ringColor} />
            <LipSyncRing active={speaking} color={ecfg.ringColor} />

            {/* WebRTC / E2EE pip */}
            <div className="apr-rtc-pip">
              <span className={`apr-dot${speaking ? ' apr-dot--pulse' : ''}`} style={{ background: ecfg.ringColor }}/>
              <Lock size={7}/>
              <span>E2EE</span>
              <span className="apr-rtc-pip__sep">·</span>
              <Radio size={7}/>
              <span>WebRTC</span>
            </div>
          </div>
          {/* Mouth overlay removed — jaw-split on portrait handles lipsync */}
        </div>

        {/* Content */}
        <div className="apr-content">
          <div className="apr-content__row">
            <div className="apr-identity">
              <span className="apr-identity__name">Aippie</span>
              <span className="apr-identity__org">AIPPIETAX S.A. · v116</span>
            </div>
            <div className="apr-emotion-badge"
              style={{ color: ecfg.ringColor, borderColor: `${ecfg.ringColor}33`, background: `${ecfg.ringColor}0d` }}>
              <Sparkles size={8}/>{ecfg.label}
            </div>
            <div className="apr-listen-icon" aria-hidden="true">
              {listening ? <MicOff size={12} style={{ color: ecfg.ringColor }}/> : <Mic size={12} style={{ color: '#475569' }}/>}
            </div>
          </div>

          {/* Waveform */}
          <Waveform active={speaking} color={ecfg.waveColor}/>

          {/* Subtitle */}
          <div className={`apr-subtitle${speaking && subtitle ? ' apr-subtitle--active' : ''}`}>
            {speaking && subtitle ? subtitle : '\u00A0'}
          </div>
        </div>
      </div>
    );
  }
);

export default AippiePresenter;

// Attach display name for DevTools
AippiePresenter.displayName = 'AippiePresenter';
