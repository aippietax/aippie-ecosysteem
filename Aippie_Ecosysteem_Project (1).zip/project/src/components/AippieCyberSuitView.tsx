/**
 * AippieCyberSuitView — V211 Cyber-Suit & Bio-Defense Infrastructure
 * AIPPIETAX S.A. · Module 19
 *
 * Left: animated SVG humanoid cybernetic wireframe with neon-blue pulse nodes.
 * Right: Fase 3 Development Pipeline product copy.
 * On mount: TTS introduction at rate 0.82 with typewriter subtitle.
 */
import { useEffect, useRef, useState } from 'react';
import { Building2, Activity, Wind, Mic, ShieldCheck, Save, Check } from 'lucide-react';
import { withVoicesReady, selectPremiumVoice, normalizeForTTS } from '../lib/ttsVoice';
import { supabase } from '../lib/supabase';

const CYBERSUIT_SPEECH = normalizeForTTS(
  'Hello, I am Aippie. This is the Aippie Cyber-Suit, your personal physical guardian.'
);

// ── Typewriter hook ───────────────────────────────────────────────────────────
function useTypewriter(text: string, active: boolean, intervalMs = 58) {
  const [displayed, setDisplayed] = useState('');
  const idxRef = useRef(0);
  const tmrRef = useRef<ReturnType<typeof setInterval> | null>(null);

  useEffect(() => {
    if (tmrRef.current) { clearInterval(tmrRef.current); tmrRef.current = null; }
    setDisplayed('');
    idxRef.current = 0;
    if (!active || !text) return;
    tmrRef.current = setInterval(() => {
      idxRef.current++;
      setDisplayed(text.slice(0, idxRef.current));
      if (idxRef.current >= text.length && tmrRef.current) {
        clearInterval(tmrRef.current);
        tmrRef.current = null;
      }
    }, intervalMs);
    return () => { if (tmrRef.current) { clearInterval(tmrRef.current); tmrRef.current = null; } };
  }, [text, active, intervalMs]);

  return displayed;
}

// ── Pulse node animation hook ─────────────────────────────────────────────────
// Returns a tick counter that increments every ~80ms for smooth pulsing.
function useTick(ms = 80) {
  const [tick, setTick] = useState(0);
  useEffect(() => {
    const id = setInterval(() => setTick(t => t + 1), ms);
    return () => clearInterval(id);
  }, [ms]);
  return tick;
}

// ── Humanoid SVG wireframe with neon nodes ────────────────────────────────────
const NODE_POSITIONS: { cx: number; cy: number; label: string; phase: number }[] = [
  { cx: 100, cy:  28, label: 'Neural Core',       phase: 0.00 },
  { cx:  78, cy:  55, label: 'Left Shoulder',     phase: 0.40 },
  { cx: 122, cy:  55, label: 'Right Shoulder',    phase: 0.80 },
  { cx: 100, cy:  80, label: 'Thoracic Hub',      phase: 0.20 },
  { cx:  62, cy:  90, label: 'Left Elbow',        phase: 1.00 },
  { cx: 138, cy:  90, label: 'Right Elbow',       phase: 0.60 },
  { cx: 100, cy: 115, label: 'Core Spine',        phase: 1.20 },
  { cx:  58, cy: 120, label: 'Left Wrist',        phase: 1.40 },
  { cx: 142, cy: 120, label: 'Right Wrist',       phase: 0.30 },
  { cx:  85, cy: 145, label: 'Left Hip',          phase: 1.60 },
  { cx: 115, cy: 145, label: 'Right Hip',         phase: 0.90 },
  { cx:  80, cy: 180, label: 'Left Knee',         phase: 1.80 },
  { cx: 120, cy: 180, label: 'Right Knee',        phase: 0.50 },
  { cx:  78, cy: 215, label: 'Left Ankle',        phase: 2.00 },
  { cx: 122, cy: 215, label: 'Right Ankle',       phase: 0.70 },
];

function HumanoidWireframe({ tick }: { tick: number }) {
  return (
    <svg
      viewBox="0 0 200 240"
      className="csv-svg"
      aria-label="Cybernetic humanoid wireframe"
    >
      <defs>
        <filter id="csv-glow">
          <feGaussianBlur stdDeviation="2.5" result="blur" />
          <feComposite in="SourceGraphic" in2="blur" operator="over" />
        </filter>
        <linearGradient id="csv-body-grad" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%"   stopColor="#38bdf8" stopOpacity="0.55" />
          <stop offset="100%" stopColor="#0284c7" stopOpacity="0.20" />
        </linearGradient>
      </defs>

      {/* ── Skeleton wireframe lines ── */}
      <g stroke="url(#csv-body-grad)" strokeWidth="1.2" fill="none" opacity="0.7">
        {/* Head */}
        <ellipse cx="100" cy="18" rx="12" ry="14" />
        {/* Neck → shoulders */}
        <line x1="100" y1="32" x2="100" y2="42" />
        <line x1="100" y1="42" x2="78"  y2="55" />
        <line x1="100" y1="42" x2="122" y2="55" />
        {/* Spine */}
        <line x1="100" y1="42" x2="100" y2="140" />
        {/* Upper arms */}
        <line x1="78"  y1="55" x2="62"  y2="90" />
        <line x1="122" y1="55" x2="138" y2="90" />
        {/* Forearms */}
        <line x1="62"  y1="90" x2="58"  y2="120" />
        <line x1="138" y1="90" x2="142" y2="120" />
        {/* Pelvis */}
        <line x1="100" y1="140" x2="85"  y2="145" />
        <line x1="100" y1="140" x2="115" y2="145" />
        {/* Thighs */}
        <line x1="85"  y1="145" x2="80"  y2="180" />
        <line x1="115" y1="145" x2="120" y2="180" />
        {/* Shins */}
        <line x1="80"  y1="180" x2="78"  y2="215" />
        <line x1="120" y1="180" x2="122" y2="215" />
        {/* Chest / rib cage hints */}
        <ellipse cx="100" cy="80" rx="22" ry="18" opacity="0.35" />
        <line x1="100" y1="62" x2="100" y2="98" strokeOpacity="0.3" />
        <line x1="78"  y1="80" x2="122" y2="80" strokeOpacity="0.3" />
      </g>

      {/* ── Neon pulse nodes ── */}
      {NODE_POSITIONS.map((n) => {
        const wave = Math.sin(tick * 0.14 + n.phase * Math.PI);
        const r    = 3.5 + 1.4 * wave;
        const glow = 0.55 + 0.45 * ((wave + 1) / 2);
        return (
          <g key={n.label} filter="url(#csv-glow)">
            {/* Outer ring */}
            <circle
              cx={n.cx} cy={n.cy}
              r={r + 3}
              fill="none"
              stroke="#38bdf8"
              strokeWidth="0.6"
              opacity={0.18 + 0.22 * ((wave + 1) / 2)}
            />
            {/* Core dot */}
            <circle
              cx={n.cx} cy={n.cy}
              r={r}
              fill={`rgba(56,189,248,${glow.toFixed(2)})`}
              stroke="#7dd3fc"
              strokeWidth="0.5"
            />
          </g>
        );
      })}

      {/* ── Grid overlay — subtle perspective grid ── */}
      <g stroke="#0ea5e9" strokeWidth="0.3" opacity="0.08">
        {[0, 40, 80, 120, 160, 200].map(x => (
          <line key={`vg${x}`} x1={x} y1="0" x2={x} y2="240" />
        ))}
        {[0, 40, 80, 120, 160, 200, 240].map(y => (
          <line key={`hg${y}`} x1="0" y1={y} x2="200" y2={y} />
        ))}
      </g>
    </svg>
  );
}

// ── Pipeline feature rows ─────────────────────────────────────────────────────
const PIPELINE_FEATURES = [
  {
    emoji: '🫁',
    label: 'Active Bio-Filtration',
    description: 'Continuous graphene micro-filtering delivering 100% pure oxygen.',
    color: '#4ade80',
    icon: <Wind size={14} />,
    status: 'FASE 3',
  },
  {
    emoji: '🩺',
    label: 'Real-Time Diagnostics',
    description:
      'Active monitoring for blood pressure (PPG), SpO2 levels, and non-invasive glucose tracking linked directly to Aippie Doctor (Module 7).',
    color: '#38bdf8',
    icon: <Activity size={14} />,
    status: 'INTEGRATED',
  },
  {
    emoji: '🗣️',
    label: 'Neural Translation Grendel',
    description:
      'Real-time bone-conduction voice translation and environmental threat alerts.',
    color: '#fb923c',
    icon: <Mic size={14} />,
    status: 'STAGING',
  },
] as const;

// ── Main view ─────────────────────────────────────────────────────────────────
export default function AippieCyberSuitView() {
  const [speaking, setSpeaking] = useState(false);
  const [bioFilter, setBioFilter] = useState(true);
  const [neuralSync, setNeuralSync] = useState(false);
  const [powerMode, setPowerMode] = useState<'ECO'|'NORMAL'|'PERFORMANCE'|'MAX'>('ECO');
  const [saved, setSaved] = useState(false);
  const cancelRef = useRef(false);
  const tick = useTick(80);
  const deviceKey = localStorage.getItem('aippie_device_key') ?? 'anon';

  const SUBTITLE_TEXT = 'Hello, I am Aippie. This is the Aippie Cyber-Suit, your personal physical guardian.';
  const subtitle = useTypewriter(SUBTITLE_TEXT, speaking, 58);

  // Load saved config on mount
  useEffect(() => {
    supabase.from('cybersuit_configs').select('*').eq('device_key', deviceKey).maybeSingle().then(({ data }) => {
      if (data) {
        setBioFilter(data.bio_filter ?? true);
        setNeuralSync(data.neural_sync ?? false);
        setPowerMode(data.power_mode ?? 'ECO');
      }
    });
  }, []);

  const handleSave = async () => {
    await supabase.from('cybersuit_configs').upsert({
      device_key: deviceKey, bio_filter: bioFilter, neural_sync: neuralSync,
      power_mode: powerMode, updated_at: new Date().toISOString(),
    }, { onConflict: 'device_key' });
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  useEffect(() => {
    cancelRef.current = false;
    if (!('speechSynthesis' in window)) return;
    window.speechSynthesis.cancel();

    let delayTimer: ReturnType<typeof setTimeout> | null = null;

    withVoicesReady(() => {
      if (cancelRef.current) return;
      delayTimer = setTimeout(() => {
        if (cancelRef.current) return;
        const voices = window.speechSynthesis.getVoices();
        const { voice, isFallback } = selectPremiumVoice(voices);
        const u = new SpeechSynthesisUtterance(CYBERSUIT_SPEECH);
        u.rate  = 0.82;
        u.pitch = 1.02;
        u.lang  = 'en-US';
        if (voice) u.voice = voice;
        if (isFallback) { u.lang = 'en-US'; u.pitch = 1.05; }
        u.onstart = () => setSpeaking(true);
        u.onend   = () => setSpeaking(false);
        u.onerror = () => setSpeaking(false);
        window.speechSynthesis.speak(u);
      }, 600);
    });

    return () => {
      cancelRef.current = true;
      if (delayTimer) clearTimeout(delayTimer);
      window.speechSynthesis?.cancel();
    };
  }, []);

  return (
    <div className="csv-root">
      {/* Background grid */}
      <div className="csv-bg" aria-hidden="true">
        <div className="csv-bg__grid" />
        <div className="csv-bg__glow" />
      </div>

      {/* ── Header ── */}
      <div className="csv-header w-full max-w-[1600px] mx-auto px-6">
        <div className="csv-header__badge">
          <span className="csv-header__dot" />
          MODULE 19 · FASE 3 DEVELOPMENT PIPELINE
        </div>
        <h1 className="csv-header__title">Aippie Cyber-Suit & Bio-Defense Infrastructure</h1>
        <p className="csv-header__sub">Personal Physical Guardian · AIPPIETAX S.A. · v211</p>
      </div>

      {/* ── Body: wireframe left, features right ── */}
      <div className="csv-body w-full max-w-[1600px] mx-auto px-6">

        {/* Left — SVG humanoid */}
        <div className="csv-panel csv-panel--left">
          <div className="csv-panel__label">
            <ShieldCheck size={12} />
            Dermal Biometric Sensor Alignment
          </div>
          <div className="csv-wireframe-wrap">
            <HumanoidWireframe tick={tick} />
          </div>
          <div className="csv-sensor-legend">
            {NODE_POSITIONS.slice(0, 5).map(n => (
              <div key={n.label} className="csv-sensor-legend__item">
                <span className="csv-sensor-legend__dot" />
                {n.label}
              </div>
            ))}
            <div className="csv-sensor-legend__more">+{NODE_POSITIONS.length - 5} sensors active</div>
          </div>
        </div>

        {/* Right — pipeline features */}
        <div className="csv-panel csv-panel--right">
          <div className="csv-panel__label">
            <Activity size={12} />
            Fase 3 Development Pipeline
          </div>

          {PIPELINE_FEATURES.map(f => (
            <div key={f.label} className="csv-feature" style={{ '--csf-color': f.color } as React.CSSProperties}>
              <div className="csv-feature__header">
                <span className="csv-feature__emoji">{f.emoji}</span>
                <div className="csv-feature__title-wrap">
                  <span className="csv-feature__title">{f.label}</span>
                  <span className="csv-feature__status">{f.status}</span>
                </div>
                <span className="csv-feature__icon">{f.icon}</span>
              </div>
              <p className="csv-feature__desc">{f.description}</p>
              {/* Animated progress bar */}
              <div className="csv-feature__bar-track">
                <div className="csv-feature__bar-fill" />
              </div>
            </div>
          ))}

          {/* Config controls */}
          <div className="csv-config">
            <div className="csv-config__row">
              <span className="csv-config__label">Bio-Filtration</span>
              <button className={`csv-toggle${bioFilter ? ' csv-toggle--on' : ''}`} onClick={() => setBioFilter(f => !f)}>
                {bioFilter ? 'ON' : 'OFF'}
              </button>
            </div>
            <div className="csv-config__row">
              <span className="csv-config__label">Neural Sync</span>
              <button className={`csv-toggle${neuralSync ? ' csv-toggle--on' : ''}`} onClick={() => setNeuralSync(s => !s)}>
                {neuralSync ? 'ON' : 'OFF'}
              </button>
            </div>
            <div className="csv-config__row">
              <span className="csv-config__label">Power Mode</span>
              <select className="csv-select" value={powerMode} onChange={e => setPowerMode(e.target.value as typeof powerMode)}>
                {['ECO','NORMAL','PERFORMANCE','MAX'].map(m => <option key={m} value={m}>{m}</option>)}
              </select>
            </div>
            <button className="csv-save-btn" onClick={handleSave}>
              {saved ? <><Check size={12} /> Opgeslagen</> : <><Save size={12} /> Instellingen opslaan</>}
            </button>
          </div>

          {/* Compliance badges */}
          <div className="csv-compliance">
            {['ISO 13485', 'HIPAA', 'CE Mark', 'FDA Class II Prep'].map(b => (
              <span key={b} className="csv-compliance__badge">{b}</span>
            ))}
          </div>
        </div>
      </div>

      {/* ── Typewriter subtitle bar ── */}
      <div className="csv-subtitle-bar w-full max-w-[1600px] mx-auto px-6">
        <div className="csv-subtitle-bar__inner">
          {speaking && <span className="csv-subtitle-bar__pulse" aria-hidden="true" />}
          <span className="csv-subtitle-bar__text">
            {subtitle || <span className="csv-subtitle-bar__idle">Initializing Aippie Cyber-Suit…</span>}
          </span>
          {speaking && <span className="csv-subtitle-bar__cursor" aria-hidden="true" />}
        </div>
      </div>

      {/* ── Footer ── */}
      <div className="csv-footer w-full max-w-[1600px] mx-auto px-6">
        <Building2 size={9} />
        <span>AIPPIETAX S.A.</span>
        <span className="csv-footer__sep">·</span>
        <span>Aippie Cyber-Suit Module 19</span>
        <span className="csv-footer__sep">·</span>
        <span>Fase 3 Development Pipeline</span>
        <span className="csv-footer__sep">·</span>
        <span>v211</span>
      </div>
    </div>
  );
}
