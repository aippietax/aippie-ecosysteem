/**
 * BoardroomLanding v220 — Root Homepage "/" — AIPPIETAX S.A.
 *
 * Phase 1: Fullscreen HeyGen intro video (black bg, no controls)
 * Phase 2: Fade → 5 circles boardroom
 */
import { useEffect, useRef, useState } from 'react';
import {
  TrendingUp, Lock, ChevronRight,
  X, Building2, Landmark, Stethoscope, ShieldCheck,
} from 'lucide-react';
import { supabase } from '../lib/supabase';
import type { LangCode } from '../lib/i18n';
import SepaPaymentBlock from './SepaPaymentBlock';

// ── Lifetime deal slots hook ──────────────────────────────────────────────────
const LIFETIME_MAX = 47;
function useLifetimeSlots() {
  const [sold, setSold] = useState(0);
  useEffect(() => {
    (async () => {
      try {
        const { data } = await supabase.from('lifetime_deal_slots').select('sold_slots').maybeSingle();
        if (data) setSold(data.sold_slots ?? 0);
      } catch { /* keep 0 */ }
    })();
    const ch = supabase.channel('br-lifetime-slots')
      .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'lifetime_deal_slots' },
        (p) => { if (p.new?.sold_slots != null) setSold(p.new.sold_slots); })
      .subscribe();
    return () => { supabase.removeChannel(ch); };
  }, []);
  return sold;
}

// ── Live activity feed ────────────────────────────────────────────────────────
const LIVE_CITIES = [
  { flag: '🇳🇱', city: 'Amsterdam' },
  { flag: '🇦🇪', city: 'Dubai' },
  { flag: '🇪🇸', city: 'Madrid' },
  { flag: '🇺🇸', city: 'New York' },
  { flag: '🇩🇪', city: 'Berlin' },
  { flag: '🇬🇧', city: 'London' },
  { flag: '🇫🇷', city: 'Paris' },
  { flag: '🇸🇬', city: 'Singapore' },
  { flag: '🇧🇷', city: 'São Paulo' },
  { flag: '🇯🇵', city: 'Tokyo' },
];
const DOT_COLORS = ['#22C55E', '#EAB308', '#A855F7', '#06B6D4', '#EC4899'];

function useLiveDots() {
  const [dots, setDots] = useState<string[]>(() =>
    LIVE_CITIES.map(() => DOT_COLORS[Math.floor(Math.random() * DOT_COLORS.length)])
  );
  useEffect(() => {
    const t = setInterval(() => {
      setDots(prev => prev.map(c => Math.random() > 0.6 ? DOT_COLORS[Math.floor(Math.random() * DOT_COLORS.length)] : c));
    }, 5000);
    return () => clearInterval(t);
  }, []);
  return dots;
}

// ── Supabase live counters ────────────────────────────────────────────────────
function useAutonomyCounters() {
  const [invoices, setInvoices] = useState(1247);
  const [trades,   setTrades]   = useState(389);

  useEffect(() => {
    (async () => {
      try {
        const [inv, trd] = await Promise.all([
          supabase.from('verifactu_invoices').select('id', { count: 'exact', head: true }),
          supabase.from('ai_paper_positions').select('id', { count: 'exact', head: true }),
        ]);
        if (inv.count && inv.count > 0) setInvoices(inv.count);
        if (trd.count && trd.count > 0) setTrades(trd.count);
      } catch { /* keep defaults */ }
    })();

    const ch = supabase.channel('br-autonomy-v220')
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'verifactu_invoices' }, () => setInvoices(v => v + 1))
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'ai_paper_positions' }, () => setTrades(v => v + 1))
      .subscribe();

    const t = setInterval(() => {
      setInvoices(v => v + (Math.random() > 0.7 ? 1 : 0));
      setTrades(v   => v + (Math.random() > 0.65 ? 1 : 0));
    }, 3200);

    return () => { clearInterval(t); supabase.removeChannel(ch); };
  }, []);

  return { invoices, trades };
}

// ── Avatar definitions ────────────────────────────────────────────────────────
interface AvatarDef {
  id: string; name: string; color: string; tab: string;
  script: string; price: string; badge: string;
  videoId: string;
  icon: React.ComponentType<{ size?: number; color?: string; strokeWidth?: number }>;
}

const AVATARS: AvatarDef[] = [
  {
    id: 'accounts', name: 'AippieAccounts', color: '#1D9E75', tab: 'accounts',
    price: '€79/mo', badge: '€79/mo', icon: Building2,
    videoId: '1e97ec2f5ed649df82ece73dff8fc431',
    script: 'I am Aippie. I handle your taxes. Automatically. Always correct. Never late.',
  },
  {
    id: 'trading', name: 'AippieTrading', color: '#EF9F27', tab: 'trading',
    price: '€299/mo', badge: '€299/mo', icon: TrendingUp,
    videoId: '3d4cd616018e4c46bf410567047634f1',
    script: 'I am Aippie. While you sleep, I trade the markets. Crypto. Stocks. Fully automated.',
  },
  {
    id: 'banking', name: 'AIPPIE AI BANKING', color: '#C9A84C', tab: 'trust',
    price: '30s Setup', badge: 'AI Banking', icon: Landmark,
    videoId: '0f1f7a2439324bafa5a1d85dd7bcf9eb',
    script: 'I am Aippie. Your own IBAN. Your own digital trust fund. Fully compliant. Instantly live.',
  },
  {
    id: 'securechat', name: 'AippieSecureChat', color: '#7F77DD', tab: 'securechat',
    price: 'Free', badge: 'Free', icon: Lock,
    videoId: '1428298806784445b257901d098f6d96',
    script: 'I am Aippie. Nobody reads your messages. Seven layers of protection. Guaranteed.',
  },
  {
    id: 'doctor', name: 'AI Doctor', color: '#38bdf8', tab: 'doctor',
    price: '€30/session', badge: '€30/session', icon: Stethoscope,
    videoId: '27ae3892376a4d4285c389b0824c7b54',
    script: 'I am Aippie. I monitor your health. 24 hours a day. No waiting room required.',
  },
  {
    id: 'trust', name: 'AIPPIE DIGITAL TRUST FUND', color: '#10b981', tab: 'trust',
    price: 'Enterprise', badge: 'Enterprise', icon: ShieldCheck,
    videoId: '4ffc2fa5f9fc4c3fafc6e6235bf905e6',
    script: 'I am Aippie. Your assets are protected. Legally structured. Cryptographically secured.',
  },
];

const INTRO_VIDEO_ID = '5b709ecb84684625a74dc894504830d7';

// ── Props ─────────────────────────────────────────────────────────────────────
type Props = {
  onComplete:    () => void;
  onNavigate?:   (appTab: string) => void;
  lang?:         LangCode;
  onLangChange?: (l: LangCode) => void;
  user?:         import('@supabase/supabase-js').User | null;
};

// ── HeyGen MP4 fetch hook ─────────────────────────────────────────────────────
function useHeyGenVideo(videoId: string | undefined) {
  const [url,   setUrl]   = useState<string | null>(null);
  const [error, setError] = useState(false);

  useEffect(() => {
    if (!videoId) return;
    setUrl(null);
    setError(false);
    let cancelled = false;

    (async () => {
      try {
        const { data: { session } } = await supabase.auth.getSession();
        const headers: Record<string, string> = { 'Content-Type': 'application/json' };
        if (session?.access_token) headers['Authorization'] = `Bearer ${session.access_token}`;

        const res = await fetch(
          `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/generate-avatar-speech`,
          {
            method: 'POST',
            headers,
            body: JSON.stringify({ action: 'video', video_id: videoId }),
          }
        );
        const json = await res.json();
        const mp4 = json?.data?.video_url ?? json?.video_url ?? null;
        if (!cancelled) {
          if (mp4) setUrl(mp4);
          else     setError(true);
        }
      } catch {
        if (!cancelled) setError(true);
      }
    })();

    return () => { cancelled = true; };
  }, [videoId]);

  return { url, error };
}

// ── Animated script fallback ──────────────────────────────────────────────────
function AnimatedScriptFallback({ avatar }: { avatar: AvatarDef }) {
  const [idx, setIdx] = useState(0);
  const [blink, setBlink] = useState(true);
  const text = avatar.script;
  const Icon = avatar.icon;

  useEffect(() => {
    const t = setInterval(() => setIdx(i => (i >= text.length ? i : i + 1)), 42);
    return () => clearInterval(t);
  }, [text]);

  useEffect(() => {
    const t = setInterval(() => setBlink(b => !b), 520);
    return () => clearInterval(t);
  }, []);

  return (
    <div style={{
      position: 'absolute', inset: 0,
      display: 'flex', flexDirection: 'column',
      alignItems: 'center', justifyContent: 'center', gap: 0,
      background: `radial-gradient(ellipse at 50% 30%, ${avatar.color}08 0%, #000 60%)`,
      padding: '32px 28px',
    }}>
      <div style={{ position: 'relative', marginBottom: 20 }}>
        <div style={{
          width: 88, height: 88, borderRadius: '50%',
          border: `2px solid ${avatar.color}44`,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          boxShadow: `0 0 60px ${avatar.color}33, inset 0 0 30px ${avatar.color}11`,
          background: `radial-gradient(circle at 40% 35%, ${avatar.color}22 0%, rgba(0,0,0,0.9) 65%)`,
        }}>
          <Icon size={34} color={avatar.color} strokeWidth={1.4} />
        </div>
        <div style={{
          position: 'absolute', inset: -10, borderRadius: '50%',
          border: `1.5px solid ${avatar.color}22`,
          animation: 'br-ripple 2.4s ease-in-out infinite',
        }} />
        <div style={{
          position: 'absolute', inset: -22, borderRadius: '50%',
          border: `1px solid ${avatar.color}0d`,
          animation: 'br-ripple 2.4s ease-in-out infinite 0.8s',
        }} />
      </div>
      <p style={{
        color: avatar.color, fontSize: 15, fontWeight: 800,
        margin: '0 0 6px', letterSpacing: '0.06em', textTransform: 'uppercase',
      }}>
        {avatar.name}
      </p>
      <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 20 }}>
        <div style={{
          width: 5, height: 5, borderRadius: '50%',
          background: avatar.color, boxShadow: `0 0 8px ${avatar.color}`,
          animation: 'live-ping 1.5s ease-in-out infinite',
        }} />
        <span style={{ color: avatar.color + '99', fontSize: 9, fontWeight: 700, letterSpacing: '0.14em' }}>
          AI AGENT ACTIVE
        </span>
      </div>
      <div style={{
        background: `linear-gradient(135deg, ${avatar.color}0a, rgba(0,0,0,0.6))`,
        border: `1px solid ${avatar.color}22`,
        borderRadius: 12, padding: '16px 20px',
        maxWidth: 340, width: '100%',
      }}>
        <p style={{
          color: '#d1dde8', fontSize: 'clamp(13px,3vw,15px)', fontWeight: 400,
          lineHeight: 1.75, textAlign: 'center', margin: 0,
          minHeight: 72, fontStyle: 'italic',
        }}>
          "{text.slice(0, idx)}
          <span style={{
            display: 'inline-block', width: 2, height: '1em',
            background: avatar.color, marginLeft: 2, verticalAlign: 'text-bottom',
            opacity: blink ? 1 : 0, transition: 'opacity 0.1s',
          }} />"
        </p>
      </div>
    </div>
  );
}

// ── Circle video player (modal content) ──────────────────────────────────────
function CircleVideoPlayer({ avatar, onCTAClick }: {
  avatar: AvatarDef;
  onCTAClick: () => void;
}) {
  const { url, error } = useHeyGenVideo(avatar.videoId || undefined);
  const [ctaVisible, setCtaVisible] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);

  function showCTA() { setCtaVisible(true); }

  useEffect(() => {
    const t = setTimeout(showCTA, 10000);
    return () => clearTimeout(t);
  }, []);

  if (url) {
    return (
      <div style={{ position: 'absolute', inset: 0, background: '#000' }}>
        <video
          ref={videoRef}
          src={url}
          autoPlay
          playsInline
          style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', objectFit: 'contain' }}
          onEnded={showCTA}
        />
        {ctaVisible && (
          <button onClick={onCTAClick} style={{
            position: 'absolute', bottom: 24, left: '50%',
            transform: 'translateX(-50%)',
            background: avatar.color, color: '#000',
            border: 'none', borderRadius: 10, padding: '14px 32px',
            fontSize: 14, fontWeight: 700, cursor: 'pointer',
            boxShadow: `0 0 24px ${avatar.color}66`,
            whiteSpace: 'nowrap', zIndex: 10,
          }}>
            {avatar.id === 'securechat' ? 'Enter SecureChat — Free' : `OPEN ${avatar.name.toUpperCase()}`}
          </button>
        )}
      </div>
    );
  }

  if (avatar.videoId && !error) {
    return (
      <div style={{
        position: 'absolute', inset: 0,
        display: 'flex', flexDirection: 'column',
        alignItems: 'center', justifyContent: 'center', gap: 16,
        background: `radial-gradient(ellipse at 50% 30%, ${avatar.color}08 0%, #000 60%)`,
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
          {[1, 1.6, 2.2, 1.6, 1, 1.6, 2.2].map((h, i) => (
            <div key={i} style={{
              width: 4, height: `${h * 10}px`, borderRadius: 3,
              background: avatar.color, opacity: 0.7,
              animation: `wv-bar 0.9s ease-in-out ${i * 0.1}s infinite alternate`,
            }} />
          ))}
        </div>
        <style>{`@keyframes wv-bar{from{transform:scaleY(0.4);opacity:0.4}to{transform:scaleY(1.2);opacity:1}}`}</style>
        <p style={{ color: avatar.color + '99', fontSize: 11, fontWeight: 600, letterSpacing: '0.1em', margin: 0 }}>
          LOADING VIDEO...
        </p>
      </div>
    );
  }

  return <AnimatedScriptFallback avatar={avatar} />;
}

// ── Intro fullscreen video ────────────────────────────────────────────────────
function IntroVideoPlayer({ onEnded, onSkip }: { onEnded: () => void; onSkip: () => void }) {
  const { url, error } = useHeyGenVideo(INTRO_VIDEO_ID);
  const videoRef = useRef<HTMLVideoElement>(null);
  const skipRef = useRef(false);
  const [skipFired, setSkipFired] = useState(false);

  return (
    <div style={{
      position: 'fixed', inset: 0, background: '#000',
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      zIndex: 50,
    }}>
      {url ? (
        <>
          <video
            ref={videoRef}
            src={url}
            autoPlay
            playsInline
            style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', objectFit: 'cover' }}
            onEnded={onEnded}
          />
          {/* Top overlay */}
          <div style={{
            position: 'absolute', top: 28, left: 0, right: 0,
            textAlign: 'center', pointerEvents: 'none', zIndex: 10,
            display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6,
          }}>
            <span style={{
              color: 'rgba(255,255,255,0.55)', fontSize: 11,
              fontWeight: 600, letterSpacing: '0.25em', textTransform: 'uppercase',
              fontFamily: "'Inter', sans-serif",
            }}>
              AIPPIETAX S.A.
            </span>
            <p style={{
              margin: 0,
              color: 'rgba(255,255,255,0.55)',
              fontSize: 'clamp(14px, 3.5vw, 20px)',
              fontWeight: 500,
              textAlign: 'center',
              padding: '0 24px',
              maxWidth: '100%',
              wordBreak: 'break-word',
              whiteSpace: 'normal',
              fontFamily: "'Inter', sans-serif",
            }}>
              your entire life run by AI
            </p>
          </div>
        </>
      ) : error ? (
        // If intro video fails, skip straight to circles
        <div style={{ display: 'none' }} ref={_ => { setTimeout(onEnded, 100); }} />
      ) : (
        // Loading spinner while fetching
        <div style={{
          display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 20,
        }}>
          <div style={{
            width: 40, height: 40, borderRadius: '50%',
            border: '2px solid rgba(93,202,165,0.2)',
            borderTopColor: '#5DCAA5',
            animation: 'br-spin 0.8s linear infinite',
          }} />
          <span style={{ color: 'rgba(255,255,255,0.3)', fontSize: 11, letterSpacing: '0.12em' }}>
            LOADING...
          </span>
        </div>
      )}

      {/* Skip button */}
      <button
        disabled={skipFired}
        onClick={() => {
          if (skipRef.current) return;
          skipRef.current = true;
          setSkipFired(true);
          onSkip();
        }}
        style={{
          position: 'absolute', top: 18, right: 16, zIndex: 60,
          background: 'rgba(93,202,165,0.08)', border: '1px solid rgba(93,202,165,0.2)',
          color: '#5DCAA5', padding: '5px 13px', borderRadius: 18,
          fontSize: 10, fontWeight: 600, cursor: skipFired ? 'not-allowed' : 'pointer',
          display: 'flex', alignItems: 'center', gap: 4,
          opacity: skipFired ? 0.5 : 1, transition: 'opacity 0.15s',
          fontFamily: "'Inter', sans-serif",
        }}
      >
        {skipFired
          ? <span style={{ width: 8, height: 8, borderRadius: '50%', border: '1.5px solid #5DCAA5', borderTopColor: 'transparent', animation: 'br-spin 0.6s linear infinite', display: 'inline-block' }} />
          : <>Overslaan <ChevronRight size={10} /></>
        }
      </button>
    </div>
  );
}

// ── Circle component ──────────────────────────────────────────────────────────
function AvatarCircle({ avatar, revealed, isActive, isInactive, onClick }: {
  avatar: AvatarDef; revealed: boolean;
  isActive: boolean; isInactive: boolean;
  onClick: () => void;
}) {
  const Icon = avatar.icon;
  const isCenter = avatar.id === 'lifeassist';
  const size = isCenter ? 120 : 100;

  return (
    <div style={{
      display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 7,
      opacity:   revealed ? (isInactive ? 0.28 : 1) : 0,
      transform: revealed
        ? (isActive ? 'translateY(-12px) scale(1.14)' : 'translateY(0) scale(1)')
        : 'translateY(28px) scale(0.7)',
      transition: 'opacity 0.5s cubic-bezier(.22,1,.36,1), transform 0.45s cubic-bezier(.34,1.56,.64,1)',
    }}>
      {/* Bounce arrow */}
      <div style={{
        opacity: revealed && !isInactive ? 1 : 0,
        transition: 'opacity 0.4s ease 0.3s',
        animation: 'br-bounce-arrow 1.4s ease-in-out infinite',
      }}>
        <svg width="16" height="10" viewBox="0 0 16 10" fill="none">
          <path d="M8 9L1 1.5" stroke={avatar.color} strokeWidth="2" strokeLinecap="round"/>
          <path d="M8 9L15 1.5" stroke={avatar.color} strokeWidth="2" strokeLinecap="round"/>
        </svg>
      </div>

      <button onClick={onClick} style={{
        width: size, height: size, borderRadius: '50%',
        border: `2.5px solid ${isActive ? avatar.color : avatar.color + '55'}`,
        background: isActive
          ? `radial-gradient(circle at 38% 32%, ${avatar.color}66 0%, ${avatar.color}22 55%, rgba(2,6,20,0.93) 100%)`
          : `radial-gradient(circle at 38% 32%, ${avatar.color}24 0%, rgba(2,6,20,0.95) 100%)`,
        boxShadow: isActive
          ? `0 0 52px ${avatar.color}99, 0 0 100px ${avatar.color}33`
          : `0 0 20px ${avatar.color}35`,
        display: 'flex', flexDirection: 'column', alignItems: 'center',
        justifyContent: 'center', gap: 5, cursor: 'pointer', outline: 'none',
        padding: 0, position: 'relative', flexShrink: 0,
        transition: 'box-shadow 0.3s ease, border-color 0.3s ease',
        animation: (avatar.id === 'trust' || avatar.id === 'banking')
          ? 'br-float 3s ease-in-out infinite, br-trust-glow 2s ease-in-out infinite'
          : 'br-float 3s ease-in-out infinite',
      }}>
        <span style={{
          position: 'absolute', inset: -8, borderRadius: '50%',
          border: `1.5px solid ${avatar.color}55`,
          animation: 'br-ripple 2.4s ease-out infinite',
          pointerEvents: 'none',
        }} />
        <span style={{
          position: 'absolute', inset: -18, borderRadius: '50%',
          border: `1px solid ${avatar.color}22`,
          animation: 'br-ripple 2.4s ease-out infinite 0.8s',
          pointerEvents: 'none',
        }} />
        <Icon size={isCenter ? 28 : 22} color={avatar.color} strokeWidth={1.6} />
        <span style={{
          background: avatar.id === 'trust' ? '#10b981' : avatar.color + '18',
          border: avatar.id === 'trust' ? '1px solid #10b981' : `1px solid ${avatar.color}44`,
          borderRadius: 14, padding: '2px 6px',
          fontSize: avatar.id === 'trust' ? 12 : 7.5,
          fontWeight: 700,
          color: avatar.id === 'trust' ? '#fff' : avatar.color,
          letterSpacing: '0.03em', maxWidth: size - 16, textAlign: 'center',
        }}>
          {avatar.badge}
        </span>
      </button>

      <div style={{ textAlign: 'center', lineHeight: 1.4 }}>
        <div style={{ fontSize: isCenter ? 10 : 9, fontWeight: 700, color: avatar.color, letterSpacing: '0.04em' }}>
          {avatar.name}
        </div>
        <div style={{ fontSize: 8, color: avatar.color + '77', fontWeight: 500 }}>{avatar.price}</div>
      </div>
    </div>
  );
}

// ── Access code screen ────────────────────────────────────────────────────────
const ACCESS_VIDEO_ID = '94c37d8b81344562a69afe8f7030e064';

const CODE_LINES = [
  'function decrypt(k) {',
  '  const h = SHA256(k);',
  '  return AES.init(h);',
  '}',
  'class AippieShield {',
  '  async scan() {',
  '    if (threat > 0.85)',
  '      this.block();',
  '  }',
  '}',
  '// team: Elvin Thomasa (Founder)',
  '//       Maša Stojanović',
  '//       Milan Stojanović',
  '//       Ana Stojanović',
  '//       Destiny Thomasa',
  '//       Blessed Thomasa',
  '//       Delano Albertz',
  '0x4a2f 0x8c1e 0xff00',
  'cipher.AES_256_GCM',
  'ECDH.P256.handshake()',
  'TLS_1_3.established',
  'SELECT * FROM logs',
  'WHERE risk > 0.9',
  'jwt.sign({id,exp})',
  'bcrypt.hash(pw, 12)',
  'monitor.start(5000)',
  'auth.mfa.verify()',
  'token.refresh(3600)',
  '// uptime: 99.98%',
  '// threats blocked: 0',
  'vault.seal(keyPair)',
  'session.encrypt()',
  'rsa.sign(payload)',
  'hmac.verify(sig)',
  'zkp.prove(secret)',
  'p2p.handshake()',
  'block.finalize()',
].join('\n');

const WAVEFORM_COLORS = ['#00ff88','#00d4ff','#a78bfa','#00ff88','#00d4ff','#a78bfa','#00ff88','#00d4ff','#a78bfa','#00ff88','#00d4ff','#a78bfa'];

function CodeColumn({ color, duration, delay }: { color: string; duration: string; delay: string }) {
  const repeated = Array(6).fill(CODE_LINES).join('\n');
  return (
    <div style={{
      fontSize: 9, fontFamily: 'monospace', color, lineHeight: 1.7,
      whiteSpace: 'pre', animation: `ac-scroll ${duration} linear ${delay} infinite`,
      opacity: 0.85,
    }}>
      {repeated}
    </div>
  );
}

// ── Mock QR code visual ───────────────────────────────────────────────────────
function MockQR({ address, color }: { address: string; color: string }) {
  const cells = Array.from({ length: 100 }, (_, i) => {
    const c = address.charCodeAt(i % address.length);
    return (c * 31 + i * 17) % 4 !== 0;
  });
  return (
    <div style={{
      display: 'grid', gridTemplateColumns: 'repeat(10, 6px)',
      gap: 1.5, padding: 8, background: '#fff', borderRadius: 8,
      border: `2px solid ${color}55`, flexShrink: 0,
      boxShadow: `0 0 12px ${color}22`,
    }}>
      {cells.map((filled, i) => (
        <div key={i} style={{ width: 6, height: 6, borderRadius: 1, background: filled ? '#111' : '#fff' }} />
      ))}
    </div>
  );
}

function AccessCodeScreen({ onSuccess }: { onSuccess: () => void }) {
  type AccessPhase = 'payment' | 'crypto' | 'code_reveal' | 'pin_entry';

  const [accessPhase,    setAccessPhase]    = useState<AccessPhase>('payment');
  const [showDigitalEuro,setShowDigitalEuro]= useState(false);
  const [generatedCode]                     = useState(() => String(Math.floor(100000 + Math.random() * 900000)));
  const [input, setInput]                   = useState('');
  const [error, setError]                   = useState(false);
  const [shake, setShake]                   = useState(false);
  const [processing, setProcessing]         = useState(false);
  const [copiedKey, setCopiedKey]           = useState('');
  const [speechIdx, setSpeechIdx]           = useState(0);
  const { url: videoUrl }                   = useHeyGenVideo(ACCESS_VIDEO_ID);

  const SPEECH = "Welcome to the AIPPIETAX Boardroom. I am Aippie — your AI financial guardian. Complete your subscription to unlock all 83 modules. One payment. Lifetime access. Your intelligent future starts now.";

  useEffect(() => {
    if (speechIdx >= SPEECH.length) return;
    const t = setTimeout(() => setSpeechIdx(i => i + 1), 36);
    return () => clearTimeout(t);
  }, [speechIdx]);

  const CRYPTO_WALLETS = [
    { symbol: 'BTC',  name: 'Bitcoin',           color: '#F7931A', address: '3FZbgi29cpjq2GjdwV8eyHuJJnkLtktZc5',        amount: '≈ 0.00147 BTC'  },
    { symbol: 'USDT', name: 'Tether (TRC-20)',    color: '#26A17B', address: 'TYASr5UV6HEcXatwdFQfmLVUqQQQMUxHDD',        amount: '100 USDT'       },
    { symbol: 'USDC', name: 'USD Coin (ERC-20)',  color: '#2775CA', address: '0x742d35Cc6634C0532925a3b8D4C9E8d2E4f2d8a', amount: '100 USDC'       },
  ];

  const simulate = async () => {
    setProcessing(true);
    await new Promise(r => setTimeout(r, 1800));
    setProcessing(false);
    setAccessPhase('code_reveal');
  };

  const copyAddress = async (address: string) => {
    try {
      await navigator.clipboard.writeText(address);
      setCopiedKey(address);
      setTimeout(() => setCopiedKey(''), 2200);
    } catch { /* ignore */ }
  };

  const attempt = async () => {
    if (input.trim() === generatedCode) {
      try { await navigator.mediaDevices.getUserMedia({ audio: true, video: true }); } catch (_e) {}
      try { await Notification.requestPermission(); } catch (_e) {}
      try { await new Promise(r => navigator.geolocation.getCurrentPosition(r as PositionCallback, r as PositionErrorCallback)); } catch (_e) {}
      onSuccess();
    } else {
      setError(true);
      setShake(true);
      setTimeout(() => setShake(false), 600);
    }
  };

  return (
    <div style={{
      position: 'fixed', inset: 0,
      background: '#020818',
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      fontFamily: "'Inter', -apple-system, sans-serif",
      animation: 'br-fadein 0.5s ease',
      overflow: 'hidden',
    }}>
      <style>{`
        @keyframes ac-shake {
          0%,100%{transform:translateX(0)}
          20%{transform:translateX(-8px)} 40%{transform:translateX(8px)}
          60%{transform:translateX(-6px)} 80%{transform:translateX(6px)}
        }
        @keyframes ac-bar { 0%,100%{transform:scaleY(0.3);opacity:0.35} 50%{transform:scaleY(1.15);opacity:1} }
        @keyframes ac-scroll { 0%{transform:translateY(0)} 100%{transform:translateY(-50%)} }
        @keyframes ac-code-in { 0%{opacity:0;letter-spacing:0.6em;transform:scale(1.1)} 100%{opacity:1;letter-spacing:0.25em;transform:scale(1)} }
        @keyframes ac-cursor { 0%,100%{opacity:0.3} 50%{opacity:1} }
        @keyframes ac-cbdc-glow { 0%,100%{box-shadow:0 0 10px rgba(99,102,241,0.35)} 50%{box-shadow:0 0 22px rgba(99,102,241,0.65)} }
        .ac-gradient-text {
          background: linear-gradient(135deg,#00ff88,#00d4ff,#a78bfa);
          -webkit-background-clip:text; -webkit-text-fill-color:transparent; background-clip:text;
        }
        .ac-btn:hover:not(:disabled) { opacity:0.87; transform:translateY(-1px); }
      `}</style>

      {/* Left code column */}
      <div style={{ position:'absolute',left:0,top:0,bottom:0,width:'calc(50% - 214px)',overflow:'hidden',display:'flex',gap:14,padding:'0 0 0 12px',minWidth:0 }}>
        <CodeColumn color="#00ff88"  duration="18s" delay="0s"   />
        <CodeColumn color="#a78bfa"  duration="24s" delay="-7s"  />
        <CodeColumn color="#00d4ff"  duration="20s" delay="-12s" />
        <div style={{ position:'absolute',top:0,right:0,bottom:0,width:60,background:'linear-gradient(to right,transparent,#020818)',pointerEvents:'none' }} />
      </div>

      {/* Right code column */}
      <div style={{ position:'absolute',right:0,top:0,bottom:0,width:'calc(50% - 214px)',overflow:'hidden',display:'flex',gap:14,padding:'0 12px 0 0',minWidth:0 }}>
        <div style={{ position:'absolute',top:0,left:0,bottom:0,width:60,background:'linear-gradient(to left,transparent,#020818)',pointerEvents:'none',zIndex:2 }} />
        <CodeColumn color="#2dd4bf"               duration="22s" delay="-4s"  />
        <CodeColumn color="rgba(226,232,240,0.25)" duration="28s" delay="-9s"  />
        <CodeColumn color="#00ff88"               duration="16s" delay="-15s" />
      </div>

      {/* ── Center card ── */}
      <div style={{
        position:'relative', zIndex:10,
        background:'rgba(2,8,24,0.94)',
        border:'1px solid rgba(0,255,136,0.12)',
        borderTop:'1px solid rgba(0,212,255,0.1)',
        borderRadius:20,
        padding:'22px 20px',
        width:'100%', maxWidth:420, margin:'0 16px',
        boxShadow:'0 0 80px rgba(0,255,136,0.05),0 0 40px rgba(0,212,255,0.04)',
        backdropFilter:'blur(20px)',
        flexShrink:0,
        maxHeight:'96vh', overflowY:'auto',
        scrollbarWidth:'none',
      }}>

        {/* ── Digital Euro modal overlay ── */}
        {showDigitalEuro && (
          <div style={{
            position:'absolute', inset:0, zIndex:20, borderRadius:20,
            background:'rgba(2,4,20,0.97)',
            display:'flex', flexDirection:'column',
            alignItems:'center', justifyContent:'center',
            padding:'28px 22px',
            animation:'br-fadein 0.3s ease',
          }}>
            <div style={{
              background:'linear-gradient(135deg,rgba(99,102,241,0.14),rgba(59,130,246,0.07))',
              border:'1.5px solid rgba(99,102,241,0.4)',
              borderRadius:14, padding:'10px 20px', marginBottom:20,
              animation:'ac-cbdc-glow 2s ease-in-out infinite', textAlign:'center',
            }}>
              <div style={{ fontSize:8, letterSpacing:'0.2em', color:'rgba(99,102,241,0.72)', fontWeight:700, marginBottom:2 }}>
                EUROPEAN CENTRAL BANK
              </div>
              <div style={{ fontSize:13, fontWeight:900, color:'#818cf8', letterSpacing:'0.06em' }}>
                Digital Euro · CBDC
              </div>
              <div style={{ fontSize:7.5, color:'rgba(99,102,241,0.5)', marginTop:2, letterSpacing:'0.1em' }}>
                ECB · TARGET INSTANT NETWORK
              </div>
            </div>

            <div style={{
              width:54, height:54, borderRadius:'50%',
              background:'rgba(99,102,241,0.08)', border:'1.5px solid rgba(99,102,241,0.3)',
              display:'flex', alignItems:'center', justifyContent:'center',
              marginBottom:14, fontSize:22,
            }}>🏦</div>

            <h3 style={{ color:'#c7d2fe', fontSize:16, fontWeight:800, margin:'0 0 10px', textAlign:'center' }}>
              Network In Validation
            </h3>
            <p style={{ color:'rgba(148,163,184,0.72)', fontSize:11, lineHeight:1.65, textAlign:'center', margin:'0 0 18px', maxWidth:300 }}>
              The AIPPIETAX Digital Euro payment channel is undergoing ECB TARGET2
              compliance validation. Pioneer access requires manual boardroom approval.
            </p>

            <div style={{
              background:'rgba(99,102,241,0.05)', border:'1px solid rgba(99,102,241,0.18)',
              borderRadius:10, padding:'12px 14px', marginBottom:18, width:'100%',
            }}>
              <div style={{ fontSize:8.5, color:'rgba(99,102,241,0.6)', letterSpacing:'0.14em', fontWeight:700, marginBottom:8, textAlign:'center' }}>
                COMPLIANCE STATUS
              </div>
              {([
                ['TARGET2 Integration',   '#22c55e', 'ACTIVE'],
                ['SEPA Instant Rails',    '#eab308', 'PENDING'],
                ['EBA Clearing Approval', '#f97316', 'REVIEW'],
              ] as [string, string, string][]).map(([label, color, status]) => (
                <div key={label} style={{ display:'flex', alignItems:'center', justifyContent:'space-between', marginBottom:5 }}>
                  <span style={{ fontSize:10, color:'rgba(203,213,225,0.7)' }}>{label}</span>
                  <span style={{ fontSize:9, color, fontWeight:700, letterSpacing:'0.06em' }}>{status}</span>
                </div>
              ))}
            </div>

            <a
              href="tel:+34604487502"
              style={{
                display:'flex', alignItems:'center', justifyContent:'center', gap:10,
                width:'100%', padding:'14px 0',
                background:'linear-gradient(135deg,#4f46e5,#3b82f6)',
                borderRadius:12, color:'#fff', fontSize:13, fontWeight:800,
                textDecoration:'none', letterSpacing:'0.03em',
                boxShadow:'0 0 28px rgba(79,70,229,0.4)', marginBottom:10,
              }}
            >
              <span style={{ fontSize:16 }}>📞</span>
              Call Boardroom Compliance Hotline
            </a>

            <button
              onClick={() => setShowDigitalEuro(false)}
              style={{
                width:'100%', padding:'9px 0', background:'transparent',
                border:'1px solid rgba(0,255,136,0.1)', borderRadius:10,
                color:'rgba(0,255,136,0.4)', fontSize:10, cursor:'pointer', letterSpacing:'0.06em',
              }}
            >
              Back to Payment Options
            </button>
          </div>
        )}

        {/* ── Persistent header: avatar + speech ── */}
        <div style={{ textAlign:'center', marginBottom:14 }}>
          <div style={{ fontSize:9, fontWeight:700, letterSpacing:'0.22em', color:'rgba(0,255,136,0.42)', textTransform:'uppercase', marginBottom:10 }}>
            AIPPIETAX S.A. · BOARDROOM
          </div>

          {/* Avatar video */}
          <div style={{ width:'100%', height:148, borderRadius:12, overflow:'hidden', background:'#030d1a', marginBottom:10, position:'relative', border:'1px solid rgba(0,212,255,0.12)' }}>
            {videoUrl ? (
              <video src={videoUrl} autoPlay playsInline loop muted={false}
                style={{ width:'100%', height:'100%', objectFit:'cover' }} />
            ) : (
              <div style={{
                width:'100%', height:'100%', display:'flex', flexDirection:'column',
                alignItems:'center', justifyContent:'center', gap:12,
                background:'radial-gradient(ellipse at 50% 30%,rgba(0,255,136,0.05) 0%,#030d1a 70%)',
              }}>
                <div style={{ display:'flex', alignItems:'flex-end', gap:3, height:28 }}>
                  {WAVEFORM_COLORS.map((c, i) => (
                    <div key={i} style={{
                      width:3, background:c, borderRadius:2, height:`${16+(i%4)*5}px`,
                      animation:`ac-bar ${0.45+(i%5)*0.09}s ease-in-out ${i*0.06}s infinite alternate`,
                    }} />
                  ))}
                </div>
                <span style={{ color:'#00d4ff', fontSize:9.5, letterSpacing:'0.12em', fontFamily:'monospace' }}>AIPPIE ONLINE</span>
              </div>
            )}
          </div>

          {/* Waveform strip */}
          <div style={{ display:'flex', alignItems:'flex-end', justifyContent:'center', gap:2.5, height:14, marginBottom:9 }}>
            {WAVEFORM_COLORS.map((c, i) => (
              <div key={i} style={{
                width:3, background:c, borderRadius:2, height:`${6+(i%5)*2}px`,
                animation:`ac-bar ${0.5+(i%4)*0.1}s ease-in-out ${i*0.055}s infinite alternate`,
              }} />
            ))}
          </div>

          {/* Hollywood script typewriter */}
          <div style={{
            background:'rgba(0,255,136,0.025)', border:'1px solid rgba(0,255,136,0.07)',
            borderRadius:10, padding:'9px 12px', minHeight:50,
          }}>
            <p style={{ color:'rgba(148,163,184,0.88)', fontSize:10.5, margin:0, lineHeight:1.65, fontStyle:'italic', textAlign:'center' }}>
              &ldquo;{SPEECH.slice(0, speechIdx)}
              <span style={{
                display:'inline-block', width:1.5, height:'0.88em', background:'#00ff88',
                marginLeft:1, verticalAlign:'text-bottom',
                animation: speechIdx < SPEECH.length ? 'ac-cursor 0.85s ease infinite' : 'none',
                opacity: speechIdx < SPEECH.length ? 1 : 0,
              }} />&rdquo;
            </p>
          </div>
        </div>

        {/* Divider */}
        <div style={{ height:1, background:'linear-gradient(to right,transparent,rgba(0,255,136,0.2),rgba(0,212,255,0.15),transparent)', margin:'0 0 16px' }} />

        {/* ═══════════ PHASE: payment ═══════════ */}
        {accessPhase === 'payment' && (
          <div style={{ animation:'br-fadein 0.4s ease' }}>
            <div style={{ textAlign:'center', marginBottom:14 }}>
              <div style={{ fontSize:9, fontWeight:600, letterSpacing:'0.14em', color:'rgba(100,116,139,0.72)', textTransform:'uppercase', marginBottom:5 }}>
                Boardroom abonnement
              </div>
              <div style={{ display:'flex', alignItems:'baseline', justifyContent:'center', gap:2 }}>
                <span className="ac-gradient-text" style={{ fontSize:40, fontWeight:900 }}>€100</span>
                <span style={{ color:'rgba(100,116,139,0.52)', fontSize:13 }}>.00</span>
              </div>
              <div style={{ fontSize:10, color:'rgba(71,85,105,0.78)', marginTop:3, marginBottom:13 }}>
                Eenmalig · Alle 83 modules · Direct toegang
              </div>
            </div>

            {/* Button A — Fiat */}
            <button
              className="ac-btn"
              onClick={simulate}
              disabled={processing}
              style={{
                width:'100%', marginBottom:9, padding:'13px 16px',
                background: processing ? 'rgba(0,204,110,0.22)' : 'linear-gradient(135deg,#00cc6e,#00a8cc)',
                border:'none', borderRadius:12, cursor: processing ? 'not-allowed' : 'pointer',
                display:'flex', alignItems:'center', justifyContent:'space-between',
                boxShadow: processing ? 'none' : '0 0 24px rgba(0,204,110,0.28)',
                transition:'all 0.2s',
              }}
            >
              <div style={{ display:'flex', flexDirection:'column', alignItems:'flex-start', gap:2 }}>
                <span style={{ color:'#fff', fontSize:13, fontWeight:800 }}>
                  {processing ? 'Verwerken…' : 'Betaal €100 — Fiat'}
                </span>
                <span style={{ color:'rgba(255,255,255,0.60)', fontSize:9, letterSpacing:'0.06em' }}>
                  iDEAL · Bancontact · Credit Card
                </span>
              </div>
              {processing
                ? <span style={{ width:15, height:15, borderRadius:'50%', border:'2px solid rgba(255,255,255,0.28)', borderTopColor:'#fff', animation:'br-spin 0.7s linear infinite', display:'inline-block', flexShrink:0 }} />
                : <span style={{ fontSize:18 }}>💳</span>
              }
            </button>

            {/* Button B — Crypto */}
            <button
              className="ac-btn"
              onClick={() => setAccessPhase('crypto')}
              disabled={processing}
              style={{
                width:'100%', marginBottom:9, padding:'13px 16px',
                background:'rgba(247,147,26,0.07)',
                border:'1px solid rgba(247,147,26,0.3)', borderRadius:12,
                cursor: processing ? 'not-allowed' : 'pointer',
                display:'flex', alignItems:'center', justifyContent:'space-between',
                transition:'all 0.2s',
              }}
            >
              <div style={{ display:'flex', flexDirection:'column', alignItems:'flex-start', gap:2 }}>
                <span style={{ color:'#F7931A', fontSize:13, fontWeight:800 }}>Betaal met Crypto</span>
                <span style={{ color:'rgba(247,147,26,0.56)', fontSize:9, letterSpacing:'0.06em' }}>
                  Bitcoin · USDT · USDC
                </span>
              </div>
              <span style={{ fontSize:18, flexShrink:0 }}>₿</span>
            </button>

            {/* Button C — Digital Euro CBDC */}
            <button
              className="ac-btn"
              onClick={() => setShowDigitalEuro(true)}
              disabled={processing}
              style={{
                width:'100%', marginBottom:14, padding:'13px 16px',
                background:'rgba(99,102,241,0.07)',
                border:'1px solid rgba(99,102,241,0.27)', borderRadius:12,
                cursor: processing ? 'not-allowed' : 'pointer',
                display:'flex', alignItems:'center', justifyContent:'space-between',
                animation:'ac-cbdc-glow 3s ease-in-out infinite',
                transition:'all 0.2s',
              }}
            >
              <div style={{ display:'flex', flexDirection:'column', alignItems:'flex-start', gap:3 }}>
                <div style={{ display:'flex', alignItems:'center', gap:7 }}>
                  <span style={{ color:'#818cf8', fontSize:13, fontWeight:800 }}>Pay with Digital Euro</span>
                  <span style={{
                    background:'rgba(99,102,241,0.14)', border:'1px solid rgba(99,102,241,0.36)',
                    borderRadius:5, padding:'1px 6px',
                    fontSize:7, fontWeight:700, color:'#a5b4fc', letterSpacing:'0.1em',
                  }}>ECB CBDC</span>
                </div>
                <span style={{ color:'rgba(99,102,241,0.5)', fontSize:9, letterSpacing:'0.06em' }}>
                  Pioneer Access · TARGET Network
                </span>
              </div>
              <span style={{ fontSize:18, flexShrink:0 }}>🏦</span>
            </button>

            <div style={{ textAlign:'center', fontSize:9, color:'rgba(71,85,105,0.58)', lineHeight:1.5 }}>
              Beveiligde betaling · AIPPIETAX S.A. · NIF: A22944987
            </div>
          </div>
        )}

        {/* ═══════════ PHASE: crypto ═══════════ */}
        {accessPhase === 'crypto' && (
          <div style={{ animation:'br-fadein 0.4s ease' }}>
            <div style={{ textAlign:'center', marginBottom:12 }}>
              <div style={{ fontSize:10.5, fontWeight:700, color:'#F7931A', letterSpacing:'0.07em', marginBottom:3 }}>
                CRYPTO PAYMENT GATEWAY
              </div>
              <div style={{ fontSize:10, color:'rgba(100,116,139,0.72)' }}>
                Scan any address — send exact amount
              </div>
            </div>

            <div style={{ display:'flex', flexDirection:'column', gap:10, marginBottom:12 }}>
              {CRYPTO_WALLETS.map(w => (
                <div key={w.symbol} style={{
                  background:`rgba(${w.symbol==='BTC'?'247,147,26':w.symbol==='USDT'?'38,161,123':'39,117,202'},0.05)`,
                  border:`1px solid ${w.color}2c`, borderRadius:12, padding:'11px 12px',
                  display:'flex', gap:11, alignItems:'flex-start',
                }}>
                  <MockQR address={w.address} color={w.color} />
                  <div style={{ flex:1, minWidth:0 }}>
                    <div style={{ display:'flex', alignItems:'center', gap:6, marginBottom:4 }}>
                      <span style={{
                        background:`${w.color}18`, border:`1px solid ${w.color}42`,
                        borderRadius:6, padding:'2px 7px',
                        fontSize:10, fontWeight:900, color:w.color,
                      }}>{w.symbol}</span>
                      <span style={{ fontSize:9, color:'rgba(148,163,184,0.6)' }}>{w.name}</span>
                    </div>
                    <div style={{ fontSize:13, fontWeight:700, color:w.color, marginBottom:5 }}>
                      {w.amount}
                    </div>
                    <div style={{
                      fontSize:7.5, fontFamily:'monospace',
                      color:'rgba(148,163,184,0.52)',
                      background:'rgba(0,0,0,0.3)', borderRadius:5, padding:'4px 6px',
                      wordBreak:'break-all', lineHeight:1.5, marginBottom:7,
                    }}>
                      {w.address}
                    </div>
                    <button
                      onClick={() => copyAddress(w.address)}
                      style={{
                        padding:'4px 10px',
                        background: copiedKey===w.address ? `${w.color}22` : 'rgba(255,255,255,0.04)',
                        border:`1px solid ${copiedKey===w.address ? w.color+'50' : 'rgba(255,255,255,0.09)'}`,
                        borderRadius:6, color: copiedKey===w.address ? w.color : 'rgba(148,163,184,0.52)',
                        fontSize:9, fontWeight:600, cursor:'pointer', transition:'all 0.18s', letterSpacing:'0.05em',
                      }}
                    >
                      {copiedKey===w.address ? '✓ Copied' : 'Copy Address'}
                    </button>
                  </div>
                </div>
              ))}
            </div>

            <button
              onClick={simulate}
              disabled={processing}
              style={{
                width:'100%', padding:'13px 0',
                background: processing ? 'rgba(247,147,26,0.22)' : 'linear-gradient(135deg,#F7931A,#e8840a)',
                border:'none', borderRadius:12, color:'#fff',
                fontSize:13, fontWeight:700, cursor: processing ? 'not-allowed' : 'pointer',
                letterSpacing:'0.04em', marginBottom:8,
                boxShadow: processing ? 'none' : '0 0 22px rgba(247,147,26,0.3)',
                display:'flex', alignItems:'center', justifyContent:'center', gap:8,
              }}
            >
              {processing
                ? <><span style={{ width:13, height:13, borderRadius:'50%', border:'2px solid rgba(255,255,255,0.28)', borderTopColor:'#fff', animation:'br-spin 0.7s linear infinite', display:'inline-block' }} />Verifying…</>
                : 'I Have Sent Payment →'
              }
            </button>
            <button
              onClick={() => setAccessPhase('payment')}
              style={{
                width:'100%', padding:'8px 0', background:'transparent',
                border:'1px solid rgba(0,255,136,0.1)', borderRadius:10,
                color:'rgba(0,255,136,0.38)', fontSize:10, cursor:'pointer',
              }}
            >
              ← Back to payment options
            </button>
          </div>
        )}

        {/* ═══════════ PHASE: code_reveal ═══════════ */}
        {accessPhase === 'code_reveal' && (
          <div style={{ animation:'br-fadein 0.4s ease', textAlign:'center' }}>
            <div style={{
              width:46, height:46, borderRadius:'50%', margin:'0 auto 12px',
              background:'rgba(0,255,136,0.07)', border:'1.5px solid rgba(0,255,136,0.35)',
              display:'flex', alignItems:'center', justifyContent:'center',
              boxShadow:'0 0 28px rgba(0,255,136,0.18)', fontSize:20,
            }}>✓</div>

            <div style={{ fontSize:10.5, fontWeight:700, color:'#00ff88', letterSpacing:'0.1em', marginBottom:3 }}>
              BETALING BEVESTIGD
            </div>
            <div style={{ fontSize:10, color:'rgba(100,116,139,0.72)', marginBottom:18, lineHeight:1.5 }}>
              Uw cloud toegangscode is gegenereerd
            </div>

            <div style={{ marginBottom:20 }}>
              <div style={{ fontSize:9, fontWeight:600, letterSpacing:'0.14em', color:'rgba(71,85,105,0.72)', textTransform:'uppercase', marginBottom:10 }}>
                Uw 6-cijferige toegangscode
              </div>
              <div className="ac-gradient-text" style={{
                fontSize:46, fontWeight:900, letterSpacing:'0.25em',
                fontVariantNumeric:'tabular-nums', fontFamily:'monospace',
                animation:'ac-code-in 0.8s cubic-bezier(.22,1,.36,1) both',
              }}>
                {generatedCode}
              </div>
              <div style={{
                margin:'10px auto 0', maxWidth:288,
                background:'rgba(0,255,136,0.03)', border:'1px solid rgba(0,255,136,0.1)',
                borderRadius:8, padding:'8px 12px',
                fontSize:10, color:'rgba(148,163,184,0.6)', lineHeight:1.5,
              }}>
                Noteer deze code. Voer hem in op de volgende stap.
              </div>
            </div>

            <button
              onClick={() => { setAccessPhase('pin_entry'); setInput(''); setError(false); }}
              style={{
                width:'100%', padding:'13px 0',
                background:'linear-gradient(135deg,#00cc6e,#00a8cc)',
                border:'none', borderRadius:12, color:'#fff',
                fontSize:14, fontWeight:700, cursor:'pointer',
                letterSpacing:'0.04em', boxShadow:'0 0 24px rgba(0,204,110,0.25)',
              }}
            >
              Voer code in → Boardroom
            </button>
          </div>
        )}

        {/* ═══════════ PHASE: pin_entry ═══════════ */}
        {accessPhase === 'pin_entry' && (
          <div style={{ animation:'br-fadein 0.4s ease' }}>
            <div style={{ textAlign:'center', marginBottom:14 }}>
              <div style={{ fontSize:10, fontWeight:700, color:'rgba(0,255,136,0.56)', letterSpacing:'0.12em', marginBottom:3 }}>
                SECURITY KEYPAD — PIN FALLBACK
              </div>
              <div style={{ fontSize:10, color:'rgba(71,85,105,0.82)' }}>
                Voer de 6-cijferige toegangscode in
              </div>
            </div>

            <div style={{ animation: shake ? 'ac-shake 0.55s ease' : 'none' }}>
              <input
                type="text" inputMode="numeric" maxLength={6} autoFocus
                placeholder="_ _ _ _ _ _"
                value={input}
                onChange={e => { setInput(e.target.value.replace(/\D/g,'').slice(0,6)); setError(false); }}
                onKeyDown={e => { if (e.key==='Enter') attempt(); }}
                style={{
                  width:'100%', padding:'13px 16px',
                  background:'#030d1a',
                  border:`1px solid ${error ? 'rgba(248,113,113,0.6)' : 'rgba(0,255,136,0.22)'}`,
                  borderRadius:12, color:'#00ff88', fontSize:22,
                  textAlign:'center', letterSpacing:'0.3em', fontWeight:700,
                  outline:'none', boxSizing:'border-box',
                  marginBottom: error ? 8 : 12, transition:'border-color 0.2s',
                  fontVariantNumeric:'tabular-nums', fontFamily:'monospace',
                }}
              />
              {error && (
                <div style={{ fontSize:11, color:'#f87171', textAlign:'center', marginBottom:12 }}>
                  Ongeldige code. Probeer opnieuw.
                </div>
              )}

              {/* 3×4 numeric keypad */}
              <div style={{ display:'grid', gridTemplateColumns:'repeat(3,1fr)', gap:8, marginBottom:12 }}>
                {(['1','2','3','4','5','6','7','8','9','←','0','⏎'] as const).map(key => (
                  <button
                    key={key}
                    onClick={() => {
                      if (key==='←') { setInput(p => p.slice(0,-1)); setError(false); }
                      else if (key==='⏎') attempt();
                      else if (input.length < 6) { setInput(p => p+key); setError(false); }
                    }}
                    style={{
                      padding:'12px 0',
                      background: key==='⏎' ? 'linear-gradient(135deg,#00cc6e,#00a8cc)'
                        : key==='←' ? 'rgba(248,113,113,0.07)'
                        : 'rgba(0,255,136,0.05)',
                      border: key==='⏎' ? 'none'
                        : key==='←' ? '1px solid rgba(248,113,113,0.2)'
                        : '1px solid rgba(0,255,136,0.1)',
                      borderRadius:10,
                      color: key==='⏎' ? '#fff' : key==='←' ? '#f87171' : '#00ff88',
                      fontSize: (key==='⏎' || key==='←') ? 16 : 18,
                      fontWeight:700, cursor:'pointer',
                      fontFamily:'monospace', transition:'background 0.15s',
                    }}
                  >
                    {key}
                  </button>
                ))}
              </div>

              <button
                onClick={attempt}
                style={{
                  width:'100%', padding:'13px 0',
                  background:'linear-gradient(135deg,#00cc6e,#00a8cc)',
                  border:'none', borderRadius:12, color:'#fff',
                  fontSize:14, fontWeight:700, cursor:'pointer',
                  letterSpacing:'0.04em', boxShadow:'0 0 24px rgba(0,204,110,0.25)',
                }}
              >
                Enter Boardroom →
              </button>
            </div>

            <button
              onClick={() => setAccessPhase('code_reveal')}
              style={{
                width:'100%', marginTop:10, padding:'8px 0',
                background:'transparent', border:'1px solid rgba(0,255,136,0.1)',
                borderRadius:10, color:'rgba(0,255,136,0.38)',
                fontSize:10, cursor:'pointer', letterSpacing:'0.06em',
              }}
            >
              Terug naar code
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
// ── Main component ────────────────────────────────────────────────────────────
type Phase = 'intro' | 'access_code' | 'circles';

export default function BoardroomLanding({ onComplete, onNavigate, user }: Props) {
  const [phase,        setPhase]        = useState<Phase>('intro');
  const [circlesIn,    setCirclesIn]    = useState(false);
  const [revealedIdx,  setRevealedIdx]  = useState(-1);
  const [activeId,     setActiveId]     = useState<string | null>(null);
  const [showModal,    setShowModal]    = useState(false);
  const [showCTA,      setShowCTA]      = useState(false);
  const [showPaywall,  setShowPaywall]  = useState(false);
  const [pendingAvatar, setPendingAvatar] = useState<AvatarDef | null>(null);
  const [showEnterpriseModal, setShowEnterpriseModal] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [skipped, setSkipped] = useState(false);
  const [pricingTab, setPricingTab] = useState<'jaarlijks' | 'lifetime'>('jaarlijks');

  const timers  = useRef<ReturnType<typeof setTimeout>[]>([]);
  const ctaTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const { invoices, trades } = useAutonomyCounters();
  const lifetimeSold = useLifetimeSlots();
  const liveDots = useLiveDots();
  const activeAvatar = AVATARS.find(a => a.id === activeId) ?? null;

  const push = (fn: () => void, ms: number) => {
    const t = setTimeout(fn, ms);
    timers.current.push(t);
    return t;
  };

  function enterAccessCode() {
    setPhase('access_code');
  }

  function enterCircles() {
    setPhase('circles');
    push(() => setCirclesIn(true), 100);
    AVATARS.forEach((_, i) => push(() => setRevealedIdx(i), 200 + i * 280));
  }

  useEffect(() => {
    return () => {
      timers.current.forEach(clearTimeout);
      if (ctaTimer.current) clearTimeout(ctaTimer.current);
    };
  }, []);

  function handleCircleClick(avatar: AvatarDef) {
    if (ctaTimer.current) clearTimeout(ctaTimer.current);
    setActiveId(avatar.id);
    setShowModal(true);
    setShowCTA(false);
    ctaTimer.current = setTimeout(() => setShowCTA(true), 10000);
  }

  function closeModal() {
    if (ctaTimer.current) clearTimeout(ctaTimer.current);
    setShowModal(false);
    setActiveId(null);
    setShowCTA(false);
  }

  function handleNavigate(avatar: AvatarDef) {
    if (ctaTimer.current) clearTimeout(ctaTimer.current);
    const TAB_MAP: Record<string, string> = {
      accounts:   'accounting',
      trading:    'trading',
      securechat: 'securechat',
      lifeassist: 'lifeassist',
      doctor:     'doctor',
      trust:      'trust',
    };
    const urlTab = TAB_MAP[avatar.tab] ?? avatar.tab;
    if (onNavigate) onNavigate(urlTab);
    else window.location.href = '/?tab=' + urlTab;
    onComplete();
  }

  function handleCTAClick(avatar: AvatarDef) {
    const paidModules = ['accounts', 'trading', 'doctor'];
    const freeModules = ['securechat', 'banking', 'trust'];
    if (freeModules.includes(avatar.id) || !paidModules.includes(avatar.id)) { handleNavigate(avatar); return; }
    if (user) {
      supabase
        .from('subscriptions')
        .select('id')
        .eq('user_id', user.id)
        .eq('status', 'active')
        .limit(1)
        .maybeSingle()
        .then(({ data }) => {
          if (data) handleNavigate(avatar);
          else { setPendingAvatar(avatar); setShowPaywall(true); }
        })
        .catch(() => { setPendingAvatar(avatar); setShowPaywall(true); });
    } else {
      setPendingAvatar(avatar);
      setShowPaywall(true);
    }
  }

  return (
    <div style={{
      position: 'fixed', inset: 0, background: '#000',
      fontFamily: "'Inter', -apple-system, sans-serif",
      overflowY: phase === 'circles' ? 'auto' : 'hidden',
      overflowX: 'hidden',
      maxWidth: '100vw',
    }}>
      <style>{`
        @keyframes br-dot-pulse  { 0%,100%{opacity:0.04;transform:scale(1)} 50%{opacity:0.12;transform:scale(1.3)} }
        @keyframes br-scan-line  { 0%{top:-2px;opacity:0} 5%{opacity:0.05} 95%{opacity:0.05} 100%{top:100%;opacity:0} }
        @keyframes br-glow-pulse { 0%,100%{filter:brightness(1)} 50%{filter:brightness(1.5) drop-shadow(0 0 12px currentColor)} }
        @keyframes br-countdown  { from{width:0%} to{width:100%} }
        @keyframes br-float      { 0%,100%{transform:translateY(0)} 50%{transform:translateY(-7px)} }
        @keyframes br-ripple     { 0%{opacity:0.7;transform:scale(1)} 100%{opacity:0;transform:scale(1.5)} }
        @keyframes br-bounce-arrow { 0%,100%{transform:translateY(0)} 50%{transform:translateY(-6px)} }
        @keyframes br-fadein     { from{opacity:0;transform:translateY(14px)} to{opacity:1;transform:translateY(0)} }
        @keyframes br-spin       { to{transform:rotate(360deg)} }
        @keyframes br-hint-pulse { 0%,100%{box-shadow:0 0 0 0 rgba(93,202,165,0.5)} 50%{box-shadow:0 0 0 8px rgba(93,202,165,0)} }
        @keyframes br-finger-bounce { 0%,100%{transform:translateY(0)} 50%{transform:translateY(-5px)} }
        @keyframes live-ping     { 0%{box-shadow:0 0 0 0 rgba(239,68,68,0.7)} 70%{box-shadow:0 0 0 8px rgba(239,68,68,0)} 100%{box-shadow:0 0 0 0 rgba(239,68,68,0)} }
        @keyframes intro-fade-out { from{opacity:1} to{opacity:0;pointer-events:none} }
        @keyframes circles-fade-in { from{opacity:0} to{opacity:1} }
        button:hover { opacity: 0.88; }
      `}</style>

      {/* ══════════════════════════════════════════
          PHASE 1 — Fullscreen HeyGen intro video
      ══════════════════════════════════════════ */}
      {phase === 'intro' && (
        <div style={{
          animation: circlesIn ? 'intro-fade-out 0.6s ease forwards' : 'none',
        }}>
          <IntroVideoPlayer
            onEnded={enterAccessCode}
            onSkip={enterAccessCode}
          />
        </div>
      )}

      {/* ══════════════════════════════════════════
          PHASE 1.5 — Access code gate
      ══════════════════════════════════════════ */}
      {phase === 'access_code' && (
        <AccessCodeScreen onSuccess={enterCircles} />
      )}

      {/* ══════════════════════════════════════════
          PHASE 2 — Circles boardroom
      ══════════════════════════════════════════ */}
      {phase === 'circles' && (
        <div style={{
          display: 'flex', flexDirection: 'column', alignItems: 'center',
          minHeight: '100%',
          opacity: circlesIn ? 1 : 0,
          animation: 'circles-fade-in 0.7s ease forwards',
        }}>
          {/* Dot-grid background */}
          <div style={{
            position: 'fixed', inset: 0, pointerEvents: 'none', zIndex: 0, overflow: 'hidden',
          }}>
            {Array.from({ length: Math.ceil(window.innerWidth / 28) * Math.ceil(window.innerHeight / 28) }).slice(0, 480).map((_, i) => {
              const cols = Math.ceil(window.innerWidth / 28);
              return (
                <div key={i} style={{
                  position: 'absolute',
                  left: (i % cols) * 28 + 14,
                  top:  Math.floor(i / cols) * 28 + 14,
                  width: 2, height: 2, borderRadius: '50%',
                  background: '#5DCAA5',
                  animation: `br-dot-pulse ${3.2 + (i % 7) * 0.3}s ease-in-out infinite`,
                  animationDelay: `${(i % 19) * 0.2}s`,
                }} />
              );
            })}
            <div style={{
              position: 'absolute', left: 0, right: 0, height: 2,
              background: 'linear-gradient(90deg, transparent, #5DCAA522, transparent)',
              animation: 'br-scan-line 3s linear infinite',
            }} />
          </div>

          {/* Skip button */}
          <button
            disabled={isSubmitting || skipped}
            onClick={() => {
              if (skipped || isSubmitting) return;
              setSkipped(true);
              setIsSubmitting(true);
              onComplete();
            }}
            style={{
              position: 'fixed', top: 14, right: 16, zIndex: 30,
              background: 'rgba(93,202,165,0.08)', border: '1px solid rgba(93,202,165,0.2)',
              color: '#5DCAA5', padding: '5px 13px', borderRadius: 18,
              fontSize: 10, fontWeight: 600, cursor: isSubmitting ? 'not-allowed' : 'pointer',
              display: 'flex', alignItems: 'center', gap: 4,
              opacity: isSubmitting ? 0.5 : 1, transition: 'opacity 0.15s',
            }}
          >
            {isSubmitting
              ? <><span style={{ width: 8, height: 8, borderRadius: '50%', border: '1.5px solid #5DCAA5', borderTopColor: 'transparent', animation: 'br-spin 0.6s linear infinite', display: 'inline-block' }} /> Loading…</>
              : <>Overslaan <ChevronRight size={10} /></>
            }
          </button>

          {/* Circles section — 3-column grid with company info left column */}
          <div className="br-circles-anchor" style={{
            display: 'grid',
            gridTemplateColumns: 'clamp(160px, 20vw, 240px) 1fr clamp(160px, 20vw, 240px)',
            alignItems: 'start',
            width: '100%', maxWidth: '1400px', margin: '0 auto', padding: '56px 12px 20px',
            zIndex: 10, position: 'relative', gap: 16,
            boxSizing: 'border-box',
          }}>

            {/* ── LEFT COLUMN — Company identity & certification ── */}
            <div className="bg-[#0A0F1E] border border-[rgba(6,182,212,0.2)] rounded-xl p-4 text-left flex flex-col gap-3 self-start mt-8 animate-[br-fadein_0.8s_ease]">
              {/* Corporate cyborg logo */}
              <div style={{ display: 'flex', justifyContent: 'center', marginBottom: 4 }}>
                <img
                  src="/aippieremix_aippieremix_In_generated_file_3_keep_the_split_human-robot_face_the_aippie_1ada2b19-20fd-43ac-bcd7-e099712720a6_(2).png"
                  alt="AIPPIE"
                  style={{ width: 72, height: 72, objectFit: 'cover', borderRadius: 12, border: '1px solid rgba(6,182,212,0.25)' }}
                />
              </div>
              {/* Header */}
              <div>
                <div className="text-[#06B6D4] font-extrabold tracking-widest text-[11px] uppercase mb-1">AIPPIETAX S.A.</div>
                <div className="text-[rgba(255,255,255,0.45)] text-[10px] leading-relaxed">NIF: A22944987 · Málaga, Spain</div>
              </div>

              {/* Compliance badges */}
              <div className="flex flex-col gap-1.5">
                {[
                  { icon: '🔒', label: 'GDPR compliant' },
                  { icon: '✅', label: 'Verifactu certified' },
                  { icon: '🔐', label: 'End-to-end encrypted' },
                ].map(b => (
                  <div key={b.label} className="flex items-center gap-2 text-[10px] text-[rgba(255,255,255,0.55)]">
                    <span>{b.icon}</span><span>{b.label}</span>
                  </div>
                ))}
              </div>

              <hr className="border-[rgba(6,182,212,0.15)]" />

              {/* Software valuation certificate */}
              <div>
                <div className="text-[rgba(255,255,255,0.45)] text-[9px] uppercase tracking-widest mb-2">Software certificering</div>
                <div className="bg-[rgba(6,182,212,0.07)] border border-[rgba(6,182,212,0.18)] rounded-lg p-3 flex flex-col gap-1.5">
                  <div className="text-[#06B6D4] font-black text-[18px] leading-none">€1.743.516</div>
                  {[
                    ['Expert',  'Dr. David Santo Orcero'],
                    ['Titel',   'Perito Judicial Informático'],
                    ['Reg. nr', '2009/63'],
                    ['Methode', 'COCOMO II'],
                    ['Ref',     'AIPPIETAX260512'],
                    ['Ticket',  'WEBT93931757'],
                    ['Rapport', '112 pagina\'s'],
                  ].map(([k, v]) => (
                    <div key={k} className="flex gap-1.5 text-[9px]">
                      <span className="text-[rgba(6,182,212,0.6)] w-14 flex-shrink-0">{k}</span>
                      <span className="text-[rgba(255,255,255,0.6)]">{v}</span>
                    </div>
                  ))}
                </div>
              </div>

              <hr className="border-[rgba(6,182,212,0.15)]" />

              {/* Notarial registration */}
              <div className="flex flex-col gap-1">
                <div className="text-[rgba(255,255,255,0.65)] text-[9px] font-semibold uppercase tracking-wider">Notarieel geregistreerd</div>
                <div className="text-[rgba(255,255,255,0.4)] text-[9px] leading-relaxed">
                  Registro Mercantil de Málaga<br />Dossier: 4/2026/16084
                </div>
              </div>
            </div>

            {/* ── CENTER COLUMN — existing circles + wordmark + slogan ── */}
            <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', width: '100%' }}>
            {/* Wordmark */}
            <div style={{ marginBottom: 8, animation: 'br-fadein 0.7s ease' }}>
              <img
                src="/Jouw_alineatekst_(2).png" alt="Aippie"
                style={{ height: 26, objectFit: 'contain' }}
                onError={e => { (e.currentTarget as HTMLImageElement).style.display = 'none'; }}
              />
            </div>

            {/* Slogan */}
            <p style={{
              color: 'rgba(255,255,255,0.55)',
              fontSize: 'clamp(16px, 4vw, 24px)',
              fontWeight: 500,
              letterSpacing: '0.04em',
              textAlign: 'center',
              margin: '0 0 16px',
              padding: '0 16px',
              width: '100%',
              maxWidth: '100%',
              whiteSpace: 'normal',
              wordBreak: 'break-word',
              lineHeight: 1.4,
              fontFamily: "'Inter', sans-serif",
              animation: 'br-fadein 0.9s ease',
            }}>
              your entire life run by AI
            </p>

            {/* 6 circles — responsive grid: 2-col mobile → 3-col tablet → 6-col desktop */}
            <div style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(2, 1fr)',
              gap: 'clamp(10px, 2.5vw, 24px)',
              justifyItems: 'center',
              alignItems: 'center',
              width: '100%',
              maxWidth: '100%',
              margin: '0 auto',
              marginBottom: 16,
              padding: '0 12px',
              boxSizing: 'border-box',
            }}
              className="br-circles-grid"
            >
              <style>{`
                @media (min-width: 600px) { .br-circles-grid { grid-template-columns: repeat(3, 1fr) !important; } }
                @media (min-width: 960px) { .br-circles-grid { grid-template-columns: repeat(6, 1fr) !important; max-width: 1100px !important; } }
                @keyframes br-trust-glow {
                  0%, 100% { box-shadow: 0 0 20px #10b98135, 0 0 0px #10b98100; }
                  50% { box-shadow: 0 0 40px #10b98188, 0 0 70px #10b98144; }
                }
              `}</style>
              {AVATARS.map((avatar, i) => (
                <div key={avatar.id} style={{ display: 'flex', justifyContent: 'center', width: '100%' }}>
                  <AvatarCircle
                    avatar={avatar}
                    revealed={revealedIdx >= i}
                    isActive={activeId === avatar.id}
                    isInactive={activeId !== null && activeId !== avatar.id}
                    onClick={() => handleCircleClick(avatar)}
                  />
                </div>
              ))}
            </div>

            {/* Tap hint */}
            <div style={{
              opacity: revealedIdx >= AVATARS.length - 1 ? 1 : 0,
              transform: revealedIdx >= AVATARS.length - 1 ? 'translateY(0)' : 'translateY(12px)',
              transition: 'opacity 0.6s ease 0.5s, transform 0.6s ease 0.5s',
              marginTop: 4, marginBottom: 18,
              background: 'rgba(93,202,165,0.05)',
              border: '1px solid rgba(93,202,165,0.2)',
              borderRadius: 14, padding: '10px 20px',
              display: 'flex', alignItems: 'center', gap: 10,
              animation: revealedIdx >= AVATARS.length - 1 ? 'br-hint-pulse 2.5s ease-in-out infinite' : 'none',
            }}>
              <span style={{ fontSize: 18, display: 'inline-block', animation: 'br-finger-bounce 1.2s ease-in-out infinite' }}>
                👆
              </span>
              <span style={{ fontSize: 12, color: '#888', fontWeight: 500 }}>
                <span style={{ color: '#5DCAA5', fontWeight: 700 }}>Tap a circle</span> to meet your AI agent
              </span>
            </div>

            {/* Mini live counters */}
            <div style={{
              display: 'flex', gap: 10, flexWrap: 'wrap', justifyContent: 'center',
              animation: 'br-fadein 0.8s ease 1.5s both',
            }}>
              {[
                { label: 'Invoices',           value: invoices, color: '#5DCAA5' },
                { label: 'Trades',             value: trades,   color: '#EF9F27' },
                { label: 'Human intervention', value: 0,        color: '#E24B4A' },
              ].map(item => (
                <div key={item.label} style={{
                  background: item.color + '0a',
                  border: `1px solid ${item.color}22`,
                  borderRadius: 10, padding: '6px 14px', textAlign: 'center', minWidth: 110,
                }}>
                  <div style={{
                    fontSize: 18, fontWeight: 900, color: item.color,
                    fontVariantNumeric: 'tabular-nums',
                    textShadow: item.value === 0 ? `0 0 10px ${item.color}` : 'none',
                  }}>
                    {item.value.toLocaleString()}
                  </div>
                  <div style={{ fontSize: 8, color: '#444', fontWeight: 600, letterSpacing: '0.06em' }}>
                    {item.label}
                  </div>
                </div>
              ))}
            </div>
            <div style={{ height: 8 }} />
            </div>{/* end center column */}

            {/* ── RIGHT COLUMN — Live activity + Lifetime deal ── */}
            <div className="bg-[#0A0F1E] border border-[rgba(234,179,8,0.2)] rounded-xl p-4 text-left flex flex-col gap-3 self-start mt-8 animate-[br-fadein_0.8s_ease]">

              {/* Header */}
              <div className="text-[#EAB308] font-extrabold tracking-widest text-[11px] uppercase">Live activiteit</div>

              {/* Animated city dots */}
              <div className="flex flex-col gap-1.5">
                {LIVE_CITIES.map((item, i) => (
                  <div key={item.city} className="flex items-center gap-2 text-[10px] text-[rgba(255,255,255,0.55)]">
                    <span
                      className="w-1.5 h-1.5 rounded-full flex-shrink-0 transition-colors duration-700"
                      style={{ background: liveDots[i], boxShadow: `0 0 5px ${liveDots[i]}` }}
                    />
                    <span>{item.flag}</span>
                    <span>{item.city}</span>
                  </div>
                ))}
              </div>

              <hr className="border-[rgba(234,179,8,0.15)]" />

              {/* Lifetime deal */}
              <div>
                <div className="text-[rgba(255,255,255,0.45)] text-[9px] uppercase tracking-widest mb-2">Lifetime deal</div>
                <div className="bg-[rgba(234,179,8,0.07)] border border-[rgba(234,179,8,0.2)] rounded-lg p-3 flex flex-col gap-2">
                  <div className="flex items-baseline gap-1.5">
                    <span className="text-[#EAB308] font-black text-[16px] leading-none">
                      {Math.max(0, LIFETIME_MAX - lifetimeSold)}
                    </span>
                    <span className="text-[rgba(255,255,255,0.5)] text-[10px]">beschikbaar</span>
                  </div>
                  <div className="text-[rgba(255,255,255,0.35)] text-[9px]">Max {LIFETIME_MAX} slots</div>
                  {/* Progress bar */}
                  <div className="w-full h-1.5 bg-[rgba(234,179,8,0.1)] rounded-full overflow-hidden">
                    <div
                      className="h-full rounded-full transition-all duration-700"
                      style={{
                        width: `${Math.min(100, (lifetimeSold / LIFETIME_MAX) * 100)}%`,
                        background: 'linear-gradient(90deg, #EAB308, #F59E0B)',
                        boxShadow: '0 0 6px rgba(234,179,8,0.5)',
                      }}
                    />
                  </div>
                  <div className="flex justify-between text-[8px] text-[rgba(255,255,255,0.3)]">
                    <span>{lifetimeSold} verkocht</span>
                    <span>{LIFETIME_MAX} totaal</span>
                  </div>
                </div>
              </div>
            </div>

          </div>

          {/* Below-fold sections */}
          <div style={{ width: '100%', background: '#0a0a0f', zIndex: 10, position: 'relative' }}>
            {/* ── PRICING SECTION ───────────────────────────────────────────── */}
            <div className="w-full max-w-xl mx-auto px-4 pt-12 pb-10 flex flex-col items-center gap-6">

              {/* Toggle */}
              <div className="flex items-center bg-[#0d1420] border border-[rgba(255,255,255,0.08)] rounded-full p-1 gap-1">
                {(['jaarlijks', 'lifetime'] as const).map(tab => (
                  <button
                    key={tab}
                    onClick={() => setPricingTab(tab)}
                    className={[
                      'px-5 py-2 rounded-full text-[12px] font-bold tracking-wide transition-all duration-200',
                      pricingTab === tab
                        ? tab === 'jaarlijks'
                          ? 'bg-[#3B82F6] text-white shadow-[0_0_12px_rgba(59,130,246,0.4)]'
                          : 'bg-[#EAB308] text-[#0a0a0f] shadow-[0_0_12px_rgba(234,179,8,0.4)]'
                        : 'text-[rgba(255,255,255,0.4)] hover:text-[rgba(255,255,255,0.7)]',
                    ].join(' ')}
                  >
                    {tab === 'jaarlijks' ? 'Jaarlijks' : 'Lifetime'}
                  </button>
                ))}
              </div>

              {/* ── JAARLIJKS CARD ── */}
              {pricingTab === 'jaarlijks' && (
                <div className="w-full bg-[#0A0F1E] border border-[rgba(59,130,246,0.25)] rounded-2xl p-6 flex flex-col gap-5 shadow-[0_0_40px_rgba(59,130,246,0.06)]">
                  {/* Badge + price */}
                  <div className="flex items-start justify-between gap-3">
                    <span className="bg-[rgba(59,130,246,0.15)] border border-[rgba(59,130,246,0.3)] text-[#60A5FA] text-[10px] font-bold tracking-widest uppercase px-3 py-1 rounded-full">
                      Meest gekozen
                    </span>
                  </div>
                  <div>
                    <div className="flex items-baseline gap-2">
                      <span className="text-white font-black text-[32px] leading-none">€299</span>
                      <span className="text-[rgba(255,255,255,0.4)] text-[13px]">/ jaar</span>
                    </div>
                    <div className="text-[rgba(255,255,255,0.35)] text-[11px] mt-1">€24,92 / maand · automatisch verlengd</div>
                  </div>

                  {/* Features */}
                  <ul className="flex flex-col gap-2">
                    {[
                      'Alle 83 modules inbegrepen',
                      'Verifactu fiscaal gecertificeerd',
                      'Updates gedurende 1 jaar',
                      'Licentie AIPP-XXXX (per email)',
                    ].map(f => (
                      <li key={f} className="flex items-center gap-2.5 text-[12px] text-[rgba(255,255,255,0.65)]">
                        <span className="text-[#3B82F6] text-[14px] leading-none">✓</span>
                        {f}
                      </li>
                    ))}
                  </ul>

                  <SepaPaymentBlock amount={299} accent="#3B82F6" paypalUrl="https://www.paypal.com/paypalme/aippietax/299" />
                </div>
              )}

              {/* ── LIFETIME CARD ── */}
              {pricingTab === 'lifetime' && (
                <div className="w-full bg-[#0A0F1E] border border-[rgba(234,179,8,0.25)] rounded-2xl p-6 flex flex-col gap-5 shadow-[0_0_40px_rgba(234,179,8,0.06)]">
                  {/* Badge + price */}
                  <div className="flex items-start justify-between gap-3">
                    <span className="bg-[rgba(234,179,8,0.15)] border border-[rgba(234,179,8,0.3)] text-[#EAB308] text-[10px] font-bold tracking-widest uppercase px-3 py-1 rounded-full">
                      Lifetime · nog {Math.max(0, LIFETIME_MAX - lifetimeSold)} plekken
                    </span>
                  </div>
                  <div>
                    <div className="flex items-baseline gap-2">
                      <span className="text-white font-black text-[32px] leading-none">€2.497</span>
                      <span className="text-[rgba(255,255,255,0.4)] text-[13px]">eenmalig</span>
                    </div>
                    <div className="text-[rgba(255,255,255,0.35)] text-[11px] mt-1">Nooit meer betalen · voor altijd toegang</div>
                  </div>

                  {/* Features */}
                  <ul className="flex flex-col gap-2">
                    {[
                      'Alle 83 modules inbegrepen',
                      'Updates voor altijd inbegrepen',
                      'Licentie AIPP-LIFE-XXXX (per email)',
                      `Max ${LIFETIME_MAX} slots wereldwijd`,
                    ].map(f => (
                      <li key={f} className="flex items-center gap-2.5 text-[12px] text-[rgba(255,255,255,0.65)]">
                        <span className="text-[#EAB308] text-[14px] leading-none">✓</span>
                        {f}
                      </li>
                    ))}
                  </ul>

                  {/* Slots progress */}
                  <div className="flex flex-col gap-1.5">
                    <div className="flex justify-between text-[10px]">
                      <span className="text-[rgba(255,255,255,0.4)]">{lifetimeSold} verkocht</span>
                      <span className="text-[#EAB308] font-bold">{Math.max(0, LIFETIME_MAX - lifetimeSold)} beschikbaar</span>
                    </div>
                    <div className="w-full h-2 bg-[rgba(234,179,8,0.08)] rounded-full overflow-hidden">
                      <div
                        className="h-full rounded-full transition-all duration-700"
                        style={{
                          width: `${Math.min(100, (lifetimeSold / LIFETIME_MAX) * 100)}%`,
                          background: 'linear-gradient(90deg, #EAB308, #F59E0B)',
                          boxShadow: '0 0 8px rgba(234,179,8,0.5)',
                        }}
                      />
                    </div>
                  </div>

                  <SepaPaymentBlock amount={2497} accent="#EAB308" paypalUrl="https://www.paypal.com/paypalme/aippietax/2497" />
                </div>
              )}

              {/* Footer trust line */}
              <div className="flex items-center justify-center gap-2 text-[10px] text-[rgba(255,255,255,0.3)] text-center">
                <Lock size={10} className="flex-shrink-0" />
                <span>Beveiligde betaling · Licentie direct per email · Beschikbaar in 150+ landen</span>
              </div>
            </div>

            {/* Privacy & Compliance */}
            <div style={{ maxWidth: 760, margin: '0 auto', padding: '48px 24px 40px', textAlign: 'center' }}>
              <h2 style={{
                color: '#ffffff', fontSize: 'clamp(18px, 3.5vw, 28px)', fontWeight: 800,
                margin: '0 0 18px', letterSpacing: '0.01em',
              }}>
                Your data is yours. Always.
              </h2>
              <p style={{
                color: '#e2e8f0', fontSize: 'clamp(12px, 2vw, 14px)', lineHeight: 1.8,
                maxWidth: 580, margin: '0 auto 32px',
              }}>
                At Aippie, we built something simple: an AI that works for you — not against you.
                Your messages cannot be read by anyone. Not by us. Not by governments. Not by anyone.
                Your health data never leaves your device. Your financial data is encrypted at rest and in transit.
                Your trades are yours alone. We do not sell data. We do not store what we do not need.
                We do not share anything with anyone. Ever.
              </p>
              <div style={{
                display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))',
                gap: 10, textAlign: 'left', maxWidth: 680, margin: '0 auto',
              }}>
                {[
                  'Your messages self-destruct automatically',
                  'Nobody can read your chats — not even us',
                  'Your health data stays on your device',
                  'Your money moves stay private',
                  'European servers — EU law protects you',
                  'If someone looks over your shoulder — chat closes instantly',
                  'No data brokers. No advertising. No tracking.',
                ].map(item => (
                  <div key={item} style={{
                    display: 'flex', alignItems: 'flex-start', gap: 10,
                    padding: '10px 14px',
                    background: 'rgba(29,158,117,0.04)',
                    border: '1px solid rgba(29,158,117,0.1)',
                    borderRadius: 8,
                  }}>
                    <span style={{ color: '#1D9E75', fontWeight: 900, fontSize: 14, lineHeight: 1.4, flexShrink: 0 }}>✓</span>
                    <span style={{ color: '#e2e8f0', fontSize: 12, lineHeight: 1.5 }}>{item}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Cyber strip */}
            <div style={{
              margin: '0 24px 40px', maxWidth: 760, marginLeft: 'auto', marginRight: 'auto',
              border: '0.5px solid #1D9E75', borderRadius: 10, background: '#0d0d16',
              padding: '14px 24px', display: 'flex', flexWrap: 'wrap',
              justifyContent: 'center', gap: '8px 24px',
              boxShadow: '0 0 20px rgba(29,158,117,0.06)',
            }}>
              {['256-bit Encrypted', 'GDPR Compliant', 'HIPAA Ready', 'Zero Knowledge Architecture'].map((item, i) => (
                <span key={item} style={{
                  color: '#5DCAA5', fontSize: 10, fontWeight: 700,
                  letterSpacing: '0.12em', textTransform: 'uppercase',
                  display: 'flex', alignItems: 'center', gap: 8,
                }}>
                  {i > 0 && <span style={{ color: 'rgba(93,202,165,0.4)', fontSize: 12 }}>·</span>}
                  {item}
                </span>
              ))}
            </div>

            {/* CTA */}
            <div style={{ textAlign: 'center', padding: '0 24px 48px' }}>
              <p style={{ color: '#ffffff', fontSize: 'clamp(15px, 2.8vw, 20px)', fontWeight: 700, margin: '0 0 6px' }}>
                Ready to let AI run your life?
              </p>
              <p style={{ color: '#888888', fontSize: 13, margin: '0 0 20px' }}>
                Choose your agent above — and never look back.
              </p>
              <button
                onClick={() => document.querySelector('.br-circles-anchor')?.scrollIntoView({ behavior: 'smooth' })}
                style={{
                  background: 'transparent', border: '1px solid rgba(29,158,117,0.3)',
                  color: '#1D9E75', fontSize: 11, fontWeight: 600,
                  padding: '8px 20px', borderRadius: 20, cursor: 'pointer', letterSpacing: '0.06em',
                }}
              >
                Back to top
              </button>
            </div>

            <div style={{ borderTop: '0.5px solid rgba(255,255,255,0.04)', margin: '0 24px' }} />

            {/* Footer */}
            <div style={{
              maxWidth: 760, margin: '0 auto', padding: '32px 24px 40px',
              display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))', gap: 32,
            }}>
              <div>
                <div style={{ color: '#ffffff', fontSize: 12, fontWeight: 700, marginBottom: 10, letterSpacing: '0.04em' }}>
                  AIPPIETAX S.A.
                </div>
                {['NIF: A22944987', 'Mijas, Málaga, España', 'elvin@aippie.com', '+34 604 487 502', 'aippie.com'].map(line => (
                  <div key={line} style={{ color: (line.includes('@') || line.startsWith('+') || line.startsWith('aippie.com')) ? '#5DCAA5' : '#94a3b8', fontSize: 10, marginBottom: 4, lineHeight: 1.5 }}>{line}</div>
                ))}
              </div>
              <div>
                <div style={{ color: '#1D9E75', fontSize: 10, fontWeight: 700, marginBottom: 10, letterSpacing: '0.08em', textTransform: 'uppercase' }}>
                  Certified AI Platform
                </div>
                {['Valuation: €1.743.516', 'Expert: David Santo Orcero', 'Judicial Software Valuation', 'Registro Mercantil de Málaga', 'Ref: WEBT93931757 · 17/06/2026'].map(line => (
                  <div key={line} style={{ color: '#e2e8f0', fontSize: 10, marginBottom: 4, lineHeight: 1.5 }}>{line}</div>
                ))}
              </div>
              <div>
                <div style={{ color: '#e2e8f0', fontSize: 12, fontWeight: 700, marginBottom: 10, letterSpacing: '0.04em' }}>
                  Built by humans.<br />Run by AI.<br />For everyone.
                </div>
                <div style={{ color: '#94a3b8', fontSize: 10, marginTop: 12, lineHeight: 1.6 }}>
                  © 2026 AIPPIETAX S.A.<br />All rights reserved.
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ══════════════════════════════════════════
          MODAL — Circle video player
      ══════════════════════════════════════════ */}
      {showModal && activeAvatar && (
        <div style={{
          position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.97)',
          display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
          zIndex: 200, animation: 'br-fadein 0.3s ease',
        }}>
          <button onClick={closeModal} style={{
            position: 'absolute', top: 18, right: 18, width: 38, height: 38, borderRadius: '50%',
            background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.1)',
            color: '#e2e8f0', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 201,
          }}>
            <X size={17} />
          </button>

          <div style={{ marginBottom: 14, display: 'flex', alignItems: 'center', gap: 10 }}>
            <div style={{
              width: 8, height: 8, borderRadius: '50%',
              background: activeAvatar.color, boxShadow: `0 0 12px ${activeAvatar.color}`,
              animation: 'br-glow-pulse 1s ease-in-out infinite',
            }} />
            <span style={{ color: activeAvatar.color, fontWeight: 700, fontSize: 14, letterSpacing: '0.04em' }}>
              {activeAvatar.name}
            </span>
            <span style={{ color: '#333', fontSize: 10 }}>· Live Avatar</span>
          </div>

          <div style={{
            width: '94%', maxWidth: 820, aspectRatio: '16/9',
            borderRadius: 14, overflow: 'hidden',
            border: `2px solid ${activeAvatar.color}44`,
            boxShadow: `0 0 60px ${activeAvatar.color}22`,
            position: 'relative', background: '#000',
          }}>
            <CircleVideoPlayer
              key={activeAvatar.id}
              avatar={activeAvatar}
              onCTAClick={() => handleCTAClick(activeAvatar)}
            />
          </div>

          {showCTA ? (
            <div style={{ marginTop: 24, animation: 'br-fadein 0.5s ease', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 10 }}>
              <p style={{ color: '#444', fontSize: 11, margin: 0 }}>Klaar om te activeren?</p>
              <button
                onClick={() => handleCTAClick(activeAvatar)}
                style={{
                  backgroundColor: activeAvatar.color,
                  color: ['#EF9F27', '#5DCAA5', '#1D9E75'].includes(activeAvatar.color) ? '#0a0a0a' : '#fff',
                  padding: '13px 44px', borderRadius: 9999, fontSize: 14, fontWeight: 900,
                  border: 'none', cursor: 'pointer', letterSpacing: '0.08em',
                  textTransform: 'uppercase', boxShadow: `0 8px 36px ${activeAvatar.color}66`,
                }}
              >
                {activeAvatar.id === 'doctor' ? 'Open Doctor' : `OPEN ${activeAvatar.name.toUpperCase()}`}
              </button>
            </div>
          ) : (
            <div style={{ marginTop: 16, textAlign: 'center' }}>
              <div style={{ width: 180, height: 2, background: 'rgba(255,255,255,0.06)', borderRadius: 2, overflow: 'hidden' }}>
                <div style={{
                  height: '100%', background: activeAvatar.color,
                  animation: 'br-countdown 10s linear forwards',
                } as React.CSSProperties} />
              </div>
              <p style={{ color: '#222', fontSize: 9, marginTop: 5 }}>CTA verschijnt over 10 seconden</p>
            </div>
          )}
        </div>
      )}

      {/* ══════════════════════════════════════════
          PAYWALL MODAL
      ══════════════════════════════════════════ */}
      {showPaywall && pendingAvatar && (
        <div style={{
          position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.97)',
          display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
          zIndex: 300, animation: 'br-fadein 0.3s ease', padding: '24px 16px',
        }}>
          <button onClick={() => setShowPaywall(false)} style={{
            position: 'absolute', top: 18, right: 18, width: 38, height: 38, borderRadius: '50%',
            background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.1)',
            color: '#e2e8f0', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center',
          }}>
            <X size={17} />
          </button>

          <div style={{ maxWidth: 480, width: '100%', textAlign: 'center' }}>
            <div style={{
              width: 64, height: 64, borderRadius: '50%', margin: '0 auto 20px',
              border: `2px solid ${pendingAvatar.color}55`,
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              boxShadow: `0 0 32px ${pendingAvatar.color}33`,
            }}>
              <pendingAvatar.icon size={28} color={pendingAvatar.color} strokeWidth={1.5} />
            </div>
            <h2 style={{ color: '#e2e8f0', fontSize: 20, fontWeight: 900, margin: '0 0 8px', letterSpacing: '0.02em' }}>
              Unlock {pendingAvatar.name}
            </h2>
            <p style={{ color: '#666', fontSize: 12, margin: '0 0 28px', lineHeight: 1.6 }}>
              Choose your plan to access all AI modules. Cancel anytime.
            </p>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 14, marginBottom: 24 }}>
              {[
                { name: 'Starter', price: '€29', period: '/month', desc: '3 AI modules · Basic automation', color: '#3b82f6', paypalUrl: 'https://www.paypal.com/paypalme/aippietax/29', amount: 29 },
                { name: 'Business', price: '€79', period: '/month', desc: '10 AI modules · Full automation', color: '#1D9E75', popular: true, paypalUrl: 'https://www.paypal.com/paypalme/aippietax/79', amount: 79 },
              ].map(plan => (
                <div key={plan.name} style={{
                  background: plan.popular ? 'rgba(29,158,117,0.08)' : 'rgba(59,130,246,0.06)',
                  border: `1px solid ${plan.popular ? '#1D9E75' : 'rgba(59,130,246,0.3)'}`,
                  borderRadius: 14, padding: '16px 20px', position: 'relative',
                }}>
                  {plan.popular && (
                    <div style={{
                      position: 'absolute', top: -10, left: '50%', transform: 'translateX(-50%)',
                      background: '#1D9E75', color: '#fff',
                      fontSize: 9, fontWeight: 800, padding: '3px 12px', borderRadius: 20,
                      letterSpacing: '0.1em', whiteSpace: 'nowrap',
                    }}>MOST POPULAR</div>
                  )}
                  <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12 }}>
                    <div>
                      <div style={{ color: '#e2e8f0', fontSize: 16, fontWeight: 800 }}>{plan.name}</div>
                      <div style={{ color: '#6b7280', fontSize: 11, marginTop: 2 }}>{plan.desc}</div>
                    </div>
                    <div style={{ textAlign: 'right' }}>
                      <span style={{ color: plan.color, fontSize: 22, fontWeight: 900 }}>{plan.price}</span>
                      <span style={{ color: '#4b5563', fontSize: 11 }}>{plan.period}</span>
                    </div>
                  </div>
                  <SepaPaymentBlock
                    amount={plan.amount}
                    accent={plan.color}
                    paypalUrl={plan.paypalUrl}
                    paypalLabel={`Betaal via PayPal of Creditcard · ${plan.price}${plan.period}`}
                  />
                </div>
              ))}
            </div>
            <p style={{ color: '#333', fontSize: 10, margin: 0 }}>
              Secure payment · AIPPIETAX S.A. · NIF: A22944987
            </p>
          </div>
        </div>
      )}

      {/* ══════════════════════════════════════════
          SECURECHAT MODAL
      ══════════════════════════════════════════ */}
      {showEnterpriseModal && (
        <div style={{
          position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.97)',
          display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
          zIndex: 300, animation: 'br-fadein 0.3s ease', padding: '24px 16px',
        }}>
          <button onClick={() => setShowEnterpriseModal(false)} style={{
            position: 'absolute', top: 18, right: 18, width: 38, height: 38, borderRadius: '50%',
            background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.1)',
            color: '#e2e8f0', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center',
          }}>
            <X size={17} />
          </button>

          <div style={{ maxWidth: 440, width: '100%', textAlign: 'center' }}>
            <div style={{
              width: 72, height: 72, borderRadius: '50%', margin: '0 auto 20px',
              border: '2px solid rgba(127,119,221,0.5)',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              boxShadow: '0 0 48px rgba(127,119,221,0.3)',
              background: 'radial-gradient(circle, rgba(127,119,221,0.15) 0%, transparent 70%)',
              position: 'relative',
            }}>
              <Lock size={30} color="#7F77DD" strokeWidth={1.5} />
              <div style={{
                position: 'absolute', width: 88, height: 88, borderRadius: '50%',
                border: '1.5px solid rgba(127,119,221,0.2)',
                animation: 'br-ripple 2.4s ease-in-out infinite',
              }} />
            </div>
            <h2 style={{ color: '#e2e8f0', fontSize: 22, fontWeight: 900, margin: '0 0 6px', letterSpacing: '0.01em' }}>
              AippieSecureChat
            </h2>
            <p style={{ color: '#7F77DD', fontSize: 12, fontWeight: 600, margin: '0 0 20px', letterSpacing: '0.06em' }}>
              FREE FOR EVERYONE — MILITARY-GRADE ENCRYPTED
            </p>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8, marginBottom: 28, textAlign: 'left' }}>
              {[
                { icon: '🔒', text: '7-layer military-grade encryption on every message' },
                { icon: '💣', text: 'Messages self-destruct automatically after reading' },
                { icon: '👁', text: 'Zero-knowledge architecture — nobody can read your chats' },
                { icon: '🕵️', text: 'Someone looks over your shoulder? Chat closes instantly' },
                { icon: '📡', text: 'European servers — protected under EU law' },
                { icon: '🚫', text: 'No data brokers. No advertising. No tracking. Ever.' },
                { icon: '✅', text: 'GDPR compliant · HIPAA ready · ISO 27001 grade' },
              ].map(item => (
                <div key={item.text} style={{
                  display: 'flex', alignItems: 'flex-start', gap: 12,
                  padding: '10px 14px',
                  background: 'rgba(127,119,221,0.06)',
                  border: '1px solid rgba(127,119,221,0.15)',
                  borderRadius: 10,
                }}>
                  <span style={{ fontSize: 14, flexShrink: 0, lineHeight: 1.4 }}>{item.icon}</span>
                  <span style={{ color: '#cbd5e1', fontSize: 12, lineHeight: 1.5 }}>{item.text}</span>
                </div>
              ))}
            </div>
            <button
              onClick={() => {
                setShowEnterpriseModal(false);
                const sc = AVATARS.find(a => a.id === 'securechat');
                if (sc) handleNavigate(sc);
              }}
              style={{
                width: '100%',
                background: 'linear-gradient(135deg, #7F77DD, #5b54b8)',
                color: '#fff', padding: '14px 40px', borderRadius: 12,
                fontSize: 15, fontWeight: 900, border: 'none', cursor: 'pointer',
                letterSpacing: '0.06em', boxShadow: '0 8px 36px rgba(127,119,221,0.45)',
              }}
            >
              Enter SecureChat — Free
            </button>
            <p style={{ color: '#374151', fontSize: 10, marginTop: 14 }}>
              No subscription required · elvin@aippie.com · AIPPIETAX S.A.
            </p>
          </div>
        </div>
      )}
    </div>
  );
}
