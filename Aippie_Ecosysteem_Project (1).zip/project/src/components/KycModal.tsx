import { useState } from 'react';
import { ShieldCheck, CreditCard, X, AlertCircle } from 'lucide-react';
import { supabase, type TranslatorProfile } from '../lib/supabase';
import type { User } from '@supabase/supabase-js';

type Props = {
  user: User;
  existing: TranslatorProfile | null;
  onVerified: (profile: TranslatorProfile) => void;
  onClose: () => void;
};

const COUNTRIES = [
  'Spain', 'Netherlands', 'Germany', 'France', 'Belgium',
  'Italy', 'Portugal', 'Austria', 'Ireland', 'Luxembourg',
  'United Kingdom', 'Other',
];

function formatIBAN(raw: string) {
  return raw.toUpperCase().replace(/\s/g, '').replace(/(.{4})/g, '$1 ').trim();
}

export default function KycModal({ user, existing, onVerified, onClose }: Props) {
  const prefill = existing ?? { full_name: '', iban: '', bic: '', country: '' };

  const [fullName, setFullName] = useState(prefill.full_name);
  const [iban, setIban]         = useState(prefill.iban);
  const [bic, setBic]           = useState(prefill.bic);
  const [country, setCountry]   = useState(prefill.country || '');
  const [saving, setSaving]     = useState(false);
  const [error, setError]       = useState('');

  const validate = () => {
    if (!fullName.trim())             return 'Full legal name is required.';
    const cleanIban = iban.replace(/\s/g, '');
    if (cleanIban.length < 15)        return 'IBAN appears too short.';
    if (!/^[A-Z]{2}/.test(cleanIban)) return 'IBAN must start with a 2-letter country code.';
    if (!bic.trim() || bic.replace(/\s/g,'').length < 8)
                                      return 'BIC/SWIFT must be at least 8 characters.';
    if (!country)                     return 'Please select your country.';
    return '';
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const err = validate();
    if (err) { setError(err); return; }
    setError('');
    setSaving(true);

    const now = new Date().toISOString();
    const payload = {
      user_id:      user.id,
      full_name:    fullName.trim(),
      iban:         iban.replace(/\s/g, '').toUpperCase(),
      bic:          bic.trim().toUpperCase(),
      country,
      kyc_status:   'verified' as const,   // MVP: auto-verify on submit
      submitted_at: now,
      verified_at:  now,
    };

    const { data, error: dbErr } = await supabase
      .from('translator_profiles')
      .upsert(payload, { onConflict: 'user_id' })
      .select()
      .maybeSingle();

    setSaving(false);
    if (dbErr || !data) {
      setError('Could not save your details. Please try again.');
      return;
    }
    onVerified(data as TranslatorProfile);
  };

  return (
    <div className="modal-overlay">
      <div className="modal-sheet">
        {/* Header */}
        <div className="kyc-modal__header">
          <div className="kyc-modal__icon-wrap">
            <ShieldCheck size={22} className="kyc-modal__icon" />
          </div>
          <div>
            <h2 className="kyc-modal__title">Verification Required</h2>
            <p className="kyc-modal__sub">Required before going online to receive calls</p>
          </div>
          <button className="modal-close" onClick={onClose} aria-label="Close">
            <X size={18} />
          </button>
        </div>

        {/* Info banner */}
        <div className="kyc-modal__banner">
          <CreditCard size={15} />
          <span>
            Your bank details are stored securely and used only for monthly payout transfers.
            This verification is <strong>free of charge</strong>.
          </span>
        </div>

        {error && (
          <div className="kyc-modal__error">
            <AlertCircle size={14} />
            <span>{error}</span>
          </div>
        )}

        <form className="kyc-modal__form" onSubmit={handleSubmit} noValidate>
          <div className="modal-field">
            <label className="modal-field__label">Full Legal Name</label>
            <input
              className="modal-pay__input"
              type="text"
              placeholder="As it appears on your bank account"
              value={fullName}
              onChange={e => setFullName(e.target.value)}
              autoComplete="name"
            />
          </div>

          <div className="modal-field">
            <label className="modal-field__label">IBAN</label>
            <input
              className="modal-pay__input modal-pay__input--mono"
              type="text"
              placeholder="e.g. NL91 ABNA 0417 1643 00"
              value={iban}
              onChange={e => setIban(formatIBAN(e.target.value))}
              autoComplete="off"
              spellCheck={false}
              maxLength={34}
            />
          </div>

          <div className="modal-field-row">
            <div className="modal-field">
              <label className="modal-field__label">BIC / SWIFT</label>
              <input
                className="modal-pay__input modal-pay__input--mono"
                type="text"
                placeholder="e.g. ABNANL2A"
                value={bic}
                onChange={e => setBic(e.target.value.toUpperCase())}
                autoComplete="off"
                spellCheck={false}
                maxLength={11}
              />
            </div>

            <div className="modal-field">
              <label className="modal-field__label">Country</label>
              <select
                className="modal-pay__input modal-select"
                value={country}
                onChange={e => setCountry(e.target.value)}
              >
                <option value="">Select…</option>
                {COUNTRIES.map(c => <option key={c} value={c}>{c}</option>)}
              </select>
            </div>
          </div>

          <button
            type="submit"
            className="modal-cta-btn"
            disabled={saving}
          >
            {saving
              ? <><span className="modal__spinner modal__spinner--sm" /> Verifying…</>
              : <><ShieldCheck size={16} /> Verify & Activate Account</>
            }
          </button>
        </form>

        <p className="kyc-modal__legal">
          By submitting you confirm these are your own bank details.
          AIPPIETAX S.A. processes payouts on the 1st of each month.
          Your data is protected under GDPR.
        </p>
      </div>
    </div>
  );
}
