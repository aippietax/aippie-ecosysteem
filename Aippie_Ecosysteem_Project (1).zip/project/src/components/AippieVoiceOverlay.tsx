// @ts-nocheck
/**
 * AippieVoiceOverlay — V206 AnamAIController · Interactive AI Avatar Welcome Mode
 * AIPPIETAX S.A.
 *
 * Green "Start Live Face-to-Face" CTA button mountable inside any product dashboard.
 * When clicked, opens a full-screen AnamAIController modal with:
 *   - aippie-avatar.png centered upper, animated lip-sync rings
 *   - V206: "Hello, I am Aippie, nice meeting you." welcome greeting at rate 0.82
 *   - Typewriter subtitles synchronized below the face
 *   - Product quick-nav grid (Tax · Doctor · Academy · Companion Radar)
 *   - Two-way Web Speech API: user speaks → SpeechRecognition → Aippie responds
 *   - Google US English / Google Nederlands voice at rate 0.82
 *   - 28-bar equalizer waveform active during speech
 */
import { useCallback, useEffect, useRef, useState } from 'react';
import { Mic, MicOff, Video, X, Zap, BarChart2, Stethoscope, GraduationCap, Radar } from 'lucide-react';
import { speakNatural, cancelSpeech } from '../lib/ttsVoice';

// ── Constants ──────────────────────────────────────────────────────────────────
const SPEECH_RATE  = 0.82;
const SPEECH_PITCH = 1.02;

// V206: universal welcome greeting delivered on first open
const WELCOME_GREETING = 'Hello, I am Aippie, nice meeting you.';

// Context-aware response templates — keyed by context prop
const CONTEXT_GREETINGS: Record<string, string> = {
  tax:         'Hallo. Ik ben Aippie, uw AI-belastingadviseur. Vertel mij welke fiscale vraag of boekhoudkundige kwestie ik voor u kan oplossen.',
  voice:       'Hello. I am Aippie, your certified translation assistant. Tell me which language you need, and I will connect you to a live interpreter within seconds.',
  wifi:        'Hello. I am Aippie. Your WiFi sharing node is active. How can I help you optimize your connection or earnings today?',
  companion:   'Hallo. Ik ben Aippie. Ik ben er voor je. Vertel mij hoe je je voelt — ik luister.',
  silentvoice: 'Hello. I am Aippie, your Autism AI Signal Radar. I am scanning all five behavioral signals. Please hold your hand or face towards the camera and I will begin my real-time evaluation.',
  trading:     'Hello. I am Aippie, your Trading Alpha analyst. Tell me which asset, position, or market signal you want me to analyze for you right now.',
  parking:     'Hallo. Ik ben Aippie. Uw parkeerlocatie is actief. Wilt u navigatie starten of een nieuwe parkeerspot registreren?',
  guardian:    'Hello. I am Aippie Guardian. Your safety timer is ready. Tell me how many minutes you need, and I will arm the countdown immediately.',
  wearable:    'Hello. I am Aippie. Your Smart Glass wearable link is ready to pair. Tell me your device model and I will initiate Bluetooth Low Energy scanning.',
  doctor:      'Hallo. Ik ben Aippie Doctor. Vertel mij uw symptomen of gezondheidsklachten in detail, dan help ik u direct met een eerste oriëntatie en wijs ik u de dichtstbijzijnde zorg aan.',
  default:     WELCOME_GREETING,
};

// ── Product quick-nav buttons (V206) ──────────────────────────────────────────
const PRODUCT_NAV_BUTTONS = [
  {
    id: 'tax',
    icon: <BarChart2 size={15} />,
    label: 'Launch AippieTax',
    sub: 'AI Tax & Accounting',
    tab: 'tax',
    color: '#38bdf8',
  },
  {
    id: 'doctor',
    icon: <Stethoscope size={15} />,
    label: 'Open Aippie Doctor',
    sub: 'Medical Suite · €30/consult',
    tab: 'doctor',
    color: '#4ade80',
  },
  {
    id: 'academy',
    icon: <GraduationCap size={15} />,
    label: 'Enter AI Academy',
    sub: '12-Week AI Curriculum',
    tab: 'academy',
    color: '#f59e0b',
  },
  {
    id: 'companionradar',
    icon: <Radar size={15} />,
    label: 'Companion Radar',
    sub: 'Matchmaker · Module 17',
    tab: 'companionradar',
    color: '#fb7185',
  },
] as const;

// Simple context-aware reply engine — keyword matching
function buildReply(input: string, context: string): string {
  const t = input.toLowerCase();

  if (context === 'tax' || context === 'default') {
    if (t.includes('btw') || t.includes('vat'))       return 'I can automatically fill in your VAT return using your invoice history. Do you have access to your accounting software, or would you like to enter the figures manually?';
    if (t.includes('loon') || t.includes('salary'))   return 'For payroll tax and Nominas salary administration I need your BSN or NIE number. Would you like to enter that now or later?';
    if (t.includes('invoice') || t.includes('factuur')) return 'Upload your invoice via the OCR window and I will automatically categorize the amounts in your ledger.';
  }
  if (context === 'doctor') {
    if (t.includes('pijn') || t.includes('pain'))     return 'I understand you are experiencing pain. Can you describe the location and intensity on a scale of one to ten? I am meanwhile searching for the nearest doctors for you.';
    if (t.includes('koorts') || t.includes('fever'))  return 'A fever above 38.5 degrees requires medical attention. I am now activating the GPS radar to find the nearest urgent care clinic for you.';
    if (t.includes('hart') || t.includes('heart'))    return 'For a heart rate measurement, place your fingertip over the camera lens. I will automatically start the PPG biometric scan as soon as I detect a stable signal.';
  }
  if (context === 'trading') {
    if (t.includes('bitcoin') || t.includes('btc'))   return 'Bitcoin spot price is being fetched from live order book feeds. Dark pool activity detected: large buy-side block at the 61.8% Fibonacci retracement. Signal confidence: 87 percent.';
    if (t.includes('signal') || t.includes('signaal')) return 'Three active alpha signals detected in the current session. Two long positions with a risk-reward ratio of 2.8 to 1. Shall I push them to your copy trading queue?';
  }
  if (context === 'companion') {
    if (t.includes('verdrietig') || t.includes('sad')) return 'I hear you. It is completely okay to feel that way. I am right here with you. Would you like to talk about it, or just be quiet together for a moment?';
    if (t.includes('blij') || t.includes('happy'))    return 'That is wonderful to hear! Your energy is contagious. Tell me more — what is making you so happy today?';
  }
  if (context === 'parking') {
    if (t.includes('parkeer') || t.includes('park'))  return 'I am registering your current GPS location as your parking spot. The 3D map has been updated. Tap Route when you want to navigate back to your vehicle.';
  }

  return 'I have registered your question. Give me a moment to retrieve the relevant information and I will get back to you right away with a complete answer.';
}

// ── Typewriter subtitle hook ───────────────────────────────────────────────────
function useWordSubtitle(text: string, active: boolean) {
  const [sub, setSub] = useState('');
  const tmr = useRef<ReturnType<typeof setInterval> | null>(null);
  const idx  = useRef(0);
  useEffect(() => {
    if (tmr.current) { clearInterval(tmr.current); tmr.current = null; }
    setSub('');
    if (!active || !text.trim()) return;
    const words = text.split(/\s+/);
    idx.current = 0;
    tmr.current = setInterval(() => {
      idx.current++;
      setSub(words.slice(Math.max(0, idx.current - 9), idx.current).join(' '));
      if (idx.current >= words.length && tmr.current) { clearInterval(tmr.current); tmr.current = null; }
    }, 510);
    return () => { if (tmr.current) { clearInterval(tmr.current); tmr.current = null; } };
  }, [text, active]);
  return sub;
}

// ── 28-bar waveform ────────────────────────────────────────────────────────────
function Waveform({ active, color = '#4ade80' }: { active: boolean; color?: string }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const frameRef  = useRef<number>(0);
  const tickRef   = useRef(0);
  useEffect(() => {
    const canvas = canvasRef.current; if (!canvas) return;
    const ctx = canvas.getContext('2d'); if (!ctx) return;
    const draw = () => {
      tickRef.current++;
      const tk = tickRef.current, W = canvas.width, H = canvas.height;
      ctx.clearRect(0, 0, W, H);
      const gap = W / 28, barW = Math.max(2, gap - 2);
      for (let i = 0; i < 28; i++) {
        const phase = (i / 28) * Math.PI * 2;
        const rawH = active
          ? (0.10 + 0.90 * Math.abs(Math.sin(tk * 0.07 + phase))) * H
          : (0.04 + 0.03 * Math.abs(Math.sin(tk * 0.015 + phase))) * H;
        const x = i * gap + (gap - barW) / 2, y = (H - rawH) / 2;
        ctx.fillStyle = active ? color + 'ee' : color + '2a';
        ctx.beginPath(); ctx.roundRect(x, y, barW, rawH, Math.min(barW / 2, 4)); ctx.fill();
      }
      frameRef.current = requestAnimationFrame(draw);
    };
    frameRef.current = requestAnimationFrame(draw);
    return () => cancelAnimationFrame(frameRef.current);
  }, [active, color]);
  return <canvas ref={canvasRef} width={320} height={36} aria-hidden="true" className="avo-waveform" />;
}

// ── AnamAIController modal ─────────────────────────────────────────────────────
function AnamAIController({
  context,
  onClose,
  onNavigate,
}: {
  context: string;
  onClose: () => void;
  onNavigate?: (tab: string) => void;
}) {
  const [speaking,    setSpeaking]    = useState(false);
  const [listening,   setListening]   = useState(false);
  const [transcript,  setTranscript]  = useState('');
  const [subtitleTxt, setSubtitleTxt] = useState('');
  const [chatLog,     setChatLog]     = useState<{ role: 'aippie' | 'user'; text: string }[]>([]);

  const subtitle     = useWordSubtitle(subtitleTxt, speaking);
  const cancelRef    = useRef(false);
  const recognRef    = useRef<SpeechRecognition | null>(null);

  const isWelcomeMode = context === 'default';

  // ── speak helper ─────────────────────────────────────────────────────────────
  const speak = useCallback((text: string) => {
    setSubtitleTxt(text);
    const isNl = context === 'companion' || context === 'doctor' || context === 'tax' || context === 'parking';
    speakNatural(text, {
      lang: isNl ? 'nl' : 'en',
      onStart: () => setSpeaking(true),
      onEnd:   () => setSpeaking(false),
    });
  }, [context]);

  // ── Mount greeting ────────────────────────────────────────────────────────────
  useEffect(() => {
    cancelRef.current = false;
    const greeting = CONTEXT_GREETINGS[context] ?? CONTEXT_GREETINGS['default'];
    setChatLog([{ role: 'aippie', text: greeting }]);
    speak(greeting);
    return () => {
      cancelRef.current = true;
      cancelSpeech();
      if (recognRef.current) { try { recognRef.current.stop(); } catch { /* ignore */ } }
    };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // ── Start listening ───────────────────────────────────────────────────────────
  const startListening = useCallback(() => {
    const SR = (window as typeof window & { SpeechRecognition?: typeof SpeechRecognition; webkitSpeechRecognition?: typeof SpeechRecognition }).SpeechRecognition
      ?? (window as typeof window & { webkitSpeechRecognition?: typeof SpeechRecognition }).webkitSpeechRecognition;
    if (!SR) {
      speak('Spraakherkenning is niet beschikbaar in deze browser. Gebruik Chrome voor de beste ervaring.');
      return;
    }
    window.speechSynthesis?.cancel();
    setSpeaking(false);

    const r = new SR();
    r.lang = 'en-US';
    r.continuous      = false;
    r.interimResults  = true;
    recognRef.current = r;

    r.onstart  = () => setListening(true);
    r.onresult = (e) => {
      const t = Array.from(e.results).map(r => r[0].transcript).join('');
      setTranscript(t);
    };
    r.onend = () => {
      setListening(false);
      const finalText = transcript || (recognRef.current as unknown as { _lastTranscript?: string })?._lastTranscript || '';
      if (finalText.trim()) {
        setChatLog(prev => [...prev, { role: 'user', text: finalText }]);
        setTranscript('');
        setTimeout(() => {
          const reply = buildReply(finalText, context);
          setChatLog(prev => [...prev, { role: 'aippie', text: reply }]);
          speak(reply);
        }, 400);
      }
    };
    r.onerror = () => { setListening(false); };
    r.start();
  }, [context, speak, transcript]);

  const stopListening = useCallback(() => {
    try { recognRef.current?.stop(); } catch { /* ignore */ }
    setListening(false);
  }, []);

  // ── Product nav handler ───────────────────────────────────────────────────────
  const handleProductNav = useCallback((tab: string) => {
    cancelSpeech();
    onClose();
    if (onNavigate) {
      onNavigate(tab);
    } else {
      // Dispatch a CustomEvent so App.tsx can route without prop drilling
      window.dispatchEvent(new CustomEvent('aippie:navigate', { detail: tab }));
    }
  }, [onClose, onNavigate]);

  return (
    <div className="avo-modal" role="dialog" aria-modal="true" aria-label="Aippie Face-to-Face">
      <div className="avo-modal__backdrop" onClick={onClose} />
      <div className={`avo-modal__panel${isWelcomeMode ? ' avo-modal__panel--welcome' : ''}`}>

        {/* Close */}
        <button className="avo-modal__close" onClick={onClose} aria-label="Sluiten">
          <X size={18} />
        </button>

        {/* Header */}
        <div className="avo-modal__header">
          <Video size={13} style={{ color: '#4ade80' }} />
          <span>{isWelcomeMode ? 'Aippie AI · Welcome Mode · v209' : 'Live Face-to-Face · AnamAIController'}</span>
          <span className="avo-modal__live-dot" />
          <span style={{ color: '#4ade80', fontSize: '10px', fontWeight: 700 }}>LIVE</span>
        </div>

        {/* Avatar — upper center, larger in welcome mode */}
        <div className={`avo-avatar-wrap${speaking ? ' avo-avatar-wrap--speaking' : ''}${isWelcomeMode ? ' avo-avatar-wrap--welcome' : ''}`}>
          <img
            src="/Jouw_alineatekst_(2).png"
            alt="Aippie"
            className={`avo-avatar-img${speaking ? ' avo-avatar-img--speaking' : ''}${isWelcomeMode ? ' avo-avatar-img--welcome' : ''}`}
            onError={e => {
              (e.currentTarget as HTMLImageElement).src =
                'https://images.pexels.com/photos/1858175/pexels-photo-1858175.jpeg?auto=compress&cs=tinysrgb&w=600&h=800&fit=crop&crop=faces';
            }}
          />
          {speaking && <div className="avo-ring avo-ring--1" />}
          {speaking && <div className="avo-ring avo-ring--2" />}
          {listening && <div className="avo-ring avo-ring--listen" />}
        </div>

        {/* Waveform */}
        <div className="avo-wave-row">
          {speaking && <Mic size={11} style={{ color: '#4ade80', flexShrink: 0 }} />}
          {listening && <MicOff size={11} style={{ color: '#fb7185', flexShrink: 0 }} />}
          <Waveform active={speaking || listening} color={listening ? '#fb7185' : '#4ade80'} />
        </div>

        {/* Typewriter subtitle — large synchronized bar in welcome mode */}
        <div className={`avo-subtitle${speaking && subtitle ? ' avo-subtitle--active' : ''}${isWelcomeMode ? ' avo-subtitle--welcome' : ''}`}>
          {speaking && subtitle
            ? subtitle
            : listening
            ? (transcript || '…listening…')
            : isWelcomeMode
            ? 'Hello, I am Aippie — select a module below or speak to me.'
            : '\u00A0'
          }
        </div>

        {/* V206: Product quick-nav grid — only in welcome mode */}
        {isWelcomeMode && (
          <div className="avo-product-grid">
            {PRODUCT_NAV_BUTTONS.map(btn => (
              <button
                key={btn.id}
                className="avo-product-btn"
                style={{ '--avo-btn-color': btn.color } as React.CSSProperties}
                onClick={() => handleProductNav(btn.tab)}
              >
                <span className="avo-product-btn__icon" style={{ color: btn.color }}>
                  {btn.icon}
                </span>
                <span className="avo-product-btn__label">{btn.label}</span>
                <span className="avo-product-btn__sub">{btn.sub}</span>
              </button>
            ))}
          </div>
        )}

        {/* Chat log — only in non-welcome mode */}
        {!isWelcomeMode && (
          <div className="avo-chat-log">
            {chatLog.map((row, i) => (
              <div key={i} className={`avo-chat-row avo-chat-row--${row.role}`}>
                {row.role === 'aippie' && (
                  <img src="/Jouw_alineatekst_(2).png" alt="Aippie" className="avo-chat-thumb"
                    onError={e => { (e.currentTarget as HTMLImageElement).src = 'https://images.pexels.com/photos/1858175/pexels-photo-1858175.jpeg?auto=compress&cs=tinysrgb&w=60&h=60&fit=crop&crop=faces'; }}
                  />
                )}
                <div className="avo-chat-bubble">{row.text}</div>
              </div>
            ))}
          </div>
        )}

        {/* Mic CTA */}
        <div className="avo-mic-row">
          {!listening ? (
            <button className="avo-mic-btn" onClick={startListening}>
              <Mic size={18} />
              <span>Spreek nu</span>
            </button>
          ) : (
            <button className="avo-mic-btn avo-mic-btn--listening" onClick={stopListening}>
              <MicOff size={18} />
              <span>Stoppen</span>
            </button>
          )}
        </div>

        <div className="avo-modal__footer">
          <Zap size={9} />
          AIPPIETAX S.A. · v209 · Google {context === 'companion' || context === 'doctor' ? 'Nederlands' : 'US English'} · E2EE
        </div>
      </div>
    </div>
  );
}

// ── Public: green CTA button + overlay controller ─────────────────────────────
export default function AippieVoiceOverlay({
  context = 'default',
  onNavigate,
}: {
  context?: string;
  onNavigate?: (tab: string) => void;
}) {
  const [open, setOpen] = useState(false);

  return (
    <>
      <button
        className="avo-cta-btn"
        onClick={() => setOpen(true)}
        aria-label="Start live face-to-face gesprek met Aippie"
      >
        <span className="avo-cta-btn__dot" />
        <Video size={15} />
        Start Live Face-to-Face Gesprek met Aippie
      </button>

      {open && (
        <AnamAIController
          context={context}
          onClose={() => setOpen(false)}
          onNavigate={onNavigate}
        />
      )}
    </>
  );
}
