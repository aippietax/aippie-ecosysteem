/**
 * CompanionRadarView — V190 Companionship & Matchmaker Radar · Module 17
 * AIPPIETAX S.A.
 *
 * Two user roles:
 *   A. The Seeker  — €5.00/month auto-terminating search loop (12-week max)
 *   B. The Provider — Secured payout ledger · 15% platform escrow commission
 *
 * Features:
 *   - AI Live Face & Identity Verification Pipeline (camera stream + face mesh)
 *   - Split-screen match connection popup with avatar speech at 0.82
 *   - Provider payout ledger with 85/15 split
 */
import { useCallback, useEffect, useRef, useState } from 'react';
import AippieVoiceOverlay from './AippieVoiceOverlay';
import FatigueCompanion from './FatigueCompanion';
import {
  Radar, Users, Heart, DollarSign, Camera, CameraOff,
  CheckCircle2, AlertCircle, ShieldCheck, Mic, Activity,
  Star, MapPin, ChevronRight, RefreshCw, Building2,
  CreditCard, ArrowDownToLine, Zap, Eye, X,
} from 'lucide-react';
import { supabase } from '../lib/supabase';
import { applyPremiumVoice, withVoicesReady } from '../lib/ttsVoice';

// ── Constants ──────────────────────────────────────────────────────────────────
const SPEECH_RATE        = 0.82;
const SPEECH_PITCH       = 1.02;
const SEEKER_PRICE_EUR   = 5.00;
const PLATFORM_ESCROW    = 0.15; // 15 % retained by AIPPIETAX S.A.
const PROVIDER_RATE      = 1 - PLATFORM_ESCROW; // 85 %

// ── Types ──────────────────────────────────────────────────────────────────────
type RadarRole   = 'none' | 'seeker' | 'provider';
type CamPhase    = 'idle' | 'requesting' | 'active' | 'denied';
type FacePhase   = 'scanning' | 'detected' | 'verified' | 'failed';
type MatchPhase  = 'searching' | 'found' | 'connecting' | 'connected';
type PayPhase    = 'idle' | 'processing' | 'success' | 'error';

interface MatchProfile {
  id:       string;
  name:     string;
  age:      number;
  city:     string;
  tag:      string;
  score:    number;
  portrait: string;
}

interface PayoutRow {
  id: string; session_mins: number; gross_eur: number;
  escrow_eur: number; net_eur: number; status: string; created_at: string;
}

// ── Simulated match profiles ───────────────────────────────────────────────────
const MATCH_POOL: MatchProfile[] = [
  { id: 'm1', name: 'Sophie',  age: 28, city: 'Amsterdam',  tag: 'Creative · Music · Travel',  score: 97, portrait: 'https://images.pexels.com/photos/1130626/pexels-photo-1130626.jpeg?auto=compress&cs=tinysrgb&w=300&h=360&fit=crop&crop=faces' },
  { id: 'm2', name: 'Lara',    age: 31, city: 'Barcelona',  tag: 'Yoga · Cooking · Arts',       score: 94, portrait: 'https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=300&h=360&fit=crop&crop=faces' },
  { id: 'm3', name: 'Eva',     age: 26, city: 'Madrid',     tag: 'Fitness · Tech · Cinema',     score: 91, portrait: 'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=300&h=360&fit=crop&crop=faces' },
  { id: 'm4', name: 'Mia',     age: 29, city: 'Rotterdam',  tag: 'Books · Nature · Wellness',   score: 89, portrait: 'https://images.pexels.com/photos/415829/pexels-photo-415829.jpeg?auto=compress&cs=tinysrgb&w=300&h=360&fit=crop&crop=faces' },
  { id: 'm5', name: 'Zara',    age: 33, city: 'Valencia',   tag: 'Dance · Design · Languages',  score: 86, portrait: 'https://images.pexels.com/photos/1181690/pexels-photo-1181690.jpeg?auto=compress&cs=tinysrgb&w=300&h=360&fit=crop&crop=faces' },
];

const FACE_MESH_PARAMS = [
  { label: 'Landmark Points',    val: '468',       color: '#38bdf8' },
  { label: 'Liveness Score',     val: '0.98',      color: '#4ade80' },
  { label: 'Symmetry Index',     val: '94.3%',     color: '#fbbf24' },
  { label: 'ID Confidence',      val: '99.1%',     color: '#4ade80' },
  { label: 'Spoof Detection',    val: 'Real ✓',    color: '#4ade80' },
  { label: 'Age Estimate',       val: '25–35',     color: '#94a3b8' },
];

const PROVIDER_SESSIONS: PayoutRow[] = [
  { id: 'p1', session_mins: 45, gross_eur: 22.50, escrow_eur: 3.38, net_eur: 19.13, status: 'paid',    created_at: '2026-05-18T14:30:00Z' },
  { id: 'p2', session_mins: 30, gross_eur: 15.00, escrow_eur: 2.25, net_eur: 12.75, status: 'paid',    created_at: '2026-05-17T11:15:00Z' },
  { id: 'p3', session_mins: 60, gross_eur: 30.00, escrow_eur: 4.50, net_eur: 25.50, status: 'pending', created_at: '2026-05-19T09:00:00Z' },
];

export default function CompanionRadarView() {
  const [role,         setRole]         = useState<RadarRole>('none');
  const [camPhase,     setCamPhase]     = useState<CamPhase>('idle');
  const [facePhase,    setFacePhase]    = useState<FacePhase>('scanning');
  const [camStream,    setCamStream]    = useState<MediaStream | null>(null);
  const [matchPhase,   setMatchPhase]   = useState<MatchPhase>('searching');
  const [matches,      setMatches]      = useState<MatchProfile[]>([]);
  const [activeMatch,  setActiveMatch]  = useState<MatchProfile | null>(null);
  const [showMatchPop, setShowMatchPop] = useState(false);
  const [seekerCard,   setSeekerCard]   = useState('');
  const [seekerCardErr,setSeekerCardErr]= useState('');
  const [payPhase,     setPayPhase]     = useState<PayPhase>('idle');
  const [seekerActive, setSeekerActive] = useState(false);
  const [ibanInput,    setIbanInput]    = useState('');
  const [payoutPhase,  setPayoutPhase]  = useState<'idle'|'processing'|'success'>('idle');
  const [speaking,     setSpeaking]     = useState(false);
  const [subtitle,     setSubtitle]     = useState('');

  const videoRef       = useRef<HTMLVideoElement>(null);
  const cancelledRef   = useRef(false);
  const faceTimerRef   = useRef<ReturnType<typeof setTimeout> | null>(null);
  const matchTimerRef  = useRef<ReturnType<typeof setTimeout> | null>(null);

  // ── TTS ───────────────────────────────────────────────────────────────────────
  const speak = useCallback((text: string, onEnd?: () => void) => {
    if (!('speechSynthesis' in window)) { onEnd?.(); return; }
    cancelledRef.current = true;
    window.speechSynthesis.cancel();
    cancelledRef.current = false;
    const words = text.split(' ');
    let wordIdx = 0;
    const interval = setInterval(() => {
      if (cancelledRef.current) { clearInterval(interval); return; }
      setSubtitle(words.slice(Math.max(0, wordIdx - 2), wordIdx + 3).join(' '));
      wordIdx++;
      if (wordIdx >= words.length) clearInterval(interval);
    }, 280);
    setSpeaking(true);
    withVoicesReady(() => {
      if (cancelledRef.current) return;
      const u = new SpeechSynthesisUtterance(text);
      u.rate  = SPEECH_RATE;
      u.pitch = SPEECH_PITCH;
      applyPremiumVoice(u);
      u.onend   = () => { setSpeaking(false); setSubtitle(''); if (!cancelledRef.current) onEnd?.(); };
      u.onerror = () => { setSpeaking(false); setSubtitle(''); if (!cancelledRef.current) onEnd?.(); };
      window.speechSynthesis.speak(u);
    });
  }, []);

  // ── Camera: start live face verification stream ───────────────────────────────
  const startCamera = useCallback(async () => {
    setCamPhase('requesting');
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'user' }, audio: false });
      setCamStream(stream);
      setCamPhase('active');
      setFacePhase('scanning');
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.play().catch(() => {});
      }
      // Simulate face mesh pipeline
      faceTimerRef.current = setTimeout(() => setFacePhase('detected'), 1200);
      setTimeout(() => setFacePhase('verified'), 3000);
    } catch {
      setCamPhase('denied');
      setFacePhase('failed');
    }
  }, []);

  const stopCamera = useCallback(() => {
    camStream?.getTracks().forEach(t => t.stop());
    setCamStream(null);
    if (videoRef.current) videoRef.current.srcObject = null;
    setCamPhase('idle');
    setFacePhase('scanning');
  }, [camStream]);

  // ── Seeker: activate subscription ─────────────────────────────────────────────
  const activateSeeker = useCallback(() => {
    const digits = seekerCard.replace(/\s/g, '');
    if (digits.length !== 16) { setSeekerCardErr('Please enter a valid 16-digit card number.'); return; }
    setSeekerCardErr('');
    setPayPhase('processing');
    speak('Payment processed. Search subscription activated. Five euros per month. Automatically cancelled after week twelve.');
    setTimeout(() => {
      setPayPhase('success');
      setSeekerActive(true);
      setMatchPhase('searching');
      // Simulate radar scan → matches found
      matchTimerRef.current = setTimeout(() => {
        setMatches(MATCH_POOL);
        setMatchPhase('found');
      }, 2200);
    }, 2600);
  }, [seekerCard, speak]);

  // ── Match connection popup ─────────────────────────────────────────────────────
  const connectMatch = useCallback((profile: MatchProfile) => {
    setActiveMatch(profile);
    setMatchPhase('connecting');
    setShowMatchPop(true);
    speak(`Match found. Connecting with ${profile.name} from ${profile.city}. Compatibility score ${profile.score} percent. Identity verification passed. Welcome, ${profile.name}.`, () => {
      setMatchPhase('connected');
    });
  }, [speak]);

  // ── Provider: payout simulation ───────────────────────────────────────────────
  const requestPayout = useCallback(() => {
    if (!ibanInput.trim()) return;
    setPayoutPhase('processing');
    speak('Payout request submitted. Escrow settled. Net payment is being processed.');
    setTimeout(() => setPayoutPhase('success'), 2400);
  }, [ibanInput, speak]);

  // Unmount cleanup
  useEffect(() => {
    cancelledRef.current = false;
    return () => {
      cancelledRef.current = true;
      window.speechSynthesis?.cancel();
      camStream?.getTracks().forEach(t => t.stop());
      if (faceTimerRef.current) clearTimeout(faceTimerRef.current);
      if (matchTimerRef.current) clearTimeout(matchTimerRef.current);
    };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Attach stream to video element when stream changes
  useEffect(() => {
    if (camStream && videoRef.current) {
      videoRef.current.srcObject = camStream;
      videoRef.current.play().catch(() => {});
    }
  }, [camStream]);

  // ── Render ────────────────────────────────────────────────────────────────────
  return (
    <div className="cr-root">
      <div className="cr-bg" />

      {/* ── Match connection pop-up overlay ─────────────────────────────────── */}
      {showMatchPop && activeMatch && (
        <div className="cr-match-popup">
          <div className="cr-match-popup__inner">
            <button className="cr-match-popup__close" onClick={() => { setShowMatchPop(false); setActiveMatch(null); setMatchPhase('found'); }}>
              <X size={14} />
            </button>

            {/* Split screen: aippie avatar left | match right */}
            <div className="cr-match-split">
              <div className="cr-match-split__side cr-match-split__side--avatar">
                <div className="cr-popup-avatar-wrap">
                  <img
                    src="/Jouw_alineatekst_(2).png"
                    alt="Aippie"
                    className={`cr-popup-avatar${speaking ? ' cr-popup-avatar--speaking' : ''}`}
                    onError={e => { (e.currentTarget as HTMLImageElement).src = 'https://images.pexels.com/photos/1858175/pexels-photo-1858175.jpeg?auto=compress&cs=tinysrgb&w=200&h=240&fit=crop&crop=faces'; }}
                  />
                  {speaking && <div className="cr-popup-avatar-ring" />}
                  <div className="cr-popup-avatar-label">Aippie · Matchmaker</div>
                </div>
                {subtitle && speaking && (
                  <div className="cr-popup-subtitle">{subtitle}</div>
                )}
                {!speaking && matchPhase === 'connected' && (
                  <div className="cr-popup-subtitle cr-popup-subtitle--connected">
                    <CheckCircle2 size={10} style={{ color: '#4ade80' }} /> Connection active
                  </div>
                )}
              </div>

              <div className="cr-match-split__side cr-match-split__side--profile">
                <img
                  src={activeMatch.portrait}
                  alt={activeMatch.name}
                  className="cr-popup-portrait"
                  onError={e => { (e.currentTarget as HTMLImageElement).src = 'https://images.pexels.com/photos/1130626/pexels-photo-1130626.jpeg?auto=compress&cs=tinysrgb&w=200&h=240&fit=crop&crop=faces'; }}
                />
                <div className="cr-popup-profile-info">
                  <div className="cr-popup-profile-name">{activeMatch.name}, {activeMatch.age}</div>
                  <div className="cr-popup-profile-city"><MapPin size={9} /> {activeMatch.city}</div>
                  <div className="cr-popup-profile-tag">{activeMatch.tag}</div>
                  <div className="cr-popup-score">
                    <Star size={9} style={{ color: '#fbbf24' }} /> {activeMatch.score}% match
                  </div>
                  {matchPhase === 'connected' && (
                    <div className="cr-popup-verified">
                      <ShieldCheck size={9} style={{ color: '#4ade80' }} /> Identity verified
                    </div>
                  )}
                </div>
              </div>
            </div>

            <div className="cr-popup-status">
              {matchPhase === 'connecting' && <><Activity size={10} className="rem-spin" style={{ color: '#38bdf8' }} /> Initializing connection…</>}
              {matchPhase === 'connected'  && <><CheckCircle2 size={10} style={{ color: '#4ade80' }} /> Connected · AI-intro active</>}
            </div>
          </div>
        </div>
      )}

      {/* ── Header ──────────────────────────────────────────────────────────── */}
      <div className="cr-header">
        <div className="cr-header__left">
          <Radar size={14} style={{ color: '#fb7185' }} />
          <div>
            <div className="cr-header__title">Aippie Companionship &amp; Matchmaker Radar</div>
            <div className="cr-header__sub">AIPPIETAX S.A. · Module 17 · v190 · AI Live Face Verification</div>
          </div>
        </div>
        <div className="cr-header__badge">
          <Activity size={9} /> Live
        </div>
      </div>

      {/* ── Role selector ───────────────────────────────────────────────────── */}
      {role === 'none' && (
        <div className="cr-role-selector">
          <div className="cr-role-selector__title">Choose your role to get started</div>
          <div className="cr-role-grid">
            <button className="cr-role-card cr-role-card--seeker" onClick={() => setRole('seeker')}>
              <Heart size={22} style={{ color: '#fb7185' }} />
              <div className="cr-role-card__name">The Seeker</div>
              <div className="cr-role-card__price" style={{ color: '#fb7185' }}>€{SEEKER_PRICE_EUR.toFixed(2)}/month</div>
              <div className="cr-role-card__desc">Auto-terminating search loop. Find your match within 12 weeks.</div>
              <ul className="cr-role-card__features">
                <li><CheckCircle2 size={9} style={{ color: '#fb7185' }} /> AI matchmaking radar active</li>
                <li><CheckCircle2 size={9} style={{ color: '#fb7185' }} /> Live face verification</li>
                <li><CheckCircle2 size={9} style={{ color: '#fb7185' }} /> Auto-termination after Week 12</li>
                <li><CheckCircle2 size={9} style={{ color: '#fb7185' }} /> Unlimited profiles view</li>
              </ul>
              <div className="cr-role-card__cta">
                <ChevronRight size={11} /> Activate Seeker
              </div>
            </button>

            <button className="cr-role-card cr-role-card--provider" onClick={() => setRole('provider')}>
              <DollarSign size={22} style={{ color: '#4ade80' }} />
              <div className="cr-role-card__name">The Provider</div>
              <div className="cr-role-card__price" style={{ color: '#4ade80' }}>85% payout</div>
              <div className="cr-role-card__desc">Earn through companionship. Secured payout ledger. 15% platform escrow.</div>
              <ul className="cr-role-card__features">
                <li><CheckCircle2 size={9} style={{ color: '#4ade80' }} /> 85% net per session</li>
                <li><CheckCircle2 size={9} style={{ color: '#4ade80' }} /> Secured escrow system</li>
                <li><CheckCircle2 size={9} style={{ color: '#4ade80' }} /> Live session tracking</li>
                <li><CheckCircle2 size={9} style={{ color: '#4ade80' }} /> IBAN payout portal</li>
              </ul>
              <div className="cr-role-card__cta" style={{ borderColor: '#4ade8044', color: '#4ade80', background: '#4ade8011' }}>
                <ChevronRight size={11} /> Become Provider
              </div>
            </button>
          </div>
        </div>
      )}

      {/* ── AI Live Face & Identity Verification Pipeline ─────────────────────
          Shown for both roles once selected
      ──────────────────────────────────────────────────────────────────────── */}
      {role !== 'none' && (
        <div className="cr-face-panel">
          <div className="cr-face-panel__header">
            <Eye size={12} style={{ color: '#38bdf8' }} />
            <span>AI Live Face &amp; Identity Verification Pipeline</span>
            <div className={`cr-face-status cr-face-status--${facePhase}`}>
              {facePhase === 'scanning'  && <><Activity size={8} className="rem-spin" /> Scanning…</>}
              {facePhase === 'detected'  && <><Activity size={8} /> Face detected</>}
              {facePhase === 'verified'  && <><CheckCircle2 size={8} /> Verified</>}
              {facePhase === 'failed'    && <><AlertCircle size={8} /> Access denied</>}
            </div>
          </div>

          <div className="cr-face-viewport">
            {/* Camera stream */}
            <div className="cr-cam-wrap">
              {camPhase === 'active' ? (
                <div className="cr-cam-frame">
                  <video
                    ref={videoRef}
                    className="cr-cam-video"
                    muted
                    playsInline
                    aria-hidden="true"
                  />
                  {/* Face mesh overlay */}
                  <div className={`cr-face-mesh${facePhase === 'verified' ? ' cr-face-mesh--verified' : ''}`}>
                    <div className="cr-face-mesh__corner cr-face-mesh__corner--tl" />
                    <div className="cr-face-mesh__corner cr-face-mesh__corner--tr" />
                    <div className="cr-face-mesh__corner cr-face-mesh__corner--bl" />
                    <div className="cr-face-mesh__corner cr-face-mesh__corner--br" />
                    {facePhase === 'verified' && (
                      <div className="cr-face-mesh__verified">
                        <CheckCircle2 size={18} style={{ color: '#4ade80' }} />
                      </div>
                    )}
                  </div>
                  <button className="cr-cam-stop" onClick={stopCamera}>
                    <CameraOff size={10} />
                  </button>
                </div>
              ) : (
                <div className="cr-cam-idle">
                  <Camera size={28} style={{ color: '#334155' }} />
                  <span>
                    {camPhase === 'idle'      ? 'Enable camera for live face verification'
                   : camPhase === 'requesting' ? 'Requesting camera access…'
                   : 'Camera access denied — use phone settings'}
                  </span>
                  {camPhase !== 'requesting' && (
                    <button className="cr-cam-start-btn" onClick={startCamera}>
                      <Camera size={11} /> Start camera
                    </button>
                  )}
                </div>
              )}
            </div>

            {/* Face mesh telemetry parameters */}
            <div className="cr-face-metrics">
              {FACE_MESH_PARAMS.map(p => (
                <div key={p.label} className="cr-face-metric">
                  <span className="cr-face-metric__label">{p.label}</span>
                  <span className="cr-face-metric__val" style={{ color: p.color }}>{p.val}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* ══════════════════════════════════════════════════════════════════════
          SEEKER INTERFACE
      ══════════════════════════════════════════════════════════════════════ */}
      {role === 'seeker' && (
        <div className="cr-seeker-panel">
          {!seekerActive ? (
            /* Payment gate */
            <div className="cr-paywall">
              <div className="cr-paywall__header">
                <Heart size={13} style={{ color: '#fb7185' }} />
                <div>
                  <div className="cr-paywall__title">Seeker Abonnement · €{SEEKER_PRICE_EUR.toFixed(2)}/maand</div>
                  <div className="cr-paywall__sub">Automatisch beëindigd na Week 12 certificering</div>
                </div>
              </div>
              <div className="cr-paywall__price-row">
                <span style={{ color: '#fb7185', fontSize: 28, fontWeight: 900 }}>€{SEEKER_PRICE_EUR.toFixed(2)}</span>
                <span style={{ color: '#475569', fontSize: 11 }}>/month · max 12 weeks</span>
              </div>
              <label className="cr-form-label"><CreditCard size={10} /> Card Number</label>
              <div className="cr-input-row">
                <input
                  className="cr-card-input"
                  placeholder="4242 4242 4242 4242"
                  maxLength={19}
                  value={seekerCard}
                  onChange={e => {
                    const raw = e.target.value.replace(/\D/g, '').slice(0, 16);
                    setSeekerCard(raw.replace(/(.{4})/g, '$1 ').trim());
                    setSeekerCardErr('');
                  }}
                />
                <button
                  className="cr-pay-btn"
                  onClick={activateSeeker}
                  disabled={payPhase === 'processing'}
                  style={{ background: '#fb718511', borderColor: '#fb718555', color: '#fb7185' }}
                >
                  {payPhase === 'processing'
                    ? <><Activity size={10} className="rem-spin" /> Processing…</>
                    : <><Zap size={10} /> Activate</>}
                </button>
              </div>
              {seekerCardErr && <div className="cr-card-err"><AlertCircle size={9} /> {seekerCardErr}</div>}
              <div className="cr-card-hint">Test mode · use <span style={{ color: '#fbbf24' }}>4242 4242 4242 4242</span></div>
            </div>
          ) : (
            /* Radar view with matches */
            <div className="cr-radar-active">
              <div className="cr-radar-status">
                <Radar size={11} style={{ color: '#fb7185' }} />
                <span>Matchmaker Radar Active · {matches.length} profiles found</span>
                <div className="cr-radar-dot" />
              </div>

              {matchPhase === 'searching' && (
                <div className="cr-searching">
                  <div className="cr-radar-anim">
                    <div className="cr-radar-ring cr-radar-ring--1" />
                    <div className="cr-radar-ring cr-radar-ring--2" />
                    <div className="cr-radar-ring cr-radar-ring--3" />
                    <Radar size={20} style={{ color: '#fb7185', position: 'relative', zIndex: 1 }} />
                  </div>
                  <span>AI matchmaker scanning…</span>
                </div>
              )}

              {matchPhase === 'found' && (
                <div className="cr-match-grid">
                  {matches.map(m => (
                    <div key={m.id} className="cr-match-card" onClick={() => connectMatch(m)}>
                      <img
                        src={m.portrait}
                        alt={m.name}
                        className="cr-match-card__img"
                        onError={e => { (e.currentTarget as HTMLImageElement).src = 'https://images.pexels.com/photos/1130626/pexels-photo-1130626.jpeg?auto=compress&cs=tinysrgb&w=200&h=240&fit=crop&crop=faces'; }}
                      />
                      <div className="cr-match-card__info">
                        <div className="cr-match-card__name">{m.name}, {m.age}</div>
                        <div className="cr-match-card__city"><MapPin size={8} /> {m.city}</div>
                        <div className="cr-match-card__tag">{m.tag}</div>
                        <div className="cr-match-card__score">
                          <Star size={8} style={{ color: '#fbbf24' }} /> {m.score}%
                        </div>
                      </div>
                      <button className="cr-match-card__connect">
                        <Zap size={9} /> Connect
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {/* ══════════════════════════════════════════════════════════════════════
          PROVIDER INTERFACE
      ══════════════════════════════════════════════════════════════════════ */}
      {role === 'provider' && (
        <div className="cr-provider-panel">

          {/* Earnings overview */}
          <div className="cr-provider-header">
            <div className="cr-provider-header__left">
              <DollarSign size={13} style={{ color: '#4ade80' }} />
              <div>
                <div className="cr-provider-header__title">Provider Payout Ledger</div>
                <div className="cr-provider-header__sub">85% net payout · 15% AIPPIETAX S.A. escrow</div>
              </div>
            </div>
            <div className="cr-provider-totals">
              <div className="cr-provider-total">
                <span style={{ color: '#4ade80', fontSize: 18, fontWeight: 900 }}>
                  €{PROVIDER_SESSIONS.filter(s => s.status === 'paid').reduce((a, s) => a + s.net_eur, 0).toFixed(2)}
                </span>
                <span style={{ fontSize: 8, color: '#475569' }}>Total paid</span>
              </div>
              <div className="cr-provider-total">
                <span style={{ color: '#fbbf24', fontSize: 18, fontWeight: 900 }}>
                  €{PROVIDER_SESSIONS.filter(s => s.status === 'pending').reduce((a, s) => a + s.net_eur, 0).toFixed(2)}
                </span>
                <span style={{ fontSize: 8, color: '#475569' }}>Pending</span>
              </div>
            </div>
          </div>

          {/* Session ledger */}
          <div className="cr-provider-ledger">
            <div className="cr-provider-ledger__header">Session Overview</div>
            {PROVIDER_SESSIONS.map(s => (
              <div key={s.id} className="cr-provider-row">
                <div className="cr-provider-row__left">
                  <div className="cr-provider-row__time">{s.session_mins} min</div>
                  <div className="cr-provider-row__date">{new Date(s.created_at).toLocaleDateString('nl-NL', { day: '2-digit', month: 'short' })}</div>
                </div>
                <div className="cr-provider-row__mid">
                  <div className="cr-provider-row__gross">Gross €{s.gross_eur.toFixed(2)}</div>
                  <div className="cr-provider-row__escrow">Escrow −€{s.escrow_eur.toFixed(2)} (15%)</div>
                </div>
                <div className="cr-provider-row__right">
                  <div className="cr-provider-row__net">€{s.net_eur.toFixed(2)}</div>
                  <div className={`cr-provider-row__status cr-provider-row__status--${s.status}`}>
                    {s.status === 'paid' ? <CheckCircle2 size={8} /> : <Activity size={8} />}
                    {s.status === 'paid' ? 'Paid' : 'Pending'}
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Payout form */}
          {payoutPhase !== 'success' ? (
            <div className="cr-payout-form">
              <div className="cr-form-label"><ArrowDownToLine size={10} style={{ color: '#4ade80' }} /> IBAN payout</div>
              <div className="cr-input-row">
                <input
                  className="cr-card-input"
                  placeholder="NL91ABNA0417164300"
                  value={ibanInput}
                  onChange={e => setIbanInput(e.target.value.toUpperCase())}
                  style={{ fontFamily: 'monospace', letterSpacing: '0.08em' }}
                />
                <button
                  className="cr-pay-btn"
                  onClick={requestPayout}
                  disabled={payoutPhase === 'processing' || !ibanInput.trim()}
                  style={{ background: '#4ade8011', borderColor: '#4ade8055', color: '#4ade80' }}
                >
                  {payoutPhase === 'processing'
                    ? <><Activity size={10} className="rem-spin" /> Processing…</>
                    : <><ArrowDownToLine size={10} /> Payout</>}
                </button>
              </div>
            </div>
          ) : (
            <div className="cr-payout-success">
              <CheckCircle2 size={16} style={{ color: '#4ade80' }} />
              <div>
                <div style={{ color: '#4ade80', fontWeight: 800, fontSize: 13 }}>Payout processed</div>
                <div style={{ color: '#64748b', fontSize: 9 }}>Net amount transferred to {ibanInput}</div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Switch role button */}
      {role !== 'none' && (
        <button className="cr-switch-role-btn" onClick={() => { setRole('none'); stopCamera(); setSeekerActive(false); setMatches([]); setMatchPhase('searching'); }}>
          <RefreshCw size={10} /> Choose different role
        </button>
      )}

      <div className="cr-footer">
        <ShieldCheck size={8} style={{ color: '#4ade80' }} />
        AIPPIETAX S.A. · Companion Radar · Module 17 · E2EE · GDPR · v190
      </div>

      <FatigueCompanion />
      <AippieVoiceOverlay context="companion" />
    </div>
  );
}
