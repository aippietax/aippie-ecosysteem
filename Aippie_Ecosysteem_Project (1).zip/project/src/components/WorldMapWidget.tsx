/**
 * WorldMapWidget — Live users on a simplified SVG world map
 * AIPPIETAX S.A. · v215
 * Pulsing dots on Amsterdam, Marbella, Dubai, New York, London
 */
import { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';

interface CityDot {
  id: string;
  name: string;
  country: string;
  // SVG coords as % of viewBox (0–1000 x 0–500)
  x: number;
  y: number;
  color: string;
  users: number;
}

const BASE_CITIES: Omit<CityDot, 'users'>[] = [
  { id: 'amsterdam',  name: 'Amsterdam',  country: 'NL', x: 495, y: 138, color: '#38bdf8' },
  { id: 'marbella',   name: 'Marbella',   country: 'ES', x: 464, y: 178, color: '#4ade80' },
  { id: 'london',     name: 'London',     country: 'GB', x: 479, y: 143, color: '#fbbf24' },
  { id: 'dubai',      name: 'Dubai',      country: 'AE', x: 614, y: 203, color: '#fb7185' },
  { id: 'newyork',    name: 'New York',   country: 'US', x: 267, y: 163, color: '#a78bfa' },
];

function useUserCounts() {
  const [counts, setCounts] = useState<Record<string, number>>(() => ({
    amsterdam: 3, marbella: 2, london: 5, dubai: 1, newyork: 4,
  }));

  useEffect(() => {
    // Try real data from Supabase — fall back to simulated
    let channel: ReturnType<typeof supabase.channel> | null = null;

    async function loadCounts() {
      try {
        const { data } = await supabase
          .from('client_profiles')
          .select('location_city')
          .not('location_city', 'is', null);

        if (data && data.length > 0) {
          const newCounts: Record<string, number> = { amsterdam: 0, marbella: 0, london: 0, dubai: 0, newyork: 0 };
          for (const row of data) {
            const city = (row.location_city as string)?.toLowerCase() ?? '';
            if (city.includes('amsterdam')) newCounts.amsterdam++;
            else if (city.includes('marbella') || city.includes('malaga')) newCounts.marbella++;
            else if (city.includes('london')) newCounts.london++;
            else if (city.includes('dubai')) newCounts.dubai++;
            else if (city.includes('new york')) newCounts.newyork++;
          }
          setCounts(prev => ({ ...prev, ...newCounts }));
        }
      } catch { /* stay with defaults */ }
    }

    loadCounts();

    // Realtime subscribe to client_profiles insertions
    channel = supabase
      .channel('world-map-updates')
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'client_profiles' }, () => {
        loadCounts();
      })
      .subscribe();

    // Simulate small random fluctuations for visual life
    const t = setInterval(() => {
      setCounts(prev => {
        const next = { ...prev };
        const keys = Object.keys(next);
        const key = keys[Math.floor(Math.random() * keys.length)];
        next[key] = Math.max(1, next[key] + (Math.random() > 0.5 ? 1 : -1));
        return next;
      });
    }, 5000);

    return () => {
      clearInterval(t);
      if (channel) supabase.removeChannel(channel);
    };
  }, []);

  return counts;
}

export default function WorldMapWidget() {
  const counts = useUserCounts();
  const [hovered, setHovered] = useState<string | null>(null);

  const cities: CityDot[] = BASE_CITIES.map(c => ({
    ...c,
    users: counts[c.id] ?? 1,
  }));

  return (
    <div style={{
      background: 'rgba(2,6,23,0.8)',
      border: '1px solid rgba(56,189,248,0.15)',
      borderRadius: 16,
      overflow: 'hidden',
      padding: '16px',
      position: 'relative',
    }}>
      {/* Header */}
      <div style={{
        display: 'flex', alignItems: 'center', gap: 8, marginBottom: 12,
      }}>
        <div style={{
          width: 7, height: 7, borderRadius: '50%', background: '#4ade80',
          boxShadow: '0 0 8px #4ade80',
          animation: 'live-ping 1.5s ease-in-out infinite',
        }} />
        <span style={{ color: '#94a3b8', fontSize: 11, fontWeight: 700, letterSpacing: '0.1em' }}>
          AIPPIE WORLD MAP · LIVE USERS
        </span>
      </div>

      {/* SVG Map */}
      <div style={{ position: 'relative', width: '100%' }}>
        <svg
          viewBox="0 0 1000 500"
          style={{ width: '100%', display: 'block' }}
          xmlns="http://www.w3.org/2000/svg"
        >
          {/* Simplified continent outlines */}
          <rect width="1000" height="500" fill="rgba(15,23,42,0.6)" rx="8" />

          {/* Ocean grid */}
          <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
            <path d="M 40 0 L 0 0 0 40" fill="none" stroke="rgba(56,189,248,0.04)" strokeWidth="0.5" />
          </pattern>
          <rect width="1000" height="500" fill="url(#grid)" />

          {/* ── Simplified continents (filled paths) ── */}
          {/* North America */}
          <path d="M 80 80 L 120 60 L 200 55 L 280 80 L 310 120 L 320 160 L 290 200 L 250 240 L 210 280 L 180 300 L 160 280 L 130 250 L 100 200 L 80 160 Z"
            fill="rgba(30,41,59,0.9)" stroke="rgba(56,189,248,0.2)" strokeWidth="1" />
          {/* South America */}
          <path d="M 200 280 L 240 270 L 270 300 L 280 350 L 270 400 L 240 430 L 210 420 L 190 380 L 185 330 Z"
            fill="rgba(30,41,59,0.9)" stroke="rgba(56,189,248,0.2)" strokeWidth="1" />
          {/* Europe */}
          <path d="M 440 100 L 480 90 L 530 100 L 540 140 L 520 160 L 490 165 L 460 155 L 440 140 Z"
            fill="rgba(30,41,59,0.9)" stroke="rgba(56,189,248,0.2)" strokeWidth="1" />
          {/* Africa */}
          <path d="M 450 175 L 510 170 L 540 195 L 545 250 L 530 320 L 500 370 L 470 360 L 445 300 L 440 240 L 445 200 Z"
            fill="rgba(30,41,59,0.9)" stroke="rgba(56,189,248,0.2)" strokeWidth="1" />
          {/* Asia */}
          <path d="M 540 80 L 650 70 L 780 90 L 850 130 L 840 180 L 780 200 L 700 210 L 640 200 L 580 180 L 545 150 Z"
            fill="rgba(30,41,59,0.9)" stroke="rgba(56,189,248,0.2)" strokeWidth="1" />
          {/* Australia */}
          <path d="M 760 310 L 830 300 L 860 330 L 850 380 L 810 400 L 770 385 L 750 350 Z"
            fill="rgba(30,41,59,0.9)" stroke="rgba(56,189,248,0.2)" strokeWidth="1" />

          {/* City dots with animation */}
          {cities.map(city => {
            const isHov = hovered === city.id;
            const radius = isHov ? 10 : 7;
            return (
              <g key={city.id}
                onMouseEnter={() => setHovered(city.id)}
                onMouseLeave={() => setHovered(null)}
                style={{ cursor: 'pointer' }}
              >
                {/* Outer pulse ring */}
                <circle cx={city.x} cy={city.y} r={radius + 8}
                  fill="none" stroke={city.color + '44'} strokeWidth="1.5"
                  style={{ animation: `br-pulse1 2s ease-out infinite` }}
                />
                {/* Inner dot */}
                <circle cx={city.x} cy={city.y} r={radius}
                  fill={city.color + '33'} stroke={city.color} strokeWidth="2"
                />
                <circle cx={city.x} cy={city.y} r={radius * 0.4}
                  fill={city.color}
                />
                {/* Tooltip on hover */}
                {isHov && (
                  <g>
                    <rect x={city.x - 60} y={city.y - 44} width={120} height={32}
                      rx={6} fill="rgba(15,23,42,0.95)" stroke={city.color + '66'} strokeWidth="1" />
                    <text x={city.x} y={city.y - 28} textAnchor="middle"
                      fill={city.color} fontSize="10" fontWeight="700" fontFamily="Inter, sans-serif">
                      {city.name} — {city.users} user{city.users !== 1 ? 's' : ''} live
                    </text>
                    <text x={city.x} y={city.y - 16} textAnchor="middle"
                      fill="#64748b" fontSize="8" fontFamily="Inter, sans-serif">
                      {city.country}
                    </text>
                  </g>
                )}
              </g>
            );
          })}
        </svg>
      </div>

      {/* Legend */}
      <div style={{
        display: 'flex', flexWrap: 'wrap', gap: 8, marginTop: 10,
        justifyContent: 'center',
      }}>
        {cities.map(city => (
          <div key={city.id} style={{
            display: 'flex', alignItems: 'center', gap: 5,
            background: city.color + '11', border: `1px solid ${city.color}33`,
            borderRadius: 20, padding: '3px 8px',
          }}>
            <div style={{
              width: 6, height: 6, borderRadius: '50%',
              background: city.color, boxShadow: `0 0 6px ${city.color}`,
            }} />
            <span style={{ color: city.color, fontSize: 9, fontWeight: 600 }}>
              {city.name}
            </span>
            <span style={{ color: '#64748b', fontSize: 9 }}>
              {city.users}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}
