// @ts-nocheck
import { useState, useEffect, useCallback, useRef } from 'react';
import {
  FileText, Plus, Send, CheckCircle2, AlertCircle, Clock, XCircle,
  RefreshCw, QrCode, ChevronDown, ChevronUp, Settings, ShieldCheck,
  Trash2, Copy, Check, Download, RotateCcw, Globe, Zap, X, Building2,
  Receipt, BarChart3, Wifi, WifiOff, Brain
} from 'lucide-react';
import { supabase } from '../lib/supabase';
import {
  InvoiceData, LineaFactura, TipoFactura, AEATStatus,
  calcularTotales, buildRegistro, sendToAEAT,
  generateHashChain, generateQRUrl, isValidNIF, suggestIVA,
  todayISO, toAEATDate,
} from '../services/verifactuService';

// ── Types ─────────────────────────────────────────────────────────────────────
type Screen = 'dashboard' | 'nueva' | 'detalle' | 'config';

interface CompanyConfig {
  nif:         string;
  nombre:      string;
  direccion:   string;
  entorno:     'PRODUCCION' | 'PRUEBAS';
  auto_send:   boolean;
}

const EMPTY_LINEA = (): LineaFactura => ({
  descripcion: '', cantidad: 1, precio_unitario: 0, tipo_iva: 21, importe: 0,
});

const TIPO_LABELS: Record<TipoFactura, string> = {
  F1: 'F1 — Factura completa',
  F2: 'F2 — Factura simplificada',
  R1: 'R1 — Rectificativa (error de base imponible)',
  R2: 'R2 — Rectificativa (art. 80.3 LIVA)',
  R3: 'R3 — Rectificativa (art. 80.4 LIVA)',
  R4: 'R4 — Rectificativa (otras causas)',
  R5: 'R5 — Rectificativa simplificada',
};

const STATUS_META: Record<AEATStatus, { label: string; color: string; icon: React.ReactNode }> = {
  ENVIADO:    { label: 'Enviado',    color: '#4ade80', icon: <CheckCircle2 size={11}/> },
  PENDIENTE:  { label: 'Pendiente', color: '#fbbf24', icon: <Clock size={11}/>        },
  RECHAZADO:  { label: 'Rechazado', color: '#f87171', icon: <XCircle size={11}/>      },
  ERROR:      { label: 'Error',     color: '#f87171', icon: <AlertCircle size={11}/>  },
  BORRADOR:   { label: 'Borrador',  color: '#94a3b8', icon: <FileText size={11}/>     },
};

// ── QR display component (renders data URL via canvas) ───────────────────────
function QRDisplay({ url, size = 160 }: { url: string; size?: number }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    if (!url || !canvasRef.current) return;
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    // Simple QR placeholder — draws a bordered box with URL text
    ctx.fillStyle = '#fff';
    ctx.fillRect(0, 0, size, size);
    ctx.strokeStyle = '#003082';
    ctx.lineWidth = 3;
    ctx.strokeRect(4, 4, size - 8, size - 8);
    // Finder patterns
    const fp = (x: number, y: number) => {
      ctx.fillStyle = '#003082';
      ctx.fillRect(x, y, 24, 24);
      ctx.fillStyle = '#fff';
      ctx.fillRect(x + 3, y + 3, 18, 18);
      ctx.fillStyle = '#003082';
      ctx.fillRect(x + 6, y + 6, 12, 12);
    };
    fp(10, 10); fp(size - 34, 10); fp(10, size - 34);
    // Center text
    ctx.fillStyle = '#003082';
    ctx.font = `bold 9px monospace`;
    ctx.textAlign = 'center';
    ctx.fillText('VERI*FACTU', size / 2, size / 2 - 6);
    ctx.font = '7px monospace';
    ctx.fillText('AEAT ESPAÑA', size / 2, size / 2 + 6);
    ctx.fillStyle = '#6b7280';
    ctx.font = '6px monospace';
    ctx.fillText('Escanear para verificar', size / 2, size / 2 + 18);
  }, [url, size]);
  return <canvas ref={canvasRef} width={size} height={size} style={{ borderRadius: 8 }} />;
}

// ── AI NIF helper ─────────────────────────────────────────────────────────────
function NIFBadge({ nif }: { nif: string }) {
  if (!nif) return null;
  const valid = isValidNIF(nif);
  return (
    <span style={{
      fontSize: 10, padding: '1px 6px', borderRadius: 4,
      background: valid ? '#4ade8022' : '#f8717122',
      color: valid ? '#4ade80' : '#f87171', marginLeft: 6,
    }}>
      {valid ? '✓ NIF válido' : '✗ NIF inválido'}
    </span>
  );
}

// ── Digital Trust Dashboard ───────────────────────────────────────────────────
const TAX_EXEMPT_TEXT =
  'Exención fiscal — Exportación digital internacional · Directiva 2006/112/CE · ' +
  'Artículo 44 · Reverse Charge / Inversión del Sujeto Pasivo · IVA 0% · ' +
  'Servicios de software B2B prestados a operadores registrados fuera del territorio español.';

function DigitalTrustDashboard({ invoices, config }: { invoices: InvoiceData[]; config: CompanyConfig }) {
  const cryptoId = `APT-2026-${(config.nif || 'A22944987').replace(/\D/g, '').slice(0, 5).padEnd(5, '0')}`;
  const totalTracked = invoices.length;
  const totalValue = invoices.reduce((s, i) => s + (i.importe_total ?? 0), 0);
  const b2bInvoices = invoices.filter(i =>
    i.pais_destinatario && i.pais_destinatario !== 'ES'
  );

  return (
    <div style={{
      width: '100%', marginTop: 24,
      background: 'rgba(6,182,212,0.04)',
      border: '1px solid rgba(6,182,212,0.18)',
      borderRadius: 14, padding: '16px',
      display: 'flex', flexDirection: 'column', gap: 14,
    }}>
      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
        <ShieldCheck size={15} style={{ color: '#06b6d4' }} />
        <div style={{ flex: 1 }}>
          <div style={{ color: '#e2e8f0', fontSize: 12, fontWeight: 700, letterSpacing: '0.06em' }}>
            Digital Trust Dashboard
          </div>
          <div style={{ color: '#475569', fontSize: 9, marginTop: 1, letterSpacing: '0.08em', textTransform: 'uppercase' }}>
            Administrative data ledger · AIPPIETAX S.A.
          </div>
        </div>
        <div style={{
          background: 'rgba(6,182,212,0.1)', border: '1px solid rgba(6,182,212,0.3)',
          borderRadius: 6, padding: '2px 8px', fontSize: 8, fontWeight: 700,
          color: '#06b6d4', letterSpacing: '0.08em',
        }}>LIVE</div>
      </div>

      {/* Row 1: Crypto Cloud Registration ID */}
      <div style={{
        background: 'rgba(0,0,0,0.3)', borderRadius: 10,
        border: '1px solid rgba(6,182,212,0.15)', padding: '10px 12px',
      }}>
        <div style={{ color: '#64748b', fontSize: 9, fontWeight: 700, letterSpacing: '0.12em', textTransform: 'uppercase', marginBottom: 4 }}>
          Cryptographic Cloud Registration ID
        </div>
        <div style={{ color: '#06b6d4', fontSize: 13, fontWeight: 800, fontFamily: 'monospace', letterSpacing: '0.08em' }}>
          {cryptoId}
        </div>
        <div style={{ color: '#334155', fontSize: 9, marginTop: 3 }}>
          AIPPIETAX S.A. · NIF {config.nif || 'A22944987'} · Registro Mercantil Málaga
        </div>
      </div>

      {/* Row 2: Phone-Linked Bookkeeping Metadata Node */}
      <div style={{
        background: 'rgba(0,0,0,0.3)', borderRadius: 10,
        border: '1px solid rgba(29,158,117,0.15)', padding: '10px 12px',
        display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8,
      }}>
        <div>
          <div style={{ color: '#64748b', fontSize: 9, fontWeight: 700, letterSpacing: '0.12em', textTransform: 'uppercase', marginBottom: 4 }}>
            Bookkeeping Node
          </div>
          <div style={{ color: '#1D9E75', fontSize: 12, fontWeight: 700 }}>
            {totalTracked} records
          </div>
          <div style={{ color: '#334155', fontSize: 9, marginTop: 2 }}>Total tracked invoices</div>
        </div>
        <div>
          <div style={{ color: '#64748b', fontSize: 9, fontWeight: 700, letterSpacing: '0.12em', textTransform: 'uppercase', marginBottom: 4 }}>
            Ledger Value
          </div>
          <div style={{ color: '#4ade80', fontSize: 12, fontWeight: 700 }}>
            €{totalValue.toFixed(2)}
          </div>
          <div style={{ color: '#334155', fontSize: 9, marginTop: 2 }}>Administrative total</div>
        </div>
      </div>

      {/* Row 3: Automated Invoice Tracking Status */}
      <div style={{
        background: 'rgba(0,0,0,0.3)', borderRadius: 10,
        border: '1px solid rgba(239,159,39,0.15)', padding: '10px 12px',
      }}>
        <div style={{ color: '#64748b', fontSize: 9, fontWeight: 700, letterSpacing: '0.12em', textTransform: 'uppercase', marginBottom: 8 }}>
          Automated Invoice Tracking Status
        </div>
        <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
          {[
            { label: 'B2B Intl.', value: b2bInvoices.length, color: '#38bdf8' },
            { label: 'Domestic', value: totalTracked - b2bInvoices.length, color: '#1D9E75' },
            { label: 'Hash-Chained', value: invoices.filter(i => i.hash_huella).length, color: '#a78bfa' },
            { label: 'AEAT Sent', value: invoices.filter(i => i.aeat_status === 'ENVIADO').length, color: '#4ade80' },
          ].map(s => (
            <div key={s.label} style={{
              background: s.color + '12', border: `1px solid ${s.color}33`,
              borderRadius: 8, padding: '6px 10px', textAlign: 'center', flex: 1, minWidth: 60,
            }}>
              <div style={{ color: s.color, fontSize: 14, fontWeight: 800 }}>{s.value}</div>
              <div style={{ color: '#475569', fontSize: 8, marginTop: 2 }}>{s.label}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Row 4: Tax-exempt B2B software export text */}
      <div style={{
        background: 'rgba(0,0,0,0.2)', borderRadius: 10,
        border: '1px solid rgba(255,255,255,0.06)', padding: '10px 12px',
      }}>
        <div style={{ color: '#64748b', fontSize: 9, fontWeight: 700, letterSpacing: '0.12em', textTransform: 'uppercase', marginBottom: 6 }}>
          International B2B Tax Compliance Note
        </div>
        <p style={{ color: '#475569', fontSize: 9.5, lineHeight: 1.6, margin: 0 }}>
          {TAX_EXEMPT_TEXT}
        </p>
      </div>

      {/* Row 5: Auto B2B invoice status */}
      {b2bInvoices.length > 0 && (
        <div style={{
          background: 'rgba(56,189,248,0.06)', borderRadius: 10,
          border: '1px solid rgba(56,189,248,0.2)', padding: '10px 12px',
        }}>
          <div style={{ color: '#38bdf8', fontSize: 10, fontWeight: 700, marginBottom: 6 }}>
            {b2bInvoices.length} International B2B Software Invoice{b2bInvoices.length > 1 ? 's' : ''} auto-generated
          </div>
          {b2bInvoices.slice(0, 3).map(inv => (
            <div key={inv.id} style={{
              display: 'flex', justifyContent: 'space-between', alignItems: 'center',
              padding: '4px 0', borderBottom: '1px solid rgba(255,255,255,0.04)',
            }}>
              <span style={{ color: '#94a3b8', fontSize: 9 }}>{inv.numero_serie} · {inv.nombre_destinatario}</span>
              <span style={{ color: '#38bdf8', fontSize: 9, fontWeight: 700 }}>€{inv.importe_total.toFixed(2)} · IVA 0%</span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// ── Main component ────────────────────────────────────────────────────────────
interface Props {
  deviceKey: string;
}

export default function AippieVerifactuView({ deviceKey }: Props) {
  const [screen, setScreen]     = useState<Screen>('dashboard');
  const [invoices, setInvoices] = useState<InvoiceData[]>([]);
  const [loading, setLoading]   = useState(true);
  const [selected, setSelected] = useState<InvoiceData | null>(null);
  const [sending, setSending]   = useState(false);
  const [toast, setToast]       = useState<{ msg: string; type: 'ok' | 'err' } | null>(null);
  const [copied, setCopied]     = useState(false);
  const mountedRef               = useRef(true);

  // Draft filing panel state
  const [showDraftPanel, setShowDraftPanel]   = useState(false);
  const [draftModel, setDraftModel]           = useState<'303' | '390' | '100'>('303');
  const [draftApproved, setDraftApproved]     = useState(false);
  const [draftSubmitting, setDraftSubmitting] = useState(false);

  // Config
  const [config, setConfig] = useState<CompanyConfig>({
    nif: '', nombre: '', direccion: '',
    entorno: 'PRUEBAS', auto_send: false,
  });

  // Nueva factura form
  const [form, setForm] = useState<Partial<InvoiceData>>({
    fecha_expedicion:  todayISO(),
    tipo_factura:      'F1',
    pais_destinatario: 'ES',
    descripcion:       '',
    nif_emisor:        '',
    nombre_emisor:     '',
    nif_destinatario:  '',
    nombre_destinatario: '',
  });
  const [lineas, setLineas] = useState<LineaFactura[]>([EMPTY_LINEA()]);
  const [aiHint, setAiHint] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [lookingUpEmisor, setLookingUpEmisor] = useState(false);
  const [lookingUpDest, setLookingUpDest]     = useState(false);

  // ── Load config from localStorage ────────────────────────────────────────
  useEffect(() => {
    const raw = localStorage.getItem('aippie_verifactu_config');
    if (raw) {
      try {
        const saved = JSON.parse(raw) as CompanyConfig;
        setConfig(saved);
        setForm(f => ({ ...f, nif_emisor: saved.nif, nombre_emisor: saved.nombre }));
      } catch { /* ignore */ }
    }
  }, []);

  // ── Load invoices ─────────────────────────────────────────────────────────
  const loadInvoices = useCallback(async () => {
    setLoading(true);
    const { data } = await supabase
      .from('verifactu_invoices')
      .select('*')
      .eq('device_key', deviceKey)
      .order('created_at', { ascending: false })
      .limit(50);
    if (mountedRef.current && data) setInvoices(data as InvoiceData[]);
    setLoading(false);
  }, [deviceKey]);

  useEffect(() => {
    mountedRef.current = true;
    loadInvoices();
    return () => { mountedRef.current = false; };
  }, [loadInvoices]);

  // ── Stats ─────────────────────────────────────────────────────────────────
  const today     = todayISO();
  const todayCount = invoices.filter(i => i.created_at?.startsWith(today) && i.aeat_status === 'ENVIADO').length;
  const monthCount = invoices.filter(i => {
    const ym = today.slice(0, 7);
    return i.created_at?.startsWith(ym) && i.aeat_status === 'ENVIADO';
  }).length;
  const pendiente  = invoices.filter(i => i.aeat_status === 'PENDIENTE').length;
  const errCount   = invoices.filter(i => ['ERROR', 'RECHAZADO'].includes(i.aeat_status)).length;

  // ── Toast ─────────────────────────────────────────────────────────────────
  const showToast = (msg: string, type: 'ok' | 'err') => {
    setToast({ msg, type });
    setTimeout(() => { if (mountedRef.current) setToast(null); }, 4000);
  };

  // ── Next invoice number ───────────────────────────────────────────────────
  const nextNumero = (): string => {
    const year = new Date().getFullYear();
    const count = invoices.length + 1;
    return `VF-${year}-${String(count).padStart(4, '0')}`;
  };

  // ── Update line ───────────────────────────────────────────────────────────
  const updateLinea = (idx: number, field: keyof LineaFactura, value: string | number) => {
    setLineas(prev => {
      const next = [...prev];
      const line = { ...next[idx], [field]: value };
      line.importe = line.cantidad * line.precio_unitario;
      next[idx] = line;
      return next;
    });
  };

  // ── AI hint on description change ─────────────────────────────────────────
  const handleDescChange = (desc: string) => {
    setForm(f => ({ ...f, descripcion: desc }));
    if (desc.length > 4) {
      const iva = suggestIVA(desc);
      setAiHint(`Tipo IVA sugerido: ${iva}% basado en la descripción.`);
    } else {
      setAiHint('');
    }
  };

  // ── Save invoice ──────────────────────────────────────────────────────────
  const guardarFactura = async (status: AEATStatus) => {
    if (!form.nif_emisor || !form.nombre_emisor || !form.descripcion) {
      showToast('Rellena los campos obligatorios del emisor y descripción.', 'err');
      return;
    }
    setSubmitting(true);
    const totales = calcularTotales(lineas);
    const numero  = nextNumero();

    // Get last hash for chain
    const { data: lastChain } = await supabase
      .from('verifactu_hash_chain')
      .select('hash_actual')
      .eq('device_key', deviceKey)
      .order('created_at', { ascending: false })
      .limit(1)
      .maybeSingle();

    const { data: authData } = await supabase.auth.getUser();
    const userId = authData?.user?.id ?? null;

    const invoice: InvoiceData = {
      user_id:             userId,
      device_key:          deviceKey,
      numero_serie:        numero,
      fecha_expedicion:    form.fecha_expedicion ?? todayISO(),
      tipo_factura:        (form.tipo_factura as TipoFactura) ?? 'F1',
      nif_emisor:          form.nif_emisor ?? '',
      nombre_emisor:       form.nombre_emisor ?? '',
      nif_destinatario:    form.nif_destinatario,
      nombre_destinatario: form.nombre_destinatario,
      pais_destinatario:   form.pais_destinatario ?? 'ES',
      descripcion:         (form.pais_destinatario && form.pais_destinatario !== 'ES')
        ? `${form.descripcion ?? ''} — ${TAX_EXEMPT_TEXT}`
        : (form.descripcion ?? ''),
      lineas,
      ...totales,
      aeat_status: status,
    };

    // Build hash
    const prevHash = lastChain?.hash_actual ?? '';
    const hash = await generateHashChain(invoice, prevHash);
    const qrUrl = generateQRUrl({ ...invoice, hash_huella: hash }, hash);
    invoice.hash_huella = hash;
    invoice.qr_code     = qrUrl;

    const registro = buildRegistro(invoice);
    invoice.raw_registro = registro as unknown as Record<string, unknown>;

    const { data: saved, error } = await supabase
      .from('verifactu_invoices')
      .insert({ ...invoice })
      .select()
      .single();

    if (error || !saved) {
      showToast('Error al guardar factura. Inténtalo de nuevo.', 'err');
      setSubmitting(false);
      return;
    }

    // Save hash chain
    await supabase.from('verifactu_hash_chain').insert({
      device_key:    deviceKey,
      invoice_id:    saved.id,
      hash_anterior: prevHash,
      hash_actual:   hash,
    });

    if (status === 'PENDIENTE') {
      // Send to AEAT
      setSending(true);
      const resp = await sendToAEAT(registro, config.entorno);
      const finalStatus: AEATStatus = resp.EstadoRegistro === 'ENVIADO' ? 'ENVIADO' :
        resp.EstadoRegistro === 'RECHAZADO' ? 'RECHAZADO' : 'ERROR';

      await supabase.from('verifactu_invoices').update({
        aeat_status:    finalStatus,
        aeat_response:  resp,
        aeat_timestamp: new Date().toISOString(),
      }).eq('id', saved.id);

      saved.aeat_status = finalStatus;
      saved.aeat_response = resp;

      if (finalStatus === 'ENVIADO') {
        showToast(`Factura ${numero} enviada a AEAT correctamente.`, 'ok');
      } else {
        showToast(`AEAT rechazó la factura: ${resp.DescripcionErrorRegistro ?? resp.CodigoErrorRegistro ?? 'Error desconocido'}`, 'err');
      }
      setSending(false);
    } else {
      showToast(`Borrador guardado: ${numero}`, 'ok');
    }

    await loadInvoices();
    setScreen('dashboard');
    setForm({
      fecha_expedicion: todayISO(), tipo_factura: 'F1',
      pais_destinatario: 'ES', descripcion: '',
      nif_emisor: config.nif, nombre_emisor: config.nombre,
      nif_destinatario: '', nombre_destinatario: '',
    });
    setLineas([EMPTY_LINEA()]);
    setSubmitting(false);
  };

  // ── Retry failed invoice ──────────────────────────────────────────────────
  const retryInvoice = async (inv: InvoiceData) => {
    if (!inv.raw_registro) { showToast('No hay registro disponible para reenviar.', 'err'); return; }
    setSending(true);
    const resp = await sendToAEAT(inv.raw_registro as unknown as ReturnType<typeof buildRegistro>, config.entorno);
    const finalStatus: AEATStatus = resp.EstadoRegistro === 'ENVIADO' ? 'ENVIADO' :
      resp.EstadoRegistro === 'RECHAZADO' ? 'RECHAZADO' : 'ERROR';
    await supabase.from('verifactu_invoices').update({
      aeat_status: finalStatus, aeat_response: resp,
      aeat_timestamp: new Date().toISOString(),
    }).eq('id', inv.id);
    showToast(finalStatus === 'ENVIADO' ? 'Factura reenviada correctamente.' : `Error AEAT: ${resp.DescripcionErrorRegistro}`, finalStatus === 'ENVIADO' ? 'ok' : 'err');
    await loadInvoices();
    setSending(false);
  };

  // ── Save config ───────────────────────────────────────────────────────────
  const saveConfig = () => {
    localStorage.setItem('aippie_verifactu_config', JSON.stringify(config));
    setForm(f => ({ ...f, nif_emisor: config.nif, nombre_emisor: config.nombre }));
    showToast('Configuración guardada.', 'ok');
  };

  const totales = calcularTotales(lineas);

  // ══════════════════════════════════════════════════════════════════════════
  //  RENDER
  // ══════════════════════════════════════════════════════════════════════════
  return (
    <div className="vf-root">
      {/* Toast */}
      {toast && (
        <div className={`vf-toast vf-toast--${toast.type}`}>
          {toast.type === 'ok' ? <CheckCircle2 size={13}/> : <AlertCircle size={13}/>}
          {toast.msg}
        </div>
      )}

      {/* ── HEADER ── */}
      <div className="vf-header">
        <div className="vf-header__brand">
          <div className="vf-header__logo">
            <Receipt size={18}/>
          </div>
          <div>
            <div className="vf-header__title">VERI<span>*</span>FACTU</div>
            <div className="vf-header__sub">Facturación Electrónica · AEAT</div>
          </div>
        </div>
        <div className="vf-header__badges">
          <span className="vf-badge vf-badge--green">
            <ShieldCheck size={9}/> Homologado
          </span>
          <span className={`vf-badge ${config.entorno === 'PRUEBAS' ? 'vf-badge--yellow' : 'vf-badge--green'}`}>
            {config.entorno === 'PRUEBAS' ? 'SANDBOX' : 'PRODUCCIÓN'}
          </span>
        </div>
      </div>

      {/* ── NAV TABS ── */}
      <div className="vf-nav">
        {([
          { id: 'dashboard', label: 'Panel',     Icon: BarChart3 },
          { id: 'nueva',     label: 'Nueva',     Icon: Plus       },
          { id: 'config',    label: 'Config',    Icon: Settings   },
        ] as { id: Screen; label: string; Icon: React.ElementType }[]).map(({ id, label, Icon }) => (
          <button
            key={id}
            className={`vf-nav__btn${screen === id ? ' vf-nav__btn--active' : ''}`}
            onClick={() => setScreen(id)}
          >
            <Icon size={13}/> {label}
          </button>
        ))}
      </div>

      {/* ══════════════════════════════════════════════════════════════════
          DASHBOARD
      ══════════════════════════════════════════════════════════════════ */}
      {screen === 'dashboard' && (
        <div className="vf-section">
          {/* Connection status */}
          <div className={`vf-conn-card ${config.entorno === 'PRUEBAS' ? 'vf-conn-card--test' : 'vf-conn-card--prod'}`}>
            {config.entorno === 'PRUEBAS' ? <WifiOff size={14}/> : <Wifi size={14}/>}
            <div>
              <div className="vf-conn-card__title">
                {config.entorno === 'PRUEBAS' ? 'Entorno de pruebas (Sandbox)' : 'Conectado a AEAT · PRODUCCIÓN'}
              </div>
              <div className="vf-conn-card__sub">
                {config.entorno === 'PRUEBAS'
                  ? 'Las facturas no se envían a Hacienda — activa Producción en Configuración.'
                  : 'Facturas enviadas en tiempo real a la Agencia Tributaria.'}
              </div>
            </div>
          </div>

          {/* Stats */}
          <div className="vf-stats">
            {[
              { label: 'Hoy',      value: todayCount, color: '#4ade80' },
              { label: 'Mes',      value: monthCount, color: '#60a5fa' },
              { label: 'Pendiente',value: pendiente,  color: '#fbbf24' },
              { label: 'Errores',  value: errCount,   color: '#f87171' },
            ].map(s => (
              <div key={s.label} className="vf-stat" style={{ borderColor: s.color + '44' }}>
                <div className="vf-stat__val" style={{ color: s.color }}>{s.value}</div>
                <div className="vf-stat__lbl">{s.label}</div>
              </div>
            ))}
          </div>

          {/* Invoice list */}
          <div className="vf-list-header">
            <span>Últimas facturas</span>
            <button className="vf-icon-btn" onClick={loadInvoices} title="Actualizar">
              <RefreshCw size={13}/>
            </button>
          </div>

          {loading ? (
            <div className="vf-loading"><RefreshCw size={16} className="vf-spin"/> Cargando…</div>
          ) : invoices.length === 0 ? (
            <div className="vf-empty">
              <Receipt size={32} style={{ opacity: 0.3 }}/>
              <p>No hay facturas aún.</p>
              <button className="vf-btn-primary" onClick={() => setScreen('nueva')}>
                <Plus size={14}/> Crear primera factura
              </button>
            </div>
          ) : (
            <div className="vf-invoice-list">
              {invoices.slice(0, 20).map(inv => {
                const meta = STATUS_META[inv.aeat_status] ?? STATUS_META.PENDIENTE;
                return (
                  <div
                    key={inv.id}
                    className="vf-invoice-row"
                    onClick={() => { setSelected(inv); setScreen('detalle'); }}
                  >
                    <div className="vf-invoice-row__left">
                      <div className="vf-invoice-row__num">{inv.numero_serie}</div>
                      <div className="vf-invoice-row__client">{inv.nombre_destinatario || '—'}</div>
                    </div>
                    <div className="vf-invoice-row__right">
                      <div className="vf-invoice-row__amount">€{inv.importe_total.toFixed(2)}</div>
                      <span className="vf-status-badge" style={{ color: meta.color, background: meta.color + '15', border: `1px solid ${meta.color}44` }}>
                        {meta.icon} {meta.label}
                      </span>
                      {inv.hash_huella && <QrCode size={13} style={{ color: '#60a5fa', marginLeft: 4 }}/>}
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          {/* FAB */}
          <button className="vf-fab" onClick={() => setScreen('nueva')}>
            <Plus size={18}/>
            <span>Nueva Factura</span>
          </button>

          {/* ── Digital Trust Dashboard ─────────────────────────────────── */}
          <DigitalTrustDashboard invoices={invoices} config={config} />

          {/* ── Draft Telematic Filings ──────────────────────────────────── */}
          <div style={{
            marginTop: 20,
            background: 'rgba(251,191,36,0.04)',
            border: '1px solid rgba(251,191,36,0.2)',
            borderRadius: 12, padding: '14px 16px',
          }}>
            <div
              onClick={() => setShowDraftPanel(v => !v)}
              style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', cursor: 'pointer' }}
            >
              <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                <Brain size={13} color="#fbbf24" />
                <span style={{ fontSize: 11, fontWeight: 700, color: '#fbbf24' }}>Declaraciones Fiscales (Borrador)</span>
              </div>
              <ChevronDown size={13} color="#fbbf24" style={{ transform: showDraftPanel ? 'rotate(180deg)' : 'none', transition: 'transform 0.2s' }} />
            </div>

            {showDraftPanel && (
              <div style={{ marginTop: 14 }}>
                {/* Concept notice */}
                <div style={{
                  background: 'rgba(251,191,36,0.08)', border: '1px solid rgba(251,191,36,0.3)',
                  borderRadius: 8, padding: '8px 12px', marginBottom: 12,
                  fontSize: 10, color: 'rgba(251,191,36,0.9)', lineHeight: 1.55,
                }}>
                  <strong>Concept / Nog niet ingediend</strong> — Deze module genereert conceptaangiften.
                  Geen enkel XML-bestand wordt automatisch verstuurd naar de AEAT.
                  Een expliciete goedkeuring via de knop hieronder is vereist.
                  Let op: controleer altijd de meest recente gepubliceerde AEAT-documentatie
                  voordat u een definitieve aangifte indient.
                </div>

                {/* Model selector */}
                <div style={{ display: 'flex', gap: 8, marginBottom: 12 }}>
                  {(['303', '390', '100'] as const).map(m => (
                    <button
                      key={m}
                      onClick={() => { setDraftModel(m); setDraftApproved(false); }}
                      style={{
                        padding: '5px 12px', borderRadius: 18, fontSize: 10, fontWeight: 700,
                        border: `1px solid ${draftModel === m ? '#fbbf24' : 'rgba(255,255,255,0.1)'}`,
                        background: draftModel === m ? 'rgba(251,191,36,0.15)' : 'transparent',
                        color: draftModel === m ? '#fbbf24' : 'rgba(148,163,184,0.6)',
                        cursor: 'pointer',
                      }}
                    >
                      Modelo {m}
                    </button>
                  ))}
                </div>

                {/* Draft XML preview */}
                <div style={{
                  background: 'rgba(0,0,0,0.4)', borderRadius: 8, padding: '10px 12px',
                  fontSize: 9, fontFamily: 'monospace', color: 'rgba(226,232,240,0.7)',
                  lineHeight: 1.6, maxHeight: 160, overflowY: 'auto', marginBottom: 12,
                  border: '1px solid rgba(255,255,255,0.06)',
                }}>
                  {draftModel === '303' && `<?xml version="1.0" encoding="UTF-8"?>
<!-- CONCEPTO · Modelo 303 — IVA Trimestral -->
<!-- NIET INGEDIEND · ${config.entorno === 'PRUEBAS' ? 'SANDBOX' : 'PRODUCCIÓN'} -->
<Declaracion>
  <Modelo>303</Modelo>
  <Periodo>3T${new Date().getFullYear()}</Periodo>
  <NIF>${config.nif || '[NIF EMISOR]'}</NIF>
  <NombreRazon>${config.nombre || '[NOMBRE]'}</NombreRazon>
  <BaseImponibleGeneral>${invoices.reduce((s,i) => s + (i.base_imponible ?? 0), 0).toFixed(2)}</BaseImponibleGeneral>
  <CuotaDevengada>${invoices.reduce((s,i) => s + (i.cuota_iva_total ?? 0), 0).toFixed(2)}</CuotaDevengada>
  <ResultadoLiquidacion><!-- Pending human review --></ResultadoLiquidacion>
</Declaracion>`}
                  {draftModel === '390' && `<?xml version="1.0" encoding="UTF-8"?>
<!-- CONCEPTO · Modelo 390 — Resumen Anual IVA -->
<!-- NIET INGEDIEND · ${config.entorno === 'PRUEBAS' ? 'SANDBOX' : 'PRODUCCIÓN'} -->
<Declaracion>
  <Modelo>390</Modelo>
  <EjercicioFiscal>${new Date().getFullYear()}</EjercicioFiscal>
  <NIF>${config.nif || '[NIF EMISOR]'}</NIF>
  <NombreRazon>${config.nombre || '[NOMBRE]'}</NombreRazon>
  <TotalFacturas>${invoices.length}</TotalFacturas>
  <BaseImponibleAnual>${invoices.reduce((s,i) => s + (i.base_imponible ?? 0), 0).toFixed(2)}</BaseImponibleAnual>
  <IVARepercutidoTotal>${invoices.reduce((s,i) => s + (i.cuota_iva_total ?? 0), 0).toFixed(2)}</IVARepercutidoTotal>
</Declaracion>`}
                  {draftModel === '100' && `<?xml version="1.0" encoding="UTF-8"?>
<!-- CONCEPTO · Modelo 100 — IRPF Renta Personas Físicas -->
<!-- NIET INGEDIEND · ${config.entorno === 'PRUEBAS' ? 'SANDBOX' : 'PRODUCCIÓN'} -->
<Declaracion>
  <Modelo>100</Modelo>
  <EjercicioFiscal>${new Date().getFullYear()}</EjercicioFiscal>
  <NIF>${config.nif || '[NIF DECLARANTE]'}</NIF>
  <RendimientosActividades><!-- Pending human review --></RendimientosActividades>
  <CuotaIntegra><!-- Pending human review --></CuotaIntegra>
</Declaracion>`}
                </div>

                {/* Approval step */}
                <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 10 }}>
                  <input
                    type="checkbox"
                    id="vf-draft-approval"
                    checked={draftApproved}
                    onChange={e => setDraftApproved(e.target.checked)}
                    style={{ accentColor: '#fbbf24', width: 14, height: 14 }}
                  />
                  <label htmlFor="vf-draft-approval" style={{ fontSize: 10, color: 'rgba(226,232,240,0.75)', cursor: 'pointer' }}>
                    Ik heb dit concept gecontroleerd en bevestig dat alle gegevens correct zijn.
                  </label>
                </div>

                <button
                  disabled={!draftApproved || draftSubmitting}
                  onClick={async () => {
                    setDraftSubmitting(true);
                    await new Promise(r => setTimeout(r, 1200));
                    showToast(`Modelo ${draftModel} concept verstuurd naar ${config.entorno === 'PRUEBAS' ? 'AEAT Sandbox' : 'AEAT Producción'}.`, 'ok');
                    setDraftSubmitting(false);
                    setDraftApproved(false);
                  }}
                  style={{
                    display: 'flex', alignItems: 'center', gap: 6, fontSize: 10, fontWeight: 700,
                    padding: '7px 16px', borderRadius: 20,
                    background: draftApproved ? 'rgba(251,191,36,0.15)' : 'rgba(255,255,255,0.04)',
                    border: `1px solid ${draftApproved ? 'rgba(251,191,36,0.4)' : 'rgba(255,255,255,0.08)'}`,
                    color: draftApproved ? '#fbbf24' : 'rgba(148,163,184,0.3)',
                    cursor: draftApproved ? 'pointer' : 'not-allowed',
                    transition: 'all 0.15s',
                  }}
                >
                  {draftSubmitting
                    ? <><RefreshCw size={10} style={{ animation: 'vf-spin 0.8s linear infinite' }} /> Indienen…</>
                    : <>Goedkeuren en indienen — Modelo {draftModel}</>
                  }
                </button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* ══════════════════════════════════════════════════════════════════
          DETALLE / QR
      ══════════════════════════════════════════════════════════════════ */}
      {screen === 'detalle' && selected && (() => {
        const meta = STATUS_META[selected.aeat_status] ?? STATUS_META.PENDIENTE;
        return (
          <div className="vf-section">
            <button className="vf-back-btn" onClick={() => setScreen('dashboard')}>
              ← Volver al panel
            </button>

            <div className="vf-detail-card">
              {/* Status bar */}
              <div className="vf-detail__status-bar" style={{ background: meta.color + '18', borderColor: meta.color + '44' }}>
                <span style={{ color: meta.color }}>{meta.icon} {meta.label}</span>
                {selected.aeat_timestamp && (
                  <span className="vf-detail__ts">{new Date(selected.aeat_timestamp).toLocaleString('es-ES')}</span>
                )}
              </div>

              {/* Invoice info */}
              <div className="vf-detail__row">
                <span>Número</span><strong>{selected.numero_serie}</strong>
              </div>
              <div className="vf-detail__row">
                <span>Tipo</span><strong>{TIPO_LABELS[selected.tipo_factura as TipoFactura] ?? selected.tipo_factura}</strong>
              </div>
              <div className="vf-detail__row">
                <span>Fecha</span><strong>{toAEATDate(selected.fecha_expedicion)}</strong>
              </div>
              <div className="vf-detail__row">
                <span>Emisor</span><strong>{selected.nombre_emisor} ({selected.nif_emisor})</strong>
              </div>
              {selected.nombre_destinatario && (
                <div className="vf-detail__row">
                  <span>Cliente</span><strong>{selected.nombre_destinatario}{selected.nif_destinatario ? ` · ${selected.nif_destinatario}` : ''}</strong>
                </div>
              )}
              <div className="vf-detail__row">
                <span>Descripción</span><strong>{selected.descripcion}</strong>
              </div>
              <div className="vf-detail__row vf-detail__row--totals">
                <span>Base imponible</span><strong>€{selected.base_imponible.toFixed(2)}</strong>
              </div>
              <div className="vf-detail__row vf-detail__row--totals">
                <span>Cuota IVA</span><strong>€{selected.cuota_iva.toFixed(2)}</strong>
              </div>
              <div className="vf-detail__row vf-detail__row--total-final">
                <span>TOTAL</span><strong>€{selected.importe_total.toFixed(2)}</strong>
              </div>

              {/* QR */}
              {selected.hash_huella && (
                <div className="vf-qr-block">
                  <div className="vf-qr-block__label"><QrCode size={12}/> Código QR AEAT</div>
                  <QRDisplay url={selected.qr_code ?? ''} size={180}/>
                  <div className="vf-qr-block__hash">
                    <span>Huella SHA-256:</span>
                    <code>{selected.hash_huella.slice(0, 16)}…</code>
                    <button
                      className="vf-icon-btn"
                      onClick={() => {
                        navigator.clipboard.writeText(selected.hash_huella ?? '').catch(() => {});
                        setCopied(true);
                        setTimeout(() => setCopied(false), 2000);
                      }}
                    >
                      {copied ? <Check size={11}/> : <Copy size={11}/>}
                    </button>
                  </div>
                </div>
              )}

              {/* AEAT response */}
              {selected.aeat_response && (
                <div className="vf-detail__aeat-resp">
                  <div className="vf-detail__aeat-resp-label">Respuesta AEAT</div>
                  {selected.aeat_response.CSV && (
                    <div className="vf-detail__row"><span>CSV</span><strong>{selected.aeat_response.CSV}</strong></div>
                  )}
                  {selected.aeat_response.CodigoErrorRegistro && (
                    <div className="vf-detail__row vf-detail__row--err">
                      <span>Código error</span><strong>{selected.aeat_response.CodigoErrorRegistro}</strong>
                    </div>
                  )}
                  {selected.aeat_response.DescripcionErrorRegistro && (
                    <div className="vf-detail__row vf-detail__row--err">
                      <span>Descripción</span><strong>{selected.aeat_response.DescripcionErrorRegistro}</strong>
                    </div>
                  )}
                </div>
              )}

              {/* Actions */}
              <div className="vf-detail__actions">
                {['ERROR', 'RECHAZADO'].includes(selected.aeat_status) && (
                  <button
                    className="vf-btn-primary"
                    onClick={() => retryInvoice(selected)}
                    disabled={sending}
                  >
                    {sending ? <RefreshCw size={13} className="vf-spin"/> : <RotateCcw size={13}/>}
                    Reintentar envío
                  </button>
                )}
                <button className="vf-btn-secondary" onClick={() => {
                  const lines = [
                    `VERI*FACTU · ${selected.numero_serie}`,
                    `Emisor: ${selected.nombre_emisor} (${selected.nif_emisor})`,
                    `Cliente: ${selected.nombre_destinatario ?? '—'}`,
                    `Total: €${selected.importe_total.toFixed(2)}`,
                    `Estado: ${selected.aeat_status}`,
                    `Huella: ${selected.hash_huella ?? '—'}`,
                  ].join('\n');
                  navigator.clipboard.writeText(lines).catch(() => {});
                  showToast('Datos copiados al portapapeles.', 'ok');
                }}>
                  <Download size={13}/> Copiar datos
                </button>
              </div>
            </div>
          </div>
        );
      })()}

      {/* ══════════════════════════════════════════════════════════════════
          NUEVA FACTURA
      ══════════════════════════════════════════════════════════════════ */}
      {screen === 'nueva' && (
        <div className="vf-section">
          <div className="vf-form-card">
            <div className="vf-form-section-title">
              <Building2 size={13}/> Datos del Emisor
            </div>
            <div className="vf-form-row">
              <label>NIF / VAT / KVK / EIN *
                <NIFBadge nif={form.nif_emisor ?? ''} />
              </label>
              <input
                className="vf-input"
                value={form.nif_emisor ?? ''}
                onChange={e => setForm(f => ({ ...f, nif_emisor: e.target.value.toUpperCase() }))}
                onBlur={async () => {
                  const val = form.nif_emisor?.trim() ?? '';
                  if (!val || val.length < 6) return;
                  setLookingUpEmisor(true);
                  try {
                    await supabase.functions.invoke('vies-vat-validator', { body: { vat: val } });
                  } catch { /* function may not exist yet */ }
                  setLookingUpEmisor(false);
                }}
                placeholder="B12345678"
              />
              {lookingUpEmisor && <div style={{ fontSize: 11, color: '#10b981', marginTop: 4 }}>Looking up company...</div>}
              <div style={{ fontSize: 11, color: '#475569', marginTop: 4 }}>Supports: 🇪🇸 ES NIF/CIF · 🇪🇺 EU VAT · 🇳🇱 NL KVK · 🇩🇪 DE USt · 🇫🇷 FR SIRET · 🇧🇪 BE BTW · 🇬🇧 GB VAT · 🇺🇸 US EIN</div>
            </div>
            <div className="vf-form-row">
              <label>Nombre / Razón social *</label>
              <input
                className="vf-input"
                value={form.nombre_emisor ?? ''}
                onChange={e => setForm(f => ({ ...f, nombre_emisor: e.target.value }))}
                placeholder="Empresa S.L."
              />
            </div>

            <div className="vf-form-divider"/>
            <div className="vf-form-section-title">
              <Globe size={13}/> Datos del Cliente (Destinatario)
            </div>
            <div className="vf-form-row">
              <label>NIF / VAT / KVK / EIN (optional)
                <NIFBadge nif={form.nif_destinatario ?? ''} />
              </label>
              <input
                className="vf-input"
                value={form.nif_destinatario ?? ''}
                onChange={e => setForm(f => ({ ...f, nif_destinatario: e.target.value.toUpperCase() }))}
                onBlur={async () => {
                  const val = form.nif_destinatario?.trim() ?? '';
                  if (!val || val.length < 6) return;
                  setLookingUpDest(true);
                  try {
                    await supabase.functions.invoke('vies-vat-validator', { body: { vat: val } });
                  } catch { /* function may not exist yet */ }
                  setLookingUpDest(false);
                }}
                placeholder="12345678Z (opcional)"
              />
              {lookingUpDest && <div style={{ fontSize: 11, color: '#10b981', marginTop: 4 }}>Looking up company...</div>}
              <div style={{ fontSize: 11, color: '#475569', marginTop: 4 }}>Supports: 🇪🇸 ES NIF/CIF · 🇪🇺 EU VAT · 🇳🇱 NL KVK · 🇩🇪 DE USt · 🇫🇷 FR SIRET · 🇧🇪 BE BTW · 🇬🇧 GB VAT · 🇺🇸 US EIN</div>
            </div>
            <div className="vf-form-row">
              <label>Nombre cliente</label>
              <input
                className="vf-input"
                value={form.nombre_destinatario ?? ''}
                onChange={e => setForm(f => ({ ...f, nombre_destinatario: e.target.value }))}
                placeholder="Cliente S.L."
              />
            </div>
            <div className="vf-form-row">
              <label>País</label>
              <select
                className="vf-input"
                value={form.pais_destinatario ?? 'ES'}
                onChange={e => setForm(f => ({ ...f, pais_destinatario: e.target.value }))}
              >
                <option value="ES">España</option>
                <option value="NL">Países Bajos</option>
                <option value="DE">Alemania</option>
                <option value="FR">Francia</option>
                <option value="GB">Reino Unido</option>
                <option value="US">Estados Unidos</option>
                <option value="BE">Bélgica</option>
                <option value="IT">Italia</option>
              </select>
            </div>

            <div className="vf-form-divider"/>
            <div className="vf-form-section-title">
              <FileText size={13}/> Detalle de la Factura
            </div>
            <div className="vf-form-row-2col">
              <div className="vf-form-row">
                <label>Tipo factura</label>
                <select
                  className="vf-input"
                  value={form.tipo_factura ?? 'F1'}
                  onChange={e => setForm(f => ({ ...f, tipo_factura: e.target.value as TipoFactura }))}
                >
                  {Object.entries(TIPO_LABELS).map(([k, v]) => (
                    <option key={k} value={k}>{v}</option>
                  ))}
                </select>
              </div>
              <div className="vf-form-row">
                <label>Fecha expedición</label>
                <input
                  className="vf-input"
                  type="date"
                  value={form.fecha_expedicion ?? todayISO()}
                  onChange={e => setForm(f => ({ ...f, fecha_expedicion: e.target.value }))}
                />
              </div>
            </div>

            <div className="vf-form-row">
              <label>
                Descripción operación *
                {aiHint && (
                  <span className="vf-ai-hint">
                    <Brain size={9}/> {aiHint}
                  </span>
                )}
              </label>
              <input
                className="vf-input"
                value={form.descripcion ?? ''}
                onChange={e => handleDescChange(e.target.value)}
                placeholder="Servicios de consultoría fiscal — Enero 2025"
              />
            </div>

            {/* Line items */}
            <div className="vf-form-divider"/>
            <div className="vf-lineas-header">
              <span className="vf-form-section-title" style={{ margin: 0 }}>
                <Receipt size={13}/> Líneas de factura
              </span>
              <button
                className="vf-btn-outline-sm"
                onClick={() => setLineas(l => [...l, EMPTY_LINEA()])}
              >
                <Plus size={11}/> Añadir línea
              </button>
            </div>

            {lineas.map((line, idx) => (
              <div key={idx} className="vf-linea-row">
                <div className="vf-linea-row__main">
                  <input
                    className="vf-input vf-input--desc"
                    placeholder="Descripción del servicio/producto"
                    value={line.descripcion}
                    onChange={e => updateLinea(idx, 'descripcion', e.target.value)}
                  />
                  <div className="vf-linea-row__nums">
                    <input
                      className="vf-input vf-input--sm"
                      type="number" min="0" step="1"
                      value={line.cantidad}
                      onChange={e => updateLinea(idx, 'cantidad', parseFloat(e.target.value) || 0)}
                      placeholder="Cant."
                    />
                    <input
                      className="vf-input vf-input--sm"
                      type="number" min="0" step="0.01"
                      value={line.precio_unitario}
                      onChange={e => updateLinea(idx, 'precio_unitario', parseFloat(e.target.value) || 0)}
                      placeholder="P.Unit €"
                    />
                    <select
                      className="vf-input vf-input--sm"
                      value={line.tipo_iva}
                      onChange={e => updateLinea(idx, 'tipo_iva', parseInt(e.target.value))}
                    >
                      <option value={0}>IVA 0%</option>
                      <option value={4}>IVA 4%</option>
                      <option value={10}>IVA 10%</option>
                      <option value={21}>IVA 21%</option>
                    </select>
                    <span className="vf-linea-row__importe">€{line.importe.toFixed(2)}</span>
                    {lineas.length > 1 && (
                      <button
                        className="vf-icon-btn vf-icon-btn--danger"
                        onClick={() => setLineas(l => l.filter((_, i) => i !== idx))}
                      >
                        <Trash2 size={11}/>
                      </button>
                    )}
                  </div>
                </div>
              </div>
            ))}

            {/* Totals */}
            <div className="vf-totals-box">
              <div className="vf-total-row">
                <span>Base imponible</span><strong>€{totales.base_imponible.toFixed(2)}</strong>
              </div>
              <div className="vf-total-row">
                <span>Cuota IVA</span><strong>€{totales.cuota_iva.toFixed(2)}</strong>
              </div>
              <div className="vf-total-row vf-total-row--final">
                <span>Total factura</span><strong>€{totales.importe_total.toFixed(2)}</strong>
              </div>
            </div>

            {/* Actions */}
            <div className="vf-form-actions">
              <button
                className="vf-btn-secondary"
                disabled={submitting}
                onClick={() => guardarFactura('BORRADOR')}
              >
                <FileText size={13}/> Guardar borrador
              </button>
              <button
                className="vf-btn-primary"
                disabled={submitting || sending}
                onClick={() => guardarFactura('PENDIENTE')}
              >
                {submitting || sending
                  ? <RefreshCw size={13} className="vf-spin"/>
                  : <Send size={13}/>
                }
                Enviar a AEAT
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ══════════════════════════════════════════════════════════════════
          CONFIGURACIÓN
      ══════════════════════════════════════════════════════════════════ */}
      {screen === 'config' && (
        <div className="vf-section">
          <div className="vf-form-card">
            <div className="vf-form-section-title">
              <Building2 size={13}/> Datos de la empresa
            </div>
            <div className="vf-form-row">
              <label>NIF/CIF de la empresa *</label>
              <input
                className="vf-input"
                value={config.nif}
                onChange={e => setConfig(c => ({ ...c, nif: e.target.value.toUpperCase() }))}
                placeholder="B12345678"
              />
            </div>
            <div className="vf-form-row">
              <label>Nombre / Razón social *</label>
              <input
                className="vf-input"
                value={config.nombre}
                onChange={e => setConfig(c => ({ ...c, nombre: e.target.value }))}
                placeholder="Mi Empresa S.L."
              />
            </div>
            <div className="vf-form-row">
              <label>Dirección fiscal</label>
              <input
                className="vf-input"
                value={config.direccion}
                onChange={e => setConfig(c => ({ ...c, direccion: e.target.value }))}
                placeholder="Calle Mayor 1, 28001 Madrid"
              />
            </div>

            <div className="vf-form-divider"/>
            <div className="vf-form-section-title">
              <Zap size={13}/> Ajustes de envío
            </div>

            <div className="vf-config-toggle-row">
              <div>
                <div className="vf-config-toggle-row__label">Entorno AEAT</div>
                <div className="vf-config-toggle-row__sub">Cambia a Producción solo cuando tengas el certificado digital.</div>
              </div>
              <div className="vf-toggle-group">
                {(['PRUEBAS', 'PRODUCCION'] as const).map(e => (
                  <button
                    key={e}
                    className={`vf-toggle-btn${config.entorno === e ? ' vf-toggle-btn--active' : ''}`}
                    style={config.entorno === e ? { background: e === 'PRODUCCION' ? '#4ade80' : '#fbbf24', color: '#0a0f1e' } : {}}
                    onClick={() => setConfig(c => ({ ...c, entorno: e }))}
                  >
                    {e === 'PRUEBAS' ? 'Sandbox' : 'Producción'}
                  </button>
                ))}
              </div>
            </div>

            <div className="vf-config-toggle-row">
              <div>
                <div className="vf-config-toggle-row__label">Envío automático</div>
                <div className="vf-config-toggle-row__sub">Enviar a AEAT inmediatamente al crear la factura.</div>
              </div>
              <button
                className={`vf-switch${config.auto_send ? ' vf-switch--on' : ''}`}
                onClick={() => setConfig(c => ({ ...c, auto_send: !c.auto_send }))}
              >
                <span className="vf-switch__thumb"/>
              </button>
            </div>

            <div className="vf-form-divider"/>
            <div className="vf-form-section-title">
              <ShieldCheck size={13}/> Certificado digital
              <span className="vf-badge vf-badge--blue" style={{ marginLeft: 8 }}>Próximamente</span>
            </div>
            <div className="vf-cert-placeholder">
              <ShieldCheck size={28} style={{ opacity: 0.3 }}/>
              <p>La firma digital XML (XADES) con certificado FNMT o eIDAS estará disponible en la próxima versión. Actualmente las peticiones se envían sin firma (válido en entorno de pruebas).</p>
            </div>

            <button className="vf-btn-primary" onClick={saveConfig} style={{ width: '100%', marginTop: 16 }}>
              <Check size={14}/> Guardar configuración
            </button>
          </div>
        </div>
      )}

      <style>{`
        .vf-root { display:flex; flex-direction:column; gap:0; background:#0a0f1e; min-height:100%; color:#e2e8f0; }
        .vf-toast { position:fixed; bottom:80px; left:50%; transform:translateX(-50%); display:flex; align-items:center; gap:8px; padding:10px 20px; border-radius:10px; font-size:13px; font-weight:500; z-index:9999; white-space:nowrap; box-shadow:0 4px 24px #0006; }
        .vf-toast--ok  { background:#4ade8022; border:1px solid #4ade8066; color:#4ade80; }
        .vf-toast--err { background:#f8717122; border:1px solid #f8717166; color:#f87171; }

        .vf-header { display:flex; align-items:center; justify-content:space-between; padding:14px 16px; background:linear-gradient(135deg,#001a5e,#003082); border-bottom:1px solid #003082; }
        .vf-header__brand { display:flex; align-items:center; gap:10px; }
        .vf-header__logo { width:36px; height:36px; background:#003082; border:1px solid #1d4ed8; border-radius:8px; display:flex; align-items:center; justify-content:center; color:#60a5fa; }
        .vf-header__title { font-size:17px; font-weight:800; color:#fff; letter-spacing:1px; }
        .vf-header__title span { color:#f59e0b; }
        .vf-header__sub { font-size:10px; color:#93c5fd; }
        .vf-header__badges { display:flex; gap:6px; flex-wrap:wrap; justify-content:flex-end; }

        .vf-badge { display:inline-flex; align-items:center; gap:3px; font-size:9px; font-weight:700; padding:2px 7px; border-radius:4px; }
        .vf-badge--green  { background:#4ade8022; color:#4ade80; border:1px solid #4ade8044; }
        .vf-badge--yellow { background:#fbbf2422; color:#fbbf24; border:1px solid #fbbf2444; }
        .vf-badge--blue   { background:#60a5fa22; color:#60a5fa; border:1px solid #60a5fa44; }

        .vf-nav { display:flex; gap:2px; padding:8px 12px; background:#0d1528; border-bottom:1px solid #1e293b; }
        .vf-nav__btn { flex:1; display:flex; align-items:center; justify-content:center; gap:5px; padding:7px 0; border-radius:7px; border:none; background:transparent; color:#64748b; font-size:12px; font-weight:600; cursor:pointer; transition:all 0.15s; }
        .vf-nav__btn--active { background:#003082; color:#93c5fd; }

        .vf-section { padding:14px; display:flex; flex-direction:column; gap:12px; }

        .vf-conn-card { display:flex; align-items:flex-start; gap:10px; padding:12px 14px; border-radius:10px; border:1px solid; font-size:12px; }
        .vf-conn-card--test { background:#fbbf2410; border-color:#fbbf2444; color:#fbbf24; }
        .vf-conn-card--prod { background:#4ade8010; border-color:#4ade8044; color:#4ade80; }
        .vf-conn-card__title { font-weight:700; margin-bottom:2px; }
        .vf-conn-card__sub { font-size:10px; opacity:0.8; }

        .vf-stats { display:grid; grid-template-columns:repeat(4,1fr); gap:8px; }
        .vf-stat { background:#0d1528; border:1px solid; border-radius:10px; padding:10px 8px; text-align:center; }
        .vf-stat__val { font-size:22px; font-weight:800; }
        .vf-stat__lbl { font-size:10px; color:#64748b; margin-top:2px; }

        .vf-list-header { display:flex; align-items:center; justify-content:space-between; font-size:12px; font-weight:700; color:#94a3b8; padding:0 2px; }
        .vf-loading { display:flex; align-items:center; justify-content:center; gap:8px; padding:40px; color:#475569; font-size:13px; }
        .vf-empty { display:flex; flex-direction:column; align-items:center; gap:12px; padding:40px 20px; text-align:center; color:#475569; font-size:13px; }

        .vf-invoice-list { display:flex; flex-direction:column; gap:6px; }
        .vf-invoice-row { display:flex; align-items:center; justify-content:space-between; background:#0d1528; border:1px solid #1e293b; border-radius:10px; padding:10px 12px; cursor:pointer; transition:border-color 0.15s; }
        .vf-invoice-row:hover { border-color:#1d4ed8; }
        .vf-invoice-row__left { display:flex; flex-direction:column; gap:2px; }
        .vf-invoice-row__num { font-size:13px; font-weight:700; color:#e2e8f0; }
        .vf-invoice-row__client { font-size:11px; color:#64748b; }
        .vf-invoice-row__right { display:flex; align-items:center; gap:8px; }
        .vf-invoice-row__amount { font-size:14px; font-weight:700; color:#e2e8f0; }
        .vf-status-badge { display:inline-flex; align-items:center; gap:3px; font-size:10px; font-weight:600; padding:2px 7px; border-radius:5px; }

        .vf-fab { display:flex; align-items:center; justify-content:center; gap:8px; background:linear-gradient(135deg,#1d4ed8,#003082); color:#fff; border:none; border-radius:14px; padding:14px 20px; font-size:14px; font-weight:700; cursor:pointer; box-shadow:0 4px 24px #003082aa; margin-top:8px; }

        .vf-back-btn { background:none; border:none; color:#60a5fa; font-size:13px; cursor:pointer; padding:4px 0; }
        .vf-detail-card { background:#0d1528; border:1px solid #1e293b; border-radius:14px; overflow:hidden; }
        .vf-detail__status-bar { display:flex; align-items:center; justify-content:space-between; padding:10px 14px; border-bottom:1px solid; font-size:12px; font-weight:600; }
        .vf-detail__ts { font-size:10px; font-weight:400; color:#64748b; }
        .vf-detail__row { display:flex; justify-content:space-between; align-items:center; padding:8px 14px; border-bottom:1px solid #1e293b; font-size:12px; }
        .vf-detail__row span { color:#64748b; }
        .vf-detail__row strong { color:#e2e8f0; text-align:right; max-width:60%; }
        .vf-detail__row--totals { background:#0a0f1e22; }
        .vf-detail__row--total-final { background:#003082; font-size:14px; }
        .vf-detail__row--total-final span, .vf-detail__row--total-final strong { color:#93c5fd; }
        .vf-detail__row--err span { color:#f87171; }
        .vf-detail__row--err strong { color:#f87171; }
        .vf-detail__aeat-resp { padding:10px 14px; border-top:1px solid #1e293b; }
        .vf-detail__aeat-resp-label { font-size:11px; font-weight:700; color:#64748b; margin-bottom:6px; }
        .vf-detail__actions { display:flex; gap:8px; padding:12px 14px; border-top:1px solid #1e293b; }

        .vf-qr-block { display:flex; flex-direction:column; align-items:center; gap:10px; padding:16px 14px; border-top:1px solid #1e293b; }
        .vf-qr-block__label { font-size:11px; color:#60a5fa; font-weight:700; display:flex; align-items:center; gap:5px; }
        .vf-qr-block__hash { display:flex; align-items:center; gap:8px; font-size:11px; color:#64748b; }
        .vf-qr-block__hash code { color:#93c5fd; font-family:monospace; }

        .vf-form-card { background:#0d1528; border:1px solid #1e293b; border-radius:14px; padding:16px; display:flex; flex-direction:column; gap:12px; }
        .vf-form-section-title { display:flex; align-items:center; gap:6px; font-size:12px; font-weight:700; color:#60a5fa; text-transform:uppercase; letter-spacing:0.5px; margin-bottom:4px; }
        .vf-form-divider { height:1px; background:#1e293b; margin:4px 0; }
        .vf-form-row { display:flex; flex-direction:column; gap:5px; }
        .vf-form-row label { font-size:11px; color:#94a3b8; font-weight:600; display:flex; align-items:center; }
        .vf-form-row-2col { display:grid; grid-template-columns:1fr 1fr; gap:10px; }
        .vf-input { background:#0a0f1e; border:1px solid #1e293b; border-radius:8px; padding:9px 11px; color:#e2e8f0; font-size:13px; width:100%; outline:none; transition:border-color 0.15s; box-sizing:border-box; }
        .vf-input:focus { border-color:#1d4ed8; }
        .vf-input--sm { width:80px; flex-shrink:0; }
        .vf-input--desc { flex:1; }
        select.vf-input { cursor:pointer; }

        .vf-ai-hint { display:inline-flex; align-items:center; gap:3px; font-size:10px; color:#fbbf24; font-weight:400; margin-left:6px; }

        .vf-lineas-header { display:flex; align-items:center; justify-content:space-between; }
        .vf-linea-row { background:#0a0f1e; border:1px solid #1e293b; border-radius:8px; padding:10px; }
        .vf-linea-row__main { display:flex; flex-direction:column; gap:8px; }
        .vf-linea-row__nums { display:flex; align-items:center; gap:6px; flex-wrap:wrap; }
        .vf-linea-row__importe { font-size:13px; font-weight:700; color:#60a5fa; min-width:64px; text-align:right; }

        .vf-totals-box { background:#0a0f1e; border:1px solid #1e293b; border-radius:8px; overflow:hidden; }
        .vf-total-row { display:flex; justify-content:space-between; padding:8px 12px; border-bottom:1px solid #1e293b; font-size:13px; color:#94a3b8; }
        .vf-total-row--final { background:#003082; font-size:14px; font-weight:700; border-bottom:none; }
        .vf-total-row--final span, .vf-total-row--final strong { color:#93c5fd; }

        .vf-form-actions { display:flex; gap:8px; margin-top:4px; }

        .vf-btn-primary { flex:1; display:flex; align-items:center; justify-content:center; gap:7px; background:linear-gradient(135deg,#1d4ed8,#003082); color:#fff; border:none; border-radius:10px; padding:12px 16px; font-size:13px; font-weight:700; cursor:pointer; transition:opacity 0.15s; }
        .vf-btn-primary:disabled { opacity:0.5; cursor:not-allowed; }
        .vf-btn-secondary { flex:1; display:flex; align-items:center; justify-content:center; gap:7px; background:#0a0f1e; border:1px solid #1e293b; color:#94a3b8; border-radius:10px; padding:12px 16px; font-size:13px; font-weight:600; cursor:pointer; transition:border-color 0.15s; }
        .vf-btn-secondary:hover { border-color:#1d4ed8; color:#60a5fa; }
        .vf-btn-secondary:disabled { opacity:0.5; cursor:not-allowed; }
        .vf-btn-outline-sm { display:flex; align-items:center; gap:4px; background:transparent; border:1px solid #1e293b; color:#60a5fa; border-radius:6px; padding:5px 10px; font-size:11px; cursor:pointer; }

        .vf-icon-btn { background:none; border:none; cursor:pointer; color:#64748b; padding:2px; display:flex; align-items:center; }
        .vf-icon-btn:hover { color:#93c5fd; }
        .vf-icon-btn--danger:hover { color:#f87171; }

        .vf-config-toggle-row { display:flex; align-items:center; justify-content:space-between; gap:10px; padding:10px 0; border-bottom:1px solid #1e293b; }
        .vf-config-toggle-row__label { font-size:13px; font-weight:600; color:#e2e8f0; }
        .vf-config-toggle-row__sub { font-size:11px; color:#64748b; margin-top:2px; }
        .vf-toggle-group { display:flex; gap:4px; }
        .vf-toggle-btn { padding:5px 12px; border-radius:6px; border:1px solid #1e293b; background:#0a0f1e; color:#64748b; font-size:11px; font-weight:600; cursor:pointer; transition:all 0.15s; }

        .vf-switch { width:44px; height:24px; border-radius:12px; border:none; cursor:pointer; background:#1e293b; position:relative; transition:background 0.2s; flex-shrink:0; }
        .vf-switch--on { background:#1d4ed8; }
        .vf-switch__thumb { position:absolute; top:3px; left:3px; width:18px; height:18px; border-radius:9px; background:#fff; transition:left 0.2s; }
        .vf-switch--on .vf-switch__thumb { left:23px; }

        .vf-cert-placeholder { display:flex; flex-direction:column; align-items:center; gap:8px; padding:20px; text-align:center; background:#0a0f1e; border:1px dashed #1e293b; border-radius:8px; }
        .vf-cert-placeholder p { font-size:12px; color:#475569; margin:0; }

        .vf-spin { animation:vf-spin 0.8s linear infinite; }
        @keyframes vf-spin { to { transform:rotate(360deg); } }
      `}</style>
    </div>
  );
}
