/**
 * AippieAssistantView — V123 Face-to-Face Message Reader, STT Reply Drafter & Clipboard Bridge
 * AIPPIETAX S.A.
 *
 * V123 additions:
 *  - Clipboard Paste shortcut: one-tap pulls copied text into the reader engine
 *  - Speech-to-Text reply drafting via webkitSpeechRecognition (hands-free)
 *  - Internal Web Notification dispatch after read completion
 */
import { useCallback, useEffect, useRef, useState } from 'react';
import {
  Mic, MicOff, Play, Square, RotateCcw, Copy, CheckCircle2,
  ChevronRight, MessageSquare, FileText, Globe,
  Sparkles, Volume2, VolumeX, AlertCircle, Clipboard,
  Radio
} from 'lucide-react';
import { applyPremiumVoice, withVoicesReady, normalizeForTTS } from '../lib/ttsVoice';
import { notifyReadComplete, notificationsGranted } from '../lib/notificationService';

const SPEECH_RATE  = 0.82;
const SPEECH_PITCH = 1.02;

type Stage = 'input' | 'reading' | 'read-done' | 'reply-prompt' | 'drafting' | 'draft-done';
type ReplyTone = 'formal' | 'friendly' | 'assertive';
type DraftLang = 'nl' | 'en' | 'es' | 'de' | 'fr';

const LANG_LABELS: Record<DraftLang, string> = {
  nl: 'Nederlands', en: 'English', es: 'Español', de: 'Deutsch', fr: 'Français',
};

const TONE_LABELS: Record<ReplyTone, string> = {
  formal: 'Formal', friendly: 'Friendly', assertive: 'Assertive',
};

// ── SpeechRecognition types (not in lib.dom by default) ────────────────────
declare global {
  interface Window {
    SpeechRecognition: new () => SpeechRecognitionInstance;
    webkitSpeechRecognition: new () => SpeechRecognitionInstance;
  }
}

interface SpeechRecognitionInstance extends EventTarget {
  lang:         string;
  continuous:   boolean;
  interimResults: boolean;
  maxAlternatives: number;
  start():  void;
  stop():   void;
  abort():  void;
  onresult: ((e: SpeechRecognitionEvent) => void) | null;
  onend:    (() => void) | null;
  onerror:  ((e: { error: string }) => void) | null;
}

interface SpeechRecognitionEvent extends Event {
  resultIndex: number;
  results: {
    length: number;
    [i: number]: { isFinal: boolean; [j: number]: { transcript: string } };
  };
}

function getSpeechRecognition(): (new () => SpeechRecognitionInstance) | null {
  if (typeof window === 'undefined') return null;
  return window.SpeechRecognition ?? window.webkitSpeechRecognition ?? null;
}

const SUPABASE_URL = import.meta.env.VITE_SUPABASE_URL as string;
const SUPABASE_ANON_KEY = import.meta.env.VITE_SUPABASE_ANON_KEY as string;

async function generateDraftAI(
  originalText: string,
  context: string,
  tone: ReplyTone,
  lang: DraftLang,
): Promise<string> {
  const res = await fetch(`${SUPABASE_URL}/functions/v1/assistant-reply`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${SUPABASE_ANON_KEY}`,
    },
    body: JSON.stringify({ originalMessage: originalText, context, tone, lang }),
  });
  if (!res.ok) throw new Error('AI generation failed');
  const data = await res.json();
  if (!data.reply) throw new Error('Empty reply');
  return data.reply;
}

// ── 20-bar waveform ───────────────────────────────────────────────────────────
function MiniWaveform({ active, color }: { active: boolean; color: string }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const frameRef  = useRef<number>(0);
  const tick      = useRef(0);
  useEffect(() => {
    const canvas = canvasRef.current; if (!canvas) return;
    const ctx = canvas.getContext('2d'); if (!ctx) return;
    const BARS = 20;
    const draw = () => {
      tick.current++;
      const tk = tick.current, W = canvas.width, H = canvas.height;
      ctx.clearRect(0, 0, W, H);
      const gap = W / BARS, barW = Math.max(2, gap - 2);
      for (let i = 0; i < BARS; i++) {
        const phase = (i / BARS) * Math.PI * 2;
        const rawH = active
          ? (0.15 + 0.85 * Math.abs(Math.sin(tk * 0.08 + phase))) * H
          : (0.05 + 0.03 * Math.abs(Math.sin(tk * 0.01 + phase))) * H;
        const x = i * gap + (gap - barW) / 2, y = (H - rawH) / 2;
        ctx.fillStyle = color + (active ? 'dd' : '25');
        ctx.beginPath();
        ctx.roundRect(x, y, barW, rawH, Math.min(barW / 2, 3));
        ctx.fill();
      }
      frameRef.current = requestAnimationFrame(draw);
    };
    frameRef.current = requestAnimationFrame(draw);
    return () => cancelAnimationFrame(frameRef.current);
  }, [active, color]);
  return <canvas ref={canvasRef} width={160} height={28} className="av-waveform" />;
}

// ── Typewriter subtitle ────────────────────────────────────────────────────────
function useTypewriterSub(text: string, active: boolean) {
  const [sub, setSub] = useState('');
  const tmr = useRef<ReturnType<typeof setInterval> | null>(null);
  const idx  = useRef(0);
  useEffect(() => {
    if (tmr.current) { clearInterval(tmr.current); tmr.current = null; }
    setSub('');
    if (!active || !text.trim()) return;
    const words = text.split(/\s+/);
    idx.current = 0;
    tmr.current = setInterval(() => {
      idx.current++;
      setSub(words.slice(Math.max(0, idx.current - 10), idx.current).join(' '));
      if (idx.current >= words.length) { clearInterval(tmr.current!); tmr.current = null; }
    }, 480);
    return () => { if (tmr.current) { clearInterval(tmr.current); tmr.current = null; } };
  }, [text, active]);
  return sub;
}

// ── STT status label ─────────────────────────────────────────────────────────
type SttStatus = 'idle' | 'listening' | 'processing' | 'done' | 'unsupported' | 'error';

export default function AippieAssistantView() {
  const [stage,       setStage]       = useState<Stage>('input');
  const [inputText,   setInputText]   = useState('');
  const [replyCtx,    setReplyCtx]    = useState('');
  const [replyTone,   setReplyTone]   = useState<ReplyTone>('formal');
  const [replyLang,   setReplyLang]   = useState<DraftLang>('nl');
  const [draft,       setDraft]       = useState('');
  const [draftError,  setDraftError]  = useState('');
  const [speaking,    setSpeaking]    = useState(false);
  const [muted,       setMuted]       = useState(false);
  const [copied,      setCopied]      = useState(false);
  const [charCount,   setCharCount]   = useState(0);

  // STT state
  const [sttStatus,   setSttStatus]   = useState<SttStatus>('idle');
  const [sttInterim,  setSttInterim]  = useState('');
  const [sttLang,     setSttLang]     = useState<DraftLang>('nl');
  const sttRef        = useRef<SpeechRecognitionInstance | null>(null);

  // Clipboard state
  const [clipStatus,  setClipStatus]  = useState<'idle' | 'copied' | 'denied'>('idle');

  const cancelRef  = useRef(false);
  const subtitle   = useTypewriterSub(inputText, speaking);

  const MAX_CHARS = 2000;

  const STT_LANG_CODES: Record<DraftLang, string> = {
    nl: 'nl-NL', en: 'en-GB', es: 'es-ES', de: 'de-DE', fr: 'fr-FR',
  };

  // Check STT support on mount
  useEffect(() => {
    if (!getSpeechRecognition()) setSttStatus('unsupported');
    return () => {
      cancelRef.current = true;
      window.speechSynthesis?.cancel();
      sttRef.current?.abort();
    };
  }, []);

  // ── speak() ───────────────────────────────────────────────────────────────
  const speak = useCallback((text: string, onEnd?: () => void) => {
    if (!('speechSynthesis' in window) || muted) { onEnd?.(); return; }
    cancelRef.current = true;
    window.speechSynthesis.cancel();
    cancelRef.current = false;
    setSpeaking(true);
    const fire = () => {
      const u = new SpeechSynthesisUtterance(normalizeForTTS(text));
      u.rate  = SPEECH_RATE;
      u.pitch = SPEECH_PITCH;
      applyPremiumVoice(u);
      u.onend   = () => { if (!cancelRef.current) { setSpeaking(false); onEnd?.(); } };
      u.onerror = () => { setSpeaking(false); onEnd?.(); };
      window.speechSynthesis.speak(u);
    };
    withVoicesReady(fire);
  }, [muted]);

  const stopSpeech = useCallback(() => {
    cancelRef.current = true;
    window.speechSynthesis?.cancel();
    setSpeaking(false);
  }, []);

  // ── Clipboard paste ────────────────────────────────────────────────────────
  const handleClipboardPaste = useCallback(async () => {
    try {
      const text = await navigator.clipboard.readText();
      if (!text.trim()) return;
      const trimmed = text.slice(0, MAX_CHARS);
      setInputText(trimmed);
      setCharCount(trimmed.length);
      setStage('input');
      setClipStatus('copied');
      setTimeout(() => setClipStatus('idle'), 2500);
    } catch {
      setClipStatus('denied');
      setTimeout(() => setClipStatus('idle'), 2500);
    }
  }, []);

  // ── STT ───────────────────────────────────────────────────────────────────
  const startSTT = useCallback((
    onFinal: (text: string) => void,
    targetLang: DraftLang,
  ) => {
    const SR = getSpeechRecognition();
    if (!SR) { setSttStatus('unsupported'); return; }

    sttRef.current?.abort();
    const rec = new SR();
    sttRef.current = rec;
    rec.lang             = STT_LANG_CODES[targetLang];
    rec.continuous       = false;
    rec.interimResults   = true;
    rec.maxAlternatives  = 1;

    setSttStatus('listening');
    setSttInterim('');

    rec.onresult = (e: SpeechRecognitionEvent) => {
      let interim = '';
      let finalStr = '';
      for (let i = e.resultIndex; i < e.results.length; i++) {
        const t = e.results[i][0].transcript;
        if (e.results[i].isFinal) finalStr += t;
        else interim += t;
      }
      setSttInterim(interim);
      if (finalStr) {
        setSttStatus('processing');
        setSttInterim('');
        onFinal(finalStr.trim());
      }
    };

    rec.onend = () => {
      setSttStatus(prev => prev === 'listening' ? 'idle' : prev);
    };

    rec.onerror = (e: { error: string }) => {
      setSttStatus(e.error === 'not-allowed' ? 'error' : 'idle');
      setSttInterim('');
    };

    try { rec.start(); } catch { setSttStatus('error'); }
  // STT_LANG_CODES is a constant — safe to omit
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const stopSTT = useCallback(() => {
    sttRef.current?.stop();
    setSttStatus('idle');
    setSttInterim('');
  }, []);

  // ── Handlers ──────────────────────────────────────────────────────────────
  const handleRead = () => {
    if (!inputText.trim()) return;
    setStage('reading');
    speak(inputText, () => {
      setStage('read-done');
      if (notificationsGranted()) {
        notifyReadComplete({ preview: inputText });
      }
    });
  };

  const handleGenerateDraft = async () => {
    setStage('drafting');
    setDraftError('');
    try {
      const d = await generateDraftAI(inputText, replyCtx, replyTone, replyLang);
      setDraft(d);
      setStage('draft-done');
    } catch {
      setDraftError('Could not generate reply. Please try again.');
      setStage('reply-prompt');
    }
  };

  const handleReadDraft = () => speak(draft);

  const handleCopyDraft = () => {
    navigator.clipboard.writeText(draft).catch(() => {});
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleReset = () => {
    stopSpeech();
    stopSTT();
    setStage('input');
    setInputText('');
    setReplyCtx('');
    setDraft('');
    setDraftError('');
    setCopied(false);
    setCharCount(0);
    setSttInterim('');
    setSttStatus(getSpeechRecognition() ? 'idle' : 'unsupported');
  };

  // STT for reply context
  const handleSttReply = () => {
    if (sttStatus === 'listening') { stopSTT(); return; }
    startSTT((text) => {
      setReplyCtx(prev => (prev.trim() ? prev.trim() + ' ' : '') + text);
      setSttStatus('done');
      setTimeout(() => setSttStatus('idle'), 1500);
    }, replyLang);
  };

  // STT for input field
  const handleSttInput = () => {
    if (sttStatus === 'listening') { stopSTT(); return; }
    startSTT((text) => {
      const combined = (inputText.trim() ? inputText.trim() + ' ' : '') + text;
      const trimmed  = combined.slice(0, MAX_CHARS);
      setInputText(trimmed);
      setCharCount(trimmed.length);
      setSttStatus('done');
      if (stage === 'read-done') setStage('input');
      setTimeout(() => setSttStatus('idle'), 1500);
    }, sttLang);
  };

  const avatarSpeaking = speaking && stage !== 'draft-done';

  // ── Clipboard button label ─────────────────────────────────────────────────
  const clipLabel = clipStatus === 'copied'
    ? <><CheckCircle2 size={12} /> Pasted</>
    : clipStatus === 'denied'
    ? <><AlertCircle size={12} /> No access</>
    : <><Clipboard size={12} /> Paste from clipboard</>;

  // ── STT mic button label ────────────────────────────────────────────────────
  const sttMicLabel = (forInput: boolean) => {
    if (sttStatus === 'unsupported') return <><MicOff size={12} /> Not available</>;
    if (sttStatus === 'listening')   return <><Radio size={12} className="av-pulse" /> Listening…</>;
    if (sttStatus === 'processing')  return <><span className="av-spinner" /> Processing…</>;
    if (sttStatus === 'done' && forInput) return <><CheckCircle2 size={12} /> Recorded</>;
    return <><Mic size={12} /> Dictate</>;
  };

  return (
    <div className="av-root">

      {/* ── Avatar face panel ── */}
      <div className="av-face-panel">
        <div className={`av-avatar-wrap${avatarSpeaking ? ' av-avatar-wrap--speaking' : ''}`}>
          <img
            src="/Jouw_alineatekst_(2).png"
            alt="Aippie"
            className={`av-avatar-img${avatarSpeaking ? ' av-avatar-img--speaking' : ''}`}
            draggable={false}
            onError={e => {
              (e.currentTarget as HTMLImageElement).src =
                'https://images.pexels.com/photos/1858175/pexels-photo-1858175.jpeg?auto=compress&cs=tinysrgb&w=200&h=260&fit=crop&crop=faces';
            }}
          />
          {avatarSpeaking && (
            <>
              <span className="av-ring av-ring--1" />
              <span className="av-ring av-ring--2" />
            </>
          )}
        </div>

        <div className="av-wave-row">
          <MiniWaveform active={avatarSpeaking} color="#38bdf8" />
        </div>

        <div className={`av-subtitle${avatarSpeaking && subtitle ? ' av-subtitle--active' : ''}`}>
          {avatarSpeaking && subtitle ? subtitle : '\u00A0'}
        </div>

        <button
          className="av-mute-btn"
          onClick={() => { setMuted(m => !m); if (!muted) stopSpeech(); }}
          title={muted ? 'Sound on' : 'Sound off'}
        >
          {muted ? <VolumeX size={13} /> : <Volume2 size={13} />}
          <span>{muted ? 'Sound off' : 'Voice active'}</span>
        </button>

        {/* STT language selector for input */}
        {(stage === 'input' || stage === 'reading' || stage === 'read-done') && sttStatus !== 'unsupported' && (
          <div className="av-stt-lang-row">
            {(Object.keys(LANG_LABELS) as DraftLang[]).map(l => (
              <button
                key={l}
                className={`av-stt-lang-btn${sttLang === l ? ' av-stt-lang-btn--active' : ''}`}
                onClick={() => setSttLang(l)}
                title={LANG_LABELS[l]}
              >
                {l.toUpperCase()}
              </button>
            ))}
          </div>
        )}
      </div>

      {/* ── Work panel ── */}
      <div className="av-work-panel">

        {/* ── STAGE: input / reading / read-done ── */}
        {(stage === 'input' || stage === 'reading' || stage === 'read-done') && (
          <div className="av-section">
            <div className="av-section__header">
              <FileText size={14} style={{ color: '#38bdf8' }} />
              <span className="av-section__title">Enter message or text</span>
              <span className="av-section__badge">v123</span>
            </div>

            {/* ── V123: Clipboard paste + STT input row ── */}
            <div className="av-input-actions">
              <button
                className={`av-input-action-btn${clipStatus === 'copied' ? ' av-input-action-btn--success' : ''}${clipStatus === 'denied' ? ' av-input-action-btn--error' : ''}`}
                onClick={handleClipboardPaste}
                disabled={stage === 'reading'}
                title="Paste text from clipboard"
              >
                {clipLabel}
              </button>
              <button
                className={`av-input-action-btn${sttStatus === 'listening' ? ' av-input-action-btn--recording' : ''}${sttStatus === 'done' ? ' av-input-action-btn--success' : ''}`}
                onClick={handleSttInput}
                disabled={stage === 'reading' || sttStatus === 'unsupported' || sttStatus === 'processing'}
                title="Dictate text via microphone"
              >
                {sttMicLabel(true)}
              </button>
            </div>

            {/* Interim STT feedback */}
            {sttStatus === 'listening' && (
              <div className="av-stt-interim">
                <Radio size={10} className="av-pulse" style={{ color: '#f87171', flexShrink: 0 }} />
                <span>{sttInterim || 'Waiting for speech…'}</span>
              </div>
            )}

            <div className="av-textarea-wrap">
              <textarea
                className="av-textarea"
                value={inputText}
                onChange={e => {
                  const v = e.target.value.slice(0, MAX_CHARS);
                  setInputText(v);
                  setCharCount(v.length);
                  if (stage === 'read-done') setStage('input');
                }}
                placeholder="Paste or dictate a message, email, letter, or contract text here. Aippie will read it aloud and help you formulate a reply."
                rows={7}
                disabled={stage === 'reading'}
              />
              <div className="av-textarea__footer">
                <span className={charCount > MAX_CHARS * 0.9 ? 'av-char-warn' : 'av-char-count'}>
                  {charCount}/{MAX_CHARS}
                </span>
                {inputText && (
                  <button className="av-clear-btn" onClick={handleReset}>
                    <RotateCcw size={11} /> Clear
                  </button>
                )}
              </div>
            </div>

            <div className="av-action-row">
              {stage === 'reading' ? (
                <button className="av-btn av-btn--stop" onClick={stopSpeech}>
                  <Square size={13} /> Stop
                </button>
              ) : (
                <button
                  className="av-btn av-btn--play"
                  onClick={handleRead}
                  disabled={!inputText.trim()}
                >
                  <Play size={13} /> Read Aloud
                </button>
              )}
              {stage === 'read-done' && (
                <button className="av-btn av-btn--next" onClick={() => setStage('reply-prompt')}>
                  <MessageSquare size={13} /> Draft a Reply
                  <ChevronRight size={12} />
                </button>
              )}
            </div>

            {stage === 'read-done' && (
              <div className="av-done-note">
                <CheckCircle2 size={11} style={{ color: '#4ade80' }} />
                Aippie has finished reading the text. Would you like to draft a reply?
              </div>
            )}
          </div>
        )}

        {/* ── STAGE: reply-prompt / drafting ── */}
        {(stage === 'reply-prompt' || stage === 'drafting') && (
          <div className="av-section">
            <div className="av-section__header">
              <MessageSquare size={14} style={{ color: '#a78bfa' }} />
              <span className="av-section__title">Configure Reply</span>
            </div>

            <div className="av-field-label">Reply Language</div>
            <div className="av-pill-row">
              {(Object.keys(LANG_LABELS) as DraftLang[]).map(l => (
                <button
                  key={l}
                  className={`av-pill${replyLang === l ? ' av-pill--active' : ''}`}
                  onClick={() => setReplyLang(l)}
                >
                  <Globe size={10} /> {LANG_LABELS[l]}
                </button>
              ))}
            </div>

            <div className="av-field-label" style={{ marginTop: 12 }}>Tone</div>
            <div className="av-pill-row">
              {(Object.keys(TONE_LABELS) as ReplyTone[]).map(t => (
                <button
                  key={t}
                  className={`av-pill${replyTone === t ? ' av-pill--active' : ''}`}
                  onClick={() => setReplyTone(t)}
                >
                  {TONE_LABELS[t]}
                </button>
              ))}
            </div>

            {/* Reply context — text + STT */}
            <div className="av-field-label" style={{ marginTop: 12 }}>
              Your reply context (optional) — type or dictate
            </div>

            {/* V123: STT button for reply context */}
            <div className="av-input-actions av-input-actions--compact">
              <button
                className={`av-input-action-btn${sttStatus === 'listening' ? ' av-input-action-btn--recording' : ''}${sttStatus === 'done' ? ' av-input-action-btn--success' : ''}`}
                onClick={handleSttReply}
                disabled={sttStatus === 'unsupported' || sttStatus === 'processing' || stage === 'drafting'}
                title="Dictate reply"
              >
                {sttMicLabel(false)}
              </button>
              {replyCtx && (
                <button
                  className="av-input-action-btn"
                  onClick={() => setReplyCtx('')}
                >
                  <RotateCcw size={11} /> Clear
                </button>
              )}
            </div>

            {sttStatus === 'listening' && (
              <div className="av-stt-interim">
                <Radio size={10} className="av-pulse" style={{ color: '#f87171', flexShrink: 0 }} />
                <span>{sttInterim || 'Speak your reply…'}</span>
              </div>
            )}

            <textarea
              className="av-textarea av-textarea--short"
              value={replyCtx}
              onChange={e => setReplyCtx(e.target.value.slice(0, 500))}
              placeholder="E.g. 'I agree but would like to move the date to June 20th.' Or press Dictate."
              rows={3}
              disabled={stage === 'drafting'}
            />

            <div className="av-action-row">
              <button className="av-btn av-btn--ghost" onClick={() => setStage('read-done')}>
                ← Back
              </button>
              <button
                className="av-btn av-btn--generate"
                onClick={handleGenerateDraft}
                disabled={stage === 'drafting'}
              >
                {stage === 'drafting'
                  ? <><span className="av-spinner" /> Generating…</>
                  : <><Sparkles size={13} /> Generate Reply</>
                }
              </button>
            </div>
            {draftError && (
              <div className="av-done-note" style={{ color: '#f87171' }}>
                <AlertCircle size={11} style={{ color: '#f87171' }} />
                {draftError}
              </div>
            )}
          </div>
        )}

        {/* ── STAGE: draft-done ── */}
        {stage === 'draft-done' && (
          <div className="av-section">
            <div className="av-section__header">
              <Sparkles size={14} style={{ color: '#fbbf24' }} />
              <span className="av-section__title">Generated Reply</span>
              <span className="av-section__badge">
                {TONE_LABELS[replyTone]} · {LANG_LABELS[replyLang]}
              </span>
            </div>

            <div className="av-draft-box">
              <pre className="av-draft-text">{draft}</pre>
            </div>

            <div className="av-action-row av-action-row--wrap">
              <button className="av-btn av-btn--play" onClick={handleReadDraft} disabled={speaking}>
                <Volume2 size={13} /> Read Aloud
              </button>
              <button className="av-btn av-btn--copy" onClick={handleCopyDraft}>
                {copied
                  ? <><CheckCircle2 size={13} /> Copied</>
                  : <><Copy size={13} /> Copy</>
                }
              </button>
              <button className="av-btn av-btn--ghost" onClick={() => setStage('reply-prompt')}>
                <RotateCcw size={12} /> Adjust
              </button>
              <button className="av-btn av-btn--ghost" onClick={handleReset}>
                <FileText size={12} /> New Message
              </button>
            </div>

            <div className="av-disclaimer">
              <AlertCircle size={10} style={{ color: '#475569', flexShrink: 0 }} />
              This is an AI-generated draft. Always review the content before sending.
            </div>
          </div>
        )}

        {/* Quick-use suggestions */}
        {stage === 'input' && !inputText && (
          <div className="av-suggestions">
            <div className="av-suggestions__label">
              <Mic size={11} /> Sample Messages
            </div>
            {[
              'Dear tenant, this confirms receipt of your outstanding rent arrears of €850. We kindly request that you settle this amount within 14 days.',
              'Dear customer, your invoice #2024-0089 is now overdue. Please arrange payment within 5 business days to avoid late fees.',
              'Estimado propietario, me pongo en contacto para informarle de que la caldera de la vivienda presenta un fallo técnico que requiere reparación urgente.',
            ].map((s, i) => (
              <button
                key={i}
                className="av-suggestion-btn"
                onClick={() => { setInputText(s); setCharCount(s.length); }}
              >
                <ChevronRight size={10} style={{ color: '#38bdf8', flexShrink: 0 }} />
                <span>{s.slice(0, 80)}…</span>
              </button>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
