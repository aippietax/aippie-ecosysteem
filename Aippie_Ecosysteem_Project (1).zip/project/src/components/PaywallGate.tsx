/**
 * PaywallGate — universal subscription gate for premium AippieOS modules.
 *
 * Reads `user_subscriptions.status` for the current authenticated user from
 * Supabase. If the status is anything other than 'active', rendering of the
 * wrapped view is interrupted and the viewport is redirected to the
 * AippieOnboardingView so the user can subscribe.
 *
 * Zero-bypass protection: every premium export in the SPA is wrapped by this
 * single component, so there is no code path that reaches a paid view without
 * an active subscription row in the database.
 *
 * Dev / lifetime accounts are always admitted so the platform team can reach
 * every module without friction.
 */
import { ReactNode, useEffect, useRef, useState } from 'react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import AippieOnboardingView from './AippieOnboardingView';

const DEV_EMAILS = ['elvin@aippietax.com', 'aippieai@gmail.com'];

type GateState = 'checking' | 'active' | 'blocked';

interface PaywallGateProps {
  /** Optional name of the gated module — surfaced in telemetry. */
  module?: string;
  children: ReactNode;
}

export default function PaywallGate({ module, children }: PaywallGateProps) {
  const { user } = useAuth();
  const [state, setState] = useState<GateState>('checking');
  const mountedRef = useRef(true);

  useEffect(() => {
    mountedRef.current = true;

    (async () => {
      if (!user) {
        if (mountedRef.current) setState('blocked');
        return;
      }

      const meta = user.user_metadata as Record<string, unknown> | undefined;
      const isDev =
        DEV_EMAILS.includes(user.email ?? '') ||
        meta?.is_subscribed === true ||
        meta?.subscription_type === 'lifetime' ||
        meta?.subscription_type === 'annual';
      if (isDev) {
        if (mountedRef.current) setState('active');
        return;
      }

      const { data, error } = await supabase
        .from('user_subscriptions')
        .select('status')
        .eq('user_id', user.id)
        .maybeSingle();

      if (!mountedRef.current) return;

      if (error) {
        setState('blocked');
        return;
      }

      if (data?.status === 'active') {
        setState('active');
      } else {
        supabase
          .from('user_subscriptions')
          .update({ updated_at: new Date().toISOString() })
          .eq('user_id', user.id)
          .then(() => {}, () => {});
        setState('blocked');
      }
    })();

    return () => {
      mountedRef.current = false;
    };
  }, [user, module]);

  if (state === 'active') return <>{children}</>;
  if (state === 'blocked') return <AippieOnboardingView module={module} />;

  return (
    <div className="pw-gate-loading">
      <div className="pw-gate-loading__spinner" />
      <span className="pw-gate-loading__label">Verifying subscription…</span>
    </div>
  );
}
