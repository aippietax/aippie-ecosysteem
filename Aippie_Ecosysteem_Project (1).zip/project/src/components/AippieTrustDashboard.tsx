import { useEffect, useState } from 'react';
import {
  ShieldCheck, Copy, CheckCheck, Phone, FileText,
  Globe, Lock, Hash, ChevronRight, Building2,
  AlertTriangle, Star, Zap, CheckCircle, Download,
  User as UserIcon, MapPin, ReceiptText, PlusCircle,
  CreditCard, Smartphone, X as XIcon,
} from 'lucide-react';
import type { User } from '@supabase/supabase-js';
import { supabase } from '../lib/supabase';
import SepaPaymentBlock from './SepaPaymentBlock';

interface Props {
  user?: User | null;
}

interface InvoiceSummary {
  total: number;
  totalAmount: number;
  pending: number;
  paid: number;
  certified: number;
}

function generateAPTId(trustName: string): string {
  const namePart = trustName
    .toUpperCase()
    .replace(/[^A-Z0-9]/g, '')
    .slice(0, 6)
    .padEnd(6, 'X');
  const ts = Date.now().toString().slice(-5);
  return `APT-2026-${namePart}-${ts}`;
}

function copyToClipboard(text: string, setCopied: (v: boolean) => void) {
  navigator.clipboard.writeText(text).then(() => {
    setCopied(true);
    setTimeout(() => setCopied(false), 1800);
  });
}

const TAX_NOTE =
  'Operación exenta de IVA — Directive 2006/112/CE art. 44 (B2B intracomunitario). ' +
  'VAT 0% aplicable · Base imponible sujeta a inversión del sujeto pasivo en destino. ' +
  'NIF-IVA del prestador: ESA22944987 · AIPPIETAX S.A. · Mijas, Málaga, España.';

const COUNTRIES = [
  'Spain', 'Netherlands', 'Germany', 'France', 'Belgium', 'Portugal',
  'Italy', 'United Kingdom', 'United States', 'Mexico', 'Colombia',
  'Argentina', 'Other',
];

// ── Registration screen ───────────────────────────────────────────────────────
function RegistrationScreen({
  onActivate,
}: {
  onActivate: (name: string, phone: string, aptId: string, fullName: string, country: string, vat: string) => void;
}) {
  const [trustName, setTrustName] = useState('');
  const [phone, setPhone] = useState('');
  const [fullName, setFullName] = useState('');
  const [country, setCountry] = useState('');
  const [vat, setVat] = useState('');
  const [agreed, setAgreed] = useState(false);
  const [error, setError] = useState('');

  function handleSubmit() {
    if (!fullName.trim()) { setError('Full Legal Name is required.'); return; }
    if (!country) { setError('Please select your Country.'); return; }
    if (!trustName.trim()) { setError('Please enter a Trust name to continue.'); return; }
    if (!agreed) { setError('You must confirm the administrative-only disclaimer.'); return; }
    const aptId = generateAPTId(trustName.trim());
    onActivate(trustName.trim(), phone.trim(), aptId, fullName.trim(), country, vat.trim());
  }

  return (
    <div style={{
      minHeight: '100vh', background: 'linear-gradient(160deg, #020d0a 0%, #041a12 40%, #061f17 100%)',
      fontFamily: "'Inter', -apple-system, sans-serif",
      color: '#e2e8f0', display: 'flex', flexDirection: 'column',
      alignItems: 'center', justifyContent: 'center', padding: '32px 20px',
    }}>
      <style>{`
        .trust-input {
          width: 100%; background: rgba(0,0,0,0.45);
          border: 1px solid rgba(16,185,129,0.25); border-radius: 10px;
          padding: 13px 16px; color: #e2e8f0; font-size: 15px; outline: none;
          box-sizing: border-box; transition: border-color 0.2s;
        }
        .trust-input:focus { border-color: rgba(16,185,129,0.65); }
        .trust-input::placeholder { color: #334155; }
        .trust-select {
          width: 100%; background: rgba(0,0,0,0.45);
          border: 1px solid rgba(16,185,129,0.25); border-radius: 10px;
          padding: 13px 16px; color: #e2e8f0; font-size: 15px; outline: none;
          box-sizing: border-box; appearance: none; cursor: pointer;
        }
        .trust-select:focus { border-color: rgba(16,185,129,0.65); }
      `}</style>

      <div style={{
        width: 64, height: 64, borderRadius: 18,
        background: 'linear-gradient(135deg, #065f46 0%, #10b981 100%)',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        boxShadow: '0 0 32px rgba(16,185,129,0.4)', marginBottom: 24,
      }}>
        <ShieldCheck size={30} color="#fff" strokeWidth={2} />
      </div>

      <h1 style={{ margin: '0 0 6px', fontSize: 22, fontWeight: 800, color: '#f0fdf4', textAlign: 'center' }}>
        Activate Your Digital Trust Fund
      </h1>
      <p style={{ margin: '0 0 32px', fontSize: 13, color: '#475569', textAlign: 'center', maxWidth: 360 }}>
        Register your enterprise trust entity. You will receive a unique Cryptographic Cloud Registry ID instantly.
      </p>

      <div style={{ width: '100%', maxWidth: 420, display: 'flex', flexDirection: 'column', gap: 16 }}>

        {/* REQUIRED — Full Legal Name */}
        <div>
          <label style={{ display: 'block', fontSize: 12, color: '#10b981', fontWeight: 600, marginBottom: 7, letterSpacing: '0.06em', textTransform: 'uppercase' }}>
            Full Legal Name <span style={{ color: '#f87171' }}>*</span>
          </label>
          <input
            className="trust-input"
            placeholder="e.g. John Andrew Smith"
            value={fullName}
            onChange={e => { setFullName(e.target.value); setError(''); }}
          />
        </div>

        {/* REQUIRED — Country */}
        <div>
          <label style={{ display: 'block', fontSize: 12, color: '#10b981', fontWeight: 600, marginBottom: 7, letterSpacing: '0.06em', textTransform: 'uppercase' }}>
            Country <span style={{ color: '#f87171' }}>*</span>
          </label>
          <select
            className="trust-select"
            value={country}
            onChange={e => { setCountry(e.target.value); setError(''); }}
          >
            <option value="">Select your country...</option>
            {COUNTRIES.map(c => <option key={c} value={c}>{c}</option>)}
          </select>
        </div>

        {/* OPTIONAL — Company / VAT */}
        <div>
          <label style={{ display: 'block', fontSize: 12, color: '#94A3B8', fontWeight: 600, marginBottom: 7, letterSpacing: '0.06em', textTransform: 'uppercase' }}>
            Company / VAT Number <span style={{ color: '#475569', fontSize: 10 }}>(Optional)</span>
          </label>
          <input
            className="trust-input"
            placeholder="e.g. ES B12345678"
            value={vat}
            onChange={e => setVat(e.target.value)}
          />
        </div>

        {/* DIVIDER */}
        <div style={{ height: 1, background: 'rgba(16,185,129,0.1)', margin: '4px 0' }} />

        {/* Trust Name */}
        <div>
          <label style={{ display: 'block', fontSize: 12, color: '#10b981', fontWeight: 600, marginBottom: 7, letterSpacing: '0.06em', textTransform: 'uppercase' }}>
            Choose Your Trust Name <span style={{ color: '#f87171' }}>*</span>
          </label>
          <input
            className="trust-input"
            placeholder="e.g. Vanguard Digital Trust S.L."
            value={trustName}
            onChange={e => { setTrustName(e.target.value); setError(''); }}
          />
        </div>

        {/* Phone (optional) */}
        <div>
          <label style={{ display: 'block', fontSize: 12, color: '#94A3B8', fontWeight: 600, marginBottom: 7, letterSpacing: '0.06em', textTransform: 'uppercase' }}>
            Link Phone Number <span style={{ color: '#475569', fontSize: 10 }}>(Optional)</span>
          </label>
          <input
            className="trust-input"
            placeholder="+34 600 000 000"
            value={phone}
            onChange={e => setPhone(e.target.value)}
            type="tel"
          />
        </div>

        {/* Legal checkbox */}
        <label style={{
          display: 'flex', alignItems: 'flex-start', gap: 10, cursor: 'pointer',
          background: agreed ? 'rgba(16,185,129,0.05)' : 'rgba(251,191,36,0.04)',
          border: `1px solid ${agreed ? 'rgba(16,185,129,0.25)' : 'rgba(251,191,36,0.2)'}`,
          borderRadius: 10, padding: '12px 14px',
        }}>
          <input
            type="checkbox"
            checked={agreed}
            onChange={e => { setAgreed(e.target.checked); setError(''); }}
            style={{ marginTop: 2, accentColor: '#10b981', flexShrink: 0, width: 16, height: 16 }}
          />
          <span style={{ fontSize: 12, color: '#94A3B8', lineHeight: 1.6 }}>
            I confirm this is for <strong style={{ color: '#e2e8f0' }}>administrative purposes only</strong>. Not a bank account. Not a financial product.
          </span>
        </label>

        {error && (
          <div style={{
            background: 'rgba(239,68,68,0.08)', border: '1px solid rgba(239,68,68,0.25)',
            borderRadius: 8, padding: '10px 14px', fontSize: 12, color: '#fca5a5',
          }}>
            {error}
          </div>
        )}

        <button
          onClick={handleSubmit}
          style={{
            display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
            background: 'linear-gradient(135deg, #065f46, #10b981)',
            border: 'none', borderRadius: 12, color: '#fff',
            fontSize: 15, fontWeight: 700, padding: '14px 24px', cursor: 'pointer',
            marginTop: 4, boxShadow: '0 0 24px rgba(16,185,129,0.3)',
            transition: 'opacity 0.15s',
          }}
        >
          <Zap size={16} />
          Activate My Digital Trust
        </button>

        <p style={{ margin: 0, fontSize: 10, color: '#1e3a2f', textAlign: 'center', lineHeight: 1.6 }}>
          AIPPIETAX S.A. · NIF A22944987 · Mijas, Málaga · Administrative ledger only — no funds held
        </p>
      </div>
    </div>
  );
}

// ── Confirmation screen ───────────────────────────────────────────────────────
function ConfirmationScreen({
  trustName, phone, aptId, fullName, country,
  onContinue,
}: {
  trustName: string; phone: string; aptId: string;
  fullName: string; country: string;
  onContinue: () => void;
}) {
  const [copiedId, setCopiedId] = useState(false);
  const [showWelcome, setShowWelcome] = useState(true);
  const [videoUrl, setVideoUrl] = useState<string | null>(null);

  useEffect(() => {
    const seen = localStorage.getItem(`trust_welcome_seen_${aptId}`);
    if (seen) setShowWelcome(false);
  }, [aptId]);

  useEffect(() => {
    if (!showWelcome) return;
    supabase.functions.invoke('generate-avatar-speech', {
      body: { action: 'video', video_id: '0f1f7a2439324bafa5a1d85dd7bcf9eb' }
    }).then(({ data }) => {
      if (data?.url) setVideoUrl(data.url);
    }).catch(console.error);
  }, [showWelcome]);

  // eslint-disable-next-line react-hooks/exhaustive-deps
  useEffect(() => {
    supabase.functions.invoke('send-trust-certificate', {
      body: { trustName, aptId, activationDate: new Date().toLocaleDateString() }
    }).catch(console.error);
  }, []);

  return (
    <>
      {showWelcome && (
        <div style={{ position: 'fixed', inset: 0, zIndex: 99999, background: '#030508', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center' }}>
          {videoUrl ? (
            <video
              src={videoUrl}
              autoPlay
              playsInline
              style={{ width: '100%', height: '100%', objectFit: 'cover' }}
              onEnded={() => { localStorage.setItem(`trust_welcome_seen_${aptId}`, 'true'); setShowWelcome(false); }}
            />
          ) : (
            <div style={{ color: '#10b981', fontSize: 14, fontFamily: "'Inter', sans-serif" }}>
              Loading your welcome...
            </div>
          )}
          <button
            onClick={() => { localStorage.setItem(`trust_welcome_seen_${aptId}`, 'true'); setShowWelcome(false); }}
            style={{ position: 'absolute', top: 20, right: 20, background: 'rgba(255,255,255,0.1)', border: '1px solid rgba(255,255,255,0.2)', borderRadius: 8, color: '#fff', padding: '8px 16px', cursor: 'pointer', fontSize: 13, fontWeight: 600 }}
          >
            Skip →
          </button>
        </div>
      )}
      <div style={{
        minHeight: '100vh', background: 'linear-gradient(160deg, #020d0a 0%, #041a12 40%, #061f17 100%)',
      fontFamily: "'Inter', -apple-system, sans-serif",
      color: '#e2e8f0', display: 'flex', flexDirection: 'column',
      alignItems: 'center', justifyContent: 'center', padding: '32px 20px',
    }}>
      <style>{`
        @keyframes confirm-pop {
          0% { transform: scale(0.6); opacity: 0; }
          70% { transform: scale(1.08); }
          100% { transform: scale(1); opacity: 1; }
        }
      `}</style>

      <div style={{
        width: 72, height: 72, borderRadius: '50%',
        background: 'linear-gradient(135deg, #065f46, #10b981)',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        boxShadow: '0 0 48px rgba(16,185,129,0.5)', marginBottom: 20,
        animation: 'confirm-pop 0.5s cubic-bezier(.34,1.56,.64,1) both',
      }}>
        <CheckCircle size={36} color="#fff" strokeWidth={2.2} />
      </div>

      <h1 style={{ margin: '0 0 6px', fontSize: 22, fontWeight: 800, color: '#4ade80', textAlign: 'center' }}>
        Trust Activated
      </h1>
      <p style={{ margin: '0 0 28px', fontSize: 13, color: '#475569', textAlign: 'center' }}>
        Your Digital Trust Fund is now registered and active.
      </p>

      <div style={{
        width: '100%', maxWidth: 420,
        background: 'rgba(16,185,129,0.06)', border: '1px solid rgba(16,185,129,0.25)',
        borderRadius: 16, padding: 24, marginBottom: 20,
      }}>
        <div style={{ fontSize: 10, color: '#334155', letterSpacing: '0.1em', textTransform: 'uppercase', marginBottom: 16 }}>
          Trust Profile
        </div>

        {[
          { label: 'Legal Name', value: fullName, icon: <UserIcon size={13} color="#10b981" /> },
          { label: 'Country', value: country, icon: <MapPin size={13} color="#10b981" /> },
          { label: 'Trust Name', value: trustName, icon: <Building2 size={13} color="#10b981" /> },
          { label: 'Registry ID', value: aptId, icon: <Hash size={13} color="#10b981" />, mono: true, copyable: true },
          ...(phone ? [{ label: 'Phone Node', value: phone, icon: <Phone size={13} color="#10b981" /> }] : []),
          { label: 'Status', value: 'ACTIVE', icon: <CheckCircle size={13} color="#10b981" /> },
          { label: 'Compliance', value: 'Verifactu B2B · 0% VAT · Directive 2006/112/CE', icon: <Globe size={13} color="#10b981" /> },
        ].map((item) => (
          <div key={item.label} style={{
            display: 'flex', alignItems: 'flex-start', gap: 10,
            padding: '10px 0', borderBottom: '1px solid rgba(255,255,255,0.05)',
          }}>
            <div style={{ flexShrink: 0, marginTop: 1 }}>{item.icon}</div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ fontSize: 10, color: '#334155', letterSpacing: '0.06em', textTransform: 'uppercase', marginBottom: 2 }}>
                {item.label}
              </div>
              <div style={{
                fontSize: 13, color: item.label === 'Status' ? '#4ade80' : '#e2e8f0',
                fontWeight: item.mono ? 700 : 500,
                fontFamily: item.mono ? 'monospace' : 'inherit',
                letterSpacing: item.mono ? '0.06em' : 0,
                wordBreak: 'break-all',
              }}>
                {item.value}
              </div>
            </div>
            {'copyable' in item && item.copyable && (
              <button
                onClick={() => copyToClipboard(aptId, setCopiedId)}
                style={{
                  flexShrink: 0, background: 'rgba(16,185,129,0.1)',
                  border: '1px solid rgba(16,185,129,0.25)', borderRadius: 6,
                  color: '#10b981', cursor: 'pointer', padding: '4px 8px',
                  display: 'flex', alignItems: 'center', gap: 4, fontSize: 10,
                }}
              >
                {copiedId ? <CheckCheck size={11} /> : <Copy size={11} />}
                {copiedId ? 'Copied' : 'Copy'}
              </button>
            )}
          </div>
        ))}
      </div>

      <button
        onClick={onContinue}
        style={{
          display: 'flex', alignItems: 'center', gap: 8,
          background: 'linear-gradient(135deg, #065f46, #10b981)',
          border: 'none', borderRadius: 12, color: '#fff',
          fontSize: 14, fontWeight: 700, padding: '13px 28px', cursor: 'pointer',
          boxShadow: '0 0 20px rgba(16,185,129,0.25)', transition: 'opacity 0.15s',
        }}
      >
        Open Trust Dashboard
        <ChevronRight size={15} />
      </button>
    </div>
    </>
  );
}

// ── Invoice row type ──────────────────────────────────────────────────────────
interface InvoiceRow {
  id: string;
  serie: string;
  numero: number;
  fecha_expedicion: string;
  importe_total: number;
  estado_envio: string;
  nombre_destinatario?: string;
}

// ── Main dashboard (post-registration) ───────────────────────────────────────
function TrustDashboard({
  trustName, phone, aptId, fullName, country, user,
}: {
  trustName: string; phone: string; aptId: string;
  fullName: string; country: string; user?: User | null;
}) {
  const [copiedId, setCopiedId] = useState(false);
  const [copiedTax, setCopiedTax] = useState(false);
  const [summary, setSummary] = useState<InvoiceSummary | null>(null);
  const [invoices, setInvoices] = useState<InvoiceRow[]>([]);
  const [showCardModal, setShowCardModal] = useState(false);

  useEffect(() => {
    if (!user?.id) return;
    supabase
      .from('verifactu_invoices')
      .select('id, serie, numero, fecha_expedicion, importe_total, estado_envio, nombre_destinatario')
      .eq('user_id', user.id)
      .order('fecha_expedicion', { ascending: false })
      .limit(20)
      .then(({ data }) => {
        const rows = (data ?? []) as InvoiceRow[];
        setInvoices(rows);
        const total = rows.length;
        const totalAmount = rows.reduce((s, r) => s + (r.importe_total || 0), 0);
        const pending = rows.filter(r => r.estado_envio === 'pendiente' || !r.estado_envio).length;
        const paid = rows.filter(r => r.estado_envio === 'aceptada').length;
        const certified = rows.filter(r => r.estado_envio === 'registrada').length;
        setSummary({ total, totalAmount, pending, paid, certified });
      });
  }, [user?.id]);

  const fmt = (n: number) =>
    new Intl.NumberFormat('es-ES', { style: 'currency', currency: 'EUR' }).format(n);

  const statusColor = (s?: string) => {
    if (s === 'aceptada') return '#4ade80';
    if (s === 'registrada') return '#38bdf8';
    return '#fbbf24';
  };

  const statusLabel = (s?: string) => {
    if (s === 'aceptada') return 'Paid';
    if (s === 'registrada') return 'Certified';
    return 'Pending';
  };

  return (
    <div style={{
      minHeight: '100vh', background: 'linear-gradient(160deg, #020d0a 0%, #041a12 40%, #061f17 100%)',
      fontFamily: "'Inter', -apple-system, sans-serif",
      color: '#e2e8f0', padding: '24px 16px 80px',
    }}>
      <style>{`
        .trust-card { background: rgba(16,185,129,0.05); border: 1px solid rgba(16,185,129,0.18); border-radius: 14px; padding: 20px; margin-bottom: 16px; }
        .trust-card--dark { background: rgba(0,0,0,0.35); border: 1px solid rgba(255,255,255,0.07); }
        .trust-stat { display: flex; flex-direction: column; align-items: center; background: rgba(0,0,0,0.3); border: 1px solid rgba(255,255,255,0.06); border-radius: 10px; padding: 14px 10px; }
        .trust-badge-pill { display: inline-flex; align-items: center; gap: 5px; background: #10b981; border-radius: 20px; padding: 4px 10px; font-size: 12px; font-weight: 700; color: #fff; letter-spacing: 0.06em; text-transform: uppercase; }
        .trust-copy-btn { display: flex; align-items: center; gap: 5px; background: rgba(16,185,129,0.08); border: 1px solid rgba(16,185,129,0.22); border-radius: 7px; padding: 6px 10px; color: #10b981; font-size: 11px; cursor: pointer; }
        .inv-row { display: grid; grid-template-columns: 1fr 1fr auto auto; gap: 8px; align-items: center; padding: 10px 14px; border-bottom: 1px solid rgba(255,255,255,0.05); font-size: 12px; }
        .inv-row:last-child { border-bottom: none; }
      `}</style>

      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'flex-start', gap: 14, marginBottom: 28 }}>
        <div style={{
          width: 48, height: 48, borderRadius: 14, flexShrink: 0,
          background: 'linear-gradient(135deg, #065f46 0%, #10b981 100%)',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          boxShadow: '0 0 24px rgba(16,185,129,0.35)',
        }}>
          <ShieldCheck size={24} color="#fff" strokeWidth={2} />
        </div>
        <div style={{ flex: 1 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, flexWrap: 'wrap' }}>
            <h1 style={{ margin: 0, fontSize: 18, fontWeight: 800, color: '#f0fdf4' }}>
              Digital Trust Dashboard
            </h1>
            <span className="trust-badge-pill"><Star size={9} />Enterprise</span>
          </div>
          <div style={{ color: '#4ade80', fontSize: 11, marginTop: 3, fontWeight: 600, letterSpacing: '0.04em' }}>
            {trustName}
          </div>
          <div style={{ color: '#1e3a2f', fontSize: 9, marginTop: 2, letterSpacing: '0.08em', textTransform: 'uppercase' }}>
            {fullName} · {country} · AIPPIETAX S.A. · NIF A22944987
          </div>
        </div>
      </div>

      {/* Registry ID */}
      <div className="trust-card">
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 12 }}>
          <Hash size={15} color="#10b981" />
          <span style={{ fontSize: 11, fontWeight: 700, color: '#10b981', letterSpacing: '0.1em', textTransform: 'uppercase' }}>
            Cryptographic Cloud Registry ID
          </span>
        </div>
        <div style={{
          display: 'flex', alignItems: 'center', gap: 10,
          background: 'rgba(0,0,0,0.5)', border: '1px solid rgba(16,185,129,0.3)',
          borderRadius: 10, padding: '12px 16px',
        }}>
          <Lock size={13} color="#10b981" />
          <code style={{ flex: 1, fontSize: 15, fontWeight: 800, color: '#4ade80', letterSpacing: '0.1em', wordBreak: 'break-all' }}>
            {aptId}
          </code>
          <button className="trust-copy-btn" onClick={() => copyToClipboard(aptId, setCopiedId)}>
            {copiedId ? <CheckCheck size={12} /> : <Copy size={12} />}
            {copiedId ? 'Copied' : 'Copy'}
          </button>
        </div>
      </div>

      {/* Phone node */}
      {phone && (
        <div className="trust-card trust-card--dark">
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 10 }}>
            <Phone size={15} color="#10b981" />
            <span style={{ fontSize: 11, fontWeight: 700, color: '#10b981', letterSpacing: '0.1em', textTransform: 'uppercase' }}>
              Phone-Linked Bookkeeping Node
            </span>
          </div>
          <div style={{ fontSize: 14, color: '#4ade80', fontWeight: 600 }}>{phone}</div>
          <p style={{ margin: '6px 0 0', fontSize: 11, color: '#334155', lineHeight: 1.5 }}>
            External banking webhook synchronisation via Banco Sabadell API infrastructure.
          </p>
        </div>
      )}

      {/* ── Invoice Tracking ── */}
      <div className="trust-card">
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 14 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <FileText size={14} color="#F59E0B" />
            <span style={{ fontSize: 11, fontWeight: 700, color: '#ffffff', letterSpacing: '0.06em', textTransform: 'uppercase' }}>
              Verifactu Invoice Ledger Realtime Data
            </span>
          </div>
          <button
            onClick={() => alert('Navigate to Verifactu module to create a new invoice.')}
            style={{
              display: 'flex', alignItems: 'center', gap: 5,
              background: 'rgba(245,158,11,0.08)', border: '1px solid rgba(245,158,11,0.4)',
              borderRadius: 7, padding: '5px 10px', color: '#F59E0B', fontSize: 11, cursor: 'pointer', fontWeight: 600,
            }}
          >
            + New Invoice ↗
          </button>
        </div>

        {/* Stats */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 10, marginBottom: 16 }}>
          {[
            { label: 'Total Invoices', value: summary?.total ?? '—', color: '#4ade80' },
            { label: 'Total Amount', value: summary ? fmt(summary.totalAmount) : '—', color: '#38bdf8', small: true },
            { label: 'Pending', value: summary?.pending ?? '—', color: '#fbbf24' },
          ].map(s => (
            <div key={s.label} className="trust-stat">
              <span style={{ fontSize: s.small ? 13 : 22, fontWeight: 800, color: s.color, wordBreak: 'break-word', textAlign: 'center' }}>
                {String(s.value)}
              </span>
              <span style={{ fontSize: 9, color: '#334155', marginTop: 2, letterSpacing: '0.06em', textTransform: 'uppercase', textAlign: 'center' }}>
                {s.label}
              </span>
            </div>
          ))}
        </div>

        {/* Status grid */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 8, marginBottom: 16 }}>
          {[
            { label: 'Pending', value: summary?.pending ?? 0, color: '#fbbf24' },
            { label: 'Paid', value: summary?.paid ?? 0, color: '#4ade80' },
            { label: 'Certified', value: summary?.certified ?? 0, color: '#38bdf8' },
          ].map(s => (
            <div key={s.label} style={{
              background: 'rgba(0,0,0,0.3)', border: `1px solid ${s.color}30`,
              borderRadius: 8, padding: '10px 8px', textAlign: 'center',
            }}>
              <div style={{ fontSize: 18, fontWeight: 800, color: s.color }}>{s.value}</div>
              <div style={{ fontSize: 9, color: '#475569', marginTop: 2, textTransform: 'uppercase', letterSpacing: '0.06em' }}>{s.label}</div>
            </div>
          ))}
        </div>

        {/* Invoice list */}
        {invoices.length > 0 ? (
          <div style={{ background: 'rgba(0,0,0,0.3)', borderRadius: 10, overflow: 'hidden' }}>
            <div style={{ padding: '8px 14px', background: 'rgba(255,255,255,0.03)', borderBottom: '1px solid rgba(255,255,255,0.06)' }}>
              <div style={{ display: 'grid', gridTemplateColumns: '90px 90px 1fr auto auto', gap: 8, fontSize: 9, color: '#334155', textTransform: 'uppercase', letterSpacing: '0.06em' }}>
                <span>Timestamp</span><span>Ref ID</span><span>Company</span><span>Amount</span><span>Status</span>
              </div>
            </div>
            {invoices.map(inv => (
              <div key={inv.id} className="inv-row" style={{ display: 'grid', gridTemplateColumns: '90px 90px 1fr auto auto', gap: 8, alignItems: 'center', padding: '9px 14px', borderBottom: '1px solid rgba(255,255,255,0.04)' }}>
                <span style={{ color: '#475569', fontSize: 10 }}>{inv.fecha_expedicion?.slice(0, 10)}</span>
                <span style={{ color: '#38bdf8', fontWeight: 700, fontSize: 10, fontFamily: 'monospace' }}>AIPP-{inv.id.slice(0, 6)}</span>
                <span style={{ color: '#e2e8f0', fontWeight: 600, fontSize: 11, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                  {inv.nombre_destinatario || `${inv.serie}-${inv.numero}`}
                </span>
                <span style={{ color: '#4ade80', fontWeight: 700, fontSize: 11, whiteSpace: 'nowrap' }}>{fmt(inv.importe_total)}</span>
                <span style={{
                  fontSize: 10, fontWeight: 700,
                  color: (inv.estado_envio === 'paid_certified' || inv.estado_envio === 'aceptada') ? '#10b981' : '#F59E0B',
                  background: (inv.estado_envio === 'paid_certified' || inv.estado_envio === 'aceptada') ? 'rgba(16,185,129,0.12)' : 'rgba(245,158,11,0.12)',
                  border: `1px solid ${(inv.estado_envio === 'paid_certified' || inv.estado_envio === 'aceptada') ? 'rgba(16,185,129,0.3)' : 'rgba(245,158,11,0.3)'}`,
                  borderRadius: 20, padding: '2px 8px', whiteSpace: 'nowrap', display: 'flex', alignItems: 'center', gap: 4,
                }}>
                  {(inv.estado_envio === 'paid_certified' || inv.estado_envio === 'aceptada') ? '✓ Certified' : statusLabel(inv.estado_envio)}
                </span>
              </div>
            ))}
          </div>
        ) : (
          <div style={{ textAlign: 'center', padding: '20px 0', color: '#334155', fontSize: 12 }}>
            <ReceiptText size={28} color="#1e3a2f" style={{ marginBottom: 8 }} />
            <div>No invoices found for this account.</div>
            <div style={{ fontSize: 10, marginTop: 4 }}>Issue your first invoice via VERI*FACTU to see data here.</div>
          </div>
        )}

        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginTop: 12 }}>
          <span style={{ fontSize: 10, color: '#475569' }}>
            {invoices.length} invoice{invoices.length !== 1 ? 's' : ''} · {aptId}
          </span>
          <button
            onClick={() => alert('ZIP download requires a server endpoint. Contact support.')}
            style={{
              display: 'flex', alignItems: 'center', gap: 5,
              background: 'rgba(0,0,0,0.4)', border: '1px solid rgba(255,255,255,0.1)',
              borderRadius: 7, padding: '5px 10px', color: '#94a3b8', fontSize: 10, cursor: 'pointer',
            }}
          >
            <Download size={11} />
            Download ZIP ↗
          </button>
        </div>
      </div>

      {/* ── Linked Bank Wallet ── */}
      <div className="trust-card trust-card--dark" style={{ background: 'linear-gradient(160deg, #0d1b2a 0%, #0a1628 100%)', border: '1px solid rgba(16,185,129,0.25)' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 16 }}>
          <span style={{ fontSize: 11, fontWeight: 700, color: '#10b981', letterSpacing: '0.1em', textTransform: 'uppercase' }}>
            Linked Bank Wallet
          </span>
        </div>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 16 }}>
          <div>
            <div style={{ fontSize: 18, fontWeight: 800, color: '#ffffff', letterSpacing: '0.02em' }}>Banco Sabadell</div>
            <div style={{ fontSize: 10, color: '#475569', marginTop: 3, textTransform: 'uppercase', letterSpacing: '0.08em' }}>Connected Bank · ES</div>
          </div>
          <div style={{ textAlign: 'right' }}>
            <div style={{ fontSize: 9, color: '#475569', textTransform: 'uppercase', letterSpacing: '0.08em', marginBottom: 4 }}>IBAN (masked)</div>
            <div style={{ fontSize: 12, fontWeight: 700, color: '#4ade80', fontFamily: 'monospace' }}>ES91 **** XXXX</div>
          </div>
        </div>
        <div style={{ marginBottom: 14 }}>
          <div style={{ fontSize: 9, color: '#475569', textTransform: 'uppercase', letterSpacing: '0.1em', marginBottom: 6 }}>Gross Balance</div>
          <div style={{ fontSize: 32, fontWeight: 900, color: '#10b981', letterSpacing: '-0.02em', lineHeight: 1 }}>
            € 14.250,00
          </div>
        </div>
        <div style={{ padding: '8px 12px', background: 'rgba(16,185,129,0.08)', border: '1px solid rgba(16,185,129,0.2)', borderRadius: 8, fontSize: 11, color: '#10b981', display: 'flex', alignItems: 'center', gap: 8 }}>
          <div style={{ width: 7, height: 7, borderRadius: '50%', background: '#10b981', boxShadow: '0 0 8px #10b981', flexShrink: 0 }} />
          Sabadell webhook active
        </div>
      </div>

      {/* ── AIPPIE Card Issuance Hub ── */}
      <div className="trust-card trust-card--dark">
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 16 }}>
          <CreditCard size={14} color="#C9A84C" />
          <span style={{ fontSize: 11, fontWeight: 700, color: '#C9A84C', letterSpacing: '0.1em', textTransform: 'uppercase' }}>
            AIPPIE Card Issuance Hub
          </span>
          <span style={{ marginLeft: 'auto', fontSize: 9, fontWeight: 700, color: '#10b981', background: 'rgba(16,185,129,0.12)', border: '1px solid rgba(16,185,129,0.25)', borderRadius: 20, padding: '2px 8px' }}>
            ACTIVE
          </span>
        </div>

        {/* Virtual card */}
        <div style={{
          background: 'linear-gradient(135deg, #0f2027 0%, #1a3a2a 50%, #0d1f13 100%)',
          border: '1px solid rgba(201,168,76,0.4)',
          borderRadius: 14, padding: '18px 20px', marginBottom: 14,
          boxShadow: '0 4px 24px rgba(201,168,76,0.15)',
          position: 'relative', overflow: 'hidden',
        }}>
          <div style={{ position: 'absolute', top: -30, right: -30, width: 100, height: 100, borderRadius: '50%', background: 'rgba(201,168,76,0.08)' }} />
          <div style={{ position: 'absolute', bottom: -20, left: -20, width: 80, height: 80, borderRadius: '50%', background: 'rgba(16,185,129,0.06)' }} />
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 20 }}>
            <span style={{ fontSize: 11, fontWeight: 800, color: '#C9A84C', letterSpacing: '0.15em', textTransform: 'uppercase' }}>
              AIPPIETAX S.A.
            </span>
            <div style={{ display: 'flex', gap: -4 }}>
              <div style={{ width: 22, height: 22, borderRadius: '50%', background: 'rgba(201,168,76,0.7)' }} />
              <div style={{ width: 22, height: 22, borderRadius: '50%', background: 'rgba(201,168,76,0.4)', marginLeft: -8 }} />
            </div>
          </div>
          <div style={{ fontSize: 15, fontWeight: 700, color: '#e2e8f0', letterSpacing: '0.2em', marginBottom: 16, fontFamily: 'monospace' }}>
            5412 **** **** 8890
          </div>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end' }}>
            <div>
              <div style={{ fontSize: 8, color: '#475569', textTransform: 'uppercase', letterSpacing: '0.08em' }}>Card Holder</div>
              <div style={{ fontSize: 11, color: '#94a3b8', fontWeight: 600 }}>DELTA TRUST</div>
            </div>
            <div style={{ textAlign: 'right' }}>
              <div style={{ fontSize: 8, color: '#475569', textTransform: 'uppercase', letterSpacing: '0.08em' }}>Valid Thru</div>
              <div style={{ fontSize: 11, color: '#94a3b8', fontWeight: 600 }}>12/31</div>
            </div>
          </div>
        </div>

        {/* Apple Pay / Google Pay */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8, marginBottom: 12 }}>
          <button style={{
            background: '#000', border: '1px solid rgba(255,255,255,0.15)', borderRadius: 8,
            padding: '9px 12px', color: '#fff', fontSize: 11, fontWeight: 600, cursor: 'pointer',
            display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6,
          }}>
            <Smartphone size={12} /> Apple Pay
          </button>
          <button style={{
            background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.12)', borderRadius: 8,
            padding: '9px 12px', color: '#e2e8f0', fontSize: 11, fontWeight: 600, cursor: 'pointer',
            display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6,
          }}>
            <Smartphone size={12} /> Google Pay
          </button>
        </div>

        {/* Physical Mastercard upsell */}
        <button
          onClick={() => setShowCardModal(true)}
          style={{
            width: '100%', background: 'linear-gradient(135deg, #C9A84C, #10b981)',
            border: 'none', borderRadius: 8, padding: '10px 16px', color: '#000',
            fontSize: 12, fontWeight: 700, cursor: 'pointer', letterSpacing: '0.04em',
            display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
          }}
        >
          <CreditCard size={13} /> Bestel Fysieke Premium Mastercard
        </button>
      </div>

      {/* Mastercard order modal */}
      {showCardModal && (
        <div style={{ position: 'fixed', inset: 0, zIndex: 99998, background: 'rgba(0,0,0,0.85)', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 16 }}>
          <div style={{ background: '#0d1f13', border: '1px solid rgba(201,168,76,0.3)', borderRadius: 16, padding: 24, maxWidth: 360, width: '100%', position: 'relative' }}>
            <button onClick={() => setShowCardModal(false)} style={{ position: 'absolute', top: 12, right: 12, background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 6, color: '#94a3b8', padding: '4px 8px', cursor: 'pointer' }}>
              <XIcon size={12} />
            </button>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 16 }}>
              <CreditCard size={18} color="#C9A84C" />
              <span style={{ fontSize: 14, fontWeight: 700, color: '#C9A84C' }}>Premium Mastercard</span>
            </div>
            <p style={{ margin: '0 0 16px', fontSize: 12, color: '#94a3b8', lineHeight: 1.6 }}>
              Ontvang uw gepersonaliseerde AIPPIETAX Mastercard op uw adres. Eenmalige setup fee van €9,99. Gratis leveringen binnen de EU.
            </p>
            <div style={{ background: 'rgba(201,168,76,0.08)', border: '1px solid rgba(201,168,76,0.2)', borderRadius: 8, padding: '10px 14px', marginBottom: 16, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <span style={{ fontSize: 12, color: '#e2e8f0' }}>Setup fee</span>
              <span style={{ fontSize: 16, fontWeight: 800, color: '#C9A84C' }}>€9,99</span>
            </div>
            <SepaPaymentBlock
              amount={9.99}
              accent="#C9A84C"
              paypalUrl="https://www.paypal.com/paypalme/aippietax/9.99"
              paypalLabel="Betaal via PayPal of Creditcard · €9,99"
            />
          </div>
        </div>
      )}

      {/* Verifactu compliance */}
      <div className="trust-card">
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 14 }}>
          <Globe size={15} color="#10b981" />
          <span style={{ fontSize: 11, fontWeight: 700, color: '#10b981', letterSpacing: '0.1em', textTransform: 'uppercase' }}>
            Verifactu B2B Compliance
          </span>
        </div>
        <div style={{
          background: 'rgba(0,0,0,0.45)', border: '1px solid rgba(16,185,129,0.2)',
          borderRadius: 10, padding: 14, marginBottom: 12,
        }}>
          <div style={{ fontSize: 9, color: '#334155', letterSpacing: '0.08em', textTransform: 'uppercase', marginBottom: 8 }}>
            Auto-appended tax disclaimer
          </div>
          <p style={{ margin: 0, fontSize: 11, color: '#4ade80', lineHeight: 1.7, fontStyle: 'italic' }}>
            "{TAX_NOTE}"
          </p>
        </div>
        <button className="trust-copy-btn" onClick={() => copyToClipboard(TAX_NOTE, setCopiedTax)}>
          {copiedTax ? <CheckCheck size={12} /> : <Copy size={12} />}
          {copiedTax ? 'Copied disclaimer' : 'Copy disclaimer text'}
        </button>
      </div>

      {/* Add Additional Trust */}
      <div className="trust-card trust-card--dark" style={{ marginBottom: 16 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 12 }}>
          <PlusCircle size={15} color="#10b981" />
          <span style={{ fontSize: 11, fontWeight: 700, color: '#10b981', letterSpacing: '0.1em', textTransform: 'uppercase' }}>
            Add Additional Trust Entity
          </span>
          <span style={{
            background: 'rgba(16,185,129,0.12)', border: '1px solid rgba(16,185,129,0.25)',
            borderRadius: 20, padding: '2px 10px', fontSize: 10, fontWeight: 700, color: '#4ade80',
          }}>€49 / entity</span>
        </div>
        <p style={{ margin: '0 0 14px', fontSize: 12, color: '#475569', lineHeight: 1.5 }}>
          Register an additional trust entity under your account. Each entity gets its own unique APT Registry ID.
        </p>
        <SepaPaymentBlock
          amount={49}
          accent="#10b981"
          paypalUrl="https://www.paypal.com/paypalme/aippietax/49"
          paypalLabel="Betaal via PayPal of Creditcard · €49"
        />
      </div>

      {/* Disclaimer */}
      <div style={{
        display: 'flex', alignItems: 'flex-start', gap: 10,
        background: 'rgba(251,191,36,0.05)', border: '1px solid rgba(251,191,36,0.15)',
        borderRadius: 12, padding: 14,
      }}>
        <AlertTriangle size={14} color="#fbbf24" style={{ flexShrink: 0, marginTop: 1 }} />
        <p style={{ margin: 0, fontSize: 11, color: '#475569', lineHeight: 1.65 }}>
          Administrative reference only. This application does not process, hold, or transfer financial funds. All payment ledger settlement is managed via external banking API infrastructure (Banco Sabadell). Consult a qualified professional before using generated texts in binding documents.
        </p>
      </div>

      <div style={{ marginTop: 24, textAlign: 'center', color: '#1e3a2f', fontSize: 9, letterSpacing: '0.06em' }}>
        AIPPIE DIGITAL TRUST FUND · ENTERPRISE · {aptId}
      </div>
    </div>
  );
}

// ── Root export ───────────────────────────────────────────────────────────────
export default function AippieTrustDashboard({ user }: Props) {
  const [screen, setScreen] = useState<'register' | 'confirm' | 'dashboard'>('register');
  const [trustName, setTrustName] = useState('');
  const [phone, setPhone] = useState('');
  const [aptId, setAptId] = useState('');
  const [fullName, setFullName] = useState('');
  const [country, setCountry] = useState('');
  const [vat, setVat] = useState('');

  if (screen === 'register') {
    return (
      <RegistrationScreen
        onActivate={(name, ph, id, fn, c, v) => {
          setTrustName(name);
          setPhone(ph);
          setAptId(id);
          setFullName(fn);
          setCountry(c);
          setVat(v);
          setScreen('confirm');
        }}
      />
    );
  }

  if (screen === 'confirm') {
    return (
      <ConfirmationScreen
        trustName={trustName}
        phone={phone}
        aptId={aptId}
        fullName={fullName}
        country={country}
        onContinue={() => setScreen('dashboard')}
      />
    );
  }

  return (
    <TrustDashboard
      trustName={trustName}
      phone={phone}
      aptId={aptId}
      fullName={fullName}
      country={country}
      user={user}
    />
  );
}
