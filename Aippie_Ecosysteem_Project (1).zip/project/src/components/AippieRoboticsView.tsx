/**
 * AippieRoboticsView — V204 Humanoid Robotics & Cybernetic Interface
 * AIPPIETAX S.A. · Module 18
 *
 * Engineering blueprint deployment environment.
 * Displays live telemetry streams for the cloud-to-hardware synchronization
 * architecture — staging visualization only, no physical hardware connected.
 */
import { useEffect, useRef, useState } from 'react';
import {
  Cpu, Radio, Eye, ShieldCheck, Wifi, Activity,
  Zap, Globe, Lock, Terminal, ChevronRight, Building2,
  Layers, GitBranch, Hexagon,
} from 'lucide-react';
import { supabase } from '../lib/supabase';

// ── Telemetry stream definitions ──────────────────────────────────────────────
const TELEMETRY_STREAMS = [
  {
    id: 'cloud',
    icon: <Globe size={14} />,
    label: 'Cloud-to-Hardware Telemetry',
    status: 'STAGING',
    detail: '5G/6G Cloud Brain Active',
    color: '#38bdf8',
    pulse: true,
  },
  {
    id: 'vision',
    icon: <Eye size={14} />,
    label: 'Computer Vision Navigation',
    status: 'INTEGRATED',
    detail: '3D Spatial Core Active',
    color: '#4ade80',
    pulse: true,
  },
  {
    id: 'safety',
    icon: <ShieldCheck size={14} />,
    label: 'Core Directives & Safety Protocols',
    status: '100% COMPLIANT',
    detail: 'Immutable System Safety Override',
    color: '#f59e0b',
    pulse: false,
  },
] as const;

// ── Subsystem node definitions ─────────────────────────────────────────────────
const SUBSYSTEMS = [
  { id: 'nn',     label: 'Neural Net Core',         val: '98.7%',  unit: 'integrity',   color: '#38bdf8' },
  { id: 'servo',  label: 'Servo Motor Array',        val: '24/24',  unit: 'online',      color: '#4ade80' },
  { id: 'latency',label: 'Cloud Sync Latency',       val: '4.2ms',  unit: 'round-trip',  color: '#a78bfa' },
  { id: 'battery',label: 'Power Cell Capacity',      val: '94.1%',  unit: 'remaining',   color: '#fb7185' },
  { id: 'cv',     label: 'CV Object Detection',      val: '312',    unit: 'fps',         color: '#4ade80' },
  { id: 'safety', label: 'Safety Override Layer',    val: 'LOCKED', unit: 'immutable',   color: '#f59e0b' },
] as const;

// ── Wireframe node coordinates (SVG skeleton) ─────────────────────────────────
const SKELETON_NODES = [
  // head
  { x: 100, y: 18, r: 13, label: 'CNS' },
  // neck
  { x: 100, y: 38, r: 4, label: '' },
  // shoulders
  { x: 68,  y: 58, r: 6, label: 'L-SH' },
  { x: 132, y: 58, r: 6, label: 'R-SH' },
  // elbows
  { x: 52,  y: 88, r: 4, label: '' },
  { x: 148, y: 88, r: 4, label: '' },
  // hands
  { x: 42,  y: 116, r: 3, label: '' },
  { x: 158, y: 116, r: 3, label: '' },
  // torso
  { x: 100, y: 78, r: 8, label: 'CORE' },
  { x: 100, y: 100, r: 5, label: '' },
  // hips
  { x: 82,  y: 120, r: 5, label: '' },
  { x: 118, y: 120, r: 5, label: '' },
  // knees
  { x: 80,  y: 148, r: 4, label: '' },
  { x: 120, y: 148, r: 4, label: '' },
  // feet
  { x: 79,  y: 174, r: 3, label: '' },
  { x: 121, y: 174, r: 3, label: '' },
];

const SKELETON_EDGES = [
  [0,1],[1,2],[1,3],[2,4],[3,5],[4,6],[5,7],
  [1,8],[8,9],[9,10],[9,11],[10,12],[11,13],[12,14],[13,15],
];

// ── Wireframe SVG skeleton ────────────────────────────────────────────────────
function WireframeSkeleton({ accentColor, tick }: { accentColor: string; tick: number }) {
  const pulse = 0.6 + 0.4 * Math.abs(Math.sin(tick * 0.04));
  return (
    <svg
      viewBox="0 0 200 200"
      width="200"
      height="200"
      aria-hidden="true"
      className="robo-skeleton"
    >
      {/* Grid */}
      {[0,1,2,3].map(i => (
        <line key={`gh-${i}`} x1="0" y1={i*50} x2="200" y2={i*50}
          stroke={accentColor} strokeWidth="0.3" opacity="0.1" />
      ))}
      {[0,1,2,3].map(i => (
        <line key={`gv-${i}`} x1={i*50} y1="0" x2={i*50} y2="200"
          stroke={accentColor} strokeWidth="0.3" opacity="0.1" />
      ))}
      {/* Edges */}
      {SKELETON_EDGES.map(([a, b], i) => (
        <line
          key={`e-${i}`}
          x1={SKELETON_NODES[a].x} y1={SKELETON_NODES[a].y}
          x2={SKELETON_NODES[b].x} y2={SKELETON_NODES[b].y}
          stroke={accentColor}
          strokeWidth="1.2"
          opacity={0.45 * pulse}
          strokeDasharray="4 2"
        />
      ))}
      {/* Nodes */}
      {SKELETON_NODES.map((n, i) => (
        <g key={`n-${i}`}>
          <circle cx={n.x} cy={n.y} r={n.r + 2} fill={accentColor} opacity="0.08" />
          <circle cx={n.x} cy={n.y} r={n.r} fill="none" stroke={accentColor}
            strokeWidth="1" opacity={0.7 * pulse} />
          {n.label && (
            <text x={n.x + n.r + 3} y={n.y + 3} fontSize="5"
              fill={accentColor} opacity="0.6">{n.label}</text>
          )}
        </g>
      ))}
      {/* Data pulse along neck→core */}
      <circle
        cx={100}
        cy={18 + (tick % 80) * (78 - 18) / 80}
        r="2.5"
        fill={accentColor}
        opacity={0.9}
      />
    </svg>
  );
}

// ── Rolling log entries ───────────────────────────────────────────────────────
const LOG_POOL = [
  '[BOOT]    Neural net core loaded — 4.2B parameters',
  '[SYNC]    Cloud-brain handshake confirmed — 4.2ms latency',
  '[CV]      3D spatial map updated — 312 fps',
  '[SAFETY]  Core directives verified — COMPLIANT',
  '[SERVO]   Motor array calibrated — 24/24 online',
  '[NET]     6G uplink stable — 2.1 Gbps throughput',
  '[AUTH]    Operator identity verified — biometric PASS',
  '[POWER]   Cell 94.1% · estimated 18h autonomy',
  '[CV]      Object: human detected · safe-zone maintained',
  '[SYNC]    Telemetry heartbeat #' + Math.floor(Math.random() * 9000 + 1000),
];

export default function AippieRoboticsView() {
  const [tick, setTick] = useState(0);
  const [logs, setLogs] = useState<string[]>([
    '[BOOT]    Neural net core loaded — 4.2B parameters',
    '[SYNC]    Cloud-brain handshake confirmed — 4.2ms latency',
    '[CV]      3D spatial map updated — 312 fps',
  ]);
  const logRef = useRef<HTMLDivElement>(null);
  const frameRef = useRef<number>(0);
  const lastLogRef = useRef(0);
  const lastDbLogRef = useRef(0);

  // Smooth tick for animations
  useEffect(() => {
    const animate = () => {
      setTick(t => t + 1);
      frameRef.current = requestAnimationFrame(animate);
    };
    frameRef.current = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(frameRef.current);
  }, []);

  // Rolling log — appends a new entry every ~2.4s
  useEffect(() => {
    if (tick - lastLogRef.current < 144) return;
    lastLogRef.current = tick;
    const entry = LOG_POOL[Math.floor(Math.random() * LOG_POOL.length)];
    setLogs(prev => {
      const next = [...prev, entry];
      return next.slice(-8);
    });
    // Persist to Supabase every ~30s (every 12 log entries)
    lastDbLogRef.current++;
    if (lastDbLogRef.current % 12 === 0) {
      supabase.from('robotics_telemetry').insert({
        system: 'SYSTEM-LOG', status: 'ONLINE', value: null, unit: null, note: entry,
      }).then(() => {});
    }
  }, [tick]);

  // Auto-scroll log
  useEffect(() => {
    if (logRef.current) {
      logRef.current.scrollTop = logRef.current.scrollHeight;
    }
  }, [logs]);

  const ACCENT = '#38bdf8';

  return (
    <div className="robo-root">
      <div className="robo-bg" />

      {/* ── Header ── */}
      <div className="robo-header">
        <div className="robo-header__brand">
          <Hexagon size={14} style={{ color: ACCENT }} />
          <span className="robo-header__title">Aippie Humanoid Robotics</span>
          <span className="robo-header__badge">AIPPIETAX S.A. · Module 18 · v204</span>
        </div>
        <span className="robo-header__status">
          <span className="robo-status-dot robo-status-dot--pulse" />
          STAGING — Engineering Blueprint
        </span>
      </div>

      {/* ── Main grid ── */}
      <div className="robo-grid">

        {/* Left: Wireframe + subsystems */}
        <div className="robo-col robo-col--left">
          <div className="robo-panel robo-panel--skeleton">
            <div className="robo-panel__title">
              <Layers size={11} style={{ color: ACCENT }} />
              Cybernetic Wireframe · 3D Spatial Map
            </div>
            <div className="robo-skeleton-wrap">
              <WireframeSkeleton accentColor={ACCENT} tick={tick} />
              <div className="robo-skeleton-overlay">
                <span style={{ color: ACCENT, fontSize: 9, opacity: 0.7 }}>
                  COORDINATE SYNC ACTIVE
                </span>
              </div>
            </div>
          </div>

          {/* Subsystems */}
          <div className="robo-panel robo-panel--subsystems">
            <div className="robo-panel__title">
              <Cpu size={11} style={{ color: ACCENT }} />
              Subsystem Status Matrix
            </div>
            <div className="robo-subsystems">
              {SUBSYSTEMS.map(s => (
                <div key={s.id} className="robo-subsystem-row">
                  <span className="robo-subsystem-row__label">{s.label}</span>
                  <span className="robo-subsystem-row__val" style={{ color: s.color }}>
                    {s.val}
                  </span>
                  <span className="robo-subsystem-row__unit">{s.unit}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Center: Telemetry streams */}
        <div className="robo-col robo-col--center">
          <div className="robo-panel robo-panel--telemetry">
            <div className="robo-panel__title">
              <Radio size={11} style={{ color: ACCENT }} />
              Live Telemetry Streams
            </div>

            {TELEMETRY_STREAMS.map(stream => (
              <div key={stream.id} className="robo-stream-card" style={{ borderColor: stream.color + '44' }}>
                <div className="robo-stream-card__top">
                  <span className="robo-stream-card__icon" style={{ color: stream.color }}>
                    {stream.icon}
                  </span>
                  <span className="robo-stream-card__label">{stream.label}</span>
                  {stream.pulse && (
                    <span className="robo-status-dot robo-status-dot--pulse" style={{ background: stream.color }} />
                  )}
                </div>
                <div className="robo-stream-card__status" style={{ color: stream.color }}>
                  {stream.status}
                </div>
                <div className="robo-stream-card__detail">{stream.detail}</div>
                {/* Signal bar */}
                <div className="robo-stream-card__bar-track">
                  <div
                    className="robo-stream-card__bar-fill"
                    style={{
                      background: stream.color,
                      width: stream.id === 'safety' ? '100%'
                        : `${70 + 28 * Math.abs(Math.sin(tick * 0.025 + stream.id.length))}%`,
                      transition: 'width 0.8s ease',
                    }}
                  />
                </div>
              </div>
            ))}
          </div>

          {/* Network topology */}
          <div className="robo-panel robo-panel--topology">
            <div className="robo-panel__title">
              <GitBranch size={11} style={{ color: ACCENT }} />
              Cloud Network Topology
            </div>
            <div className="robo-topology">
              {['6G Edge Node', 'Cloud Brain', 'Neural API', 'Hardware Bus'].map((node, i) => (
                <div key={node} className="robo-topology__node">
                  <span
                    className="robo-topology__dot"
                    style={{
                      background: ACCENT,
                      opacity: 0.5 + 0.5 * Math.abs(Math.sin(tick * 0.04 + i)),
                    }}
                  />
                  <span className="robo-topology__label">{node}</span>
                  {i < 3 && <ChevronRight size={9} style={{ color: ACCENT, opacity: 0.4 }} />}
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right: System log */}
        <div className="robo-col robo-col--right">
          <div className="robo-panel robo-panel--log">
            <div className="robo-panel__title">
              <Terminal size={11} style={{ color: ACCENT }} />
              System Boot Log
            </div>
            <div className="robo-log" ref={logRef}>
              {logs.map((line, i) => (
                <div key={i} className="robo-log__line">
                  <span className="robo-log__ts">
                    {String(Math.floor(Date.now() / 1000) % 1000).padStart(3, '0')}
                  </span>
                  <span className="robo-log__text">{line}</span>
                </div>
              ))}
              <div className="robo-log__cursor">_</div>
            </div>
          </div>

          {/* Spec sheet */}
          <div className="robo-panel robo-panel--specs">
            <div className="robo-panel__title">
              <Zap size={11} style={{ color: ACCENT }} />
              Hardware Specification Node
            </div>
            <div className="robo-specs">
              {[
                ['Platform',      'AIPPIETAX Humanoid v1.0'],
                ['Locomotion',    'Bipedal · 12-DOF legs'],
                ['Actuators',     '24 servo motors · 0.2N·m'],
                ['Vision',        'Stereo RGB-D · 120° FOV'],
                ['Processing',    'Edge TPU · 8 TOPS'],
                ['Connectivity',  '5G / 6G · Wi-Fi 7 · BLE 5.3'],
                ['Cloud Sync',    'AIPPIETAX Cloud Brain API'],
                ['Safety',        'ISO 10218 · IEC 62443'],
                ['Status',        'STAGING · Pre-production'],
              ].map(([k, v]) => (
                <div key={k} className="robo-spec-row">
                  <span className="robo-spec-row__key">{k}</span>
                  <span className="robo-spec-row__val">{v}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Footer badges */}
          <div className="robo-badges">
            <span className="robo-badge"><Lock size={8} />ISO 10218</span>
            <span className="robo-badge"><ShieldCheck size={8} />IEC 62443</span>
            <span className="robo-badge"><Wifi size={8} />6G Ready</span>
            <span className="robo-badge"><Activity size={8} />Live Sync</span>
          </div>
        </div>
      </div>

      {/* ── Footer ── */}
      <div className="robo-footer">
        <Building2 size={8} />
        AIPPIETAX S.A. · Module 18 · Humanoid Robotics & Cybernetic Interface · v204 · Engineering Staging Blueprint
      </div>
    </div>
  );
}
