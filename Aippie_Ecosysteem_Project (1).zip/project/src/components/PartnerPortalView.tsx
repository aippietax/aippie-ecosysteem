import { useCallback, useEffect, useRef, useState } from 'react';
import {
  X, ShieldCheck, Briefcase, CheckCircle, AlertCircle,
  TrendingUp, Euro, Users, Lock, Zap, ExternalLink,
  Upload, Eye, EyeOff, RefreshCw
} from 'lucide-react';
import { applyPremiumVoice, normalizeForTTS, withVoicesReady } from '../lib/ttsVoice';
import { supabase } from '../lib/supabase';

// ── Types ─────────────────────────────────────────────────────────────────────
type PartnerRecord = {
  id: string;
  partner_token: string;
  company_name: string;
  contact_email: string;
  is_aippietax_internal_agent: boolean;
  client_paid: boolean;
  commission_eur: number;
  active_lead_description: string;
  b2b_billing_active: boolean;
  created_at: string;
};

type MediaAsset = {
  id: string;
  client_email: string;
  asset_title: string;
  cloud_storage_url: string | null;
  asset_type: string;
  client_paid: boolean;
  watermark_enabled: boolean;
  uploaded_by_admin: boolean;
};

type Props = { onClose: () => void };

// ── 28-bar waveform ───────────────────────────────────────────────────────────
function Waveform({ active }: { active: boolean }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const frameRef  = useRef<number>(0);
  const tickRef   = useRef(0);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    const BARS = 28;
    const draw = () => {
      tickRef.current++;
      const tk = tickRef.current;
      const W = canvas.width, H = canvas.height;
      ctx.clearRect(0, 0, W, H);
      const gap = W / BARS, barW = Math.max(2, gap - 2);
      for (let i = 0; i < BARS; i++) {
        const phase = (i / BARS) * Math.PI * 2;
        const rawH = active ? (0.2 + 0.8 * Math.abs(Math.sin(tk * 0.05 + phase))) * H : 4;
        const x = i * gap + (gap - barW) / 2, y = (H - rawH) / 2;
        const grad = ctx.createLinearGradient(0, y, 0, y + rawH);
        grad.addColorStop(0,   'rgba(251,191,36,0.95)');
        grad.addColorStop(0.5, 'rgba(245,158,11,0.75)');
        grad.addColorStop(1,   'rgba(217,119,6,0.4)');
        ctx.fillStyle = grad;
        ctx.beginPath(); ctx.roundRect(x, y, barW, rawH, Math.min(barW/2,3)); ctx.fill();
      }
      frameRef.current = requestAnimationFrame(draw);
    };
    frameRef.current = requestAnimationFrame(draw);
    return () => cancelAnimationFrame(frameRef.current);
  }, [active]);

  return <canvas ref={canvasRef} width={260} height={40} className="pp-waveform" aria-hidden="true"/>;
}

// ── Word-sync subtitle hook ───────────────────────────────────────────────────
function useWordSubtitle(text: string, active: boolean): string {
  const [subtitle, setSubtitle] = useState('');
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const idxRef   = useRef(0);

  useEffect(() => {
    if (timerRef.current) clearInterval(timerRef.current);
    if (!active || !text) { setSubtitle(''); return; }
    const words = text.split(' ');
    idxRef.current = 0;
    setSubtitle('');
    timerRef.current = setInterval(() => {
      idxRef.current++;
      const start = Math.max(0, idxRef.current - 10);
      setSubtitle(words.slice(start, idxRef.current).join(' '));
      if (idxRef.current >= words.length && timerRef.current) clearInterval(timerRef.current);
    }, 460);
    return () => { if (timerRef.current) clearInterval(timerRef.current); };
  }, [text, active]);

  return subtitle;
}

// ── Aippie voice ledger messages ──────────────────────────────────────────────
function getLedgerScript(partner: PartnerRecord): string {
  if (partner.client_paid) {
    return `Good morning! Your client has successfully paid the invoice. Your commission of ${partner.commission_eur.toFixed(2)} euros has been automatically credited to your secure balance. Keep pushing!`;
  }
  return `Welcome back. Your active lead is currently pending payment. The video download remains locked until Stripe verification completes. Lead: ${partner.active_lead_description}.`;
}

// ── Login screen ──────────────────────────────────────────────────────────────
function LoginScreen({ onAuth }: { onAuth: (p: PartnerRecord) => void }) {
  const [token, setToken]   = useState('');
  const [show,  setShow]    = useState(false);
  const [busy,  setBusy]    = useState(false);
  const [error, setError]   = useState('');

  const handleLogin = async () => {
    if (!token.trim() || busy) return;
    setBusy(true); setError('');
    const { data } = await supabase
      .from('aippie_partner_network')
      .select('*')
      .eq('partner_token', token.trim())
      .maybeSingle();
    setBusy(false);
    if (!data) { setError('Invalid partner token. Please check and try again.'); return; }
    onAuth(data as PartnerRecord);
  };

  return (
    <div className="pp-login">
      <div className="pp-login__icon"><Briefcase size={22}/></div>
      <div className="pp-login__title">B2B Partner Portal</div>
      <div className="pp-login__sub">AIPPIETAX S.A. · Secure Agent Access</div>

      <div className="pp-login__field-wrap">
        <div className="pp-login__label">Partner Access Token</div>
        <div className="pp-login__input-row">
          <input
            type={show ? 'text' : 'password'}
            className="pp-login__input"
            placeholder="Enter your partner token…"
            value={token}
            onChange={e => setToken(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && handleLogin()}
            autoComplete="off"
          />
          <button className="pp-login__eye" onClick={() => setShow(s => !s)} type="button">
            {show ? <EyeOff size={14}/> : <Eye size={14}/>}
          </button>
        </div>
        {error && <div className="pp-login__error"><AlertCircle size={11}/> {error}</div>}
      </div>

      <button className="pp-login__btn" onClick={handleLogin} disabled={busy || !token.trim()}>
        {busy ? <span className="ob-cta__spinner"/> : <><Lock size={13}/> ACCESS PARTNER PORTAL</>}
      </button>

      <div className="pp-login__demo">
        <div className="pp-login__demo-title">Demo tokens:</div>
        <code className="pp-login__demo-code" onClick={() => setToken('AIPPIE-INTERNAL-2024')}>AIPPIE-INTERNAL-2024</code>
        <code className="pp-login__demo-code" onClick={() => setToken('PARTNER-DEMO-EXTERNAL')}>PARTNER-DEMO-EXTERNAL</code>
      </div>

      <div className="pp-login__trust"><ShieldCheck size={10}/> 256-bit encrypted · GDPR compliant · AIPPIETAX S.A.</div>
    </div>
  );
}

// ── External B2B billing gate ─────────────────────────────────────────────────
function BillingGate({ partner, onClose }: { partner: PartnerRecord; onClose: () => void }) {
  const [busy, setBusy] = useState(false);
  const [activated, setActivated] = useState(false);

  const handleActivate = async () => {
    setBusy(true);
    await supabase.from('aippie_partner_network')
      .update({ b2b_billing_active: true, updated_at: new Date().toISOString() })
      .eq('id', partner.id);
    setBusy(false);
    setActivated(true);
  };

  if (activated) {
    return (
      <div className="pp-billing-gate pp-billing-gate--done">
        <CheckCircle size={32} color="#4ade80"/>
        <div className="pp-billing-gate__title">Enterprise Access Activated</div>
        <div className="pp-billing-gate__sub">Your €199.99/month B2B license is now active. Please refresh the portal.</div>
        <button className="pp-billing-gate__btn" onClick={onClose}><RefreshCw size={13}/> Refresh</button>
      </div>
    );
  }

  return (
    <div className="pp-billing-gate">
      <div className="pp-billing-gate__icon"><TrendingUp size={20}/></div>
      <div className="pp-billing-gate__title">Aippie Enterprise B2B Licensing</div>
      <div className="pp-billing-gate__price">€199.99<span>/month</span></div>
      <div className="pp-billing-gate__sub">
        Your company <strong>{partner.company_name}</strong> is leasing the Aippie automated agent infrastructure.
        Activate your monthly B2B license to unlock the full management dashboard.
      </div>
      <ul className="pp-billing-gate__features">
        {[
          'Live client payment tracker',
          'Automated commission ledger',
          'Aippie AI voice briefing',
          'Media asset command center',
          'Multi-agent sub-portal access',
          'Priority support line',
        ].map(f => <li key={f}><CheckCircle size={10}/> {f}</li>)}
      </ul>
      <button className="pp-billing-gate__btn" onClick={handleActivate} disabled={busy}>
        {busy ? <span className="ob-cta__spinner"/> : <><Zap size={13}/> ACTIVATE — €199.99/mo</>}
      </button>
      <div className="pp-billing-gate__trust"><ShieldCheck size={10}/> Secured by Stripe · Cancel anytime</div>
    </div>
  );
}

// ── Media Admin Panel ─────────────────────────────────────────────────────────
function MediaAdminPanel() {
  const [assets, setAssets]   = useState<MediaAsset[]>([]);
  const [loading, setLoading] = useState(true);
  const [newEmail, setNewEmail]  = useState('');
  const [newTitle, setNewTitle]  = useState('');
  const [newUrl,   setNewUrl]    = useState('');
  const [newPaid,  setNewPaid]   = useState(false);
  const [saving, setSaving]      = useState(false);

  const loadAssets = useCallback(async () => {
    setLoading(true);
    const { data } = await supabase.from('aippie_media_assets').select('*').order('created_at', { ascending: false });
    setAssets((data as MediaAsset[]) ?? []);
    setLoading(false);
  }, []);

  useEffect(() => { loadAssets(); }, [loadAssets]);

  const handleSave = async () => {
    if (!newEmail.trim() || !newTitle.trim() || saving) return;
    setSaving(true);
    await supabase.from('aippie_media_assets').insert({
      client_email: newEmail.trim(),
      asset_title: newTitle.trim(),
      cloud_storage_url: newUrl.trim() || null,
      client_paid: newPaid,
      uploaded_by_admin: !!newUrl.trim(),
      watermark_enabled: true,
    });
    setNewEmail(''); setNewTitle(''); setNewUrl(''); setNewPaid(false);
    setSaving(false);
    loadAssets();
  };

  const togglePaid = async (asset: MediaAsset) => {
    await supabase.from('aippie_media_assets')
      .update({ client_paid: !asset.client_paid, updated_at: new Date().toISOString() })
      .eq('id', asset.id);
    loadAssets();
  };

  const updateUrl = async (asset: MediaAsset, url: string) => {
    await supabase.from('aippie_media_assets')
      .update({ cloud_storage_url: url || null, uploaded_by_admin: !!url, updated_at: new Date().toISOString() })
      .eq('id', asset.id);
    loadAssets();
  };

  return (
    <div className="pp-media">
      <div className="pp-media__header">
        <Upload size={13}/> Aippie Media Admin Command Center
      </div>

      {/* Add asset */}
      <div className="pp-media__add">
        <input className="pp-media__input" placeholder="Client email" value={newEmail} onChange={e => setNewEmail(e.target.value)}/>
        <input className="pp-media__input" placeholder="Asset title" value={newTitle} onChange={e => setNewTitle(e.target.value)}/>
        <input className="pp-media__input" placeholder="Cloud storage URL (S3 / GCS)" value={newUrl} onChange={e => setNewUrl(e.target.value)}/>
        <label className="pp-media__paid-label">
          <input type="checkbox" checked={newPaid} onChange={e => setNewPaid(e.target.checked)}/>
          Client paid
        </label>
        <button className="pp-media__save-btn" onClick={handleSave} disabled={saving}>
          {saving ? <span className="ob-cta__spinner"/> : 'Add Asset'}
        </button>
      </div>

      {/* Asset list */}
      {loading ? (
        <div className="pp-media__loading"><span className="ob-cta__spinner"/></div>
      ) : assets.length === 0 ? (
        <div className="pp-media__empty">No media assets yet. Add one above.</div>
      ) : (
        <div className="pp-media__list">
          {assets.map(a => (
            <div key={a.id} className="pp-media__row">
              <div className="pp-media__row-info">
                <div className="pp-media__row-title">{a.asset_title}</div>
                <div className="pp-media__row-email">{a.client_email}</div>
              </div>
              <div className="pp-media__row-url">
                <input
                  className="pp-media__url-input"
                  defaultValue={a.cloud_storage_url ?? ''}
                  placeholder="Paste URL…"
                  onBlur={e => { if (e.target.value !== (a.cloud_storage_url ?? '')) updateUrl(a, e.target.value); }}
                />
              </div>
              <div className="pp-media__row-actions">
                <button
                  className={`pp-media__paid-btn${a.client_paid ? ' pp-media__paid-btn--paid' : ''}`}
                  onClick={() => togglePaid(a)}
                  title={a.client_paid ? 'Mark unpaid' : 'Mark paid'}
                >
                  {a.client_paid ? <><CheckCircle size={11}/> PAID</> : <><AlertCircle size={11}/> PENDING</>}
                </button>
                {a.cloud_storage_url && a.client_paid && (
                  <a
                    className="pp-media__download-btn"
                    href={a.cloud_storage_url}
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    <ExternalLink size={11}/> View
                  </a>
                )}
                {a.cloud_storage_url && !a.client_paid && (
                  <span className="pp-media__locked"><Lock size={10}/> Locked</span>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// ── Main dashboard ────────────────────────────────────────────────────────────
function Dashboard({ partner, onLogout }: { partner: PartnerRecord; onLogout: () => void }) {
  const [speaking, setSpeaking] = useState(false);
  const [tab, setTab]           = useState<'ledger' | 'media'>('ledger');
  const script = getLedgerScript(partner);
  const subtitle = useWordSubtitle(script, speaking);

  const speak = useCallback(() => {
    if (!('speechSynthesis' in window)) return;
    window.speechSynthesis.cancel();
    setSpeaking(false);
    const fire = () => {
      const u = new SpeechSynthesisUtterance(normalizeForTTS(script));
      u.pitch = 1.1; u.rate = 0.92;
      applyPremiumVoice(u);
      u.onstart = () => setSpeaking(true);
      u.onend   = () => setSpeaking(false);
      u.onerror = () => setSpeaking(false);
      window.speechSynthesis.speak(u);
    };
    withVoicesReady(fire);
  }, [script]);

  // Auto-speak on mount
  useEffect(() => {
    const t = setTimeout(speak, 800);
    return () => { clearTimeout(t); window.speechSynthesis?.cancel(); };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <div className="pp-dashboard">

      {/* Header */}
      <div className="pp-dashboard__header">
        <div className="pp-dashboard__header-left">
          <div className="pp-dashboard__company">{partner.company_name}</div>
          <div className="pp-dashboard__email">{partner.contact_email}</div>
        </div>
        <div className="pp-dashboard__badges">
          {partner.is_aippietax_internal_agent && (
            <span className="pp-badge pp-badge--internal"><ShieldCheck size={9}/> Internal Agent</span>
          )}
          {!partner.is_aippietax_internal_agent && partner.b2b_billing_active && (
            <span className="pp-badge pp-badge--b2b"><TrendingUp size={9}/> B2B Licensed</span>
          )}
        </div>
        <button className="pp-dashboard__logout" onClick={onLogout} title="Log out">
          <X size={14}/>
        </button>
      </div>

      {/* Avatar + waveform + subtitles */}
      <div className="pp-avatar-section">
        <div className="pp-avatar-wrap">
          <img
            src="/Jouw_alineatekst_(2).png"
            alt="Aippie" className="pp-avatar"
          />
          <div className="pp-avatar__fade"/>
          {speaking && <div className="pp-avatar__speaking-dot"/>}
        </div>
        <div className="pp-avatar-speech">
          <Waveform active={speaking}/>
          {speaking && subtitle && (
            <div className="pp-subtitle">{subtitle}</div>
          )}
          <button
            className={`pp-speak-btn${speaking ? ' pp-speak-btn--active' : ''}`}
            onClick={() => {
              if (speaking) { window.speechSynthesis?.cancel(); setSpeaking(false); }
              else speak();
            }}
          >
            {speaking ? 'Stop Briefing' : 'Hear Aippie Briefing'}
          </button>
        </div>
      </div>

      {/* KPI strip */}
      <div className="pp-kpi-strip">
        <div className={`pp-kpi-card${partner.client_paid ? ' pp-kpi-card--paid' : ' pp-kpi-card--pending'}`}>
          <div className="pp-kpi-card__label">Client Payment</div>
          <div className="pp-kpi-card__value">
            {partner.client_paid
              ? <><CheckCircle size={14}/> PAID</>
              : <><AlertCircle size={14}/> PENDING</>
            }
          </div>
        </div>
        <div className="pp-kpi-card pp-kpi-card--commission">
          <div className="pp-kpi-card__label">Earned Commission</div>
          <div className="pp-kpi-card__value">
            <Euro size={13}/>
            {partner.commission_eur.toFixed(2)}
          </div>
        </div>
        <div className="pp-kpi-card pp-kpi-card--neutral">
          <div className="pp-kpi-card__label">Active Lead</div>
          <div className="pp-kpi-card__value pp-kpi-card__value--small">
            {partner.active_lead_description || '—'}
          </div>
        </div>
      </div>

      {/* Lead description */}
      {partner.active_lead_description && (
        <div className="pp-lead-box">
          <Users size={11}/> <span>{partner.active_lead_description}</span>
        </div>
      )}

      {/* Tab switcher */}
      <div className="pp-tab-bar">
        <button
          className={`pp-tab-btn${tab === 'ledger' ? ' pp-tab-btn--active' : ''}`}
          onClick={() => setTab('ledger')}
        >
          Ledger
        </button>
        <button
          className={`pp-tab-btn${tab === 'media' ? ' pp-tab-btn--active' : ''}`}
          onClick={() => setTab('media')}
        >
          Media Assets
        </button>
      </div>

      {tab === 'ledger' && (
        <div className="pp-ledger">
          <div className="pp-ledger__row">
            <span className="pp-ledger__key">Status</span>
            <span className={`pp-ledger__val ${partner.client_paid ? 'pp-ledger__val--green' : 'pp-ledger__val--red'}`}>
              {partner.client_paid ? '🟢 Payment confirmed' : '🔴 Awaiting payment'}
            </span>
          </div>
          <div className="pp-ledger__row">
            <span className="pp-ledger__key">Commission</span>
            <span className="pp-ledger__val pp-ledger__val--gold">€{partner.commission_eur.toFixed(2)}</span>
          </div>
          <div className="pp-ledger__row">
            <span className="pp-ledger__key">Type</span>
            <span className="pp-ledger__val">{partner.is_aippietax_internal_agent ? 'Internal AIPPIETAX Agent' : 'External Enterprise'}</span>
          </div>
          <div className="pp-ledger__row">
            <span className="pp-ledger__key">B2B License</span>
            <span className={`pp-ledger__val ${partner.b2b_billing_active || partner.is_aippietax_internal_agent ? 'pp-ledger__val--green' : 'pp-ledger__val--red'}`}>
              {partner.is_aippietax_internal_agent ? 'Free (Internal)' : partner.b2b_billing_active ? 'Active — €199.99/mo' : 'Not activated'}
            </span>
          </div>
          {!partner.client_paid && (
            <div className="pp-ledger__locked-notice">
              <Lock size={11}/>
              Video download locked · Stripe verification pending
            </div>
          )}
        </div>
      )}

      {tab === 'media' && <MediaAdminPanel/>}
    </div>
  );
}

// ── Main component ────────────────────────────────────────────────────────────
export default function PartnerPortalView({ onClose }: Props) {
  const [partner, setPartner] = useState<PartnerRecord | null>(null);
  const [needsBilling, setNeedsBilling] = useState(false);

  const handleAuth = (p: PartnerRecord) => {
    if (!p.is_aippietax_internal_agent && !p.b2b_billing_active) {
      setPartner(p);
      setNeedsBilling(true);
    } else {
      setPartner(p);
      setNeedsBilling(false);
    }
  };

  const handleLogout = () => {
    window.speechSynthesis?.cancel();
    setPartner(null);
    setNeedsBilling(false);
  };

  return (
    <div className="pp-backdrop" onClick={onClose}>
      <div className="pp-modal" onClick={e => e.stopPropagation()}>

        {/* Header bar */}
        <div className="pp-modal__bar">
          <div className="pp-modal__bar-left">
            <Briefcase size={12}/>
            <span>B2B Partner Portal · AIPPIETAX S.A. · v86</span>
          </div>
          <button className="pp-modal__close" onClick={onClose}><X size={16}/></button>
        </div>

        {/* Content */}
        <div className="pp-modal__body">
          {!partner && <LoginScreen onAuth={handleAuth}/>}
          {partner && needsBilling && <BillingGate partner={partner} onClose={handleLogout}/>}
          {partner && !needsBilling && <Dashboard partner={partner} onLogout={handleLogout}/>}
        </div>
      </div>
    </div>
  );
}
