import { useCallback, useEffect, useRef, useState } from 'react';
import { Users, Zap, AlertCircle, TrendingUp } from 'lucide-react';
import { supabase, type CallRequest, type Subscription, PLAN_CONFIG, currentMonthStart } from '../lib/supabase';
import { CORRIDORS, buildRoutingParams, corridorCode, type LanguageCorridor } from '../lib/routingConfig';
import CallButton from './CallButton';
import CallTimer from './CallTimer';
import LanguageToggle from './LanguageToggle';
import SubscriptionModal from './SubscriptionModal';
import VoicePaywall from './VoicePaywall';
import type { User } from '@supabase/supabase-js';

const FALLBACK_TIMEOUT_MS = 15_000;

type CallPhase = 'idle' | 'dispatching' | 'connected' | 'fallback' | 'ended';

// V47: voiceToken is passed from App (resolved from onboarding + DB) — no internal re-fetch
type Props = {
  user: User | null;
  subscription: Subscription | null;
  voiceToken: boolean;
  onVoiceTokenGranted: () => void;
};

export default function ClientView({ user, subscription, voiceToken, onVoiceTokenGranted }: Props) {
  const [showModal, setShowModal]     = useState(false);
  const [phase, setPhase]             = useState<CallPhase>('idle');
  const [callSeconds, setCallSeconds] = useState(0);
  const [corridor, setCorridor]       = useState<LanguageCorridor>(CORRIDORS[0]);
  const [flipped, setFlipped]         = useState(false);
  const [onlineCount, setOnlineCount] = useState(142);
  const [activeRequestId, setActiveRequestId] = useState<string | null>(null);
  const [monthMinutesUsed, setMonthMinutesUsed] = useState(0);

  const timerRef       = useRef<ReturnType<typeof setInterval> | null>(null);
  const fallbackRef    = useRef<ReturnType<typeof setTimeout> | null>(null);
  const resetPhaseRef  = useRef<ReturnType<typeof setTimeout> | null>(null);
  const channelRef     = useRef<ReturnType<typeof supabase.channel> | null>(null);
  const callStartRef   = useRef<number>(0);
  const prevCountRef   = useRef<number>(142);

  const hasSubscription = !!subscription;
  const tier  = subscription?.plan_tier;
  const cfg   = tier ? PLAN_CONFIG[tier] : null;
  const includedMinutes = cfg?.includedMinutes ?? 40;
  const overageRate     = cfg?.overageRate ?? 0.50;

  const liveCallMinutes = callSeconds / 60;
  const totalMinutes    = monthMinutesUsed + (phase === 'connected' ? liveCallMinutes : 0);
  const overageMinutes  = Math.max(0, totalMinutes - includedMinutes);
  const overageCost     = overageMinutes * overageRate;

  useEffect(() => {
    const fetchCount = () =>
      supabase
        .from('translator_sessions')
        .select('id', { count: 'exact', head: true })
        .eq('status', 'online')
        .then(({ count }) => {
          if (count !== null && count !== prevCountRef.current) {
            prevCountRef.current = count;
            setOnlineCount(count);
          }
        });
    fetchCount();
    const ch = supabase.channel('translator-count')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'translator_sessions' }, fetchCount)
      .subscribe();
    return () => { supabase.removeChannel(ch); };
  }, []);

  useEffect(() => {
    if (!user) return;
    supabase
      .from('client_usage')
      .select('minutes_used')
      .eq('user_id', user.id)
      .eq('month_start', currentMonthStart())
      .maybeSingle()
      .then(({ data }) => { if (data) setMonthMinutesUsed(Number(data.minutes_used)); });
  }, [user]);

  useEffect(() => {
    if (!activeRequestId) return;
    const ch = supabase
      .channel(`request-${activeRequestId}`)
      .on('postgres_changes',
        { event: 'UPDATE', schema: 'public', table: 'call_requests', filter: `id=eq.${activeRequestId}` },
        (payload) => {
          const row = payload.new as CallRequest;
          if (row.status === 'accepted') {
            clearTimeout(fallbackRef.current!);
            setPhase('connected');
            startTimer();
          }
        }
      ).subscribe();
    channelRef.current = ch;
    return () => { supabase.removeChannel(ch); };
  }, [activeRequestId]);

  const startTimer = () => {
    callStartRef.current = Date.now();
    setCallSeconds(0);
    timerRef.current = setInterval(() => setCallSeconds(s => s + 1), 1000);
  };

  const stopTimer = () => {
    if (timerRef.current) { clearInterval(timerRef.current); timerRef.current = null; }
  };

  const logClientUsage = async (seconds: number) => {
    if (!user) return;
    const added      = seconds / 60;
    const monthStart = currentMonthStart();
    await supabase.from('client_usage').upsert(
      { user_id: user.id, month_start: monthStart, minutes_used: monthMinutesUsed + added, updated_at: new Date().toISOString() },
      { onConflict: 'user_id,month_start' }
    );
    setMonthMinutesUsed(prev => prev + added);
  };

  const endCall = useCallback(async () => {
    const elapsed = callSeconds;
    stopTimer();
    clearTimeout(fallbackRef.current!);
    clearTimeout(resetPhaseRef.current!);
    if (channelRef.current) supabase.removeChannel(channelRef.current);
    if (activeRequestId) {
      await supabase.from('call_requests').update({ status: 'ended' }).eq('id', activeRequestId);
    }
    await logClientUsage(elapsed);
    setActiveRequestId(null);
    setPhase('ended');
    resetPhaseRef.current = setTimeout(() => setPhase('idle'), 2000);
    setCallSeconds(0);
  }, [activeRequestId, callSeconds]);

  const triggerFallback = useCallback(async () => {
    stopTimer();
    if (activeRequestId) {
      await supabase.from('call_requests')
        .update({ status: 'fallback', fallback_at: new Date().toISOString() })
        .eq('id', activeRequestId);
    }
    setPhase('fallback');
    startTimer();
  }, [activeRequestId]);

  const handleCallPress = async () => {
    if (!user || !hasSubscription) { setShowModal(true); return; }
    if (phase === 'connected' || phase === 'fallback') { endCall(); return; }
    if (phase !== 'idle') return;

    const params = buildRoutingParams(CORRIDORS.indexOf(corridor));
    const code   = corridorCode(params.corridor);

    const { data, error } = await supabase
      .from('call_requests')
      .insert({ client_user_id: user.id, corridor: code, status: 'pending' })
      .select('id').single();
    if (error || !data) return;

    setActiveRequestId(data.id);
    setPhase('dispatching');
    fallbackRef.current = setTimeout(triggerFallback, FALLBACK_TIMEOUT_MS);
  };

  useEffect(() => () => {
    stopTimer();
    clearTimeout(fallbackRef.current!);
    clearTimeout(resetPhaseRef.current!);
  }, []);

  const fromLang = flipped ? corridor.to   : corridor.from;
  const toLang   = flipped ? corridor.from : corridor.to;
  const isActive = phase === 'connected' || phase === 'fallback';

  const minutesPct = Math.min((totalMinutes / includedMinutes) * 100, 100);
  const isOverage  = overageMinutes > 0;

  // ── V47: Paywall gate — only blocks if voice_token is explicitly false ──────
  if (!voiceToken) {
    return (
      <>
        <VoicePaywall onSubscribe={() => setShowModal(true)} />
        {showModal && (
          <SubscriptionModal
            onClose={() => setShowModal(false)}
            onSubscribed={async () => {
              const deviceKey = localStorage.getItem('aippie_device_key') ?? '';
              if (deviceKey) {
                await supabase
                  .from('client_profiles')
                  .update({ voice_token: true })
                  .eq('device_key', deviceKey);
              }
              onVoiceTokenGranted();
              setShowModal(false);
            }}
          />
        )}
      </>
    );
  }

  // ── Full AippieVoice interface — only rendered when voice_token is true ─────
  return (
    <div className="app">
      <div className="app__bg" />

      <header className="app__header">
        <div className="status-bar">
          <span className="status-bar__text">
            <span className="status-bar__dot" />
            {onlineCount} Certified Translators online in Spain
          </span>
        </div>
      </header>

      <main className="app__main">
        <div className="app__brand">
          <span className="app__logo">AippieVoice</span>
          <p className="app__tagline">
            {cfg ? cfg.label : 'Live interpreter at your fingertips'}
          </p>
        </div>

        {hasSubscription && cfg && (
          <div className="usage-bar-wrap">
            <div className="usage-bar-header">
              <span className="usage-bar-label">
                <TrendingUp size={11} />
                {totalMinutes.toFixed(1)} / {includedMinutes} min used
              </span>
              {isOverage && (
                <span className="usage-bar-overage">+€{overageCost.toFixed(2)} overage</span>
              )}
            </div>
            <div className="usage-bar">
              <div
                className={`usage-bar__fill${isOverage ? ' usage-bar__fill--over' : ''}`}
                style={{ width: `${minutesPct}%` }}
              />
            </div>
          </div>
        )}

        <div className="app__call-area">
          {isActive && <CallTimer seconds={callSeconds} />}

          {phase === 'dispatching' && (
            <div className="dispatch-badge">
              <span className="dispatch-badge__dot" />
              Broadcasting to {fromLang.flag} {fromLang.label} ⇄ {toLang.flag} {toLang.label} translators…
            </div>
          )}

          {phase === 'connected' && (
            <div className="phase-badge phase-badge--connected">
              <Users size={13} /> Translator connected
            </div>
          )}

          {phase === 'fallback' && (
            <div className="phase-badge phase-badge--fallback">
              <Zap size={13} /> Routing to AippieVoice Emergency AI Assistant… Connected
            </div>
          )}

          {phase === 'ended' && (
            <div className="phase-badge phase-badge--ended">
              <AlertCircle size={13} /> Call ended
            </div>
          )}

          <CallButton isActive={isActive} onPress={handleCallPress} />

          {phase === 'idle' && (
            <p className="app__hint">
              {hasSubscription ? 'Tap to connect with a translator' : 'Tap to start — subscription required'}
            </p>
          )}
          {phase === 'dispatching' && <p className="app__hint">Connecting… tap to cancel</p>}
          {isActive && <p className="app__hint app__hint--active">Tap to end call</p>}
        </div>
      </main>

      <footer className="app__footer">
        <LanguageToggle onCorridorChange={(c, f) => {
          if (isActive) endCall();
          setCorridor(c);
          setFlipped(f);
        }} />
        {user && (
          <button className="app__signout" onClick={() => supabase.auth.signOut()}>
            Sign out
          </button>
        )}
      </footer>

      {showModal && (
        <SubscriptionModal
          onClose={() => setShowModal(false)}
          onSubscribed={() => setShowModal(false)}
        />
      )}
    </div>
  );
}
