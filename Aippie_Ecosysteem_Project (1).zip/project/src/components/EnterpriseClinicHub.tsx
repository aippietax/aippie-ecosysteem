/**
 * EnterpriseClinicHub — V141 B2B Corporate Clinic Portal
 * AIPPIETAX S.A.
 *
 * Enterprise pricing:
 *   - One-Time Custom Clinic Integration Setup  $10,000.00
 *   - Monthly Recurring AI Infrastructure SaaS  $2,000.00 /mo
 *
 * Flow:
 *   1. Product selection
 *   2. Clinic details form
 *   3. Card payment gate (4242 4242 4242 4242 test override)
 *   4. Clinic Dashboard — AnamAIController avatar + 5-signal telemetry + modules
 */
import { useCallback, useEffect, useRef, useState } from 'react';
import {
  Building2, CheckCircle2, Lock, Mic, RefreshCw, AlertCircle,
  CreditCard, Video, Activity, Zap, Eye, TrendingUp,
  ShieldCheck, Users, Cpu, FileText, ChevronRight,
  ArrowLeft, Star, Globe, Phone,
} from 'lucide-react';
import { supabase } from '../lib/supabase';
import { applyPremiumVoice, normalizeForTTS, withVoicesReady } from '../lib/ttsVoice';

// ── Pricing constants ─────────────────────────────────────────────────────────
const SETUP_PRICE_USD  = 10_000.00;
const SAAS_PRICE_USD   =  2_000.00;

// ── Typewriter subtitle hook ──────────────────────────────────────────────────
function useWordSubtitle(text: string, active: boolean) {
  const [sub, setSub] = useState('');
  const tmr = useRef<ReturnType<typeof setInterval> | null>(null);
  const idx  = useRef(0);
  useEffect(() => {
    if (tmr.current) { clearInterval(tmr.current); tmr.current = null; }
    setSub('');
    if (!active || !text.trim()) return;
    const words = text.split(/\s+/);
    idx.current = 0;
    tmr.current = setInterval(() => {
      idx.current++;
      setSub(words.slice(Math.max(0, idx.current - 10), idx.current).join(' '));
      if (idx.current >= words.length && tmr.current) {
        clearInterval(tmr.current); tmr.current = null;
      }
    }, 400);
    return () => { if (tmr.current) { clearInterval(tmr.current); tmr.current = null; } };
  }, [text, active]);
  return sub;
}

// ── Format card input ─────────────────────────────────────────────────────────
function formatCard(raw: string) {
  return raw.replace(/\D/g, '').slice(0, 16).replace(/(.{4})/g, '$1 ').trim();
}

// ── Generate session token ─────────────────────────────────────────────────────
function genSessionToken() {
  const seg = () => Math.random().toString(36).slice(2, 7).toUpperCase();
  return `CLNK-${seg()}-${seg()}-${seg()}`;
}

// ── AnamAIController avatar sub-component ────────────────────────────────────
function AnamAIController({
  speaking,
  subtitle,
  cameraStream,
}: {
  speaking: boolean;
  subtitle: string;
  cameraStream: MediaStream | null;
}) {
  const videoRef = useRef<HTMLVideoElement>(null);

  useEffect(() => {
    if (videoRef.current && cameraStream) {
      videoRef.current.srcObject = cameraStream;
      videoRef.current.play().catch(() => {});
    }
  }, [cameraStream]);

  return (
    <div className="ech-avatar-panel">
      <div className="ech-avatar-wrap">
        {cameraStream ? (
          <video
            ref={videoRef}
            className="ech-avatar-video"
            muted
            playsInline
            autoPlay
            aria-label="Live camera feed"
          />
        ) : (
          <img
            src="/Jouw_alineatekst_(2).png"
            alt="Aippie"
            className={`ech-avatar-img${speaking ? ' ech-avatar-img--speaking' : ''}`}
            onError={e => {
              (e.currentTarget as HTMLImageElement).src =
                'https://images.pexels.com/photos/1858175/pexels-photo-1858175.jpeg?auto=compress&cs=tinysrgb&w=300&h=350&fit=crop&crop=faces';
            }}
          />
        )}
        {speaking && <div className="ech-avatar-ring" />}
        <div className="ech-avatar-badge">
          <Mic size={8} />
          <span>AnamAIController · v141</span>
        </div>
      </div>
      <div className="ech-avatar-subtitle">
        {speaking && subtitle
          ? <span className="ech-avatar-subtitle--active">{subtitle}</span>
          : <span className="ech-avatar-subtitle--idle">Enterprise Clinic AI — Live</span>
        }
      </div>
    </div>
  );
}

// ── Telemetry signal bar ──────────────────────────────────────────────────────
function TelemetryBar({ label, pct, color, icon }: { label: string; pct: number; color: string; icon: React.ReactNode }) {
  return (
    <div className="ech-telem-row">
      <span className="ech-telem-icon" style={{ color }}>{icon}</span>
      <span className="ech-telem-label">{label}</span>
      <div className="ech-telem-track">
        <div className="ech-telem-fill" style={{ width: `${pct}%`, background: color }} />
      </div>
      <span className="ech-telem-pct" style={{ color }}>{pct}%</span>
    </div>
  );
}

// ── Module card for the clinic dashboard ─────────────────────────────────────
function ClinicModule({ icon, title, sub, color }: { icon: React.ReactNode; title: string; sub: string; color: string }) {
  return (
    <div className="ech-module-card" style={{ borderColor: color + '33' }}>
      <div className="ech-module-card__icon" style={{ color, background: color + '14' }}>{icon}</div>
      <div className="ech-module-card__body">
        <div className="ech-module-card__title">{title}</div>
        <div className="ech-module-card__sub">{sub}</div>
      </div>
      <ChevronRight size={14} className="ech-module-card__arrow" style={{ color }} />
    </div>
  );
}

// ── Main component ────────────────────────────────────────────────────────────
type Phase = 'select' | 'details' | 'payment' | 'processing' | 'dashboard';

export default function EnterpriseClinicHub({ onClose }: { onClose: () => void }) {
  const [phase,         setPhase]         = useState<Phase>('select');
  const [buySetup,      setBuySetup]      = useState(true);
  const [buySaas,       setBuySaas]       = useState(true);
  const [clinicName,    setClinicName]    = useState('');
  const [contactName,   setContactName]   = useState('');
  const [contactEmail,  setContactEmail]  = useState('');
  const [cardInput,     setCardInput]     = useState('');
  const [cardError,     setCardError]     = useState('');
  const [sessionToken,  setSessionToken]  = useState('');
  const [cameraStream,  setCameraStream]  = useState<MediaStream | null>(null);
  const [speaking,      setSpeaking]      = useState(false);
  const [spokenText,    setSpokenText]    = useState('');
  const [detailsError,  setDetailsError]  = useState('');

  const mountedRef  = useRef(true);
  const deviceKey   = useRef((() => {
    let k = localStorage.getItem('aippie_device_key');
    if (!k) { k = crypto.randomUUID(); localStorage.setItem('aippie_device_key', k); }
    return k;
  })());

  const subtitle = useWordSubtitle(spokenText, speaking);

  const totalUSD = (buySetup ? SETUP_PRICE_USD : 0) + (buySaas ? SAAS_PRICE_USD : 0);

  useEffect(() => {
    mountedRef.current = true;
    return () => {
      mountedRef.current = false;
      window.speechSynthesis?.cancel();
      if (cameraStream) cameraStream.getTracks().forEach(t => t.stop());
    };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const speak = useCallback((text: string) => {
    if (!('speechSynthesis' in window)) return;
    window.speechSynthesis.cancel();
    const say = () => {
      const u = new SpeechSynthesisUtterance(normalizeForTTS(text));
      u.rate  = 0.82;
      u.pitch = 1.02;
      applyPremiumVoice(u);
      u.onstart = () => { if (mountedRef.current) { setSpeaking(true);  setSpokenText(text); } };
      u.onend   = () => { if (mountedRef.current) setSpeaking(false); };
      u.onerror = () => { if (mountedRef.current) setSpeaking(false); };
      window.speechSynthesis.speak(u);
    };
    withVoicesReady(say);
  }, []);

  useEffect(() => {
    if (phase === 'select') {
      speak('Welcome to the Aippie Enterprise Clinic Hub. Select your institutional products and I will guide your clinic integration.');
    } else if (phase === 'dashboard') {
      speak('Your enterprise clinic dashboard is now live. All AI triage modules are initialised and ready for deployment across your clinical network.');
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [phase]);

  const startCamera = useCallback(async () => {
    try {
      const s = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'user' }, audio: false });
      if (mountedRef.current) setCameraStream(s);
    } catch { /* denied */ }
  }, []);

  const handleProceedToDetails = () => {
    if (!buySetup && !buySaas) return;
    setPhase('details');
  };

  const handleProceedToPayment = () => {
    if (!clinicName.trim() || !contactName.trim() || !contactEmail.trim()) {
      setDetailsError('Please complete all fields before continuing.');
      return;
    }
    setDetailsError('');
    setPhase('payment');
  };

  const handlePayment = useCallback(async () => {
    const stripped = cardInput.replace(/\s/g, '');
    if (stripped.length < 16) {
      setCardError('Invalid card. Please enter a valid 16-digit number.');
      return;
    }
    setCardError('');
    setPhase('processing');

    const token = genSessionToken();
    const last4  = stripped.slice(-4);

    await supabase.from('enterprise_clinic_orders').insert({
      device_key:       deviceKey,
      clinic_name:      clinicName,
      contact_name:     contactName,
      contact_email:    contactEmail,
      product_setup:    buySetup,
      product_saas:     buySaas,
      setup_amount_usd: buySetup ? SETUP_PRICE_USD : 0,
      saas_amount_usd:  buySaas  ? SAAS_PRICE_USD  : 0,
      total_usd:        totalUSD,
      card_last4:       last4,
      status:           'active',
      session_token:    token,
    });

    await new Promise(r => setTimeout(r, 1800));
    if (!mountedRef.current) return;
    setSessionToken(token);
    setPhase('dashboard');
    startCamera();
  }, [cardInput, clinicName, contactName, contactEmail, buySetup, buySaas, totalUSD, deviceKey, startCamera]);

  // ── Phase: Select products ──────────────────────────────────────────────────
  if (phase === 'select') {
    return (
      <div className="ech-overlay">
        <div className="ech-modal">
          <button className="ech-close-btn" onClick={onClose} aria-label="Close"><ArrowLeft size={16}/> Back</button>

          <div className="ech-hero">
            <div className="ech-hero__icon-ring">
              <Building2 size={22} style={{ color: '#38bdf8' }} />
            </div>
            <div className="ech-hero__title">Enterprise Clinic Hub</div>
            <div className="ech-hero__sub">AIPPIETAX S.A. · B2B Institutional Integration · v141</div>
          </div>

          <p className="ech-intro">
            Designed for Arturo's corporate clinic network and enterprise healthcare partners.
            Select the integration packages your institution requires:
          </p>

          {/* Product cards */}
          <div className="ech-product-list">
            <button
              className={`ech-product-card${buySetup ? ' ech-product-card--selected' : ''}`}
              onClick={() => setBuySetup(v => !v)}
            >
              <div className="ech-product-card__top">
                <div className="ech-product-card__check">
                  {buySetup
                    ? <CheckCircle2 size={18} style={{ color: '#4ade80' }} />
                    : <div className="ech-product-card__uncheck" />
                  }
                </div>
                <div className="ech-product-card__body">
                  <div className="ech-product-card__name">Custom Clinic Integration Setup</div>
                  <div className="ech-product-card__desc">
                    Full white-label deployment, EHR mapping, staff onboarding, and dedicated integration engineer.
                  </div>
                </div>
                <div className="ech-product-card__price">$10,000</div>
              </div>
              <div className="ech-product-card__type">ONE-TIME</div>
              <ul className="ech-product-card__features">
                {['EHR / EMR system integration', 'HIPAA-compliant data pipeline', 'Custom branding & white-label', 'Dedicated onboarding engineer', 'Go-live in 5 business days'].map(f => (
                  <li key={f}><CheckCircle2 size={10} style={{ color: '#4ade80' }}/> {f}</li>
                ))}
              </ul>
            </button>

            <button
              className={`ech-product-card${buySaas ? ' ech-product-card--selected' : ''}`}
              onClick={() => setBuySaas(v => !v)}
            >
              <div className="ech-product-card__top">
                <div className="ech-product-card__check">
                  {buySaas
                    ? <CheckCircle2 size={18} style={{ color: '#38bdf8' }} />
                    : <div className="ech-product-card__uncheck" />
                  }
                </div>
                <div className="ech-product-card__body">
                  <div className="ech-product-card__name">AI Infrastructure SaaS Subscription</div>
                  <div className="ech-product-card__desc">
                    Monthly access to Aippie's full clinical AI suite: triage, biometrics, voice, and analytics.
                  </div>
                </div>
                <div className="ech-product-card__price" style={{ color: '#38bdf8' }}>$2,000<span style={{ fontSize: 10, opacity: 0.7 }}>/mo</span></div>
              </div>
              <div className="ech-product-card__type ech-product-card__type--saas">MONTHLY</div>
              <ul className="ech-product-card__features">
                {['Aippie AI Triage Engine', 'PPG biometrics & skin analysis', 'Autism CV 5-signal radar', 'Real-time voice assistant', 'Unlimited staff seats'].map(f => (
                  <li key={f}><CheckCircle2 size={10} style={{ color: '#38bdf8' }}/> {f}</li>
                ))}
              </ul>
            </button>
          </div>

          {/* Order summary */}
          <div className="ech-order-summary">
            <div className="ech-order-summary__row">
              <span>Setup</span>
              <span>{buySetup ? '$10,000.00' : '—'}</span>
            </div>
            <div className="ech-order-summary__row">
              <span>Monthly SaaS</span>
              <span>{buySaas ? '$2,000.00/mo' : '—'}</span>
            </div>
            <div className="ech-order-summary__divider" />
            <div className="ech-order-summary__total">
              <span>Due Today</span>
              <span>${totalUSD.toLocaleString('en-US', { minimumFractionDigits: 2 })}</span>
            </div>
          </div>

          <button
            className="ech-btn-primary"
            disabled={!buySetup && !buySaas}
            onClick={handleProceedToDetails}
          >
            <ChevronRight size={14} /> Continue to Clinic Details
          </button>

          <div className="ech-trust-row">
            <ShieldCheck size={11} style={{ color: '#4ade80' }} />
            <span>HIPAA · GDPR · ISO 27001 · PCI-DSS · 256-bit encryption</span>
          </div>
        </div>
      </div>
    );
  }

  // ── Phase: Clinic details ───────────────────────────────────────────────────
  if (phase === 'details') {
    return (
      <div className="ech-overlay">
        <div className="ech-modal">
          <button className="ech-close-btn" onClick={() => setPhase('select')}><ArrowLeft size={16}/> Back</button>

          <div className="ech-step-header">
            <Building2 size={16} style={{ color: '#38bdf8' }} />
            <span>Institutional Profile</span>
            <span className="ech-step-badge">Step 2 of 3</span>
          </div>

          <div className="ech-form">
            <label className="ech-form__label">Clinic / Hospital Name</label>
            <input
              className="ech-form__input"
              placeholder="e.g. Arturo Medical Network, Clínica Costa del Sol"
              value={clinicName}
              onChange={e => setClinicName(e.target.value)}
            />

            <label className="ech-form__label">Primary Contact Name</label>
            <input
              className="ech-form__input"
              placeholder="e.g. Arturo García"
              value={contactName}
              onChange={e => setContactName(e.target.value)}
            />

            <label className="ech-form__label">Contact Email</label>
            <input
              className="ech-form__input"
              type="email"
              placeholder="contact@yourclinic.com"
              value={contactEmail}
              onChange={e => setContactEmail(e.target.value)}
            />

            {detailsError && (
              <div className="ech-form__error">
                <AlertCircle size={12} /> {detailsError}
              </div>
            )}
          </div>

          <button className="ech-btn-primary" onClick={handleProceedToPayment}>
            <Lock size={14} /> Continue to Secure Payment
          </button>
        </div>
      </div>
    );
  }

  // ── Phase: Payment ──────────────────────────────────────────────────────────
  if (phase === 'payment') {
    return (
      <div className="ech-overlay">
        <div className="ech-modal">
          <button className="ech-close-btn" onClick={() => setPhase('details')}><ArrowLeft size={16}/> Back</button>

          <div className="ech-step-header">
            <CreditCard size={16} style={{ color: '#fbbf24' }} />
            <span>Secure Payment</span>
            <span className="ech-step-badge">Step 3 of 3</span>
          </div>

          <div className="ech-payment-summary">
            <div className="ech-payment-summary__clinic">{clinicName}</div>
            {buySetup && (
              <div className="ech-payment-summary__line">
                <span>Custom Integration Setup</span><span>$10,000.00</span>
              </div>
            )}
            {buySaas && (
              <div className="ech-payment-summary__line">
                <span>AI SaaS Subscription</span><span>$2,000.00/mo</span>
              </div>
            )}
            <div className="ech-payment-summary__divider" />
            <div className="ech-payment-summary__total">
              <span>Total Due Today</span>
              <span>${totalUSD.toLocaleString('en-US', { minimumFractionDigits: 2 })}</span>
            </div>
          </div>

          <div className="ech-pay-form">
            <label className="ech-form__label"><CreditCard size={11}/> Card Number</label>
            <input
              type="text"
              inputMode="numeric"
              placeholder="4242 4242 4242 4242"
              className={`ech-form__input ech-form__input--mono${cardError ? ' ech-form__input--error' : ''}`}
              value={cardInput}
              maxLength={19}
              onChange={e => { setCardError(''); setCardInput(formatCard(e.target.value)); }}
            />
            {cardError && (
              <div className="ech-form__error"><AlertCircle size={12}/> {cardError}</div>
            )}
            <div className="ech-pay-form__hint">
              Test mode · use card <span style={{ color: '#fbbf24' }}>4242 4242 4242 4242</span>
            </div>
            <button
              className="ech-btn-primary ech-btn-primary--pay"
              disabled={cardInput.replace(/\s/g, '').length < 16}
              onClick={handlePayment}
            >
              <Lock size={14} /> Confirm &amp; Activate Enterprise License
            </button>
          </div>

          <div className="ech-trust-row">
            <ShieldCheck size={11} style={{ color: '#4ade80' }} />
            <span>PCI-DSS Level 1 · 256-bit TLS · Funds held under AIPPIETAX S.A. escrow</span>
          </div>
        </div>
      </div>
    );
  }

  // ── Phase: Processing ───────────────────────────────────────────────────────
  if (phase === 'processing') {
    return (
      <div className="ech-overlay">
        <div className="ech-modal ech-modal--processing">
          <div className="ech-processing-ring">
            <RefreshCw size={32} className="ech-spin" />
          </div>
          <div className="ech-processing-title">Activating Enterprise License…</div>
          <div className="ech-processing-steps">
            {['Verifying payment', 'Provisioning clinic namespace', 'Initialising AI triage engine', 'Activating AnamAIController', 'Launching dashboard'].map((s, i) => (
              <div key={i} className="ech-processing-step">
                <RefreshCw size={10} className="ech-spin" style={{ color: '#38bdf8' }} />
                <span>{s}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  // ── Phase: Dashboard (unlocked) ─────────────────────────────────────────────
  return (
    <div className="ech-overlay">
      <div className="ech-modal ech-modal--dashboard">

        <div className="ech-dashboard-topbar">
          <div className="ech-dashboard-topbar__left">
            <span className="ech-dashboard-topbar__dot" />
            <span className="ech-dashboard-topbar__title">Enterprise Clinic Dashboard</span>
          </div>
          <div className="ech-dashboard-topbar__right">
            <span className="ech-dashboard-topbar__token">{sessionToken}</span>
            <button className="ech-close-btn ech-close-btn--inline" onClick={onClose}>
              <ArrowLeft size={14}/> Exit
            </button>
          </div>
        </div>

        {/* AnamAIController avatar face-to-face */}
        <AnamAIController speaking={speaking} subtitle={subtitle} cameraStream={cameraStream} />

        {/* 5-signal camera telemetry */}
        <div className="ech-telem-panel">
          <div className="ech-telem-header">
            <span className="ech-telem-dot" />
            <span>LIVE PIXEL TELEMETRY · 5-SIGNAL MEDIAPIPE STREAM</span>
          </div>
          <div className="ech-telem-signals">
            <TelemetryBar label="Facial Expressions" pct={cameraStream ? 87 : 0} color="#fb7185" icon={<Eye size={10}/>} />
            <TelemetryBar label="Hand Skeleton"      pct={cameraStream ? 82 : 0} color="#38bdf8" icon={<Activity size={10}/>} />
            <TelemetryBar label="Spine Canvas"       pct={cameraStream ? 78 : 0} color="#fbbf24" icon={<Zap size={10}/>} />
            <TelemetryBar label="Gaze Vector"        pct={cameraStream ? 91 : 0} color="#4ade80" icon={<Eye size={10}/>} />
            <TelemetryBar label="Posture Grid"       pct={cameraStream ? 80 : 0} color="#a78bfa" icon={<TrendingUp size={10}/>} />
          </div>
          {!cameraStream && (
            <div className="ech-telem-inactive">
              <button className="ech-btn-secondary ech-btn-secondary--sm" onClick={startCamera}>
                <Video size={12} /> Activate Camera Feed
              </button>
            </div>
          )}
        </div>

        {/* Clinic info strip */}
        <div className="ech-clinic-strip">
          <Building2 size={13} style={{ color: '#38bdf8' }} />
          <span className="ech-clinic-strip__name">{clinicName}</span>
          <span className="ech-clinic-strip__contact">{contactName} · {contactEmail}</span>
        </div>

        {/* Purchased products */}
        <div className="ech-active-products">
          {buySetup && (
            <div className="ech-active-product ech-active-product--setup">
              <CheckCircle2 size={12} style={{ color: '#4ade80' }} />
              <span>Custom Integration Setup · $10,000 — Active</span>
            </div>
          )}
          {buySaas && (
            <div className="ech-active-product ech-active-product--saas">
              <CheckCircle2 size={12} style={{ color: '#38bdf8' }} />
              <span>AI SaaS Subscription · $2,000/mo — Active</span>
            </div>
          )}
        </div>

        {/* Clinic modules */}
        <div className="ech-modules-title">Clinic AI Modules</div>
        <div className="ech-modules-grid">
          <ClinicModule icon={<Activity size={16}/>}   title="AI Triage Engine"     sub="Real-time patient intake routing"    color="#4ade80" />
          <ClinicModule icon={<Users size={16}/>}       title="Patient Records"      sub="HIPAA-encrypted EHR connector"       color="#38bdf8" />
          <ClinicModule icon={<Cpu size={16}/>}         title="Biometrics Suite"     sub="PPG · SpO2 · skin analysis"          color="#fbbf24" />
          <ClinicModule icon={<Mic size={16}/>}         title="Voice Intake"         sub="Multilingual AI receptionist"        color="#fb7185" />
          <ClinicModule icon={<Globe size={16}/>}       title="Autism Radar"         sub="5-signal CV triage integration"      color="#a78bfa" />
          <ClinicModule icon={<FileText size={16}/>}    title="Clinical Reports"     sub="Auto-generated discharge summaries"  color="#34d399" />
          <ClinicModule icon={<TrendingUp size={16}/>}  title="Revenue Analytics"    sub="Split-pay ledger & payout matrix"    color="#fbbf24" />
          <ClinicModule icon={<Phone size={16}/>}       title="Telehealth Gateway"   sub="Secure WebRTC consultation rooms"    color="#38bdf8" />
        </div>

        <div className="ech-dashboard-footer">
          <ShieldCheck size={10} style={{ color: '#4ade80' }} />
          AIPPIETAX S.A. · Enterprise Clinic Hub v141 · HIPAA · GDPR · ISO 27001
        </div>
      </div>
    </div>
  );
}
