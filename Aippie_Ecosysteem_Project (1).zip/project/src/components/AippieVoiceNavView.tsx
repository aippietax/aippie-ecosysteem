// @ts-nocheck
/**
 * AippieVoiceNavView — Real Voice AI + Battery Monitor + Face/Fingerprint Security
 * AIPPIETAX S.A. · Module 21
 */
import { useCallback, useEffect, useRef, useState } from 'react';
import {
  Mic, MicOff, ShieldCheck, ShieldAlert, Battery, BatteryCharging,
  BatteryWarning, Globe, Lock, Unlock, Fingerprint, Camera, CameraOff,
  AlertTriangle, CheckCircle2, X, Radio, Volume2, VolumeX,
  ExternalLink, Navigation,
} from 'lucide-react';
import { speakNatural, cancelSpeech } from '../lib/ttsVoice';
import { processAIOSCommand } from '../lib/aiosEngine';
import { logAIOSActivity } from '../lib/aiosLogger';
import { supabase } from '../lib/supabase';

const SUPABASE_URL      = import.meta.env.VITE_SUPABASE_URL as string;
const SUPABASE_ANON_KEY = import.meta.env.VITE_SUPABASE_ANON_KEY as string;

// ── Browser API type shims ────────────────────────────────────────────────────
declare global {
  interface Window {
    SpeechRecognition: new () => SpeechRecognitionI;
    webkitSpeechRecognition: new () => SpeechRecognitionI;
  }
}
interface SpeechRecognitionI extends EventTarget {
  lang: string; continuous: boolean; interimResults: boolean;
  start(): void; stop(): void; abort(): void;
  onresult: ((e: SpeechResultEvent) => void) | null;
  onend: (() => void) | null;
  onerror: ((e: { error: string }) => void) | null;
}
interface SpeechResultEvent extends Event {
  resultIndex: number;
  results: { length: number; [i: number]: { isFinal: boolean; [j: number]: { transcript: string } } };
}
interface BatteryManager extends EventTarget {
  level: number; charging: boolean;
  addEventListener(type: string, cb: () => void): void;
}

interface CommandResult {
  action: 'open_url' | 'navigate_tab' | 'answer' | 'call';
  url?: string; tab?: string; phone?: string; tts: string;
}

interface HistoryItem {
  id: string; command: string; response: string; action: string; ts: Date;
}

function getSR(): (new () => SpeechRecognitionI) | null {
  if (typeof window === 'undefined') return null;
  return window.SpeechRecognition ?? window.webkitSpeechRecognition ?? null;
}

// ── Waveform canvas ───────────────────────────────────────────────────────────
function Waveform({ active, color = '#38bdf8' }: { active: boolean; color?: string }) {
  const ref  = useRef<HTMLCanvasElement>(null);
  const fRef = useRef(0);
  const tk   = useRef(0);
  useEffect(() => {
    const c = ref.current; if (!c) return;
    const ctx = c.getContext('2d'); if (!ctx) return;
    const draw = () => {
      tk.current++;
      const t = tk.current, W = c.width, H = c.height;
      ctx.clearRect(0, 0, W, H);
      const bars = 28, gap = W / bars, bw = Math.max(2, gap - 2);
      for (let i = 0; i < bars; i++) {
        const ph = (i / bars) * Math.PI * 2;
        const h = active
          ? (0.12 + 0.88 * Math.abs(Math.sin(t * 0.07 + ph))) * H
          : (0.04 + 0.04 * Math.abs(Math.sin(t * 0.012 + ph))) * H;
        const x = i * gap + (gap - bw) / 2, y = (H - h) / 2;
        ctx.fillStyle = color + (active ? 'cc' : '22');
        ctx.beginPath(); ctx.roundRect(x, y, bw, h, 2); ctx.fill();
      }
      fRef.current = requestAnimationFrame(draw);
    };
    fRef.current = requestAnimationFrame(draw);
    return () => cancelAnimationFrame(fRef.current);
  }, [active, color]);
  return <canvas ref={ref} width={220} height={32} className="block" aria-hidden="true" />;
}

// ── Battery bar ───────────────────────────────────────────────────────────────
function BatteryBar({ level, charging }: { level: number; charging: boolean }) {
  const pct   = Math.round(level * 100);
  const color = pct <= 15 ? '#f87171' : pct <= 30 ? '#fbbf24' : '#4ade80';
  const Icon  = charging ? BatteryCharging : pct <= 15 ? BatteryWarning : Battery;
  return (
    <div className="flex items-center gap-2 text-xs">
      <Icon size={14} style={{ color }} />
      <div className="relative w-20 h-2 rounded-full bg-white/10 overflow-hidden">
        <div className="absolute inset-y-0 left-0 rounded-full transition-all duration-500"
          style={{ width: `${pct}%`, background: color }} />
      </div>
      <span style={{ color }} className="font-mono font-bold">{pct}%</span>
      {charging && <span className="text-emerald-400 text-[10px]">Charging</span>}
    </div>
  );
}

// ── Main component ────────────────────────────────────────────────────────────
export default function AippieVoiceNavView() {
  // Voice
  const [listening,    setListening]    = useState(false);
  const [processing,   setProcessing]   = useState(false);
  const [speaking,     setSpeaking]     = useState(false);
  const [muted,        setMuted]        = useState(false);
  const [interim,      setInterim]      = useState('');
  const [lastCommand,  setLastCommand]  = useState('');
  const [lastResponse, setLastResponse] = useState('Say something... I\'m listening.');
  const [lastAction,   setLastAction]   = useState('');
  const [history,      setHistory]      = useState<HistoryItem[]>([]);

  // Battery
  const [battery, setBattery] = useState<{ level: number; charging: boolean } | null>(null);
  const batteryAlerted = useRef<Set<number>>(new Set());

  // Security
  const [securityPanel,  setSecurityPanel]  = useState(false);
  const [biometricDone,  setBiometricDone]  = useState(false);
  const [biometricError, setBiometricError] = useState('');
  const [cameraOn,       setCameraOn]       = useState(false);
  const [intruderAlert,  setIntruderAlert]  = useState(false);
  const [faceDetected,   setFaceDetected]   = useState(false);

  const srRef       = useRef<SpeechRecognitionI | null>(null);
  const videoRef    = useRef<HTMLVideoElement>(null);
  const streamRef   = useRef<MediaStream | null>(null);
  const faceTimerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const canListen   = !!getSR();

  // ── Battery monitoring ──────────────────────────────────────────────────
  useEffect(() => {
    const nav = navigator as Navigator & { getBattery?: () => Promise<BatteryManager> };
    if (!nav.getBattery) return;
    let bm: BatteryManager;
    const update = () => {
      if (!bm) return;
      setBattery({ level: bm.level, charging: bm.charging });
      const pct = Math.round(bm.level * 100);
      if (!bm.charging) {
        [20, 10].forEach(threshold => {
          if (pct <= threshold && !batteryAlerted.current.has(threshold)) {
            batteryAlerted.current.add(threshold);
            speakNatural(
              `Warning, your battery is only ${pct} percent. Plug your phone into the charger.`,
              { lang: 'en' },
            );
          }
        });
      } else {
        batteryAlerted.current.clear();
      }
    };
    nav.getBattery().then(manager => {
      bm = manager;
      update();
      bm.addEventListener('levelchange',    update);
      bm.addEventListener('chargingchange', update);
    }).catch(() => {});
  }, []);

  // ── speak() ─────────────────────────────────────────────────────────────
  const speak = useCallback((text: string) => {
    if (muted) return;
    cancelSpeech();
    setSpeaking(true);
    speakNatural(text, { onEnd: () => setSpeaking(false) });
  }, [muted]);

  // ── Welcome on mount ─────────────────────────────────────────────────────
  useEffect(() => {
    const t = setTimeout(() => {
      speak('Aippie Voice AI active. Press the microphone and give a command.');
    }, 500);
    return () => {
      clearTimeout(t);
      cancelSpeech();
      if (faceTimerRef.current) clearInterval(faceTimerRef.current);
      streamRef.current?.getTracks().forEach(tr => tr.stop());
    };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // ── Process voice command: AI-OS engine first, edge function fallback ──────
  const processCommand = useCallback(async (text: string) => {
    setProcessing(true);
    setLastCommand(text);
    setInterim('');
    try {
      // Client-side AI-OS intent router (instant, zero-latency)
      const aiosResult = await processAIOSCommand({
        rawText: text,
        timestamp: Date.now(),
        source: 'voice',
      });

      if (aiosResult.status === 'SUCCESS' && aiosResult.confidence > 0.05) {
        setLastResponse(aiosResult.actionTaken);
        setLastAction(aiosResult.navigateTab ? 'navigate_tab' : 'aios');
        setHistory(prev => [{
          id: crypto.randomUUID(), command: text,
          response: aiosResult.actionTaken, action: aiosResult.navigateTab ? 'navigate_tab' : 'aios', ts: new Date(),
        }, ...prev.slice(0, 9)]);
        if (aiosResult.navigateTab) {
          window.dispatchEvent(new CustomEvent('aippie-navigate', { detail: aiosResult.navigateTab }));
        }
        speak(aiosResult.actionTaken);
        // Fire-and-forget: log to Supabase
        supabase.auth.getUser().then(({ data }) => {
          if (data.user) {
            logAIOSActivity({
              user_id:      data.user.id,
              raw_text:     text,
              intent:       aiosResult.intent,
              confidence:   aiosResult.confidence,
              status:       aiosResult.status,
              action_taken: aiosResult.actionTaken,
            });
          }
        });
        setProcessing(false);
        return;
      }

      // Fallback: cloud edge function for unknown commands
      const res = await fetch(`${SUPABASE_URL}/functions/v1/voice-command`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${SUPABASE_ANON_KEY}`,
        },
        body: JSON.stringify({ command: text, lang: 'auto' }),
      });
      const result: CommandResult = await res.json();

      setLastResponse(result.tts ?? '');
      setLastAction(result.action);
      setHistory(prev => [{
        id: crypto.randomUUID(), command: text,
        response: result.tts ?? '', action: result.action, ts: new Date(),
      }, ...prev.slice(0, 9)]);

      if (result.action === 'open_url' && result.url) {
        window.open(result.url, '_blank', 'noopener,noreferrer');
      } else if (result.action === 'navigate_tab' && result.tab) {
        window.dispatchEvent(new CustomEvent('aippie-navigate', { detail: result.tab }));
      } else if (result.action === 'call' && result.phone) {
        window.open(`tel:${result.phone}`);
      }

      speak(result.tts ?? '');
    } catch {
      const err = 'Sorry, something went wrong. Try again.';
      setLastResponse(err);
      speak(err);
    } finally {
      setProcessing(false);
    }
  }, [speak]);

  // ── STT ─────────────────────────────────────────────────────────────────
  const startListening = useCallback(() => {
    const SR = getSR();
    if (!SR || listening) return;
    srRef.current?.abort();
    const rec = new SR();
    srRef.current = rec;
    rec.lang = 'nl-NL';
    rec.continuous = false;
    rec.interimResults = true;
    rec.onresult = (e: SpeechResultEvent) => {
      let fin = '', int = '';
      for (let i = e.resultIndex; i < e.results.length; i++) {
        const t = e.results[i][0].transcript;
        if (e.results[i].isFinal) fin += t; else int += t;
      }
      setInterim(int);
      if (fin.trim()) processCommand(fin.trim());
    };
    rec.onend  = () => setListening(false);
    rec.onerror = () => { setListening(false); setInterim(''); };
    try { rec.start(); setListening(true); setInterim(''); } catch { setListening(false); }
  }, [listening, processCommand]);

  const stopListening = useCallback(() => {
    srRef.current?.stop();
    setListening(false);
    setInterim('');
  }, []);

  // ── Camera / face detection ──────────────────────────────────────────────
  const stopCamera = useCallback(() => {
    if (faceTimerRef.current) clearInterval(faceTimerRef.current);
    streamRef.current?.getTracks().forEach(t => t.stop());
    streamRef.current = null;
    setCameraOn(false);
    setFaceDetected(false);
    setIntruderAlert(false);
  }, []);

  const startCamera = useCallback(async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'user' }, audio: false,
      });
      streamRef.current = stream;
      if (videoRef.current) videoRef.current.srcObject = stream;
      setCameraOn(true);

      const canvas = document.createElement('canvas');
      const ctx    = canvas.getContext('2d');
      if (!ctx) return;
      canvas.width = 80; canvas.height = 60;

      let lastHadFace = false;
      faceTimerRef.current = setInterval(() => {
        if (!videoRef.current || !ctx) return;
        ctx.drawImage(videoRef.current, 0, 0, 80, 60);
        const data = ctx.getImageData(0, 0, 80, 60).data;
        let skinPixels = 0;
        for (let i = 0; i < data.length; i += 4) {
          const r = data[i], g = data[i + 1], b = data[i + 2];
          if (r > 95 && g > 40 && b > 20 && r > g && r > b &&
              Math.abs(r - g) > 15 && r - b > 20) skinPixels++;
        }
        const hasFace = (skinPixels / (80 * 60)) > 0.08;
        setFaceDetected(hasFace);
        if (hasFace && !lastHadFace && !biometricDone) {
          setIntruderAlert(true);
          speakNatural('Warning! Unknown face detected. Authentication required.', { lang: 'en' });
        }
        lastHadFace = hasFace;
      }, 1500);
    } catch {
      setCameraOn(false);
    }
  }, [biometricDone]);

  const toggleCamera = useCallback(() => {
    if (cameraOn) stopCamera(); else startCamera();
  }, [cameraOn, startCamera, stopCamera]);

  // ── WebAuthn biometrics ──────────────────────────────────────────────────
  const enrollBiometric = useCallback(async () => {
    setBiometricError('');
    if (!window.PublicKeyCredential) {
      setBiometricError('WebAuthn is not supported on this device.');
      return;
    }
    try {
      const challenge = crypto.getRandomValues(new Uint8Array(32));
      const userId    = crypto.getRandomValues(new Uint8Array(16));
      await navigator.credentials.create({
        publicKey: {
          challenge,
          rp: { name: 'Aippie Security', id: window.location.hostname },
          user: { id: userId, name: 'aippie-user', displayName: 'Aippie User' },
          pubKeyCredParams: [{ alg: -7, type: 'public-key' }],
          authenticatorSelection: {
            authenticatorAttachment: 'platform',
            userVerification: 'required',
          },
          timeout: 60000,
        },
      });
      setBiometricDone(true);
      setIntruderAlert(false);
      localStorage.setItem('aippie_biometric_enrolled', '1');
      speak('Biometric authentication set up. Your phone is now secure.');
    } catch (e: unknown) {
      const msg = e instanceof Error ? e.message : String(e);
      setBiometricError(
        msg.includes('cancel') || msg.includes('NotAllowed')
          ? 'Cancelled. Try again.'
          : 'Setup failed. Make sure your fingerprint or Face ID is available.',
      );
    }
  }, [speak]);

  const verifyBiometric = useCallback(async () => {
    setBiometricError('');
    if (!window.PublicKeyCredential) { setBiometricError('WebAuthn not available.'); return; }
    try {
      const challenge = crypto.getRandomValues(new Uint8Array(32));
      await navigator.credentials.get({
        publicKey: { challenge, userVerification: 'required', timeout: 60000 },
      });
      setIntruderAlert(false);
      setBiometricDone(true);
      speak('Identity verified. Access granted.');
    } catch {
      speak('Authentication failed. Try again.');
    }
  }, [speak]);

  useEffect(() => {
    if (localStorage.getItem('aippie_biometric_enrolled') === '1') setBiometricDone(true);
  }, []);

  // ── Action icon helper ────────────────────────────────────────────────────
  const ActionIcon = () => {
    if (lastAction === 'open_url')     return <ExternalLink size={12} className="text-sky-400" />;
    if (lastAction === 'navigate_tab') return <Navigation size={12} className="text-violet-400" />;
    if (lastAction === 'call')         return <Mic size={12} className="text-green-400" />;
    return <Globe size={12} className="text-slate-400" />;
  };

  // ── Render ────────────────────────────────────────────────────────────────
  return (
    <div className="min-h-screen bg-[#030712] text-white flex flex-col relative overflow-hidden">

      {/* Ambient glow */}
      <div className="absolute inset-0 pointer-events-none" aria-hidden="true">
        <div className="absolute top-0 left-1/4 w-96 h-96 rounded-full opacity-10"
          style={{ background: 'radial-gradient(circle, #0ea5e9, transparent)' }} />
        <div className="absolute bottom-0 right-1/4 w-80 h-80 rounded-full opacity-8"
          style={{ background: 'radial-gradient(circle, #7c3aed, transparent)' }} />
      </div>

      {/* Intruder alert overlay */}
      {intruderAlert && (
        <div className="absolute inset-0 z-50 flex items-center justify-center"
          style={{ background: 'rgba(239,68,68,0.15)', backdropFilter: 'blur(4px)' }}>
          <div className="bg-red-900/90 border border-red-500 rounded-2xl p-6 max-w-xs mx-4 text-center shadow-2xl">
            <AlertTriangle size={40} className="text-red-400 mx-auto mb-3" />
            <div className="text-red-300 font-bold text-lg mb-1">WARNING</div>
            <div className="text-red-200 text-sm mb-4">
              Unknown face detected.<br />Authenticate yourself to continue.
            </div>
            <div className="flex gap-2">
              <button
                onClick={verifyBiometric}
                className="flex-1 flex items-center justify-center gap-2 bg-red-600 hover:bg-red-500 rounded-xl py-2.5 text-sm font-semibold transition-colors"
              >
                <Fingerprint size={15} /> Verify
              </button>
              <button
                onClick={() => setIntruderAlert(false)}
                className="flex items-center justify-center bg-slate-700 hover:bg-slate-600 rounded-xl px-3 transition-colors"
              >
                <X size={15} />
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Top bar */}
      <div className="relative z-10 flex items-center justify-between px-4 pt-4 pb-2">
        <div className="flex items-center gap-2">
          <div className="w-2 h-2 rounded-full bg-sky-400 animate-pulse" />
          <span className="text-[11px] text-slate-400 font-mono tracking-widest">AIPPIE VOICE AI</span>
        </div>
        <div className="flex items-center gap-3">
          {battery && <BatteryBar level={battery.level} charging={battery.charging} />}
          <button
            onClick={() => { setMuted(m => !m); if (!muted) cancelSpeech(); }}
            className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 transition-colors"
          >
            {muted
              ? <VolumeX size={13} className="text-slate-400" />
              : <Volume2 size={13} className="text-sky-400" />}
          </button>
          <button
            onClick={() => setSecurityPanel(p => !p)}
            className={`p-1.5 rounded-lg transition-colors ${securityPanel ? 'bg-violet-600/40' : 'bg-white/5 hover:bg-white/10'}`}
          >
            {biometricDone
              ? <ShieldCheck size={13} className="text-emerald-400" />
              : <ShieldAlert size={13} className="text-amber-400" />}
          </button>
        </div>
      </div>

      {/* Main voice area */}
      <div className="relative z-10 flex-1 flex flex-col items-center px-4 pt-2">

        {/* Avatar with pulse rings */}
        <div className="relative mb-4">
          {speaking && (
            <div className="absolute inset-0 rounded-full animate-ping opacity-20"
              style={{ background: 'radial-gradient(circle, #38bdf8, transparent)' }} />
          )}
          <div className={`relative rounded-full overflow-hidden border-2 transition-colors duration-300 ${
            speaking ? 'border-sky-400 shadow-lg shadow-sky-400/30' : 'border-white/10'
          }`} style={{ width: 90, height: 90 }}>
            <img
              src="/Jouw_alineatekst_(2).png"
              alt="Aippie"
              className="w-full h-full object-cover"
              onError={e => {
                (e.currentTarget as HTMLImageElement).src =
                  'https://images.pexels.com/photos/1858175/pexels-photo-1858175.jpeg?auto=compress&cs=tinysrgb&w=200&h=200&fit=crop&crop=faces';
              }}
            />
          </div>
          {speaking && (
            <div className="absolute -bottom-1 -right-1 w-5 h-5 rounded-full bg-sky-500 flex items-center justify-center">
              <Volume2 size={10} className="text-white" />
            </div>
          )}
        </div>

        {/* Waveform */}
        <Waveform active={listening || speaking} color={listening ? '#f87171' : '#38bdf8'} />

        {/* Status */}
        <div className="mt-2 mb-1 text-xs font-mono text-slate-400 h-4 text-center">
          {processing ? 'AI processing...' :
           listening  ? 'Listening...' :
           speaking   ? 'Aippie is speaking...' :
           'Press the microphone'}
        </div>

        {/* Interim transcript */}
        {interim && (
          <div className="text-sky-300 text-sm italic px-4 text-center mb-1">
            "{interim}"
          </div>
        )}

        {/* Big mic button */}
        <button
          onClick={listening ? stopListening : startListening}
          disabled={!canListen || processing}
          className={`mt-3 w-16 h-16 rounded-full flex items-center justify-center transition-all duration-200 shadow-lg ${
            listening
              ? 'bg-red-500 hover:bg-red-400 shadow-red-500/40 scale-110'
              : processing
              ? 'bg-slate-700 cursor-wait'
              : 'bg-sky-500 hover:bg-sky-400 shadow-sky-500/30 active:scale-95'
          }`}
          aria-label={listening ? 'Stop listening' : 'Start listening'}
        >
          {listening
            ? <Radio size={24} className="text-white animate-pulse" />
            : processing
            ? <div className="w-5 h-5 border-2 border-white/40 border-t-white rounded-full animate-spin" />
            : <Mic size={24} className="text-white" />}
        </button>

        {!canListen && (
          <div className="mt-2 text-xs text-amber-400 flex items-center gap-1">
            <MicOff size={11} /> Speech recognition not available in this browser
          </div>
        )}

        {/* Last command + response */}
        <div className="w-full max-w-sm mt-5 space-y-2">
          {lastCommand && (
            <div className="bg-white/5 rounded-xl p-3 border border-white/8">
              <div className="text-[10px] text-slate-500 mb-1 uppercase tracking-wider">You said</div>
              <div className="text-sm text-white">{lastCommand}</div>
            </div>
          )}
          <div className="bg-sky-950/60 rounded-xl p-3 border border-sky-800/40">
            <div className="flex items-center gap-1.5 mb-1">
              <ActionIcon />
              <div className="text-[10px] text-sky-400 uppercase tracking-wider">Aippie</div>
            </div>
            <div className="text-sm text-sky-100">{lastResponse}</div>
          </div>
        </div>

        {/* Quick command shortcuts */}
        <div className="w-full max-w-sm mt-4">
          <div className="text-[10px] text-slate-500 uppercase tracking-wider mb-2">Quick commands</div>
          <div className="flex flex-wrap gap-1.5">
            {['Open Google', 'Open YouTube', 'Ga naar dokter', 'Ga naar belasting', 'Wat is het weer?'].map(cmd => (
              <button
                key={cmd}
                onClick={() => processCommand(cmd)}
                disabled={processing || listening}
                className="text-[11px] px-2.5 py-1 rounded-lg bg-white/5 hover:bg-white/10 border border-white/8 text-slate-300 transition-colors disabled:opacity-40"
              >
                {cmd}
              </button>
            ))}
          </div>
        </div>

        {/* History */}
        {history.length > 0 && (
          <div className="w-full max-w-sm mt-4 mb-6">
            <div className="text-[10px] text-slate-500 uppercase tracking-wider mb-2">History</div>
            <div className="space-y-1.5">
              {history.slice(0, 4).map(item => (
                <div key={item.id}
                  className="flex items-start gap-2 text-xs text-slate-500 bg-white/3 rounded-lg px-3 py-2">
                  <span className="text-slate-400 font-medium shrink-0">
                    {item.command.slice(0, 28)}{item.command.length > 28 ? '…' : ''}
                  </span>
                  <span className="shrink-0">→</span>
                  <span className="text-slate-600 italic">
                    {item.response.slice(0, 48)}{item.response.length > 48 ? '…' : ''}
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Security panel */}
      {securityPanel && (
        <div className="relative z-10 mx-4 mb-4 bg-slate-900/90 border border-violet-800/40 rounded-2xl p-4 backdrop-blur-md">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <ShieldCheck size={14} className="text-violet-400" />
              <span className="text-sm font-semibold text-violet-300">Security</span>
            </div>
            <button onClick={() => setSecurityPanel(false)} className="text-slate-500 hover:text-slate-300">
              <X size={14} />
            </button>
          </div>

          {/* Biometric */}
          <div className="mb-3">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs text-slate-300">Fingerprint / Face ID</span>
              {biometricDone
                ? <span className="flex items-center gap-1 text-xs text-emerald-400"><CheckCircle2 size={11} /> Enabled</span>
                : <span className="flex items-center gap-1 text-xs text-amber-400"><Lock size={11} /> Not set up</span>}
            </div>
            <div className="flex gap-2">
              <button
                onClick={enrollBiometric}
                className="flex-1 flex items-center justify-center gap-1.5 text-xs bg-violet-600 hover:bg-violet-500 rounded-lg py-2 transition-colors"
              >
                <Fingerprint size={12} />
                {biometricDone ? 'Reset' : 'Set up'}
              </button>
              {biometricDone && (
                <button
                  onClick={verifyBiometric}
                  className="flex items-center justify-center gap-1.5 text-xs bg-emerald-700 hover:bg-emerald-600 rounded-lg px-3 py-2 transition-colors"
                >
                  <Unlock size={12} /> Verify
                </button>
              )}
            </div>
            {biometricError && (
              <div className="mt-1.5 text-xs text-red-400 flex items-center gap-1">
                <AlertTriangle size={10} /> {biometricError}
              </div>
            )}
          </div>

          {/* Camera / intrusion monitor */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs text-slate-300">Intruder monitoring</span>
              <span className={`text-xs ${cameraOn ? 'text-emerald-400' : 'text-slate-500'}`}>
                {cameraOn ? (faceDetected ? 'Face detected' : 'Active') : 'Off'}
              </span>
            </div>
            <button
              onClick={toggleCamera}
              className={`w-full flex items-center justify-center gap-1.5 text-xs rounded-lg py-2 transition-colors ${
                cameraOn
                  ? 'bg-red-700/60 hover:bg-red-700 border border-red-600/40'
                  : 'bg-slate-700 hover:bg-slate-600 border border-slate-600/40'
              }`}
            >
              {cameraOn ? <><CameraOff size={12} /> Stop monitoring</> : <><Camera size={12} /> Start monitoring</>}
            </button>
            {cameraOn && (
              <div className="mt-2 relative rounded-lg overflow-hidden bg-black">
                <video
                  ref={videoRef}
                  autoPlay muted playsInline
                  className="w-full rounded-lg"
                  style={{ maxHeight: 120, objectFit: 'cover' }}
                />
                {faceDetected && (
                  <div className="absolute top-1.5 left-1.5 text-[10px] bg-red-600 px-1.5 py-0.5 rounded text-white animate-pulse">
                    Face detected
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
