import { useEffect, useRef, useState } from 'react';
import { Shield, Lock, Send, Inbox, SquarePen as PenSquare, ArrowLeft, Clock, Eye, EyeOff, Trash2, RefreshCw, AlertTriangle, CheckCircle2, Mail, Skull, ChevronRight, X, Check } from 'lucide-react';
import { supabase } from '../lib/supabase';
import type { User } from '@supabase/supabase-js';

type Screen = 'loading' | 'no_pin' | 'inbox' | 'sent' | 'compose' | 'read' | 'guardian';

interface MailItem {
  id: string;
  from_pin: string;
  to_pin: string;
  subject: string;
  body: string;
  is_read: boolean;
  read_at: string | null;
  opened_at: string | null;
  expires_at: string | null;
  destroy_after: number;
  is_deleted: boolean;
  created_at: string;
}

const TIMER_OPTIONS = [
  { label: '1 min',  value: 60 },
  { label: '3 min',  value: 180 },
  { label: '5 min',  value: 300 },
  { label: '10 min', value: 600 },
  { label: 'None',   value: 0 },
];

function dlpScan(text: string): string | null {
  if (/\b[A-Z]{2}\d{6,9}\b/.test(text)) return 'Possible passport number detected';
  if (/\b[A-Z]{2}\d{2}[A-Z0-9]{4}\d{7}([A-Z0-9]{0,16})?\b/.test(text)) return 'Possible IBAN detected';
  if (/\b\d{16}\b/.test(text.replace(/[ -]/g, ''))) return 'Possible credit card number detected';
  if (/\b\d{3}-\d{2}-\d{4}\b/.test(text)) return 'Possible BSN/SSN detected';
  if (/-----BEGIN (?:RSA |EC )?PRIVATE KEY-----/.test(text)) return 'Private key detected — NEVER send!';
  return null;
}

function timeAgo(ts: string): string {
  const d = Date.now() - new Date(ts).getTime();
  if (d < 60000) return 'just now';
  if (d < 3600000) return `${Math.floor(d / 60000)} min ago`;
  if (d < 86400000) return `${Math.floor(d / 3600000)} hour${Math.floor(d / 3600000) === 1 ? '' : 's'} ago`;
  return `${Math.floor(d / 86400000)} day${Math.floor(d / 86400000) === 1 ? '' : 's'} ago`;
}

function formatCountdown(s: number): string {
  const m = Math.floor(s / 60);
  const sec = s % 60;
  return m > 0 ? `${m}:${String(sec).padStart(2, '0')}` : `${s}s`;
}

export default function AippieMailView({ user }: { user: User | null }) {
  const [screen, setScreen]       = useState<Screen>('loading');
  const [myPin, setMyPin]         = useState<string | null>(null);
  const [inbox, setInbox]         = useState<MailItem[]>([]);
  const [sent, setSent]           = useState<MailItem[]>([]);
  const [activeMail, setActiveMail] = useState<MailItem | null>(null);
  const [contacts, setContacts]   = useState<Record<string, string>>({});

  // Compose
  const [toPin, setToPin]         = useState('');
  const [subject, setSubject]     = useState('');
  const [body, setBody]           = useState('');
  const [destroyAfter, setDestroyAfter] = useState(180);
  const [sending, setSending]     = useState(false);
  const [sendError, setSendError] = useState('');
  const [dlpWarning, setDlpWarning] = useState<string | null>(null);
  const [dlpBypass, setDlpBypass] = useState(false);

  // Guardian
  const [guardianPin, setGuardianPin]     = useState('');
  const [guardianError, setGuardianError] = useState('');
  const [pendingMailId, setPendingMailId] = useState<string | null>(null);
  const prevScreenRef = useRef<Screen>('inbox');
  const [strikeCount, setStrikeCount]     = useState(0);
  const [lockdownUntil, setLockdownUntil] = useState<Date | null>(null);
  const [lockdownSecs, setLockdownSecs]   = useState(0);

  // Reading countdown
  const [countdown, setCountdown] = useState<number | null>(null);
  const countdownRef = useRef<ReturnType<typeof setInterval> | null>(null);

  // Blur protection
  const [blurred, setBlurred]     = useState(false);

  // Tab
  const [tab, setTab]             = useState<'inbox' | 'sent'>('inbox');

  useEffect(() => {
    const onHide  = () => setBlurred(true);
    const onShow  = () => { if (!document.hidden) setBlurred(false); };
    const onBlur  = () => setBlurred(true);
    const onFocus = () => setBlurred(false);
    document.addEventListener('visibilitychange', onShow);
    window.addEventListener('blur', onBlur);
    window.addEventListener('focus', onFocus);
    return () => {
      document.removeEventListener('visibilitychange', onShow);
      window.removeEventListener('blur', onBlur);
      window.removeEventListener('focus', onFocus);
    };
    void onHide;
  }, []);

  // Init — load PIN
  useEffect(() => {
    if (!user) { setScreen('no_pin'); return; }
    const init = async () => {
      const { data } = await supabase
        .from('secure_chat_pins').select('pin_code')
        .eq('user_id', user.id).maybeSingle();
      if (!data) { setScreen('no_pin'); return; }
      setMyPin(data.pin_code);

      // Load contact names
      const { data: ctcs } = await supabase
        .from('secure_chat_contacts').select('contact_pin, nickname')
        .eq('owner_pin', data.pin_code);
      const map: Record<string, string> = {};
      (ctcs ?? []).forEach((c: { contact_pin: string; nickname?: string }) => {
        map[c.contact_pin] = c.nickname ?? c.contact_pin;
      });
      setContacts(map);

      await loadMail(data.pin_code);
      setScreen('inbox');
    };
    init();
  }, [user]); // eslint-disable-line

  // Realtime — new inbound mail
  useEffect(() => {
    if (!myPin) return;
    const ch = supabase.channel('aippie_mail_realtime')
      .on('postgres_changes', {
        event: 'INSERT', schema: 'public', table: 'aippie_mail',
        filter: `to_pin=eq.${myPin}`,
      }, (payload) => {
        setInbox(prev => [payload.new as MailItem, ...prev]);
      })
      .on('postgres_changes', {
        event: 'UPDATE', schema: 'public', table: 'aippie_mail',
      }, (payload) => {
        const updated = payload.new as MailItem;
        setInbox(prev => prev.map(m => m.id === updated.id ? updated : m));
        setSent(prev => prev.map(m => m.id === updated.id ? updated : m));
        if (activeMail?.id === updated.id) setActiveMail(updated);
      })
      .subscribe();
    return () => { supabase.removeChannel(ch); };
  }, [myPin, activeMail?.id]);

  // Countdown timer when reading
  useEffect(() => {
    if (screen !== 'read' || !activeMail?.expires_at) {
      if (countdownRef.current) { clearInterval(countdownRef.current); countdownRef.current = null; }
      setCountdown(null);
      return;
    }
    const tick = () => {
      const remaining = Math.max(0, Math.ceil((new Date(activeMail.expires_at!).getTime() - Date.now()) / 1000));
      setCountdown(remaining);
      if (remaining === 0) {
        if (countdownRef.current) { clearInterval(countdownRef.current); countdownRef.current = null; }
        // Soft-delete both sides
        supabase.from('aippie_mail').update({ is_deleted: true }).eq('id', activeMail.id).then(() => {
          setInbox(prev => prev.filter(m => m.id !== activeMail.id));
          setSent(prev => prev.filter(m => m.id !== activeMail.id));
          setActiveMail(null);
          setScreen(prevScreenRef.current);
        });
      }
    };
    tick();
    countdownRef.current = setInterval(tick, 1000);
    return () => { if (countdownRef.current) { clearInterval(countdownRef.current); countdownRef.current = null; } };
  }, [screen, activeMail?.expires_at]); // eslint-disable-line

  // Lockdown countdown
  useEffect(() => {
    if (!lockdownUntil) return;
    const interval = setInterval(() => {
      const remaining = Math.max(0, Math.ceil((lockdownUntil.getTime() - Date.now()) / 1000));
      setLockdownSecs(remaining);
      if (remaining === 0) { clearInterval(interval); setLockdownUntil(null); setStrikeCount(0); }
    }, 1000);
    return () => clearInterval(interval);
  }, [lockdownUntil]);

  const loadMail = async (pin: string) => {
    const { data: inboxData } = await supabase
      .from('aippie_mail').select('*')
      .eq('to_pin', pin).eq('is_deleted', false)
      .order('created_at', { ascending: false }).limit(50);
    setInbox((inboxData ?? []) as MailItem[]);

    const { data: sentData } = await supabase
      .from('aippie_mail').select('*')
      .eq('from_pin', pin).eq('is_deleted', false)
      .order('created_at', { ascending: false }).limit(50);
    setSent((sentData ?? []) as MailItem[]);
  };

  const openMail = (mail: MailItem) => {
    setActiveMail(mail);
    setPendingMailId(mail.id);
    prevScreenRef.current = tab;
    setGuardianPin(''); setGuardianError('');
    setScreen('guardian');
  };

  const handleGuardian = async () => {
    if (!myPin) return;
    if (lockdownUntil && lockdownUntil > new Date()) return;

    if (guardianPin !== myPin) {
      const next = strikeCount + 1;
      setStrikeCount(next);
      setGuardianPin('');
      if (next >= 3) {
        const until = new Date(Date.now() + 5 * 60 * 1000);
        setLockdownUntil(until);
        setLockdownSecs(300);
        setGuardianError('LOCKDOWN: 3 failed attempts. Mail locked for 5 minutes.');
      } else {
        setGuardianError(`Wrong PIN — ${3 - next} attempt${3 - next === 1 ? '' : 's'} remaining.`);
      }
      return;
    }

    setGuardianError(''); setStrikeCount(0);
    const mail = inbox.find(m => m.id === pendingMailId) ?? sent.find(m => m.id === pendingMailId);
    if (!mail) { setScreen(prevScreenRef.current as Screen); return; }

    // Mark read + set expires_at if not yet opened
    const now = new Date().toISOString();
    const expiresAt = mail.destroy_after > 0 && !mail.opened_at
      ? new Date(Date.now() + mail.destroy_after * 1000).toISOString()
      : mail.expires_at;
    const updates: Partial<MailItem> = { is_read: true, read_at: now };
    if (!mail.opened_at) {
      updates.opened_at = now;
      if (expiresAt) updates.expires_at = expiresAt;
    }
    await supabase.from('aippie_mail').update(updates).eq('id', mail.id);
    setActiveMail({ ...mail, ...updates } as MailItem);
    setInbox(prev => prev.map(m => m.id === mail.id ? { ...m, ...updates } as MailItem : m));
    setScreen('read');
  };

  const handleDelete = async (mailId: string) => {
    await supabase.from('aippie_mail').update({ is_deleted: true }).eq('id', mailId);
    setInbox(prev => prev.filter(m => m.id !== mailId));
    setSent(prev => prev.filter(m => m.id !== mailId));
    if (activeMail?.id === mailId) { setActiveMail(null); setScreen(prevScreenRef.current as Screen); }
  };

  const handleSend = async () => {
    if (!myPin) return;
    setSendError('');

    if (!dlpBypass) {
      const w = dlpScan(body) ?? dlpScan(subject);
      if (w) { setDlpWarning(w); return; }
    }
    setDlpWarning(null); setDlpBypass(false);

    if (!toPin.trim() || toPin.length !== 5) { setSendError('Enter a valid 5-digit PIN.'); return; }
    if (!body.trim()) { setSendError('Message cannot be empty.'); return; }

    // Check recipient PIN exists
    const { data: rec } = await supabase
      .from('secure_chat_pins').select('pin_code')
      .eq('pin_code', toPin.trim()).maybeSingle();
    if (!rec) { setSendError('PIN not found. Recipient must have a SecureChat profile.'); return; }

    setSending(true);
    const { error } = await supabase.from('aippie_mail').insert({
      from_pin: myPin,
      to_pin: toPin.trim(),
      subject: subject.trim() || '(geen onderwerp)',
      body: body.trim(),
      destroy_after: destroyAfter,
    });
    setSending(false);
    if (error) { setSendError('Send failed: ' + error.message); return; }

    // Reload sent
    await loadMail(myPin);
    setToPin(''); setSubject(''); setBody(''); setDestroyAfter(180);
    setTab('sent');
    setScreen('sent');
  };

  // ── Guard ─────────────────────────────────────────────────────────────────
  if (!user) {
    return (
      <div className="aml-root">
        <div className="aml-empty"><Lock size={38} className="aml-empty__icon" /><p>Log in to use Aippie Mail</p></div>
      </div>
    );
  }

  if (screen === 'loading') {
    return <div className="aml-root"><div className="aml-empty"><span className="aml-spinner" /></div></div>;
  }

  if (screen === 'no_pin') {
    return (
      <div className="aml-root">
        <div className="aml-empty">
          <Mail size={38} className="aml-empty__icon" />
          <p className="aml-empty__title">No SecureChat profile</p>
          <p className="aml-empty__sub">Open SecureChat first and create a PIN profile. That profile is also your Aippie Mail address.</p>
        </div>
      </div>
    );
  }

  // ── Guardian ─────────────────────────────────────────────────────────────
  if (screen === 'guardian') {
    const isLockedDown = lockdownUntil && lockdownUntil > new Date();
    return (
      <div className="aml-root">
        <div className="aml-guardian">
          <div className={`aml-guardian__ring${isLockedDown ? ' aml-guardian__ring--locked' : ''}`}>
            {isLockedDown ? <Lock size={32} style={{ color: '#ef4444' }} /> : <Eye size={32} style={{ color: '#22d3ee' }} />}
          </div>
          <h2 className="aml-guardian__title">
            {isLockedDown ? 'Inbox Locked' : 'AippieShield Verification'}
          </h2>
          {isLockedDown ? (
            <>
              <p className="aml-guardian__sub aml-guardian__sub--danger">3 failed attempts detected</p>
              <div className="aml-lockdown-timer">
                <span className="aml-lockdown-timer__label">Unlocks in</span>
                <span className="aml-lockdown-timer__secs">{Math.floor(lockdownSecs / 60)}:{String(lockdownSecs % 60).padStart(2, '0')}</span>
              </div>
            </>
          ) : (
            <>
              <p className="aml-guardian__sub">Enter your 5-digit PIN to unlock and read this mail.</p>
              {strikeCount > 0 && (
                <div className="aml-strike-row">
                  {[0, 1, 2].map(i => (
                    <div key={i} className={`aml-strike-dot${i < strikeCount ? ' aml-strike-dot--hit' : ''}`} />
                  ))}
                  <span className="aml-strike-label">{strikeCount}/3 attempts</span>
                </div>
              )}
              <input
                className="aml-pin-input"
                type="password"
                inputMode="numeric"
                maxLength={5}
                placeholder="•••••"
                value={guardianPin}
                autoFocus
                onChange={e => setGuardianPin(e.target.value.replace(/\D/g, '').slice(0, 5))}
                onKeyDown={e => { if (e.key === 'Enter' && guardianPin.length === 5) handleGuardian(); }}
              />
              {guardianError && <p className="aml-error">{guardianError}</p>}
              <button className="aml-primary-btn" onClick={handleGuardian} disabled={guardianPin.length !== 5}>
                <Lock size={14} /> Unlock
              </button>
            </>
          )}
          <button className="aml-ghost-btn" onClick={() => { setScreen(prevScreenRef.current as Screen); setGuardianPin(''); setGuardianError(''); }}>
            <ArrowLeft size={13} /> Back
          </button>
        </div>
      </div>
    );
  }

  // ── Read mail ─────────────────────────────────────────────────────────────
  if (screen === 'read' && activeMail) {
    const isMine = activeMail.from_pin === myPin;
    const party = isMine
      ? (contacts[activeMail.to_pin] ?? activeMail.to_pin)
      : (contacts[activeMail.from_pin] ?? activeMail.from_pin);
    const urgent = countdown !== null && countdown <= 30;

    return (
      <div className="aml-root">
        {blurred && (
          <div className="aml-blackout">
            <Shield size={40} style={{ color: '#22d3ee' }} />
            <p>AippieShield active</p>
            <span>Come back to read mail</span>
          </div>
        )}
        <div className={`aml-read${blurred ? ' aml-read--blurred' : ''}`}>
          <div className="aml-topbar">
            <button className="aml-back" onClick={() => { setScreen(prevScreenRef.current as Screen); setActiveMail(null); }}>
              <ArrowLeft size={16} />
            </button>
            <span className="aml-topbar__title">Secure Mail</span>
            {!isMine && (
              <button className="aml-icon-btn" onClick={() => handleDelete(activeMail.id)}>
                <Trash2 size={15} />
              </button>
            )}
          </div>

          {/* Countdown banner */}
          {countdown !== null && activeMail.destroy_after > 0 && (
            <div className={`aml-countdown-bar${urgent ? ' aml-countdown-bar--urgent' : ''}`}>
              <Skull size={13} />
              <span>Self-deletes in <strong>{formatCountdown(countdown)}</strong></span>
              <span className="aml-countdown-bar__sub">Mail disappears permanently on both sides</span>
            </div>
          )}

          {/* Shield badges */}
          <div className="aml-shield-row">
            <span><Lock size={10} /> E2EE</span>
            <span><EyeOff size={10} /> Anti-copy</span>
            {activeMail.destroy_after > 0 && <span><Clock size={10} /> Auto-delete</span>}
          </div>

          <div
            className="aml-mail-body"
            onCopy={e => e.preventDefault()}
            onCut={e => e.preventDefault()}
            style={{ userSelect: 'none', WebkitUserSelect: 'none' }}
          >
            <div className="aml-mail-from">
              {isMine ? <><Send size={12} /> Aan: {party}</> : <><Mail size={12} /> Van: {party}</>}
              <span className="aml-mail-time">{timeAgo(activeMail.created_at)}</span>
            </div>
            <h2 className="aml-mail-subject">{activeMail.subject}</h2>
            <div className="aml-mail-text">{activeMail.body}</div>
          </div>
        </div>
      </div>
    );
  }

  // ── Compose ───────────────────────────────────────────────────────────────
  if (screen === 'compose') {
    return (
      <div className="aml-root">
        <div className="aml-compose">
          <div className="aml-topbar">
            <button className="aml-back" onClick={() => { setScreen(tab); setToPin(''); setSubject(''); setBody(''); setDlpWarning(null); setSendError(''); }}>
              <ArrowLeft size={16} />
            </button>
            <span className="aml-topbar__title">New Secure Mail</span>
            <button className={`aml-send-btn${body.trim() && toPin.length === 5 ? ' aml-send-btn--ready' : ''}`}
              onClick={handleSend} disabled={sending || !body.trim() || toPin.length !== 5}>
              {sending ? <span className="aml-spinner" /> : <><Send size={14} /> Send</>}
            </button>
          </div>

          {/* DLP warning */}
          {dlpWarning && (
            <div className="aml-dlp-bar">
              <AlertTriangle size={14} className="aml-dlp-bar__icon" />
              <div className="aml-dlp-bar__body">
                <span className="aml-dlp-bar__title">AippieShield DLP</span>
                <span className="aml-dlp-bar__msg">{dlpWarning}</span>
              </div>
              <div className="aml-dlp-bar__actions">
                <button className="aml-dlp-btn aml-dlp-btn--cancel" onClick={() => { setDlpWarning(null); setDlpBypass(false); }}>Cancel</button>
                <button className="aml-dlp-btn aml-dlp-btn--send" onClick={() => { setDlpBypass(true); setDlpWarning(null); setTimeout(handleSend, 0); }}>Send anyway</button>
              </div>
            </div>
          )}
          {sendError && <div className="aml-error aml-error--bar">{sendError}</div>}

          <div className="aml-fields">
            <div className="aml-field">
              <label className="aml-label">To (PIN)</label>
              <input className="aml-input" placeholder="12345" maxLength={5} inputMode="numeric"
                value={toPin} onChange={e => setToPin(e.target.value.replace(/\D/g, '').slice(0, 5))} />
            </div>
            <div className="aml-field">
              <label className="aml-label">Subject</label>
              <input className="aml-input" placeholder="Subject (optional)" value={subject} onChange={e => setSubject(e.target.value)} />
            </div>
            <div className="aml-field">
              <label className="aml-label">Message</label>
              <textarea className="aml-textarea" placeholder="Write your secure message…"
                value={body} onChange={e => setBody(e.target.value)} rows={8} />
            </div>

            {/* Destroy timer */}
            <div className="aml-field">
              <label className="aml-label"><Skull size={11} /> Auto-delete timer (after reading)</label>
              <div className="aml-timer-opts">
                {TIMER_OPTIONS.map(o => (
                  <button key={o.value}
                    className={`aml-timer-opt${destroyAfter === o.value ? ' aml-timer-opt--active' : ''}`}
                    onClick={() => setDestroyAfter(o.value)}>
                    {o.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Shield info */}
            <div className="aml-shield-info">
              <Shield size={12} style={{ color: '#22d3ee' }} />
              <span>Mail sent E2EE · Metadata stripped · Recipient must enter PIN to read</span>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // ── Inbox / Sent ──────────────────────────────────────────────────────────
  const currentList = tab === 'inbox' ? inbox : sent;
  const unreadCount = inbox.filter(m => !m.is_read).length;

  return (
    <div className="aml-root">
      {blurred && (
        <div className="aml-blackout">
          <Shield size={40} style={{ color: '#22d3ee' }} />
          <p>AippieShield active</p>
          <span>Come back to read mail</span>
        </div>
      )}

      <div className={blurred ? 'aml-blurred' : ''}>
        {/* Header */}
        <div className="aml-header">
          <div className="aml-header__left">
            <div className="aml-header__logo"><Shield size={16} style={{ color: '#22d3ee' }} /></div>
            <div>
              <div className="aml-header__title">Aippie Mail</div>
              <div className="aml-header__pin">PIN: {myPin} · E2EE protected</div>
            </div>
          </div>
          <button className="aml-compose-fab" onClick={() => setScreen('compose')}>
            <PenSquare size={16} /> New
          </button>
        </div>

        {/* Shield bar */}
        <div className="aml-protect-bar">
          <span><Lock size={10} /> E2EE</span>
          <span><EyeOff size={10} /> Anti-screenshot</span>
          <span><Skull size={10} /> Auto-wipe</span>
          <span><Shield size={10} /> DLP</span>
        </div>

        {/* Tabs */}
        <div className="aml-tabs">
          <button className={`aml-tab${tab === 'inbox' ? ' aml-tab--active' : ''}`} onClick={() => { setTab('inbox'); setScreen('inbox'); }}>
            <Inbox size={13} /> Inbox {unreadCount > 0 && <span className="aml-tab-badge">{unreadCount}</span>}
          </button>
          <button className={`aml-tab${tab === 'sent' ? ' aml-tab--active' : ''}`} onClick={() => { setTab('sent'); setScreen('sent'); }}>
            <Send size={13} /> Sent
          </button>
          <button className="aml-tab aml-tab--refresh" onClick={() => myPin && loadMail(myPin)}>
            <RefreshCw size={13} />
          </button>
        </div>

        {/* Mail list */}
        <div className="aml-list">
          {currentList.length === 0 ? (
            <div className="aml-empty">
              <Mail size={36} className="aml-empty__icon" />
              <p className="aml-empty__title">{tab === 'inbox' ? 'Inbox is empty' : 'Nothing sent yet'}</p>
              <p className="aml-empty__sub">{tab === 'inbox' ? 'Receive secure mails from other Aippie users via their PIN.' : 'Click "New" to send a secure mail.'}</p>
            </div>
          ) : currentList.map(mail => {
            const isMine = mail.from_pin === myPin;
            const party = isMine
              ? (contacts[mail.to_pin] ?? mail.to_pin)
              : (contacts[mail.from_pin] ?? mail.from_pin);
            const unread = !isMine && !mail.is_read;
            const expiring = mail.expires_at && new Date(mail.expires_at).getTime() > Date.now();
            return (
              <button key={mail.id} className={`aml-mail-row${unread ? ' aml-mail-row--unread' : ''}`} onClick={() => openMail(mail)}>
                <div className="aml-mail-row__avatar" style={{ background: unread ? '#22d3ee22' : '#1e293b', border: `1px solid ${unread ? '#22d3ee44' : '#334155'}` }}>
                  {unread ? <Mail size={14} style={{ color: '#22d3ee' }} /> : <CheckCircle2 size={14} style={{ color: '#475569' }} />}
                </div>
                <div className="aml-mail-row__body">
                  <div className="aml-mail-row__top">
                    <span className={`aml-mail-row__name${unread ? ' aml-mail-row__name--bold' : ''}`}>{party}</span>
                    <span className="aml-mail-row__time">{timeAgo(mail.created_at)}</span>
                  </div>
                  <div className={`aml-mail-row__subject${unread ? ' aml-mail-row__subject--bold' : ''}`}>{mail.subject}</div>
                  <div className="aml-mail-row__preview">{mail.body.slice(0, 60)}{mail.body.length > 60 ? '…' : ''}</div>
                </div>
                <div className="aml-mail-row__right">
                  {expiring && <Clock size={11} style={{ color: '#fbbf24' }} />}
                  <ChevronRight size={13} style={{ color: '#475569' }} />
                </div>
              </button>
            );
          })}
        </div>

        {/* Compose FAB bottom */}
        <button className="aml-bottom-fab" onClick={() => setScreen('compose')}>
          <PenSquare size={20} />
        </button>
      </div>
    </div>
  );
}
