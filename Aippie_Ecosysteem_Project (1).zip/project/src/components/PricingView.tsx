import { useEffect, useState } from 'react';
import { Check, X, Shield, Lock, Award, ChevronDown, ChevronUp, Zap, Infinity } from 'lucide-react';
import { supabase } from '../lib/supabase';
import SepaPaymentBlock from './SepaPaymentBlock';

type Cycle = 'monthly' | 'yearly';

const LIFETIME_SLOTS = 47;

const PLANS = [
  {
    id: 'starter',
    name: 'Starter',
    badge: 'Most Popular',
    badgeColor: '#0369a1',
    monthly: 29,
    yearly: 290,
    yearlySaving: 58,
    accent: '#0ea5e9',
    description: 'Everything you need to get started',
    features: [
      { text: 'AippieAccounts + AI Tax Chat', included: true },
      { text: 'AippieLifeAssistant', included: true },
      { text: 'AippieSecureChat', included: true },
      { text: 'VERI*FACTU (50 invoices/mth)', included: true },
      { text: '1 company · 1 user', included: true },
      { text: 'AippieTrading Alpha', included: false },
      { text: 'AippieDoctor consultations', included: false },
      { text: 'AippieLegal AI', included: false },
      { text: 'AippieRealEstate', included: false },
      { text: 'Aippie Predict', included: false },
    ],
    cta: 'Start Free 14-Day Trial',
    note: 'No credit card required',
  },
  {
    id: 'business',
    name: 'Business',
    badge: 'Best Value',
    badgeColor: '#b45309',
    monthly: 79,
    yearly: 790,
    yearlySaving: 158,
    accent: '#f59e0b',
    featured: true,
    description: 'The complete AI-powered life OS',
    features: [
      { text: 'Everything in Starter', included: true },
      { text: 'AippieTrading Alpha (quant AI)', included: true },
      { text: 'AippieDoctor consultations', included: true },
      { text: 'AippieLegal AI', included: true },
      { text: 'AippieRealEstate portfolio', included: true },
      { text: 'Unlimited VERI*FACTU invoices', included: true },
      { text: '5 companies · 5 users', included: true },
      { text: 'Aippie Predict (AI forecasting)', included: true },
      { text: 'Priority support', included: true },
      { text: 'White label', included: false },
    ],
    cta: 'Start Free 14-Day Trial',
    note: 'Most businesses choose this',
  },
  {
    id: 'enterprise',
    name: 'Enterprise',
    badge: 'Full Power',
    badgeColor: '#6b21a8',
    monthly: 199,
    yearly: 1990,
    yearlySaving: 398,
    accent: '#a855f7',
    description: 'Unlimited everything for serious operators',
    features: [
      { text: 'All 83 Aippie modules', included: true },
      { text: 'Unlimited companies & users', included: true },
      { text: 'White label + Custom branding', included: true },
      { text: 'REST API + Custom integrations', included: true },
      { text: 'Dedicated account manager', included: true },
      { text: '99.9% SLA uptime guarantee', included: true },
      { text: 'Enterprise Clinic Hub', included: true },
      { text: 'B2B Partner network access', included: true },
      { text: 'Custom AI model training', included: true },
      { text: 'GDPR / HIPAA / PCI-DSS', included: true },
    ],
    cta: 'Contact Sales',
    note: 'For companies & institutions',
  },
];

const FAQS = [
  {
    q: 'What is the Lifetime deal?',
    a: 'A one-time payment of €2,497 gives you permanent access to all 83 Aippie modules — forever. No monthly fees, no renewals. All future updates included. Only 47 slots available globally.',
  },
  {
    q: 'Can I upgrade my plan at any time?',
    a: 'Yes. Upgrade or downgrade whenever you want. Changes apply from the next billing cycle.',
  },
  {
    q: 'Is there a free trial?',
    a: '14 days free, no credit card required. Cancel any time before the trial ends.',
  },
  {
    q: 'What is VERI*FACTU?',
    a: 'VERI*FACTU is the mandatory electronic invoicing system in Spain since July 2025. All invoices must be sent in real-time to the AEAT with QR code and verifiable hash chain.',
  },
  {
    q: 'How does the Ambassador program work?',
    a: 'Refer 1 customer → earn 50 APC (€50 value). Refer 5 → get 1 month Business free. Refer 10 → get 1 year Enterprise free. Your unique referral link is available in the Partner Portal.',
  },
];

function FaqItem({ q, a }: { q: string; a: string }) {
  const [open, setOpen] = useState(false);
  return (
    <div className="pricing-faq__item" onClick={() => setOpen(o => !o)}>
      <div className="pricing-faq__q">
        <span>{q}</span>
        {open ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
      </div>
      {open && <div className="pricing-faq__a">{a}</div>}
    </div>
  );
}

export default function PricingView() {
  const [cycle, setCycle] = useState<Cycle>('monthly');
  const [soldSlots, setSoldSlots] = useState<number | null>(null);

  useEffect(() => {
    supabase
      .from('lifetime_deal_slots')
      .select('sold_count')
      .eq('id', 1)
      .maybeSingle()
      .then(({ data }) => {
        if (data) setSoldSlots(data.sold_count as number);
        else setSoldSlots(12); // fallback display
      });
  }, []);

  const remaining = soldSlots !== null ? LIFETIME_SLOTS - soldSlots : null;

  return (
    <div className="pricing-root">
      {/* Header */}
      <div className="pricing-header">
        <div className="pricing-header__badge">AIPPIETAX S.A. · 83 Modules</div>
        <h1 className="pricing-header__title">Simple plans. Zero surprises.</h1>
        <p className="pricing-header__sub">Start free for 14 days. No credit card required.</p>

        <div className="pricing-toggle">
          <button
            className={`pricing-toggle__btn${cycle === 'monthly' ? ' pricing-toggle__btn--active' : ''}`}
            onClick={() => setCycle('monthly')}
          >Monthly</button>
          <button
            className={`pricing-toggle__btn${cycle === 'yearly' ? ' pricing-toggle__btn--active' : ''}`}
            onClick={() => setCycle('yearly')}
          >
            Yearly
            <span className="pricing-toggle__save">2 months free</span>
          </button>
        </div>
      </div>

      {/* Standard plan cards */}
      <div className="pricing-cards">
        {PLANS.map(plan => {
          const price = cycle === 'monthly' ? plan.monthly : Math.round(plan.yearly / 12);
          return (
            <div
              key={plan.id}
              className={`pricing-card${plan.featured ? ' pricing-card--featured' : ''}`}
              style={{ '--plan-accent': plan.accent } as React.CSSProperties}
            >
              <div className="pricing-card__badge" style={{ background: plan.badgeColor }}>{plan.badge}</div>
              <div className="pricing-card__name">{plan.name}</div>
              <div className="pricing-card__desc">{plan.description}</div>

              <div className="pricing-card__price">
                <span className="pricing-card__currency">€</span>
                <span className="pricing-card__amount">{price}</span>
                <span className="pricing-card__period">/mo</span>
              </div>

              {cycle === 'yearly' && (
                <div className="pricing-card__yearly">
                  €{plan.yearly}/year · Save €{plan.yearlySaving}
                </div>
              )}

              <div className="pricing-card__divider" style={{ background: plan.accent }} />

              <ul className="pricing-card__features">
                {plan.features.map((f, i) => (
                  <li key={i} className={`pricing-card__feature${f.included ? '' : ' pricing-card__feature--no'}`}>
                    {f.included
                      ? <Check size={14} className="pricing-card__check" style={{ color: plan.accent }} />
                      : <X size={14} className="pricing-card__x" />}
                    {f.text}
                  </li>
                ))}
              </ul>

              <button
                className="pricing-card__cta"
                style={plan.featured
                  ? { background: plan.accent, color: '#fff' }
                  : { background: 'transparent', color: plan.accent, border: `2px solid ${plan.accent}` }}
              >
                {plan.cta}
              </button>
              <div className="pricing-card__note">{plan.note}</div>
            </div>
          );
        })}
      </div>

      {/* ── LIFETIME DEAL ── */}
      <div className="pricing-lifetime">
        <div className="pricing-lifetime__glow" aria-hidden="true" />
        <div className="pricing-lifetime__top">
          <div className="pricing-lifetime__icon"><Infinity size={22} /></div>
          <div>
            <div className="pricing-lifetime__tag">LIMITED TIME</div>
            <h2 className="pricing-lifetime__title">Lifetime Deal</h2>
            <p className="pricing-lifetime__sub">Pay once. Own Aippie forever.</p>
          </div>
          <div className="pricing-lifetime__price-wrap">
            <span className="pricing-lifetime__price">€2,497</span>
            <span className="pricing-lifetime__once">one-time</span>
          </div>
        </div>

        <div className="pricing-lifetime__features">
          {[
            'All 83 Aippie modules — forever',
            'Every future update included',
            'No monthly fees. No renewals. Ever.',
            'License key: AIPP-LIFE-XXXX-XXXX',
            'Priority support for life',
            'Ambassador commission for referrals',
          ].map((f, i) => (
            <div key={i} className="pricing-lifetime__feature">
              <Zap size={13} className="pricing-lifetime__feature-icon" />
              {f}
            </div>
          ))}
        </div>

        <div className="pricing-lifetime__scarcity">
          <div className="pricing-lifetime__scarcity-bar">
            <div
              className="pricing-lifetime__scarcity-fill"
              style={{ width: `${remaining !== null ? ((LIFETIME_SLOTS - remaining) / LIFETIME_SLOTS) * 100 : 25}%` }}
            />
          </div>
          <span className="pricing-lifetime__scarcity-text">
            {remaining !== null
              ? `${remaining} of ${LIFETIME_SLOTS} slots remaining`
              : `Loading availability...`}
          </span>
        </div>

        <SepaPaymentBlock
          amount={2497}
          accent="#EAB308"
          paypalUrl="https://www.paypal.com/paypalme/aippietax/2497"
        />

        <p className="pricing-lifetime__guarantee">30-day money-back guarantee · AIPPIETAX S.A. · NIF A22944987</p>
      </div>

      {/* Trust badges */}
      <div className="pricing-trust">
        <div className="pricing-trust__badge"><Award size={16} />AEAT Certified</div>
        <div className="pricing-trust__badge"><Shield size={16} />GDPR Compliant</div>
        <div className="pricing-trust__badge"><Lock size={16} />256-bit Encryption</div>
        <div className="pricing-trust__badge"><Zap size={16} />83 Modules Live</div>
      </div>

      {/* FAQ */}
      <div className="pricing-faq">
        <h2 className="pricing-faq__title">Frequently asked questions</h2>
        {FAQS.map((faq, i) => <FaqItem key={i} q={faq.q} a={faq.a} />)}
      </div>

      <div className="pricing-iva-note">* Prices exclude 21% VAT. Billed in euros. AIPPIETAX S.A. · NIF A22944987</div>
    </div>
  );
}
