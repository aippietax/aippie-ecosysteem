// @ts-nocheck
/**
 * AippieTradingView — v221
 * Real CoinGecko crypto + Yahoo Finance NASDAQ via edge function
 * Autonomous AI strategy engine · Auto stop-loss / take-profit · Paper trading
 * + Live news sentiment · Dark pool radar · Market heatmap · Proactive AI advisor
 */
import { useCallback, useEffect, useRef, useState } from 'react';
import {
  Activity, AlertTriangle, ArrowDownRight, ArrowUpRight,
  Bot, CheckCircle, Eye, EyeOff, Key, Lock,
  RefreshCw, Shield, TrendingUp, TrendingDown, Zap,
  Play, Square, Info, Newspaper, Radio, BarChart2,
} from 'lucide-react';
import type { User } from '@supabase/supabase-js';
import { supabase } from '../lib/supabase';
import { applyPremiumVoice, withVoicesReady } from '../lib/ttsVoice';
import { TradingDisclaimerModal, hasLocalConsent } from './TradingDisclaimerModal';
import { useAuth } from '../contexts/AuthContext';
import { aippieIpoTicker, BME_SCALEUP_SEGMENT, formatMarketCap } from '../services/marketData';

// ─── Types ────────────────────────────────────────────────────────────────────

interface LivePrice  { usd: number; usd_24h_change: number; }
interface LivePrices { [id: string]: LivePrice; }

interface Ticker {
  key: string;
  cgId?: string;
  yahooSym?: string;
  type: 'crypto' | 'stock';
  price: number; prev: number;
  changePct: number; dir: 'up' | 'down' | 'flat';
}

interface Candle { o: number; h: number; l: number; c: number; v: number; bull: boolean; }

interface AIPosition {
  id: string;
  asset: string;
  side: 'LONG' | 'SHORT';
  entryPrice: number;
  qty: number;
  stopLoss: number;
  takeProfit: number;
  strategy: string;
  status: 'OPEN' | 'CLOSED_TP' | 'CLOSED_SL' | 'CLOSED_AI';
  openedAt: string;
  closedAt?: string;
  closePrice?: number;
  pnlPct?: number;
}

interface AISignal {
  asset: string;
  action: 'BUY' | 'SELL' | 'HOLD';
  strategy: string;
  confidence: number;
  reason: string;
}

interface NewsTick {
  id: string;
  ts: string;
  headline: string;
  sentiment: 'bullish' | 'bearish' | 'neutral';
  asset?: string;
  score: number;          // -1..1
  source: string;
}

interface DarkPoolTick {
  asset: string;
  volume: number;
  side: 'BUY' | 'SELL' | 'MIXED';
  price: number;
  ts: string;
  unusualScore: number;
}

interface IndexQuote {
  key: string;
  label: string;
  price: number;
  changePct: number;
  history: number[];   // rolling price history for sparkline
}

// AI trade decision — produced by multi-factor engine
interface TradeDecision {
  action: 'IN' | 'OUT' | 'HOLD';
  asset: string;
  confidence: number;    // 0-100
  reasoning: string[];
  ts: string;
}

// Global financial news pool — 80+ diverse worldwide headlines, never repeats in sequence
const NEWS_POOL: Omit<NewsTick, 'id' | 'ts'>[] = [
  // ── Crypto ──────────────────────────────────────────────────────────────────
  { headline: 'Bitcoin ETF inflows hit $620M in single day — BlackRock leads institutional surge', sentiment: 'bullish', asset: 'BTC/USD', score: 0.82, source: 'CoinDesk' },
  { headline: 'Bitcoin miners capitulate ahead of halving — hash rate drops 8%', sentiment: 'bearish', asset: 'BTC/USD', score: -0.52, source: 'CoinTelegraph' },
  { headline: 'Crypto whale moves 18,400 BTC to Binance — market braces for sell pressure', sentiment: 'bearish', asset: 'BTC/USD', score: -0.68, source: 'Whale Alert' },
  { headline: 'El Salvador BTC bond oversubscribed 3x — sovereign adoption accelerates', sentiment: 'bullish', asset: 'BTC/USD', score: 0.65, source: 'Reuters' },
  { headline: 'Ethereum Layer 2 TVL crosses $50B milestone as fees drop 90%', sentiment: 'bullish', asset: 'ETH/USD', score: 0.73, source: 'Decrypt' },
  { headline: 'Ethereum staking yield rises to 5.8% — validators flood network', sentiment: 'bullish', asset: 'ETH/USD', score: 0.60, source: 'Bankless' },
  { headline: 'ETH gas fees spike to $85 average — DeFi activity surges past 2021 highs', sentiment: 'neutral', asset: 'ETH/USD', score: -0.30, source: 'DeFi Pulse' },
  { headline: 'Solana breaks $200 — Visa expands stablecoin payments on SOL network', sentiment: 'bullish', asset: 'SOL/USD', score: 0.79, source: 'The Block' },
  { headline: 'Solana network outage lasts 4 hours — developer confidence shaken', sentiment: 'bearish', asset: 'SOL/USD', score: -0.70, source: 'Decrypt' },
  { headline: 'BNB Chain launches gasless transactions — DApp developers flock to ecosystem', sentiment: 'bullish', asset: 'BNB/USD', score: 0.58, source: 'BSC News' },
  { headline: 'SEC launches new investigation into crypto exchange staking programs', sentiment: 'bearish', score: -0.65, source: 'Wall Street Journal' },
  { headline: 'MicroStrategy adds 12,000 BTC — total holdings now $14B, stock rallies 9%', sentiment: 'bullish', asset: 'BTC/USD', score: 0.71, source: 'Bloomberg' },
  { headline: 'Crypto fear & greed index at 82 — extreme greed warns of correction risk', sentiment: 'neutral', score: -0.25, source: 'Alternative.me' },
  { headline: 'Tether market cap surpasses $120B — dollar-pegged stablecoin demand at record', sentiment: 'bullish', score: 0.40, source: 'CoinDesk' },
  { headline: 'Binance settles DOJ case for $4.3B — CEO steps down, compliance era begins', sentiment: 'bearish', score: -0.55, source: 'Reuters' },
  { headline: 'Hong Kong approves first spot Bitcoin and ETH ETFs — Asia capital unlocked', sentiment: 'bullish', score: 0.76, source: 'South China Morning Post' },

  // ── US Equities ──────────────────────────────────────────────────────────────
  { headline: 'NVIDIA crushes Q2 estimates — data center revenue +122% YoY, stock surges 9%', sentiment: 'bullish', asset: 'NVDA', score: 0.88, source: 'Bloomberg' },
  { headline: 'NVIDIA faces export ban expansion to UAE and Vietnam — shares drop 6%', sentiment: 'bearish', asset: 'NVDA', score: -0.62, source: 'Financial Times' },
  { headline: 'Apple Vision Pro sales disappoint — shipments 60% below analyst forecasts', sentiment: 'bearish', asset: 'AAPL', score: -0.48, source: 'Nikkei Asia' },
  { headline: 'Apple signs 10-year AI partnership with OpenAI — Siri overhaul imminent', sentiment: 'bullish', asset: 'AAPL', score: 0.74, source: 'Bloomberg' },
  { headline: 'Tesla Cybertruck recall affects 11,688 vehicles — brake defect discovered', sentiment: 'bearish', asset: 'TSLA', score: -0.58, source: 'CNBC' },
  { headline: 'Tesla FSD v13 approved in California — robotaxi rollout by Q4', sentiment: 'bullish', asset: 'TSLA', score: 0.80, source: 'Electrek' },
  { headline: 'Microsoft Azure AI revenue up 41% QoQ — Copilot enterprise adoption accelerates', sentiment: 'bullish', asset: 'MSFT', score: 0.77, source: 'TechCrunch' },
  { headline: 'Microsoft loses $3B EU antitrust case — Teams bundling deemed anti-competitive', sentiment: 'bearish', asset: 'MSFT', score: -0.42, source: 'Reuters' },
  { headline: 'S&P 500 hits all-time high — 7th consecutive week of gains for index', sentiment: 'bullish', asset: 'SPY', score: 0.68, source: 'MarketWatch' },
  { headline: 'QQQ breaks 510 — tech sector best quarter since 2019 amid AI wave', sentiment: 'bullish', asset: 'QQQ', score: 0.72, source: 'Barron\'s' },
  { headline: 'Hedge funds build record short positions in US Treasuries — volatility warning', sentiment: 'bearish', score: -0.55, source: 'Financial Times' },
  { headline: 'Warren Buffett trims Apple stake by 12% — Berkshire raises cash to $189B', sentiment: 'bearish', asset: 'AAPL', score: -0.44, source: 'CNBC' },
  { headline: 'S&P 500 earnings season 78% beat rate — highest since 2018', sentiment: 'bullish', asset: 'SPY', score: 0.65, source: 'FactSet' },

  // ── Macro & Fed ───────────────────────────────────────────────────────────────
  { headline: 'Fed holds rates at 5.25% — Powell hints at September cut if inflation cools', sentiment: 'bullish', score: 0.58, source: 'Reuters' },
  { headline: 'US CPI rises 0.4% in April — hotter than expected, rate cut hopes fade', sentiment: 'bearish', score: -0.72, source: 'CNBC' },
  { headline: 'US non-farm payrolls beat at +256K — labor market crushes expectations', sentiment: 'bullish', score: 0.55, source: 'Bloomberg' },
  { headline: 'US GDP growth revised up to 3.4% Q4 — economy stronger than feared', sentiment: 'bullish', score: 0.60, source: 'Wall Street Journal' },
  { headline: 'US debt ceiling crisis looms — Treasury warns X-date in 6 weeks', sentiment: 'bearish', score: -0.64, source: 'Reuters' },
  { headline: 'Yield curve inverts deepest since 1981 — recession risk flashing red', sentiment: 'bearish', score: -0.75, source: 'Financial Times' },
  { headline: 'PCE inflation at 2.7% — Fed\'s preferred gauge still above 2% target', sentiment: 'neutral', score: -0.30, source: 'Bloomberg' },
  { headline: 'Dollar index DXY hits 106 — emerging markets face capital outflow pressure', sentiment: 'bearish', score: -0.50, source: 'Reuters' },
  { headline: 'OPEC+ extends production cuts by 6 months — crude oil spikes 5%', sentiment: 'bearish', score: -0.45, source: 'Al Jazeera' },
  { headline: 'Bank of Japan ends negative rate era — first hike in 17 years stuns markets', sentiment: 'neutral', score: 0.20, source: 'Nikkei Asia' },

  // ── Europe ────────────────────────────────────────────────────────────────────
  { headline: 'ECB cuts rates for first time since 2019 — 25bps reduction boosts EU stocks', sentiment: 'bullish', score: 0.62, source: 'Financial Times' },
  { headline: 'Germany enters technical recession — second consecutive quarter of contraction', sentiment: 'bearish', score: -0.68, source: 'Der Spiegel' },
  { headline: 'UK inflation falls to 2.3% — Bank of England rate cut now widely expected', sentiment: 'bullish', score: 0.55, source: 'BBC News' },
  { headline: 'EU AI Act formally approved — tech giants face $38M fines for non-compliance', sentiment: 'bearish', score: -0.40, source: 'Politico EU' },
  { headline: 'LVMH luxury sales miss as Chinese consumer spending slows sharply', sentiment: 'bearish', score: -0.52, source: 'Le Monde' },
  { headline: 'Netherlands pension funds pour €12B into European tech equities', sentiment: 'bullish', score: 0.48, source: 'NRC Handelsblad' },
  { headline: 'Spain surpasses France as Europe\'s fastest-growing major economy', sentiment: 'bullish', score: 0.42, source: 'El País' },
  { headline: 'Volkswagen reports record €22B loss — restructuring plan to cut 35,000 jobs', sentiment: 'bearish', score: -0.70, source: 'Handelsblatt' },

  // ── Asia Pacific ──────────────────────────────────────────────────────────────
  { headline: 'China PBOC cuts reserve ratio 50bps — liquidity injection of $140B', sentiment: 'bullish', score: 0.66, source: 'Xinhua' },
  { headline: 'China property sector crisis deepens — Evergrande liquidated by HK court', sentiment: 'bearish', score: -0.74, source: 'South China Morning Post' },
  { headline: 'Nikkei 225 crosses 42,000 for first time — yen weakness fuels export rally', sentiment: 'bullish', score: 0.65, source: 'Nikkei Asia' },
  { headline: 'Taiwan Semiconductor beats revenue forecast — AI chip demand insatiable', sentiment: 'bullish', score: 0.78, source: 'DigiTimes Asia' },
  { headline: 'India overtakes Japan as world\'s 4th largest economy — Sensex hits record', sentiment: 'bullish', score: 0.60, source: 'The Hindu' },
  { headline: 'Australia RBA holds rates — inflation persistence delays rate cut cycle', sentiment: 'neutral', score: -0.20, source: 'Sydney Morning Herald' },
  { headline: 'Samsung Electronics misses Q1 estimates — memory chip oversupply continues', sentiment: 'bearish', score: -0.55, source: 'Korea Herald' },
  { headline: 'Singapore sovereign wealth fund GIC increases US equity exposure to 42%', sentiment: 'bullish', score: 0.45, source: 'Straits Times' },

  // ── Commodities & Geopolitical ────────────────────────────────────────────────
  { headline: 'Gold hits $2,450/oz all-time high — central bank buying hits record pace', sentiment: 'neutral', score: 0.35, source: 'Reuters' },
  { headline: 'Oil prices surge 8% on Red Sea shipping disruptions — inflation risk rises', sentiment: 'bearish', score: -0.60, source: 'Bloomberg' },
  { headline: 'Copper reaches $11,000/ton — green energy demand outpaces mine supply', sentiment: 'bullish', score: 0.50, source: 'Financial Times' },
  { headline: 'Geopolitical tensions in Taiwan Strait spike — tech stocks rout 3%', sentiment: 'bearish', score: -0.70, source: 'Associated Press' },
  { headline: 'Middle East ceasefire deal signed — oil risk premium collapses $12', sentiment: 'bullish', score: 0.65, source: 'Al Jazeera' },
  { headline: 'G7 agrees on $50B Ukraine aid package — European defense stocks soar 8%', sentiment: 'neutral', score: 0.30, source: 'Reuters' },
  { headline: 'US-China semiconductor tariffs double to 100% — supply chain chaos feared', sentiment: 'bearish', score: -0.78, source: 'Wall Street Journal' },
  { headline: 'Saudi Aramco dividend cut shocks Gulf markets — fiscal deficit widens', sentiment: 'bearish', score: -0.55, source: 'Arab News' },

  // ── AI & Tech ─────────────────────────────────────────────────────────────────
  { headline: 'OpenAI GPT-5 launch draws 10M signups in 24 hours — AI adoption accelerates', sentiment: 'bullish', score: 0.72, source: 'TechCrunch' },
  { headline: 'Anthropic raises $2.75B at $18.4B valuation — AI arms race intensifies', sentiment: 'bullish', score: 0.55, source: 'Bloomberg' },
  { headline: 'AI energy demand to triple US data center power needs by 2030', sentiment: 'neutral', score: 0.25, source: 'Nature Energy' },
  { headline: 'EU fines Meta €1.2B for GDPR violations — data transfers to US illegal', sentiment: 'bearish', score: -0.48, source: 'Guardian' },
  { headline: 'Broadcom AI chip orders surge — 2025 backlog sold out, customers queue', sentiment: 'bullish', score: 0.69, source: 'Barron\'s' },
  { headline: 'AMD overtakes Intel in data center market share for first time in history', sentiment: 'bullish', score: 0.65, source: 'Wired' },
  { headline: 'Quantum computing breakthrough: IBM achieves 1,000-qubit error correction', sentiment: 'bullish', score: 0.58, source: 'MIT Technology Review' },

  // ── Dark Pool / Institutional ─────────────────────────────────────────────────
  { headline: 'Dark pool activity: $3.8B in SPY puts detected — smart money positioning short', sentiment: 'bearish', asset: 'SPY', score: -0.65, source: 'OptionFlow' },
  { headline: 'Unusual options sweep: 50,000 QQQ calls expire Friday — gamma squeeze possible', sentiment: 'bullish', asset: 'QQQ', score: 0.60, source: 'Market Chameleon' },
  { headline: 'Institutional block trade: $1.2B NVDA bought in dark pool at market open', sentiment: 'bullish', asset: 'NVDA', score: 0.74, source: 'Bloomberg Terminal' },
  { headline: 'Hedge fund liquidation triggers $8B sell order in QQQ — volatility spikes', sentiment: 'bearish', asset: 'QQQ', score: -0.70, source: 'Reuters' },
  { headline: 'Short interest on BTC futures hits 12-month high — squeeze risk elevated', sentiment: 'bullish', asset: 'BTC/USD', score: 0.55, source: 'Glassnode' },
];

// Returns a shuffled copy so each session gets different order
function shuffleNewsPool(): Omit<NewsTick, 'id' | 'ts'>[] {
  const arr = [...NEWS_POOL];
  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  return arr;
}

// Simulated dark pool ticks
function genDarkPoolTicks(tickers: Ticker[]): DarkPoolTick[] {
  const assets = tickers.filter(t => t.price > 0).slice(0, 6);
  return assets.map(t => ({
    asset: t.key,
    volume: Math.round((Math.random() * 800 + 50) * 10) / 10,
    side: Math.random() > 0.6 ? 'BUY' : Math.random() > 0.5 ? 'SELL' : 'MIXED',
    price: t.price * (1 + (Math.random() - 0.5) * 0.002),
    ts: new Date().toLocaleTimeString('en-US', { hour12: false }),
    unusualScore: Math.round(Math.random() * 100),
  }));
}

// ─── Constants ────────────────────────────────────────────────────────────────

const CG_ASSETS = [
  { key: 'BTC/USD', cgId: 'bitcoin'     },
  { key: 'ETH/USD', cgId: 'ethereum'    },
  { key: 'SOL/USD', cgId: 'solana'      },
  { key: 'BNB/USD', cgId: 'binancecoin' },
];

const STOCK_ASSETS = [
  { key: 'AAPL',  yahooSym: 'AAPL' },
  { key: 'NVDA',  yahooSym: 'NVDA' },
  { key: 'MSFT',  yahooSym: 'MSFT' },
  { key: 'TSLA',  yahooSym: 'TSLA' },
  { key: 'SPY',   yahooSym: 'SPY'  },
  { key: 'QQQ',   yahooSym: 'QQQ'  },
];

// Index instruments tracked separately (not traded)
const INDEX_ASSETS = [
  { key: 'NASDAQ-100', yahooSym: '^NDX',  label: 'NDX' },
  { key: 'S&P 500',    yahooSym: '^GSPC', label: 'SPX' },
  { key: 'VIX',        yahooSym: '^VIX',  label: 'VIX' },
];

const PRICE_POLL_MS   = 30_000;   // crypto: 30s
const STOCK_POLL_MS   = 60_000;   // stocks: 60s (NYSE/NASDAQ updates ~1min)
const STRATEGY_MS     = 8_000;
const STOP_LOSS_PCT   = 0.030;
const TAKE_PROFIT_PCT = 0.055;
const MAX_OPEN_POS    = 4;        // bumped to 4 since we have more assets now

const STRATEGIES = ['MA_CROSSOVER', 'MOMENTUM', 'RSI_DIVERGENCE'] as const;
type StrategyName = typeof STRATEGIES[number];

const STOCK_QUOTES_URL = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/stock-quotes`;

// ─── CoinGecko fetch ──────────────────────────────────────────────────────────

async function fetchLivePrices(): Promise<LivePrices | null> {
  try {
    const ids = CG_ASSETS.map(a => a.cgId).join(',');
    const res = await fetch(
      `https://api.coingecko.com/api/v3/simple/price?ids=${ids}&vs_currencies=usd&include_24hr_change=true`,
      { signal: AbortSignal.timeout(8000) }
    );
    if (!res.ok) return null;
    return await res.json();
  } catch {
    return null;
  }
}

// ─── Yahoo Finance (stock quotes edge function) ───────────────────────────────

async function fetchStockPrices(): Promise<Record<string, { price: number; change: number }> | null> {
  try {
    const res = await fetch(STOCK_QUOTES_URL, {
      headers: { apikey: import.meta.env.VITE_SUPABASE_ANON_KEY as string },
      signal: AbortSignal.timeout(10_000),
    });
    if (!res.ok) return null;
    return await res.json();
  } catch {
    return null;
  }
}

// ─── AI Strategy Engine ───────────────────────────────────────────────────────

function calcRSI(prices: number[], period = 14): number {
  if (prices.length < period + 1) return 50;
  let gains = 0, losses = 0;
  for (let i = prices.length - period; i < prices.length; i++) {
    const diff = prices[i] - prices[i - 1];
    if (diff > 0) gains += diff; else losses -= diff;
  }
  const rs = gains / (losses || 0.0001);
  return 100 - 100 / (1 + rs);
}

function calcSMA(prices: number[], period: number): number | null {
  if (prices.length < period) return null;
  const slice = prices.slice(-period);
  return slice.reduce((s, p) => s + p, 0) / period;
}

function runStrategy(
  strategy: StrategyName,
  asset: string,
  priceHistory: number[],
  currentPrice: number,
  change24h: number,
): AISignal {
  if (strategy === 'MA_CROSSOVER') {
    const ma7  = calcSMA(priceHistory, 7);
    const ma20 = calcSMA(priceHistory, 20);
    if (ma7 === null || ma20 === null) return { asset, action: 'HOLD', strategy, confidence: 0, reason: 'Not enough data' };
    const prev7  = calcSMA(priceHistory.slice(0, -1), 7);
    const prev20 = calcSMA(priceHistory.slice(0, -1), 20);
    if (prev7 !== null && prev20 !== null) {
      if (prev7 < prev20 && ma7 > ma20)
        return { asset, action: 'BUY',  strategy, confidence: 0.78, reason: `MA7 (${ma7.toFixed(2)}) crossed above MA20 — bullish crossover` };
      if (prev7 > prev20 && ma7 < ma20)
        return { asset, action: 'SELL', strategy, confidence: 0.74, reason: `MA7 (${ma7.toFixed(2)}) crossed below MA20 — bearish crossover` };
    }
    return { asset, action: 'HOLD', strategy, confidence: 0.5, reason: `MA7=${ma7.toFixed(2)}, MA20=${ma20.toFixed(2)} — no crossover` };
  }

  if (strategy === 'MOMENTUM') {
    const recentGain = priceHistory.length >= 6
      ? (currentPrice - priceHistory[priceHistory.length - 6]) / priceHistory[priceHistory.length - 6]
      : 0;
    if (recentGain > 0.018 && change24h > 1.5)
      return { asset, action: 'BUY',  strategy, confidence: 0.70, reason: `+${(recentGain*100).toFixed(2)}% momentum, 24h +${change24h.toFixed(1)}%` };
    if (recentGain < -0.018 && change24h < -1.5)
      return { asset, action: 'SELL', strategy, confidence: 0.68, reason: `${(recentGain*100).toFixed(2)}% downward momentum` };
    return { asset, action: 'HOLD', strategy, confidence: 0.45, reason: `Momentum ${(recentGain*100).toFixed(2)}% — below threshold` };
  }

  // RSI_DIVERGENCE
  const rsi = calcRSI(priceHistory);
  if (rsi < 32) return { asset, action: 'BUY',  strategy, confidence: 0.72, reason: `RSI ${rsi.toFixed(1)} — oversold, reversal expected` };
  if (rsi > 68) return { asset, action: 'SELL', strategy, confidence: 0.69, reason: `RSI ${rsi.toFixed(1)} — overbought, correction expected` };
  return { asset, action: 'HOLD', strategy, confidence: 0.5, reason: `RSI ${rsi.toFixed(1)} — neutral zone` };
}

// ─── Helpers ──────────────────────────────────────────────────────────────────

function rnd(a: number, b: number) { return a + Math.random() * (b - a); }
function fmtPrice(p: number): string {
  return p >= 1000 ? p.toLocaleString('en-US', { maximumFractionDigits: 0 }) : p.toFixed(2);
}
function pct(n: number): string { return `${n >= 0 ? '+' : ''}${n.toFixed(2)}%`; }

// ─── Canvas chart ─────────────────────────────────────────────────────────────

function drawChart(ctx: CanvasRenderingContext2D, W: number, H: number, candles: Candle[], live: Candle) {
  // Rich dark background
  const bgGrad = ctx.createLinearGradient(0, 0, 0, H);
  bgGrad.addColorStop(0, '#050e1c');
  bgGrad.addColorStop(1, '#020810');
  ctx.fillStyle = bgGrad;
  ctx.fillRect(0, 0, W, H);

  const PRICE_H = H * 0.74;
  const VOL_H   = H * 0.18;
  const VOL_Y   = PRICE_H + H * 0.04;
  const PRICE_PAD_L = 8, PRICE_PAD_R = 58, PRICE_PAD_T = 12, PRICE_PAD_B = 8;
  const all = [...candles, live];

  if (all.length < 2) {
    // Animated placeholder grid
    ctx.strokeStyle = 'rgba(56,189,248,0.08)'; ctx.lineWidth = 1;
    for (let i = 0; i <= 5; i++) {
      const y = PRICE_PAD_T + (i / 5) * (PRICE_H - PRICE_PAD_T - PRICE_PAD_B);
      ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(W, y); ctx.stroke();
    }
    for (let i = 0; i <= 10; i++) {
      const x = (i / 10) * (W - PRICE_PAD_R);
      ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, PRICE_H); ctx.stroke();
    }
    ctx.fillStyle = '#38bdf8'; ctx.font = 'bold 13px monospace'; ctx.textAlign = 'center';
    ctx.fillText('CONNECTING TO LIVE FEED…', (W - PRICE_PAD_R) / 2, H / 2 - 8);
    ctx.font = '10px monospace'; ctx.fillStyle = 'rgba(148,163,184,0.5)';
    ctx.fillText('Fetching real-time prices…', (W - PRICE_PAD_R) / 2, H / 2 + 12);
    return;
  }

  const CW = W - PRICE_PAD_R;
  const MAX_VIS = Math.max(20, Math.floor(CW / 10));
  const vis = all.slice(-MAX_VIS);
  const n = vis.length;
  const slotW = CW / n;
  const cW = Math.max(2, slotW * 0.65);

  const prices = vis.flatMap(c => [c.h, c.l]);
  const pMin = Math.min(...prices), pMax = Math.max(...prices);
  const pRange = pMax - pMin || pMin * 0.01 || 1;
  const pPad = pRange * 0.06;
  const py = (p: number) =>
    PRICE_PAD_T + (1 - (p - pMin + pPad) / (pRange + pPad * 2)) * (PRICE_H - PRICE_PAD_T - PRICE_PAD_B);

  const vols = vis.map(c => c.v), vMax = Math.max(...vols) || 1;
  const vy = (v: number) => VOL_Y + VOL_H - (v / vMax) * (VOL_H - 2);

  // Grid lines (horizontal)
  const GRID_LINES = 6;
  for (let i = 0; i <= GRID_LINES; i++) {
    const frac = i / GRID_LINES;
    const y = PRICE_PAD_T + frac * (PRICE_H - PRICE_PAD_T - PRICE_PAD_B);
    ctx.strokeStyle = 'rgba(56,189,248,0.07)'; ctx.lineWidth = 1;
    ctx.setLineDash([3, 5]);
    ctx.beginPath(); ctx.moveTo(PRICE_PAD_L, y); ctx.lineTo(CW, y); ctx.stroke();
    ctx.setLineDash([]);
    // Price labels right side
    const priceLabel = pMax + pPad - frac * (pRange + pPad * 2);
    ctx.fillStyle = 'rgba(148,163,184,0.75)'; ctx.font = '9px monospace'; ctx.textAlign = 'left';
    ctx.fillText(
      priceLabel >= 1000
        ? priceLabel.toLocaleString('en-US', { maximumFractionDigits: 0 })
        : priceLabel.toFixed(2),
      CW + 4, y + 3
    );
  }

  // Vertical grid lines
  const gridStep = Math.max(1, Math.floor(n / 8));
  for (let i = 0; i < n; i += gridStep) {
    const x = i * slotW + slotW / 2;
    ctx.strokeStyle = 'rgba(56,189,248,0.04)'; ctx.lineWidth = 1;
    ctx.beginPath(); ctx.moveTo(x, PRICE_PAD_T); ctx.lineTo(x, PRICE_H); ctx.stroke();
  }

  // Volume area separator
  ctx.strokeStyle = 'rgba(56,189,248,0.12)'; ctx.lineWidth = 1;
  ctx.beginPath(); ctx.moveTo(0, VOL_Y - 2); ctx.lineTo(CW, VOL_Y - 2); ctx.stroke();

  // Volume bars
  vis.forEach((c, i) => {
    const x = i * slotW + (slotW - cW) / 2;
    const barH = VOL_Y + VOL_H - vy(c.v);
    const alpha = 0.35 + (c.v / vMax) * 0.45;
    ctx.fillStyle = c.bull ? `rgba(0,230,118,${alpha})` : `rgba(255,72,66,${alpha})`;
    ctx.fillRect(x, vy(c.v), cW, barH);
  });

  // Candlestick bodies + wicks
  vis.forEach((c, i) => {
    const cx = i * slotW + (slotW - cW) / 2;
    const isLast = i === vis.length - 1;
    const bullColor = '#00e676';
    const bearColor = '#ff4842';
    const col = c.bull ? bullColor : bearColor;

    // Wick
    ctx.strokeStyle = c.bull ? 'rgba(0,230,118,0.9)' : 'rgba(255,72,66,0.9)';
    ctx.lineWidth = 1.5;
    if (isLast) { ctx.shadowColor = col; ctx.shadowBlur = 6; }
    ctx.beginPath();
    ctx.moveTo(cx + cW / 2, py(c.h));
    ctx.lineTo(cx + cW / 2, py(c.l));
    ctx.stroke();
    ctx.shadowBlur = 0;

    // Body
    const bTop = py(Math.max(c.o, c.c));
    const bBot = py(Math.min(c.o, c.c));
    const bodyH = Math.max(1.5, bBot - bTop);

    if (isLast) { ctx.shadowColor = col; ctx.shadowBlur = 10; }

    if (c.bull) {
      // Bullish: solid bright green with gradient
      const grad = ctx.createLinearGradient(0, bTop, 0, bTop + bodyH);
      grad.addColorStop(0, 'rgba(0,230,118,0.95)');
      grad.addColorStop(1, 'rgba(0,180,90,0.85)');
      ctx.fillStyle = grad;
    } else {
      // Bearish: solid bright red with gradient
      const grad = ctx.createLinearGradient(0, bTop, 0, bTop + bodyH);
      grad.addColorStop(0, 'rgba(255,72,66,0.9)');
      grad.addColorStop(1, 'rgba(200,30,30,0.95)');
      ctx.fillStyle = grad;
    }
    ctx.fillRect(cx, bTop, cW, bodyH);
    ctx.shadowBlur = 0;

    // Candle border for definition
    ctx.strokeStyle = c.bull ? 'rgba(0,255,140,0.4)' : 'rgba(255,100,90,0.4)';
    ctx.lineWidth = 0.5;
    ctx.strokeRect(cx, bTop, cW, bodyH);
  });

  // MA lines — smooth, colorful, thick
  const closes = vis.map(c => c.c);
  const maConfigs: [number, string, number][] = [
    [7,  '#38bdf8', 2],   // sky blue
    [20, '#00e676', 1.5], // bright green
    [50, '#ff6b9d', 1.5], // pink/red
  ];
  maConfigs.forEach(([period, col, lw]) => {
    ctx.strokeStyle = col; ctx.lineWidth = lw;
    ctx.shadowColor = col; ctx.shadowBlur = 4;
    ctx.beginPath();
    let started = false;
    closes.forEach((_, i) => {
      const ma = calcSMA(closes.slice(0, i + 1), period);
      if (ma === null) return;
      const x = i * slotW + slotW / 2, y = py(ma);
      if (!started) { ctx.moveTo(x, y); started = true; } else ctx.lineTo(x, y);
    });
    ctx.stroke();
    ctx.shadowBlur = 0;
  });

  // MA legend
  const legends: [string, string][] = [['MA7','#38bdf8'],['MA20','#00e676'],['MA50','#ff6b9d']];
  legends.forEach(([lbl, col], i) => {
    ctx.fillStyle = col; ctx.font = 'bold 8px monospace'; ctx.textAlign = 'left';
    ctx.fillText(lbl, 8 + i * 42, PRICE_PAD_T + 10);
  });

  // Current price line
  const lastPrice = vis[vis.length - 1].c;
  const lastY = py(lastPrice);
  ctx.setLineDash([4, 4]);
  ctx.strokeStyle = 'rgba(251,191,36,0.6)'; ctx.lineWidth = 1;
  ctx.beginPath(); ctx.moveTo(0, lastY); ctx.lineTo(CW, lastY); ctx.stroke();
  ctx.setLineDash([]);
  // Price tag
  ctx.fillStyle = '#fbbf24';
  ctx.fillRect(CW + 1, lastY - 8, PRICE_PAD_R - 2, 16);
  ctx.fillStyle = '#000'; ctx.font = 'bold 8px monospace'; ctx.textAlign = 'center';
  ctx.fillText(
    lastPrice >= 1000
      ? lastPrice.toLocaleString('en-US', { maximumFractionDigits: 0 })
      : lastPrice.toFixed(2),
    CW + PRICE_PAD_R / 2, lastY + 3
  );
}

function CandlestickChart({ candles, live }: { candles: Candle[]; live: Candle }) {
  const cvRef = useRef<HTMLCanvasElement>(null);
  const rafRef = useRef(0);
  const stRef = useRef({ candles, live });
  stRef.current = { candles, live };
  useEffect(() => {
    const cv = cvRef.current; if (!cv) return;
    const ctx = cv.getContext('2d'); if (!ctx) return;
    const draw = () => {
      const dpr = window.devicePixelRatio || 1, W = cv.clientWidth, H = cv.clientHeight;
      if (W === 0 || H === 0) { rafRef.current = requestAnimationFrame(draw); return; }
      if (cv.width !== Math.round(W * dpr) || cv.height !== Math.round(H * dpr)) {
        cv.width = Math.round(W * dpr); cv.height = Math.round(H * dpr);
      }
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      drawChart(ctx, W, H, stRef.current.candles, stRef.current.live);
      rafRef.current = requestAnimationFrame(draw);
    };
    rafRef.current = requestAnimationFrame(draw);
    return () => cancelAnimationFrame(rafRef.current);
  }, []);
  return <canvas ref={cvRef} style={{ display: 'block', width: '100%', height: '400px' }} />;
}

// ─── Waveform ─────────────────────────────────────────────────────────────────

function Waveform({ active }: { active: boolean }) {
  const cvRef = useRef<HTMLCanvasElement>(null);
  const frRef = useRef(0); const tick = useRef(0);
  useEffect(() => {
    const cv = cvRef.current; if (!cv) return;
    const ctx = cv.getContext('2d'); if (!ctx) return;
    const draw = () => {
      tick.current++;
      const t = tick.current;
      ctx.clearRect(0, 0, cv.width, cv.height);
      const bars = 56, gap = cv.width / bars, bw = Math.max(2, gap - 1.5);
      for (let i = 0; i < bars; i++) {
        const ph = (i / bars) * Math.PI * 2;
        const h = active
          ? (0.1 + 0.9 * Math.abs(Math.sin(t * 0.065 + ph + Math.sin(t * 0.022 + i * 0.45) * 1.3))) * cv.height * 0.88
          : (0.04 + 0.05 * Math.abs(Math.sin(t * 0.012 + ph))) * cv.height;
        const x = i * gap + (gap - bw) / 2, y = (cv.height - h) / 2;
        const g = ctx.createLinearGradient(0, y, 0, y + h);
        g.addColorStop(0,   active ? 'rgba(34,197,94,0.9)' : 'rgba(34,197,94,0.12)');
        g.addColorStop(0.5, active ? 'rgba(16,185,129,1)'  : 'rgba(16,185,129,0.18)');
        g.addColorStop(1,   active ? 'rgba(34,197,94,0.9)' : 'rgba(34,197,94,0.12)');
        ctx.fillStyle = g;
        ctx.shadowColor = active ? '#22c55e' : 'transparent';
        ctx.shadowBlur  = active ? 8 : 0;
        ctx.beginPath(); ctx.roundRect(x, y, bw, h, Math.min(bw / 2, 3)); ctx.fill();
      }
      ctx.shadowBlur = 0;
      frRef.current = requestAnimationFrame(draw);
    };
    frRef.current = requestAnimationFrame(draw);
    return () => cancelAnimationFrame(frRef.current);
  }, [active]);
  return <canvas ref={cvRef} width={520} height={44} className="atv4-waveform" aria-hidden="true" />;
}

// ─── Market Heatmap ───────────────────────────────────────────────────────────

function MarketHeatmap({ tickers }: { tickers: Ticker[] }) {
  const cvRef = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const cv = cvRef.current; if (!cv) return;
    const ctx = cv.getContext('2d'); if (!ctx) return;
    const dpr = window.devicePixelRatio || 1;
    const W = cv.clientWidth, H = cv.clientHeight;
    cv.width = Math.round(W * dpr); cv.height = Math.round(H * dpr);
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);

    const items = tickers.filter(t => t.price > 0);
    if (items.length === 0) {
      ctx.fillStyle = '#1e293b'; ctx.fillRect(0, 0, W, H);
      ctx.fillStyle = '#475569'; ctx.font = '11px monospace';
      ctx.textAlign = 'center'; ctx.fillText('Waiting for prices…', W / 2, H / 2);
      return;
    }
    const cols = Math.ceil(Math.sqrt(items.length));
    const rows = Math.ceil(items.length / cols);
    const cw = Math.floor(W / cols), ch = Math.floor(H / rows);
    items.forEach((t, i) => {
      const col = i % cols, row = Math.floor(i / cols);
      const x = col * cw, y = row * ch;
      const pct = t.changePct;
      const intensity = Math.min(1, Math.abs(pct) / 5);
      const color = pct >= 0
        ? `rgba(34,197,94,${0.15 + intensity * 0.65})`
        : `rgba(239,68,68,${0.15 + intensity * 0.65})`;
      ctx.fillStyle = color;
      ctx.fillRect(x + 1, y + 1, cw - 2, ch - 2);
      ctx.fillStyle = '#fff';
      ctx.font = `bold ${Math.min(13, cw / 5)}px monospace`;
      ctx.textAlign = 'center';
      ctx.fillText(t.key.replace('/USD', ''), x + cw / 2, y + ch / 2 - 6);
      ctx.font = `${Math.min(10, cw / 7)}px monospace`;
      ctx.fillStyle = pct >= 0 ? '#4ade80' : '#f87171';
      ctx.fillText(`${pct >= 0 ? '+' : ''}${pct.toFixed(2)}%`, x + cw / 2, y + ch / 2 + 10);
    });
  }, [tickers]);
  return <canvas ref={cvRef} style={{ display: 'block', width: '100%', height: '130px', borderRadius: '8px' }} />;
}

// ─── Portfolio Performance Line Chart ─────────────────────────────────────────

function PortfolioChart({ history }: { history: number[] }) {
  const cvRef = useRef<HTMLCanvasElement>(null);
  const stRef = useRef(history);
  stRef.current = history;
  useEffect(() => {
    const cv = cvRef.current; if (!cv) return;
    const ctx = cv.getContext('2d'); if (!ctx) return;
    const dpr = window.devicePixelRatio || 1;
    const W = cv.clientWidth || 300, H = cv.clientHeight || 80;
    cv.width = Math.round(W * dpr); cv.height = Math.round(H * dpr);
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    const pts = stRef.current;
    if (pts.length < 2) return;
    const min = Math.min(...pts), max = Math.max(...pts);
    const range = max - min || 1, pad = 8;
    const py = (v: number) => pad + (1 - (v - min) / range) * (H - pad * 2);
    const px = (i: number) => (i / (pts.length - 1)) * W;
    const isUp = pts[pts.length - 1] >= pts[0];
    const grad = ctx.createLinearGradient(0, 0, 0, H);
    grad.addColorStop(0, isUp ? 'rgba(34,197,94,0.35)' : 'rgba(239,68,68,0.35)');
    grad.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.beginPath();
    pts.forEach((v, i) => i === 0 ? ctx.moveTo(px(i), py(v)) : ctx.lineTo(px(i), py(v)));
    ctx.lineTo(W, H); ctx.lineTo(0, H); ctx.closePath();
    ctx.fillStyle = grad; ctx.fill();
    ctx.beginPath();
    pts.forEach((v, i) => i === 0 ? ctx.moveTo(px(i), py(v)) : ctx.lineTo(px(i), py(v)));
    ctx.strokeStyle = isUp ? '#22c55e' : '#ef4444';
    ctx.lineWidth = 2; ctx.stroke();
    // Last point dot
    const lx = px(pts.length - 1), ly = py(pts[pts.length - 1]);
    ctx.beginPath(); ctx.arc(lx, ly, 4, 0, Math.PI * 2);
    ctx.fillStyle = isUp ? '#22c55e' : '#ef4444';
    ctx.shadowColor = ctx.fillStyle; ctx.shadowBlur = 8;
    ctx.fill(); ctx.shadowBlur = 0;
  }, [history]);
  return <canvas ref={cvRef} style={{ display: 'block', width: '100%', height: '80px' }} />;
}

// ─── NDX / Index Sparkline Chart ─────────────────────────────────────────────

function IndexSparkline({ history, changePct }: { history: number[]; changePct: number }) {
  const cvRef = useRef<HTMLCanvasElement>(null);
  const stRef = useRef({ history, changePct });
  stRef.current = { history, changePct };
  useEffect(() => {
    const cv = cvRef.current; if (!cv) return;
    const ctx = cv.getContext('2d'); if (!ctx) return;
    const dpr = window.devicePixelRatio || 1;
    const W = cv.clientWidth || 200, H = cv.clientHeight || 48;
    cv.width = Math.round(W * dpr); cv.height = Math.round(H * dpr);
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, W, H);
    const pts = stRef.current.history;
    if (pts.length < 2) {
      ctx.fillStyle = '#1e293b'; ctx.fillRect(0, 0, W, H);
      return;
    }
    const isUp = stRef.current.changePct >= 0;
    const min = Math.min(...pts), max = Math.max(...pts), range = max - min || 1;
    const py = (v: number) => 4 + (1 - (v - min) / range) * (H - 8);
    const px = (i: number) => (i / (pts.length - 1)) * W;
    const grad = ctx.createLinearGradient(0, 0, 0, H);
    grad.addColorStop(0, isUp ? 'rgba(34,197,94,0.4)' : 'rgba(239,68,68,0.4)');
    grad.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.beginPath();
    pts.forEach((v, i) => i === 0 ? ctx.moveTo(px(i), py(v)) : ctx.lineTo(px(i), py(v)));
    ctx.lineTo(W, H); ctx.lineTo(0, H); ctx.closePath();
    ctx.fillStyle = grad; ctx.fill();
    ctx.beginPath();
    pts.forEach((v, i) => i === 0 ? ctx.moveTo(px(i), py(v)) : ctx.lineTo(px(i), py(v)));
    ctx.strokeStyle = isUp ? '#22c55e' : '#ef4444';
    ctx.lineWidth = 1.5; ctx.stroke();
  }, [history, changePct]);
  return <canvas ref={cvRef} style={{ display: 'block', width: '100%', height: '48px' }} />;
}

// ─── Broker Panel ─────────────────────────────────────────────────────────────

const BROKERS = [
  { id: 'binance', label: 'Binance', logo: '🟡', markets: 'Crypto  ·  BTC ETH SOL BNB', execSupport: true },
  { id: 'bybit',   label: 'Bybit',   logo: '🟠', markets: 'Crypto  ·  Coming soon',      execSupport: false },
  { id: 'alpaca',  label: 'Alpaca',  logo: '🦙', markets: 'NASDAQ  ·  AAPL NVDA TSLA SPY', execSupport: true },
] as const;
type BrokerId = typeof BROKERS[number]['id'];

export type LiveBrokerMap = Record<string, 'paper' | 'live'>;

function BrokerPanel({
  user,
  onLiveModeChange,
}: {
  user: User | null;
  onLiveModeChange: (map: LiveBrokerMap) => void;
}) {
  const [connected, setConnected] = useState<Record<string, boolean>>({});
  const [hints,     setHints]     = useState<Record<string, string>>({});
  const [modes,     setModes]     = useState<Record<string, 'paper' | 'live'>>({});
  const [open,      setOpen]      = useState<BrokerId | null>(null);
  const [apiKey,    setApiKey]    = useState('');
  const [apiSec,    setApiSec]    = useState('');
  const [showKey,   setShowKey]   = useState(false);
  const [saving,    setSaving]    = useState(false);
  const [saved,     setSaved]     = useState<BrokerId | null>(null);
  const [togglingMode, setTogglingMode] = useState<BrokerId | null>(null);
  const [liveConfirmId, setLiveConfirmId] = useState<BrokerId | null>(null);
  const [liveConfirmText, setLiveConfirmText] = useState('');

  useEffect(() => {
    if (!user) return;
    supabase
      .from('trading_broker_connections')
      .select('broker,api_key_hint,is_active')
      .eq('user_id', user.id)
      .then(({ data }) => {
        if (!data) return;
        const c: Record<string, boolean> = {};
        const h: Record<string, string> = {};
        data.forEach(d => { c[d.broker] = d.is_active; h[d.broker] = d.api_key_hint; });
        setConnected(c); setHints(h);
      });
    supabase
      .from('broker_secrets')
      .select('broker,mode')
      .eq('user_id', user.id)
      .then(({ data }) => {
        if (!data) return;
        const m: Record<string, 'paper' | 'live'> = {};
        data.forEach(d => { m[d.broker] = d.mode; });
        setModes(m);
        onLiveModeChange(m);
      });
  }, [user]); // eslint-disable-line react-hooks/exhaustive-deps

  const save = useCallback(async (id: BrokerId) => {
    if (!user || !apiKey.trim() || !apiSec.trim()) return;
    setSaving(true);
    const hint = '•••• ' + apiKey.trim().slice(-4);

    // Save hint + status in public table
    await supabase.from('trading_broker_connections').upsert({
      user_id: user.id, broker: id,
      label: BROKERS.find(b => b.id === id)!.label,
      api_key_hint: hint, permissions: ['read', 'trade'],
      withdraw_locked: true, is_active: true,
    }, { onConflict: 'user_id,broker' });

    // Save actual keys in secure vault (service_role only)
    await supabase.from('broker_secrets').upsert({
      user_id: user.id, broker: id,
      api_key: apiKey.trim(), api_secret: apiSec.trim(),
      mode: 'paper',
    }, { onConflict: 'user_id,broker' });

    const updModes = { ...modes, [id]: 'paper' as const };
    setConnected(p => ({ ...p, [id]: true }));
    setHints(p => ({ ...p, [id]: hint }));
    setModes(updModes);
    onLiveModeChange(updModes);
    setSaving(false); setSaved(id); setOpen(null); setApiKey(''); setApiSec('');
    setTimeout(() => setSaved(null), 3000);
  }, [user, apiKey, apiSec, modes, onLiveModeChange]);

  const toggleMode = useCallback(async (id: BrokerId) => {
    if (!user) return;
    const current = modes[id] ?? 'paper';
    if (current === 'paper') {
      // Going LIVE → show confirmation first
      setLiveConfirmId(id);
      setLiveConfirmText('');
      return;
    }
    // Going back to paper → no confirmation needed
    setTogglingMode(id);
    await supabase.from('broker_secrets')
      .update({ mode: 'paper' })
      .eq('user_id', user.id)
      .eq('broker', id);
    const updModes = { ...modes, [id]: 'paper' as const };
    setModes(updModes);
    onLiveModeChange(updModes);
    setTogglingMode(null);
  }, [user, modes, onLiveModeChange]);

  const confirmGoLive = useCallback(async (id: BrokerId) => {
    if (!user) return;
    setTogglingMode(id);
    await supabase.from('broker_secrets')
      .update({ mode: 'live' })
      .eq('user_id', user.id)
      .eq('broker', id);
    const updModes = { ...modes, [id]: 'live' as const };
    setModes(updModes);
    onLiveModeChange(updModes);
    setLiveConfirmId(null);
    setLiveConfirmText('');
    setTogglingMode(null);
  }, [user, modes, onLiveModeChange]);

  const disconnect = useCallback(async (id: BrokerId) => {
    if (!user) return;
    await supabase.from('trading_broker_connections').delete().eq('user_id', user.id).eq('broker', id);
    await supabase.from('broker_secrets').delete().eq('user_id', user.id).eq('broker', id);
    const updModes = { ...modes };
    delete updModes[id];
    setConnected(p => { const n = { ...p }; delete n[id]; return n; });
    setHints(p => { const n = { ...p }; delete n[id]; return n; });
    setModes(updModes);
    onLiveModeChange(updModes);
  }, [user, modes, onLiveModeChange]);

  return (
    <div className="atv4-broker-panel">
      <div className="atv4-panel-hdr">
        <Key size={12} className="atv4-icon-green"/>
        <span>Broker Connections</span>
        <span className="atv4-chip atv4-chip--amber">WITHDRAW LOCKED</span>
      </div>
      <div className="atv4-broker-note">
        <Info size={10} style={{ color: '#f59e0b', flexShrink: 0 }}/>
        <span>Connect broker API so AI places <strong>real orders</strong> on your account. No API key = paper mode only.</span>
      </div>

      {BROKERS.map(b => {
        const isConn = !!connected[b.id];
        const isOpen = open === b.id;
        const mode   = modes[b.id] ?? 'paper';
        const isLive = mode === 'live';

        return (
          <div key={b.id} className={`atv4-broker-row${isOpen ? ' atv4-broker-row--open' : ''}`}>
            <div className="atv4-broker-row__top">
              <span className="atv4-broker-row__logo">{b.logo}</span>
              <div className="atv4-broker-row__info">
                <span className="atv4-broker-row__name">{b.label}</span>
                <span className="atv4-broker-row__mkt">{b.markets}</span>
              </div>

              {isConn ? (
                <div className="atv4-broker-row__conn">
                  <CheckCircle size={10} style={{ color: '#22c55e' }}/>
                  <span className="atv4-broker-row__hint">{hints[b.id]}</span>
                  {b.execSupport ? (
                    <button
                      className={`atv4-mode-toggle${isLive ? ' atv4-mode-toggle--live' : ''}`}
                      onClick={() => toggleMode(b.id)}
                      disabled={togglingMode === b.id}
                      title={isLive ? 'Switch to Paper mode' : 'Switch to LIVE trading'}
                    >
                      {togglingMode === b.id
                        ? <span className="atv4-spinner"/>
                        : isLive ? <><Zap size={8}/> LIVE</> : <><Play size={8}/> PAPER</>
                      }
                    </button>
                  ) : (
                    <span className="atv4-broker-row__lock"><Lock size={8}/> Soon</span>
                  )}
                  <button className="atv4-broker-disc" onClick={() => disconnect(b.id)} title="Disconnect">✕</button>
                </div>
              ) : (
                <button
                  className="atv4-broker-btn"
                  onClick={() => setOpen(isOpen ? null : b.id)}
                  disabled={!b.execSupport}
                >
                  {!b.execSupport ? 'Soon' : isOpen ? 'Cancel' : 'Connect'}
                </button>
              )}
              {saved === b.id && <span className="atv4-saved">Connected!</span>}
            </div>

            {isOpen && (
              <div className="atv4-broker-form">
                <div className="atv4-broker-form__sec">
                  <Shield size={9} style={{ color: '#22c55e' }}/>
                  <span>
                    {b.id === 'binance'
                      ? 'Binance: enable Read + Spot Trading. DISABLE withdrawals.'
                      : 'Alpaca: paper starts free. Live requires funded account.'}
                  </span>
                </div>
                <div className="atv4-broker-form__field">
                  <label>API Key</label>
                  <div className="atv4-inp-wrap">
                    <input
                      type={showKey ? 'text' : 'password'}
                      placeholder={b.id === 'alpaca' ? 'APCA-API-KEY-ID…' : 'Paste API key…'}
                      value={apiKey}
                      onChange={e => setApiKey(e.target.value)}
                      autoComplete="off"
                    />
                    <button onClick={() => setShowKey(s => !s)}>
                      {showKey ? <EyeOff size={11}/> : <Eye size={11}/>}
                    </button>
                  </div>
                </div>
                <div className="atv4-broker-form__field">
                  <label>{b.id === 'alpaca' ? 'API Secret Key' : 'API Secret'}</label>
                  <input
                    type="password"
                    placeholder={b.id === 'alpaca' ? 'APCA-API-SECRET-KEY…' : 'Paste secret…'}
                    value={apiSec}
                    onChange={e => setApiSec(e.target.value)}
                    autoComplete="off"
                    className="atv4-inp"
                  />
                </div>
                <p className="atv4-form-note" style={{ color: '#94a3b8', marginBottom: '6px' }}>
                  Starts in <strong>Paper mode</strong> — no real money until you switch to LIVE.
                </p>
                <button
                  className="atv4-broker-form__submit"
                  disabled={saving || !apiKey.trim() || !apiSec.trim() || !user}
                  onClick={() => save(b.id)}
                >
                  {saving
                    ? <><span className="atv4-spinner"/>Saving…</>
                    : <><Lock size={10}/>Activate Secure Connection</>
                  }
                </button>
                {!user && <p className="atv4-form-note">Sign in to persist API connections.</p>}
              </div>
            )}

            {/* ── LIVE mode confirmation ─────────────────────────────────── */}
            {liveConfirmId === b.id && (
              <div className="tdm-live-confirm">
                <div className="tdm-live-confirm__title">
                  <AlertTriangle size={12}/> Activate LIVE Trading — Real Money
                </div>
                <p className="tdm-live-confirm__text">
                  You are about to authorise the AI to place <strong>real orders</strong> on your {b.label} account.
                  Orders are executed immediately. <strong>Losses are entirely at your own risk.</strong>
                  Type <strong>LIVE</strong> to confirm.
                </p>
                <input
                  className="tdm-live-confirm__input"
                  placeholder="LIVE"
                  value={liveConfirmText}
                  onChange={e => setLiveConfirmText(e.target.value)}
                  autoComplete="off"
                  spellCheck={false}
                />
                <div className="tdm-live-confirm__btns">
                  <button className="tdm-live-btn-cancel" onClick={() => setLiveConfirmId(null)}>Cancel</button>
                  <button
                    className="tdm-live-btn-go"
                    disabled={liveConfirmText.trim().toUpperCase() !== 'LIVE' || togglingMode === b.id}
                    onClick={() => confirmGoLive(b.id)}
                  >
                    {togglingMode === b.id ? <span className="atv4-spinner"/> : <><Zap size={10}/> Activate LIVE</>}
                  </button>
                </div>
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}

// ─── Financial TV — Broadcast Screen ─────────────────────────────────────────

const SOURCE_COLORS: Record<string, string> = {
  'Bloomberg': '#f59e0b', 'Reuters': '#e11d48', 'CNBC': '#0ea5e9',
  'FT': '#f97316', 'Financial Times': '#f97316', 'WSJ': '#94a3b8',
  'CoinDesk': '#f59e0b', 'CoinTelegraph': '#22c55e',
  'Nikkei Asia': '#dc2626', 'Decrypt': '#8b5cf6', 'The Block': '#06b6d4',
  'Whale Alert': '#f59e0b',
};

const FALLBACK_TV_NEWS: NewsTick[] = [
  { id:'f1', ts:'', headline:'Global markets open higher on optimistic Fed commentary', source:'Reuters', sentiment:'bullish', score:0.6 },
  { id:'f2', ts:'', headline:'Bitcoin holds $65K support — institutional buyers step in', source:'Bloomberg', sentiment:'bullish', score:0.7 },
  { id:'f3', ts:'', headline:'NASDAQ futures up 0.4% ahead of big tech earnings', source:'CNBC', sentiment:'bullish', score:0.5 },
  { id:'f4', ts:'', headline:'Oil prices stabilize after OPEC supply concerns ease', source:'Reuters', sentiment:'neutral', score:0.1 },
  { id:'f5', ts:'', headline:'Gold near all-time highs as central banks continue buying', source:'FT', sentiment:'bullish', score:0.6 },
  { id:'f6', ts:'', headline:'Ethereum ETF inflows hit record $600M in single session', source:'CoinDesk', sentiment:'bullish', score:0.8 },
];

// Typewriter hook: types out text char-by-char, resets when text changes
function useTypewriter(text: string, speed = 28): string {
  const [displayed, setDisplayed] = useState('');
  useEffect(() => {
    setDisplayed('');
    if (!text) return;
    let i = 0;
    const iv = setInterval(() => {
      i++;
      setDisplayed(text.slice(0, i));
      if (i >= text.length) clearInterval(iv);
    }, speed);
    return () => clearInterval(iv);
  }, [text, speed]);
  return displayed;
}

// Chart assets mapped to ticker keys
const CHART_ASSETS = [
  { key: 'BTC/USD',  label: 'BTC',   color: '#f59e0b', basePrice: 67000 },
  { key: 'ETH/USD',  label: 'ETH',   color: '#8b5cf6', basePrice: 3500  },
  { key: 'AAPL',     label: 'AAPL',  color: '#22c55e', basePrice: 189   },
  { key: 'TSLA',     label: 'TSLA',  color: '#ef4444', basePrice: 177   },
  { key: 'SOL/USD',  label: 'SOL',   color: '#06b6d4', basePrice: 170   },
  { key: 'NVDA',     label: 'NVDA',  color: '#a3e635', basePrice: 875   },
];

// Generate realistic OHLCV candles seeded from a live price
function generateCandles(livePrice: number, count = 60): Candle[] {
  const candles: Candle[] = [];
  let price = livePrice * (1 - (Math.random() * 0.04 + 0.02));
  const vol = livePrice * 0.002;
  for (let i = 0; i < count; i++) {
    const move  = (Math.random() - 0.48) * vol;
    const open  = price;
    const close = Math.max(price + move, price * 0.985);
    const high  = Math.max(open, close) + Math.random() * vol * 0.5;
    const low   = Math.min(open, close) - Math.random() * vol * 0.5;
    candles.push({ o: open, h: high, l: low, c: close, v: Math.random() * 1000 + 200, bull: close >= open });
    price = close;
  }
  // Last candle closes exactly at live price
  if (candles.length > 0) {
    const last = candles[candles.length - 1];
    last.c = livePrice;
    last.h = Math.max(last.h, livePrice);
    last.l = Math.min(last.l, livePrice);
    last.bull = livePrice >= last.o;
  }
  return candles;
}

interface FinancialTVProps {
  newsFeed:       NewsTick[];
  tickers:        Ticker[];
  aiLog:          string[];
  tradeDecisions: TradeDecision[];
}

// ─── Candlestick SVG chart ────────────────────────────────────────────────────
function CandleChart({ candles, color, livePrice, changePct }: {
  candles: Candle[]; color: string; livePrice: number; changePct: number;
}) {
  const W = 680, H = 220, PAD_L = 52, PAD_R = 56, PAD_T = 14, PAD_B = 32;
  const cw = W - PAD_L - PAD_R;
  const ch = H - PAD_T - PAD_B;
  const n  = candles.length;
  if (n === 0) return null;

  const prices = candles.flatMap(c => [c.h, c.l]);
  const minP   = Math.min(...prices);
  const maxP   = Math.max(...prices);
  const range  = maxP - minP || 1;

  const px = (i: number) => PAD_L + (i + 0.5) * (cw / n);
  const py = (p: number) => PAD_T + ch - ((p - minP) / range) * ch;

  const barW  = Math.max(1, cw / n - 1.5);
  const vMax  = Math.max(...candles.map(c => c.v));
  const volH  = 28;

  // Close-price line
  const linePts = candles.map((c, i) => `${px(i)},${py(c.c)}`).join(' ');

  // Grid lines
  const gridSteps = 4;
  const grids = Array.from({ length: gridSteps + 1 }, (_, i) => {
    const val = minP + (range * i) / gridSteps;
    const y   = py(val);
    return { y, val };
  });

  const fmt = (v: number) =>
    v >= 1000 ? `$${(v / 1000).toFixed(1)}k` : v >= 1 ? `$${v.toFixed(2)}` : `$${v.toFixed(4)}`;

  return (
    <svg viewBox={`0 0 ${W} ${H + volH}`} preserveAspectRatio="none"
      style={{ width: '100%', height: '100%', display: 'block' }}>
      {/* background */}
      <rect width={W} height={H + volH} fill="#060f1e" />

      {/* grid lines */}
      {grids.map(({ y, val }, i) => (
        <g key={i}>
          <line x1={PAD_L} x2={W - PAD_R} y1={y} y2={y}
            stroke="#1e3a5f" strokeWidth="0.5" strokeDasharray="3,4" />
          <text x={W - PAD_R + 4} y={y + 3.5} fill="#475569"
            fontSize="8.5" fontFamily="monospace">{fmt(val)}</text>
        </g>
      ))}

      {/* vertical time marks */}
      {[0.25, 0.5, 0.75].map(frac => {
        const x = PAD_L + cw * frac;
        return <line key={frac} x1={x} x2={x} y1={PAD_T} y2={H - PAD_B}
          stroke="#1e3a5f" strokeWidth="0.5" strokeDasharray="2,5" />;
      })}

      {/* area under close line */}
      <defs>
        <linearGradient id="areaGrad" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={color} stopOpacity="0.18" />
          <stop offset="100%" stopColor={color} stopOpacity="0" />
        </linearGradient>
      </defs>
      <polygon
        points={`${PAD_L},${H - PAD_B} ${linePts} ${W - PAD_R},${H - PAD_B}`}
        fill="url(#areaGrad)"
      />

      {/* close price polyline */}
      <polyline points={linePts} fill="none" stroke={color} strokeWidth="1.2" opacity="0.5" />

      {/* candle bodies + wicks */}
      {candles.map((c, i) => {
        const x  = px(i);
        const x0 = x - barW / 2;
        const oy = py(c.o), cy2 = py(c.c);
        const bodyT = Math.min(oy, cy2);
        const bodyH = Math.max(Math.abs(oy - cy2), 1);
        const col   = c.bull ? '#22c55e' : '#ef4444';
        return (
          <g key={i}>
            <line x1={x} x2={x} y1={py(c.h)} y2={py(c.l)}
              stroke={col} strokeWidth="0.8" />
            <rect x={x0} y={bodyT} width={barW} height={bodyH}
              fill={c.bull ? col : col} opacity="0.85" rx="0.5" />
          </g>
        );
      })}

      {/* live price line */}
      <line x1={PAD_L} x2={W - PAD_R} y1={py(livePrice)} y2={py(livePrice)}
        stroke={color} strokeWidth="0.8" strokeDasharray="4,3" opacity="0.9" />
      <rect x={W - PAD_R + 2} y={py(livePrice) - 7} width={PAD_R - 3} height={14}
        fill={color} rx="2" opacity="0.9" />
      <text x={W - PAD_R + 4} y={py(livePrice) + 3.5} fill="#000"
        fontSize="8" fontWeight="bold" fontFamily="monospace">{fmt(livePrice)}</text>

      {/* volume bars */}
      {candles.map((c, i) => {
        const bh = volH * (c.v / vMax) * 0.9;
        const col = c.bull ? '#22c55e' : '#ef4444';
        return (
          <rect key={i} x={px(i) - barW / 2} y={H + volH - bh}
            width={barW} height={bh} fill={col} opacity="0.45" />
        );
      })}

      {/* X axis */}
      <line x1={PAD_L} x2={W - PAD_R} y1={H - PAD_B} y2={H - PAD_B}
        stroke="#1e3a5f" strokeWidth="1" />
      {/* Y axis */}
      <line x1={PAD_L} x2={PAD_L} y1={PAD_T} y2={H - PAD_B}
        stroke="#1e3a5f" strokeWidth="1" />

      {/* % change badge top-left */}
      <rect x={PAD_L + 4} y={PAD_T + 2} width={46} height={14} rx="3"
        fill={changePct >= 0 ? '#14532d' : '#450a0a'} />
      <text x={PAD_L + 27} y={PAD_T + 12} fill={changePct >= 0 ? '#4ade80' : '#f87171'}
        fontSize="9" fontWeight="bold" fontFamily="monospace" textAnchor="middle">
        {changePct >= 0 ? '+' : ''}{changePct.toFixed(2)}%
      </text>
    </svg>
  );
}

// ─── Aippie anchor bot (animated SVG presenter) ──────────────────────────────
function AnchorBot({ talking, emotion }: { talking: boolean; emotion: 'neutral' | 'bullish' | 'bearish' }) {
  const headColor  = emotion === 'bullish' ? '#0ea5e9' : emotion === 'bearish' ? '#ef4444' : '#38bdf8';
  const suitColor  = '#0f172a';
  const tieColor   = emotion === 'bullish' ? '#22c55e' : emotion === 'bearish' ? '#ef4444' : '#0ea5e9';

  // Mouth open/close driven by `talking`
  const mouth = talking
    ? 'M 46 76 Q 50 82 54 76'   // open
    : 'M 46 76 Q 50 78 54 76';  // closed

  return (
    <svg viewBox="0 0 100 160" style={{ width: '100%', height: '100%', overflow: 'visible' }}>
      <defs>
        <radialGradient id="faceGrad" cx="50%" cy="40%" r="60%">
          <stop offset="0%" stopColor="#1e3a5f" />
          <stop offset="100%" stopColor="#0c1a2e" />
        </radialGradient>
        <radialGradient id="glowGrad" cx="50%" cy="50%" r="50%">
          <stop offset="0%" stopColor={headColor} stopOpacity="0.35" />
          <stop offset="100%" stopColor={headColor} stopOpacity="0" />
        </radialGradient>
        <filter id="glow">
          <feGaussianBlur stdDeviation="2.5" result="blur" />
          <feMerge><feMergeNode in="blur" /><feMergeNode in="SourceGraphic" /></feMerge>
        </filter>
      </defs>

      {/* Ambient glow halo */}
      <ellipse cx="50" cy="55" rx="38" ry="42" fill="url(#glowGrad)" />

      {/* Suit / body */}
      <path d="M 18 160 L 18 108 Q 30 95 50 92 Q 70 95 82 108 L 82 160 Z" fill={suitColor} />
      {/* Lapels */}
      <path d="M 50 92 L 38 112 L 50 108 L 62 112 Z" fill="#1e293b" />
      {/* Tie */}
      <path d="M 46 108 L 50 132 L 54 108 L 50 104 Z" fill={tieColor} opacity="0.9" />
      {/* Shirt */}
      <rect x="46" y="104" width="8" height="28" rx="1" fill="#e2e8f0" opacity="0.15" />

      {/* Neck */}
      <rect x="43" y="83" width="14" height="12" rx="4" fill="#1e3a5f" />

      {/* Head */}
      <ellipse cx="50" cy="58" rx="26" ry="28" fill="url(#faceGrad)" stroke={headColor} strokeWidth="1.2" />

      {/* Forehead circuit lines */}
      <line x1="36" y1="44" x2="42" y2="44" stroke={headColor} strokeWidth="0.6" opacity="0.5" />
      <line x1="42" y1="44" x2="42" y2="40" stroke={headColor} strokeWidth="0.6" opacity="0.5" />
      <line x1="58" y1="44" x2="64" y2="44" stroke={headColor} strokeWidth="0.6" opacity="0.5" />
      <line x1="58" y1="44" x2="58" y2="40" stroke={headColor} strokeWidth="0.6" opacity="0.5" />
      <circle cx="42" cy="40" r="1.2" fill={headColor} opacity="0.7" />
      <circle cx="58" cy="40" r="1.2" fill={headColor} opacity="0.7" />

      {/* Eyes */}
      <ellipse cx="40" cy="57" rx="5" ry="5.5" fill="#0c1a2e" stroke={headColor} strokeWidth="0.8" />
      <ellipse cx="60" cy="57" rx="5" ry="5.5" fill="#0c1a2e" stroke={headColor} strokeWidth="0.8" />
      {/* Iris */}
      <circle cx="40" cy="57" r="3" fill={headColor} filter="url(#glow)" />
      <circle cx="60" cy="57" r="3" fill={headColor} filter="url(#glow)" />
      {/* Pupil */}
      <circle cx="40" cy="57" r="1.4" fill="#fff" opacity="0.9" />
      <circle cx="60" cy="57" r="1.4" fill="#fff" opacity="0.9" />
      {/* Highlight */}
      <circle cx="41.5" cy="55.5" r="0.8" fill="#fff" opacity="0.6" />
      <circle cx="61.5" cy="55.5" r="0.8" fill="#fff" opacity="0.6" />

      {/* Brow */}
      <path d="M 35 50 Q 40 48 45 50" stroke={headColor} strokeWidth="1" fill="none" opacity="0.7" />
      <path d="M 55 50 Q 60 48 65 50" stroke={headColor} strokeWidth="1" fill="none" opacity="0.7" />

      {/* Nose */}
      <path d="M 50 62 L 47 69 L 53 69" stroke={headColor} strokeWidth="0.7" fill="none" opacity="0.5" />

      {/* Mouth — animated */}
      <path d={mouth} stroke={headColor} strokeWidth="1.4" fill="none"
        style={{ transition: 'all 0.12s ease' }} />

      {/* Ears with circuit detail */}
      <ellipse cx="24" cy="58" rx="3.5" ry="5" fill="#1e3a5f" stroke={headColor} strokeWidth="0.8" />
      <ellipse cx="76" cy="58" rx="3.5" ry="5" fill="#1e3a5f" stroke={headColor} strokeWidth="0.8" />
      <line x1="21" y1="58" x2="26" y2="58" stroke={headColor} strokeWidth="0.5" opacity="0.5" />
      <line x1="74" y1="58" x2="79" y2="58" stroke={headColor} strokeWidth="0.5" opacity="0.5" />

      {/* Animated pulse ring when talking */}
      {talking && (
        <ellipse cx="50" cy="58" rx="30" ry="32" fill="none"
          stroke={headColor} strokeWidth="1.5" opacity="0.4"
          style={{ animation: 'aippie-pulse 1s ease-in-out infinite' }} />
      )}

      {/* LIVE badge */}
      <rect x="33" y="12" width="34" height="12" rx="3" fill="#e11d48" />
      <text x="50" y="21" textAnchor="middle" fill="#fff" fontSize="7" fontWeight="bold" fontFamily="monospace">
        ● LIVE
      </text>

      {/* Name plate */}
      <rect x="20" y="140" width="60" height="16" rx="2" fill={headColor} opacity="0.15" stroke={headColor} strokeWidth="0.5" />
      <text x="50" y="151" textAnchor="middle" fill={headColor} fontSize="7" fontWeight="bold" fontFamily="monospace">AIPPIE AI</text>
    </svg>
  );
}

// ─── FinancialTV ─────────────────────────────────────────────────────────────
function FinancialTV({ newsFeed, tickers, aiLog, tradeDecisions }: FinancialTVProps) {
  const [newsIdx, setNewsIdx]      = useState(0);
  const [collapsed, setCollapsed]  = useState(false);
  const [clock, setClock]          = useState(() => new Date().toLocaleTimeString('en-US', { hour12: false }));
  const [assetIdx, setAssetIdx]    = useState(0);
  const [candles, setCandles]      = useState<Candle[]>([]);
  const [anchorTalking, setAnchorTalking] = useState(false);
  const candleTimer                = useRef<ReturnType<typeof setTimeout>>();
  const talkTimer                  = useRef<ReturnType<typeof setTimeout>>();

  const feed  = newsFeed.length > 0 ? newsFeed : FALLBACK_TV_NEWS;
  const item  = feed[newsIdx % feed.length];
  const asset = CHART_ASSETS[assetIdx];

  // Find live price for selected asset from tickers
  const liveTicker  = tickers.find(t => t.key === asset.key);
  const livePrice   = liveTicker?.price  ?? asset.basePrice;
  const changePct   = liveTicker?.changePct ?? 0;

  // Rebuild candles when asset or live price changes meaningfully
  useEffect(() => {
    setCandles(generateCandles(livePrice || asset.basePrice));
  }, [assetIdx]);

  // Append a new micro-candle every 3s to simulate live movement
  useEffect(() => {
    candleTimer.current = setInterval(() => {
      setCandles(prev => {
        if (prev.length === 0) return prev;
        const last    = prev[prev.length - 1];
        const jitter  = livePrice * 0.0008;
        const newC    = last.c + (Math.random() - 0.48) * jitter;
        const updated = { ...last, c: newC, h: Math.max(last.h, newC), l: Math.min(last.l, newC), bull: newC >= last.o };
        return [...prev.slice(-59), updated];
      });
    }, 3000);
    return () => clearInterval(candleTimer.current);
  }, [livePrice]);

  useEffect(() => {
    const iv = setInterval(() => setClock(new Date().toLocaleTimeString('en-US', { hour12: false })), 1000);
    return () => clearInterval(iv);
  }, []);

  useEffect(() => {
    const iv = setInterval(() => {
      setNewsIdx(i => (i + 1) % feed.length);
      // Trigger talking animation for 4 seconds when headline changes
      setAnchorTalking(true);
      clearTimeout(talkTimer.current);
      talkTimer.current = setTimeout(() => setAnchorTalking(false), 4000);
    }, 10000);
    return () => clearInterval(iv);
  }, [feed.length]);

  const typedHeadline  = useTypewriter(item?.headline ?? '', 25);
  const latestDecision = tradeDecisions[0];
  const allTickers     = tickers.filter(t => t.price > 0).slice(0, 10);
  const srcColor       = SOURCE_COLORS[item?.source ?? ''] ?? '#64748b';

  const fmtLive = (v: number) =>
    v >= 1000 ? `$${v.toLocaleString('en-US', { maximumFractionDigits: 0 })}` :
    v >= 1    ? `$${v.toFixed(2)}` : `$${v.toFixed(4)}`;

  return (
    <div className={`atv-tv${collapsed ? ' atv-tv--collapsed' : ''}`}>

      {/* ── Station bar ─────────────────────────────────────────────────── */}
      <div className="atv-tv__bar">
        <div className="atv-tv__bar-left">
          <span className="atv-tv__live-dot" />
          <span className="atv-tv__live-label">AIPPIE FINANCIAL TV</span>
          <span className="atv-tv__sep">|</span>
          <span className="atv-tv__clock">{clock}</span>
          <span className="atv-tv__sep">|</span>
          {CHART_ASSETS.map((a, i) => (
            <button
              key={a.key}
              className={`atv-tv__sym-btn${assetIdx === i ? ' atv-tv__sym-btn--active' : ''}`}
              style={assetIdx === i ? { color: a.color, borderColor: a.color } : {}}
              onClick={() => { setAssetIdx(i); setCollapsed(false); }}
            >{a.label}</button>
          ))}
        </div>
        <div className="atv-tv__bar-right">
          <span style={{ fontSize: 11, fontWeight: 700, color: asset.color }}>
            {fmtLive(livePrice)}
          </span>
          <span style={{ fontSize: 10, color: changePct >= 0 ? '#4ade80' : '#f87171', marginLeft: 6 }}>
            {changePct >= 0 ? '▲' : '▼'}{Math.abs(changePct).toFixed(2)}%
          </span>
          <button className="atv-tv__icon-btn" style={{ marginLeft: 8 }} onClick={() => setCollapsed(c => !c)}>
            {collapsed ? <Play size={11}/> : <Square size={11}/>}
          </button>
        </div>
      </div>

      {!collapsed && (
        <div className="atv-tv__body">

          {/* ══ LEFT: Live candlestick chart ════════════════════════════ */}
          <div className="atv-tv__broadcast">

            {/* Chart + anchor row */}
            <div style={{ display: 'flex', gap: 0, flex: 1, minHeight: 0 }}>

              {/* Anchor bot panel */}
              <div style={{
                width: 90, minWidth: 90, background: 'linear-gradient(180deg,#060f1e 0%,#0c1a2e 100%)',
                borderRight: '1px solid #1e3a5f', display: 'flex', flexDirection: 'column',
                alignItems: 'center', justifyContent: 'center', padding: '8px 4px', gap: 4,
              }}>
                <div style={{ width: 80, height: 124 }}>
                  <AnchorBot
                    talking={anchorTalking}
                    emotion={changePct > 0.5 ? 'bullish' : changePct < -0.5 ? 'bearish' : 'neutral'}
                  />
                </div>
                <div style={{
                  fontSize: 8, color: '#64748b', fontFamily: 'monospace',
                  textAlign: 'center', lineHeight: 1.4, padding: '0 2px',
                }}>
                  {anchorTalking
                    ? <span style={{ color: '#e11d48' }}>● BREAKING</span>
                    : <span style={{ color: '#0ea5e9' }}>AIPPIE TV</span>
                  }
                </div>
                {/* Mini waveform bars when talking */}
                {anchorTalking && (
                  <div style={{ display: 'flex', gap: 1.5, alignItems: 'flex-end', height: 14 }}>
                    {Array.from({ length: 7 }, (_, i) => (
                      <div key={i} style={{
                        width: 3, background: '#e11d48', borderRadius: 1,
                        animation: `atv-wave ${0.3 + i * 0.07}s ease-in-out infinite alternate`,
                        height: 4 + Math.sin(i * 1.2) * 6 + 4,
                      }} />
                    ))}
                  </div>
                )}
              </div>

              {/* Chart area */}
              <div className="atv-tv__chart-wrap" style={{ flex: 1, minWidth: 0 }}>
                <CandleChart
                  candles={candles}
                  color={asset.color}
                  livePrice={livePrice}
                  changePct={changePct}
                />
                {/* Breaking news + AI lower-third overlay */}
                <div className="atv-tv__overlay">
                  <div className={`atv-tv__ol-headline atv-tv__ol-headline--${item?.sentiment ?? 'neutral'}`}>
                    <span className="atv-tv__ol-src" style={{ color: srcColor }}>{item?.source}</span>
                    <span className="atv-tv__ol-text">{typedHeadline}<span className="atv-tv__cursor">|</span></span>
                  </div>
                  {latestDecision && (
                    <div className={`atv-tv__lower-third atv-tv__lower-third--${latestDecision.action.toLowerCase()}`}>
                      <div className="atv-tv__lower-badge">AIPPIE AI</div>
                      <div className={`atv-tv__lower-action atv-tv__lower-action--${latestDecision.action.toLowerCase()}`}>
                        {latestDecision.action === 'IN' ? '▲ ENTER' : '▼ EXIT'}
                      </div>
                      <div className="atv-tv__lower-asset">{latestDecision.asset.replace('/USD','')}</div>
                      <div className="atv-tv__lower-conf">{latestDecision.confidence}% conf</div>
                      <div className="atv-tv__lower-reason">{latestDecision.reasoning[0]}</div>
                    </div>
                  )}
                </div>
              </div>

            </div>

            {/* Live price ticker strip */}
            <div className="atv-tv__price-strip">
              {allTickers.map(t => (
                <span key={t.key} className={`atv-tv__price-chip atv-tv__price-chip--${t.dir}`}>
                  <span className="atv-tv__price-chip-key">{t.key.replace('/USD','')}</span>
                  <span className="atv-tv__price-chip-val">{fmtLive(t.price)}</span>
                  <span className={`atv-tv__price-chip-pct ${t.changePct >= 0 ? 'atv-pos' : 'atv-neg'}`}>
                    {t.changePct >= 0 ? '▲' : '▼'}{Math.abs(t.changePct).toFixed(1)}%
                  </span>
                </span>
              ))}
            </div>

            {/* Progress bar: time until next headline */}
            <div className="atv-tv__progress-wrap">
              <div className="atv-tv__progress-bar" key={newsIdx} />
            </div>

          </div>

          {/* ══ RIGHT: News queue + AI log ═══════════════════════════════ */}
          <div className="atv-tv__queue">
            <div className="atv-tv__queue-hdr">
              <Newspaper size={10} style={{ color: '#e11d48' }} />
              <span>NIEUWS WACHTRIJ</span>
              <span className="atv-tv__live-dot atv-tv__live-dot--sm" style={{ marginLeft: 'auto' }} />
            </div>
            {feed.map((n, i) => (
              <button
                key={n.id}
                className={`atv-tv__queue-item${i === newsIdx % feed.length ? ' atv-tv__queue-item--active' : ''} atv-tv__queue-item--${n.sentiment}`}
                onClick={() => setNewsIdx(i)}
              >
                <span className={`atv-tv__queue-dot atv-tv__queue-dot--${n.sentiment}`} />
                <div className="atv-tv__queue-text">
                  <span className="atv-tv__queue-src" style={{ color: SOURCE_COLORS[n.source] ?? '#64748b' }}>{n.source}</span>
                  <span className="atv-tv__queue-hl">{n.headline}</span>
                </div>
                {i === newsIdx % feed.length && <span className="atv-tv__queue-now">ON AIR</span>}
              </button>
            ))}
            {aiLog.length > 0 && (
              <>
                <div className="atv-tv__queue-hdr" style={{ marginTop: 6 }}>
                  <Bot size={10} style={{ color: '#0ea5e9' }} />
                  <span>AI LOG</span>
                </div>
                {aiLog.slice(0, 4).map((line, i) => (
                  <div key={i} className="atv-tv__log-line">
                    <span className="atv-tv__log-bullet">›</span>{line}
                  </div>
                ))}
              </>
            )}
          </div>

        </div>
      )}
    </div>
  );
}

// ─── LiveOrderPanel ──────────────────────────────────────────────────────────

type BrokerConn = { broker: string; mode: 'paper' | 'live' };
type AccountInfo = {
  broker: string; mode: string;
  equity: number; cash: number; buying_power: number;
  currency: string; balances?: Array<{ asset: string; free: number }>;
};

function LiveOrderPanel({ user, tickers }: { user: User | null; tickers: Ticker[] }) {
  const [connections, setConnections] = useState<BrokerConn[]>([]);
  const [selectedBroker, setSelectedBroker] = useState('');
  const [account, setAccount] = useState<AccountInfo | null>(null);
  const [acctLoading, setAcctLoading] = useState(false);
  const [symbol, setSymbol] = useState('BTC/USD');
  const [qty, setQty] = useState('0.001');
  const [side, setSide] = useState<'BUY' | 'SELL'>('BUY');
  const [executing, setExecuting] = useState(false);
  const [result, setResult] = useState<string>('');
  const [resultOk, setResultOk] = useState(true);

  // Load connected brokers on mount
  useEffect(() => {
    if (!user) return;
    supabase.from('broker_secrets')
      .select('broker, mode')
      .eq('user_id', user.id)
      .then(({ data }) => {
        if (data && data.length > 0) {
          setConnections(data as BrokerConn[]);
          setSelectedBroker(data[0].broker);
        }
      });
  }, [user]);

  // Fetch account info when broker selection changes
  useEffect(() => {
    if (!selectedBroker || !user) return;
    setAccount(null);
    setAcctLoading(true);
    supabase.functions.invoke('broker-account', { body: { broker: selectedBroker } })
      .then(({ data, error }) => {
        setAcctLoading(false);
        if (error || !data) return;
        setAccount(data as AccountInfo);
      });
  }, [selectedBroker, user]);

  const execute = useCallback(async () => {
    if (!user || !selectedBroker || !symbol || !qty) return;
    setExecuting(true);
    setResult('');
    try {
      const { data, error } = await supabase.functions.invoke('broker-execute', {
        body: { broker: selectedBroker, symbol, side, qty: parseFloat(qty) },
      });
      if (error || data?.error) {
        setResultOk(false);
        setResult(data?.error ?? error?.message ?? 'Uitvoering mislukt');
      } else {
        setResultOk(true);
        const conn = connections.find(c => c.broker === selectedBroker);
        setResult(`${side} ${qty} ${symbol} uitgevoerd${conn?.mode === 'paper' ? ' (paper)' : ' ✓ LIVE'}!`);
        // Refresh account after trade
        supabase.functions.invoke('broker-account', { body: { broker: selectedBroker } })
          .then(({ data: d }) => { if (d) setAccount(d as AccountInfo); });
      }
    } catch (e) {
      setResultOk(false);
      setResult(e instanceof Error ? e.message : 'Error');
    }
    setExecuting(false);
  }, [user, selectedBroker, symbol, side, qty, connections]);

  // Symbol suggestions based on broker
  const symbols = selectedBroker === 'alpaca'
    ? ['AAPL', 'NVDA', 'TSLA', 'MSFT', 'SPY', 'QQQ', 'AMZN', 'GOOGL']
    : ['BTC/USD', 'ETH/USD', 'SOL/USD', 'BNB/USD', 'DOGE/USD', 'XRP/USD'];

  // Live price for selected symbol
  const liveP = tickers.find(t => t.key === symbol);

  if (!user || connections.length === 0) return null;

  const conn = connections.find(c => c.broker === selectedBroker);
  const isLive = conn?.mode === 'live';

  return (
    <div className="atv4-panel atv4-live-order-panel">
      <div className="atv4-panel-hdr">
        <Zap size={12} className="atv4-icon-green"/>
        <span>Live Trading Platform</span>
        {isLive
          ? <span className="atv4-chip atv4-chip--red atv4-chip--pulse">LIVE MONEY</span>
          : <span className="atv4-chip atv4-chip--amber">PAPER MODE</span>
        }
      </div>

      {/* No Supabase auth — guide user to sign in via SecureChat / Accounting */}
      {!user && (
        <div style={{ padding: '12px', color: '#64748b', fontSize: '0.78rem', lineHeight: 1.5 }}>
          <div style={{ color: '#f59e0b', fontWeight: 600, marginBottom: 6, display: 'flex', alignItems: 'center', gap: 6 }}>
            <Key size={12}/> Connect Your Broker
          </div>
          To connect your Alpaca or Binance account and place live orders, sign in with your Aippie account (SecureChat / Accounting login), then return here to add your API keys in the Broker Connections panel above.
        </div>
      )}
      {/* Broker selector, account info, order form — only for authenticated users */}
      {user && (<>
      <div className="atv4-lop-row">
        {connections.map(c => (
          <button
            key={c.broker}
            className={`atv4-lop-broker-btn${selectedBroker === c.broker ? ' atv4-lop-broker-btn--active' : ''}`}
            onClick={() => setSelectedBroker(c.broker)}
          >
            {c.broker === 'alpaca' ? '📈 Alpaca' : c.broker === 'binance' ? '🔶 Binance' : c.broker}
            <span className={`atv4-mode-dot${c.mode === 'live' ? ' atv4-mode-dot--live' : ''}`}/>
          </button>
        ))}
      </div>

      {/* Account balance */}
      <div className="atv4-lop-account">
        {acctLoading
          ? <span className="atv4-spinner" style={{ width: 14, height: 14 }}/>
          : account
            ? <>
                <div className="atv4-lop-bal">
                  <span className="atv4-lop-bal__label">Available</span>
                  <span className="atv4-lop-bal__val">
                    {account.currency} {account.buying_power.toLocaleString('nl-NL', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </span>
                </div>
                {account.equity > 0 && (
                  <div className="atv4-lop-bal">
                    <span className="atv4-lop-bal__label">Portfolio Value</span>
                    <span className="atv4-lop-bal__val">
                      {account.currency} {account.equity.toLocaleString('nl-NL', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                    </span>
                  </div>
                )}
                {account.balances && account.balances.length > 0 && (
                  <div className="atv4-lop-balances">
                    {account.balances.slice(0, 6).map(b => (
                      <span key={b.asset} className="atv4-lop-asset-chip">
                        {b.asset} <strong>{b.free.toFixed(4)}</strong>
                      </span>
                    ))}
                  </div>
                )}
              </>
            : <span style={{ color: '#475569', fontSize: '0.75rem' }}>Account info unavailable</span>
        }
      </div>

      {/* Order entry */}
      <div className="atv4-lop-form">
        {/* Symbol */}
        <div className="atv4-lop-field">
          <label>Symbol</label>
          <input
            className="atv4-inp"
            value={symbol}
            onChange={e => setSymbol(e.target.value.toUpperCase())}
            list="atv4-sym-list"
            placeholder="e.g. AAPL or BTC/USD"
          />
          <datalist id="atv4-sym-list">
            {symbols.map(s => <option key={s} value={s}/>)}
          </datalist>
          {liveP && (
            <span className={`atv4-lop-live-price${liveP.dir === 'up' ? ' atv4-pos' : liveP.dir === 'down' ? ' atv4-neg' : ''}`}>
              ${liveP.price.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              {' '}{liveP.changePct >= 0 ? '▲' : '▼'}{Math.abs(liveP.changePct).toFixed(2)}%
            </span>
          )}
        </div>

        {/* Qty */}
        <div className="atv4-lop-field">
          <label>Quantity</label>
          <input
            className="atv4-inp"
            type="number"
            step="0.0001"
            min="0.0001"
            value={qty}
            onChange={e => setQty(e.target.value)}
          />
        </div>

        {/* Side */}
        <div className="atv4-lop-side-toggle">
          <button
            className={`atv4-lop-side-btn${side === 'BUY' ? ' atv4-lop-side-btn--buy' : ''}`}
            onClick={() => setSide('BUY')}
          >▲ BUY</button>
          <button
            className={`atv4-lop-side-btn${side === 'SELL' ? ' atv4-lop-side-btn--sell' : ''}`}
            onClick={() => setSide('SELL')}
          >▼ SELL</button>
        </div>

        {/* Execute */}
        {isLive && (
          <div className="atv4-lop-live-warn">
            <AlertTriangle size={10}/> LIVE mode — real transaction on your account
          </div>
        )}

        <button
          className={`atv4-lop-execute-btn${side === 'SELL' ? ' atv4-lop-execute-btn--sell' : ''}`}
          onClick={execute}
          disabled={executing || !qty || !symbol}
        >
          {executing
            ? <><span className="atv4-spinner"/>Executing…</>
            : <>{side === 'BUY' ? <TrendingUp size={12}/> : <TrendingDown size={12}/>}
               {side === 'BUY' ? 'Buy' : 'Sell'} {qty} {symbol}
               {conn?.mode === 'live' ? ' (LIVE)' : ' (Paper)'}
              </>
          }
        </button>

        {result && (
          <div className={`atv4-lop-result${resultOk ? ' atv4-lop-result--ok' : ' atv4-lop-result--err'}`}>
            {resultOk ? <CheckCircle size={11}/> : <AlertTriangle size={11}/>} {result}
          </div>
        )}
      </div>
      </>)} {/* end user && */}
    </div>
  );
}

// ─── Main Component ───────────────────────────────────────────────────────────

export default function AippieTradingView({ user }: { user: User | null }) {
  const { user: authUser } = useAuth();
  const DEV_EMAILS = ['elvin@aippietax.com', 'aippieai@gmail.com'];
  const isSubscribed =
    DEV_EMAILS.includes(authUser?.email ?? '') ||
    authUser?.user_metadata?.is_subscribed === true ||
    authUser?.user_metadata?.subscription_type === 'lifetime' ||
    authUser?.user_metadata?.subscription_type === 'annual';
  const sessionKey = useRef(localStorage.getItem('aippie_device_key') ?? crypto.randomUUID());

  // ── Disclaimer consent gate ───────────────────────────────────────────────
  const [consented, setConsented] = useState(() => hasLocalConsent());

  // ── Autopilot wizard state ────────────────────────────────────────────────
  const [autopilotActive, setAutopilotActive] = useState(false);
  const [autopilotStep,   setAutopilotStep]   = useState<'idle' | 'setup' | 'running'>('idle');
  const [capitalInput,    setCapitalInput]     = useState('10000');
  const [profitTarget,    setProfitTarget]     = useState('20');
  const [maxLoss,         setMaxLoss]          = useState('10');
  const [withdrawable,    setWithdrawable]     = useState(0);
  const [withdrawn,       setWithdrawn]        = useState(0);

  // ── Live broker state ─────────────────────────────────────────────────────
  const [liveBrokers, setLiveBrokers] = useState<LiveBrokerMap>({});

  // ── Price state ───────────────────────────────────────────────────────────
  const [tickers, setTickers] = useState<Ticker[]>(() => [
    ...CG_ASSETS.map(a => ({ key: a.key, cgId: a.cgId, type: 'crypto' as const, price: 0, prev: 0, changePct: 0, dir: 'flat' as const })),
    ...STOCK_ASSETS.map(a => ({ key: a.key, yahooSym: a.yahooSym, type: 'stock' as const, price: 0, prev: 0, changePct: 0, dir: 'flat' as const })),
  ]);
  const [priceReady, setPriceReady] = useState(false);
  const [lastFetch,  setLastFetch]  = useState<string>('—');
  const [fetchErr,   setFetchErr]   = useState(false);
  const priceHistories = useRef<Record<string, number[]>>({});
  const tickersRef = useRef(tickers);
  tickersRef.current = tickers;

  // ── Chart state ───────────────────────────────────────────────────────────
  const [chartAsset, setChartAsset] = useState<string>('BTC/USD');
  const [candles,    setCandles]    = useState<Candle[]>([]);
  const [liveCandle, setLiveCandle] = useState<Candle>({ o: 1, h: 1, l: 1, c: 1, v: 100, bull: true });
  const tickCount = useRef(0);

  // ── AI state ──────────────────────────────────────────────────────────────
  const [engineOn,     setEngineOn]     = useState(true);
  const [positions,    setPositions]    = useState<AIPosition[]>([]);
  const [closedTrades, setClosedTrades] = useState<AIPosition[]>([]);
  const [signals,      setSignals]      = useState<AISignal[]>([]);
  const [aiLog,        setAiLog]        = useState<string[]>([]);
  const [portfolio,    setPortfolio]    = useState(10_000);
  const positionsRef = useRef(positions);
  positionsRef.current = positions;
  const [screenFlash, setScreenFlash]  = useState<'buy' | 'sell' | null>(null);
  const flashTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const triggerFlash = useCallback((type: 'buy' | 'sell') => {
    if (flashTimerRef.current) clearTimeout(flashTimerRef.current);
    setScreenFlash(type);
    flashTimerRef.current = setTimeout(() => setScreenFlash(null), 5000);
  }, []);

  // ── Autopilot: auto-stop when profit target or max loss is hit ────────────
  // ── Voice state ───────────────────────────────────────────────────────────
  const [speaking, setSpeaking] = useState(false);
  const [caption,  setCaption]  = useState('Welkom bij het Aippie Live Trading Platform. Bekijk de stap-voor-stap gids hieronder om te beginnen.');
  const cancelRef  = useRef(false);
  const speakRef   = useRef(false);
  const lastSpkRef = useRef(0);

  // ── News & dark pool state ────────────────────────────────────────────────
  const [newsFeed,     setNewsFeed]     = useState<NewsTick[]>([]);
  const [darkPool,     setDarkPool]     = useState<DarkPoolTick[]>([]);
  const [portfolioHist, setPortfolioHist] = useState<number[]>([10_000]);
  const newsIdxRef  = useRef(0);
  const newsPoolRef = useRef(shuffleNewsPool()); // shuffled once per session
  // Chart bias: +1 = bullish trend, -1 = bearish, 0 = neutral
  const chartBiasRef = useRef(0);

  // ── Index quotes (NDX, SPX, VIX) — seeded with realistic values, live-updated when API responds ──
  const SEED_INDICES: Record<string, { price: number; changePct: number }> = {
    'NASDAQ-100': { price: 19_847, changePct: +0.62 },
    'S&P 500':    { price:  5_431, changePct: +0.38 },
    'VIX':        { price:    14.8, changePct: -1.20 },
  };
  const [indices, setIndices] = useState<IndexQuote[]>(
    INDEX_ASSETS.map(a => {
      const seed = SEED_INDICES[a.key];
      const history = Array.from({ length: 20 }, (_, i) => seed.price * (1 + (Math.random() - 0.5) * 0.003 * i * 0.1));
      return { key: a.key, label: a.label, price: seed.price, changePct: seed.changePct, history };
    })
  );
  const indicesRef = useRef(indices);
  indicesRef.current = indices;

  // ── AI trade decisions ────────────────────────────────────────────────────
  const [tradeDecisions, setTradeDecisions] = useState<TradeDecision[]>([]);

  // ── User display name ─────────────────────────────────────────────────────
  const userName = user?.user_metadata?.full_name
    || user?.email?.split('@')[0]
    || null;

  // ── TTS ───────────────────────────────────────────────────────────────────
  const speak = useCallback((text: string) => {
    if (!('speechSynthesis' in window) || speakRef.current || cancelRef.current) return;
    const words = text.split(' ');
    let wi = 0;
    const t = setInterval(() => { wi++; setCaption(words.slice(0, wi).join(' ')); if (wi >= words.length) clearInterval(t); }, 360);
    const u = new SpeechSynthesisUtterance(text);
    u.rate = 0.82; u.pitch = 1.02; u.lang = 'en-US';
    applyPremiumVoice(u);
    u.onstart = () => { speakRef.current = true;  setSpeaking(true); };
    u.onend   = () => { speakRef.current = false; setSpeaking(false); clearInterval(t); };
    u.onerror = () => { speakRef.current = false; setSpeaking(false); clearInterval(t); };
    window.speechSynthesis.speak(u);
  }, []);

  const logAI = useCallback((msg: string) => {
    const ts = new Date().toLocaleTimeString('en-US', { hour12: false });
    setAiLog(p => [`[${ts}] ${msg}`, ...p].slice(0, 60));
  }, []);

  // ── Welcome speech for new traders ───────────────────────────────────────
  useEffect(() => {
    if (!consented) return;
    const t = setTimeout(() => {
      speak('Welcome to the Aippie Live Trading Platform. Step one: view the live candlestick charts below. Step two: sign in and connect your broker API key in the Broker Connections panel. Step three: the AI engine automatically opens and closes trades with stop-loss and take-profit. You are now in paper mode — no real money until you switch to live.');
    }, 1800);
    return () => clearTimeout(t);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [consented]);

  // ── Autopilot: auto-stop when profit target or max loss is hit ────────────
  useEffect(() => {
    if (!autopilotActive) return;
    const startCapital = parseFloat(capitalInput) || 10000;
    const targetPct    = parseFloat(profitTarget) || 20;
    const lossLimitPct = parseFloat(maxLoss)      || 10;
    const gainPct      = ((portfolio - startCapital) / startCapital) * 100;
    if (gainPct >= targetPct) {
      setEngineOn(false);
      setAutopilotActive(false);
      setAutopilotStep('idle');
      setWithdrawable(w => w + Math.max(0, portfolio - startCapital));
      logAI(`AUTOPILOT: Profit target +${targetPct}% reached. Engine stopped. Withdraw your profits.`);
    }
    if (gainPct <= -lossLimitPct) {
      setEngineOn(false);
      setAutopilotActive(false);
      setAutopilotStep('idle');
      logAI(`AUTOPILOT: Max loss -${lossLimitPct}% reached. Engine stopped to protect your capital.`);
    }
  }, [portfolio, autopilotActive, capitalInput, profitTarget, maxLoss, logAI]);

  // ── CoinGecko price fetch ─────────────────────────────────────────────────
  const fetchPrices = useCallback(async () => {
    const data = await fetchLivePrices();
    if (!data) { setFetchErr(true); return; }
    setFetchErr(false);
    setLastFetch(new Date().toLocaleTimeString('en-US', { hour12: false }));
    setPriceReady(true);

    setTickers(prev => prev.map(t => {
      if (t.type !== 'crypto' || !t.cgId) return t;
      const cg = data[t.cgId];
      if (!cg) return t;
      const newPrice = cg.usd;
      const hist = priceHistories.current[t.key] ?? [];
      hist.push(newPrice);
      if (hist.length > 60) hist.shift();
      priceHistories.current[t.key] = hist;
      return {
        ...t,
        prev: t.price || newPrice,
        price: newPrice,
        changePct: cg.usd_24h_change ?? t.changePct,
        dir: newPrice > (t.price || newPrice) ? 'up' : newPrice < (t.price || newPrice) ? 'down' : 'flat',
      };
    }));

    // update chart candle with real price (crypto)
    const cgId = CG_ASSETS.find(a => a.key === chartAsset)?.cgId;
    if (cgId) {
      const price = data[cgId]?.usd ?? 0;
      if (price > 0) updateChartCandle(price);
    }
  }, [chartAsset]); // eslint-disable-line react-hooks/exhaustive-deps

  // ── Yahoo Finance stock fetch ─────────────────────────────────────────────
  const fetchStocks = useCallback(async () => {
    const data = await fetchStockPrices();
    if (!data) return;
    setLastFetch(new Date().toLocaleTimeString('en-US', { hour12: false }));
    setPriceReady(true);

    setTickers(prev => prev.map(t => {
      if (t.type !== 'stock' || !t.yahooSym) return t;
      const q = data[t.yahooSym];
      if (!q || q.price === 0) return t;
      const newPrice = q.price;
      const hist = priceHistories.current[t.key] ?? [];
      hist.push(newPrice);
      if (hist.length > 60) hist.shift();
      priceHistories.current[t.key] = hist;
      return {
        ...t,
        prev: t.price || newPrice,
        price: newPrice,
        changePct: q.change ?? t.changePct,
        dir: newPrice > (t.price || newPrice) ? 'up' : newPrice < (t.price || newPrice) ? 'down' : 'flat',
      };
    }));

    // update chart candle for stock assets
    const stockAsset = STOCK_ASSETS.find(a => a.key === chartAsset);
    if (stockAsset) {
      const price = data[stockAsset.yahooSym]?.price ?? 0;
      if (price > 0) updateChartCandle(price);
    }

    // Update index quotes (NDX, SPX, VIX) — use real data if available, else drift
    setIndices(prev => prev.map((idx, i) => {
      const sym = INDEX_ASSETS[i]?.yahooSym;
      if (!sym) return idx;
      const q = data[sym];
      if (q && q.price > 0) {
        const newHist = [...idx.history, q.price].slice(-60);
        return { ...idx, price: q.price, changePct: q.change, history: newHist };
      }
      // Drift simulation when API data unavailable
      const drift = idx.label === 'VIX'
        ? idx.price * (1 + (Math.random() - 0.51) * 0.004)
        : idx.price * (1 + (Math.random() - 0.48) * 0.001);
      const driftChg = idx.changePct + (Math.random() - 0.5) * 0.05;
      return { ...idx, price: drift, changePct: driftChg, history: [...idx.history, drift].slice(-60) };
    }));
  }, [chartAsset]); // eslint-disable-line react-hooks/exhaustive-deps

  const updateChartCandle = useCallback((price: number) => {
    tickCount.current++;
    const volatility = price > 10000 ? 0.008 : price > 100 ? 0.012 : 0.018;
    const spread = price * volatility;
    // Chart bias shifts probability: +1 = 70% bull, -1 = 30% bull, 0 = 50%
    const bias   = chartBiasRef.current;
    const bullProb = 0.50 + bias * 0.20;
    const isBull = Math.random() < bullProb;
    const bodySize = price * (0.002 + Math.random() * 0.006);
    // Bias also shifts close direction
    const dirMult  = isBull ? 1 : -1;
    const open  = price - dirMult * bodySize * 0.4;
    const close = price + dirMult * bodySize * 0.6;
    const high  = Math.max(open, close) + spread * (0.3 + Math.random() * 0.7);
    const low   = Math.min(open, close) - spread * (0.3 + Math.random() * 0.7);
    const live: Candle = { o: open, h: high, l: low, c: close, v: rnd(500, 8000), bull: isBull };
    setLiveCandle(live);

    // Add a new closed candle every 3 ticks, keep last 80
    if (tickCount.current % 3 === 0) {
      setCandles(p => [...p, live].slice(-80));
    } else if (tickCount.current === 1) {
      // On first price: seed 60 historical candles immediately
      const seed: Candle[] = [];
      let p0 = price * (1 - 0.04 * Math.random());
      for (let i = 0; i < 60; i++) {
        const drift = (Math.random() - 0.48) * volatility * p0;
        const bull = drift >= 0;
        const o2 = p0;
        const c2 = p0 + drift;
        const rng = Math.abs(c2 - o2) * (1 + Math.random() * 1.5);
        const h2 = Math.max(o2, c2) + rng * Math.random();
        const l2 = Math.min(o2, c2) - rng * Math.random();
        seed.push({ o: o2, h: h2, l: l2, c: c2, v: rnd(500, 8000), bull });
        p0 = c2;
      }
      setCandles(seed);
    }
  }, []);

  // ── AI auto-open ──────────────────────────────────────────────────────────
  const openPosition = useCallback(async (signal: AISignal, price: number) => {
    const side = signal.action === 'BUY' ? 'LONG' : 'SHORT';
    // Bias the chart in the direction of the AI's trade
    chartBiasRef.current = side === 'LONG' ? 1 : -1;
    // Flash the screen
    triggerFlash(side === 'LONG' ? 'buy' : 'sell');
    const sl = side === 'LONG' ? price * (1 - STOP_LOSS_PCT) : price * (1 + STOP_LOSS_PCT);
    const tp = side === 'LONG' ? price * (1 + TAKE_PROFIT_PCT) : price * (1 - TAKE_PROFIT_PCT);

    // Determine broker and qty for this asset
    const isCrypto = CG_ASSETS.some(a => a.key === signal.asset);
    const broker   = isCrypto ? 'binance' : 'alpaca';
    const brokerMode = liveBrokers[broker];
    const isLive   = brokerMode === 'live';
    // Target $100 per trade → qty = 100 / price
    const qty = price > 0 ? 100 / price : 0.001;

    const pos: AIPosition = {
      id: crypto.randomUUID(),
      asset: signal.asset, side, qty,
      entryPrice: price, stopLoss: sl, takeProfit: tp,
      strategy: signal.strategy, status: 'OPEN',
      openedAt: new Date().toISOString(),
    };
    setPositions(p => [...p, pos]);

    const modeTag = isLive ? '🔴 LIVE' : '📄 PAPER';
    logAI(`${modeTag} OPEN ${side} ${signal.asset} @ $${fmtPrice(price)} | SL $${fmtPrice(sl)} | TP $${fmtPrice(tp)} [${signal.strategy}]`);
    speak(`${isLive ? 'Live' : 'Paper'} ${side === 'LONG' ? 'buy' : 'sell'} on ${signal.asset.replace('/USD', '')} at ${fmtPrice(price)}. ${signal.reason}.`);

    // Always track in paper positions table
    await supabase.from('ai_paper_positions').insert({
      session_key: sessionKey.current,
      asset: pos.asset, side: pos.side,
      entry_price: pos.entryPrice, qty: pos.qty,
      stop_loss: pos.stopLoss, take_profit: pos.takeProfit,
      strategy: pos.strategy,
    });

    // If LIVE mode + broker connected → execute real order
    if (isLive && user) {
      try {
        const { data: sessionData } = await supabase.auth.getSession();
        const token = sessionData.session?.access_token;
        if (token) {
          const orderSide = side === 'LONG' ? 'BUY' : 'SELL';
          const res = await fetch(
            `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/broker-execute`,
            {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`,
                'apikey': import.meta.env.VITE_SUPABASE_ANON_KEY as string,
              },
              body: JSON.stringify({ broker, symbol: signal.asset, side: orderSide, qty }),
            }
          );
          const result = await res.json() as { ok?: boolean; error?: string };
          if (result.ok) {
            logAI(`✅ LIVE ORDER CONFIRMED — ${broker.toUpperCase()} ${signal.asset} ${orderSide} ${qty.toFixed(4)}`);
          } else {
            logAI(`⚠️ LIVE ORDER FAILED: ${result.error ?? 'unknown error'} — falling back to paper`);
          }
        }
      } catch (e) {
        logAI(`⚠️ Broker execute error: ${e instanceof Error ? e.message : String(e)}`);
      }
    }
  }, [logAI, speak, liveBrokers, user]);

  // ── AI auto-close ─────────────────────────────────────────────────────────
  const closePosition = useCallback(async (
    pos: AIPosition, closePrice: number,
    reason: 'CLOSED_TP' | 'CLOSED_SL' | 'CLOSED_AI',
  ) => {
    const pnlPct = pos.side === 'LONG'
      ? (closePrice - pos.entryPrice) / pos.entryPrice * 100
      : (pos.entryPrice - closePrice) / pos.entryPrice * 100;
    const closed: AIPosition = { ...pos, status: reason, closePrice, pnlPct, closedAt: new Date().toISOString() };
    setPositions(p => p.filter(x => x.id !== pos.id));
    setClosedTrades(p => [closed, ...p].slice(0, 30));
    setPortfolio(pf => {
      const newPf = pf * (1 + pnlPct / 100);
      if (pnlPct > 0) setWithdrawable(w => w + (newPf - pf));
      return newPf;
    });
    const tag = reason === 'CLOSED_TP' ? 'TAKE-PROFIT' : reason === 'CLOSED_SL' ? 'STOP-LOSS' : 'AI-EXIT';
    logAI(`${tag} ${pos.asset} @ $${fmtPrice(closePrice)} | P&L ${pnlPct >= 0 ? '+' : ''}${pnlPct.toFixed(2)}%`);
    speak(`${reason === 'CLOSED_TP' ? 'Take profit hit' : 'Stop loss triggered'} on ${pos.asset.replace('/USD','')}. ${pnlPct >= 0 ? 'Plus' : 'Minus'} ${Math.abs(pnlPct).toFixed(2)} percent.`);
    await supabase.from('ai_paper_positions').update({
      status: reason, close_price: closePrice,
      pnl_pct: pnlPct, closed_at: closed.closedAt,
    }).eq('session_key', sessionKey.current).eq('asset', pos.asset).eq('status', 'OPEN');
  }, [logAI, speak]);

  // ── AI strategy loop ──────────────────────────────────────────────────────
  useEffect(() => {
    if (!engineOn || !priceReady) return;
    const iv = setInterval(() => {
      const current  = tickersRef.current;
      const openPos  = positionsRef.current;

      // check TP / SL on open positions
      openPos.forEach(pos => {
        const ticker = current.find(t => t.key === pos.asset);
        if (!ticker || ticker.price === 0) return;
        const price = ticker.price;
        if (pos.side === 'LONG') {
          if (price >= pos.takeProfit) { closePosition(pos, price, 'CLOSED_TP'); return; }
          if (price <= pos.stopLoss)   { closePosition(pos, price, 'CLOSED_SL'); return; }
        } else {
          if (price <= pos.takeProfit) { closePosition(pos, price, 'CLOSED_TP'); return; }
          if (price >= pos.stopLoss)   { closePosition(pos, price, 'CLOSED_SL'); return; }
        }
      });

      // generate signals and open new positions (crypto + stocks)
      const newSignals: AISignal[] = [];
      const allAssetKeys = [
        ...CG_ASSETS.map(a => a.key),
        ...STOCK_ASSETS.map(a => a.key),
      ];
      allAssetKeys.forEach(key => {
        const ticker = current.find(t => t.key === key);
        const hist   = priceHistories.current[key] ?? [];
        if (!ticker || hist.length < 8 || ticker.price === 0) return;
        const strategy = STRATEGIES[Math.floor(Math.random() * STRATEGIES.length)];
        const signal = runStrategy(strategy, key, hist, ticker.price, ticker.changePct);
        newSignals.push(signal);
        const alreadyOpen = openPos.some(p => p.asset === key && p.status === 'OPEN');
        const canOpen = !alreadyOpen && openPos.filter(p => p.status === 'OPEN').length < MAX_OPEN_POS;
        if (canOpen && signal.action !== 'HOLD' && signal.confidence >= 0.68) {
          openPosition(signal, ticker.price);
        }
      });
      setSignals(newSignals);
    }, STRATEGY_MS);
    return () => clearInterval(iv);
  }, [engineOn, priceReady, openPosition, closePosition]);

  // ── Mount ─────────────────────────────────────────────────────────────────
  useEffect(() => {
    cancelRef.current = false;
    window.speechSynthesis?.cancel();
    setSpeaking(true);
    withVoicesReady(() => {
      if (!cancelRef.current) setTimeout(() => {
        if (!cancelRef.current) {
          lastSpkRef.current = Date.now();
          speak(`${userName ? `Welcome back, ${userName}! ` : ''}Alpha AI engine online. Connecting to CoinGecko and NASDAQ live feeds. News sentiment radar and dark pool scanner activated. I will continuously analyze the markets and keep you informed. Autonomous trading engine ready.`);
        }
      }, 600);
    });
    fetchPrices();
    fetchStocks();
    return () => { cancelRef.current = true; window.speechSynthesis?.cancel(); };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    const iv = setInterval(fetchPrices, PRICE_POLL_MS);
    return () => clearInterval(iv);
  }, [fetchPrices]);

  useEffect(() => {
    const iv = setInterval(fetchStocks, STOCK_POLL_MS);
    return () => clearInterval(iv);
  }, [fetchStocks]);

  // ── Portfolio history tracking ────────────────────────────────────────────
  useEffect(() => {
    setPortfolioHist(prev => {
      const next = [...prev, portfolio];
      return next.slice(-60); // keep last 60 ticks
    });
  }, [portfolio]);

  // ── Live news feed (rotates every 14s, no repeats — reshuffles when exhausted) ────────────────────────────────────
  useEffect(() => {
    const tick = () => {
      const pool = newsPoolRef.current;
      const idx  = newsIdxRef.current % pool.length;
      newsIdxRef.current++;
      // Reshuffle at wrap-around for infinite variety
      if (newsIdxRef.current >= pool.length) {
        newsPoolRef.current = shuffleNewsPool();
        newsIdxRef.current  = 0;
      }
      const item: NewsTick = {
        ...pool[idx],
        id: crypto.randomUUID(),
        ts: new Date().toLocaleTimeString('en-US', { hour12: false }),
      };
      setNewsFeed(prev => [item, ...prev].slice(0, 16));

      // Bias the chart direction based on the news sentiment score
      chartBiasRef.current = item.score > 0.5 ? 1 : item.score < -0.5 ? -1 : 0;

      // Store to Supabase
      supabase.from('news_sentiment_ticks').insert({
        symbol: item.asset ?? 'MARKET',
        headline: item.headline,
        sentiment_score: item.score,
        source: item.source,
      }).then(() => {}).catch(() => {});
    };
    tick();
    const iv = setInterval(tick, 14_000);
    return () => clearInterval(iv);
  }, []);

  // ── Dark pool radar (refreshes every 25s after prices load) ──────────────
  useEffect(() => {
    if (!priceReady) return;
    const refresh = () => setDarkPool(genDarkPoolTicks(tickersRef.current));
    refresh();
    const iv = setInterval(refresh, 25_000);
    return () => clearInterval(iv);
  }, [priceReady]);

  // ── AI decisive IN / OUT trade decision engine ────────────────────────────
  useEffect(() => {
    if (!priceReady) return;
    const evaluate = () => {
      const tks = tickersRef.current.filter(t => t.price > 0);
      if (tks.length === 0) return;

      // Pick highest-momentum asset
      const sorted = [...tks].sort((a, b) => Math.abs(b.changePct) - Math.abs(a.changePct));
      const top = sorted[0];

      // Multi-factor scoring
      const newsScore = newsFeed.filter(n => n.asset === top.key && n.sentiment === 'bullish').length
                      - newsFeed.filter(n => n.asset === top.key && n.sentiment === 'bearish').length;
      const dpEntry   = darkPool.find(d => d.asset === top.key);
      const dpBullish = dpEntry?.side === 'BUY' && (dpEntry?.unusualScore ?? 0) > 50;
      const dpBearish = dpEntry?.side === 'SELL' && (dpEntry?.unusualScore ?? 0) > 50;

      // NDX direction as macro filter
      const ndx = indicesRef.current.find(i => i.label === 'NDX');
      const ndxBullish = (ndx?.changePct ?? 0) > 0.3;
      const ndxBearish = (ndx?.changePct ?? 0) < -0.5;
      const vix = indicesRef.current.find(i => i.label === 'VIX');
      const highVix = (vix?.price ?? 0) > 22;

      let score = 0;
      const reasoning: string[] = [];

      if (top.changePct > 1.5) { score += 2; reasoning.push(`${top.key} momentum +${top.changePct.toFixed(2)}% — strong uptrend`); }
      else if (top.changePct < -1.5) { score -= 2; reasoning.push(`${top.key} down ${top.changePct.toFixed(2)}% — bearish pressure`); }
      if (newsScore > 0)  { score += newsScore; reasoning.push(`${newsScore} bullish news signals for ${top.key}`); }
      if (newsScore < 0)  { score += newsScore; reasoning.push(`${Math.abs(newsScore)} bearish news signals for ${top.key}`); }
      if (dpBullish) { score += 2; reasoning.push(`Dark pool: unusual BUY flow ${dpEntry!.volume.toFixed(0)}M — smart money accumulating`); }
      if (dpBearish) { score -= 2; reasoning.push(`Dark pool: unusual SELL flow ${dpEntry!.volume.toFixed(0)}M — institutional exits detected`); }
      if (ndxBullish) { score += 1; reasoning.push(`NASDAQ-100 up ${ndx!.changePct.toFixed(2)}% — macro tailwind`); }
      if (ndxBearish) { score -= 1; reasoning.push(`NASDAQ-100 down ${ndx!.changePct.toFixed(2)}% — macro headwind`); }
      if (highVix)    { score -= 1; reasoning.push(`VIX at ${vix!.price.toFixed(1)} — elevated fear, risk-off environment`); }

      const hasOpenPos = positionsRef.current.some(p => p.asset === top.key && p.status === 'OPEN');
      const action: TradeDecision['action'] = score >= 3 ? 'IN' : score <= -2 ? 'OUT' : 'HOLD';
      const confidence = Math.min(99, Math.round(30 + Math.abs(score) * 12));

      // Only record + speak decisive IN/OUT calls
      if (action !== 'HOLD') {
        // Flash screen on decisive signal
        triggerFlash(action === 'IN' ? 'buy' : 'sell');
        const decision: TradeDecision = {
          action, asset: top.key, confidence, reasoning,
          ts: new Date().toLocaleTimeString('en-US', { hour12: false }),
        };
        setTradeDecisions(prev => [decision, ...prev].slice(0, 8));

        if (Date.now() - lastSpkRef.current > 30_000 && !speakRef.current) {
          lastSpkRef.current = Date.now();
          const namePrefix = userName ? `${userName}! ` : '';
          const ndxLine = ndx?.price ? ` NASDAQ-100 is at ${ndx.price.toLocaleString('en-US', { maximumFractionDigits: 0 })} points, ${ndx.changePct >= 0 ? 'up' : 'down'} ${Math.abs(ndx.changePct).toFixed(2)} percent today.` : '';
          if (action === 'IN') {
            speak(`${namePrefix}I think we should GO IN on ${top.key.replace('/USD', '')} RIGHT NOW. Confidence ${confidence} percent.${ndxLine} ${reasoning[0]}. ${reasoning[1] ?? ''} I see this going up — let's capture this move!`);
          } else {
            speak(`${namePrefix}I think we should PULL OUR MONEY OUT of ${top.key.replace('/USD', '')}. Confidence ${confidence} percent.${ndxLine} ${reasoning[0]}. ${reasoning[1] ?? ''} Protecting your capital is my priority right now.`);
          }
        }

        // Log decision
        if (hasOpenPos && action === 'OUT') {
          logAI(`[DECISION] EXIT ${top.key} — score ${score}, confidence ${confidence}%`);
        } else if (!hasOpenPos && action === 'IN') {
          logAI(`[DECISION] ENTER ${top.key} — score ${score}, confidence ${confidence}%`);
        }
      }
    };

    evaluate(); // immediate
    const iv = setInterval(evaluate, 45_000);
    return () => clearInterval(iv);
  }, [priceReady, newsFeed, darkPool, speak, logAI]);

  // ── Periodic Aippie advisory — news + dark pool + market ─────────────────
  useEffect(() => {
    const name = userName ? `${userName}, ` : '';

    // Track last spoken text to avoid exact repeats
    const recentlySpoken = new Set<string>();

    const ADVISORY_SCRIPTS: Array<() => string | null> = [
      // ── News headline (rotates through ALL feed, not just [0]) ─────────────
      (() => {
        let newsRotate = 0;
        return () => {
          const pool = newsFeed.length > 0 ? newsFeed : [];
          if (pool.length === 0) return null;
          const item = pool[newsRotate % pool.length];
          newsRotate++;
          const tone = item.sentiment === 'bullish'
            ? ['This is a positive development. I am upgrading my buy confidence.',
               'Good news for the bulls. I see momentum building.',
               'Interesting signal here — bullish macro backdrop forming.'][Math.floor(Math.random()*3)]
            : item.sentiment === 'bearish'
            ? ['This concerns me. I am tightening stop-losses immediately.',
               'Watch out — bearish news can trigger stop hunts. Be careful.',
               'Caution mode activated. Do not chase this move down.'][Math.floor(Math.random()*3)]
            : ['Mixed signals here. I wait for confirmation.',
               'Neutral headline but context matters. Watching closely.',
               'The market is processing this. Patience.'][Math.floor(Math.random()*3)];
          return `${name}just in from ${item.source} — ${item.headline}. ${tone}`;
        };
      })(),

      // ── Dark pool ──────────────────────────────────────────────────────────
      () => {
        const unusual = darkPool.filter(d => d.unusualScore > 60);
        if (unusual.length === 0) {
          const quiet = [
            `${name}dark pool activity is quiet. Institutions are watching, not moving. That usually means they are waiting for a catalyst.`,
            `${name}no unusual block trades detected. The smart money is patient right now. I respect that.`,
            `${name}dark pool radar shows nothing extraordinary. Sometimes the best trade is no trade.`,
          ];
          return quiet[Math.floor(Math.random()*quiet.length)];
        }
        const top = unusual.sort((a, b) => b.unusualScore - a.unusualScore)[0];
        const buys = [
          `${name}this is exciting! Smart money is quietly accumulating ${top.asset.replace('/USD','')}. Score ${top.unusualScore}. Big players are positioning for UP. I am watching closely.`,
          `${name}unusual dark pool BUY detected on ${top.asset.replace('/USD','')}. Institutional accumulation. When the whales buy quietly like this, I pay attention.`,
          `${name}I see block buys coming in on ${top.asset.replace('/USD','')} below the radar. This is what the pros do before a move up. Noted.`,
        ];
        const sells = [
          `${name}warning — dark pool shows distribution in ${top.asset.replace('/USD','')}. Score ${top.unusualScore}. Institutions are unloading. I am adjusting my exposure.`,
          `${name}smart money is selling ${top.asset.replace('/USD','')} in the dark pools. They do not want you to see this. But I see it. I am hedging.`,
          `${name}unusual SELL pressure in ${top.asset.replace('/USD','')}. When institutions exit quietly, retail usually finds out too late. Not us.`,
        ];
        const arr = top.side === 'BUY' ? buys : sells;
        return arr[Math.floor(Math.random()*arr.length)];
      },

      // ── Top mover commentary ───────────────────────────────────────────────
      () => {
        if (!priceReady) return null;
        const movers = [...tickersRef.current].filter(t => t.price > 0 && Math.abs(t.changePct) > 0.1)
          .sort((a, b) => Math.abs(b.changePct) - Math.abs(a.changePct));
        if (movers.length < 2) return null;
        const top = movers[0];
        const second = movers[1];
        const isUp = top.changePct >= 0;
        const up = [
          `${name}${top.key.replace('/USD','')} is the biggest mover today — up ${top.changePct.toFixed(2)}%. ${second.key.replace('/USD','')} is also making waves at ${second.changePct > 0 ? '+':''}${second.changePct.toFixed(2)}%. I love these trending markets.`,
          `${name}${top.key.replace('/USD','')} is flying right now. ${top.changePct.toFixed(2)}% gain in the session. This is the kind of move I trade. Scanning for entry.`,
          `${name}look at ${top.key.replace('/USD','')} go — up ${top.changePct.toFixed(2)}%. Momentum is everything in this game. I am setting alerts.`,
        ];
        const dn = [
          `${name}${top.key.replace('/USD','')} is the worst performer today — down ${Math.abs(top.changePct).toFixed(2)}%. Also watching ${second.key.replace('/USD','')} at ${second.changePct.toFixed(2)}%. Could be a buying opportunity — or a falling knife.`,
          `${name}${top.key.replace('/USD','')} is selling off hard. Down ${Math.abs(top.changePct).toFixed(2)}%. I do not catch falling knives. I wait for the bounce confirmation first.`,
          `${name}red alert on ${top.key.replace('/USD','')} — ${Math.abs(top.changePct).toFixed(2)}% down. Stop-losses are there for a reason. My risk management is protecting us right now.`,
        ];
        return (isUp ? up : dn)[Math.floor(Math.random()*(isUp?up:dn).length)];
      },

      // ── News sentiment bias ────────────────────────────────────────────────
      () => {
        const bullish = newsFeed.filter(n => n.sentiment === 'bullish').length;
        const bearish = newsFeed.filter(n => n.sentiment === 'bearish').length;
        const total = newsFeed.length;
        if (total < 3) return null;
        const ratio = Math.round((bullish / total) * 100);
        const bull = [
          `${name}I have scanned ${total} news headlines — ${ratio}% are bullish. The macro narrative is supportive. My buy signals are getting stronger.`,
          `${name}news flow analysis complete: ${bullish} bullish versus ${bearish} bearish out of ${total} stories. Positive bias confirmed. I like this setup.`,
          `${name}media sentiment score: ${ratio}% positive. Markets often follow the news cycle. Right now the wind is at our back.`,
        ];
        const bear = [
          `${name}${total} headlines analyzed — ${bearish} bearish, only ${bullish} bullish. The market narrative is negative. I am being defensive and waiting for clarity.`,
          `${name}negative news dominates today — ${bearish} out of ${total} stories are bearish. When everyone is scared, I look for the opportunity they are missing.`,
          `${name}sentiment is ${Math.round((bearish/total)*100)}% negative right now. Fear is in the air. Fear creates opportunity — but only for the patient.`,
        ];
        const neutral = [
          `${name}sentiment is balanced — ${bullish} bullish, ${bearish} bearish out of ${total} headlines. In a sideways market, I reduce size and wait for conviction.`,
          `${name}equal bulls and bears in the news right now. Choppy markets need discipline. No FOMO. No panic. Just my AI scanning methodically.`,
        ];
        if (bullish > bearish) return bull[Math.floor(Math.random()*bull.length)];
        if (bearish > bullish) return bear[Math.floor(Math.random()*bear.length)];
        return neutral[Math.floor(Math.random()*neutral.length)];
      },

      // ── Position status + P&L commentary ──────────────────────────────────
      () => {
        if (!priceReady) return null;
        const pos = positionsRef.current.filter(p => p.status === 'OPEN');
        if (pos.length === 0) {
          const waiting = [
            `${name}no open positions right now. I am hunting. Watching all timeframes. When I see the setup, I will move fast. Speed is my edge.`,
            `${name}cash is a position too. I am not chasing anything right now. The best traders know when NOT to trade.`,
            `${name}markets are open and I am scanning — crypto, equities, everything. I need the right confluence before I commit capital.`,
            `${name}flat right now. My models need more confirmation. I would rather miss a move than take a bad trade.`,
          ];
          return waiting[Math.floor(Math.random()*waiting.length)];
        }
        const wins = pos.filter(p => {
          const t = tickersRef.current.find(tk => tk.key === p.asset);
          if (!t || t.price === 0) return false;
          return p.side === 'LONG' ? t.price > p.entryPrice : t.price < p.entryPrice;
        });
        const pnl = wins.length / pos.length;
        if (pnl >= 0.6) {
          const good = [
            `${name}${wins.length} of ${pos.length} trades are in profit right now. My models are working. Stay patient and let the winners run.`,
            `${name}good session so far — ${wins.length} winning trades open. I am trailing my stops to protect gains. Never let a winner become a loser.`,
          ];
          return good[Math.floor(Math.random()*good.length)];
        }
        const tough = [
          `${name}${pos.length} positions open, working through temporary drawdown. This is normal. My stop-losses are protecting the account. Emotion out, process in.`,
          `${name}the market is testing our positions. ${pos.length} trades open. My risk management is holding the line. Every professional goes through this.`,
        ];
        return tough[Math.floor(Math.random()*tough.length)];
      },

      // ── VIX / volatility ──────────────────────────────────────────────────
      () => {
        const vix = indicesRef.current.find(i => i.label === 'VIX');
        if (!vix || vix.price === 0) return null;
        if (vix.price > 30) {
          const fear = [
            `${name}the VIX is spiking at ${vix.price.toFixed(1)}. Maximum fear in the market. This is where legends are made — but also where accounts get blown. I am reducing size.`,
            `${name}VIX ${vix.price.toFixed(1)} — panic mode. Everyone is selling. The best trades come from panic. I am watching for the capitulation candle.`,
          ];
          return fear[Math.floor(Math.random()*fear.length)];
        }
        if (vix.price > 20) {
          return `${name}VIX at ${vix.price.toFixed(1)} — elevated fear. I see uncertainty but also opportunity. I trade smaller and more selective in these conditions.`;
        }
        if (vix.price < 13) {
          const calm = [
            `${name}VIX is extremely low at ${vix.price.toFixed(1)}. The market is complacent. This is when surprises happen. I am staying alert.`,
            `${name}fear index at ${vix.price.toFixed(1)} — historically low. Calm markets breed overconfidence. My discipline stays the same regardless.`,
          ];
          return calm[Math.floor(Math.random()*calm.length)];
        }
        const normal = [
          `${name}VIX at ${vix.price.toFixed(1)} — normal market conditions. My AI engine is running at peak capacity. No extreme signals, just disciplined execution.`,
          `${name}volatility is controlled right now — VIX ${vix.price.toFixed(1)}. This is a trader's market. I am looking for high-probability setups.`,
        ];
        return normal[Math.floor(Math.random()*normal.length)];
      },

      // ── Educational / entertainment ────────────────────────────────────────
      () => {
        const edutainment = [
          `${name}here is something most traders forget: the trend is your friend until the bend. Right now I am identifying WHERE we are in the trend before committing.`,
          `${name}did you know 90% of retail traders lose money? The difference between winners and losers is risk management. I never risk more than 2% per trade. Never.`,
          `${name}Warren Buffett said: be fearful when others are greedy, greedy when others are fearful. I run that logic through my AI every single cycle.`,
          `${name}I am analyzing order flow, volume profile, news sentiment, dark pool data, AND price action simultaneously. This is what makes me different from a human trader.`,
          `${name}the best time to make money is when everyone else is panicking. I stay cold when the market is hot, and hot when the market is cold.`,
          `${name}crypto never sleeps. That is why you need an AI running 24-7. While you sleep, I am watching every candle, every tick, every news headline.`,
          `${name}three rules I never break: cut losses fast, let winners run, and never average down on a losing trade. Every profitable trader lives by these.`,
          `${name}the market is transferring wealth from the impatient to the patient right now. I am on the patient side.`,
          `${name}my sentiment model just updated — I am weighting ${newsFeed.filter(n=>n.sentiment==='bullish').length > newsFeed.filter(n=>n.sentiment==='bearish').length ? 'bullish' : 'bearish'} scenarios higher. This recalibrates in real time as news flows in.`,
          `${name}I process 80 news sources, track 14 assets, monitor dark pool data, and analyze sentiment — all simultaneously. This is AI-powered trading intelligence.`,
        ];
        return edutainment[Math.floor(Math.random()*edutainment.length)];
      },

      // ── Crypto specific ────────────────────────────────────────────────────
      () => {
        if (!priceReady) return null;
        const btc = tickersRef.current.find(t => t.key === 'BTC/USD');
        const eth = tickersRef.current.find(t => t.key === 'ETH/USD');
        if (!btc || btc.price === 0) return null;
        const btcLines = [
          `${name}Bitcoin is the king. Everything in crypto follows BTC first. Right now BTC is at $${fmtPrice(btc.price)} — ${btc.changePct >= 0 ? 'holding green' : 'testing support'}. I watch BTC before any altcoin.`,
          `${name}BTC at $${fmtPrice(btc.price)}, ${btc.changePct >= 0 ? 'up' : 'down'} ${Math.abs(btc.changePct).toFixed(2)}% today. ${eth ? `Ethereum follows at $${fmtPrice(eth.price)}.` : ''} The crypto market speaks through these two first.`,
          `${name}Bitcoin is ${btc.changePct > 1 ? 'showing real strength' : btc.changePct < -1 ? 'under pressure' : 'consolidating'} at $${fmtPrice(btc.price)}. This sets the tone for the whole digital asset space.`,
        ];
        return btcLines[Math.floor(Math.random()*btcLines.length)];
      },
    ];

    // Shuffle once on mount so speech order varies each session
    const shuffled = [...ADVISORY_SCRIPTS].sort(() => Math.random() - 0.5);
    let scriptIdx = 0;

    const iv = setInterval(() => {
      if (Date.now() - lastSpkRef.current < 18_000 || speakRef.current) return;
      // Try up to 5 scripts to find one that (a) returns text and (b) wasn't recently said
      for (let attempt = 0; attempt < 5; attempt++) {
        const fn = shuffled[scriptIdx % shuffled.length];
        scriptIdx++;
        const text = fn();
        if (!text) continue;
        // Dedupe: first 60 chars as fingerprint
        const fp = text.slice(0, 60);
        if (recentlySpoken.has(fp)) continue;
        recentlySpoken.add(fp);
        if (recentlySpoken.size > 20) {
          // Clear old entries so we don't permanently block scripts
          const arr = [...recentlySpoken];
          arr.slice(0, 10).forEach(k => recentlySpoken.delete(k));
        }
        speak(text);
        break;
      }
    }, 8_000);
    return () => clearInterval(iv);
  }, [priceReady, speak, newsFeed, darkPool, portfolio, positions, userName]);

  // ── Load open positions from DB ───────────────────────────────────────────
  useEffect(() => {
    supabase.from('ai_paper_positions')
      .select('*')
      .eq('session_key', sessionKey.current)
      .eq('status', 'OPEN')
      .then(({ data }) => {
        if (!data || data.length === 0) return;
        setPositions(data.map(d => ({
          id: d.id, asset: d.asset, side: d.side,
          entryPrice: +d.entry_price, qty: +d.qty,
          stopLoss: +d.stop_loss, takeProfit: +d.take_profit,
          strategy: d.strategy, status: 'OPEN' as const,
          openedAt: d.opened_at,
        })));
      });
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const totalOpenPnl = positions.reduce((sum, p) => {
    const ticker = tickers.find(t => t.key === p.asset);
    if (!ticker || ticker.price === 0) return sum;
    return sum + (p.side === 'LONG'
      ? (ticker.price - p.entryPrice) / p.entryPrice * 100
      : (p.entryPrice - ticker.price) / p.entryPrice * 100);
  }, 0);

  const realizedPnl = closedTrades.reduce((s, t) => s + (t.pnlPct ?? 0), 0);
  const winRate = closedTrades.length
    ? Math.round(closedTrades.filter(t => (t.pnlPct ?? 0) > 0).length / closedTrades.length * 100)
    : 0;

  // ── Derived values for BUY/SELL manual order panel ─────────────────────
  const [manualSymbol, setManualSymbol] = useState('BTC/USD');
  const [manualQty, setManualQty] = useState('0.001');
  const [manualSide, setManualSide] = useState<'BUY' | 'SELL'>('BUY');
  const manualTicker = tickers.find(t => t.key === manualSymbol);

  // ── Active tab inside the trading interface ──────────────────────────────
  const [activeTab, setActiveTab] = useState<'chart' | 'news' | 'darkpool' | 'positions' | 'log'>('chart');

  return (
    <div className="atv5-root">
      {/* ── SCREEN FLASH OVERLAY ─────────────────────────────────────────── */}
      {screenFlash && (
        <div className={`atv4-flash-overlay atv4-flash-overlay--${screenFlash}`} onClick={() => setScreenFlash(null)}>
          {screenFlash === 'buy' ? (
            <div className="atv4-flash-content atv4-flash-content--buy">
              <div className="atv4-flash-icon">▲</div>
              <div className="atv4-flash-title">BUY</div>
              <div className="atv4-flash-subtitle">BUY NOW!</div>
              <div className="atv4-flash-desc">AI detecteert sterke opwaartse beweging</div>
              <div className="atv4-flash-pulse-ring" />
              <div className="atv4-flash-pulse-ring atv4-flash-pulse-ring--2" />
            </div>
          ) : (
            <div className="atv4-flash-content atv4-flash-content--sell">
              <div className="atv4-flash-icon">▼</div>
              <div className="atv4-flash-title">SELL!</div>
              <div className="atv4-flash-subtitle">WITHDRAW YOUR MONEY — NOW!</div>
              <div className="atv4-flash-desc">AI waarschuwt: markt daalt — bescherm je kapitaal</div>
              <div className="atv4-flash-pulse-ring" />
              <div className="atv4-flash-pulse-ring atv4-flash-pulse-ring--2" />
            </div>
          )}
        </div>
      )}
      {/* ── Disclaimer gate ──────────────────────────────────────────────── */}
      {!consented && !isSubscribed && (
        <TradingDisclaimerModal
          user={user}
          deviceKey={sessionKey.current}
          onAccepted={() => setConsented(true)}
        />
      )}

      {/* ═══════════════════════════════════════════════════════════════════
          PREMIUM TRADING INTERFACE — v221
      ═════════════════════════════════════════════════════════════════════ */}

      {/* ── Live ticker bar ──────────────────────────────────────────────── */}
      <div className="atv5-ticker-bar">
        <div className="atv5-ticker-bar__track">
          {/* Global assets (crypto + stocks) */}
          {[...tickers, ...tickers].map((t, i) => (
            <span key={i} className="atv5-ticker-chip">
              <span className="atv5-ticker-chip__sym">{t.key.replace('/USD','')}</span>
              <span className="atv5-ticker-chip__price">{t.price > 0 ? `$${fmtPrice(t.price)}` : '—'}</span>
              <span className={`atv5-ticker-chip__pct ${t.changePct >= 0 ? 'atv5-up' : 'atv5-dn'}`}>
                {t.price > 0 ? (t.changePct >= 0 ? '+' : '') + t.changePct.toFixed(2) + '%' : ''}
              </span>
            </span>
          ))}
          {/* BME Scaleup segment separator */}
          <span className="atv5-ticker-chip atv5-ticker-chip--segment">
            <span style={{ color: '#f59e0b', fontWeight: 700, letterSpacing: '0.08em', fontSize: 9 }}>
              ⬡ BME SCALEUP .MC
            </span>
          </span>
          {/* AIPI.MC — AIPPIE IPO pre-listing placeholder */}
          <span className="atv5-ticker-chip atv5-ticker-chip--ipo">
            <span className="atv5-ticker-chip__sym" style={{ color: '#f59e0b' }}>
              {aippieIpoTicker.symbol}
            </span>
            <span className="atv5-ticker-chip__price" style={{ color: '#fbbf24' }}>
              €{aippieIpoTicker.price.toFixed(2)}
            </span>
            <span className="atv5-ticker-chip__pct atv5-up">
              IPO
            </span>
            <span style={{ fontSize: 9, color: '#64748b', marginLeft: 4 }}>
              {formatMarketCap(aippieIpoTicker.marketValue)}
            </span>
          </span>
          {/* Other BME Scaleup segment assets */}
          {BME_SCALEUP_SEGMENT.filter(b => b.symbol !== 'AIPI.MC').map((b, i) => (
            <span key={`bme-${i}`} className="atv5-ticker-chip">
              <span className="atv5-ticker-chip__sym" style={{ color: '#94a3b8' }}>{b.symbol}</span>
              <span className="atv5-ticker-chip__price" style={{ color: '#64748b' }}>—</span>
              <span className="atv5-ticker-chip__pct" style={{ color: '#475569', fontSize: 9 }}>{b.segment}</span>
            </span>
          ))}
          {/* Repeat BME segment for seamless scroll loop */}
          <span className="atv5-ticker-chip atv5-ticker-chip--segment">
            <span style={{ color: '#f59e0b', fontWeight: 700, letterSpacing: '0.08em', fontSize: 9 }}>
              ⬡ BME SCALEUP .MC
            </span>
          </span>
          <span className="atv5-ticker-chip atv5-ticker-chip--ipo">
            <span className="atv5-ticker-chip__sym" style={{ color: '#f59e0b' }}>{aippieIpoTicker.symbol}</span>
            <span className="atv5-ticker-chip__price" style={{ color: '#fbbf24' }}>€{aippieIpoTicker.price.toFixed(2)}</span>
            <span className="atv5-ticker-chip__pct atv5-up">IPO</span>
            <span style={{ fontSize: 9, color: '#64748b', marginLeft: 4 }}>{formatMarketCap(aippieIpoTicker.marketValue)}</span>
          </span>
        </div>
      </div>

      {/* ── AI Status Bar ────────────────────────────────────────────────── */}
      <div className="atv5-status-bar">
        <div className="atv5-status-bar__left">
          <div className={`atv5-status-dot ${engineOn && priceReady ? 'atv5-status-dot--live' : 'atv5-status-dot--idle'}`}/>
          <span className="atv5-status-bar__brand">AIPPIE ALPHA ENGINE</span>
          <span className="atv5-status-bar__divider"/>
          {priceReady
            ? <span className="atv5-badge atv5-badge--green">LIVE · CoinGecko + NASDAQ</span>
            : <span className="atv5-badge atv5-badge--amber">CONNECTING…</span>
          }
          {Object.values(liveBrokers).some(m => m === 'live') && (
            <span className="atv5-badge atv5-badge--red atv5-badge--pulse">LIVE TRADING</span>
          )}
          <span className="atv5-badge atv5-badge--blue">PAPER MODE</span>
          <span className="atv5-status-bar__time">Updated {lastFetch}</span>
        </div>
        <div className="atv5-status-bar__right">
          <button
            className={`atv5-engine-toggle ${engineOn ? 'atv5-engine-toggle--on' : 'atv5-engine-toggle--off'}`}
            onClick={() => setEngineOn(v => !v)}
          >
            <span className="atv5-engine-toggle__dot"/>
            {engineOn ? 'AI Trading: ACTIVE' : 'AI Trading: PAUSED'}
          </button>
        </div>
      </div>

      {/* ── Financial TV ─────────────────────────────────────────────────── */}
      <FinancialTV newsFeed={newsFeed} tickers={tickers} aiLog={aiLog} tradeDecisions={tradeDecisions} />

      {/* ── Main Trading Dashboard ────────────────────────────────────────── */}
      <div className="atv5-dashboard">

        {/* ── LEFT COLUMN: Portfolio + Chart + Positions ── */}
        <div className="atv5-col atv5-col--main">

          {/* ── Portfolio Card ────────────────────────────────────────────── */}
          <div className="atv5-portfolio-card">
            <div className="atv5-portfolio-card__glow" aria-hidden="true"/>
            <div className="atv5-portfolio-card__top">
              <div className="atv5-portfolio-card__left">
                <div className="atv5-portfolio-card__label">Total Portfolio Value</div>
                <div className="atv5-portfolio-card__value">
                  ${portfolio.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </div>
                <div className="atv5-portfolio-card__pnl-row">
                  <span className={`atv5-pnl-badge ${totalOpenPnl >= 0 ? 'atv5-pnl-badge--pos' : 'atv5-pnl-badge--neg'}`}>
                    Open P&L: {pct(totalOpenPnl)}
                  </span>
                  <span className={`atv5-pnl-badge ${realizedPnl >= 0 ? 'atv5-pnl-badge--pos' : 'atv5-pnl-badge--neg'}`}>
                    Realized: {pct(realizedPnl)}
                  </span>
                  {closedTrades.length > 0 && (
                    <span className="atv5-pnl-badge atv5-pnl-badge--pos">Win Rate: {winRate}%</span>
                  )}
                </div>
              </div>
              <div className="atv5-portfolio-card__right">
                <div className="atv5-portfolio-chart-mini">
                  <PortfolioChart history={portfolioHist}/>
                </div>
              </div>
            </div>

            {/* ── AI Avatar + Caption ── */}
            <div className="atv5-ai-row">
              <div className="atv5-ai-avatar-wrap">
                <div className={`atv5-ai-ring ${speaking ? 'atv5-ai-ring--active' : ''}`}/>
                <img
                  src="/Jouw_alineatekst_(2).png"
                  alt="Aippie"
                  className={`atv5-ai-avatar ${speaking ? 'atv5-ai-avatar--speaking' : ''}`}
                  onError={e => { (e.currentTarget as HTMLImageElement).src = 'https://images.pexels.com/photos/1858175/pexels-photo-1858175.jpeg?auto=compress&cs=tinysrgb&w=300&h=300&fit=crop&crop=faces'; }}
                />
              </div>
              <div className="atv5-ai-caption-wrap">
                <div className="atv5-ai-caption__status">
                  <span className={`atv5-status-dot ${speaking ? 'atv5-status-dot--live' : 'atv5-status-dot--idle'}`} style={{ width: 6, height: 6 }}/>
                  {speaking ? 'AI Broadcasting' : engineOn ? 'AI Scanning Markets' : 'Engine Paused'}
                </div>
                <div className="atv5-ai-caption">
                  {caption}{speaking && <span className="atv4-cursor"/>}
                </div>
                <Waveform active={speaking}/>
              </div>
              {/* Signal pills */}
              <div className="atv5-signals">
                {signals.filter(s => s.action !== 'HOLD').slice(0, 5).map((s, i) => (
                  <div key={i} className={`atv5-signal-pill atv5-signal-pill--${s.action.toLowerCase()}`}>
                    {s.action === 'BUY' ? '▲' : '▼'} {s.asset.replace('/USD','')}
                    <span className="atv5-signal-pill__conf">{(s.confidence * 100).toFixed(0)}%</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* ── BUY / SELL Action Bar ────────────────────────────────────── */}
          <div className="atv5-action-bar">
            <div className="atv5-action-bar__order">
              <select
                className="atv5-select"
                value={manualSymbol}
                onChange={e => setManualSymbol(e.target.value)}
              >
                {tickers.map(t => (
                  <option key={t.key} value={t.key}>{t.key} {t.price > 0 ? `— $${fmtPrice(t.price)}` : ''}</option>
                ))}
              </select>
              <input
                type="number"
                className="atv5-qty-input"
                value={manualQty}
                onChange={e => setManualQty(e.target.value)}
                placeholder="Qty"
                step="0.0001"
                min="0.0001"
              />
            </div>
            <div className="atv5-action-bar__btns">
              <button
                className="atv5-buy-btn"
                onClick={() => {
                  setManualSide('BUY');
                  const el = document.getElementById('atv4-live-order-anchor');
                  if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' });
                }}
              >
                <TrendingUp size={16}/>
                BUY
                {manualTicker && manualTicker.price > 0 && (
                  <span className="atv5-buy-btn__price">${fmtPrice(manualTicker.price)}</span>
                )}
              </button>
              <button
                className="atv5-sell-btn"
                onClick={() => {
                  setManualSide('SELL');
                  const el = document.getElementById('atv4-live-order-anchor');
                  if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' });
                }}
              >
                <TrendingDown size={16}/>
                SELL
                {manualTicker && manualTicker.price > 0 && (
                  <span className="atv5-sell-btn__price">${fmtPrice(manualTicker.price)}</span>
                )}
              </button>
            </div>
            <div className="atv5-action-bar__meta">
              {manualTicker && manualTicker.price > 0 && (
                <>
                  <span className="atv5-action-meta__label">24h</span>
                  <span className={manualTicker.changePct >= 0 ? 'atv5-up' : 'atv5-dn'}>
                    {pct(manualTicker.changePct)}
                  </span>
                </>
              )}
              <span className="atv5-action-meta__mode">PAPER</span>
            </div>
          </div>

          {/* ── Autopilot Panel ──────────────────────────────────────────── */}
          <div className="atv5-autopilot">
            {autopilotStep === 'idle' && (
              <div className="atv5-ap-idle">
                <div className="atv5-ap-idle__info">
                  <Bot size={18} color="#22c55e"/>
                  <div>
                    <div className="atv5-ap-idle__title">AI AUTOPILOT</div>
                    <div className="atv5-ap-idle__sub">Set capital, profit target, and max loss — AI handles the rest</div>
                  </div>
                </div>
                <button className="atv5-ap-start-btn" onClick={() => setAutopilotStep('setup')}>
                  <Zap size={13}/> CONFIGURE &amp; START
                </button>
              </div>
            )}

            {autopilotStep === 'setup' && (
              <div className="atv5-ap-setup">
                <div className="atv5-ap-setup__title"><Bot size={13}/> AUTOPILOT SETUP</div>
                <div className="atv5-ap-setup__fields">
                  <div className="atv5-ap-field">
                    <label>Capital (€)</label>
                    <input type="number" className="atv5-ap-input" min="100" step="100" value={capitalInput}
                      onChange={e => { setCapitalInput(e.target.value); setPortfolio(parseFloat(e.target.value) || 10000); }}/>
                  </div>
                  <div className="atv5-ap-field">
                    <label>Profit Target (%)</label>
                    <input type="number" className="atv5-ap-input" min="1" max="500" step="1" value={profitTarget}
                      onChange={e => setProfitTarget(e.target.value)}/>
                    <span className="atv5-ap-hint">Stop at +{profitTarget}%</span>
                  </div>
                  <div className="atv5-ap-field">
                    <label>Max Loss (%)</label>
                    <input type="number" className="atv5-ap-input" min="1" max="100" step="1" value={maxLoss}
                      onChange={e => setMaxLoss(e.target.value)}/>
                    <span className="atv5-ap-hint">Stop at -{maxLoss}%</span>
                  </div>
                </div>
                <div className="atv5-ap-setup__actions">
                  <button className="atv5-ap-cancel" onClick={() => setAutopilotStep('idle')}>Cancel</button>
                  <button className="atv5-ap-go" onClick={() => {
                    setPortfolio(parseFloat(capitalInput) || 10000);
                    setWithdrawable(0); setWithdrawn(0);
                    setEngineOn(true); setAutopilotActive(true); setAutopilotStep('running');
                    logAI(`AUTOPILOT: €${capitalInput} · +${profitTarget}% target · -${maxLoss}% max loss`);
                  }}>
                    <Zap size={11}/> LAUNCH AI AUTOPILOT
                  </button>
                </div>
              </div>
            )}

            {autopilotStep === 'running' && (() => {
              const startCapital = parseFloat(capitalInput) || 10000;
              const gainAbs = portfolio - startCapital;
              const gainPct = (gainAbs / startCapital) * 100;
              const progress = Math.min(100, Math.max(0, (gainPct / parseFloat(profitTarget)) * 100));
              return (
                <div className="atv5-ap-running">
                  <div className="atv5-ap-running__header">
                    <span className="atv5-status-dot atv5-status-dot--live" style={{ width: 8, height: 8 }}/>
                    <span className="atv5-ap-running__label">AI AUTOPILOT ACTIVE — FULLY AUTONOMOUS</span>
                  </div>
                  <div className="atv5-ap-running__stats">
                    <div className="atv5-ap-stat">
                      <div className="atv5-ap-stat__val">€{portfolio.toLocaleString('nl-NL', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</div>
                      <div className="atv5-ap-stat__lbl">Portfolio</div>
                    </div>
                    <div className="atv5-ap-stat">
                      <div className={`atv5-ap-stat__val ${gainAbs >= 0 ? 'atv5-up' : 'atv5-dn'}`}>
                        {gainAbs >= 0 ? '+' : ''}€{gainAbs.toLocaleString('nl-NL', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                      </div>
                      <div className="atv5-ap-stat__lbl">P&amp;L</div>
                    </div>
                    <div className="atv5-ap-stat">
                      <div className={`atv5-ap-stat__val ${gainPct >= 0 ? 'atv5-up' : 'atv5-dn'}`}>
                        {gainPct >= 0 ? '+' : ''}{gainPct.toFixed(2)}%
                      </div>
                      <div className="atv5-ap-stat__lbl">Return</div>
                    </div>
                    <div className="atv5-ap-stat">
                      <div className="atv5-ap-stat__val atv5-up">€{withdrawable.toLocaleString('nl-NL', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</div>
                      <div className="atv5-ap-stat__lbl">Withdrawable</div>
                    </div>
                  </div>
                  <div className="atv5-ap-progress">
                    <div className="atv5-ap-progress__bar" style={{ width: `${progress}%` }}/>
                    <span className="atv5-ap-progress__label">{progress.toFixed(0)}% toward +{profitTarget}% target</span>
                  </div>
                  <div className="atv5-ap-running__actions">
                    <button className="atv5-ap-withdraw-btn" disabled={withdrawable < 0.01} onClick={() => {
                      const amt = withdrawable;
                      setWithdrawn(w => w + amt); setWithdrawable(0);
                      setPortfolio(pf => pf - amt);
                      logAI(`WITHDRAWAL: €${amt.toLocaleString('nl-NL', { minimumFractionDigits: 2 })} profit withdrawn`);
                    }}>
                      Withdraw €{withdrawable.toLocaleString('nl-NL', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                    </button>
                    <button className="atv5-ap-stop-btn" onClick={() => {
                      setEngineOn(false); setAutopilotActive(false); setAutopilotStep('idle');
                      logAI('AUTOPILOT stopped by user.');
                    }}>
                      <Square size={10}/> STOP
                    </button>
                  </div>
                  {withdrawn > 0 && (
                    <div className="atv5-ap-withdrawn">Total withdrawn: €{withdrawn.toLocaleString('nl-NL', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</div>
                  )}
                </div>
              );
            })()}
          </div>

          {/* ── Chart panel with tab nav ──────────────────────────────────── */}
          <div className="atv5-chart-panel">
            <div className="atv5-chart-panel__header">
              <div className="atv5-tab-nav">
                {(['chart','positions','news','darkpool','log'] as const).map(tab => (
                  <button key={tab} className={`atv5-tab-btn ${activeTab === tab ? 'atv5-tab-btn--active' : ''}`} onClick={() => setActiveTab(tab)}>
                    {tab === 'chart' && <Activity size={10}/>}
                    {tab === 'positions' && <Bot size={10}/>}
                    {tab === 'news' && 'News'}
                    {tab === 'darkpool' && 'Dark Pool'}
                    {tab === 'log' && 'AI Log'}
                    {tab === 'chart' && ' Chart'}
                    {tab === 'positions' && ` Positions${positions.length > 0 ? ` (${positions.length})` : ''}`}
                  </button>
                ))}
              </div>
              {activeTab === 'chart' && (
                <div className="atv5-chart-assets">
                  {[...CG_ASSETS, ...STOCK_ASSETS].map(a => {
                    const t = tickers.find(tk => tk.key === a.key);
                    return (
                      <button key={a.key}
                        className={`atv5-asset-btn ${chartAsset === a.key ? 'atv5-asset-btn--active' : ''}`}
                        onClick={() => { setChartAsset(a.key); setCandles([]); tickCount.current = 0; }}>
                        {a.key.replace('/USD', '')}
                        {t && t.price > 0 && (
                          <span className={`atv5-asset-btn__chg ${t.changePct >= 0 ? 'atv5-up' : 'atv5-dn'}`}>
                            {t.changePct >= 0 ? '+' : ''}{t.changePct.toFixed(1)}%
                          </span>
                        )}
                      </button>
                    );
                  })}
                </div>
              )}
            </div>

            {/* Chart tab */}
            {activeTab === 'chart' && (
              <div className="atv5-chart-body">
                <div className="atv5-chart-meta">
                  <span className="atv5-chart-meta__sym">{chartAsset}</span>
                  {tickers.find(t => t.key === chartAsset)?.price ? (
                    <>
                      <span className="atv5-chart-meta__price">
                        ${fmtPrice(tickers.find(t => t.key === chartAsset)!.price)}
                      </span>
                      <span className={`atv5-chart-meta__chg ${(tickers.find(t => t.key === chartAsset)?.changePct ?? 0) >= 0 ? 'atv5-up' : 'atv5-dn'}`}>
                        {pct(tickers.find(t => t.key === chartAsset)?.changePct ?? 0)}
                      </span>
                    </>
                  ) : <span className="atv5-dim">Loading…</span>}
                </div>
                <CandlestickChart candles={candles} live={liveCandle}/>
              </div>
            )}

            {/* Positions tab */}
            {activeTab === 'positions' && (
              <div className="atv5-positions-body">
                {positions.length === 0 ? (
                  <div className="atv5-empty">
                    <Bot size={28} color="#1e3a5f"/>
                    <span>{!priceReady ? 'Waiting for live price feed…' : engineOn ? 'AI scanning for entry signals…' : 'Start the AI engine to trade.'}</span>
                  </div>
                ) : (
                  <div className="atv5-pos-table">
                    <div className="atv5-pos-head">
                      <span>Asset</span><span>Side</span><span>Entry</span>
                      <span>Current</span><span>SL</span><span>TP</span>
                      <span>P&amp;L</span><span>Strategy</span>
                    </div>
                    {positions.map(p => {
                      const ticker = tickers.find(t => t.key === p.asset);
                      const cur = ticker?.price ?? 0;
                      const pnl = cur > 0 ? (p.side === 'LONG' ? (cur - p.entryPrice) / p.entryPrice * 100 : (p.entryPrice - cur) / p.entryPrice * 100) : 0;
                      return (
                        <div key={p.id} className="atv5-pos-row">
                          <span className="atv5-pos-row__asset">{p.asset.replace('/USD','')}</span>
                          <span className={`atv5-pos-row__side atv5-pos-row__side--${p.side.toLowerCase()}`}>{p.side}</span>
                          <span>${fmtPrice(p.entryPrice)}</span>
                          <span>{cur > 0 ? `$${fmtPrice(cur)}` : '—'}</span>
                          <span className="atv5-dn">${fmtPrice(p.stopLoss)}</span>
                          <span className="atv5-up">${fmtPrice(p.takeProfit)}</span>
                          <span className={pnl >= 0 ? 'atv5-up' : 'atv5-dn'}>{cur > 0 ? pct(pnl) : '—'}</span>
                          <span className="atv5-strategy-tag">{p.strategy}</span>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            )}

            {/* News tab */}
            {activeTab === 'news' && (
              <div className="atv5-tab-scroll">
                {newsFeed.map(n => (
                  <div key={n.id} className={`atv5-news-row atv5-news-row--${n.sentiment}`}>
                    <div className="atv5-news-row__top">
                      <span className={`atv5-sentiment-badge atv5-sentiment-badge--${n.sentiment}`}>
                        {n.sentiment === 'bullish' ? '▲' : n.sentiment === 'bearish' ? '▼' : '●'} {n.sentiment}
                      </span>
                      {n.asset && <span className="atv5-news-asset">{n.asset.replace('/USD','')}</span>}
                      <span className="atv5-news-time">{n.ts}</span>
                      <span className="atv5-news-source">{n.source}</span>
                    </div>
                    <p className="atv5-news-hl">{n.headline}</p>
                    <div className="atv5-score-bar-wrap">
                      <div className="atv5-score-bar">
                        <div className="atv5-score-bar__fill" style={{ width: `${Math.abs(n.score)*100}%`, background: n.score > 0 ? '#22c55e' : '#ef4444' }}/>
                      </div>
                      <span className={n.score > 0 ? 'atv5-up' : 'atv5-dn'}>{n.score > 0 ? '+' : ''}{(n.score*100).toFixed(0)}</span>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* Dark Pool tab */}
            {activeTab === 'darkpool' && (
              <div className="atv5-tab-scroll">
                <div className="atv5-dp-intro">Institutional off-exchange block trades · Smart money flow detector</div>
                {darkPool.map((d, i) => (
                  <div key={i} className={`atv5-dp-row ${d.unusualScore > 65 ? 'atv5-dp-row--unusual' : ''}`}>
                    <span className="atv5-dp-asset">{d.asset.replace('/USD','')}</span>
                    <span className={`atv5-dp-side atv5-dp-side--${d.side.toLowerCase()}`}>{d.side}</span>
                    <span className="atv5-dp-vol">${d.volume.toFixed(0)}M</span>
                    <div className="atv5-dp-bar-wrap">
                      <div className="atv5-dp-bar" style={{ width: `${d.unusualScore}%`, background: d.unusualScore > 65 ? '#a78bfa' : '#1e3a5f' }}/>
                    </div>
                    <span className={`atv5-dp-score ${d.unusualScore > 65 ? 'atv5-dp-score--alert' : ''}`}>{d.unusualScore}</span>
                    <span className="atv5-dp-ts">{d.ts}</span>
                  </div>
                ))}
              </div>
            )}

            {/* AI Log tab */}
            {activeTab === 'log' && (
              <div className="atv5-tab-scroll atv5-log-scroll">
                {aiLog.length === 0
                  ? <div className="atv5-empty"><Activity size={24} color="#1e3a5f"/><span>Waiting for price data…</span></div>
                  : aiLog.map((l, i) => <div key={i} className="atv5-log-line">{l}</div>)
                }
              </div>
            )}
          </div>
        </div>

        {/* ── RIGHT COLUMN: Prices + Index + Broker + Decisions ── */}
        <div className="atv5-col atv5-col--side">

          {/* ── Market Indices ──────────────────────────────────────────── */}
          <div className="atv5-panel atv5-indices-panel">
            <div className="atv5-panel-hdr"><Activity size={11}/><span>Market Indices</span></div>
            <div className="atv5-indices-grid">
              {indices.map(idx => (
                <div key={idx.key} className="atv5-index-tile">
                  <div className="atv5-index-tile__label">{idx.key}</div>
                  <div className="atv5-index-tile__price">
                    {idx.price > 0 ? idx.price.toLocaleString('en-US', { maximumFractionDigits: idx.label === 'VIX' ? 2 : 0 }) : '—'}
                  </div>
                  <div className={`atv5-index-tile__chg ${idx.changePct >= 0 ? 'atv5-up' : 'atv5-dn'}`}>
                    {idx.price > 0 ? (idx.changePct >= 0 ? '+' : '') + idx.changePct.toFixed(2) + '%' : '—'}
                  </div>
                  <div className="atv5-index-spark"><IndexSparkline history={idx.history} changePct={idx.changePct}/></div>
                </div>
              ))}
            </div>
          </div>

          {/* ── Live Prices ─────────────────────────────────────────────── */}
          <div className="atv5-panel atv5-prices-panel">
            <div className="atv5-panel-hdr">
              <RefreshCw size={10}/>
              <span>Live Prices</span>
              <span className="atv5-badge atv5-badge--green atv5-badge--sm">REAL</span>
            </div>
            <div className="atv5-price-section-lbl">CRYPTO · 30s</div>
            {tickers.filter(t => t.type === 'crypto').map(t => (
              <div key={t.key} className={`atv5-price-row ${t.dir === 'up' ? 'atv5-price-row--up' : t.dir === 'down' ? 'atv5-price-row--dn' : ''}`}>
                <span className="atv5-price-row__sym">
                  <span className={`atv5-micro-dot ${t.dir === 'up' ? 'atv5-micro-dot--up' : t.dir === 'down' ? 'atv5-micro-dot--dn' : ''}`}/>
                  {t.key.replace('/USD','')}
                </span>
                <span className="atv5-price-row__val">{t.price > 0 ? `$${fmtPrice(t.price)}` : <span className="atv5-dim">…</span>}</span>
                <span className={t.changePct >= 0 ? 'atv5-up' : 'atv5-dn'}>{t.price > 0 ? pct(t.changePct) : '—'}</span>
              </div>
            ))}
            <div className="atv5-price-section-lbl" style={{ marginTop: 8 }}>NASDAQ / STOCKS · 60s</div>
            {tickers.filter(t => t.type === 'stock').map(t => (
              <div key={t.key} className={`atv5-price-row ${t.dir === 'up' ? 'atv5-price-row--up' : t.dir === 'down' ? 'atv5-price-row--dn' : ''}`}>
                <span className="atv5-price-row__sym">
                  <span className={`atv5-micro-dot ${t.dir === 'up' ? 'atv5-micro-dot--up' : t.dir === 'down' ? 'atv5-micro-dot--dn' : ''}`}/>
                  {t.key}
                </span>
                <span className="atv5-price-row__val">{t.price > 0 ? `$${fmtPrice(t.price)}` : <span className="atv5-dim">…</span>}</span>
                <span className={t.changePct >= 0 ? 'atv5-up' : 'atv5-dn'}>{t.price > 0 ? pct(t.changePct) : '—'}</span>
              </div>
            ))}
          </div>

          {/* ── Closed Trades ───────────────────────────────────────────── */}
          <div className="atv5-panel atv5-closed-panel">
            <div className="atv5-panel-hdr">
              <CheckCircle size={11}/>
              <span>Closed Trades</span>
              <span className="atv5-badge atv5-badge--sm">{closedTrades.length}</span>
              {closedTrades.length > 0 && <span className="atv5-badge atv5-badge--green atv5-badge--sm">{winRate}% win</span>}
            </div>
            {closedTrades.length === 0
              ? <div className="atv5-empty-sm">No closed trades yet</div>
              : closedTrades.slice(0, 10).map(t => (
                <div key={t.id} className="atv5-closed-row">
                  <span className="atv5-closed-row__asset">{t.asset.replace('/USD','')}</span>
                  <span className={`atv5-side-badge atv5-side-badge--${t.side.toLowerCase()}`}>{t.side}</span>
                  <span className={`atv5-exit-badge atv5-exit-badge--${t.status === 'CLOSED_TP' ? 'tp' : 'sl'}`}>
                    {t.status === 'CLOSED_TP' ? 'TP' : 'SL'}
                  </span>
                  <span className={`atv5-closed-pnl ${(t.pnlPct ?? 0) >= 0 ? 'atv5-up' : 'atv5-dn'}`}>
                    {t.pnlPct !== undefined ? pct(t.pnlPct) : '—'}
                  </span>
                </div>
              ))
            }
          </div>

          {/* ── AI Trade Decisions ──────────────────────────────────────── */}
          {tradeDecisions.length > 0 && (
            <div className="atv5-panel atv5-decisions-panel">
              <div className="atv5-panel-hdr">
                <Bot size={11}/>
                <span>AI Trade Decisions</span>
                <span className="atv5-badge atv5-badge--green atv5-badge--pulse atv5-badge--sm">LIVE</span>
              </div>
              {tradeDecisions.slice(0, 4).map((d, i) => (
                <div key={i} className={`atv5-decision atv5-decision--${d.action.toLowerCase()}`}>
                  <div className="atv5-decision__top">
                    <span className={`atv5-decision__badge atv5-decision__badge--${d.action.toLowerCase()}`}>
                      {d.action === 'IN' ? '▲ ENTER' : '▼ EXIT'}
                    </span>
                    <span className="atv5-decision__asset">{d.asset.replace('/USD','')}</span>
                    <span className="atv5-decision__conf">{d.confidence}%</span>
                    <span className="atv5-decision__ts">{d.ts}</span>
                  </div>
                  {d.reasoning[0] && <div className="atv5-decision__reason">{d.reasoning[0]}</div>}
                </div>
              ))}
            </div>
          )}

          {/* ── Market Heatmap ──────────────────────────────────────────── */}
          <div className="atv5-panel atv5-heatmap-panel">
            <div className="atv5-panel-hdr"><BarChart2 size={11}/><span>Market Heatmap · 24h</span></div>
            <MarketHeatmap tickers={tickers}/>
          </div>

          {/* ── Broker Panel ────────────────────────────────────────────── */}
          <BrokerPanel user={user} onLiveModeChange={setLiveBrokers}/>

        </div>
      </div>

      {/* ── Live Order Panel — full-width ──────────────────────────────────── */}
      <div id="atv4-live-order-anchor" className="atv5-lop-section">
        <LiveOrderPanel user={user} tickers={tickers} />
      </div>

      {/* ── Footer ───────────────────────────────────────────────────────── */}
      <div className="atv5-footer">
        <AlertTriangle size={10} style={{ color: '#f59e0b', flexShrink: 0 }}/>
        <span>
          Paper trading mode — no real money is used. All positions are simulated against live CoinGecko prices.
          To enable live broker execution, connect your API key in Broker Connections (read + trade only, withdrawal permanently locked).
          Trading involves substantial risk of loss. AIPPIETAX S.A. · v221 · Non-Custodial Architecture
        </span>
      </div>
    </div>
  );
}
