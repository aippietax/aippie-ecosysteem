/**
 * LicenseGate — V116 Intellectual Property Shield
 * AIPPIETAX S.A.
 *
 * Wraps every dashboard. On mount, validates the stored license key against
 * aippietax_active_licenses. Shows a blocking modal if validation fails.
 * Silent pass-through if no license key stored (free/demo tier).
 */
import { useCallback, useEffect, useRef, useState } from 'react';
import { ShieldCheck, Lock, X, ChevronRight, RefreshCw, AlertTriangle } from 'lucide-react';
import { supabase } from '../lib/supabase';

export const LICENSE_KEY_STORAGE = 'aippie_license_key';

export type LicenseStatus = 'checking' | 'valid' | 'no_license' | 'invalid' | 'expired' | 'revoked' | 'seat_limit';

export interface LicenseRecord {
  id: string;
  license_key: string;
  owner_name: string;
  owner_email: string;
  license_type: string;
  plan: string;
  max_seats: number;
  used_seats: number;
  status: string;
  expires_at: string | null;
}

interface Props {
  /** If false, skip validation entirely (already checked at top level) */
  enabled?: boolean;
  children: React.ReactNode;
  onLicenseValid?: (record: LicenseRecord) => void;
}

async function validateKey(key: string): Promise<{ status: LicenseStatus; record?: LicenseRecord }> {
  const { data, error } = await supabase
    .from('aippietax_active_licenses')
    .select('id,license_key,owner_name,owner_email,license_type,plan,max_seats,used_seats,status,expires_at')
    .eq('license_key', key.trim().toUpperCase())
    .maybeSingle();

  if (error || !data) return { status: 'invalid' };

  const deviceKey = localStorage.getItem('aippie_device_key') ?? '';

  // Check expiry
  if (data.expires_at && new Date(data.expires_at) < new Date()) {
    await supabase.from('license_validation_log').insert({
      license_id: data.id, device_key: deviceKey, result: 'expired',
    });
    return { status: 'expired', record: data as LicenseRecord };
  }

  // Check revocation / suspension
  if (data.status === 'revoked') {
    await supabase.from('license_validation_log').insert({
      license_id: data.id, device_key: deviceKey, result: 'revoked',
    });
    return { status: 'revoked', record: data as LicenseRecord };
  }

  if (data.status !== 'active') {
    await supabase.from('license_validation_log').insert({
      license_id: data.id, device_key: deviceKey, result: 'invalid',
    });
    return { status: 'invalid', record: data as LicenseRecord };
  }

  // Check seat limit — upsert activation
  const { data: existing } = await supabase
    .from('license_activations')
    .select('id, is_active')
    .eq('license_id', data.id)
    .eq('device_key', deviceKey)
    .maybeSingle();

  if (!existing) {
    if (data.used_seats >= data.max_seats) {
      await supabase.from('license_validation_log').insert({
        license_id: data.id, device_key: deviceKey, result: 'seat_limit',
      });
      return { status: 'seat_limit', record: data as LicenseRecord };
    }
    // Register new seat
    await supabase.from('license_activations').insert({
      license_id: data.id, device_key: deviceKey, last_seen_at: new Date().toISOString(),
    });
    await supabase
      .from('aippietax_active_licenses')
      .update({ used_seats: data.used_seats + 1 })
      .eq('id', data.id);
  } else {
    // Refresh heartbeat
    await supabase
      .from('license_activations')
      .update({ last_seen_at: new Date().toISOString(), is_active: true })
      .eq('id', existing.id);
  }

  await supabase.from('license_validation_log').insert({
    license_id: data.id, device_key: deviceKey, result: 'valid',
  });

  return { status: 'valid', record: data as LicenseRecord };
}

const STATUS_COPY: Record<LicenseStatus, { title: string; body: string; color: string }> = {
  checking:    { title: 'Validating License',       body: 'Verifying your AIPPIETAX S.A. license key...', color: '#60a5fa' },
  valid:       { title: 'License Active',            body: 'Your license is valid and active.',             color: '#4ade80' },
  no_license:  { title: 'No License Key',            body: 'Enter your AIPPIETAX S.A. license key to unlock this module.', color: '#fbbf24' },
  invalid:     { title: 'Invalid License Key',       body: 'The license key was not found. Check your key or contact support@aippietax.com.', color: '#f87171' },
  expired:     { title: 'License Expired',           body: 'Your license has expired. Renew at aippietax.com.', color: '#fb923c' },
  revoked:     { title: 'License Revoked',           body: 'This license key has been revoked by an administrator.', color: '#f87171' },
  seat_limit:  { title: 'Seat Limit Reached',        body: 'All seats on this license are in use. Contact your administrator.', color: '#fb923c' },
};

export default function LicenseGate({ enabled = true, children, onLicenseValid }: Props) {
  const [status,  setStatus]  = useState<LicenseStatus>('checking');
  const [record,  setRecord]  = useState<LicenseRecord | null>(null);
  const [input,   setInput]   = useState('');
  const [inputErr,setInputErr]= useState('');
  const [saving,  setSaving]  = useState(false);
  const mountedRef = useRef(true);

  const runValidation = useCallback(async () => {
    if (!enabled) return;
    const stored = localStorage.getItem(LICENSE_KEY_STORAGE);
    if (!stored) { setStatus('no_license'); return; }

    setStatus('checking');
    const result = await validateKey(stored);
    if (!mountedRef.current) return;
    setStatus(result.status);
    if (result.record) setRecord(result.record);
    if (result.status === 'valid' && result.record) {
      onLicenseValid?.(result.record);
    }
  }, [enabled, onLicenseValid]);

  useEffect(() => {
    mountedRef.current = true;
    runValidation();
    return () => { mountedRef.current = false; };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleActivate = async () => {
    if (!input.trim()) { setInputErr('Enter your license key.'); return; }
    setSaving(true);
    setInputErr('');
    const result = await validateKey(input);
    setSaving(false);
    if (!mountedRef.current) return;
    if (result.status === 'valid' && result.record) {
      localStorage.setItem(LICENSE_KEY_STORAGE, result.record.license_key);
      setRecord(result.record);
      setStatus('valid');
      onLicenseValid?.(result.record);
    } else {
      setStatus(result.status);
      setInputErr(STATUS_COPY[result.status]?.body ?? 'Validation failed.');
    }
  };

  const handleClear = () => {
    localStorage.removeItem(LICENSE_KEY_STORAGE);
    setStatus('no_license');
    setRecord(null);
    setInput('');
  };

  // Pass-through: valid or not enabled
  if (!enabled || status === 'valid') return <>{children}</>;

  const info = STATUS_COPY[status];

  return (
    <div className="lg-root">
      <div className="lg-backdrop" />
      <div className="lg-modal">

        <div className="lg-modal__header">
          <div className="lg-modal__icon-wrap" style={{ borderColor: info.color + '44', background: info.color + '12' }}>
            {status === 'checking'
              ? <RefreshCw size={22} style={{ color: info.color }} className="lg-spin" />
              : status === 'valid'
              ? <ShieldCheck size={22} style={{ color: info.color }} />
              : status === 'no_license'
              ? <Lock size={22} style={{ color: info.color }} />
              : <AlertTriangle size={22} style={{ color: info.color }} />
            }
          </div>
          <div>
            <div className="lg-modal__title" style={{ color: info.color }}>{info.title}</div>
            <div className="lg-modal__sub">AIPPIETAX S.A. · IP Shield v116</div>
          </div>
        </div>

        <p className="lg-modal__body">{info.body}</p>

        {record && status !== 'valid' && (
          <div className="lg-modal__record">
            <span>{record.owner_name}</span>
            <span className="lg-modal__key">{record.license_key}</span>
            <span className="lg-badge" style={{ background: info.color + '22', color: info.color }}>
              {record.license_type}
            </span>
          </div>
        )}

        {/* Key input */}
        {(status === 'no_license' || status === 'invalid' || status === 'expired' || status === 'revoked' || status === 'seat_limit') && (
          <div className="lg-modal__form">
            <input
              className={`lg-input${inputErr ? ' lg-input--error' : ''}`}
              value={input}
              onChange={e => setInput(e.target.value.toUpperCase())}
              placeholder="AIPP-XXXX-XXXX-XXXX"
              maxLength={19}
              onKeyDown={e => { if (e.key === 'Enter') handleActivate(); }}
              spellCheck={false}
              autoComplete="off"
            />
            {inputErr && <div className="lg-input-err">{inputErr}</div>}
            <button
              className="lg-btn-activate"
              onClick={handleActivate}
              disabled={saving}
            >
              {saving
                ? <><RefreshCw size={13} className="lg-spin" /> Validating…</>
                : <><ShieldCheck size={13} /> Activate License <ChevronRight size={12} /></>
              }
            </button>
          </div>
        )}

        {/* Retry / clear controls */}
        <div className="lg-modal__footer">
          {status !== 'no_license' && (
            <button className="lg-btn-ghost" onClick={runValidation}>
              <RefreshCw size={11} /> Retry Validation
            </button>
          )}
          {localStorage.getItem(LICENSE_KEY_STORAGE) && (
            <button className="lg-btn-ghost lg-btn-ghost--danger" onClick={handleClear}>
              <X size={11} /> Clear Key
            </button>
          )}
          <span className="lg-modal__hint">
            Need a license? <span style={{ color: '#60a5fa' }}>aippietax.com/license</span>
          </span>
        </div>
      </div>
    </div>
  );
}
