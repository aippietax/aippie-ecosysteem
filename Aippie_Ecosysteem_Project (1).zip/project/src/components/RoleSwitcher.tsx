import { Globe, Headphones } from 'lucide-react';
import type { UserRole } from '../lib/supabase';

type Props = { role: UserRole; onChange: (r: UserRole) => void };

export default function RoleSwitcher({ role, onChange }: Props) {
  return (
    <div className="role-switcher">
      <button
        className={`role-tab${role === 'client' ? ' role-tab--active' : ''}`}
        onClick={() => onChange('client')}
      >
        <Globe size={14} />
        Client
      </button>
      <button
        className={`role-tab${role === 'translator' ? ' role-tab--active' : ''}`}
        onClick={() => onChange('translator')}
      >
        <Headphones size={14} />
        Interpreter
      </button>
    </div>
  );
}
