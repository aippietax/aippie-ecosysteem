import { useState, useRef, useEffect } from 'react';
import { TrendingUp, Shield, DollarSign, ChevronRight, AlertTriangle, CheckCircle, XCircle } from 'lucide-react';

interface Props {
  onNavigate?: (tab: string) => void;
}

const COUNTRIES = [
  { code: 'ES', label: 'Spain 🇪🇸' },
  { code: 'NL', label: 'Netherlands 🇳🇱' },
  { code: 'US', label: 'United States 🇺🇸' },
  { code: 'OTHER', label: 'Other' },
];

const COSTS = [
  { code: 'tax', label: 'Tax & Accounting', icon: '📊', tab: 'tax' },
  { code: 'health', label: 'Healthcare costs', icon: '🏥', tab: 'doctor' },
  { code: 'trading', label: 'Investment losses', icon: '📉', tab: 'alphatrade' },
  { code: 'privacy', label: 'Privacy & security', icon: '🔒', tab: 'securechat' },
];

interface ScoreResult {
  total: number;
  tax: { score: number; label: string; color: string };
  portfolio: { score: number; label: string; color: string };
  privacy: { score: number; label: string; color: string };
  tab: string;
  headline: string;
}

function computeScore(income: number, country: string, cost: string): ScoreResult {
  // Tax score — higher income + bad countries = lower score
  const taxBase = country === 'ES' ? 45 : country === 'NL' ? 52 : country === 'US' ? 37 : 40;
  const taxScore = Math.max(8, Math.min(95, 100 - (taxBase * 0.8) - (income > 5000 ? 12 : 0) - (income > 10000 ? 10 : 0)));

  // Portfolio score
  const portfolioScore = cost === 'trading'
    ? Math.max(10, 35 + Math.floor(Math.random() * 20))
    : cost === 'tax'
    ? Math.max(30, 55 + Math.floor(Math.random() * 20))
    : Math.max(20, 50 + Math.floor(Math.random() * 25));

  // Privacy score
  const privacyScore = cost === 'privacy'
    ? Math.max(5, 22 + Math.floor(Math.random() * 15))
    : Math.max(25, 48 + Math.floor(Math.random() * 30));

  const total = Math.round((taxScore * 0.4 + portfolioScore * 0.35 + privacyScore * 0.25));

  const grade = (s: number) => {
    if (s >= 75) return { label: 'GOOD', color: '#4ade80' };
    if (s >= 50) return { label: 'AVERAGE', color: '#fbbf24' };
    if (s >= 30) return { label: 'POOR', color: '#f97316' };
    return { label: 'CRITICAL', color: '#f87171' };
  };

  const tabMap: Record<string, string> = {
    tax: 'tax', health: 'doctor', trading: 'alphatrade', privacy: 'securechat',
  };

  const headlines: Record<string, string> = {
    tax: 'You are overpaying your taxes by an estimated 30–45%.',
    health: 'Your health costs are unprotected. Aippie Doctor can cut your consultation costs.',
    trading: 'Your portfolio is at risk. AI-managed strategies outperform manual trading by 3x.',
    privacy: 'Your digital footprint is exposed. Secure communication starts today.',
  };

  return {
    total,
    tax: { score: Math.round(taxScore), ...grade(taxScore) },
    portfolio: { score: Math.round(portfolioScore), ...grade(portfolioScore) },
    privacy: { score: Math.round(privacyScore), ...grade(privacyScore) },
    tab: tabMap[cost] ?? 'tax',
    headline: headlines[cost] ?? headlines.tax,
  };
}

function ScoreArc({ score }: { score: number }) {
  const r = 54;
  const circ = 2 * Math.PI * r;
  const dash = (score / 100) * circ * 0.75;
  const color = score >= 75 ? '#4ade80' : score >= 50 ? '#fbbf24' : score >= 30 ? '#f97316' : '#f87171';

  return (
    <svg width="140" height="100" viewBox="0 0 140 100" aria-hidden="true">
      <circle cx="70" cy="80" r={r} fill="none" stroke="rgba(255,255,255,0.07)" strokeWidth="10"
        strokeDasharray={`${circ * 0.75} ${circ}`} strokeDashoffset={circ * 0.125}
        strokeLinecap="round" style={{ transform: 'rotate(-90deg)', transformOrigin: '70px 80px' }} />
      <circle cx="70" cy="80" r={r} fill="none" stroke={color} strokeWidth="10"
        strokeDasharray={`${dash} ${circ}`} strokeDashoffset={circ * 0.125}
        strokeLinecap="round"
        style={{ transform: 'rotate(-90deg)', transformOrigin: '70px 80px', transition: 'stroke-dasharray 1.2s ease' }} />
      <text x="70" y="74" textAnchor="middle" fill="#fff" fontSize="28" fontWeight="700">{score}</text>
      <text x="70" y="90" textAnchor="middle" fill="rgba(255,255,255,0.4)" fontSize="10">/100</text>
    </svg>
  );
}

function MiniBar({ score, label, color }: { score: number; label: string; color: string }) {
  return (
    <div className="asw-bar-row">
      <span className="asw-bar-label">{label}</span>
      <div className="asw-bar-track">
        <div className="asw-bar-fill" style={{ width: `${score}%`, background: color }} />
      </div>
      <span className="asw-bar-grade" style={{ color }}>{score >= 75 ? 'GOOD' : score >= 50 ? 'AVG' : score >= 30 ? 'POOR' : 'CRITICAL'}</span>
    </div>
  );
}

export default function AippieScoreWidget({ onNavigate }: Props) {
  const [income, setIncome] = useState(3000);
  const [country, setCountry] = useState('ES');
  const [cost, setCost] = useState('tax');
  const [result, setResult] = useState<ScoreResult | null>(null);
  const [calculating, setCalculating] = useState(false);
  const resultRef = useRef<HTMLDivElement>(null);

  const handleCalculate = () => {
    setCalculating(true);
    setTimeout(() => {
      setResult(computeScore(income, country, cost));
      setCalculating(false);
    }, 1400);
  };

  useEffect(() => {
    if (result && resultRef.current) {
      resultRef.current.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }
  }, [result]);

  return (
    <div className="asw-root">
      <div className="asw-header">
        <span className="asw-header__badge">FREE TOOL</span>
        <h2 className="asw-header__title">What is your Aippie Score?</h2>
        <p className="asw-header__sub">3 questions · AI answer in 3 seconds · See where you lose money</p>
      </div>

      <div className="asw-fields">
        {/* Field 1 — Income */}
        <div className="asw-field">
          <label className="asw-field__label">
            <DollarSign size={13} /> Monthly income
          </label>
          <div className="asw-slider-wrap">
            <input
              type="range" min={500} max={20000} step={500}
              value={income}
              onChange={e => setIncome(+e.target.value)}
              className="asw-slider"
            />
            <span className="asw-slider-val">€ {income.toLocaleString()}</span>
          </div>
        </div>

        {/* Field 2 — Country */}
        <div className="asw-field">
          <label className="asw-field__label">
            <Shield size={13} /> Your country
          </label>
          <div className="asw-pills">
            {COUNTRIES.map(c => (
              <button
                key={c.code}
                className={`asw-pill${country === c.code ? ' asw-pill--active' : ''}`}
                onClick={() => setCountry(c.code)}
              >
                {c.label}
              </button>
            ))}
          </div>
        </div>

        {/* Field 3 — Biggest cost */}
        <div className="asw-field">
          <label className="asw-field__label">
            <TrendingUp size={13} /> Biggest concern
          </label>
          <div className="asw-pills">
            {COSTS.map(c => (
              <button
                key={c.code}
                className={`asw-pill${cost === c.code ? ' asw-pill--active' : ''}`}
                onClick={() => setCost(c.code)}
              >
                {c.icon} {c.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      <button
        className={`asw-calc-btn${calculating ? ' asw-calc-btn--loading' : ''}`}
        onClick={handleCalculate}
        disabled={calculating}
      >
        {calculating ? (
          <>
            <span className="asw-spinner" />
            Calculating your score...
          </>
        ) : (
          <>Calculate My Aippie Score <ChevronRight size={15} /></>
        )}
      </button>

      {result && (
        <div ref={resultRef} className="asw-result">
          <div className="asw-result__arc-wrap">
            <ScoreArc score={result.total} />
            <p className="asw-result__arc-label">
              {result.total >= 75 ? 'You are well protected' :
               result.total >= 50 ? 'Room for improvement' :
               result.total >= 30 ? 'You are losing money' :
               'Critical — act now'}
            </p>
          </div>

          <div className="asw-result__bars">
            <MiniBar score={result.tax.score} label="Tax efficiency" color={result.tax.color} />
            <MiniBar score={result.portfolio.score} label="Portfolio health" color={result.portfolio.color} />
            <MiniBar score={result.privacy.score} label="Privacy score" color={result.privacy.color} />
          </div>

          <div className={`asw-result__alert ${result.total < 50 ? 'asw-result__alert--warn' : 'asw-result__alert--ok'}`}>
            {result.total < 50 ? <AlertTriangle size={14} /> : <CheckCircle size={14} />}
            <span>{result.headline}</span>
          </div>

          <button
            className="asw-result__cta"
            onClick={() => onNavigate?.(result.tab)}
          >
            Fix this with Aippie — Start Free
            <ChevronRight size={14} />
          </button>
        </div>
      )}
    </div>
  );
}
