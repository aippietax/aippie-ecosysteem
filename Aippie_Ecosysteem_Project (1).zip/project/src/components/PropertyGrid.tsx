import { useState } from 'react';
import { Bed, Bath, Maximize2, MapPin, X, Calendar } from 'lucide-react';

export type Property = {
  id: string;
  title: string;
  description: string;
  location: string;
  address: string;
  price_eur: number;
  bedrooms: number;
  bathrooms: number;
  size_m2: number;
  property_type: string;
  photo_urls: string[];
  features: string[];
  is_featured: boolean;
};

type Props = {
  properties: Property[];
  onClose: () => void;
  query: string;
};

function formatPrice(n: number): string {
  if (n >= 1_000_000) return `€${(n / 1_000_000).toFixed(2).replace(/\.?0+$/, '')}M`;
  if (n >= 1_000)     return `€${Math.round(n / 1_000)}k`;
  return `€${n.toLocaleString()}`;
}

function typeLabel(t: string): string {
  const map: Record<string, string> = {
    villa: 'Villa', apartment: 'Apartment', penthouse: 'Penthouse',
    townhouse: 'Townhouse', finca: 'Finca',
  };
  return map[t] ?? t;
}

export default function PropertyGrid({ properties, onClose, query }: Props) {
  const [bookingId, setBookingId] = useState<string | null>(null);
  const [booked, setBooked]       = useState<Set<string>>(new Set());

  const handleBook = (id: string) => {
    setBookingId(id);
    setTimeout(() => {
      setBooked(prev => new Set(prev).add(id));
      setBookingId(null);
    }, 1400);
  };

  return (
    <div className="re-overlay">
      <div className="re-overlay__header">
        <div className="re-overlay__header-left">
          <div className="re-overlay__label">AippieRealEstate</div>
          <div className="re-overlay__query">"{query}"</div>
        </div>
        <button className="re-overlay__close" onClick={onClose} aria-label="Close">
          <X size={16} />
        </button>
      </div>

      <div className="re-overlay__meta">
        <span className="re-overlay__count">{properties.length} properties found</span>
        <span className="re-overlay__sub">Costa del Sol · AIPPIETAX S.A.</span>
      </div>

      <div className="re-grid">
        {properties.map(p => (
          <div key={p.id} className={`re-card${p.is_featured ? ' re-card--featured' : ''}`}>
            {p.is_featured && <div className="re-card__badge">Featured</div>}

            <div className="re-card__photo-wrap">
              <img
                src={p.photo_urls[0] ?? ''}
                alt={p.title}
                className="re-card__photo"
                loading="lazy"
              />
              <div className="re-card__photo-overlay" />
              <div className="re-card__price">{formatPrice(p.price_eur)}</div>
              <div className="re-card__type-pill">{typeLabel(p.property_type)}</div>
            </div>

            <div className="re-card__body">
              <div className="re-card__title">{p.title}</div>
              <div className="re-card__location">
                <MapPin size={10} />
                {p.location} · {p.address}
              </div>

              <div className="re-card__stats">
                <span><Bed size={11} /> {p.bedrooms} bed</span>
                <span><Bath size={11} /> {p.bathrooms} bath</span>
                <span><Maximize2 size={11} /> {p.size_m2} m²</span>
              </div>

              {p.features.length > 0 && (
                <div className="re-card__features">
                  {p.features.slice(0, 4).map(f => (
                    <span key={f} className="re-card__feature-tag">{f}</span>
                  ))}
                  {p.features.length > 4 && (
                    <span className="re-card__feature-tag re-card__feature-tag--more">
                      +{p.features.length - 4}
                    </span>
                  )}
                </div>
              )}

              <button
                className={`re-card__book-btn${booked.has(p.id) ? ' re-card__book-btn--done' : ''}`}
                onClick={() => handleBook(p.id)}
                disabled={bookingId === p.id || booked.has(p.id)}
              >
                {bookingId === p.id ? (
                  <span className="re-card__book-spinner" />
                ) : booked.has(p.id) ? (
                  'Viewing Requested!'
                ) : (
                  <>
                    <Calendar size={13} />
                    Book Viewing with Aippie
                  </>
                )}
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
