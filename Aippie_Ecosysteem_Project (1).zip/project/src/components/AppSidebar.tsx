import { useEffect, useRef } from 'react';
import {
  X, LayoutGrid, Radio, BrainCircuit, Building2, TrendingUp,
  Radar, Zap, Wallet, Lock, Video, MailOpen, Hand, Mic,
  Phone, MessageSquare, Stethoscope, ShieldCheck, HeartHandshake,
  Heart, GraduationCap, Code2, Home, Car, Wifi, Globe,
  Cpu, Scale, FolderLock, Glasses, Eye, Leaf, Crown,
} from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';

interface SidebarModule {
  tab: string;
  label: string;
  icon: React.ComponentType<{ size?: number; color?: string; strokeWidth?: number }>;
  color: string;
  badge?: string;
}

interface SidebarCategory {
  title: string;
  modules: SidebarModule[];
  activeColor: string;
}

const CATEGORIES: SidebarCategory[] = [
  {
    title: 'Dashboard',
    activeColor: '#60A5FA',
    modules: [
      { tab: 'unified',    label: 'Unified Dashboard',  icon: LayoutGrid,     color: '#60A5FA' },
      { tab: 'morning',    label: 'Morning Briefing',    icon: Radio,          color: '#60A5FA' },
      { tab: 'lifeassist', label: 'Life Assistant',      icon: BrainCircuit,   color: '#EC4899', badge: 'AI' },
      { tab: 'boardroom',  label: 'AI Boardroom',        icon: Crown,          color: '#FBBF24', badge: 'NEW' },
      { tab: 'aimanager',  label: 'AI Manager',          icon: BrainCircuit,   color: '#10B981', badge: 'NEW' },
    ],
  },
  {
    title: 'Finance & Trading',
    activeColor: '#22C55E',
    modules: [
      { tab: 'accounting',  label: 'AippieAccounts',    icon: Building2,   color: '#22C55E' },
      { tab: 'tax',         label: 'Tax Hub',           icon: Building2,   color: '#22C55E' },
      { tab: 'trading',     label: 'AI Trading',        icon: TrendingUp,  color: '#22C55E' },
      { tab: 'alphatrade',  label: 'Alpha Trade',       icon: TrendingUp,  color: '#22C55E' },
      { tab: 'signalradar', label: 'Signal Radar',      icon: Radar,       color: '#22C55E' },
      { tab: 'tournament',  label: 'AI Tournament',     icon: Zap,         color: '#22C55E' },
      { tab: 'wallet',      label: 'Digital Wallet',    icon: Wallet,      color: '#22C55E' },
      { tab: 'energy',      label: 'Aippie Energy',     icon: Leaf,        color: '#22C55E', badge: 'NEW' },
    ],
  },
  {
    title: 'Communication',
    activeColor: '#A855F7',
    modules: [
      { tab: 'securechat', label: 'Secure Chat',    icon: Lock,          color: '#A855F7' },
      { tab: 'videovault', label: 'Video Vault',    icon: Video,         color: '#A855F7' },
      { tab: 'aippiemail', label: 'Shield Mail',    icon: MailOpen,      color: '#A855F7' },
      { tab: 'silentvoice',label: 'Silent Voice',   icon: Hand,          color: '#A855F7' },
      { tab: 'voicenav',   label: 'Voice Nav',      icon: Mic,           color: '#A855F7' },
      { tab: 'voipscript', label: 'Call Script',    icon: Phone,         color: '#A855F7' },
      { tab: 'assistant',  label: 'AI Assistant',   icon: MessageSquare, color: '#A855F7' },
      { tab: 'voice',      label: 'Interpreter',    icon: Mic,           color: '#A855F7' },
    ],
  },
  {
    title: 'Health & Safety',
    activeColor: '#10B981',
    modules: [
      { tab: 'doctor',      label: 'AI Doctor',       icon: Stethoscope,    color: '#10B981' },
      { tab: 'safecheckin', label: 'Safe Check-In',   icon: ShieldCheck,    color: '#10B981' },
      { tab: 'cybersuit',   label: 'Cyber-Suit',      icon: ShieldCheck,    color: '#10B981' },
      { tab: 'companion',   label: 'AI Companion',    icon: HeartHandshake, color: '#10B981' },
      { tab: 'trust',       label: 'Digital Trust',   icon: ShieldCheck,    color: '#10B981' },
    ],
  },
  {
    title: 'Business & Legal',
    activeColor: '#60A5FA',
    modules: [
      { tab: 'b2b',       label: 'B2B Hub',        icon: Zap,           color: '#60A5FA' },
      { tab: 'legal',     label: 'Legal AI',       icon: Scale,         color: '#60A5FA' },
      { tab: 'reunion',   label: 'Reunion',        icon: Heart,         color: '#60A5FA' },
      { tab: 'academy',   label: 'AI Academy',     icon: GraduationCap, color: '#60A5FA' },
      { tab: 'aippiedev', label: 'Cloud Factory',  icon: Code2,         color: '#60A5FA' },
      { tab: 'powerpack', label: 'Commercial AI',  icon: Zap,           color: '#F59E0B', badge: 'NEW' },
      { tab: 'enterprise', label: 'Enterprise Setup', icon: Building2,    color: '#38bdf8', badge: 'NEW' },
    ],
  },
  {
    title: 'Real World',
    activeColor: '#60A5FA',
    modules: [
      { tab: 'realestate', label: 'Real Estate', icon: Home,  color: '#60A5FA' },
      { tab: 'parking',    label: 'Parking',     icon: Car,   color: '#60A5FA' },
      { tab: 'wifi',       label: 'WiFi Share',  icon: Wifi,  color: '#60A5FA' },
      { tab: 'world',      label: 'Open World',  icon: Globe, color: '#60A5FA' },
      { tab: 'robotics',   label: 'Robotics',    icon: Cpu,   color: '#60A5FA' },
    ],
  },
  {
    title: 'AI & Life',
    activeColor: '#EC4899',
    modules: [
      { tab: 'livestage',      label: 'Live Stage',      icon: Radio,    color: '#EC4899' },
      { tab: 'quantumcinema',  label: 'Chrono-Cinema',   icon: Glasses,  color: '#EC4899' },
      { tab: 'companionradar', label: 'Companion Radar', icon: Eye,      color: '#EC4899' },
    ],
  },
  {
    title: 'Documents & More',
    activeColor: '#60A5FA',
    modules: [
      { tab: 'docvault', label: 'Document Vault', icon: FolderLock, color: '#60A5FA' },
      { tab: 'wearable', label: 'Wearable',       icon: Glasses,    color: '#60A5FA' },
      { tab: 'pricing',  label: 'Pricing',        icon: Zap,        color: '#60A5FA' },
    ],
  },
];

interface Props {
  open: boolean;
  currentTab: string;
  onClose: () => void;
  onNavigate: (tab: string) => void;
}

export default function AppSidebar({ open, currentTab, onClose, onNavigate }: Props) {
  const { user } = useAuth();
  const overlayRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!open || !user) return;
    const handler = (e: KeyboardEvent) => { if (e.key === 'Escape') onClose(); };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, [open, onClose, user]);

  if (!user) return null;

  const total = CATEGORIES.reduce((sum, c) => sum + c.modules.length, 0);

  return (
    <>
      {/* Backdrop */}
      <div
        ref={overlayRef}
        onClick={onClose}
        style={{
          position: 'fixed', inset: 0, zIndex: 900,
          background: 'rgba(0,0,0,0.65)',
          backdropFilter: 'blur(2px)',
          opacity: open ? 1 : 0,
          pointerEvents: open ? 'auto' : 'none',
          transition: 'opacity 0.25s ease',
        }}
      />

      {/* Drawer */}
      <aside style={{
        position: 'fixed', top: 0, left: 0, bottom: 0,
        width: 'min(300px, 88vw)',
        zIndex: 901,
        background: '#0D1117',
        borderRight: '1px solid rgba(255,255,255,0.08)',
        display: 'flex', flexDirection: 'column',
        transform: open ? 'translateX(0)' : 'translateX(-100%)',
        transition: 'transform 0.28s cubic-bezier(.22,1,.36,1)',
        boxShadow: open ? '4px 0 48px rgba(0,0,0,0.8)' : 'none',
        overflowY: 'hidden',
      }}>

        {/* Header */}
        <div style={{
          display: 'flex', alignItems: 'center', justifyContent: 'space-between',
          padding: '14px 16px', flexShrink: 0,
          borderBottom: '1px solid rgba(255,255,255,0.08)',
          background: 'rgba(96,165,250,0.05)',
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <div style={{
              width: 8, height: 8, borderRadius: '50%', background: '#5DCAA5',
              boxShadow: '0 0 8px #5DCAA5',
              animation: 'sb-pulse 2s ease-in-out infinite',
            }} />
            <div>
              <div style={{ color: '#e2e8f0', fontSize: 13, fontWeight: 700, letterSpacing: '0.04em' }}>
                All Modules
              </div>
              <div style={{ color: '#60A5FA', fontSize: 13, fontWeight: 700, marginTop: 1, letterSpacing: '0.04em' }}>
                {total} MODULES
              </div>
            </div>
          </div>
          <button
            onClick={onClose}
            aria-label="Close menu"
            style={{
              width: 30, height: 30, borderRadius: '50%',
              background: 'rgba(255,255,255,0.05)',
              border: '1px solid rgba(255,255,255,0.1)',
              color: '#94a3b8', cursor: 'pointer',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
            }}
          >
            <X size={14} />
          </button>
        </div>

        {/* Scrollable module list */}
        <div style={{ overflowY: 'auto', flex: 1, padding: '8px 0 24px' }}>
          <style>{`
            @keyframes sb-pulse {
              0%,100% { opacity: 1; }
              50%      { opacity: 0.4; }
            }
            .sb-module-btn {
              display: flex;
              align-items: center;
              gap: 10px;
              width: 100%;
              padding: 8px 16px 8px 13px;
              border: none;
              border-left: 3px solid transparent;
              background: transparent;
              cursor: pointer;
              text-align: left;
              transition: background 0.15s ease, color 0.15s ease;
              box-sizing: border-box;
            }
            .sb-module-btn:hover {
              background: rgba(255,255,255,0.05);
            }
            .sb-module-btn:hover .sb-module-label {
              color: #ffffff !important;
            }
            .sb-module-btn:hover .sb-module-icon {
              color: #ffffff !important;
            }
          `}</style>

          {CATEGORIES.map((cat) => (
            <div key={cat.title} style={{ marginBottom: 6 }}>
              {/* Category header */}
              <div style={{
                padding: '12px 16px 5px',
                fontSize: 13,
                fontWeight: 700,
                letterSpacing: '0.08em',
                color: '#60A5FA',
                textTransform: 'uppercase',
              }}>
                {cat.title}
              </div>

              {/* Module buttons */}
              {cat.modules.map((mod) => {
                const Icon = mod.icon;
                const isActive = currentTab === mod.tab;
                const activeColor = cat.activeColor;
                return (
                  <button
                    key={mod.tab}
                    className="sb-module-btn"
                    style={isActive ? {
                      background: `rgba(${hexToRgb(activeColor)}, 0.12)`,
                      borderLeftColor: activeColor,
                    } : {}}
                    onClick={() => { onNavigate(mod.tab); onClose(); }}
                  >
                    {/* Icon badge */}
                    <div style={{
                      width: 30, height: 30, borderRadius: 8, flexShrink: 0,
                      background: isActive ? activeColor + '22' : 'rgba(255,255,255,0.04)',
                      border: `1px solid ${isActive ? activeColor + '55' : 'rgba(255,255,255,0.08)'}`,
                      display: 'flex', alignItems: 'center', justifyContent: 'center',
                      transition: 'background 0.15s, border-color 0.15s',
                    }}>
                      <Icon
                        size={18}
                        color={isActive ? activeColor : '#94A3B8'}
                        strokeWidth={1.8}
                      />
                    </div>

                    {/* Label */}
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <div
                        className="sb-module-label"
                        style={{
                          fontSize: 14,
                          fontWeight: isActive ? 700 : 500,
                          color: isActive ? activeColor : '#94A3B8',
                          letterSpacing: '0.01em',
                          whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis',
                          transition: 'color 0.15s',
                        }}
                      >
                        {mod.label}
                      </div>
                    </div>

                    {/* Active dot / badge */}
                    {isActive && (
                      <div style={{
                        width: 6, height: 6, borderRadius: '50%',
                        background: activeColor,
                        boxShadow: `0 0 6px ${activeColor}`,
                        flexShrink: 0,
                      }} />
                    )}
                    {mod.badge && !isActive && (
                      <span style={{
                        fontSize: 9, fontWeight: 700, color: '#EC4899',
                        background: 'rgba(236,72,153,0.12)',
                        border: '1px solid rgba(236,72,153,0.3)',
                        borderRadius: 8, padding: '1px 5px',
                        letterSpacing: '0.04em', flexShrink: 0,
                      }}>
                        {mod.badge}
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          ))}
        </div>

        {/* Footer */}
        <div style={{
          padding: '10px 16px', flexShrink: 0,
          borderTop: '1px solid rgba(255,255,255,0.06)',
          fontSize: 12, color: '#64748B',
          letterSpacing: '0.05em', textAlign: 'center',
          lineHeight: 1.5,
        }}>
          AIPPIETAX S.A. · NIF A22944987 · Mijas, Malaga
        </div>
      </aside>
    </>
  );
}

function hexToRgb(hex: string): string {
  const r = parseInt(hex.slice(1, 3), 16);
  const g = parseInt(hex.slice(3, 5), 16);
  const b = parseInt(hex.slice(5, 7), 16);
  return `${r},${g},${b}`;
}
