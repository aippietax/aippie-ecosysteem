import { useEffect, useRef, useState, useCallback } from 'react';
import {
  Wallet, CreditCard, Send, ArrowDownCircle, RefreshCw,
  Copy, Check, Eye, EyeOff, ArrowUpRight, ArrowDownLeft,
  Landmark, ShieldCheck, Smartphone, Clock, QrCode,
  ChevronRight, User, PhoneIncoming, X, Lock, AlertCircle, Building2,
} from 'lucide-react';
import { supabase } from '../lib/supabase';
import type { User as AuthUser } from '@supabase/supabase-js';

const PAYPAL_CLIENT_ID = import.meta.env.VITE_PAYPAL_CLIENT_ID as string | undefined;

const BANK_IBAN   = import.meta.env.VITE_BANK_IBAN   as string | undefined;
const BANK_NAME   = (import.meta.env.VITE_BANK_NAME   as string | undefined) ?? 'Sabadell';
const BANK_BIC    = (import.meta.env.VITE_BANK_BIC    as string | undefined) ?? 'BSABESBB';
const BANK_HOLDER = (import.meta.env.VITE_BANK_HOLDER as string | undefined) ?? 'AIPPIETAX S.A.';

// ── Load PayPal SDK once ──────────────────────────────────────────────────────
function loadPayPalScript(clientId: string): Promise<void> {
  return new Promise((resolve, reject) => {
    if (document.getElementById('paypal-sdk')) { resolve(); return; }
    const script = document.createElement('script');
    script.id = 'paypal-sdk';
    script.src = `https://www.paypal.com/sdk/js?client-id=${clientId}&currency=EUR&intent=capture`;
    script.onload = () => resolve();
    script.onerror = () => reject(new Error('PayPal SDK failed to load'));
    document.body.appendChild(script);
  });
}

// ── PayPal Button component ───────────────────────────────────────────────────
function PayPalButton({ amount, onSuccess, onError }: {
  amount: number;
  onSuccess: (orderId: string) => void;
  onError: (msg: string) => void;
}) {
  const containerRef = useRef<HTMLDivElement>(null);
  const renderedRef  = useRef(false);

  useEffect(() => {
    if (!PAYPAL_CLIENT_ID || PAYPAL_CLIENT_ID === 'YOUR_PAYPAL_CLIENT_ID_HERE') return;
    if (renderedRef.current) return;

    loadPayPalScript(PAYPAL_CLIENT_ID).then(() => {
      const paypal = (window as unknown as { paypal?: { Buttons: (opts: unknown) => { render: (el: HTMLElement) => void } } }).paypal;
      if (!paypal || !containerRef.current) return;
      renderedRef.current = true;
      containerRef.current.innerHTML = '';
      paypal.Buttons({
        style: { layout: 'vertical', color: 'gold', shape: 'rect', label: 'pay', height: 44 },
        createOrder: (_data: unknown, actions: { order: { create: (o: unknown) => Promise<string> } }) => {
          return actions.order.create({
            intent: 'CAPTURE',
            purchase_units: [{
              amount: { currency_code: 'EUR', value: amount.toFixed(2) },
              description: 'Aippie Pay wallet top-up',
            }],
          });
        },
        onApprove: (_data: unknown, actions: { order: { capture: () => Promise<{ id: string }> } }) => {
          return actions.order.capture().then((details) => {
            onSuccess(details.id);
          });
        },
        onError: () => onError('PayPal payment failed. Please try again.'),
        onCancel: () => onError('Payment cancelled.'),
      }).render(containerRef.current!);
    }).catch(() => onError('Could not load PayPal. Check your internet connection.'));
  }, [amount, onSuccess, onError]);

  if (!PAYPAL_CLIENT_ID || PAYPAL_CLIENT_ID === 'YOUR_PAYPAL_CLIENT_ID_HERE') {
    return (
      <div className="dw-paypal-unconfigured">
        <AlertCircle size={15} />
        <span>PayPal not yet configured — add your Client ID to .env (VITE_PAYPAL_CLIENT_ID)</span>
      </div>
    );
  }

  return <div ref={containerRef} className="dw-paypal-btn-wrap" />;
}

// ── Types ─────────────────────────────────────────────────────────────────────
interface ApcWallet {
  id: string;
  user_id: string;
  balance_apc: number;
  created_at: string;
  updated_at: string;
}

interface ApcVirtualCard {
  id: string;
  wallet_id: string;
  card_number: string;
  expiry_month: number;
  expiry_year: number;
  card_display_cvc: string;
  status: 'active' | 'frozen' | 'cancelled';
}

interface ApcTransaction {
  id: string;
  type: 'deposit' | 'transfer_out' | 'transfer_in' | 'fee_debit' | 'fee_credit';
  amount_apc: number;
  fee_apc: number;
  counterpart_phone: string | null;
  reference: string;
  status: string;
  created_at: string;
}

type ActivePanel = 'overview' | 'deposit' | 'send' | 'request' | 'card';

const QUICK_AMOUNTS = [5, 10, 20, 50, 100, 200];

// Simulated contacts (in real app these would come from user's contacts)
const RECENT_CONTACTS = [
  { name: 'Amara K.',  phone: '+27 71 000 0001', initial: 'A' },
  { name: 'Kofi B.',   phone: '+233 24 000 0002', initial: 'K' },
  { name: 'Fatima M.', phone: '+212 61 000 0003', initial: 'F' },
  { name: 'Chidi O.',  phone: '+234 80 000 0004', initial: 'C' },
];

// ── Helpers ───────────────────────────────────────────────────────────────────
function formatAPC(n: number): string {
  return new Intl.NumberFormat('en-EU', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(n);
}

function maskCard(num: string): string {
  return num.replace(/(\d{4})(\d{4})(\d{4})(\d{4})/, '$1 $2 $3 $4');
}

function fmtExpiry(month: number, year: number): string {
  return `${String(month).padStart(2, '0')}/${String(year).slice(-2)}`;
}

function txIcon(type: ApcTransaction['type']) {
  switch (type) {
    case 'deposit':      return <ArrowDownLeft  size={16} className="text-emerald-400" />;
    case 'transfer_in':  return <ArrowDownLeft  size={16} className="text-emerald-400" />;
    case 'transfer_out': return <ArrowUpRight   size={16} className="text-rose-400"    />;
    default:             return <Landmark       size={16} className="text-amber-400"   />;
  }
}

function txColor(type: ApcTransaction['type']): string {
  return type === 'deposit' || type === 'transfer_in' ? 'text-emerald-400' : 'text-rose-400';
}

function txSign(type: ApcTransaction['type']): string {
  return type === 'deposit' || type === 'transfer_in' ? '+' : '-';
}

function Shimmer({ className }: { className?: string }) {
  return <div className={`animate-pulse rounded bg-white/10 ${className ?? ''}`} />;
}

// ── PIN Pad ───────────────────────────────────────────────────────────────────
function PinPad({ onConfirm, onCancel, title, subtitle }: {
  onConfirm: (pin: string) => void;
  onCancel: () => void;
  title: string;
  subtitle: string;
}) {
  const [pin, setPin] = useState('');

  const press = (digit: string) => {
    if (pin.length >= 4) return;
    const next = pin + digit;
    setPin(next);
    if (next.length === 4) setTimeout(() => onConfirm(next), 200);
  };

  const del = () => setPin(p => p.slice(0, -1));

  return (
    <div className="dw-pin-overlay">
      <div className="dw-pin-modal">
        <button className="dw-pin-close" onClick={onCancel}><X size={16} /></button>
        <Lock size={28} className="dw-pin-icon" />
        <h3 className="dw-pin-title">{title}</h3>
        <p className="dw-pin-sub">{subtitle}</p>

        {/* Dots */}
        <div className="dw-pin-dots">
          {[0,1,2,3].map(i => (
            <div key={i} className={`dw-pin-dot${i < pin.length ? ' dw-pin-dot--filled' : ''}`} />
          ))}
        </div>

        {/* Keypad */}
        <div className="dw-pin-grid">
          {['1','2','3','4','5','6','7','8','9','*','0','⌫'].map(k => (
            <button
              key={k}
              className={`dw-pin-key${k === '*' ? ' dw-pin-key--empty' : ''}`}
              onClick={() => k === '⌫' ? del() : k !== '*' ? press(k) : undefined}
              disabled={k === '*'}
            >
              {k === '⌫' ? '⌫' : k === '*' ? '' : k}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}

// ── Virtual Card ──────────────────────────────────────────────────────────────
function VirtualCardDisplay({ card }: { card: ApcVirtualCard | null }) {
  const [cvcVisible, setCvcVisible]   = useState(false);
  const [cardVisible, setCardVisible] = useState(false);
  const [copied, setCopied]           = useState<string | null>(null);

  const copy = (text: string, key: string) => {
    navigator.clipboard.writeText(text).then(() => {
      setCopied(key);
      setTimeout(() => setCopied(null), 1800);
    });
  };

  if (!card) {
    return (
      <div className="dw-card-wrap">
        <div className="dw-card dw-card--skeleton">
          <Shimmer className="h-4 w-32 mb-6" />
          <Shimmer className="h-6 w-48 mb-4" />
          <div className="flex gap-4">
            <Shimmer className="h-4 w-20" />
            <Shimmer className="h-4 w-12" />
          </div>
        </div>
      </div>
    );
  }

  const displayNumber = cardVisible
    ? maskCard(card.card_number)
    : `•••• •••• •••• ${card.card_number.slice(-4)}`;

  return (
    <div className="dw-card-wrap">
      <div className={`dw-card${card.status === 'frozen' ? ' dw-card--frozen' : ''}`}>
        <div className="dw-card__header">
          <div className="dw-card__logo">
            <span className="dw-card__logo-text">AIPPIE</span>
            <span className="dw-card__logo-sub">PAY</span>
          </div>
          <div className="dw-card__chip" />
        </div>
        <div className="dw-card__number-row">
          <span className="dw-card__number">{displayNumber}</span>
          <button className="dw-card__icon-btn" onClick={() => setCardVisible(v => !v)}>
            {cardVisible ? <EyeOff size={14} /> : <Eye size={14} />}
          </button>
          <button className="dw-card__icon-btn" onClick={() => copy(card.card_number, 'num')}>
            {copied === 'num' ? <Check size={14} className="text-emerald-400" /> : <Copy size={14} />}
          </button>
        </div>
        <div className="dw-card__footer">
          <div className="dw-card__field">
            <span className="dw-card__field-label">EXPIRES</span>
            <span className="dw-card__field-value">{fmtExpiry(card.expiry_month, card.expiry_year)}</span>
          </div>
          <div className="dw-card__field">
            <span className="dw-card__field-label">CVC</span>
            <span className="dw-card__field-value">{cvcVisible ? card.card_display_cvc : '•••'}</span>
            <button className="dw-card__icon-btn ml-1" onClick={() => setCvcVisible(v => !v)}>
              {cvcVisible ? <EyeOff size={12} /> : <Eye size={12} />}
            </button>
          </div>
          <div className="dw-card__field dw-card__field--right">
            <span className={`dw-card__badge${card.status === 'active' ? ' dw-card__badge--active' : ' dw-card__badge--frozen'}`}>
              {card.status.toUpperCase()}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}

// ── Transaction row ───────────────────────────────────────────────────────────
function TxRow({ tx }: { tx: ApcTransaction }) {
  const date    = new Date(tx.created_at);
  const dateStr = date.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: '2-digit' });
  const timeStr = date.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' });

  return (
    <div className="dw-tx-row">
      <div className="dw-tx-row__icon">{txIcon(tx.type)}</div>
      <div className="dw-tx-row__body">
        <p className="dw-tx-row__ref">{tx.reference}</p>
        <p className="dw-tx-row__meta">
          {tx.counterpart_phone && <span className="dw-tx-row__phone">{tx.counterpart_phone} · </span>}
          {dateStr} · {timeStr}
          {tx.fee_apc > 0 && <span className="dw-tx-row__fee"> · fee {formatAPC(tx.fee_apc)}</span>}
        </p>
      </div>
      <span className={`dw-tx-row__amount ${txColor(tx.type)}`}>
        {txSign(tx.type)}{formatAPC(Math.abs(tx.amount_apc))} APC
      </span>
    </div>
  );
}

// ── Bank field with copy ──────────────────────────────────────────────────────
function BankField({ label, value, copyKey, noCopy }: {
  label: string; value: string; copyKey: string; noCopy?: boolean;
}) {
  const [copied, setCopied] = useState(false);
  const copy = () => {
    navigator.clipboard.writeText(value).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 1800);
    });
  };
  return (
    <div className="dw-bank-field">
      <span className="dw-bank-field__label">{label}</span>
      <div className="dw-bank-field__row">
        <span className="dw-bank-field__value">{value}</span>
        {!noCopy && (
          <button className="dw-bank-field__copy" onClick={copy} aria-label={`Copy ${label}`}>
            {copied ? <Check size={13} className="text-emerald-400" /> : <Copy size={13} />}
          </button>
        )}
      </div>
    </div>
  );
}

// ── Main component ────────────────────────────────────────────────────────────
export default function DigitalWalletView({ user }: { user: AuthUser | null }) {
  const [wallet, setWallet]         = useState<ApcWallet | null>(null);
  const [card, setCard]             = useState<ApcVirtualCard | null>(null);
  const [txs, setTxs]               = useState<ApcTransaction[]>([]);
  const [loading, setLoading]       = useState(true);
  const [panel, setPanel]           = useState<ActivePanel>('overview');
  const [busy, setBusy]             = useState(false);
  const [feedback, setFeedback]     = useState<{ ok: boolean; msg: string } | null>(null);
  const [showPin, setShowPin]       = useState(false);
  const [pendingAction, setPendingAction] = useState<'deposit' | 'send' | 'request' | null>(null);

  // Deposit form
  const [depositAmt, setDepositAmt]         = useState('');
  const [depositMethod, setDepositMethod]   = useState<'paypal' | 'bank'>('paypal');

  // Send form
  const [sendPhone, setSendPhone]   = useState('');
  const [sendAmt, setSendAmt]       = useState('');
  const [sendNote, setSendNote]     = useState('');

  // Request form
  const [reqPhone, setReqPhone]     = useState('');
  const [reqAmt, setReqAmt]         = useState('');

  const mountedRef = useRef(true);

  const load = useCallback(async () => {
    if (!user) { setLoading(false); return; }
    setLoading(true);
    const { error: ensureErr } = await supabase.rpc('apc_ensure_wallet');
    if (ensureErr) console.warn('ensure_wallet:', ensureErr.message);

    const [walletRes, cardRes, txRes] = await Promise.all([
      supabase.from('apc_wallets').select('*').eq('user_id', user.id).maybeSingle(),
      supabase.from('apc_virtual_cards').select('*').eq('user_id', user.id).eq('status', 'active').maybeSingle(),
      supabase.from('apc_transactions').select('*').eq('user_id', user.id)
        .order('created_at', { ascending: false }).limit(50),
    ]);

    if (!mountedRef.current) return;
    if (walletRes.data) setWallet(walletRes.data as ApcWallet);
    if (cardRes.data)   setCard(cardRes.data as ApcVirtualCard);
    setTxs((txRes.data ?? []) as ApcTransaction[]);
    setLoading(false);
  }, [user]);

  useEffect(() => {
    mountedRef.current = true;
    load();
    return () => { mountedRef.current = false; };
  }, [load]);

  const flash = (ok: boolean, msg: string) => {
    setFeedback({ ok, msg });
    setTimeout(() => { if (mountedRef.current) setFeedback(null); }, 5000);
  };

  // ── Initiate actions (show PIN first) ──────────────────────────────────────
  // Deposit goes through PayPal — no PIN needed here (PayPal IS the auth)
  const initDeposit = () => {
    const amt = parseFloat(depositAmt);
    if (!amt || amt <= 0) { flash(false, 'Enter a valid amount'); return; }
    // PayPal button handles the rest — button is shown below when amount > 0
  };

  // Called by PayPal SDK on successful payment capture
  const handlePayPalSuccess = useCallback(async (_orderId: string) => {
    const amt = parseFloat(depositAmt);
    if (!amt || amt <= 0) { flash(false, 'Invalid amount'); return; }
    setBusy(true);
    const { data, error } = await supabase.rpc('apc_deposit', { p_amount: amt });
    setBusy(false);
    if (error || !data?.ok) { flash(false, error?.message ?? data?.error ?? 'Credit failed after PayPal payment. Contact support.'); return; }
    flash(true, `Top-up successful! ${formatAPC(data.deposited)} APC added to your wallet`);
    setDepositAmt('');
    setPanel('overview');
    load();
  }, [depositAmt, load]);

  const handlePayPalError = useCallback((msg: string) => {
    flash(false, msg);
  }, []);

  const initSend = () => {
    const amt = parseFloat(sendAmt);
    if (!sendPhone.trim()) { flash(false, 'Enter recipient phone number'); return; }
    if (!amt || amt <= 0)  { flash(false, 'Enter a valid amount'); return; }
    if (amt > (wallet?.balance_apc ?? 0)) { flash(false, 'Insufficient balance'); return; }
    setPendingAction('send');
    setShowPin(true);
  };

  const initRequest = () => {
    const amt = parseFloat(reqAmt);
    if (!reqPhone.trim()) { flash(false, 'Enter phone number'); return; }
    if (!amt || amt <= 0)  { flash(false, 'Enter amount to request'); return; }
    setPendingAction('request');
    setShowPin(true);
  };

  // ── PIN confirmed — execute ────────────────────────────────────────────────
  const handlePinConfirmed = async (_pin: string) => {
    setShowPin(false);
    if (pendingAction === 'send') await executeSend();
    else if (pendingAction === 'request') executeRequest();
    setPendingAction(null);
  };

  const executeSend = async () => {
    setBusy(true);
    const { data, error } = await supabase.rpc('apc_transfer', {
      p_to_phone: sendPhone.trim(),
      p_amount:   parseFloat(sendAmt),
    });
    setBusy(false);
    if (error || !data?.ok) { flash(false, error?.message ?? data?.error ?? 'Transfer failed'); return; }
    flash(true, `Sent ${formatAPC(data.sent)} APC to ${data.to_phone}`);
    setSendPhone('');
    setSendAmt('');
    setSendNote('');
    setPanel('overview');
    load();
  };

  const executeRequest = () => {
    // In production this would send an SMS/notification to reqPhone
    flash(true, `Payment request of ${formatAPC(parseFloat(reqAmt))} APC sent to ${reqPhone}`);
    setReqPhone('');
    setReqAmt('');
    setPanel('overview');
  };

  const depositFee = depositAmt ? parseFloat(depositAmt) * 0.07 : 0;
  const depositNet = depositAmt ? parseFloat(depositAmt) - depositFee : 0;
  const sendFee    = sendAmt    ? parseFloat(sendAmt) * 0.01 : 0;
  const sendTotal  = sendAmt    ? parseFloat(sendAmt) + sendFee : 0;
  const balance    = wallet?.balance_apc ?? 0;

  if (!user) {
    return (
      <div className="dw-root dw-root--empty">
        <ShieldCheck size={40} className="dw-empty__icon" />
        <p className="dw-empty__text">Sign in to access your Digital Wallet</p>
      </div>
    );
  }

  return (
    <div className="dw-root">
      {/* PIN overlay */}
      {showPin && (
        <PinPad
          title="Confirm with PIN"
          subtitle={
            pendingAction === 'deposit' ? `Deposit ${depositAmt} APC` :
            pendingAction === 'send'    ? `Send ${sendAmt} APC to ${sendPhone}` :
            `Request ${reqAmt} APC from ${reqPhone}`
          }
          onConfirm={handlePinConfirmed}
          onCancel={() => { setShowPin(false); setPendingAction(null); }}
        />
      )}

      {/* Header */}
      <div className="dw-header">
        <div className="dw-header__left">
          <Wallet size={20} className="dw-header__icon" />
          <div>
            <h1 className="dw-header__title">Aippie Pay</h1>
            <p className="dw-header__sub">Mobile Money · 1 APC = 1 EUR</p>
          </div>
        </div>
        <button className="dw-refresh-btn" onClick={load} aria-label="Refresh">
          <RefreshCw size={15} className={loading ? 'animate-spin' : ''} />
        </button>
      </div>

      {/* Feedback */}
      {feedback && (
        <div className={`dw-feedback${feedback.ok ? ' dw-feedback--ok' : ' dw-feedback--err'}`}>
          {feedback.ok ? <Check size={15} /> : <ShieldCheck size={15} />}
          {feedback.msg}
        </div>
      )}

      {/* Balance hero */}
      <div className="dw-balance-hero">
        <div className="dw-balance-hero__glow" />
        <p className="dw-balance-hero__label">My Balance</p>
        {loading ? (
          <Shimmer className="h-12 w-48 mx-auto my-2" />
        ) : (
          <p className="dw-balance-hero__amount">
            {formatAPC(balance)}
            <span className="dw-balance-hero__currency"> APC</span>
          </p>
        )}
        <p className="dw-balance-hero__equiv">≈ €{formatAPC(balance)} EUR</p>

        {/* M-Pesa style action grid */}
        <div className="dw-mpesa-grid">
          <button
            className={`dw-mpesa-btn${panel === 'send' ? ' dw-mpesa-btn--active' : ''}`}
            onClick={() => setPanel(p => p === 'send' ? 'overview' : 'send')}
          >
            <div className="dw-mpesa-btn__icon"><Send size={20} /></div>
            <span>Send</span>
          </button>
          <button
            className={`dw-mpesa-btn${panel === 'request' ? ' dw-mpesa-btn--active' : ''}`}
            onClick={() => setPanel(p => p === 'request' ? 'overview' : 'request')}
          >
            <div className="dw-mpesa-btn__icon"><PhoneIncoming size={20} /></div>
            <span>Request</span>
          </button>
          <button
            className={`dw-mpesa-btn${panel === 'deposit' ? ' dw-mpesa-btn--active' : ''}`}
            onClick={() => setPanel(p => p === 'deposit' ? 'overview' : 'deposit')}
          >
            <div className="dw-mpesa-btn__icon"><ArrowDownCircle size={20} /></div>
            <span>Top Up</span>
          </button>
          <button
            className={`dw-mpesa-btn${panel === 'card' ? ' dw-mpesa-btn--active' : ''}`}
            onClick={() => setPanel(p => p === 'card' ? 'overview' : 'card')}
          >
            <div className="dw-mpesa-btn__icon"><CreditCard size={20} /></div>
            <span>Card</span>
          </button>
        </div>
      </div>

      {/* ── Send Money panel ──────────────────────────────────────────────────── */}
      {panel === 'send' && (
        <div className="dw-panel dw-panel--send">
          <div className="dw-panel__header">
            <Send size={18} className="text-sky-400" />
            <h2 className="dw-panel__title">Send Money</h2>
            <button className="dw-panel__close" onClick={() => setPanel('overview')}><X size={16} /></button>
          </div>

          {/* Recent contacts */}
          <div className="dw-contacts">
            <p className="dw-contacts__label">Recent</p>
            <div className="dw-contacts__row">
              {RECENT_CONTACTS.map(c => (
                <button
                  key={c.phone}
                  className="dw-contact-btn"
                  onClick={() => setSendPhone(c.phone)}
                >
                  <div className={`dw-contact-btn__avatar${sendPhone === c.phone ? ' dw-contact-btn__avatar--active' : ''}`}>
                    {c.initial}
                  </div>
                  <span className="dw-contact-btn__name">{c.name.split(' ')[0]}</span>
                </button>
              ))}
              <button className="dw-contact-btn">
                <div className="dw-contact-btn__avatar dw-contact-btn__avatar--new">
                  <QrCode size={14} />
                </div>
                <span className="dw-contact-btn__name">Scan</span>
              </button>
            </div>
          </div>

          <label className="dw-label">Phone Number</label>
          <div className="dw-input-wrap">
            <Smartphone size={15} className="dw-input-prefix-icon" />
            <input
              type="tel"
              className="dw-input dw-input--icon"
              placeholder="+27 71 000 0000"
              value={sendPhone}
              onChange={e => setSendPhone(e.target.value)}
            />
          </div>

          <label className="dw-label" style={{ marginTop: 12 }}>Amount (APC)</label>
          {/* Quick amounts */}
          <div className="dw-quick-amounts">
            {QUICK_AMOUNTS.map(a => (
              <button
                key={a}
                className={`dw-quick-amt${sendAmt === String(a) ? ' dw-quick-amt--active' : ''}`}
                onClick={() => setSendAmt(String(a))}
              >
                {a}
              </button>
            ))}
          </div>
          <div className="dw-input-wrap" style={{ marginTop: 6 }}>
            <span className="dw-input-prefix">APC</span>
            <input
              type="number"
              className="dw-input"
              placeholder="0.00"
              min="0.01"
              step="0.01"
              value={sendAmt}
              onChange={e => setSendAmt(e.target.value)}
            />
          </div>

          <label className="dw-label" style={{ marginTop: 12 }}>Note (optional)</label>
          <div className="dw-input-wrap">
            <input
              type="text"
              className="dw-input"
              placeholder="Reason for sending…"
              value={sendNote}
              onChange={e => setSendNote(e.target.value)}
              style={{ paddingLeft: 12 }}
            />
          </div>

          {sendAmt && parseFloat(sendAmt) > 0 && (
            <div className="dw-fee-breakdown">
              <div className="dw-fee-row">
                <span>You send</span>
                <span>{parseFloat(sendAmt).toFixed(2)} APC</span>
              </div>
              <div className="dw-fee-row dw-fee-row--fee">
                <span>Fee (1%)</span>
                <span>−{sendFee.toFixed(4)} APC</span>
              </div>
              <div className="dw-fee-row dw-fee-row--net">
                <span>Recipient receives</span>
                <span className="text-emerald-400">{parseFloat(sendAmt).toFixed(2)} APC</span>
              </div>
              <div className="dw-fee-row">
                <span>Total from wallet</span>
                <span className="text-sky-300">{sendTotal.toFixed(4)} APC</span>
              </div>
            </div>
          )}

          <button
            className="dw-action-btn dw-action-btn--send"
            onClick={initSend}
            disabled={busy || !sendPhone || !sendAmt}
          >
            {busy ? <RefreshCw size={15} className="animate-spin" /> : <Send size={15} />}
            {busy ? 'Sending…' : 'Send Now'}
          </button>
        </div>
      )}

      {/* ── Request Money panel ───────────────────────────────────────────────── */}
      {panel === 'request' && (
        <div className="dw-panel dw-panel--request">
          <div className="dw-panel__header">
            <PhoneIncoming size={18} className="text-violet-400" />
            <h2 className="dw-panel__title">Request Money</h2>
            <button className="dw-panel__close" onClick={() => setPanel('overview')}><X size={16} /></button>
          </div>
          <p className="dw-panel__sub">Request a payment from any Aippie Pay user by phone number.</p>

          <div className="dw-contacts">
            <p className="dw-contacts__label">Recent</p>
            <div className="dw-contacts__row">
              {RECENT_CONTACTS.map(c => (
                <button
                  key={c.phone}
                  className="dw-contact-btn"
                  onClick={() => setReqPhone(c.phone)}
                >
                  <div className={`dw-contact-btn__avatar${reqPhone === c.phone ? ' dw-contact-btn__avatar--active' : ''}`}>
                    {c.initial}
                  </div>
                  <span className="dw-contact-btn__name">{c.name.split(' ')[0]}</span>
                </button>
              ))}
            </div>
          </div>

          <label className="dw-label">From Phone Number</label>
          <div className="dw-input-wrap">
            <User size={15} className="dw-input-prefix-icon" />
            <input
              type="tel"
              className="dw-input dw-input--icon"
              placeholder="+27 71 000 0000"
              value={reqPhone}
              onChange={e => setReqPhone(e.target.value)}
            />
          </div>

          <label className="dw-label" style={{ marginTop: 12 }}>Amount to Request (APC)</label>
          <div className="dw-quick-amounts">
            {QUICK_AMOUNTS.map(a => (
              <button
                key={a}
                className={`dw-quick-amt${reqAmt === String(a) ? ' dw-quick-amt--active' : ''}`}
                onClick={() => setReqAmt(String(a))}
              >
                {a}
              </button>
            ))}
          </div>
          <div className="dw-input-wrap" style={{ marginTop: 6 }}>
            <span className="dw-input-prefix">APC</span>
            <input
              type="number"
              className="dw-input"
              placeholder="0.00"
              min="0.01"
              step="0.01"
              value={reqAmt}
              onChange={e => setReqAmt(e.target.value)}
            />
          </div>

          <button
            className="dw-action-btn dw-action-btn--request"
            onClick={initRequest}
            disabled={busy || !reqPhone || !reqAmt}
          >
            <PhoneIncoming size={15} />
            Send Request
          </button>
        </div>
      )}

      {/* ── Top Up / Deposit panel ───────────────────────────────────────────── */}
      {panel === 'deposit' && (
        <div className="dw-panel dw-panel--deposit">
          <div className="dw-panel__header">
            <ArrowDownCircle size={18} className="text-emerald-400" />
            <h2 className="dw-panel__title">Top Up Wallet</h2>
            <button className="dw-panel__close" onClick={() => setPanel('overview')}><X size={16} /></button>
          </div>

          {/* Payment method tabs */}
          <div className="dw-deposit-tabs">
            <button
              className={`dw-deposit-tab${depositMethod === 'paypal' ? ' dw-deposit-tab--active' : ''}`}
              onClick={() => setDepositMethod('paypal')}
            >
              <span className="dw-deposit-tab__pp">Pay</span>Pal
            </button>
            <button
              className={`dw-deposit-tab${depositMethod === 'bank' ? ' dw-deposit-tab--active' : ''}`}
              onClick={() => setDepositMethod('bank')}
            >
              <Building2 size={13} />
              Bank Transfer
            </button>
          </div>

          {/* ── PayPal method ─────────────────────────────────── */}
          {depositMethod === 'paypal' && (
            <>
              <p className="dw-panel__sub">Pay securely via PayPal. A 7% processing fee applies.</p>
              <label className="dw-label">Amount (EUR)</label>
              <div className="dw-quick-amounts">
                {QUICK_AMOUNTS.map(a => (
                  <button
                    key={a}
                    className={`dw-quick-amt${depositAmt === String(a) ? ' dw-quick-amt--active' : ''}`}
                    onClick={() => setDepositAmt(String(a))}
                  >
                    €{a}
                  </button>
                ))}
              </div>
              <div className="dw-input-wrap" style={{ marginTop: 6 }}>
                <span className="dw-input-prefix">€</span>
                <input
                  type="number"
                  className="dw-input"
                  placeholder="0.00"
                  min="0.01"
                  step="0.01"
                  value={depositAmt}
                  onChange={e => setDepositAmt(e.target.value)}
                />
              </div>

              {depositAmt && parseFloat(depositAmt) > 0 && (
                <>
                  <div className="dw-fee-breakdown">
                    <div className="dw-fee-row">
                      <span>You pay via PayPal</span>
                      <span>€{parseFloat(depositAmt).toFixed(2)}</span>
                    </div>
                    <div className="dw-fee-row dw-fee-row--fee">
                      <span>Processing fee (7%)</span>
                      <span>−€{depositFee.toFixed(2)}</span>
                    </div>
                    <div className="dw-fee-row dw-fee-row--net">
                      <span>Added to wallet</span>
                      <span className="text-emerald-400">{depositNet.toFixed(2)} APC</span>
                    </div>
                  </div>
                  {busy ? (
                    <div className="dw-paypal-processing">
                      <RefreshCw size={18} className="animate-spin text-emerald-400" />
                      <span>Crediting your wallet…</span>
                    </div>
                  ) : (
                    <div className="dw-paypal-section">
                      <p className="dw-paypal-label">Pay securely with:</p>
                      <PayPalButton
                        key={depositAmt}
                        amount={parseFloat(depositAmt)}
                        onSuccess={handlePayPalSuccess}
                        onError={handlePayPalError}
                      />
                    </div>
                  )}
                </>
              )}
              {(!depositAmt || parseFloat(depositAmt) <= 0) && (
                <div className="dw-paypal-hint">
                  <span>Select or enter an amount above to pay with PayPal</span>
                </div>
              )}
            </>
          )}

          {/* ── Bank Transfer method ──────────────────────────── */}
          {depositMethod === 'bank' && (
            <>
              <p className="dw-panel__sub">Transfer from your bank. Send the exact amount and include your email as reference. We credit your wallet manually within 1 business day.</p>

              <div className="dw-bank-card">
                <div className="dw-bank-card__header">
                  <Building2 size={16} className="text-sky-400" />
                  <span className="dw-bank-card__name">{BANK_NAME}</span>
                </div>

                <BankField label="Account Holder" value={BANK_HOLDER} copyKey="holder" />
                <BankField label="IBAN" value={BANK_IBAN ?? 'Set VITE_BANK_IBAN in .env'} copyKey="iban" />
                <BankField label="BIC / SWIFT" value={BANK_BIC} copyKey="bic" />
                <BankField label="Reference" value="Your email address" copyKey="ref" noCopy />
              </div>

              <div className="dw-bank-notice">
                <ShieldCheck size={13} />
                <span>Always include your registered email as payment reference so we can match your transfer.</span>
              </div>
            </>
          )}
        </div>
      )}

      {/* ── Virtual Card panel ────────────────────────────────────────────────── */}
      {panel === 'card' && (
        <div className="dw-panel">
          <div className="dw-panel__header">
            <CreditCard size={18} className="text-amber-400" />
            <h2 className="dw-panel__title">Virtual Card</h2>
            <button className="dw-panel__close" onClick={() => setPanel('overview')}><X size={16} /></button>
          </div>
          <VirtualCardDisplay card={loading ? null : card} />
        </div>
      )}

      {/* ── Transaction History ───────────────────────────────────────────────── */}
      <div className="dw-section">
        <div className="dw-section__header">
          <Clock size={16} className="dw-section__icon" />
          <h2 className="dw-section__title">Recent Transactions</h2>
          <span className="dw-section__count">{txs.length}</span>
        </div>

        {loading ? (
          <div className="dw-tx-list">
            {[1,2,3].map(i => (
              <div key={i} className="dw-tx-row">
                <Shimmer className="h-8 w-8 rounded-full" />
                <div className="flex-1 px-3 space-y-2">
                  <Shimmer className="h-3 w-48" />
                  <Shimmer className="h-3 w-32" />
                </div>
                <Shimmer className="h-4 w-20" />
              </div>
            ))}
          </div>
        ) : txs.length === 0 ? (
          <div className="dw-tx-empty">
            <Landmark size={28} className="dw-tx-empty__icon" />
            <p>No transactions yet. Top up to get started.</p>
          </div>
        ) : (
          <div className="dw-tx-list">
            {txs.map(tx => <TxRow key={tx.id} tx={tx} />)}
          </div>
        )}

        {txs.length > 0 && (
          <button className="dw-see-all">
            <span>See all transactions</span>
            <ChevronRight size={14} />
          </button>
        )}
      </div>

      {/* Compliance footer */}
      <div className="dw-compliance">
        <ShieldCheck size={11} />
        <span>AIPPIETAX S.A. · APC pegged 1:1 to EUR · Secured · Mobile Money Network</span>
      </div>

      {/* Administrative data ledger — Digital Trust Registry */}
      <div style={{
        margin: '16px 0 8px',
        background: 'rgba(6,182,212,0.04)',
        border: '1px solid rgba(6,182,212,0.15)',
        borderRadius: 12, padding: '14px',
        display: 'flex', flexDirection: 'column', gap: 10,
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <ShieldCheck size={13} style={{ color: '#06b6d4' }} />
          <span style={{ color: '#e2e8f0', fontSize: 11, fontWeight: 700, letterSpacing: '0.05em' }}>
            Digital Trust Registry
          </span>
          <span style={{
            marginLeft: 'auto', fontSize: 8, fontWeight: 700, color: '#06b6d4',
            background: 'rgba(6,182,212,0.1)', border: '1px solid rgba(6,182,212,0.3)',
            borderRadius: 5, padding: '1px 6px', letterSpacing: '0.06em',
          }}>ADMIN LEDGER</span>
        </div>

        {/* Unique Cryptographic Cloud Registration ID */}
        <div style={{ background: 'rgba(0,0,0,0.3)', borderRadius: 8, padding: '8px 10px' }}>
          <div style={{ color: '#475569', fontSize: 8, fontWeight: 700, letterSpacing: '0.12em', textTransform: 'uppercase', marginBottom: 3 }}>
            Cryptographic Cloud Registration ID
          </div>
          <div style={{ color: '#06b6d4', fontSize: 12, fontWeight: 800, fontFamily: 'monospace', letterSpacing: '0.06em' }}>
            APT-2026-{(user?.id ?? '00000').slice(0, 5).toUpperCase()}
          </div>
          <div style={{ color: '#334155', fontSize: 8, marginTop: 2 }}>
            AIPPIETAX S.A. · NIF A22944987 · Wallet Node
          </div>
        </div>

        {/* Phone-Linked Bookkeeping Metadata Node */}
        <div style={{
          background: 'rgba(0,0,0,0.3)', borderRadius: 8, padding: '8px 10px',
          display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8,
        }}>
          <div>
            <div style={{ color: '#475569', fontSize: 8, fontWeight: 700, letterSpacing: '0.12em', textTransform: 'uppercase', marginBottom: 3 }}>
              Bookkeeping Node
            </div>
            <div style={{ color: '#1D9E75', fontSize: 12, fontWeight: 700 }}>
              {txs.length} entries
            </div>
            <div style={{ color: '#334155', fontSize: 8, marginTop: 2 }}>Tracked transactions</div>
          </div>
          <div>
            <div style={{ color: '#475569', fontSize: 8, fontWeight: 700, letterSpacing: '0.12em', textTransform: 'uppercase', marginBottom: 3 }}>
              Account Value
            </div>
            <div style={{ color: '#4ade80', fontSize: 12, fontWeight: 700 }}>
              {wallet ? `${wallet.balance_apc.toFixed(2)} APC` : '—'}
            </div>
            <div style={{ color: '#334155', fontSize: 8, marginTop: 2 }}>Administrative balance</div>
          </div>
        </div>

        {/* Invoice Tracking Status */}
        <div style={{ background: 'rgba(0,0,0,0.3)', borderRadius: 8, padding: '8px 10px' }}>
          <div style={{ color: '#475569', fontSize: 8, fontWeight: 700, letterSpacing: '0.12em', textTransform: 'uppercase', marginBottom: 6 }}>
            Automated Invoice Tracking Status
          </div>
          <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
            {[
              { label: 'Deposits', value: txs.filter(t => t.type === 'deposit').length, color: '#4ade80' },
              { label: 'Sends', value: txs.filter(t => t.type === 'send').length, color: '#38bdf8' },
              { label: 'Receives', value: txs.filter(t => t.type === 'receive').length, color: '#a78bfa' },
            ].map(s => (
              <div key={s.label} style={{
                background: s.color + '12', border: `1px solid ${s.color}33`,
                borderRadius: 6, padding: '5px 8px', textAlign: 'center', flex: 1, minWidth: 50,
              }}>
                <div style={{ color: s.color, fontSize: 13, fontWeight: 800 }}>{s.value}</div>
                <div style={{ color: '#475569', fontSize: 7.5, marginTop: 1 }}>{s.label}</div>
              </div>
            ))}
          </div>
        </div>

        <p style={{ color: '#334155', fontSize: 8.5, lineHeight: 1.6, margin: 0 }}>
          This module is a bookkeeping metadata node. AIPPIETAX S.A. does not process, hold, or transfer fiat funds.
          All APC credits are administrative tracking units. External fiat settlement is handled exclusively
          by licensed third-party payment processors.
        </p>
      </div>
    </div>
  );
}
