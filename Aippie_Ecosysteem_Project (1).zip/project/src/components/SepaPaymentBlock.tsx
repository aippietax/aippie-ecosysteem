import { useEffect, useRef, useState } from 'react';
import QRCode from 'qrcode';
import { Copy, CheckCheck, ChevronDown, ChevronUp } from 'lucide-react';

interface Props {
  amount: number;
  accent?: string;
  paypalUrl: string;
  paypalLabel?: string;
}

function buildBcdString(amount: number, ref: string): string {
  return [
    'BCD',
    '002',
    '1',
    'SCT',
    'BSABESBB',
    'AIPPIETAX S.A.',
    'ES91008105960000000000',
    `EUR${amount}`,
    ref,
    'Software licentie AIPPIETAX S.A.',
    '',
    '',
  ].join('\n');
}

function useSessionRef(): string {
  const ref = useRef(`AIPP-${Date.now().toString().slice(-8)}`);
  return ref.current;
}

export default function SepaPaymentBlock({ amount, accent = '#3B82F6', paypalUrl, paypalLabel }: Props) {
  const sessionRef = useSessionRef();
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [sepaOpen, setSepaOpen] = useState(false);
  const [copiedIban, setCopiedIban] = useState(false);
  const [copiedRef, setCopiedRef] = useState(false);

  const iban = 'ES91 0081 0596 XXXX XXXX XXXX';
  const amtFmt = new Intl.NumberFormat('nl-NL', { style: 'currency', currency: 'EUR' }).format(amount);

  useEffect(() => {
    if (!sepaOpen || !canvasRef.current) return;
    const bcd = buildBcdString(amount, sessionRef);
    QRCode.toCanvas(canvasRef.current, bcd, {
      width: 160,
      margin: 1,
      color: { dark: '#000000', light: '#ffffff' },
      errorCorrectionLevel: 'M',
    });
  }, [sepaOpen, amount, sessionRef]);

  function copy(text: string, set: (v: boolean) => void) {
    navigator.clipboard.writeText(text).then(() => {
      set(true);
      setTimeout(() => set(false), 1800);
    });
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 10, width: '100%' }}>

      {/* PayPal / Credit Card */}
      <a
        href={paypalUrl}
        target="_blank"
        rel="noopener noreferrer"
        style={{
          display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 10,
          background: '#0070ba', borderRadius: 10, color: '#fff',
          fontSize: 14, fontWeight: 700, padding: '13px 20px',
          textDecoration: 'none', boxShadow: '0 4px 20px rgba(0,112,186,0.4)',
          transition: 'opacity 0.15s',
        }}
      >
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
          <path d="M19.5 7.5C19.5 11.09 16.59 14 13 14H10L9 19H6L8 7H14C17.09 7 19.5 4.91 19.5 7.5Z" fill="#fff" fillOpacity="0.9"/>
          <path d="M7 7H4L6 19H9L10 14H13C16.59 14 19.5 11.09 19.5 7.5" stroke="#fff" strokeWidth="1.5" strokeLinecap="round"/>
        </svg>
        {paypalLabel ?? `Betaal via PayPal of Creditcard · ${amtFmt}`}
      </a>

      {/* SEPA accordion */}
      <div style={{
        background: 'rgba(255,255,255,0.03)',
        border: `1px solid ${sepaOpen ? 'rgba(96,165,250,0.35)' : 'rgba(255,255,255,0.09)'}`,
        borderRadius: 10, overflow: 'hidden',
        transition: 'border-color 0.2s',
      }}>
        <button
          onClick={() => setSepaOpen(o => !o)}
          style={{
            width: '100%', display: 'flex', alignItems: 'center', justifyContent: 'space-between',
            padding: '12px 14px', background: 'transparent', border: 'none', cursor: 'pointer',
            color: '#60A5FA',
          }}
        >
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#60A5FA" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <rect x="2" y="5" width="20" height="14" rx="2"/><line x1="2" y1="10" x2="22" y2="10"/>
            </svg>
            <span style={{ fontSize: 12, fontWeight: 700, letterSpacing: '0.07em', textTransform: 'uppercase' }}>
              Bankoverschrijving (SEPA)
            </span>
          </div>
          {sepaOpen ? <ChevronUp size={14} /> : <ChevronDown size={14} />}
        </button>

        {sepaOpen && (
          <div style={{ padding: '0 14px 16px', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 16 }}>

            {/* QR code */}
            <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8 }}>
              <div style={{
                background: '#fff', borderRadius: 10, padding: 8,
                boxShadow: '0 2px 16px rgba(0,0,0,0.4)',
              }}>
                <canvas ref={canvasRef} width={160} height={160} style={{ display: 'block' }} />
              </div>
              <span style={{ fontSize: 11, color: '#94A3B8', textAlign: 'center', lineHeight: 1.4 }}>
                Scan met uw bankapp om direct te betalen
              </span>
            </div>

            {/* Bank details */}
            <div style={{ width: '100%', display: 'flex', flexDirection: 'column', gap: 10 }}>
              {[
                { label: 'Bank', value: 'Banco Sabadell', mono: false, copy: false },
                { label: 'Begunstigde', value: 'AIPPIETAX S.A.', mono: false, copy: false },
                { label: 'IBAN', value: iban, mono: true, copy: true, copyKey: 'iban' },
                { label: 'BIC/SWIFT', value: 'BSABESBB', mono: true, copy: false },
                { label: 'Bedrag', value: amtFmt, mono: false, copy: false, highlight: accent },
                { label: 'Referentie', value: sessionRef, mono: true, copy: true, copyKey: 'ref' },
              ].map(row => (
                <div key={row.label} style={{
                  display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between',
                  gap: 8, borderBottom: '1px solid rgba(255,255,255,0.05)', paddingBottom: 8,
                }}>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ fontSize: 9, color: '#334155', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 2 }}>
                      {row.label}
                    </div>
                    <div style={{
                      fontSize: row.mono ? 11 : 13,
                      color: row.highlight ?? '#e2e8f0',
                      fontWeight: 600,
                      fontFamily: row.mono ? 'monospace' : 'inherit',
                      wordBreak: 'break-all',
                    }}>
                      {row.value}
                    </div>
                  </div>
                  {row.copy && (
                    <button
                      onClick={() => copy(row.value, row.copyKey === 'iban' ? setCopiedIban : setCopiedRef)}
                      style={{
                        flexShrink: 0, display: 'flex', alignItems: 'center', gap: 4,
                        background: 'rgba(96,165,250,0.08)', border: '1px solid rgba(96,165,250,0.2)',
                        borderRadius: 6, padding: '4px 8px', color: '#60A5FA', cursor: 'pointer', fontSize: 10,
                      }}
                    >
                      {(row.copyKey === 'iban' ? copiedIban : copiedRef)
                        ? <><CheckCheck size={10} />Gekopieerd</>
                        : <><Copy size={10} />Kopieer</>
                      }
                    </button>
                  )}
                </div>
              ))}
            </div>

            <p style={{ margin: 0, fontSize: 10, color: '#475569', textAlign: 'center', lineHeight: 1.5 }}>
              Betaling wordt verwerkt binnen 1–2 werkdagen. Uw licentiesleutel wordt per e-mail verzonden na bevestiging.
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
