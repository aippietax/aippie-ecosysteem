/**
 * ClientAccessGate — Returning customer direct-access screen
 * AIPPIETAX S.A.
 *
 * Shown instead of the cinematic landing when:
 *   a) A license key is already stored in localStorage (auto-validates & redirects), OR
 *   b) The user clicks "Ik ben al klant" on the landing
 *
 * The user can enter their license key (format AIPP-XXXX-XXXX-XXXX) to get
 * routed directly to their paid product without going through the landing.
 */
import { useCallback, useEffect, useRef, useState } from 'react';
import {
  ShieldCheck, ArrowRight, RefreshCw, Copy, Check,
  Lock, Zap, ChevronRight, X, KeyRound, Star,
} from 'lucide-react';
import { supabase } from '../lib/supabase';

// ── Plan → AppTab mapping ──────────────────────────────────────────────────────
const PLAN_TAB_MAP: Record<string, string> = {
  tax:           'tax',
  doctor:        'doctor',
  trading:       'trading',
  alphatrade:    'alphatrade',
  academy:       'academy',
  companion:     'companion',
  companionradar:'companionradar',
  realestate:    'realestate',
  b2b:           'b2b',
  legal:         'legal',
  accounting:    'accounting',
  securechat:    'securechat',
  videovault:    'videovault',
  docvault:      'docvault',
  wallet:        'wallet',
  unified:       'unified',
  morning:       'morning',
  aippiedev:     'aippiedev',
  safecheckin:   'safecheckin',
  silentvoice:   'silentvoice',
  reunion:       'reunion',
  voice:         'voice',
};

const PLAN_LABELS: Record<string, { label: string; icon: string; color: string }> = {
  tax:           { label: 'AippieTax',          icon: '📊', color: '#38bdf8' },
  doctor:        { label: 'Aippie Doctor',       icon: '🏥', color: '#4ade80' },
  trading:       { label: 'Trading Alpha',       icon: '📈', color: '#f59e0b' },
  alphatrade:    { label: 'Alpha Trade',         icon: '⚡', color: '#f59e0b' },
  academy:       { label: 'AI Academy',          icon: '🎓', color: '#a78bfa' },
  companion:     { label: 'Companion',           icon: '💙', color: '#fb7185' },
  companionradar:{ label: 'Companion Radar',     icon: '📡', color: '#fb7185' },
  realestate:    { label: 'Real Estate',         icon: '🏡', color: '#34d399' },
  b2b:           { label: 'B2B Enterprise Hub',  icon: '🏢', color: '#60a5fa' },
  legal:         { label: 'Legal AI',            icon: '⚖️', color: '#fbbf24' },
  accounting:    { label: 'Accounting Suite',    icon: '🏦', color: '#38bdf8' },
  securechat:    { label: 'SecureChat',          icon: '🔒', color: '#34d399' },
  videovault:    { label: 'Video Vault',         icon: '🎥', color: '#60a5fa' },
  docvault:      { label: 'Document Vault',      icon: '📁', color: '#f97316' },
  wallet:        { label: 'Digital Wallet',      icon: '💳', color: '#a78bfa' },
  unified:       { label: 'Finance Command',     icon: '🎛️', color: '#38bdf8' },
  morning:       { label: 'Morning Briefing',    icon: '🌅', color: '#fbbf24' },
  aippiedev:     { label: 'AippieDev Factory',   icon: '⚙️', color: '#60a5fa' },
  voice:         { label: 'Voice Interpreter',   icon: '🎙️', color: '#38bdf8' },
};

export interface AccessGranted {
  appTab: string;
  licenseKey: string;
  ownerName: string;
  plan: string;
}

interface Props {
  onAccess: (granted: AccessGranted) => void;
  onGoToLanding: () => void;
  autoKey?: string | null; // pre-filled from localStorage
}

type Phase = 'input' | 'checking' | 'granted' | 'error';

export default function ClientAccessGate({ onAccess, onGoToLanding, autoKey }: Props) {
  const [keyInput, setKeyInput] = useState(autoKey ?? '');
  const [phase, setPhase] = useState<Phase>(autoKey ? 'checking' : 'input');
  const [granted, setGranted] = useState<AccessGranted | null>(null);
  const [errorMsg, setErrorMsg] = useState('');
  const [copied, setCopied] = useState(false);
  const [countdown, setCountdown] = useState(3);
  const mountedRef = useRef(true);
  const countdownRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const validateKey = useCallback(async (key: string) => {
    setPhase('checking');
    setErrorMsg('');

    try {
      const { data, error } = await supabase
        .from('aippietax_active_licenses')
        .select('id, license_key, owner_name, plan, status, expires_at')
        .eq('license_key', key.trim().toUpperCase())
        .maybeSingle();

      if (!mountedRef.current) return;

      if (error) {
        // Network timeout or Supabase error — show retry option
        setPhase('error');
        setErrorMsg(
          error.message?.includes('abort') || error.message?.includes('timeout')
            ? 'Connection too slow. Check your internet and try again.'
            : 'Could not validate license. Please try again.'
        );
        return;
      }

      if (!data) {
        setPhase('error');
        setErrorMsg('License key not found. Check your key or contact support@aippietax.com.');
        return;
      }

    if (data.status === 'revoked') {
      setPhase('error');
      setErrorMsg('This license has been revoked. Contact support@aippietax.com.');
      return;
    }

    if (data.expires_at && new Date(data.expires_at) < new Date()) {
      setPhase('error');
      setErrorMsg('Your license has expired. Renew at aippietax.com.');
      return;
    }

    if (data.status !== 'active') {
      setPhase('error');
      setErrorMsg('License is not active. Contact support@aippietax.com.');
      return;
    }

    const appTab = PLAN_TAB_MAP[data.plan] ?? 'voice';
    const result: AccessGranted = {
      appTab,
      licenseKey: data.license_key,
      ownerName: data.owner_name,
      plan: data.plan,
    };

    localStorage.setItem('aippie_license_key', data.license_key);
    localStorage.setItem('aippie_license_validated', data.license_key);
    setGranted(result);
    setPhase('granted');
    setCountdown(3);

    countdownRef.current = setInterval(() => {
      setCountdown(prev => {
        if (prev <= 1) {
          if (countdownRef.current) clearInterval(countdownRef.current);
          if (mountedRef.current) onAccess(result);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    } catch {
      if (!mountedRef.current) return;
      setPhase('error');
      setErrorMsg('Connection failed. Check your internet and try again.');
    }
  }, [onAccess]);

  // Auto-validate stored key on mount
  useEffect(() => {
    mountedRef.current = true;
    if (autoKey) validateKey(autoKey);
    return () => {
      mountedRef.current = false;
      if (countdownRef.current) clearInterval(countdownRef.current);
    };
  }, []); // eslint-disable-line

  const formatInput = (raw: string) => {
    const clean = raw.replace(/[^A-Z0-9]/gi, '').toUpperCase().slice(0, 16);
    const parts = [clean.slice(0,4), clean.slice(4,8), clean.slice(8,12), clean.slice(12,16)].filter(Boolean);
    return parts.join('-');
  };

  const handleInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    setKeyInput(formatInput(e.target.value));
    setErrorMsg('');
    if (phase === 'error') setPhase('input');
  };

  const copyKey = () => {
    if (!granted) return;
    navigator.clipboard.writeText(granted.licenseKey).catch(() => {});
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const planInfo = granted ? (PLAN_LABELS[granted.plan] ?? { label: granted.plan, icon: '⚡', color: '#38bdf8' }) : null;

  return (
    <div className="cag-root">
      {/* Background */}
      <div className="cag-bg">
        <div className="cag-bg__grid" />
        <div className="cag-bg__glow cag-bg__glow--left" />
        <div className="cag-bg__glow cag-bg__glow--right" />
      </div>

      <div className="cag-card">
        {/* Back to landing */}
        <button className="cag-back" onClick={onGoToLanding}>
          <X size={14} /> Close
        </button>

        {/* Header */}
        <div className="cag-header">
          <div className="cag-header__icon-wrap">
            <div className="cag-header__ring cag-header__ring--1" />
            <div className="cag-header__ring cag-header__ring--2" />
            <KeyRound size={28} className="cag-header__icon" />
          </div>
          <div className="cag-header__text">
            <h2 className="cag-header__title">Customer Access</h2>
            <p className="cag-header__sub">Enter your personal license key to access your product directly</p>
          </div>
        </div>

        {/* ── Input phase ── */}
        {(phase === 'input' || phase === 'error') && (
          <div className="cag-input-section">
            <div className="cag-key-label">
              <Lock size={12} /> Your AIPPIETAX license code
            </div>
            <input
              className={`cag-key-input${phase === 'error' ? ' cag-key-input--error' : ''}`}
              value={keyInput}
              onChange={handleInput}
              placeholder="AIPP-XXXX-XXXX-XXXX"
              maxLength={19}
              spellCheck={false}
              autoComplete="off"
              autoFocus
              onKeyDown={e => { if (e.key === 'Enter' && keyInput.length >= 19) validateKey(keyInput); }}
            />
            {errorMsg && (
              <div className="cag-error">
                <Lock size={11} /> {errorMsg}
              </div>
            )}
            <button
              className="cag-enter-btn"
              onClick={() => validateKey(keyInput)}
              disabled={keyInput.replace(/-/g,'').length < 16}
            >
              <ShieldCheck size={16} />
              Sign In Directly
              <ArrowRight size={14} />
            </button>

            <div className="cag-divider"><span>of</span></div>

            <button className="cag-landing-btn" onClick={onGoToLanding}>
              View all products
              <ChevronRight size={13} />
            </button>

            <div className="cag-hint">
              <Zap size={11} />
              <span>Your license key is in your confirmation email · format: <strong>AIPP-XXXX-XXXX-XXXX</strong></span>
            </div>
          </div>
        )}

        {/* ── Checking phase ── */}
        {phase === 'checking' && (
          <div className="cag-checking">
            <div className="cag-checking__spinner" />
            <p className="cag-checking__label">Validating license…</p>
            <p className="cag-checking__sub">Please wait (up to 10 seconds)</p>
          </div>
        )}

        {/* ── Granted phase ── */}
        {phase === 'granted' && granted && planInfo && (
          <div className="cag-granted">
            <div className="cag-granted__badge" style={{ borderColor: planInfo.color + '44', background: planInfo.color + '10' }}>
              <ShieldCheck size={20} style={{ color: planInfo.color }} />
              <span style={{ color: planInfo.color }}>License Active</span>
            </div>

            <div className="cag-granted__product" style={{ borderColor: planInfo.color + '33' }}>
              <span className="cag-granted__icon">{planInfo.icon}</span>
              <div>
                <div className="cag-granted__product-name" style={{ color: planInfo.color }}>{planInfo.label}</div>
                <div className="cag-granted__owner">Welcome back, {granted.ownerName}</div>
              </div>
            </div>

            <div className="cag-granted__key-row">
              <span className="cag-granted__key-label">Your license key</span>
              <div className="cag-granted__key" style={{ borderColor: planInfo.color + '44', color: planInfo.color }}>
                {granted.licenseKey}
              </div>
              <button className="cag-granted__copy" onClick={copyKey} style={{ color: planInfo.color }}>
                {copied ? <><Check size={11} /> Copied</> : <><Copy size={11} /> Copy</>}
              </button>
            </div>

            <button
              className="cag-granted__copy-link"
              style={{ color: planInfo.color, borderColor: planInfo.color + '44' }}
              onClick={() => {
                const link = `${window.location.origin}/?key=${granted.licenseKey}`;
                navigator.clipboard.writeText(link).catch(() => {});
                setCopied(true);
                setTimeout(() => setCopied(false), 2000);
              }}
            >
              <RefreshCw size={11} /> Copy device link — open on any phone to log in instantly
            </button>

            <button
              className="cag-go-btn"
              style={{ background: `linear-gradient(135deg, ${planInfo.color}cc, ${planInfo.color})`, boxShadow: `0 0 24px ${planInfo.color}55` }}
              onClick={() => {
                if (countdownRef.current) clearInterval(countdownRef.current);
                onAccess(granted);
              }}
            >
              <span className="cag-go-btn__icon">{planInfo.icon}</span>
              Open {planInfo.label}
              <span className="cag-go-btn__countdown">{countdown}</span>
            </button>

            <div className="cag-granted__auto-hint">
              <Star size={10} /> Auto-starting in {countdown} seconds
            </div>
          </div>
        )}

        {/* Footer */}
        <div className="cag-footer">
          <ShieldCheck size={10} />
          <span>AIPPIETAX S.A. · 256-bit TLS · GDPR</span>
        </div>
      </div>
    </div>
  );
}
