import { useEffect, useState } from 'react';
import {
  Sun, TrendingUp, TrendingDown, AlertTriangle, Bot,
  Radio, Zap, Shield, RefreshCw, BarChart2,
} from 'lucide-react';
import { supabase } from '../lib/supabase';

interface User { email?: string; user_metadata?: { name?: string } }
interface Props { user: User | null }

interface BriefingItem {
  id: string;
  asset_class: string;
  symbol: string;
  name: string;
  price: number;
  change_pct: number;
  sparkline: number[];
}
interface AlertItem {
  id: string;
  severity: 'critical' | 'high' | 'medium' | 'low';
  asset: string;
  message: string;
  source: string;
}

const SESSION_LABEL = (() => {
  const h = new Date().getHours();
  if (h < 9)  return { label: 'PRE-MARKET', color: '#fbbf24' };
  if (h < 17) return { label: 'MARKET OPEN', color: '#4ade80' };
  return { label: 'AFTER-HOURS', color: '#60a5fa' };
})();

const SEVERITY_COLOR: Record<string, string> = {
  critical: '#f87171', high: '#fb923c', medium: '#fbbf24', low: '#4ade80',
};

const CLASS_LABEL: Record<string, string> = {
  stocks: 'Aandelen', crypto: 'Crypto', forex: 'Forex', commodities: 'Grondstoffen',
};

function Sparkline({ data, positive }: { data: number[]; positive: boolean }) {
  if (!data || data.length < 2) return null;
  const min = Math.min(...data);
  const max = Math.max(...data);
  const range = max - min || 1;
  const w = 64, h = 24;
  const pts = data.map((v, i) => {
    const x = (i / (data.length - 1)) * w;
    const y = h - ((v - min) / range) * (h - 4) - 2;
    return `${x},${y}`;
  }).join(' ');
  return (
    <svg width={w} height={h} viewBox={`0 0 ${w} ${h}`}>
      <polyline
        points={pts}
        fill="none"
        stroke={positive ? '#4ade80' : '#f87171'}
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}

export default function AippieMorningBriefingView({ user }: Props) {
  const [items, setItems]   = useState<BriefingItem[]>([]);
  const [alerts, setAlerts] = useState<AlertItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [activeClass, setActiveClass] = useState<string>('all');
  const name = user?.user_metadata?.name ?? user?.email?.split('@')[0] ?? 'Trader';
  const today = new Date().toLocaleDateString('nl-NL', { weekday: 'long', day: 'numeric', month: 'long' });

  const load = async (quiet = false) => {
    if (!quiet) setLoading(true);
    else setRefreshing(true);

    const [{ data: mkt }, { data: alts }] = await Promise.all([
      supabase.from('morning_briefing_cache').select('*').order('asset_class').order('symbol'),
      supabase.from('morning_briefing_alerts').select('*').order('severity'),
    ]);

    setItems((mkt as BriefingItem[]) ?? []);
    setAlerts((alts as AlertItem[]) ?? []);
    setLoading(false);
    setRefreshing(false);
  };

  useEffect(() => { load(); }, []);

  const classes = ['all', ...Array.from(new Set(items.map(i => i.asset_class)))];
  const filtered = activeClass === 'all' ? items : items.filter(i => i.asset_class === activeClass);
  const grouped = filtered.reduce<Record<string, BriefingItem[]>>((acc, item) => {
    (acc[item.asset_class] = acc[item.asset_class] ?? []).push(item);
    return acc;
  }, {});

  if (loading) return (
    <div className="mb-root" style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', minHeight: 300 }}>
      <div className="cag-checking__spinner" />
    </div>
  );

  return (
    <div className="mb-root">
      {/* Header */}
      <div className="mb-header">
        <div className="mb-header__left">
          <div className="mb-header__icon-wrap"><Sun size={20} className="mb-header__icon" /></div>
          <div>
            <div className="mb-header__title">Goedemorgen, {name}</div>
            <div className="mb-header__sub">{today}</div>
          </div>
        </div>
        <div className="mb-header__right">
          <div className="mb-session-badge" style={{ color: SESSION_LABEL.color, borderColor: SESSION_LABEL.color + '44', background: SESSION_LABEL.color + '12' }}>
            <span className="mb-session-dot" style={{ background: SESSION_LABEL.color }} />
            {SESSION_LABEL.label}
          </div>
          <button className="mb-refresh-btn" onClick={() => load(true)} disabled={refreshing}>
            <RefreshCw size={13} className={refreshing ? 'mb-spin' : ''} />
          </button>
        </div>
      </div>

      {/* Alerts */}
      {alerts.length > 0 && (
        <div className="mb-alerts">
          <div className="mb-section-label"><AlertTriangle size={11} /> AI Markt Alerts</div>
          <div className="mb-alerts__grid">
            {alerts.map(a => (
              <div key={a.id} className="mb-alert-card" style={{ borderColor: SEVERITY_COLOR[a.severity] + '44', background: SEVERITY_COLOR[a.severity] + '0d' }}>
                <div className="mb-alert-card__severity" style={{ color: SEVERITY_COLOR[a.severity] }}>
                  {a.severity.toUpperCase()} · {a.asset}
                </div>
                <div className="mb-alert-card__msg">{a.message}</div>
                <div className="mb-alert-card__source">{a.source}</div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Filter tabs */}
      <div className="mb-tabs">
        {classes.map(c => (
          <button
            key={c}
            className={`mb-tab${activeClass === c ? ' mb-tab--active' : ''}`}
            onClick={() => setActiveClass(c)}
          >
            {c === 'all' ? 'Alles' : (CLASS_LABEL[c] ?? c)}
          </button>
        ))}
      </div>

      {/* Market data per class */}
      {Object.entries(grouped).map(([cls, rows]) => (
        <div key={cls} className="mb-class-section">
          <div className="mb-section-label">
            <BarChart2 size={11} /> {CLASS_LABEL[cls] ?? cls}
          </div>
          <div className="mb-instruments-grid">
            {rows.map(item => {
              const pos = item.change_pct >= 0;
              return (
                <div key={item.id} className="mb-instrument-card">
                  <div className="mb-instrument-card__top">
                    <div className="mb-instrument-card__symbol">{item.symbol}</div>
                    <div className={`mb-instrument-card__pct ${pos ? 'mb-pos' : 'mb-neg'}`}>
                      {pos ? <TrendingUp size={10} /> : <TrendingDown size={10} />}
                      {pos ? '+' : ''}{item.change_pct.toFixed(2)}%
                    </div>
                  </div>
                  <div className="mb-instrument-card__name">{item.name}</div>
                  <div className="mb-instrument-card__bottom">
                    <div className="mb-instrument-card__price">
                      {item.price >= 1000
                        ? item.price.toLocaleString('nl-NL', { minimumFractionDigits: 2, maximumFractionDigits: 2 })
                        : item.price.toFixed(item.price < 10 ? 4 : 2)}
                    </div>
                    <Sparkline data={item.sparkline} positive={pos} />
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      ))}

      {/* AI Briefing summary */}
      <div className="mb-ai-card">
        <div className="mb-ai-card__header">
          <Bot size={15} className="mb-ai-card__icon" />
          <span>AI Markt Analyse</span>
          <span className="mb-ai-card__badge">LIVE</span>
        </div>
        <p className="mb-ai-card__body">
          De markt opent vandaag met een positief momentum. Crypto sectoren laten de sterkste stijgingen zien,
          gedreven door institutionele instroom en positief Fed-sentiment. Grondstoffen blijven onder druk door
          verhoogd OPEC-aanbod. Risicobeheer aanbevolen voor energie-posities. Technologie-aandelen profiteren
          van sterke AI-gerelateerde capex-cijfers.
        </p>
        <div className="mb-ai-card__footer">
          <Shield size={10} /> Gegenereerd door Aippie AI · {new Date().toLocaleTimeString('nl-NL', { hour: '2-digit', minute: '2-digit' })}
        </div>
      </div>

      {/* Footer */}
      <div className="mb-footer">
        <Radio size={10} /> AIPPIETAX S.A. · Morning Briefing · Alleen informatief, geen beleggingsadvies
        <Zap size={10} style={{ marginLeft: 8 }} />
      </div>
    </div>
  );
}
