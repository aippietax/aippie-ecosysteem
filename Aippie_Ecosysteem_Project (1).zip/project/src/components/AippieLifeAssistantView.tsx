import { useCallback, useEffect, useRef, useState } from 'react';
import {
  Bell, Mic, MapPin, Mail, Calendar, ShieldCheck, Volume2, VolumeX,
  CheckCircle2, BellOff, BellRing, Clock, MessageSquare, Banknote,
  FileText, Settings, ChevronDown, ChevronUp, Zap, Coffee,
  Sunset, Moon, UtensilsCrossed, ShoppingCart, Pill, AlarmClock,
  RefreshCw, Cloud, Newspaper, Wifi, WifiOff, Send, Lock, X,
  Shield, ShieldOff, ShoppingBag, Heart, TrendingUp, Mic2, Users,
  Activity, Droplets, Battery, Star,
} from 'lucide-react';
import { supabase } from '../lib/supabase';
import { applyPremiumVoice, withVoicesReady, normalizeForTTS } from '../lib/ttsVoice';

const SUPABASE_URL   = import.meta.env.VITE_SUPABASE_URL as string;
const FUNCTIONS_BASE = `${SUPABASE_URL}/functions/v1`;
// ── Types ─────────────────────────────────────────────────────────────────────
type PermKey = 'notif_ok' | 'mic_ok' | 'location_ok' | 'email_ok' | 'calendar_ok';
type Permissions = Record<PermKey, boolean>;

interface ScheduleSettings {
  wake_up_time: string; lunch_time: string;
  afternoon_time: string; evening_time: string;
  wake_up_on: boolean; lunch_on: boolean;
  afternoon_on: boolean; evening_on: boolean;
}

interface GmailMsg   { id: string; from: string; subject: string; date: string; snippet: string; }
interface HolledInv  { number: string; client: string; amount: number; currency: string; due_date: string; }
interface WeatherData { temp: number; feels_like: number; description: string; city: string; humidity: number; }
interface NewsItem    { title: string; source: string; }

interface Intelligence {
  weather:          WeatherData | null;
  news:             NewsItem[];
  spoken_briefing:  string;
  short_alert:      string | null;
}

interface LiveEvent { id: string; ts: Date; message: string; type: string; }

// ── Helpers ────────────────────────────────────────────────────────────────────
function uid()        { return Math.random().toString(36).slice(2); }
function getDeviceKey() {
  let k = localStorage.getItem('aippie_device_key');
  if (!k) { k = crypto.randomUUID(); localStorage.setItem('aippie_device_key', k); }
  return k;
}
function toMin(t: string) { const [h, m] = t.split(':').map(Number); return h * 60 + m; }
function nowMin()         { const n = new Date(); return n.getHours() * 60 + n.getMinutes(); }
function msUntil(t: string) {
  const d = toMin(t) - nowMin();
  return d > 0 ? d * 60000 : (1440 + d) * 60000;
}
function tod(): 'morning' | 'noon' | 'afternoon' | 'evening' | 'night' {
  const h = new Date().getHours();
  if (h >= 5  && h < 11) return 'morning';
  if (h >= 11 && h < 14) return 'noon';
  if (h >= 14 && h < 18) return 'afternoon';
  if (h >= 18 && h < 22) return 'evening';
  return 'night';
}
function greeting() {
  const t = tod();
  return t === 'morning' ? 'Good morning' : t === 'evening' ? 'Good evening' : t === 'night' ? 'Good night' : 'Good afternoon';
}
const FOOD: Record<string, string[]> = {
  morning:   ['oatmeal with fresh fruit', 'Greek yogurt with honey', 'avocado toast with eggs', 'a banana smoothie'],
  noon:      ['grilled chicken salad', 'a whole grain wrap', 'lentil soup', 'a quinoa bowl'],
  afternoon: ['apple with almond butter', 'mixed nuts', 'hummus with carrots', 'dark chocolate'],
  evening:   ['salmon with sweet potato', 'stir-fry with brown rice', 'homemade vegetable soup', 'pasta primavera'],
  night:     ['chamomile tea', 'a light fruit salad'],
};
function food() { const l = FOOD[tod()]; return l[Math.floor(Math.random() * l.length)]; }

const PERM_LABELS: Record<PermKey, string> = {
  notif_ok: 'Notifications', mic_ok: 'Microphone', location_ok: 'Location',
  email_ok: 'Email', calendar_ok: 'Calendar',
};

// ── Permission card ────────────────────────────────────────────────────────────
function PermCard({ icon, label, desc, granted, loading, onGrant }: {
  icon: React.ReactNode; label: string; desc: string;
  granted: boolean; loading: boolean; onGrant: () => void;
}) {
  return (
    <div className={`la-perm-card${granted ? ' la-perm-card--granted' : ''}`}>
      <div className="la-perm-card__icon">{icon}</div>
      <div className="la-perm-card__body">
        <div className="la-perm-card__label">{label}</div>
        <div className="la-perm-card__desc">{desc}</div>
      </div>
      <button className={`la-perm-btn${granted ? ' la-perm-btn--granted' : ''}`} onClick={onGrant} disabled={granted || loading}>
        {loading ? <span className="la-spinner" /> : granted ? <><CheckCircle2 size={11} />Active</> : 'Allow'}
      </button>
    </div>
  );
}

// ── Timeline item ──────────────────────────────────────────────────────────────
function TimelineItem({ time, label, icon, color, active, upcoming }: {
  time: string; label: string; icon: React.ReactNode;
  color: string; active: boolean; upcoming: boolean;
}) {
  return (
    <div className={`la-timeline-item${active ? ' la-timeline-item--active' : ''}${upcoming ? ' la-timeline-item--upcoming' : ''}`}>
      <div className="la-timeline-dot" style={{
        background: active ? color + '22' : upcoming ? color + '11' : '#0f172a',
        border: `1.5px solid ${active ? color : upcoming ? color + '66' : '#1e293b'}`,
      }}>
        <span style={{ color: active ? color : upcoming ? color + 'aa' : '#334155' }}>{icon}</span>
      </div>
      <div className="la-timeline-content">
        <div className="la-timeline-time" style={{ color: active ? color : upcoming ? '#94a3b8' : '#475569' }}>{time}</div>
        <div className="la-timeline-label" style={{ color: active ? '#f1f5f9' : upcoming ? '#cbd5e1' : '#475569' }}>{label}</div>
      </div>
      {active && <span className="la-timeline-now-badge">Now</span>}
    </div>
  );
}

interface SecureChatMsg {
  id: string;
  from_pin: string;
  to_pin: string;
  content: string;
  is_read: boolean;
  created_at: string;
  detected_lang?: string;
}

// ── Aippie SecureChat inbox ────────────────────────────────────────────────────
function SecureChatInbox({ speak, onIncoming, familyPins = [] }: { speak: (t: string) => void; onIncoming?: (sender: string, content: string, isFamily: boolean) => void; familyPins?: string[] }) {
  const [myPin, setMyPin]         = useState<string | null>(null);
  const [messages, setMessages]   = useState<SecureChatMsg[]>([]);
  const [contacts, setContacts]   = useState<Record<string, string>>({});  // pin→name
  const [replyTo, setReplyTo]     = useState<string | null>(null);
  const [replyText, setReplyText] = useState('');
  const [sending, setSending]     = useState(false);
  const [loading, setLoading]     = useState(true);

  // Load own PIN + threads
  useEffect(() => {
    const init = async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) { setLoading(false); return; }

      const { data: pin } = await supabase
        .from('secure_chat_pins').select('pin_code, display_name')
        .eq('user_id', user.id).maybeSingle();

      if (!pin) { setLoading(false); return; }
      setMyPin(pin.pin_code);

      // Load last 40 messages (inbound + outbound)
      const { data: msgs } = await supabase
        .from('secure_chat_messages')
        .select('*')
        .or(`from_pin.eq.${pin.pin_code},to_pin.eq.${pin.pin_code}`)
        .eq('is_deleted', false)
        .order('created_at', { ascending: false })
        .limit(40);

      setMessages((msgs ?? []) as SecureChatMsg[]);

      // Load contact nicknames
      const { data: ctcs } = await supabase
        .from('secure_chat_contacts')
        .select('contact_pin, nickname')
        .eq('owner_pin', pin.pin_code);

      const map: Record<string, string> = {};
      (ctcs ?? []).forEach((c: { contact_pin: string; nickname?: string }) => {
        map[c.contact_pin] = c.nickname ?? c.contact_pin;
      });
      setContacts(map);
      setLoading(false);
    };
    init();
  }, []);

  // ── Secure access gate state ─────────────────────────────────────────────
  const [pendingMsg, setPendingMsg]   = useState<{ sender: string; msg: SecureChatMsg } | null>(null);
  const [secCodeInput, setSecCodeInput] = useState('');
  const [secCodeError, setSecCodeError] = useState('');
  const [webAuthnState, setWebAuthnState] = useState<'idle' | 'scanning' | 'verified' | 'failed'>('idle');

  const SECURE_CODE = '1234'; // demo PIN — in production: fetched from user profile

  const triggerBiometricAlert = (sender: string) => {
    // 1. Vibrate phone
    if (navigator.vibrate) {
      navigator.vibrate([300, 100, 300, 100, 300]);
    }
    // 2. Alert speak — do NOT read message yet
    speak(`Elvin, je hebt een nieuw beveiligd bericht van ${sender}. Voer je code in om het te lezen.`);
  };

  const handleWebAuthn = async () => {
    setWebAuthnState('scanning');
    try {
      if (typeof window !== 'undefined' && 'credentials' in navigator) {
        const challenge = crypto.getRandomValues(new Uint8Array(32));
        // Simulate WebAuthn assertion — in a real app this would use stored credential IDs
        await (navigator.credentials as CredentialContainer & {
          get: (opts: CredentialRequestOptions) => Promise<Credential | null>
        }).get({
          publicKey: {
            challenge,
            timeout: 10000,
            userVerification: 'required',
          },
        }).catch(() => null); // Fallback gracefully if no credential enrolled
      }
      // Simulate successful verification (biometric UI feedback)
      setTimeout(() => setWebAuthnState('verified'), 800);
    } catch {
      setWebAuthnState('failed');
    }
  };

  // Realtime — Aippie reads new inbound messages aloud after secure verification
  useEffect(() => {
    if (!myPin) return;
    const ch = supabase.channel('la_secure_chat')
      .on('postgres_changes', {
        event: 'INSERT', schema: 'public', table: 'secure_chat_messages',
        filter: `to_pin=eq.${myPin}`,
      }, (payload) => {
        const msg = payload.new as SecureChatMsg;
        setMessages(prev => [msg, ...prev].slice(0, 40));
        const sender = contacts[msg.from_pin] ?? msg.from_pin;
        const isFamily = familyPins.includes(msg.from_pin);
        // Delegate to Part 3 handler if provided
        if (onIncoming) {
          onIncoming(sender, msg.content, isFamily);
        } else {
          // Show secure access gate + vibrate + speak alert
          setPendingMsg({ sender, msg });
          setSecCodeInput('');
          setSecCodeError('');
          setWebAuthnState('idle');
          triggerBiometricAlert(sender);
        }
      }).subscribe();
    return () => { supabase.removeChannel(ch); };
  }, [myPin, contacts]);

  const sendReply = async () => {
    if (!myPin || !replyTo || !replyText.trim()) return;
    setSending(true);
    const { error } = await supabase.from('secure_chat_messages').insert({
      from_pin: myPin,
      to_pin: replyTo,
      content: replyText.trim(),
    });
    setSending(false);
    if (!error) {
      setReplyText('');
      speak('Bericht verstuurd.');
      // Reload
      const { data } = await supabase
        .from('secure_chat_messages')
        .select('*')
        .or(`from_pin.eq.${myPin},to_pin.eq.${myPin}`)
        .eq('is_deleted', false)
        .order('created_at', { ascending: false })
        .limit(40);
      setMessages((data ?? []) as SecureChatMsg[]);
    }
  };

  if (loading) return <div className="la-inbox-empty">Aippie chat laden…</div>;
  if (!myPin) return (
    <div className="la-inbox-empty">
      Geen SecureChat PIN gevonden. Open SecureChat eerst en maak een profiel aan.
    </div>
  );

  // Group into threads by the other party's pin
  const threads = Array.from(new Set(
    messages.map(m => m.from_pin === myPin ? m.to_pin : m.from_pin)
  ));

  return (
    <div className="la-inbox">
      {/* ── Secure message access gate ──────────────────────────────────── */}
      {pendingMsg && (
        <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.85)', zIndex: 9000, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 24 }}>
          <div style={{ background: '#0f172a', border: '1px solid rgba(34,211,238,0.25)', borderRadius: 16, padding: 24, width: '100%', maxWidth: 340, boxShadow: '0 0 40px rgba(34,211,238,0.1)' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 16 }}>
              <div style={{ width: 36, height: 36, borderRadius: 8, background: 'rgba(34,211,238,0.1)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <Lock size={16} style={{ color: '#22d3ee' }} />
              </div>
              <div>
                <div style={{ fontSize: 13, fontWeight: 700, color: '#f1f5f9' }}>Secure Message Received</div>
                <div style={{ fontSize: 10, color: '#64748b' }}>From: {pendingMsg.sender}</div>
              </div>
            </div>
            <div style={{ fontSize: 11, color: '#94a3b8', marginBottom: 16, lineHeight: 1.5 }}>
              Enter your secure code or use biometric verification to read this message.
            </div>
            <button
              onClick={handleWebAuthn}
              disabled={webAuthnState === 'scanning' || webAuthnState === 'verified'}
              style={{ width: '100%', padding: '10px 0', marginBottom: 10, background: webAuthnState === 'verified' ? 'rgba(74,222,128,0.1)' : 'rgba(34,211,238,0.06)', border: `1px solid ${webAuthnState === 'verified' ? 'rgba(74,222,128,0.3)' : 'rgba(34,211,238,0.2)'}`, borderRadius: 8, color: webAuthnState === 'verified' ? '#4ade80' : '#22d3ee', fontSize: 11, fontWeight: 600, cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8 }}
            >
              {webAuthnState === 'idle'     && <><ShieldCheck size={13} /> Fingerprint / Face ID</>}
              {webAuthnState === 'scanning' && <><RefreshCw size={13} style={{ animation: 'spin 1s linear infinite' }} /> Scanning…</>}
              {webAuthnState === 'verified' && <><CheckCircle2 size={13} /> Biometric Verified</>}
              {webAuthnState === 'failed'   && <><ShieldCheck size={13} /> Retry Biometric</>}
            </button>
            <div style={{ textAlign: 'center', fontSize: 9, color: '#334155', margin: '6px 0' }}>or enter PIN</div>
            <input
              type="password"
              inputMode="numeric"
              maxLength={8}
              placeholder="Secure code…"
              value={secCodeInput}
              onChange={e => { setSecCodeInput(e.target.value); setSecCodeError(''); }}
              onKeyDown={e => {
                if (e.key !== 'Enter') return;
                if (secCodeInput === SECURE_CODE || webAuthnState === 'verified') {
                  speak(`Nieuw bericht van ${pendingMsg.sender}: ${pendingMsg.msg.content}`);
                  supabase.from('secure_chat_messages').update({ is_read: true, read_at: new Date().toISOString() }).eq('id', pendingMsg.msg.id).then(() => {
                    setMessages(prev => prev.map(m => m.id === pendingMsg!.msg.id ? { ...m, is_read: true } : m));
                  });
                  setPendingMsg(null);
                } else { setSecCodeError('Incorrect code. Try again.'); }
              }}
              style={{ width: '100%', padding: '9px 12px', background: '#0a0f1e', border: '1px solid rgba(100,116,139,0.3)', borderRadius: 8, color: '#f1f5f9', fontSize: 13, outline: 'none', boxSizing: 'border-box', marginBottom: 6 }}
            />
            {secCodeError && <div style={{ fontSize: 10, color: '#f87171', marginBottom: 8 }}>{secCodeError}</div>}
            <div style={{ display: 'flex', gap: 8 }}>
              <button onClick={() => setPendingMsg(null)} style={{ flex: 1, padding: '9px 0', background: 'rgba(248,113,113,0.06)', border: '1px solid rgba(248,113,113,0.15)', borderRadius: 8, color: '#f87171', fontSize: 11, cursor: 'pointer' }}>
                Dismiss
              </button>
              <button
                onClick={() => {
                  if (secCodeInput === SECURE_CODE || webAuthnState === 'verified') {
                    speak(`Nieuw bericht van ${pendingMsg.sender}: ${pendingMsg.msg.content}`);
                    supabase.from('secure_chat_messages').update({ is_read: true, read_at: new Date().toISOString() }).eq('id', pendingMsg.msg.id).then(() => {
                      setMessages(prev => prev.map(m => m.id === pendingMsg!.msg.id ? { ...m, is_read: true } : m));
                    });
                    setPendingMsg(null);
                  } else { setSecCodeError('Incorrect code. Try again.'); }
                }}
                style={{ flex: 1, padding: '9px 0', background: 'rgba(34,211,238,0.1)', border: '1px solid rgba(34,211,238,0.2)', borderRadius: 8, color: '#22d3ee', fontSize: 11, fontWeight: 600, cursor: 'pointer' }}
              >
                <Lock size={11} style={{ display: 'inline', marginRight: 5 }} /> Unlock
              </button>
            </div>
          </div>
        </div>
      )}

      <div className="la-inbox-header">
        <span className="la-inbox-title">
          <Lock size={12} style={{ color: '#22d3ee' }} />
          Aippie SecureChat
        </span>
        <span className="la-hint-note" style={{ color: '#22d3ee88', fontSize: 10 }}>
          PIN: {myPin} · E2EE
        </span>
      </div>

      {threads.length === 0 ? (
        <div className="la-inbox-empty">
          Nog geen berichten. Open SecureChat en stuur je eerste E2EE bericht. Aippie leest elk nieuw bericht automatisch voor.
        </div>
      ) : (
        <>
          <div className="la-wa-list">
            {threads.map(pin => {
              const thread = messages.filter(m => m.from_pin === pin || m.to_pin === pin);
              const last   = thread[0];
              const unread = thread.filter(m => m.to_pin === myPin && !m.is_read).length;
              const name   = contacts[pin] ?? pin;
              const isMine = last.from_pin === myPin;
              return (
                <div
                  key={pin}
                  className={`la-wa-thread${replyTo === pin ? ' la-wa-thread--active' : ''}`}
                  onClick={() => setReplyTo(replyTo === pin ? null : pin)}
                >
                  <div className="la-wa-avatar" style={{ background: '#22d3ee22', color: '#22d3ee', border: '1px solid #22d3ee44' }}>
                    {name[0]?.toUpperCase() ?? '?'}
                  </div>
                  <div className="la-wa-thread-body">
                    <div className="la-wa-thread-name">
                      {name}
                      {unread > 0 && <span className="la-wa-badge" style={{ background: '#22d3ee' }}>{unread}</span>}
                    </div>
                    <div className="la-wa-thread-preview">
                      {isMine ? 'Jij: ' : ''}{last.content}
                    </div>
                  </div>
                  <button
                    className="la-wa-speak"
                    onClick={e => { e.stopPropagation(); speak(`${name}: ${last.content}`); }}
                  >
                    <Volume2 size={10} />
                  </button>
                </div>
              );
            })}
          </div>
          {replyTo && (
            <div className="la-reply-box">
              <input
                className="la-reply-input"
                placeholder={`Antwoord aan ${contacts[replyTo] ?? replyTo}…`}
                value={replyText}
                onChange={e => setReplyText(e.target.value)}
                onKeyDown={e => e.key === 'Enter' && sendReply()}
              />
              <button className="la-reply-send" onClick={sendReply} disabled={sending || !replyText.trim()}>
                {sending ? <span className="la-spinner" /> : <Send size={12} />}
              </button>
            </div>
          )}
        </>
      )}
    </div>
  );
}

// ── Gmail inbox ────────────────────────────────────────────────────────────────
function GmailInbox({ speak }: { speak: (t: string) => void }) {
  const [emails, setEmails]   = useState<GmailMsg[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError]     = useState('');

  const load = async () => {
    setLoading(true); setError('');
    const res  = await fetch(`${FUNCTIONS_BASE}/gmail-reader`);
    const data = await res.json();
    if (data.error) setError(data.error);
    else setEmails(data.emails ?? []);
    setLoading(false);
  };

  return (
    <div className="la-inbox">
      <div className="la-inbox-header">
        <span className="la-inbox-title"><Mail size={12} style={{ color: '#38bdf8' }} />Gmail — Unread</span>
        <button className="la-inbox-action" onClick={load} disabled={loading}>
          <RefreshCw size={10} className={loading ? 'la-spin' : ''} />{loading ? 'Loading…' : 'Fetch now'}
        </button>
      </div>
      {error ? (
        <div className="la-inbox-error">
          {error.includes('not configured')
            ? 'Not connected yet. Developer: add GMAIL_ACCESS_TOKEN to Supabase Edge Function secrets.'
            : error}
        </div>
      ) : emails.length === 0 ? (
        <div className="la-inbox-empty">{loading ? 'Fetching your emails…' : 'Tap "Fetch now" to load unread Gmail messages. Aippie will read them aloud.'}</div>
      ) : (
        <div className="la-email-list">
          {emails.map(em => (
            <div key={em.id} className="la-email-row">
              <div className="la-email-from">{em.from.replace(/<.*>/, '').trim()}</div>
              <div className="la-email-subject">{em.subject}</div>
              <div className="la-email-snippet">{em.snippet}</div>
              <button className="la-wa-speak" onClick={() => speak(`Email from ${em.from.replace(/<.*>/, '').trim()}: ${em.subject}. ${em.snippet}`)}>
                <Volume2 size={10} />
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// ── Holled invoices ────────────────────────────────────────────────────────────
function HolledPanel({ speak }: { speak: (t: string) => void }) {
  const [invoices, setInvoices] = useState<HolledInv[]>([]);
  const [total, setTotal]       = useState(0);
  const [loading, setLoading]   = useState(false);
  const [error, setError]       = useState('');

  const load = async () => {
    setLoading(true); setError('');
    const res  = await fetch(`${FUNCTIONS_BASE}/holled-invoices`);
    const data = await res.json();
    if (data.error) setError(data.error);
    else {
      setInvoices(data.invoices ?? []);
      setTotal(data.total_open ?? 0);
      if ((data.invoices ?? []).length > 0)
        speak(`You have ${data.invoices.length} open invoice${data.invoices.length > 1 ? 's' : ''} totalling €${data.total_open.toFixed(2)}.`);
    }
    setLoading(false);
  };

  return (
    <div className="la-inbox">
      <div className="la-inbox-header">
        <span className="la-inbox-title"><FileText size={12} style={{ color: '#f97316' }} />Holled — Open invoices</span>
        <button className="la-inbox-action" onClick={load} disabled={loading}>
          <RefreshCw size={10} className={loading ? 'la-spin' : ''} />{loading ? 'Loading…' : 'Fetch now'}
        </button>
      </div>
      {error ? (
        <div className="la-inbox-error">
          {error.includes('not configured')
            ? 'Not connected. Developer: add HOLLED_API_KEY to Supabase Edge Function secrets.'
            : error}
        </div>
      ) : invoices.length === 0 ? (
        <div className="la-inbox-empty">{loading ? 'Fetching invoices…' : 'Tap "Fetch now" to see open invoices. Aippie will tell you the total amount due.'}</div>
      ) : (
        <>
          <div className="la-holled-total"><Banknote size={11} style={{ color: '#f97316' }} />Total open: <strong style={{ color: '#f97316' }}>€{total.toFixed(2)}</strong></div>
          <div className="la-invoice-list">
            {invoices.map((inv, i) => (
              <div key={i} className="la-invoice-row">
                <div className="la-invoice-num">{inv.number}</div>
                <div className="la-invoice-client">{inv.client}</div>
                <div className="la-invoice-meta">Due {inv.due_date}</div>
                <div className="la-invoice-amount">€{inv.amount.toFixed(2)}</div>
              </div>
            ))}
          </div>
        </>
      )}
    </div>
  );
}

// ── Intelligence panel ─────────────────────────────────────────────────────────
function IntelligencePanel({ intel, loading, onRefresh, speak }: {
  intel: Intelligence | null; loading: boolean; onRefresh: () => void; speak: (t: string) => void;
}) {
  return (
    <div className="la-inbox">
      <div className="la-inbox-header">
        <span className="la-inbox-title"><Cloud size={12} style={{ color: '#a78bfa' }} />Live intelligence</span>
        <button className="la-inbox-action" onClick={onRefresh} disabled={loading}>
          <RefreshCw size={10} className={loading ? 'la-spin' : ''} />{loading ? 'Updating…' : 'Refresh'}
        </button>
      </div>
      {!intel ? (
        <div className="la-inbox-empty">{loading ? 'Fetching real-time data…' : 'Tap Refresh to load live weather and news.'}</div>
      ) : (
        <div style={{ padding: '10px 12px', display: 'flex', flexDirection: 'column', gap: 10 }}>
          {/* Weather */}
          {intel.weather && (
            <div className="la-intel-row">
              <Cloud size={14} style={{ color: '#38bdf8', flexShrink: 0 }} />
              <div>
                <div className="la-intel-label">{intel.weather.city} — {intel.weather.temp}°C, feels like {intel.weather.feels_like}°C</div>
                <div className="la-intel-sub">{intel.weather.description} · {intel.weather.humidity}% humidity</div>
              </div>
              <button className="la-wa-speak" onClick={() => speak(`In ${intel.weather!.city} it is ${intel.weather!.temp} degrees, ${intel.weather!.description}.`)}>
                <Volume2 size={10} />
              </button>
            </div>
          )}
          {/* News */}
          {intel.news.length > 0 && (
            <div>
              <div className="la-intel-section-title"><Newspaper size={10} />Top news</div>
              {intel.news.slice(0, 4).map((n, i) => (
                <div key={i} className="la-news-row">
                  <div className="la-news-source">{n.source}</div>
                  <div className="la-news-title">{n.title}</div>
                  <button className="la-wa-speak" onClick={() => speak(`${n.source}: ${n.title}`)}><Volume2 size={10} /></button>
                </div>
              ))}
            </div>
          )}
          {/* Full briefing */}
          <button className="la-briefing-btn" onClick={() => speak(intel.spoken_briefing)}>
            <Volume2 size={12} />Read full briefing aloud
          </button>
        </div>
      )}
    </div>
  );
}

// ── Main ───────────────────────────────────────────────────────────────────────
export default function AippieLifeAssistantView({ onClose }: { onClose?: () => void } = {}) {
  const [perms, setPerms] = useState<Permissions>({
    notif_ok: false, mic_ok: false, location_ok: false, email_ok: false, calendar_ok: false,
  });
  const [schedule, setSchedule] = useState<ScheduleSettings>({
    wake_up_time: '07:00', lunch_time: '12:30', afternoon_time: '15:00', evening_time: '20:00',
    wake_up_on: true, lunch_on: true, afternoon_on: true, evening_on: true,
  });
  const [loading, setLoading]   = useState<PermKey | null>(null);
  const [speaking, setSpeaking] = useState(false);
  const [muted, setMuted]       = useState(false);
  const [currentMsg, setCurrentMsg]   = useState('');
  const [proactive, setProactive]     = useState(true);
  const [dbLoaded, setDbLoaded]       = useState(false);
  const [showSched, setShowSched]     = useState(false);
  const [activeTab, setActiveTab]     = useState<'live' | 'context' | 'actions' | 'health' | 'reminders' | 'family' | 'schedule' | 'securechat' | 'gmail' | 'holled'>('live');
  const [liveEvents, setLiveEvents]   = useState<LiveEvent[]>([]);
  const [intel, setIntel]             = useState<Intelligence | null>(null);
  const [intelLoading, setIntelLoading] = useState(false);
  const [isOnline, setIsOnline]         = useState(navigator.onLine);
  const [currentTime, setCurrentTime]   = useState(new Date());
  const [userLocation, setUserLocation] = useState<{ lat: number; lon: number } | null>(null);

  // Feature 1: Smart Context
  const [batteryLevel, setBatteryLevel] = useState<number | null>(null);

  // Feature 3: Smart Reminders
  interface Reminder { id: string; type: 'medication' | 'meeting' | 'tax' | 'trading'; label: string; time: string; confirmed: boolean; }
  const [reminders, setReminders] = useState<Reminder[]>([
    { id: 'med1', type: 'medication', label: 'Morning medication', time: '08:00', confirmed: false },
    { id: 'meet1', type: 'meeting', label: 'Team standup', time: '09:15', confirmed: false },
    { id: 'tax1', type: 'tax', label: 'VAT deadline this month', time: '00:00', confirmed: false },
  ]);

  // Feature 4: PIN alert modal (shown when incoming message arrives)
  const [showPinModal, setShowPinModal] = useState<{ show: boolean; sender: string; messageId: string; content: string } | null>(null);
  const [pinModalInput, setPinModalInput] = useState('');
  const [pinModalError, setPinModalError] = useState('');

  // Feature 5: Quick reply
  const [quickReplyTarget, setQuickReplyTarget] = useState<string | null>(null);
  const [customReplyText, setCustomReplyText] = useState('');

  // Battery API
  useEffect(() => {
    const nav = navigator as Navigator & { getBattery?: () => Promise<{ level: number }> };
    nav.getBattery?.().then(b => setBatteryLevel(Math.round(b.level * 100))).catch(() => {});
  }, []);

  // ── NEW PARTS 1-12 STATE ──────────────────────────────────────────────────
  // Part 2: ARM state
  const [armed, setArmed] = useState(false);
  const [armingInProgress, setArmingInProgress] = useState(false);

  // Part 3: incoming message YES/NO prompt
  const [incomingPrompt, setIncomingPrompt] = useState<{ sender: string; content: string } | null>(null);

  // Part 4: Quick actions
  const [showShoppingInput, setShowShoppingInput] = useState(false);
  const [shoppingItem, setShoppingItem] = useState('');
  const [showReminderInput, setShowReminderInput] = useState(false);
  const [reminderText, setReminderText] = useState('');
  const [reminderTime, setReminderTime] = useState('');

  // Part 5: Audio / silence detection
  const audioAnalyserRef = useRef<AnalyserNode | null>(null);
  const audioStreamRef   = useRef<MediaStream | null>(null);
  const silenceTimerRef  = useRef<ReturnType<typeof setTimeout> | null>(null);
  const lastSoundRef     = useRef<number>(Date.now());

  // Part 1: Active AI rotate index
  const rotateIdxRef = useRef(0);
  const activeAiRef  = useRef<ReturnType<typeof setInterval> | null>(null);

  // Part 7: Sleep guardian
  const isSleepHour = () => { const h = new Date().getHours(); return h >= 23 || h < 7; };

  // Part 8: Health log
  const [showEnergyPrompt, setShowEnergyPrompt] = useState(false);
  const healthTimersRef = useRef<ReturnType<typeof setTimeout>[]>([]);

  // Part 9: Financial guardian
  const lastPricesRef = useRef<Record<string, number>>({});
  const finGuardRef   = useRef<ReturnType<typeof setInterval> | null>(null);

  // Part 10: Voice listener
  const [voiceListening, setVoiceListening] = useState(false);
  const [voiceTranscript, setVoiceTranscript] = useState('');
  const recognitionRef = useRef<SpeechRecognition | null>(null);
  // YES/NO voice fallback — shown when mic is blocked after incoming message prompt
  const [showVoiceFallback, setShowVoiceFallback] = useState(false);
  const respondRecognitionRef = useRef<SpeechRecognition | null>(null);

  // Part 12: Family contacts
  const [familyPins, setFamilyPins] = useState<string[]>(() => {
    try { return JSON.parse(localStorage.getItem('aippie_family_pins') ?? '[]'); } catch { return []; }
  });

  const cancelRef   = useRef(false);
  const timerRefs   = useRef<ReturnType<typeof setTimeout>[]>([]);
  const pollRef     = useRef<ReturnType<typeof setInterval> | null>(null);
  const wakeLockRef = useRef<WakeLockSentinel | null>(null);
  const deviceKey   = getDeviceKey();

  // Keep screen on so speech synthesis keeps running
  useEffect(() => {
    const acquire = async () => {
      if (!('wakeLock' in navigator)) return;
      try {
        wakeLockRef.current = await (navigator as Navigator & { wakeLock: { request: (type: string) => Promise<WakeLockSentinel> } }).wakeLock.request('screen');
      } catch { /* permission denied — no crash */ }
    };
    acquire();
    const reacquire = () => { if (document.visibilityState === 'visible') acquire(); };
    document.addEventListener('visibilitychange', reacquire);
    return () => {
      document.removeEventListener('visibilitychange', reacquire);
      wakeLockRef.current?.release().catch(() => {});
    };
  }, []);
  const anyPerm     = Object.values(perms).some(Boolean);
  const activeCount = Object.values(perms).filter(Boolean).length;

  // Online status
  useEffect(() => {
    const on  = () => setIsOnline(true);
    const off = () => setIsOnline(false);
    window.addEventListener('online', on); window.addEventListener('offline', off);
    return () => { window.removeEventListener('online', on); window.removeEventListener('offline', off); };
  }, []);

  // Clock
  useEffect(() => {
    const t = setInterval(() => setCurrentTime(new Date()), 30000);
    return () => clearInterval(t);
  }, []);

  // Load settings from DB
  useEffect(() => {
    supabase.from('life_assistant_settings').select('*').eq('device_key', deviceKey).maybeSingle()
      .then(({ data }) => {
        if (data) {
          setPerms({ notif_ok: !!data.notif_ok, mic_ok: !!data.mic_ok, location_ok: !!data.location_ok, email_ok: !!data.email_ok, calendar_ok: !!data.calendar_ok });
          setProactive(data.proactive !== false);
          if (data.wake_up_time) setSchedule({
            wake_up_time: data.wake_up_time, lunch_time: data.lunch_time,
            afternoon_time: data.afternoon_time, evening_time: data.evening_time,
            wake_up_on: data.wake_up_on !== false, lunch_on: data.lunch_on !== false,
            afternoon_on: data.afternoon_on !== false, evening_on: data.evening_on !== false,
          });
        }
        setDbLoaded(true);
      });
    return () => {
      cancelRef.current = true;
      window.speechSynthesis?.cancel();
      timerRefs.current.forEach(clearTimeout);
      if (pollRef.current) clearInterval(pollRef.current);
    };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Fetch intelligence (real weather + news)
  const fetchIntelligence = useCallback(async (lat?: number, lon?: number) => {
    setIntelLoading(true);
    const loc = lat && lon ? `?lat=${lat}&lon=${lon}` : userLocation ? `?lat=${userLocation.lat}&lon=${userLocation.lon}` : '';
    const res  = await fetch(`${FUNCTIONS_BASE}/aippie-intelligence${loc}`).catch(() => null);
    if (res?.ok) {
      const data = await res.json();
      setIntel(data);
      setIntelLoading(false);
      return data as Intelligence;
    }
    setIntelLoading(false);
    return null;
  }, [userLocation]);

  // Intro speech + intelligence on load + follow-up questions
  useEffect(() => {
    if (!dbLoaded) return;
    const run = async () => {
      let lat: number | undefined; let lon: number | undefined;
      if (perms.location_ok) {
        await new Promise<void>(resolve => {
          navigator.geolocation.getCurrentPosition(
            pos => { lat = pos.coords.latitude; lon = pos.coords.longitude; setUserLocation({ lat, lon }); resolve(); },
            () => resolve(), { timeout: 3000 }
          );
        });
      }
      const data = await fetchIntelligence(lat, lon);
      const msg = data?.spoken_briefing
        ?? `${greeting()}! I am Aippie, your personal AI life assistant. I am now live and active. I will speak to you at your scheduled times, read your messages, and keep you informed.`;
      speak(msg);

      // Follow-up questions after intro — Aippie engages the user
      const followUps = [
        data?.short_alert ?? null,
        `How are you feeling today? I will remind you to drink water and eat well throughout the day.`,
        `Your scheduled alarms are active. I will speak to you at wake-up, lunch, afternoon, and evening.`,
      ].filter(Boolean) as string[];

      followUps.forEach((q, i) => {
        setTimeout(() => { if (!muted) speak(q); }, (i + 1) * 9000);
      });
    };
    run();
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [dbLoaded]);

  // Always-on background polling — every 30 minutes, no permission gate
  useEffect(() => {
    if (!proactive) return;
    if (pollRef.current) clearInterval(pollRef.current);
    pollRef.current = setInterval(async () => {
      // Part 7: Sleep guardian — skip background speak during sleep hours unless armed for critical
      if (isSleepHour() && !armed) return;
      const data = await fetchIntelligence();
      if (!muted) {
        const msg = data?.short_alert ?? data?.spoken_briefing ?? null;
        if (msg) speak(msg);
      }
    }, 15 * 1000); // Part 1: poll every 15 seconds
    return () => { if (pollRef.current) clearInterval(pollRef.current); };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [proactive, muted, fetchIntelligence]);

  // ── PART 1: Active AI — rotate messages every 15 seconds ─────────────────
  useEffect(() => {
    if (activeAiRef.current) clearInterval(activeAiRef.current);
    if (!armed || muted) return;
    const MOTIVATIONAL: Record<string, string[]> = {
      morning:   ['Great morning to start strong!', 'New day, new opportunities!'],
      noon:      ['Keep pushing through the afternoon!', 'Halfway through the day — you\'re doing great.'],
      afternoon: ['Stay focused, you\'re almost there.', 'The best time of day to close deals.'],
      evening:   ['You made it through the day. Well done.', 'Time to wind down and recharge.'],
      night:     ['Rest well. Tomorrow is a new day.', 'Sleep is your superpower.'],
    };
    activeAiRef.current = setInterval(() => {
      if (muted || !armed || isSleepHour()) return;
      const t = tod();
      const messages = [
        intel?.news[0] ? `Breaking news: ${intel.news[0].title}` : null,
        'BTC is active — check your trading positions.',
        'Do you need anything? Groceries? A reminder?',
        'How are you feeling? Remember to drink water.',
        intel?.weather ? `Weather update: ${intel.weather.temp}°C in ${intel.weather.city}, ${intel.weather.description}.` : null,
        MOTIVATIONAL[t][rotateIdxRef.current % MOTIVATIONAL[t].length],
      ].filter(Boolean) as string[];
      const msg = messages[rotateIdxRef.current % messages.length];
      rotateIdxRef.current += 1;
      if (msg) {
        if (navigator.vibrate) navigator.vibrate([200, 100, 200]);
        speak(msg);
      }
    }, 15000);
    return () => { if (activeAiRef.current) clearInterval(activeAiRef.current); };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [armed, muted, intel]);

  // ── PART 5: Silence / audio level detection ───────────────────────────────
  useEffect(() => {
    if (!armed || !perms.mic_ok) {
      audioStreamRef.current?.getTracks().forEach(t => t.stop());
      return;
    }
    let stopped = false;
    navigator.mediaDevices.getUserMedia({ audio: true }).then(stream => {
      if (stopped) { stream.getTracks().forEach(t => t.stop()); return; }
      audioStreamRef.current = stream;
      const ctx = new (window.AudioContext || (window as typeof window & { webkitAudioContext: typeof AudioContext }).webkitAudioContext)();
      const src = ctx.createMediaStreamSource(stream);
      const analyser = ctx.createAnalyser(); analyser.fftSize = 512;
      src.connect(analyser); audioAnalyserRef.current = analyser;
      const buf = new Uint8Array(analyser.frequencyBinCount);
      const check = () => {
        if (stopped) return;
        analyser.getByteFrequencyData(buf);
        const avg = buf.reduce((s, v) => s + v, 0) / buf.length;
        if (avg > 60) { // loud audio
          lastSoundRef.current = Date.now();
          if (avg > 200 && armed && !muted) speak('I notice something intense. Need help?');
        }
        if (Date.now() - lastSoundRef.current > 5 * 60 * 1000 && armed && !muted) {
          speak('Are you still there? Everything okay?');
          lastSoundRef.current = Date.now();
        }
        requestAnimationFrame(check);
      };
      check();
    }).catch(() => {});
    return () => {
      stopped = true;
      audioStreamRef.current?.getTracks().forEach(t => t.stop());
    };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [armed, perms.mic_ok]);

  // ── PART 6: Proactive agenda AI — check every 60 seconds ─────────────────
  useEffect(() => {
    if (!armed) return;
    const t = setInterval(() => {
      if (muted || isSleepHour()) return;
      const n = nowMin();
      const day = new Date().getDay(); // 0=Sun,5=Fri,1=Mon
      const h   = new Date().getHours();
      // 20-min warning before each scheduled alarm
      timelineItems.forEach(item => {
        const diff = toMin(item.time) - n;
        if (diff === 20 && armed) speak(`You have ${item.label} in 20 minutes.`);
      });
      // Friday afternoon
      if (day === 5 && h === 15 && new Date().getMinutes() === 0)
        speak('It is Friday. Shall I prepare your weekly financial summary?');
      // Monday morning
      if (day === 1 && h === 8 && new Date().getMinutes() === 0)
        speak('Good morning Elvin. New week. Here is what needs your attention.');
    }, 60000);
    return () => clearInterval(t);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [armed, muted, timelineItems]);

  // ── PART 8: Health reminders ──────────────────────────────────────────────
  useEffect(() => {
    healthTimersRef.current.forEach(clearTimeout);
    healthTimersRef.current = [];
    if (!armed) return;
    // Water every 2 hours
    const waterTimer = setInterval(() => {
      if (!muted && !isSleepHour() && armed) speak('Time to drink water.');
    }, 2 * 60 * 60 * 1000);
    // Food every 4 hours
    const foodTimer = setInterval(() => {
      if (!muted && !isSleepHour() && armed) speak('Have you eaten recently?');
    }, 4 * 60 * 60 * 1000);
    // Late night check
    const lateTimer = setInterval(() => {
      if (armed && !muted && new Date().getHours() >= 22) speak('It is late. You should rest soon.');
    }, 60 * 60 * 1000);
    // Morning energy check at wake_up_time
    const energyTimer = setTimeout(() => {
      if (armed && !muted) {
        speak('How are you feeling today? Rate your energy from 1 to 5.');
        setShowEnergyPrompt(true);
      }
    }, msUntil(schedule.wake_up_time) + 2000);
    healthTimersRef.current = [energyTimer];
    return () => {
      clearInterval(waterTimer); clearInterval(foodTimer); clearInterval(lateTimer);
      healthTimersRef.current.forEach(clearTimeout);
    };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [armed, muted, schedule.wake_up_time]);

  // ── PART 9: Financial guardian ────────────────────────────────────────────
  useEffect(() => {
    if (finGuardRef.current) clearInterval(finGuardRef.current);
    if (!armed) return;
    // Daily summary at 20:00
    const summaryTimer = setTimeout(() => {
      if (!muted && armed) speak('Daily financial summary: Your portfolio is active. Check your trading dashboard for today\'s performance.');
    }, msUntil('20:00'));
    finGuardRef.current = setInterval(async () => {
      if (!armed || muted) return;
      try {
        const res = await fetch(`${FUNCTIONS_BASE}/stock-quotes?symbols=BTC,ETH,SPY`).catch(() => null);
        if (!res?.ok) return;
        const data = await res.json();
        const prices: Record<string, number> = data.quotes ?? {};
        Object.entries(prices).forEach(([sym, price]) => {
          const prev = lastPricesRef.current[sym];
          if (prev && Math.abs((price - prev) / prev) > 0.03) {
            const pct = (((price - prev) / prev) * 100).toFixed(1);
            if (navigator.vibrate) navigator.vibrate([300, 100, 300]);
            speak(`${sym} moved ${pct}%. Check your positions.`);
          }
        });
        lastPricesRef.current = prices;
      } catch { /* non-critical */ }
    }, 15000);
    return () => { clearInterval(finGuardRef.current!); clearTimeout(summaryTimer); };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [armed, muted]);

  // ── PART 10: Voice command listener ──────────────────────────────────────
  const startVoiceListener = useCallback(() => {
    const SR = window.SpeechRecognition ?? (window as typeof window & { webkitSpeechRecognition: typeof SpeechRecognition }).webkitSpeechRecognition;
    if (!SR) return;
    if (recognitionRef.current) { try { recognitionRef.current.stop(); } catch { /* ok */ } }
    const r = new SR();
    recognitionRef.current = r;
    r.continuous = true; r.interimResults = false; r.lang = 'en-US';
    r.onresult = (e: SpeechRecognitionEvent) => {
      const transcript = Array.from(e.results).map(res => res[0].transcript).join(' ').toLowerCase().trim();
      setVoiceTranscript(transcript);
      if (!transcript.includes('aippie') && !transcript.includes('hey aippie')) return;
      if (transcript.includes('btc') || transcript.includes('bitcoin')) {
        speak('Checking BTC price now.');
      } else if (transcript.includes('message')) {
        speak('Opening SecureChat for you.');
        setActiveTab('securechat');
      } else if (transcript.includes('read')) {
        speak('Reading your unread messages now.');
        setActiveTab('securechat');
      } else if (transcript.includes('day') || transcript.includes('briefing')) {
        const b = intel?.spoken_briefing ?? `${greeting()}! Here is your briefing. ${intel?.weather ? `It is ${intel.weather.temp} degrees, ${intel.weather.description}.` : ''}`;
        speak(b);
      } else if (transcript.includes('water') || transcript.includes('remind')) {
        speak('Reminder set. I will remind you shortly.');
      } else {
        speak('I heard you, Elvin. How can I help?');
      }
    };
    r.onerror = () => setVoiceListening(false);
    r.onend = () => { setVoiceListening(false); if (armed && perms.mic_ok) setTimeout(startVoiceListener, 1000); };
    r.start(); setVoiceListening(true);
  }, [armed, perms.mic_ok, intel, speak]);

  useEffect(() => {
    if (armed && perms.mic_ok) { startVoiceListener(); }
    else { try { recognitionRef.current?.stop(); } catch { /* ok */ } setVoiceListening(false); }
    return () => { try { recognitionRef.current?.stop(); } catch { /* ok */ } };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [armed, perms.mic_ok]);

  // ── PART 11: Context logging ──────────────────────────────────────────────
  useEffect(() => {
    supabase.from('la_context_log').insert({ device_key: deviceKey, feature: 'app_open', logged_at: new Date().toISOString() }).then(() => {});
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const logFeatureUse = useCallback((feature: string) => {
    supabase.from('la_context_log').insert({ device_key: deviceKey, feature, logged_at: new Date().toISOString() }).then(() => {});
  }, [deviceKey]);

  // ── PART 2: ARM button handler ────────────────────────────────────────────
  const handleArm = async () => {
    if (armed) { setArmed(false); speak('AI standby. I will be here when you need me.'); return; }
    setArmingInProgress(true);
    speak('Arming AI. Requesting all permissions.');
    // Request mic
    try { const s = await navigator.mediaDevices.getUserMedia({ audio: true }); s.getTracks().forEach(t => t.stop()); } catch { /* ok */ }
    // Request notifications
    await Notification.requestPermission().catch(() => {});
    // Request location
    await new Promise<void>(r => navigator.geolocation.getCurrentPosition(() => r(), () => r(), { timeout: 3000 }));
    // Camera (optional, may be denied)
    try { const s = await navigator.mediaDevices.getUserMedia({ video: true }); s.getTracks().forEach(t => t.stop()); } catch { /* ok */ }
    setArmed(true); setArmingInProgress(false);
    if (navigator.vibrate) navigator.vibrate([200, 100, 200]);
    speak('AI armed. I am now watching over you, Elvin. All systems active.');
    logFeatureUse('arm');
  };

  // Scheduled daily alarms — no anyPerm gate, just proactive
  useEffect(() => {
    timerRefs.current.forEach(clearTimeout); timerRefs.current = [];
    if (!proactive) return;

    const arm = (time: string, enabled: boolean, buildMsg: () => string, type: string) => {
      if (!enabled) return;
      const t = setTimeout(() => {
        const message = buildMsg();
        setLiveEvents(prev => [{ id: uid(), ts: new Date(), message, type }, ...prev].slice(0, 30));
        if (!muted) speak(message);
        if (perms.notif_ok && 'Notification' in window && Notification.permission === 'granted')
          new Notification('Aippie', { body: message, icon: '/icons/icon.svg' });
        supabase.from('life_assistant_events').insert({ device_key: deviceKey, event_type: type, title: message, preview: message });
        arm(time, enabled, buildMsg, type);
      }, msUntil(time));
      timerRefs.current.push(t);
    };

    arm(schedule.wake_up_time, schedule.wake_up_on, () => {
      const w = intel?.weather ? ` Outside it is ${intel.weather.temp} degrees, ${intel.weather.description}.` : '';
      return `${greeting()}! Time to wake up.${w} For breakfast I suggest ${food()}. Have a wonderful day!`;
    }, 'wake_up');
    arm(schedule.lunch_time, schedule.lunch_on, () =>
      `Lunch time! I suggest ${food()}. Take a proper break, step away from your screen, and eat well. You deserve it.`, 'lunch');
    arm(schedule.afternoon_time, schedule.afternoon_on, () =>
      `Good afternoon. Have you had enough water today? I suggest a healthy snack — maybe ${food()}. Keep going, you are doing great.`, 'afternoon');
    arm(schedule.evening_time, schedule.evening_on, () => {
      const w = intel?.weather ? ` The temperature outside is ${intel.weather.temp} degrees.` : '';
      return `Good evening.${w} For dinner I suggest ${food()}. You have done well today. Time to relax and recharge.`;
    }, 'evening');

    // Feature 2: AI Daily Briefing — auto-speak at wake_up_time
    if (schedule.wake_up_on) {
      const briefingTimer = setTimeout(() => {
        const date = new Date().toLocaleDateString('en-GB', { weekday: 'long', day: 'numeric', month: 'long' });
        const weatherPart = intel?.weather ? `Weather: ${intel.weather.temp} degrees, ${intel.weather.description}.` : '';
        const briefing = `Good morning Elvin. Today is ${date}. ${weatherPart} Have a productive day ahead.`;
        if (!muted) speak(briefing);
        setLiveEvents(prev => [{ id: uid(), ts: new Date(), message: briefing, type: 'daily_briefing' }, ...prev].slice(0, 30));
      }, msUntil(schedule.wake_up_time));
      timerRefs.current.push(briefingTimer);
    }

    return () => timerRefs.current.forEach(clearTimeout);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [proactive, schedule, muted, intel]);

  const speak = useCallback((text: string, onEnd?: () => void) => {
    if (!('speechSynthesis' in window)) { onEnd?.(); return; }
    cancelRef.current = true; window.speechSynthesis.cancel(); cancelRef.current = false;
    setCurrentMsg(text); setSpeaking(true);
    withVoicesReady(() => {
      if (cancelRef.current) { setSpeaking(false); onEnd?.(); return; }
      const u = new SpeechSynthesisUtterance(normalizeForTTS(text));
      u.rate = 0.84; u.pitch = 1.02; applyPremiumVoice(u);
      u.onend = () => { setSpeaking(false); onEnd?.(); };
      u.onerror = () => { setSpeaking(false); onEnd?.(); };
      window.speechSynthesis.speak(u);
    });
  }, []);

  // After speaking an incoming-message prompt, auto-start mic for YES/NO response.
  // Falls back to on-screen YES/NO buttons if SpeechRecognition is unavailable/blocked.
  const speakThenListen = useCallback((text: string, onYes: () => void, onNo: () => void) => {
    if (navigator.vibrate) navigator.vibrate([500, 200, 500]);
    speak(text, () => {
      const SR = window.SpeechRecognition ?? (window as typeof window & { webkitSpeechRecognition: typeof SpeechRecognition }).webkitSpeechRecognition;
      if (!SR) { setShowVoiceFallback(true); return; }
      try {
        if (respondRecognitionRef.current) { try { respondRecognitionRef.current.stop(); } catch { /* ok */ } }
        const r = new SR();
        respondRecognitionRef.current = r;
        r.continuous = false; r.interimResults = false; r.lang = 'en-US';
        r.onresult = (e: SpeechRecognitionEvent) => {
          const t = Array.from(e.results).map(res => res[0].transcript).join(' ').toLowerCase().trim();
          if (t.includes('yes') || t.includes('ja') || t.includes('read')) { onYes(); setShowVoiceFallback(false); }
          else if (t.includes('no') || t.includes('nee') || t.includes('dismiss')) { onNo(); setShowVoiceFallback(false); }
          else { setShowVoiceFallback(true); } // unclear — show buttons
        };
        r.onerror = () => setShowVoiceFallback(true);
        r.onend = () => {}; // handled above
        r.start();
      } catch {
        setShowVoiceFallback(true);
      }
    });
  }, [speak]);

  const saveSettings = async (p?: Permissions, s?: ScheduleSettings, pr?: boolean) => {
    const fp = p ?? perms; const fs = s ?? schedule; const fpr = pr ?? proactive;
    await supabase.from('life_assistant_settings').upsert({
      device_key: deviceKey, ...fp, proactive: fpr,
      wake_up_time: fs.wake_up_time, lunch_time: fs.lunch_time,
      afternoon_time: fs.afternoon_time, evening_time: fs.evening_time,
      wake_up_on: fs.wake_up_on, lunch_on: fs.lunch_on,
      afternoon_on: fs.afternoon_on, evening_on: fs.evening_on,
      updated_at: new Date().toISOString(),
    }, { onConflict: 'device_key' });
  };

  const grantPerm = async (key: PermKey) => {
    setLoading(key);
    let granted = false;
    if (key === 'notif_ok') {
      const r = await Notification.requestPermission().catch(() => 'denied');
      granted = r === 'granted';
    } else if (key === 'mic_ok') {
      try { const st = await navigator.mediaDevices.getUserMedia({ audio: true }); st.getTracks().forEach(t => t.stop()); granted = true; } catch { granted = false; }
    } else if (key === 'location_ok') {
      await new Promise<void>(resolve =>
        navigator.geolocation.getCurrentPosition(pos => {
          granted = true;
          const lat = pos.coords.latitude; const lon = pos.coords.longitude;
          setUserLocation({ lat, lon });
          fetchIntelligence(lat, lon); // immediately fetch weather for their location
          resolve();
        }, () => resolve())
      );
    } else { granted = true; }

    if (granted) {
      const next = { ...perms, [key]: true }; setPerms(next); await saveSettings(next);
      speak(`${PERM_LABELS[key]} activated. I am now fully live.`);
    } else { speak('Permission denied. You can enable it in your browser settings.'); }
    setLoading(null);
  };

  const updateSched = (field: keyof ScheduleSettings, value: string | boolean) => {
    const next = { ...schedule, [field]: value }; setSchedule(next); saveSettings(undefined, next);
  };

  const toggleProactive = async () => {
    const next = !proactive; setProactive(next); await saveSettings(undefined, undefined, next);
    speak(next ? 'I am now fully active. I will speak to you throughout the day.' : 'Proactive mode paused.');
  };

  const now = nowMin();
  const timelineItems = [
    { time: schedule.wake_up_time,   label: 'Wake-up + weather briefing',   icon: <Coffee size={10} />,        color: '#fbbf24', on: schedule.wake_up_on },
    { time: schedule.lunch_time,     label: 'Lunch reminder + suggestion',   icon: <UtensilsCrossed size={10} />, color: '#4ade80', on: schedule.lunch_on },
    { time: schedule.afternoon_time, label: 'Afternoon check-in',            icon: <ShoppingCart size={10} />,  color: '#38bdf8', on: schedule.afternoon_on },
    { time: schedule.evening_time,   label: 'Evening wind-down + news',      icon: <Sunset size={10} />,        color: '#f97316', on: schedule.evening_on },
  ].filter(i => i.on);

  const currentTOD   = tod();
  const todColor     = { morning: '#fbbf24', noon: '#4ade80', afternoon: '#38bdf8', evening: '#f97316', night: '#818cf8' }[currentTOD];

  const TABS = [
    { key: 'live',        label: 'Live AI',     icon: <Cloud size={10} /> },
    { key: 'context',     label: 'Context',     icon: <Zap size={10} /> },
    { key: 'actions',     label: 'Actions',     icon: <ShoppingBag size={10} /> },
    { key: 'health',      label: 'Health',      icon: <Heart size={10} /> },
    { key: 'reminders',   label: 'Reminders',   icon: <Pill size={10} /> },
    { key: 'family',      label: 'Family',      icon: <Users size={10} /> },
    { key: 'schedule',    label: 'Schedule',    icon: <AlarmClock size={10} /> },
    { key: 'securechat',  label: 'Aippie Chat', icon: <MessageSquare size={10} /> },
    { key: 'gmail',       label: 'Gmail',       icon: <Mail size={10} /> },
    { key: 'holled',      label: 'Invoices',    icon: <FileText size={10} /> },
  ] as const;

  return (
    <div className="la-root">

      {/* Header */}
      <div className="la-header">
        <div className="la-header__left">
          <div className="la-status-dot" style={{ background: proactive ? '#4ade80' : '#475569', boxShadow: proactive ? '0 0 6px #4ade80' : 'none' }} />
          <span className="la-header__title">Aippie Life Assistant</span>
          <span className="la-header__badge">{activeCount}/5</span>
          {isOnline
            ? <Wifi size={10} style={{ color: '#4ade80' }} />
            : <WifiOff size={10} style={{ color: '#f87171' }} />}
        </div>
        <div className="la-header__right">
          <button className="la-icon-btn" onClick={() => {
            const t = tod(); const f = food();
            const msgs = {
              morning: `${greeting()}! I hope you slept well. For breakfast I suggest ${f}. ${intel?.weather ? `Outside it is ${intel.weather.temp} degrees, ${intel.weather.description}.` : ''}`,
              noon: `Lunch time. I suggest ${f}. Take a break.`,
              afternoon: `Good afternoon. How about ${f} as a snack? Have you done your shopping today?`,
              evening: `Good evening. For dinner I suggest ${f}. ${intel?.weather ? `It is ${intel.weather.temp} degrees outside.` : ''}`,
              night: `Time to rest. I will wake you up tomorrow morning.`,
            };
            speak(msgs[t]);
          }} title="Speak now" disabled={speaking}>
            <Zap size={13} style={{ color: '#4ade80' }} />
          </button>
          <button className="la-mute-btn" onClick={() => { setMuted(m => !m); if (!muted) { cancelRef.current = true; window.speechSynthesis?.cancel(); setSpeaking(false); } }}>
            {muted ? <VolumeX size={14} /> : <Volume2 size={14} />}
          </button>
          {onClose && (
            <button className="la-icon-btn la-icon-btn--close" onClick={onClose} title="Sluiten">
              <X size={14} />
            </button>
          )}
        </div>
      </div>

      {/* Time + weather bar */}
      <div className="la-tod-bar" style={{ borderColor: todColor + '44', background: todColor + '0d' }}>
        <span className="la-tod-label" style={{ color: todColor }}>{greeting()}</span>
        <span className="la-tod-time">{currentTime.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' })}</span>
        {intel?.weather ? (
          <span className="la-tod-food" style={{ color: todColor }}>
            <Cloud size={10} />{intel.weather.city} {intel.weather.temp}°C
          </span>
        ) : (
          <span className="la-tod-food"><UtensilsCrossed size={10} />{food()}</span>
        )}
      </div>

      {/* ── PART 2: ARM / DISARM button — FIRST element ─────────────────── */}
      <div style={{ display: 'flex', justifyContent: 'center', padding: '14px 18px 8px' }}>
        <button
          onClick={handleArm}
          disabled={armingInProgress}
          style={{
            display: 'flex', alignItems: 'center', gap: 14,
            height: 64,
            padding: '0 28px',
            background: armed
              ? 'linear-gradient(135deg, rgba(74,222,128,0.18), rgba(34,197,94,0.12))'
              : 'linear-gradient(135deg, rgba(100,116,139,0.14), rgba(71,85,105,0.09))',
            border: `2px solid ${armed ? 'rgba(74,222,128,0.55)' : 'rgba(100,116,139,0.3)'}`,
            borderRadius: 16,
            cursor: armingInProgress ? 'wait' : 'pointer',
            width: '100%', maxWidth: 400,
            boxShadow: armed ? '0 0 32px rgba(74,222,128,0.22), 0 0 8px rgba(74,222,128,0.1)' : 'none',
            animation: armed ? 'la-arm-pulse 2.5s ease-in-out infinite' : 'none',
            transition: 'all 0.35s ease',
          }}
        >
          <div style={{ position: 'relative', flexShrink: 0 }}>
            {armed
              ? <Shield size={26} style={{ color: '#4ade80', filter: 'drop-shadow(0 0 8px #4ade80)' }} />
              : <ShieldOff size={26} style={{ color: '#475569' }} />}
            {armed && <span style={{ position: 'absolute', top: -3, right: -3, width: 9, height: 9, borderRadius: '50%', background: '#4ade80', boxShadow: '0 0 8px #4ade80', animation: 'la-pulse 1.2s ease-in-out infinite' }} />}
          </div>
          <div style={{ textAlign: 'left', flex: 1 }}>
            <div style={{ fontSize: 15, fontWeight: 900, color: armed ? '#4ade80' : '#64748b', letterSpacing: '0.1em', lineHeight: 1.2 }}>
              {armingInProgress ? 'ARMING…' : armed ? 'AI ARMED' : 'ARM AI'}
            </div>
            <div style={{ fontSize: 11, color: armed ? 'rgba(74,222,128,0.7)' : '#475569', fontWeight: 500, marginTop: 2 }}>
              {armed ? 'I am watching over you, Elvin' : 'Tap to activate full AI control'}
            </div>
          </div>
          {armed && (
            <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 4, flexShrink: 0 }}>
              {voiceListening && <Mic2 size={14} style={{ color: '#4ade80' }} />}
              <Activity size={14} style={{ color: '#4ade80' }} />
              <span style={{ fontSize: 9, color: 'rgba(74,222,128,0.6)', fontWeight: 700, letterSpacing: '0.06em' }}>LIVE</span>
            </div>
          )}
        </button>
      </div>

      {/* Speaking bubble */}
      {currentMsg && (
        <div className={`la-speech-bubble${speaking ? ' la-speech-bubble--active' : ''}`}>
          <img src="/Jouw_alineatekst_(2).png" alt="Aippie"
            className={`la-speech-avatar${speaking ? ' la-speech-avatar--pulse' : ''}`}
            onError={e => { (e.currentTarget as HTMLImageElement).src = 'https://images.pexels.com/photos/1858175/pexels-photo-1858175.jpeg?auto=compress&cs=tinysrgb&w=80&h=80&fit=crop&crop=faces'; }} />
          <div className="la-speech-content">
            <div className="la-speech-label">{speaking ? <><span className="la-speech-dot" />Aippie is speaking…</> : 'Aippie said:'}</div>
            <div className="la-speech-text">{currentMsg}</div>
          </div>
        </div>
      )}

      {/* Proactive toggle */}
      <div className="la-proactive-row">
        <div className="la-proactive-row__left">
          {proactive ? <BellRing size={14} style={{ color: '#4ade80' }} /> : <BellOff size={14} style={{ color: '#475569' }} />}
          <div>
            <div className="la-proactive-label">Always-on mode {proactive ? '— LIVE' : '— paused'}</div>
            <div className="la-proactive-sub">
              {proactive
                ? 'Aippie is active — speaks at alarms, reads messages, watches the news'
                : 'Tap the toggle to activate Aippie'}
            </div>
          </div>
        </div>
        <button className={`la-toggle${proactive ? ' la-toggle--on' : ''}`} onClick={toggleProactive}>
          <span className="la-toggle__knob" />
        </button>
      </div>

      {/* Onboarding — only show if truly nothing configured */}
      {!proactive && (
        <div className="la-onboard-banner">
          <div className="la-onboard-title">Aippie is paused</div>
          <div className="la-onboard-sub">Tap the toggle above to activate Aippie. She will speak to you immediately and stay active all day.</div>
        </div>
      )}

      {/* ── UNIFIED FEED — single scrollable view, no tabs ─────────────── */}
      <div style={{ flex: 1, overflowY: 'auto', display: 'flex', flexDirection: 'column', gap: 0 }}>

      {/* Live AI section */}
      <div className="la-section">
        <IntelligencePanel intel={intel} loading={intelLoading} onRefresh={() => fetchIntelligence()} speak={speak} />

        {liveEvents.length > 0 && (
          <>
            <div className="la-section__title" style={{ marginTop: 14 }}>
              <Bell size={13} style={{ color: '#a78bfa' }} />Aippie spoke today
            </div>
              <div className="la-events-list">
                {liveEvents.slice(0, 6).map(ev => (
                  <div key={ev.id} className="la-recent-event">
                    <Clock size={10} style={{ color: '#475569', flexShrink: 0 }} /><span>{ev.message}</span>
                  </div>
                ))}
              </div>
            </>
          )}

          {/* Permissions */}
          <div className="la-section__title" style={{ marginTop: 14 }}>
            <ShieldCheck size={13} style={{ color: '#4ade80' }} />Permissions — allow once, active forever
          </div>
          <div className="la-perms-grid">
            <PermCard icon={<Bell size={14} />} label="Notifications" desc="Push notifications at alarm times — even when app is in background"
              granted={perms.notif_ok} loading={loading === 'notif_ok'} onGrant={() => grantPerm('notif_ok')} />
            <PermCard icon={<Mic size={14} />} label="Microphone" desc="Speak to Aippie by voice"
              granted={perms.mic_ok} loading={loading === 'mic_ok'} onGrant={() => grantPerm('mic_ok')} />
            <PermCard icon={<MapPin size={14} />} label="Location" desc="Real weather for your exact location — updated live"
              granted={perms.location_ok} loading={loading === 'location_ok'} onGrant={() => grantPerm('location_ok')} />
            <PermCard icon={<Mail size={14} />} label="Email" desc="Aippie reads and summarises emails aloud"
              granted={perms.email_ok} loading={loading === 'email_ok'} onGrant={() => grantPerm('email_ok')} />
            <PermCard icon={<Calendar size={14} />} label="Calendar" desc="Appointments and reminders"
              granted={perms.calendar_ok} loading={loading === 'calendar_ok'} onGrant={() => grantPerm('calendar_ok')} />
          </div>

          {/* What Aippie does */}
          <div className="la-capabilities" style={{ marginTop: 14 }}>
            {[
              { icon: <AlarmClock size={12} />, label: 'Wake-up alarm with live weather briefing', color: '#fbbf24' },
              { icon: <Newspaper size={12} />,  label: 'Real-time news headlines every morning',   color: '#a78bfa' },
              { icon: <Cloud size={12} />,       label: 'Live weather — always knows your location', color: '#38bdf8' },
              { icon: <UtensilsCrossed size={12} />, label: 'Food suggestion at every meal',         color: '#4ade80' },
              { icon: <MessageSquare size={12} />,   label: 'Reads WhatsApp messages aloud instantly', color: '#34d399' },
              { icon: <ShoppingCart size={12} />,    label: 'Afternoon shopping + water reminder',   color: '#38bdf8' },
              { icon: <Pill size={12} />,        label: 'Medication reminders',                      color: '#f97316' },
              { icon: <Moon size={12} />,        label: 'Evening summary and good-night message',    color: '#818cf8' },
            ].map((c, i) => (
              <div key={i} className="la-cap-item">
                <span style={{ color: c.color }}>{c.icon}</span><span>{c.label}</span>
              </div>
            ))}
          </div>
        </div>

      {/* ── Divider ── */}
      <div style={{ height: 1, background: 'rgba(30,41,59,0.8)', margin: '0 16px' }} />

      {/* Schedule section */}
      <div className="la-section">
          <div className="la-section__title" style={{ justifyContent: 'space-between' }}>
            <span style={{ display: 'flex', alignItems: 'center', gap: 6 }}><AlarmClock size={13} style={{ color: '#fbbf24' }} />Daily alarms</span>
            <button className="la-settings-btn" onClick={() => setShowSched(s => !s)}>
              <Settings size={12} />Set times {showSched ? <ChevronUp size={11} /> : <ChevronDown size={11} />}
            </button>
          </div>
          <div className="la-timeline">
            {timelineItems.map((item, i) => {
              const mins = toMin(item.time);
              return <TimelineItem key={i} time={item.time} label={item.label} icon={item.icon}
                color={item.color} active={Math.abs(mins - now) <= 30} upcoming={mins > now && mins - now <= 120} />;
            })}
          </div>
          {showSched && (
            <div className="la-schedule-settings">
              {([
                { tk: 'wake_up_time',   ok: 'wake_up_on',   label: 'Wake-up',   icon: <Coffee size={11} /> },
                { tk: 'lunch_time',     ok: 'lunch_on',     label: 'Lunch',     icon: <UtensilsCrossed size={11} /> },
                { tk: 'afternoon_time', ok: 'afternoon_on', label: 'Afternoon', icon: <ShoppingCart size={11} /> },
                { tk: 'evening_time',   ok: 'evening_on',   label: 'Evening',   icon: <Sunset size={11} /> },
              ] as { tk: keyof ScheduleSettings; ok: keyof ScheduleSettings; label: string; icon: React.ReactNode }[]).map(row => (
                <div key={row.tk} className="la-sched-row">
                  <span className="la-sched-icon">{row.icon}</span>
                  <span className="la-sched-label">{row.label}</span>
                  <input type="time" className="la-time-input" value={schedule[row.tk] as string}
                    onChange={e => updateSched(row.tk, e.target.value)} />
                  <button className={`la-small-toggle${schedule[row.ok] ? ' la-small-toggle--on' : ''}`}
                    onClick={() => updateSched(row.ok, !schedule[row.ok])}>
                    <span className="la-small-toggle__knob" />
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>

      {/* ── Divider ── */}
      <div style={{ height: 1, background: 'rgba(30,41,59,0.8)', margin: '0 16px' }} />

      {/* SecureChat section */}
      <div className="la-section"><SecureChatInbox speak={speak} familyPins={familyPins} onIncoming={(sender, content, isFamily) => {
        setIncomingPrompt({ sender, content });
        if (isFamily) {
          speakThenListen(
            `Important: ${sender} is trying to reach you. This is a priority contact. Say yes to read or no to dismiss.`,
            () => { speak(`${sender} says: ${content}`); setIncomingPrompt(null); },
            () => setIncomingPrompt(null),
          );
        } else {
          speakThenListen(
            `Elvin, incoming message from ${sender}. Say yes to read it aloud, or no to dismiss.`,
            () => { speak(`${sender} says: ${content}`); setIncomingPrompt(null); },
            () => setIncomingPrompt(null),
          );
        }
      }} /></div>

      {/* ── Divider ── */}
      <div style={{ height: 1, background: 'rgba(30,41,59,0.8)', margin: '0 16px' }} />

      {/* Gmail section */}
      <div className="la-section"><GmailPanel speak={speak} /></div>

      {/* ── Divider ── */}
      <div style={{ height: 1, background: 'rgba(30,41,59,0.8)', margin: '0 16px' }} />

      {/* Holled section */}
      <div className="la-section"><HolledPanel speak={speak} /></div>

      {/* ── Divider ── */}
      <div style={{ height: 1, background: 'rgba(30,41,59,0.8)', margin: '0 16px' }} />

      {/* ── PART 4: Quick Actions panel ──────────────────────────────────── */}
      <div className="la-section">
          <div className="la-section__title"><ShoppingBag size={13} style={{ color: '#38bdf8' }} />Daily Life Actions</div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            {/* Shopping list */}
            <button onClick={() => { setShowShoppingInput(s => !s); logFeatureUse('shopping_list'); }}
              style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '12px 14px', background: '#0f172a', border: '1px solid #1e293b', borderRadius: 10, color: '#f1f5f9', cursor: 'pointer', textAlign: 'left' }}>
              <ShoppingCart size={16} style={{ color: '#38bdf8' }} />
              <div><div style={{ fontSize: 12, fontWeight: 600 }}>Add to shopping list</div><div style={{ fontSize: 10, color: '#64748b' }}>Saved to your Aippie list</div></div>
            </button>
            {showShoppingInput && (
              <div style={{ display: 'flex', gap: 8 }}>
                <input placeholder="Item to add…" value={shoppingItem} onChange={e => setShoppingItem(e.target.value)}
                  onKeyDown={e => {
                    if (e.key === 'Enter' && shoppingItem.trim()) {
                      supabase.from('shopping_list').insert({ device_key: deviceKey, item: shoppingItem.trim() }).then(() => {});
                      speak(`${shoppingItem} added to your shopping list.`); setShoppingItem(''); setShowShoppingInput(false);
                    }
                  }}
                  style={{ flex: 1, padding: '9px 12px', background: '#030d1a', border: '1px solid rgba(56,189,248,0.25)', borderRadius: 9, color: '#f1f5f9', fontSize: 12, outline: 'none' }} />
                <button onClick={() => { if (!shoppingItem.trim()) return; supabase.from('shopping_list').insert({ device_key: deviceKey, item: shoppingItem.trim() }).then(() => {}); speak(`${shoppingItem} added.`); setShoppingItem(''); setShowShoppingInput(false); }}
                  style={{ padding: '9px 12px', background: 'rgba(56,189,248,0.1)', border: '1px solid rgba(56,189,248,0.2)', borderRadius: 9, color: '#38bdf8', cursor: 'pointer' }}>
                  <Send size={12} />
                </button>
              </div>
            )}
            {/* Set reminder */}
            <button onClick={() => { setShowReminderInput(s => !s); logFeatureUse('set_reminder'); }}
              style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '12px 14px', background: '#0f172a', border: '1px solid #1e293b', borderRadius: 10, color: '#f1f5f9', cursor: 'pointer', textAlign: 'left' }}>
              <AlarmClock size={16} style={{ color: '#fbbf24' }} />
              <div><div style={{ fontSize: 12, fontWeight: 600 }}>Set reminder</div><div style={{ fontSize: 10, color: '#64748b' }}>Time + message</div></div>
            </button>
            {showReminderInput && (
              <div style={{ display: 'flex', flexDirection: 'column', gap: 7 }}>
                <input type="time" value={reminderTime} onChange={e => setReminderTime(e.target.value)}
                  style={{ padding: '9px 12px', background: '#030d1a', border: '1px solid rgba(251,191,36,0.25)', borderRadius: 9, color: '#fbbf24', fontSize: 12, outline: 'none' }} />
                <div style={{ display: 'flex', gap: 8 }}>
                  <input placeholder="Reminder message…" value={reminderText} onChange={e => setReminderText(e.target.value)}
                    style={{ flex: 1, padding: '9px 12px', background: '#030d1a', border: '1px solid rgba(251,191,36,0.25)', borderRadius: 9, color: '#f1f5f9', fontSize: 12, outline: 'none' }} />
                  <button onClick={() => {
                    if (!reminderText.trim() || !reminderTime) return;
                    const ms = msUntil(reminderTime);
                    setTimeout(() => { if (!muted) speak(reminderText); if (navigator.vibrate) navigator.vibrate([300, 100, 300]); }, ms);
                    speak(`Reminder set for ${reminderTime}: ${reminderText}`);
                    setReminderText(''); setReminderTime(''); setShowReminderInput(false);
                  }} style={{ padding: '9px 12px', background: 'rgba(251,191,36,0.1)', border: '1px solid rgba(251,191,36,0.2)', borderRadius: 9, color: '#fbbf24', cursor: 'pointer' }}>
                    <CheckCircle2 size={12} />
                  </button>
                </div>
              </div>
            )}
            {/* Read all messages */}
            <button onClick={() => { setActiveTab('securechat'); speak('Opening your messages.'); logFeatureUse('read_messages'); }}
              style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '12px 14px', background: '#0f172a', border: '1px solid #1e293b', borderRadius: 10, color: '#f1f5f9', cursor: 'pointer', textAlign: 'left' }}>
              <MessageSquare size={16} style={{ color: '#22d3ee' }} />
              <div><div style={{ fontSize: 12, fontWeight: 600 }}>Read all messages</div><div style={{ fontSize: 10, color: '#64748b' }}>AI reads all unread aloud</div></div>
            </button>
            {/* What is my day */}
            <button onClick={() => {
              logFeatureUse('daily_briefing');
              const d = new Date().toLocaleDateString('en-GB', { weekday: 'long', day: 'numeric', month: 'long' });
              const w = intel?.weather ? `It is ${intel.weather.temp}°C, ${intel.weather.description}.` : '';
              const n = intel?.news[0] ? `Top news: ${intel.news[0].title}.` : '';
              speak(`${greeting()} Elvin. Today is ${d}. ${w} ${n} Your schedule: ${timelineItems.map(i => `${i.label} at ${i.time}`).join(', ')}.`);
            }} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '12px 14px', background: '#0f172a', border: '1px solid #1e293b', borderRadius: 10, color: '#f1f5f9', cursor: 'pointer', textAlign: 'left' }}>
              <Cloud size={16} style={{ color: '#a78bfa' }} />
              <div><div style={{ fontSize: 12, fontWeight: 600 }}>What is my day?</div><div style={{ fontSize: 10, color: '#64748b' }}>Full spoken briefing</div></div>
            </button>
            {/* Call someone */}
            <button onClick={() => { setActiveTab('securechat'); speak('Opening your contacts.'); logFeatureUse('call_contact'); }}
              style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '12px 14px', background: '#0f172a', border: '1px solid #1e293b', borderRadius: 10, color: '#f1f5f9', cursor: 'pointer', textAlign: 'left' }}>
              <MessageSquare size={16} style={{ color: '#4ade80' }} />
              <div><div style={{ fontSize: 12, fontWeight: 600 }}>Call someone</div><div style={{ fontSize: 10, color: '#64748b' }}>Opens SecureChat contacts</div></div>
            </button>
          </div>
        </div>

      {/* ── Divider ── */}
      <div style={{ height: 1, background: 'rgba(30,41,59,0.8)', margin: '0 16px' }} />

      {/* ── PART 8: Health panel ──────────────────────────────────────────── */}
      <div className="la-section">
          <div className="la-section__title"><Heart size={13} style={{ color: '#f97316' }} />Health Guardian</div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            <div style={{ background: '#0f172a', border: '1px solid #1e293b', borderRadius: 10, padding: '14px' }}>
              <div style={{ fontSize: 11, fontWeight: 700, color: '#f97316', marginBottom: 10 }}>Automatic health reminders</div>
              {[
                { icon: <Droplets size={14} />, label: 'Water reminder', sub: 'Every 2 hours', color: '#38bdf8' },
                { icon: <UtensilsCrossed size={14} />, label: 'Meal reminder', sub: 'Every 4 hours', color: '#4ade80' },
                { icon: <Moon size={14} />, label: 'Late night alert', sub: 'After 22:00', color: '#818cf8' },
                { icon: <Activity size={14} />, label: 'Morning check-in', sub: 'At wake-up time', color: '#fbbf24' },
              ].map((r, i) => (
                <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '8px 0', borderBottom: i < 3 ? '1px solid rgba(30,41,59,0.8)' : 'none' }}>
                  <span style={{ color: r.color }}>{r.icon}</span>
                  <div><div style={{ fontSize: 11, fontWeight: 600, color: '#f1f5f9' }}>{r.label}</div><div style={{ fontSize: 10, color: '#64748b' }}>{r.sub}</div></div>
                  <div style={{ marginLeft: 'auto', width: 7, height: 7, borderRadius: '50%', background: armed ? '#4ade80' : '#475569', boxShadow: armed ? '0 0 6px #4ade80' : 'none' }} />
                </div>
              ))}
            </div>
            <button onClick={() => { speak('How are you feeling today? Rate your energy from 1 to 5.'); setShowEnergyPrompt(true); }}
              style={{ padding: '12px 0', background: 'rgba(249,115,22,0.08)', border: '1px solid rgba(249,115,22,0.2)', borderRadius: 10, color: '#f97316', fontSize: 12, fontWeight: 600, cursor: 'pointer' }}>
              <Activity size={12} style={{ display: 'inline', marginRight: 8 }} />Morning energy check
            </button>
            <button onClick={() => { speak('Time to drink water. Stay hydrated!'); if (navigator.vibrate) navigator.vibrate(200); }}
              style={{ padding: '12px 0', background: 'rgba(56,189,248,0.06)', border: '1px solid rgba(56,189,248,0.15)', borderRadius: 10, color: '#38bdf8', fontSize: 12, fontWeight: 600, cursor: 'pointer' }}>
              <Droplets size={12} style={{ display: 'inline', marginRight: 8 }} />Water reminder now
            </button>
          </div>
        </div>

      {/* ── Divider ── */}
      <div style={{ height: 1, background: 'rgba(30,41,59,0.8)', margin: '0 16px' }} />

      {/* ── PART 12: Family Circuit panel ────────────────────────────────── */}
      <div className="la-section">
          <div className="la-section__title"><Users size={13} style={{ color: '#a78bfa' }} />Family Circuit</div>
          <div style={{ fontSize: 11, color: '#64748b', marginBottom: 12, lineHeight: 1.5 }}>
            Messages from family contacts trigger a special priority alert with extended vibration.
          </div>
          {familyPins.length === 0 ? (
            <div style={{ textAlign: 'center', padding: '24px 0', color: '#475569', fontSize: 12 }}>
              No family contacts added yet.
            </div>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8, marginBottom: 12 }}>
              {familyPins.map(pin => (
                <div key={pin} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '10px 12px', background: '#0f172a', border: '1px solid rgba(167,139,250,0.2)', borderRadius: 10 }}>
                  <Star size={14} style={{ color: '#a78bfa' }} />
                  <span style={{ fontSize: 12, color: '#f1f5f9', flex: 1 }}>PIN: {pin}</span>
                  <button onClick={() => { const next = familyPins.filter(p => p !== pin); setFamilyPins(next); localStorage.setItem('aippie_family_pins', JSON.stringify(next)); }}
                    style={{ background: 'none', border: 'none', color: '#f87171', cursor: 'pointer', padding: 4 }}>
                    <X size={12} />
                  </button>
                </div>
              ))}
            </div>
          )}
          <div style={{ display: 'flex', gap: 8 }}>
            <input placeholder="Enter contact PIN…" id="family-pin-input"
              style={{ flex: 1, padding: '10px 12px', background: '#0f172a', border: '1px solid rgba(167,139,250,0.25)', borderRadius: 9, color: '#f1f5f9', fontSize: 12, outline: 'none' }}
              onKeyDown={e => {
                if (e.key !== 'Enter') return;
                const val = (e.currentTarget as HTMLInputElement).value.trim();
                if (!val || familyPins.includes(val)) return;
                const next = [...familyPins, val]; setFamilyPins(next); localStorage.setItem('aippie_family_pins', JSON.stringify(next));
                (e.currentTarget as HTMLInputElement).value = '';
                speak(`${val} added as a family contact.`);
              }} />
            <button onClick={() => {
              const inp = document.getElementById('family-pin-input') as HTMLInputElement;
              const val = inp?.value.trim();
              if (!val || familyPins.includes(val)) return;
              const next = [...familyPins, val]; setFamilyPins(next); localStorage.setItem('aippie_family_pins', JSON.stringify(next));
              if (inp) inp.value = ''; speak(`${val} added as a family contact.`);
            }} style={{ padding: '10px 14px', background: 'rgba(167,139,250,0.1)', border: '1px solid rgba(167,139,250,0.2)', borderRadius: 9, color: '#a78bfa', cursor: 'pointer' }}>
              <Star size={12} />
            </button>
          </div>
        </div>

      {/* ── Divider ── */}
      <div style={{ height: 1, background: 'rgba(30,41,59,0.8)', margin: '0 16px' }} />

      {/* AI Context panel */}
      <div className="la-section">
          <div className="la-section__title"><Zap size={13} style={{ color: '#fbbf24' }} />AI Context</div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            {/* Greeting + time */}
            <div style={{ background: '#0f172a', border: '1px solid #1e293b', borderRadius: 10, padding: '12px 14px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <div>
                <div style={{ fontSize: 11, color: '#94a3b8' }}>Current time</div>
                <div style={{ fontSize: 16, fontWeight: 700, color: '#f1f5f9' }}>{currentTime.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' })}</div>
                <div style={{ fontSize: 11, color: '#64748b' }}>{greeting()}, Elvin</div>
              </div>
              <Clock size={28} style={{ color: '#fbbf2444' }} />
            </div>
            {/* Weather */}
            {intel?.weather && (
              <div style={{ background: '#0f172a', border: '1px solid #1e293b', borderRadius: 10, padding: '12px 14px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <div>
                  <div style={{ fontSize: 11, color: '#94a3b8' }}>Weather — {intel.weather.city}</div>
                  <div style={{ fontSize: 16, fontWeight: 700, color: '#38bdf8' }}>{intel.weather.temp}°C</div>
                  <div style={{ fontSize: 11, color: '#64748b', textTransform: 'capitalize' }}>{intel.weather.description} · {intel.weather.humidity}% humidity</div>
                </div>
                <Cloud size={28} style={{ color: '#38bdf844' }} />
              </div>
            )}
            {/* Next alarm */}
            {timelineItems.length > 0 && (() => {
              const next = timelineItems.find(i => toMin(i.time) > nowMin()) ?? timelineItems[0];
              const diff = toMin(next.time) - nowMin();
              const label = diff > 0 ? `${Math.floor(diff / 60)}h ${diff % 60}m` : 'Soon';
              return (
                <div style={{ background: '#0f172a', border: '1px solid #1e293b', borderRadius: 10, padding: '12px 14px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <div>
                    <div style={{ fontSize: 11, color: '#94a3b8' }}>Next alarm</div>
                    <div style={{ fontSize: 15, fontWeight: 700, color: '#a78bfa' }}>{next.label}</div>
                    <div style={{ fontSize: 11, color: '#64748b' }}>at {next.time} · in {label}</div>
                  </div>
                  <AlarmClock size={28} style={{ color: '#a78bfa44' }} />
                </div>
              );
            })()}
            {/* Battery */}
            <div style={{ background: '#0f172a', border: '1px solid #1e293b', borderRadius: 10, padding: '12px 14px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <div>
                <div style={{ fontSize: 11, color: '#94a3b8' }}>Battery</div>
                <div style={{ fontSize: 16, fontWeight: 700, color: batteryLevel !== null && batteryLevel < 20 ? '#f87171' : '#4ade80' }}>
                  {batteryLevel !== null ? `${batteryLevel}%` : 'Unknown'}
                </div>
              </div>
              <div style={{ width: 32, height: 16, border: '2px solid #1e293b', borderRadius: 4, position: 'relative', overflow: 'hidden' }}>
                <div style={{ position: 'absolute', left: 0, top: 0, bottom: 0, width: `${batteryLevel ?? 50}%`, background: batteryLevel !== null && batteryLevel < 20 ? '#f87171' : '#4ade80', borderRadius: 2 }} />
              </div>
            </div>
            {/* Network */}
            <div style={{ background: '#0f172a', border: '1px solid #1e293b', borderRadius: 10, padding: '12px 14px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <div>
                <div style={{ fontSize: 11, color: '#94a3b8' }}>Network</div>
                <div style={{ fontSize: 14, fontWeight: 700, color: isOnline ? '#4ade80' : '#f87171' }}>{isOnline ? 'Online' : 'Offline'}</div>
              </div>
              {isOnline ? <Wifi size={24} style={{ color: '#4ade8044' }} /> : <WifiOff size={24} style={{ color: '#f8717144' }} />}
            </div>
          </div>
        </div>

      {/* ── Divider ── */}
      <div style={{ height: 1, background: 'rgba(30,41,59,0.8)', margin: '0 16px' }} />

      {/* Smart Reminders panel */}
      <div className="la-section">
          <div className="la-section__title"><Pill size={13} style={{ color: '#f97316' }} />Smart Reminders</div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            {reminders.map(r => (
              <div key={r.id} style={{
                background: r.confirmed ? 'rgba(74,222,128,0.04)' : '#0f172a',
                border: `1px solid ${r.confirmed ? 'rgba(74,222,128,0.2)' : '#1e293b'}`,
                borderRadius: 10, padding: '12px 14px',
                display: 'flex', alignItems: 'center', gap: 12,
                opacity: r.confirmed ? 0.6 : 1,
              }}>
                <span style={{ fontSize: 18 }}>
                  {r.type === 'medication' ? '💊' : r.type === 'meeting' ? '📅' : r.type === 'tax' ? '🧾' : '📈'}
                </span>
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: 12, fontWeight: 600, color: '#f1f5f9' }}>{r.label}</div>
                  <div style={{ fontSize: 10, color: '#64748b' }}>
                    {r.type === 'medication' ? 'Medication reminder' : r.type === 'meeting' ? `Meeting alert · ${r.time}` : r.type === 'tax' ? 'Tax deadline warning' : 'Trading alert'}
                  </div>
                </div>
                {!r.confirmed && (
                  <button
                    onClick={() => {
                      setReminders(prev => prev.map(x => x.id === r.id ? { ...x, confirmed: true } : x));
                      speak(`${r.label} confirmed.`);
                    }}
                    style={{ padding: '5px 12px', background: 'rgba(74,222,128,0.1)', border: '1px solid rgba(74,222,128,0.2)', borderRadius: 8, color: '#4ade80', fontSize: 10, fontWeight: 600, cursor: 'pointer', whiteSpace: 'nowrap' }}
                  >
                    Confirm
                  </button>
                )}
                {r.confirmed && <CheckCircle2 size={14} style={{ color: '#4ade80', flexShrink: 0 }} />}
              </div>
            ))}
            <button
              onClick={() => {
                const id = uid();
                setReminders(prev => [...prev, { id, type: 'medication', label: 'Custom reminder', time: new Date().toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' }), confirmed: false }]);
              }}
              style={{ padding: '9px 0', background: 'rgba(249,115,22,0.06)', border: '1px dashed rgba(249,115,22,0.2)', borderRadius: 10, color: '#f97316', fontSize: 11, fontWeight: 600, cursor: 'pointer' }}
            >
              + Add Reminder
            </button>
          </div>
        </div>

      </div>

      {/* Feature 4: PIN alert modal */}
      {showPinModal?.show && (
        <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.92)', zIndex: 9999, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 24 }}>
          <div style={{ background: '#0f172a', border: '1px solid rgba(34,211,238,0.3)', borderRadius: 16, padding: 28, width: '100%', maxWidth: 360, boxShadow: '0 0 60px rgba(34,211,238,0.12)' }}>
            <div style={{ textAlign: 'center', marginBottom: 20 }}>
              <div style={{ width: 52, height: 52, borderRadius: '50%', background: 'rgba(34,211,238,0.1)', border: '1px solid rgba(34,211,238,0.25)', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 12px' }}>
                <Lock size={22} style={{ color: '#22d3ee' }} />
              </div>
              <div style={{ fontSize: 15, fontWeight: 700, color: '#f1f5f9', marginBottom: 4 }}>New message from {showPinModal.sender}</div>
              <div style={{ fontSize: 11, color: '#64748b' }}>Enter your PIN to read this message</div>
            </div>
            <input
              type="password"
              inputMode="numeric"
              maxLength={6}
              autoFocus
              placeholder="6-digit PIN"
              value={pinModalInput}
              onChange={e => { setPinModalInput(e.target.value.replace(/\D/g,'').slice(0,6)); setPinModalError(''); }}
              style={{ width: '100%', padding: '11px 14px', background: '#0a0f1e', border: `1px solid ${pinModalError ? 'rgba(248,113,113,0.5)' : 'rgba(34,211,238,0.2)'}`, borderRadius: 10, color: '#f1f5f9', fontSize: 20, letterSpacing: '0.3em', textAlign: 'center', outline: 'none', boxSizing: 'border-box', marginBottom: 8 }}
              onKeyDown={e => {
                if (e.key === 'Enter' && pinModalInput.length >= 4) {
                  // Demo PIN check — in production compare to fetched profile PIN
                  if (pinModalInput === '1234' || pinModalInput.length >= 4) {
                    speak(`Bericht van ${showPinModal!.sender}: ${showPinModal!.content}`);
                    setQuickReplyTarget(showPinModal!.sender);
                    setShowPinModal(null); setPinModalInput(''); setPinModalError('');
                  } else {
                    if (navigator.vibrate) navigator.vibrate([100, 50, 100, 50, 100]);
                    setPinModalError('Incorrect PIN. Try again.');
                  }
                }
              }}
            />
            {pinModalError && <div style={{ fontSize: 10, color: '#f87171', marginBottom: 8, textAlign: 'center' }}>{pinModalError}</div>}
            <div style={{ display: 'flex', gap: 8, marginTop: 4 }}>
              <button onClick={() => { setShowPinModal(null); setPinModalInput(''); setPinModalError(''); }}
                style={{ flex: 1, padding: '10px 0', background: 'rgba(248,113,113,0.06)', border: '1px solid rgba(248,113,113,0.15)', borderRadius: 10, color: '#f87171', fontSize: 12, cursor: 'pointer' }}>
                Dismiss
              </button>
              <button
                onClick={() => {
                  if (pinModalInput === '1234' || pinModalInput.length >= 4) {
                    speak(`Bericht van ${showPinModal!.sender}: ${showPinModal!.content}`);
                    setQuickReplyTarget(showPinModal!.sender);
                    setShowPinModal(null); setPinModalInput(''); setPinModalError('');
                  } else {
                    if (navigator.vibrate) navigator.vibrate([100, 50, 100, 50, 100]);
                    setPinModalError('Incorrect PIN. Try again.');
                  }
                }}
                style={{ flex: 1, padding: '10px 0', background: 'rgba(34,211,238,0.1)', border: '1px solid rgba(34,211,238,0.25)', borderRadius: 10, color: '#22d3ee', fontSize: 12, fontWeight: 600, cursor: 'pointer' }}>
                <Lock size={12} style={{ display: 'inline', marginRight: 5 }} />Unlock
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Feature 5: Quick reply panel (shown after reading a message) */}
      {quickReplyTarget && (
        <div style={{ position: 'fixed', bottom: 0, left: 0, right: 0, background: '#0f172a', border: '1px solid rgba(34,211,238,0.2)', borderRadius: '16px 16px 0 0', padding: '16px 16px 24px', zIndex: 8000 }}>
          <div style={{ fontSize: 12, fontWeight: 700, color: '#94a3b8', marginBottom: 10 }}>Quick reply to {quickReplyTarget}</div>
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: 7, marginBottom: 12 }}>
            {["I'll call you back", "On my way", "Send me the code", "Got it!", "Give me 5 minutes"].map(msg => (
              <button key={msg} onClick={() => { setCustomReplyText(msg); }}
                style={{ padding: '6px 12px', background: 'rgba(34,211,238,0.06)', border: '1px solid rgba(34,211,238,0.15)', borderRadius: 20, color: '#22d3ee', fontSize: 11, cursor: 'pointer', whiteSpace: 'nowrap' }}>
                {msg}
              </button>
            ))}
          </div>
          <div style={{ display: 'flex', gap: 8 }}>
            <input
              placeholder="Custom reply…"
              value={customReplyText}
              onChange={e => setCustomReplyText(e.target.value)}
              style={{ flex: 1, padding: '9px 12px', background: '#0a0f1e', border: '1px solid rgba(100,116,139,0.3)', borderRadius: 10, color: '#f1f5f9', fontSize: 12, outline: 'none' }}
              onKeyDown={e => { if (e.key === 'Enter' && customReplyText.trim()) { speak(`Sending: ${customReplyText}`); setQuickReplyTarget(null); setCustomReplyText(''); }}}
            />
            <button
              onClick={() => { if (customReplyText.trim()) { speak(`Sending: ${customReplyText}`); setQuickReplyTarget(null); setCustomReplyText(''); }}}
              style={{ padding: '9px 14px', background: 'rgba(34,211,238,0.1)', border: '1px solid rgba(34,211,238,0.2)', borderRadius: 10, color: '#22d3ee', cursor: 'pointer' }}>
              <Send size={14} />
            </button>
            <button onClick={() => { setQuickReplyTarget(null); setCustomReplyText(''); }}
              style={{ padding: '9px 10px', background: 'rgba(100,116,139,0.1)', border: '1px solid rgba(100,116,139,0.2)', borderRadius: 10, color: '#64748b', cursor: 'pointer' }}>
              <X size={14} />
            </button>
          </div>
        </div>
      )}

      <div className="la-trust-footer">
        <ShieldCheck size={10} />
        <span>All data stored securely · GDPR-compliant · AIPPIETAX S.A.</span>
      </div>

      {/* ── PART 3: Incoming message YES/NO prompt ─────────────────────── */}
      {incomingPrompt && (
        <div style={{ position: 'fixed', bottom: 80, left: 16, right: 16, background: '#0f172a', border: '1px solid rgba(34,211,238,0.3)', borderRadius: 14, padding: '16px 18px', zIndex: 9500, boxShadow: '0 0 40px rgba(34,211,238,0.1)' }}>
          <div style={{ fontSize: 12, fontWeight: 700, color: '#f1f5f9', marginBottom: 6 }}>
            <MessageSquare size={12} style={{ display: 'inline', marginRight: 6, color: '#22d3ee' }} />
            Message from {incomingPrompt.sender}
          </div>
          {showVoiceFallback ? (
            <>
              <div style={{ fontSize: 11, color: '#22d3ee', marginBottom: 12, display: 'flex', alignItems: 'center', gap: 6 }}>
                <Mic2 size={11} />Voice recognition blocked — tap to respond:
              </div>
              <div style={{ display: 'flex', gap: 8 }}>
                <button onClick={() => { speak(`${incomingPrompt.sender} says: ${incomingPrompt.content}`); setIncomingPrompt(null); setShowVoiceFallback(false); }}
                  style={{ flex: 1, padding: '11px 0', background: 'rgba(34,211,238,0.12)', border: '1px solid rgba(34,211,238,0.35)', borderRadius: 9, color: '#22d3ee', fontSize: 13, fontWeight: 800, cursor: 'pointer' }}>
                  YES — Read it
                </button>
                <button onClick={() => { setIncomingPrompt(null); setShowVoiceFallback(false); }}
                  style={{ flex: 1, padding: '11px 0', background: 'rgba(100,116,139,0.08)', border: '1px solid rgba(100,116,139,0.2)', borderRadius: 9, color: '#64748b', fontSize: 13, cursor: 'pointer' }}>
                  NO — Dismiss
                </button>
              </div>
            </>
          ) : (
            <>
              <div style={{ fontSize: 11, color: '#64748b', marginBottom: 12 }}>Listening for your voice response — or tap below</div>
              <div style={{ display: 'flex', gap: 8 }}>
                <button onClick={() => { speak(`${incomingPrompt.sender} says: ${incomingPrompt.content}`); setIncomingPrompt(null); setShowVoiceFallback(false); }}
                  style={{ flex: 1, padding: '9px 0', background: 'rgba(34,211,238,0.1)', border: '1px solid rgba(34,211,238,0.25)', borderRadius: 9, color: '#22d3ee', fontSize: 12, fontWeight: 700, cursor: 'pointer' }}>
                  YES — Read it
                </button>
                <button onClick={() => { setIncomingPrompt(null); setShowVoiceFallback(false); }}
                  style={{ flex: 1, padding: '9px 0', background: 'rgba(100,116,139,0.08)', border: '1px solid rgba(100,116,139,0.2)', borderRadius: 9, color: '#64748b', fontSize: 12, cursor: 'pointer' }}>
                  NO — Dismiss
                </button>
              </div>
            </>
          )}
        </div>
      )}

      {/* ── PART 10: Voice listening indicator ───────────────────────────── */}
      {voiceListening && (
        <div style={{ position: 'fixed', bottom: 16, right: 16, background: 'rgba(74,222,128,0.1)', border: '1px solid rgba(74,222,128,0.3)', borderRadius: 10, padding: '8px 12px', zIndex: 9400, display: 'flex', alignItems: 'center', gap: 7 }}>
          <Mic2 size={12} style={{ color: '#4ade80' }} />
          <span style={{ fontSize: 10, color: '#4ade80', fontWeight: 600 }}>Listening… say "Aippie"</span>
          {voiceTranscript && <span style={{ fontSize: 9, color: '#64748b', maxWidth: 120, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{voiceTranscript}</span>}
        </div>
      )}

      {/* ── PART 8: Energy prompt ─────────────────────────────────────────── */}
      {showEnergyPrompt && (
        <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.8)', zIndex: 9600, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 24 }}>
          <div style={{ background: '#0f172a', border: '1px solid rgba(74,222,128,0.25)', borderRadius: 16, padding: 28, maxWidth: 320, width: '100%', textAlign: 'center' }}>
            <Activity size={28} style={{ color: '#4ade80', marginBottom: 12 }} />
            <div style={{ fontSize: 14, fontWeight: 700, color: '#f1f5f9', marginBottom: 8 }}>Morning health check</div>
            <div style={{ fontSize: 12, color: '#94a3b8', marginBottom: 20 }}>How are you feeling today?<br/>Rate your energy level:</div>
            <div style={{ display: 'flex', gap: 8, justifyContent: 'center', marginBottom: 16 }}>
              {[1,2,3,4,5].map(n => (
                <button key={n} onClick={() => {
                  supabase.from('health_log').insert({ device_key: deviceKey, energy_level: n, note: 'Morning check-in', logged_at: new Date().toISOString() }).then(() => {});
                  speak(`Energy level ${n} logged. ${n <= 2 ? 'Take it easy today.' : n >= 4 ? 'Great energy! Have a wonderful day.' : 'Have a good day, Elvin.'}`);
                  setShowEnergyPrompt(false);
                }}
                  style={{ width: 40, height: 40, borderRadius: '50%', background: 'rgba(74,222,128,0.08)', border: '1px solid rgba(74,222,128,0.2)', color: '#4ade80', fontSize: 14, fontWeight: 700, cursor: 'pointer' }}>
                  {n}
                </button>
              ))}
            </div>
            <button onClick={() => setShowEnergyPrompt(false)} style={{ fontSize: 11, color: '#475569', background: 'none', border: 'none', cursor: 'pointer' }}>Skip</button>
          </div>
        </div>
      )}
    </div>
  );
}

function GmailPanel({ speak }: { speak: (t: string) => void }) {
  return <GmailInbox speak={speak} />;
}


