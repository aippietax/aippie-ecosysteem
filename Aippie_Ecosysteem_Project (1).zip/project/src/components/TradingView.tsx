import { useCallback, useEffect, useRef, useState } from 'react';
import AippieVoiceOverlay from './AippieVoiceOverlay';
import {
  ShieldCheck, TrendingUp, TrendingDown, Lock, ExternalLink, Zap,
  Newspaper, AlertTriangle, Users, Copy, Eye, Activity,
  DollarSign, Building2, ArrowDownToLine, RefreshCw,
  Mic, CheckCircle2, AlertCircle, CreditCard, ChevronRight,
} from 'lucide-react';
import { applyPremiumVoice, normalizeForTTS, withVoicesReady } from '../lib/ttsVoice';
import { supabase, type Subscription } from '../lib/supabase';
import SofiaTabShell from './SofiaTabShell';

type Props = { subscription: Subscription | null };

// ── Core types ────────────────────────────────────────────────────────────────
type Signal = {
  ticker: string; direction: 'BUY' | 'SELL';
  probability: number; price: number; target: number; ts: number;
};
type Candle = { t: number; o: number; h: number; l: number; c: number };
type BrokerStub = 'traderepublic' | 'revolut' | 'degiro';

type PortfolioRow = {
  id: string; ticker: string; direction: 'BUY' | 'SELL';
  entry_price: number; target_price: number; probability: number;
  outcome: 'win' | 'loss' | 'pending'; pnl_eur: number;
  broker_stub: string | null; executed_at: string;
};

type NewsTick = {
  id: string; headline: string; source: string; ticker: string | null;
  direction: 'BULLISH' | 'BEARISH' | 'NEUTRAL'; velocity: number;
  region: string; created_at: string;
};

type DarkPoolTick = {
  id: string; ticker: string; direction: 'BUY' | 'SELL';
  block_size_usd: number; momentum_pct: number;
  venue: string; institution: string;
  price_hint: number; alert_fired: boolean; created_at: string;
};

// ── Static data ───────────────────────────────────────────────────────────────
const BROKERS: { key: BrokerStub; label: string; color: string; accent: string }[] = [
  { key: 'traderepublic', label: 'Trade Republic', color: '#16a34a', accent: 'rgba(22,163,74,0.15)'  },
  { key: 'revolut',       label: 'Revolut',        color: '#0ea5e9', accent: 'rgba(14,165,233,0.15)' },
  { key: 'degiro',        label: 'DEGIRO',          color: '#f59e0b', accent: 'rgba(245,158,11,0.15)' },
];

type EliteTrader = {
  name: string; icon: string; latest: string;
  ticker: string; dir: 'BUY' | 'SELL'; gain: string; followers: string;
};

const ELITE_TRADERS: EliteTrader[] = [
  { name: 'Nancy Pelosi Portfolio', icon: '🏛️',
    latest: 'Call options $NVDA · strike $500 · exp Dec 2025',
    ticker: 'NVDA', dir: 'BUY', gain: '+$4.2M this quarter', followers: '2.1M mirroring' },
  { name: 'Warren Buffett Alpha Feed', icon: '🎩',
    latest: 'Added 12.4M shares $AAPL at avg $181.20',
    ticker: 'AAPL', dir: 'BUY', gain: '+$1.8B position gain', followers: '5.7M mirroring' },
  { name: 'Michael Burry Signal', icon: '🐻',
    latest: 'Put options $SPY · $380 strike · mass short',
    ticker: 'SPY', dir: 'SELL', gain: '-€ hedge active', followers: '890K mirroring' },
  { name: 'Cathie Wood ARK Flow', icon: '🚀',
    latest: 'Bought $TSLA 680K shares on dip at $228.40',
    ticker: 'TSLA', dir: 'BUY', gain: '+18.4% ARK portfolio', followers: '3.3M mirroring' },
];

const TICKER_SEED: Record<string, number> = {
  AAPL: 189.25, NVDA: 487.60, MSFT: 415.30, TSLA: 241.80, AMZN: 178.95,
};
const TICKERS = Object.keys(TICKER_SEED);

// ── Helpers ───────────────────────────────────────────────────────────────────
function seedCandles(ticker: string, n = 60): Candle[] {
  let price = TICKER_SEED[ticker] ?? 200;
  return Array.from({ length: n }, (_, i) => {
    const move = (Math.random() - 0.49) * price * 0.008;
    const o = price; price += move;
    const range = price * (0.003 + Math.random() * 0.006);
    return {
      t: i,
      o: +o.toFixed(2),
      h: +(Math.max(o, price) + range * 0.4).toFixed(2),
      l: +(Math.min(o, price) - range * 0.4).toFixed(2),
      c: +price.toFixed(2),
    };
  });
}

function generateSignal(ticker: string, candles: Candle[]): Signal | null {
  const last = candles[candles.length - 1];
  const prob = 0.80 + Math.random() * 0.18;
  if (prob < 0.85) return null;
  const dir: 'BUY' | 'SELL' = last.c > last.o ? 'BUY' : 'SELL';
  const delta = last.c * (0.012 + Math.random() * 0.02);
  return {
    ticker, direction: dir, probability: prob, price: last.c,
    target: dir === 'BUY' ? +(last.c + delta).toFixed(2) : +(last.c - delta).toFixed(2),
    ts: Date.now(),
  };
}

function fmtUsd(n: number): string {
  if (n >= 1e9) return `$${(n / 1e9).toFixed(1)}B`;
  if (n >= 1e6) return `$${(n / 1e6).toFixed(0)}M`;
  return `$${n.toFixed(0)}`;
}

function relativeTime(iso: string): string {
  const diff = (Date.now() - new Date(iso).getTime()) / 1000;
  if (diff < 60)   return `${Math.floor(diff)}s ago`;
  if (diff < 3600) return `${Math.floor(diff / 60)}m ago`;
  return `${Math.floor(diff / 3600)}h ago`;
}

// ── Payment modal ─────────────────────────────────────────────────────────────
type PayModalProps = { onClose: () => void; onSuccess: () => void };
function PayModal({ onClose, onSuccess }: PayModalProps) {
  const [card, setCard] = useState('');
  const [exp,  setExp]  = useState('');
  const [cvc,  setCvc]  = useState('');
  const [busy, setBusy] = useState(false);
  const [err,  setErr]  = useState('');

  const fmt4   = (v: string) => v.replace(/\D/g,'').slice(0,16).replace(/(.{4})/g,'$1 ').trim();
  const fmtExp = (v: string) => { const d=v.replace(/\D/g,'').slice(0,4); return d.length>2?`${d.slice(0,2)}/${d.slice(2)}`:d; };

  const submit = () => {
    const raw = card.replace(/\s/g,'');
    if (raw.length < 16)         { setErr('Enter a valid 16-digit card number.'); return; }
    if (!raw.startsWith('4242')) { setErr('Use test card: 4242 4242 4242 4242'); return; }
    if (exp.length < 5)          { setErr('Enter expiry MM/YY.'); return; }
    if (cvc.length < 3)          { setErr('Enter 3-digit CVC.'); return; }
    setErr(''); setBusy(true);
    setTimeout(() => { setBusy(false); onSuccess(); }, 1800);
  };

  return (
    <div className="ta-pay-backdrop" onClick={e => e.target===e.currentTarget && onClose()}>
      <div className="ta-pay-modal">
        <div className="ta-pay-modal__header">
          <div className="ta-pay-modal__icon"><TrendingUp size={20}/></div>
          <div>
            <div className="ta-pay-modal__title">Aippie Trading Alpha</div>
            <div className="ta-pay-modal__sub">€99.99 / month · Cancel anytime</div>
          </div>
        </div>
        <div className="ta-pay-modal__body">
          <div className="ta-pay-modal__perks">
            <span>✓ Dark Pool institutional block tracker</span>
            <span>✓ AI Front-Running dispatch alerts</span>
            <span>✓ Billionaire copy-trading hub</span>
            <span>✓ One-tap broker execution (TR · REV · DGR)</span>
          </div>
          <div className="wf-modal__field">
            <label className="wf-modal__label">Card Number</label>
            <input className="wf-modal__input wf-modal__input--mono" type="text" inputMode="numeric"
              placeholder="4242 4242 4242 4242" value={card} onChange={e=>setCard(fmt4(e.target.value))}/>
            <div className="wf-modal__hint">Test card: 4242 4242 4242 4242</div>
          </div>
          <div className="wf-modal__row">
            <div className="wf-modal__field">
              <label className="wf-modal__label">Expiry</label>
              <input className="wf-modal__input wf-modal__input--mono" type="text" inputMode="numeric"
                placeholder="MM/YY" maxLength={5} value={exp} onChange={e=>setExp(fmtExp(e.target.value))}/>
            </div>
            <div className="wf-modal__field">
              <label className="wf-modal__label">CVC</label>
              <input className="wf-modal__input wf-modal__input--mono" type="text" inputMode="numeric"
                placeholder="123" maxLength={4} value={cvc} onChange={e=>setCvc(e.target.value.replace(/\D/g,'').slice(0,4))}/>
            </div>
          </div>
          {err && <div className="wf-modal__error">{err}</div>}
          <div className="wf-modal__terms"><ShieldCheck size={11}/> AIPPIETAX S.A. · PCI-DSS Level 1 · 256-bit TLS</div>
        </div>
        <div className="wf-modal__footer">
          <button className="wf-modal__cancel" onClick={onClose} disabled={busy}>Cancel</button>
          <button className="wf-modal__confirm wf-modal__confirm--green" onClick={submit} disabled={busy}>
            {busy ? <span className="wf-modal__spinner"/> : <><Lock size={13}/> Unlock Trading Alpha</>}
          </button>
        </div>
      </div>
    </div>
  );
}

// ── Candlestick canvas ────────────────────────────────────────────────────────
function CandleChart({ candles, signal, waveAmps, dpAlert }: {
  candles: Candle[]; signal: Signal | null; waveAmps: number[];
  dpAlert: DarkPoolTick | null;
}) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const flashRef  = useRef(0);

  useEffect(() => {
    let animId: number;
    const render = () => {
      flashRef.current++;
      const canvas = canvasRef.current;
      if (!canvas) return;
      const ctx = canvas.getContext('2d');
      if (!ctx) return;
      const W=canvas.width, H=canvas.height, PL=44, PR=8, PT=18, PB=28;
      const cW=W-PL-PR, cH=H-PT-PB;
      ctx.clearRect(0,0,W,H);
      ctx.fillStyle='#060e1c'; ctx.fillRect(0,0,W,H);
      if (!candles.length) { animId=requestAnimationFrame(render); return; }

      const prices=candles.flatMap(c=>[c.h,c.l]);
      let minP=Math.min(...prices), maxP=Math.max(...prices);
      const pad=(maxP-minP)*0.08; minP-=pad; maxP+=pad;
      const range=maxP-minP;
      const toY=(p:number)=>PT+cH-((p-minP)/range)*cH;
      const barW=Math.max(2,cW/candles.length-1), step=cW/candles.length;

      // Grid
      ctx.strokeStyle='rgba(255,255,255,0.05)'; ctx.lineWidth=1;
      for (let i=0;i<=4;i++) {
        const y=PT+(cH/4)*i;
        ctx.beginPath(); ctx.moveTo(PL,y); ctx.lineTo(W-PR,y); ctx.stroke();
        ctx.fillStyle='rgba(148,163,184,0.55)'; ctx.font='9px monospace'; ctx.textAlign='right';
        ctx.fillText((maxP-(range/4)*i).toFixed(2),PL-2,y+3);
      }

      // Candles
      candles.forEach((c,i)=>{
        const x=PL+i*step+step/2, bull=c.c>=c.o;
        ctx.strokeStyle=bull?'#22c55e':'#ef4444'; ctx.fillStyle=bull?'#22c55e':'#ef4444'; ctx.lineWidth=1;
        ctx.beginPath(); ctx.moveTo(x,toY(c.h)); ctx.lineTo(x,toY(c.l)); ctx.stroke();
        const by=toY(Math.max(c.o,c.c)), bh=Math.max(1,toY(Math.min(c.o,c.c))-by);
        ctx.fillRect(x-barW/2,by,barW,bh);
      });

      // Signal overlay
      if (signal) {
        const sy=toY(signal.target), col=signal.direction==='BUY'?'#22c55e':'#ef4444';
        const alpha=0.65+0.35*Math.abs(Math.sin(flashRef.current/12));
        ctx.save(); ctx.globalAlpha=alpha;
        ctx.strokeStyle=col; ctx.lineWidth=1.5; ctx.setLineDash([6,4]);
        ctx.beginPath(); ctx.moveTo(PL,sy); ctx.lineTo(W-PR,sy); ctx.stroke();
        ctx.setLineDash([]); ctx.globalAlpha=1;
        ctx.fillStyle=col; ctx.font='bold 10px monospace'; ctx.textAlign='left';
        ctx.fillText(`${signal.direction} TARGET  ${signal.target.toFixed(2)}`,PL+4,sy-4);
        const wH=18, wY=H-PB-wH, wStep=cW/waveAmps.length, wBW=Math.max(1,wStep-1);
        ctx.globalAlpha=0.8*alpha;
        waveAmps.forEach((amp,i)=>{
          const bh=Math.max(2,(amp/40)*wH), bx=PL+i*wStep, by=wY+(wH-bh)/2;
          ctx.fillStyle=col; ctx.beginPath(); ctx.roundRect(bx,by,wBW,bh,1); ctx.fill();
        });
        ctx.restore();
      }

      // Dark pool momentum band overlay
      if (dpAlert) {
        const dpCol = dpAlert.direction==='BUY'?'rgba(56,189,248,0.18)':'rgba(239,68,68,0.12)';
        const dpStroke = dpAlert.direction==='BUY'?'#38bdf8':'#ef4444';
        const bandAlpha = 0.4+0.3*Math.abs(Math.sin(flashRef.current/20));
        ctx.save();
        ctx.globalAlpha=bandAlpha;
        ctx.fillStyle=dpCol;
        ctx.fillRect(PL, PT, cW, cH);
        ctx.strokeStyle=dpStroke; ctx.lineWidth=1; ctx.setLineDash([3,5]);
        ctx.strokeRect(PL,PT,cW,cH);
        ctx.setLineDash([]);
        ctx.globalAlpha=0.9;
        ctx.fillStyle=dpStroke; ctx.font='bold 9px monospace'; ctx.textAlign='center';
        ctx.fillText(`DARK POOL ${dpAlert.direction} · ${dpAlert.momentum_pct.toFixed(1)}% MOMENTUM`,W/2,PT+12);
        ctx.restore();
      }

      ctx.fillStyle='rgba(148,163,184,0.4)'; ctx.font='9px monospace'; ctx.textAlign='center';
      ctx.fillText('1D · 1min bars · SIMULATED',W/2,H-8);
      animId=requestAnimationFrame(render);
    };
    animId=requestAnimationFrame(render);
    return ()=>cancelAnimationFrame(animId);
  },[candles,signal,waveAmps,dpAlert]);

  return <canvas ref={canvasRef} width={340} height={190} className="ta-chart-canvas" aria-label="Trading chart"/>;
}

// ── Broker execution row ──────────────────────────────────────────────────────
function BrokerRow({ ticker, signal, darkPoolAlert, onExecute }: {
  ticker: string; signal: Signal|null; darkPoolAlert: DarkPoolTick|null;
  onExecute:(b:BrokerStub)=>void;
}) {
  const [launching, setLaunching] = useState<BrokerStub|null>(null);
  const activeDir = darkPoolAlert?.direction ?? signal?.direction;

  const go = (b: BrokerStub) => {
    setLaunching(b); onExecute(b);
    setTimeout(()=>setLaunching(null),1800);
  };

  return (
    <div className="ta-broker-row">
      <div className="ta-broker-row__label">
        <Zap size={11}/>
        {darkPoolAlert ? 'EXECUTE JOINT MARKET MOVE' : 'EXECUTE TRADE ON YOUR BROKER'}
        {activeDir && (
          <span className={`ta-broker-row__signal ta-broker-row__signal--${activeDir==='BUY'?'buy':'sell'}`}>
            {activeDir} {ticker}
          </span>
        )}
      </div>
      <div className="ta-broker-row__btns">
        {BROKERS.map(b=>(
          <button key={b.key} className="ta-broker-btn"
            style={{'--broker-color':b.color,'--broker-accent':b.accent} as React.CSSProperties}
            onClick={()=>go(b.key)} disabled={!!launching}>
            {launching===b.key
              ? <span className="ta-broker-btn__launching">Launching…</span>
              : <><ExternalLink size={11} className="ta-broker-btn__icon"/><span>{b.label}</span></>}
          </button>
        ))}
      </div>
    </div>
  );
}

// ── Dark Pool Tracker panel ───────────────────────────────────────────────────
type FrontRunAlert = { tick: DarkPoolTick; dismissed: boolean } | null;

function DarkPoolTracker({ onFrontRun }: { onFrontRun:(t:DarkPoolTick)=>void }) {
  const [ticks, setTicks]   = useState<DarkPoolTick[]>([]);
  const [alert, setAlert]   = useState<FrontRunAlert>(null);
  const [loading, setLoading] = useState(true);
  const [execTicker, setExecTicker] = useState<string|null>(null);

  useEffect(()=>{
    const load = async () => {
      const { data } = await supabase
        .from('aippie_darkpool_liquidity')
        .select('*')
        .order('created_at',{ascending:false})
        .limit(10);
      if (data) {
        const typed = data as DarkPoolTick[];
        setTicks(typed);
        const hotAlert = typed.find(t=>t.momentum_pct>=92 && t.alert_fired);
        if (hotAlert) setAlert({ tick: hotAlert, dismissed: false });
      }
      setLoading(false);
    };
    load();

    // Simulate new dark pool detection every 18s
    const venues = ['CrossFinder','Liquidnet','IEX Dark','BATS Dark'];
    const institutions = ['Vanguard Institutional','BlackRock Alpha','Citadel Securities','JPMorgan Asset Mgmt','Norges Bank'];
    const tickers = ['AAPL','NVDA','TSLA','MSFT','AMZN'];
    const id = setInterval(()=>{
      const tkr = tickers[Math.floor(Math.random()*tickers.length)];
      const dir: 'BUY'|'SELL' = Math.random()>0.45?'BUY':'SELL';
      const mom = 82 + Math.random()*17;
      const newTick: DarkPoolTick = {
        id: crypto.randomUUID(),
        ticker: tkr,
        direction: dir,
        block_size_usd: Math.floor(50e6 + Math.random()*400e6),
        momentum_pct: +mom.toFixed(1),
        venue: venues[Math.floor(Math.random()*venues.length)],
        institution: institutions[Math.floor(Math.random()*institutions.length)],
        price_hint: +(TICKER_SEED[tkr]*(0.98+Math.random()*0.04)).toFixed(2),
        alert_fired: mom>=92,
        created_at: new Date().toISOString(),
      };
      setTicks(prev=>[newTick,...prev].slice(0,10));
      if (newTick.alert_fired) {
        setAlert({ tick: newTick, dismissed: false });
        onFrontRun(newTick);
      }
    }, 18000);
    return ()=>clearInterval(id);
  },[onFrontRun]);

  const executeMove = (tick: DarkPoolTick) => {
    setExecTicker(tick.ticker);
    supabase.from('aippie_user_portfolio').insert({
      user_id:null, ticker:tick.ticker, direction:tick.direction,
      entry_price:tick.price_hint, target_price:tick.price_hint*(tick.direction==='BUY'?1.025:0.975),
      probability:tick.momentum_pct/100, outcome:'pending', pnl_eur:0, broker_stub:'traderepublic',
    });
    setTimeout(()=>{ setExecTicker(null); setAlert(prev=>prev?{...prev,dismissed:true}:null); },2000);
  };

  return (
    <div className="ta-darkpool">
      <div className="ta-section-header">
        <Eye size={12}/>
        <span>INSTITUTIONAL DARK POOL TRACKER</span>
        <span className="ta-section-header__live">LIVE</span>
      </div>

      {/* Front-running alert */}
      {alert && !alert.dismissed && (
        <div className="ta-frontrun-alert">
          <div className="ta-frontrun-alert__header">
            <Activity size={13} className="ta-frontrun-alert__icon"/>
            <span className="ta-frontrun-alert__label">WALL STREET FRONT-RUNNING SIGNAL ACTIVE</span>
            <button className="ta-frontrun-alert__dismiss" onClick={()=>setAlert(prev=>prev?{...prev,dismissed:true}:null)}>✕</button>
          </div>
          <div className="ta-frontrun-alert__body">
            <span className={`ta-frontrun-alert__dir ta-frontrun-alert__dir--${alert.tick.direction==='BUY'?'buy':'sell'}`}>
              {alert.tick.direction} NOW
            </span>
            <span className="ta-frontrun-alert__detail">
              {alert.tick.ticker} at ${alert.tick.price_hint.toFixed(2)} · Dark Pool Momentum: {alert.tick.momentum_pct.toFixed(1)}%
            </span>
          </div>
          <div className="ta-frontrun-alert__meta">
            {alert.tick.institution} · {fmtUsd(alert.tick.block_size_usd)} block · {alert.tick.venue}
          </div>
          <div className="ta-broker-row__btns" style={{padding:'0 0 4px'}}>
            {BROKERS.map(b=>(
              <button key={b.key} className="ta-broker-btn"
                style={{'--broker-color':b.color,'--broker-accent':b.accent} as React.CSSProperties}
                onClick={()=>executeMove(alert.tick)} disabled={execTicker===alert.tick.ticker}>
                {execTicker===alert.tick.ticker
                  ? <span className="ta-broker-btn__launching">Executing…</span>
                  : <><ExternalLink size={11}/><span>{b.label}</span></>}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Dark pool feed */}
      <div className="ta-dp-feed">
        {loading ? (
          <div className="ta-portfolio__loading"><span className="modal__spinner modal__spinner--sm"/></div>
        ) : ticks.map(t=>(
          <div key={t.id} className={`ta-dp-row${t.alert_fired?' ta-dp-row--hot':''}`}>
            <div className="ta-dp-row__left">
              <span className={`ta-dp-row__dir ta-dp-row__dir--${t.direction==='BUY'?'buy':'sell'}`}>{t.direction}</span>
              <div className="ta-dp-row__info">
                <div className="ta-dp-row__ticker">{t.ticker} <span className="ta-dp-row__price">${t.price_hint.toFixed(2)}</span></div>
                <div className="ta-dp-row__inst">{t.institution} · {t.venue} · {relativeTime(t.created_at)}</div>
              </div>
            </div>
            <div className="ta-dp-row__right">
              <div className="ta-dp-row__block">{fmtUsd(t.block_size_usd)}</div>
              <div className="ta-dp-momentum">
                <div className="ta-dp-momentum__bar">
                  <div className="ta-dp-momentum__fill"
                    style={{
                      width:`${t.momentum_pct}%`,
                      background: t.direction==='BUY'?'#38bdf8':'#ef4444',
                    }}/>
                </div>
                <span className={`ta-dp-momentum__pct${t.alert_fired?' ta-dp-momentum__pct--hot':''}`}>
                  {t.momentum_pct.toFixed(1)}%
                </span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ── Copy-Trading Hub ──────────────────────────────────────────────────────────
function CopyTradingHub({ onMirror }: { onMirror:(t:EliteTrader)=>void }) {
  const [mirroring, setMirroring] = useState<string|null>(null);
  const [done, setDone]           = useState<Set<string>>(new Set());

  const mirror = (t: EliteTrader) => {
    setMirroring(t.name); onMirror(t);
    setTimeout(()=>{
      setMirroring(null);
      setDone(prev=>new Set(prev).add(t.name));
      setTimeout(()=>setDone(prev=>{ const s=new Set(prev); s.delete(t.name); return s; }), 4000);
    }, 2000);
  };

  return (
    <div className="ta-copy-hub">
      <div className="ta-section-header">
        <Users size={12}/><span>INSTITUTIONAL COPY-TRADING HUB</span>
        <span className="ta-section-header__live">LIVE</span>
      </div>
      <div className="ta-copy-hub__list">
        {ELITE_TRADERS.map(t=>(
          <div key={t.name} className="ta-elite-card">
            <div className="ta-elite-card__top">
              <span className="ta-elite-card__icon">{t.icon}</span>
              <div className="ta-elite-card__info">
                <div className="ta-elite-card__name">{t.name}</div>
                <div className="ta-elite-card__trade">{t.latest}</div>
              </div>
              <span className={`ta-elite-card__dir ta-elite-card__dir--${t.dir==='BUY'?'buy':'sell'}`}>{t.dir}</span>
            </div>
            <div className="ta-elite-card__bottom">
              <span className={`ta-elite-card__gain${t.gain.startsWith('+')?' ta-elite-card__gain--pos':''}`}>{t.gain}</span>
              <span className="ta-elite-card__followers">{t.followers}</span>
              <button
                className={`ta-mirror-btn${done.has(t.name)?' ta-mirror-btn--done':''}`}
                onClick={()=>!done.has(t.name)&&mirror(t)}
                disabled={mirroring===t.name}
              >
                {mirroring===t.name ? <span className="wf-modal__spinner wf-modal__spinner--xs"/>
                 : done.has(t.name) ? '✓ Mirrored'
                 : <><Copy size={10}/> MIRROR ELITE TRADE INSTANTLY</>}
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ── News Sentiment Shifter ────────────────────────────────────────────────────
type ShiftAlert = { direction: 'BULLISH'|'BEARISH'; velocity: number; headline: string } | null;

function NewsSentimentShifter({ onJointMove }: { onJointMove:()=>void }) {
  const [ticks, setTicks]     = useState<NewsTick[]>([]);
  const [alert, setAlert]     = useState<ShiftAlert>(null);
  const [executing, setExecuting] = useState(false);
  const [executed, setExecuted]   = useState(false);

  useEffect(()=>{
    const load = async () => {
      const { data } = await supabase
        .from('aippie_news_sentiment_ticks').select('*')
        .order('created_at',{ascending:false}).limit(8);
      if (data) {
        const typed = data as NewsTick[];
        setTicks(typed);
        const hot = typed.find(t=>t.velocity>0.90 && t.direction!=='NEUTRAL');
        if (hot) setAlert({ direction: hot.direction as 'BULLISH'|'BEARISH', velocity: hot.velocity, headline: hot.headline });
      }
    };
    load();
    const newHeadlines: Omit<NewsTick,'id'|'created_at'>[] = [
      { headline:'Fed signals 75bp emergency cut — markets surge', source:'Reuters', ticker:null, direction:'BULLISH', velocity:0.96, region:'US' },
      { headline:'Major bank collapse alert: SVB-2 receivership filed', source:'FT', ticker:null, direction:'BEARISH', velocity:0.94, region:'US' },
      { headline:'NVDA Q4 beats by 34% — AI demand unprecedented', source:'Bloomberg', ticker:'NVDA', direction:'BULLISH', velocity:0.91, region:'US' },
    ];
    const id=setInterval(()=>{
      const raw=newHeadlines[Math.floor(Math.random()*newHeadlines.length)];
      const next:NewsTick={...raw, id:crypto.randomUUID(), created_at:new Date().toISOString()};
      setTicks(prev=>[next,...prev].slice(0,8));
      if (next.velocity>0.90) setAlert({direction:next.direction as 'BULLISH'|'BEARISH', velocity:next.velocity, headline:next.headline});
    },20000);
    return ()=>clearInterval(id);
  },[]);

  const executeJointMove = () => {
    setExecuting(true); onJointMove();
    setTimeout(()=>{ setExecuting(false); setExecuted(true); setAlert(null); },2000);
  };

  return (
    <div className="ta-news-shifter">
      <div className="ta-section-header">
        <Newspaper size={12}/><span>AI NEWS SENTIMENT MARKET SHIFTER</span>
        <span className="ta-section-header__live">LIVE</span>
      </div>
      {alert && !executed && (
        <div className={`ta-shift-alert ta-shift-alert--${alert.direction==='BULLISH'?'bull':'bear'}`}>
          <div className="ta-shift-alert__top">
            <AlertTriangle size={13}/>
            <span className="ta-shift-alert__label">AIPPIE ALGO MARKET SHIFT ACTIVE</span>
            <span className="ta-shift-alert__vel">{(alert.velocity*100).toFixed(0)}% velocity</span>
          </div>
          <div className="ta-shift-alert__headline">{alert.headline}</div>
          <button
            className={`ta-joint-move-btn ta-joint-move-btn--${alert.direction==='BULLISH'?'bull':'bear'}`}
            onClick={executeJointMove} disabled={executing}>
            {executing ? <span className="wf-modal__spinner"/> : <><Zap size={13}/> EXECUTE JOINT MARKET MOVE</>}
          </button>
        </div>
      )}
      {executed&&<div className="ta-shift-executed">Joint move executed · Position logged to ledger</div>}
      <div className="ta-news-feed">
        {ticks.map(tick=>(
          <div key={tick.id} className={`ta-news-tick ta-news-tick--${tick.direction==='BULLISH'?'bull':tick.direction==='BEARISH'?'bear':'neutral'}`}>
            <div className="ta-news-tick__left">
              <span className={`ta-news-tick__dir ta-news-tick__dir--${tick.direction==='BULLISH'?'bull':tick.direction==='BEARISH'?'bear':'neutral'}`}>
                {tick.direction==='BULLISH'?'▲':tick.direction==='BEARISH'?'▼':'—'}
              </span>
              <div className="ta-news-tick__body">
                <div className="ta-news-tick__headline">{tick.headline}</div>
                <div className="ta-news-tick__meta">{tick.source} · {tick.region}{tick.ticker?` · $${tick.ticker}`:''} · {relativeTime(tick.created_at)}</div>
              </div>
            </div>
            <div className="ta-news-tick__right">
              <div className="ta-vel-bar">
                <div className="ta-vel-bar__fill" style={{width:`${Math.round(tick.velocity*100)}%`,background:tick.direction==='BULLISH'?'#22c55e':tick.direction==='BEARISH'?'#ef4444':'#94a3b8'}}/>
              </div>
              <span className="ta-vel-pct">{Math.round(tick.velocity*100)}%</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ── Portfolio ledger ──────────────────────────────────────────────────────────
type PortfolioStats = { totalPnl: number; winRate: number; trades: number };

function PortfolioLedger() {
  const [rows, setRows]     = useState<PortfolioRow[]>([]);
  const [stats, setStats]   = useState<PortfolioStats>({ totalPnl: 1420.50, winRate: 89.2, trades: 7 });
  const [loading, setLoading] = useState(true);

  useEffect(()=>{
    const load = async () => {
      const { data } = await supabase
        .from('aippie_user_portfolio').select('*')
        .is('user_id',null)
        .order('executed_at',{ascending:false}).limit(20);
      if (data) {
        const typed=data as PortfolioRow[];
        setRows(typed);
        const closed=typed.filter(r=>r.outcome!=='pending'), wins=closed.filter(r=>r.outcome==='win');
        setStats({ totalPnl:typed.reduce((s,r)=>s+Number(r.pnl_eur),0), winRate:closed.length>0?(wins.length/closed.length)*100:89.2, trades:typed.length });
      }
      setLoading(false);
    };
    load();
    const ch=supabase.channel('portfolio-live-v31')
      .on('postgres_changes',{event:'INSERT',schema:'public',table:'aippie_user_portfolio'},(payload)=>{
        const row=payload.new as PortfolioRow;
        setRows(prev=>[row,...prev].slice(0,20));
        setStats(prev=>({...prev,totalPnl:prev.totalPnl+Number(row.pnl_eur),trades:prev.trades+1}));
      }).subscribe();
    return ()=>{ supabase.removeChannel(ch); };
  },[]);

  return (
    <div className="ta-portfolio">
      <div className="ta-portfolio__stats">
        <div className="ta-portfolio__stat ta-portfolio__stat--profit">
          <div className="ta-portfolio__stat-label">Total Profit Generated by Aippie</div>
          <div className={`ta-portfolio__stat-value${stats.totalPnl>=0?' ta-portfolio__stat-value--pos':' ta-portfolio__stat-value--neg'}`}>
            {stats.totalPnl>=0?'+':''}€{stats.totalPnl.toFixed(2)}
          </div>
        </div>
        <div className="ta-portfolio__stat ta-portfolio__stat--win">
          <div className="ta-portfolio__stat-label">Win Rate Level</div>
          <div className="ta-portfolio__stat-value ta-portfolio__stat-value--win">{stats.winRate.toFixed(1)}% Accurate</div>
        </div>
      </div>
      <div className="ta-portfolio__log-header"><TrendingUp size={10}/> Recent Signals · {stats.trades} trades</div>
      <div className="ta-portfolio__log">
        {loading
          ? <div className="ta-portfolio__loading"><span className="modal__spinner modal__spinner--sm"/></div>
          : rows.map(r=>(
            <div key={r.id} className={`ta-log-row ta-log-row--${r.outcome}`}>
              <div className="ta-log-row__left">
                <span className={`ta-log-row__dir ta-log-row__dir--${r.direction==='BUY'?'buy':'sell'}`}>{r.direction}</span>
                <span className="ta-log-row__ticker">{r.ticker}</span>
                {r.broker_stub&&<span className="ta-log-row__broker">{r.broker_stub==='traderepublic'?'TR':r.broker_stub==='revolut'?'REV':'DGR'}</span>}
              </div>
              <div className="ta-log-row__right">
                <span className={`ta-log-row__pnl${Number(r.pnl_eur)>=0?' ta-log-row__pnl--pos':' ta-log-row__pnl--neg'}`}>
                  {Number(r.pnl_eur)>=0?'+':''}€{Number(r.pnl_eur).toFixed(2)}
                </span>
                <span className={`ta-log-row__outcome ta-log-row__outcome--${r.outcome}`}>{r.outcome.toUpperCase()}</span>
              </div>
            </div>
          ))
        }
        {!loading&&rows.length===0&&<div className="ta-portfolio__empty">No trades recorded yet.</div>}
      </div>
    </div>
  );
}

// ── V147 Partner Affiliate Portal ─────────────────────────────────────────────
const SUBSCRIPTION_PRICE_EUR = 499.00;
const AFFILIATE_RATE         = 0.20;  // 20% revenue share
const COMMISSION_PER_SEAT    = +(SUBSCRIPTION_PRICE_EUR * AFFILIATE_RATE).toFixed(2); // €99.80

type AffiliateRow = {
  id: string;
  affiliate_name: string;
  affiliate_email: string;
  iban: string;
  active_seats: number;
  monthly_commission_eur: number;
  total_paid_out_eur: number;
  status: string;
  created_at: string;
};
type PayoutRow = {
  id: string;
  amount_eur: number;
  invoice_ref: string;
  status: string;
  created_at: string;
};

function genInvoiceRef() {
  const s = () => Math.random().toString(36).slice(2,6).toUpperCase();
  return `INV-AIPP-PART-${s()}-${s()}`;
}

function useAffSubtitle(text: string, active: boolean) {
  const [sub, setSub] = useState('');
  const tmr = useRef<ReturnType<typeof setInterval>|null>(null);
  const idx  = useRef(0);
  useEffect(() => {
    if (tmr.current) { clearInterval(tmr.current); tmr.current = null; }
    setSub('');
    if (!active || !text.trim()) return;
    const words = text.split(/\s+/);
    idx.current = 0;
    tmr.current = setInterval(() => {
      idx.current++;
      setSub(words.slice(Math.max(0, idx.current-10), idx.current).join(' '));
      if (idx.current >= words.length && tmr.current) { clearInterval(tmr.current); tmr.current = null; }
    }, 400);
    return () => { if (tmr.current) { clearInterval(tmr.current); tmr.current = null; } };
  }, [text, active]);
  return sub;
}

function PartnerAffiliatePortal() {
  const deviceKey = useRef((() => {
    let k = localStorage.getItem('aippie_device_key');
    if (!k) { k = crypto.randomUUID(); localStorage.setItem('aippie_device_key', k); }
    return k;
  })());

  // Registration gate
  type RegPhase = 'gate' | 'register' | 'processing' | 'dashboard';
  const [regPhase,    setRegPhase]    = useState<RegPhase>('gate');
  const [cardInput,   setCardInput]   = useState('');
  const [cardError,   setCardError]   = useState('');
  const [affName,     setAffName]     = useState('');
  const [affEmail,    setAffEmail]    = useState('');
  const [affIban,     setAffIban]     = useState('');
  const [regError,    setRegError]    = useState('');

  // Dashboard state
  const [affiliate,   setAffiliate]   = useState<AffiliateRow|null>(null);
  const [payouts,     setPayouts]     = useState<PayoutRow[]>([]);
  const [loading,     setLoading]     = useState(false);
  const [payPhase,    setPayPhase]    = useState<'idle'|'processing'|'success'|'error'>('idle');
  const [payMsg,      setPayMsg]      = useState('');
  const [ibanInput,   setIbanInput]   = useState('');
  const [speaking,    setSpeaking]    = useState(false);
  const [spokenText,  setSpokenText]  = useState('');
  const mountedRef = useRef(true);

  const subtitle = useAffSubtitle(spokenText, speaking);

  useEffect(() => {
    mountedRef.current = true;
    // Check if device already has an affiliate record
    (async () => {
      const { data } = await supabase
        .from('trading_partner_affiliates')
        .select('*')
        .eq('device_key', deviceKey.current)
        .eq('status', 'active')
        .maybeSingle();
      if (data && mountedRef.current) {
        setAffiliate(data as AffiliateRow);
        setRegPhase('dashboard');
        loadPayouts(data.id);
      }
    })();
    return () => { mountedRef.current = false; };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const speakText = useCallback((text: string) => {
    if (!('speechSynthesis' in window)) return;
    window.speechSynthesis.cancel();
    const say = () => {
      const u = new SpeechSynthesisUtterance(normalizeForTTS(text));
      u.rate = 0.82; u.pitch = 1.02;
      applyPremiumVoice(u);
      u.onstart = () => { if (mountedRef.current) { setSpeaking(true); setSpokenText(text); } };
      u.onend   = () => { if (mountedRef.current) setSpeaking(false); };
      u.onerror = () => { if (mountedRef.current) setSpeaking(false); };
      window.speechSynthesis.speak(u);
    };
    withVoicesReady(say);
  }, []);

  const loadPayouts = useCallback(async (affiliateId: string) => {
    const { data } = await supabase
      .from('trading_affiliate_payouts')
      .select('id,amount_eur,invoice_ref,status,created_at')
      .eq('affiliate_id', affiliateId)
      .order('created_at', { ascending: false })
      .limit(20);
    if (data && mountedRef.current) setPayouts(data as PayoutRow[]);
  }, []);

  const handleRegisterPayment = () => {
    const stripped = cardInput.replace(/\s/g, '');
    if (stripped.length < 16) { setCardError('Enter a valid 16-digit card number.'); return; }
    setCardError('');
    if (!affName.trim() || !affEmail.trim()) { setRegError('Please fill in your name and email.'); return; }
    setRegError('');
    setRegPhase('processing');
  };

  useEffect(() => {
    if (regPhase !== 'processing') return;
    const activate = async () => {
      const seats = Math.floor(3 + Math.random() * 8); // simulated initial seat count
      const commission = +(seats * COMMISSION_PER_SEAT).toFixed(2);
      const { data } = await supabase
        .from('trading_partner_affiliates')
        .insert({
          device_key:            deviceKey.current,
          affiliate_name:        affName,
          affiliate_email:       affEmail,
          iban:                  affIban,
          active_seats:          seats,
          monthly_commission_eur: commission,
          total_paid_out_eur:    0,
          status:                'active',
        })
        .select()
        .maybeSingle();
      await new Promise(r => setTimeout(r, 1800));
      if (!mountedRef.current) return;
      if (data) {
        setAffiliate(data as AffiliateRow);
        setRegPhase('dashboard');
        speakText('Your Trading Alpha affiliate account is now live. Your 20 percent revenue share is being tracked in real time. Each active seat generates 99 euros and 80 cents per month for you automatically.');
      }
    };
    activate();
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [regPhase]);

  const handlePayout = useCallback(async () => {
    if (!affiliate) return;
    const pending = affiliate.monthly_commission_eur - affiliate.total_paid_out_eur % affiliate.monthly_commission_eur;
    if (pending <= 0) { setPayMsg('No pending balance available.'); setPayPhase('error'); return; }
    const iban = ibanInput.trim() || affiliate.iban;
    if (!iban) { setPayMsg('Please enter your IBAN before requesting a payout.'); setPayPhase('error'); return; }

    setPayPhase('processing');
    const invoiceRef = genInvoiceRef();

    await supabase.from('trading_affiliate_payouts').insert({
      device_key:   deviceKey.current,
      affiliate_id: affiliate.id,
      amount_eur:   pending,
      invoice_ref:  invoiceRef,
      status:       'queued',
    });
    await supabase.from('trading_partner_affiliates').update({
      total_paid_out_eur: affiliate.total_paid_out_eur + pending,
      iban: iban,
    }).eq('id', affiliate.id);

    await new Promise(r => setTimeout(r, 1600));
    if (!mountedRef.current) return;

    await supabase.from('trading_affiliate_payouts')
      .update({ status: 'completed' })
      .eq('invoice_ref', invoiceRef);

    setAffiliate(prev => prev ? { ...prev, total_paid_out_eur: prev.total_paid_out_eur + pending, iban } : prev);
    setPayPhase('success');
    setPayMsg(`Payout of €${pending.toFixed(2)} queued → IBAN. Invoice: ${invoiceRef}`);
    speakText(`Payout of ${pending.toFixed(2)} euros initiated to your IBAN. Invoice reference ${invoiceRef} has been generated.`);
    await loadPayouts(affiliate.id);
  }, [affiliate, ibanInput, speakText, loadPayouts]);

  const refreshData = useCallback(async () => {
    if (!affiliate) return;
    setLoading(true);
    // Simulate seat growth
    const newSeats = affiliate.active_seats + Math.floor(Math.random() * 3);
    const newCommission = +(newSeats * COMMISSION_PER_SEAT).toFixed(2);
    await supabase.from('trading_partner_affiliates').update({
      active_seats: newSeats,
      monthly_commission_eur: newCommission,
    }).eq('id', affiliate.id);
    setAffiliate(prev => prev ? { ...prev, active_seats: newSeats, monthly_commission_eur: newCommission } : prev);
    await loadPayouts(affiliate.id);
    setLoading(false);
  }, [affiliate, loadPayouts]);

  // ── Gate: not yet registered ────────────────────────────────────────────────
  if (regPhase === 'gate' || regPhase === 'register') {
    return (
      <div className="tap-root">
        {/* Avatar panel */}
        <div className="tap-avatar-panel">
          <div className="tap-avatar-wrap">
            <img
              src="/Jouw_alineatekst_(2).png"
              alt="Aippie"
              className={`tap-avatar-img${speaking ? ' tap-avatar-img--speaking' : ''}`}
              onError={e => { (e.currentTarget as HTMLImageElement).src = 'https://images.pexels.com/photos/1858175/pexels-photo-1858175.jpeg?auto=compress&cs=tinysrgb&w=300&h=350&fit=crop&crop=faces'; }}
            />
            {speaking && <div className="tap-avatar-ring"/>}
            <div className="tap-avatar-badge"><Mic size={8}/><span>Aippie · v147</span></div>
          </div>
          <div className="tap-avatar-subtitle">
            {speaking && subtitle
              ? <span className="tap-avatar-subtitle--active">{subtitle}</span>
              : <span className="tap-avatar-subtitle--idle">Partner Affiliate Matrix · AIPPIETAX S.A.</span>
            }
          </div>
        </div>

        <div className="tap-hero">
          <div className="tap-hero__title">Trading Alpha Partner Portal</div>
          <div className="tap-hero__sub">AIPPIETAX S.A. · 20% Recurring Revenue Share · v147</div>
        </div>

        {/* Pricing breakdown */}
        <div className="tap-pricing-strip">
          <div className="tap-pricing-card">
            <DollarSign size={16} style={{ color: '#4ade80' }}/>
            <div>
              <div className="tap-pricing-card__label">Software Subscription</div>
              <div className="tap-pricing-card__value" style={{ color: '#4ade80' }}>€499.00/mo</div>
              <div className="tap-pricing-card__sub">per active trader seat</div>
            </div>
          </div>
          <div className="tap-pricing-card">
            <ArrowDownToLine size={16} style={{ color: '#38bdf8' }}/>
            <div>
              <div className="tap-pricing-card__label">Your Revenue Share</div>
              <div className="tap-pricing-card__value" style={{ color: '#38bdf8' }}>€{COMMISSION_PER_SEAT.toFixed(2)}/mo</div>
              <div className="tap-pricing-card__sub">20% per active seat</div>
            </div>
          </div>
        </div>

        {/* Registration form */}
        <div className="tap-register-form">
          <div className="tap-register-form__title">
            <Users size={13} style={{ color: '#fbbf24' }}/>
            Partner Registration
          </div>

          <label className="tap-form-label">Full Name</label>
          <input
            className="tap-form-input"
            placeholder="e.g. Carlos Influencer"
            value={affName}
            onChange={e => setAffName(e.target.value)}
          />

          <label className="tap-form-label">Email</label>
          <input
            className="tap-form-input"
            type="email"
            placeholder="partner@trading.com"
            value={affEmail}
            onChange={e => setAffEmail(e.target.value)}
          />

          <label className="tap-form-label">IBAN (for commission payouts)</label>
          <input
            className="tap-form-input tap-form-input--mono"
            placeholder="NL91 ABNA 0417 1643 00"
            value={affIban}
            onChange={e => setAffIban(e.target.value)}
          />

          <label className="tap-form-label"><CreditCard size={11}/> Card Number</label>
          <input
            type="text"
            inputMode="numeric"
            placeholder="4242 4242 4242 4242"
            className={`tap-form-input tap-form-input--mono${cardError ? ' tap-form-input--error' : ''}`}
            value={cardInput}
            maxLength={19}
            onChange={e => { setCardError(''); setCardInput(e.target.value.replace(/\D/g,'').slice(0,16).replace(/(.{4})/g,'$1 ').trim()); }}
          />
          {cardError && <div className="tap-form-error"><AlertCircle size={11}/> {cardError}</div>}
          {regError  && <div className="tap-form-error"><AlertCircle size={11}/> {regError}</div>}
          <div className="tap-form-hint">Test mode · use card <span style={{ color:'#fbbf24' }}>4242 4242 4242 4242</span></div>

          <button
            className="tap-register-btn"
            disabled={cardInput.replace(/\s/g,'').length < 16 || !affName.trim() || !affEmail.trim()}
            onClick={handleRegisterPayment}
          >
            <Lock size={13}/> Activate Partner Account
          </button>
        </div>

        <div className="tap-trust-row">
          <ShieldCheck size={11} style={{ color: '#4ade80' }}/>
          <span>AIPPIETAX S.A. · PCI-DSS · GDPR · Automated 20% split execution</span>
        </div>
      </div>
    );
  }

  // ── Processing ──────────────────────────────────────────────────────────────
  if (regPhase === 'processing') {
    return (
      <div className="tap-root tap-root--processing">
        <RefreshCw size={32} className="tap-spin"/>
        <div className="tap-processing-title">Activating Partner Account…</div>
        {['Verifying payment', 'Registering affiliate token', 'Linking revenue share matrix', 'Calculating active seat count', 'Launching dashboard'].map((s, i) => (
          <div key={i} className="tap-processing-step">
            <RefreshCw size={10} className="tap-spin" style={{ color: '#38bdf8' }}/>
            <span>{s}</span>
          </div>
        ))}
      </div>
    );
  }

  // ── Dashboard (unlocked) ────────────────────────────────────────────────────
  const pendingBalance = affiliate
    ? Math.max(0, affiliate.monthly_commission_eur - (affiliate.total_paid_out_eur % (affiliate.monthly_commission_eur || 1)))
    : 0;

  return (
    <div className="tap-root">
      {/* Avatar face-to-face */}
      <div className="tap-avatar-panel">
        <div className="tap-avatar-wrap">
          <img
            src="/Jouw_alineatekst_(2).png"
            alt="Aippie"
            className={`tap-avatar-img${speaking ? ' tap-avatar-img--speaking' : ''}`}
            onError={e => { (e.currentTarget as HTMLImageElement).src = 'https://images.pexels.com/photos/1858175/pexels-photo-1858175.jpeg?auto=compress&cs=tinysrgb&w=300&h=350&fit=crop&crop=faces'; }}
          />
          {speaking && <div className="tap-avatar-ring"/>}
          <div className="tap-avatar-badge"><Mic size={8}/><span>Aippie · v147</span></div>
        </div>
        <div className="tap-avatar-subtitle">
          {speaking && subtitle
            ? <span className="tap-avatar-subtitle--active">{subtitle}</span>
            : <span className="tap-avatar-subtitle--idle">
                {affiliate?.affiliate_name} · Partner Active
              </span>
          }
        </div>
      </div>

      {/* Dashboard header */}
      <div className="tap-dash-header">
        <span className="tap-dash-header__dot"/>
        <span className="tap-dash-header__title">Partner Affiliate Dashboard</span>
        <button
          className="tap-refresh-btn"
          onClick={refreshData}
          disabled={loading}
          title="Refresh"
        >
          <RefreshCw size={12} className={loading ? 'tap-spin' : ''}/>
        </button>
      </div>

      {/* Balance widgets */}
      <div className="tap-widgets">
        <div className="tap-widget" style={{ borderColor: '#38bdf833' }}>
          <Users size={14} style={{ color: '#38bdf8' }}/>
          <div className="tap-widget__body">
            <span className="tap-widget__label">Totaal Actieve Traders</span>
            <span className="tap-widget__value" style={{ color: '#38bdf8' }}>{affiliate?.active_seats ?? 0}</span>
            <span className="tap-widget__sub">seats × €{COMMISSION_PER_SEAT.toFixed(2)}</span>
          </div>
        </div>
        <div className="tap-widget" style={{ borderColor: '#4ade8033' }}>
          <DollarSign size={14} style={{ color: '#4ade80' }}/>
          <div className="tap-widget__body">
            <span className="tap-widget__label">Mijn Maandelijkse 20% Commissie</span>
            <span className="tap-widget__value" style={{ color: '#4ade80' }}>€{(affiliate?.monthly_commission_eur ?? 0).toFixed(2)}</span>
            <span className="tap-widget__sub">20% van €499.00/seat</span>
          </div>
        </div>
        <div className="tap-widget" style={{ borderColor: '#fbbf2433' }}>
          <ArrowDownToLine size={14} style={{ color: '#fbbf24' }}/>
          <div className="tap-widget__body">
            <span className="tap-widget__label">Beschikbaar voor Uitbetaling</span>
            <span className="tap-widget__value" style={{ color: '#fbbf24' }}>€{pendingBalance.toFixed(2)}</span>
            <span className="tap-widget__sub">klaar voor IBAN-transfer</span>
          </div>
        </div>
      </div>

      {/* Split info bar */}
      <div className="tap-split-bar">
        <div className="tap-split-bar__seg tap-split-bar__seg--platform">
          <Building2 size={10}/>
          <span>80% AIPPIETAX S.A.</span>
        </div>
        <div className="tap-split-bar__seg tap-split-bar__seg--partner">
          <ArrowDownToLine size={10}/>
          <span>20% Partner</span>
        </div>
      </div>

      {/* Payout form */}
      <div className="tap-payout-form">
        <div className="tap-payout-form__title">
          <ArrowDownToLine size={12} style={{ color: '#fbbf24' }}/>
          Uitbetaling Aanvragen
        </div>
        <label className="tap-form-label">IBAN</label>
        <input
          className="tap-form-input tap-form-input--mono"
          placeholder={affiliate?.iban || 'NL91 ABNA 0417 1643 00'}
          value={ibanInput}
          onChange={e => setIbanInput(e.target.value)}
        />
        <div className="tap-payout-form__balance-row">
          <span className="tap-payout-form__balance-label">
            Beschikbaar: <span style={{ color: '#fbbf24', fontWeight: 700 }}>€{pendingBalance.toFixed(2)}</span>
          </span>
          {payMsg && (
            <span className={`tap-payout-msg${payPhase === 'error' ? ' tap-payout-msg--error' : payPhase === 'success' ? ' tap-payout-msg--success' : ''}`}>
              {payMsg}
            </span>
          )}
        </div>
        <button
          className="tap-payout-btn"
          disabled={pendingBalance <= 0 || payPhase === 'processing'}
          onClick={handlePayout}
        >
          {payPhase === 'processing'
            ? <><RefreshCw size={12} className="tap-spin"/> Verwerken…</>
            : payPhase === 'success'
            ? <><CheckCircle2 size={12}/> Uitbetaling Geïnitieerd</>
            : <><ArrowDownToLine size={12}/> Uitbetaling Starten</>
          }
        </button>
      </div>

      {/* Payout history */}
      {payouts.length > 0 && (
        <div className="tap-payout-history">
          <div className="tap-payout-history__title">
            <CheckCircle2 size={11}/> Uitbetalingshistorie
          </div>
          <div className="tap-payout-history__list">
            {payouts.map(p => (
              <div key={p.id} className="tap-payout-row">
                <div className="tap-payout-row__left">
                  <span className="tap-payout-row__date">{p.created_at.slice(0, 10)}</span>
                  <span className={`tap-payout-row__status tap-payout-row__status--${p.status}`}>{p.status}</span>
                </div>
                <div className="tap-payout-row__right">
                  <span className="tap-payout-row__amount" style={{ color: '#4ade80' }}>€{Number(p.amount_eur).toFixed(2)}</span>
                  <span className="tap-payout-row__ref">{p.invoice_ref}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Referral tip */}
      <div className="tap-referral-tip">
        <ChevronRight size={11} style={{ color: '#38bdf8' }}/>
        <span>Elke nieuwe trader die jij aanmeldt genereert automatisch <strong style={{ color: '#4ade80' }}>€{COMMISSION_PER_SEAT.toFixed(2)}/maand</strong> voor jou. De split wordt direct verwerkt door AIPPIETAX S.A.</span>
      </div>

      <div className="tap-footer">
        <ShieldCheck size={10}/>
        AIPPIETAX S.A. · Partner Affiliate Matrix v147 · GDPR · Automated Revenue Split
      </div>
    </div>
  );
}

// ── Panel types ───────────────────────────────────────────────────────────────
type Panel = 'chart' | 'darkpool' | 'copy' | 'news' | 'ledger' | 'partner';

const PANELS: { key: Panel; label: string }[] = [
  { key:'chart',    label:'Chart'     },
  { key:'darkpool', label:'Dark Pool' },
  { key:'copy',     label:'Copy'      },
  { key:'news',     label:'Sentiment' },
  { key:'ledger',   label:'Ledger'    },
  { key:'partner',  label:'Partner'   },
];

// ── Main TradingView ──────────────────────────────────────────────────────────
export default function TradingView({ subscription }: Props) {
  const hasTradingAccess = subscription!==null && (subscription.plan_tier as string)==='trading_alpha';

  const [unlocked, setUnlocked]         = useState(hasTradingAccess);
  const [showPayModal, setShowPayModal] = useState(false);
  const [panel, setPanel]               = useState<Panel>('chart');
  const [ticker, setTicker]             = useState('AAPL');
  const [candles, setCandles]           = useState<Candle[]>(()=>seedCandles('AAPL'));
  const [signal, setSignal]             = useState<Signal|null>(null);
  const [waveAmps, setWaveAmps]         = useState<number[]>(Array(28).fill(4));
  const [listening, setListening]       = useState(false);
  const [dpAlert, setDpAlert]           = useState<DarkPoolTick|null>(null);
  const [avatarText,  setAvatarText]    = useState('');
  const [isSpeaking,  setIsSpeaking]    = useState(false);

  const waveRef   = useRef<ReturnType<typeof setInterval>|null>(null);
  const signalRef = useRef<ReturnType<typeof setInterval>|null>(null);
  const holdTimer = useRef<ReturnType<typeof setTimeout>|null>(null);
  const tickRef   = useRef(0);

  // ── TTS helper ───────────────────────────────────────────────────────────────
  const speak = useCallback((text: string) => {
    if (!('speechSynthesis' in window)) return;
    window.speechSynthesis.cancel();
    setAvatarText(text);
    setIsSpeaking(false);
    const fire = () => {
      const u = new SpeechSynthesisUtterance(text);
      u.pitch = 1.1; u.rate = 0.92;
      applyPremiumVoice(u);
      u.onstart = () => setIsSpeaking(true);
      u.onend   = () => setIsSpeaking(false);
      u.onerror = () => setIsSpeaking(false);
      window.speechSynthesis.speak(u);
    };
    withVoicesReady(fire);
  }, []);

  useEffect(()=>{
    if (!unlocked) return;
    const id=setInterval(()=>{
      setCandles(prev=>{
        const last=prev[prev.length-1];
        const move=(Math.random()-0.49)*last.c*0.003;
        const c=+(last.c+move).toFixed(2);
        return [...prev.slice(-59),{
          t:last.t+1, o:last.c,
          h:+(Math.max(last.c,c)*(1+Math.random()*0.002)).toFixed(2),
          l:+(Math.min(last.c,c)*(1-Math.random()*0.002)).toFixed(2), c,
        }];
      });
    },1500);
    return ()=>clearInterval(id);
  },[unlocked]);

  useEffect(()=>{
    if (!unlocked) return;
    signalRef.current=setInterval(()=>{
      setCandles(c=>{
        const sig=generateSignal(ticker,c);
        setSignal(sig);
        if (sig) {
          if (waveRef.current) clearInterval(waveRef.current);
          tickRef.current=0;
          waveRef.current=setInterval(()=>{
            tickRef.current++;
            const tk=tickRef.current;
            setWaveAmps(Array.from({length:28},(_,i)=>Math.max(3,28*Math.abs(Math.sin(tk*0.06+(i/28)*Math.PI*2)))));
          },60);
          // Contextual voice alert for new signal
          speak(`New quantitative signal detected. ${sig.ticker}: ${sig.direction}. Target price ${sig.target.toFixed(2)} dollars. Probability score ${(sig.probability*100).toFixed(0)} percent. Act within the next ${Math.round((8000-(Date.now()%8000))/1000)} seconds.`);
          setTimeout(()=>{
            setSignal(null);
            if (waveRef.current){clearInterval(waveRef.current);waveRef.current=null;}
            setWaveAmps(Array(28).fill(4));
          },8000);
        }
        return c;
      });
    },12000);
    return ()=>{if(signalRef.current)clearInterval(signalRef.current);};
  },[unlocked,ticker]);

  useEffect(()=>()=>{
    if(waveRef.current)clearInterval(waveRef.current);
    if(signalRef.current)clearInterval(signalRef.current);
    if(holdTimer.current)clearTimeout(holdTimer.current);
  },[]);

  const switchTicker = useCallback((t:string)=>{ setTicker(t); setCandles(seedCandles(t)); setSignal(null); },[]);
  const startListening = useCallback(()=>{
    setListening(true);
    holdTimer.current=setTimeout(()=>setListening(false),10_000);
  },[]);
  const stopListening = useCallback(()=>{ setListening(false); if(holdTimer.current)clearTimeout(holdTimer.current); },[]);

  const handleBrokerExecute = useCallback(async (broker:BrokerStub)=>{
    const src = dpAlert ?? signal;
    if (!src) return;
    await supabase.from('aippie_user_portfolio').insert({
      user_id:null,
      ticker: 'ticker' in src ? src.ticker : (src as Signal).ticker,
      direction: 'direction' in src ? src.direction : 'BUY',
      entry_price: 'price_hint' in src ? (src as DarkPoolTick).price_hint : (src as Signal).price,
      target_price: 'target' in src ? (src as Signal).target : (src as DarkPoolTick).price_hint*1.02,
      probability: 'momentum_pct' in src ? (src as DarkPoolTick).momentum_pct/100 : (src as Signal).probability,
      outcome:'pending', pnl_eur:0, broker_stub:broker,
    });
  },[signal,dpAlert]);

  const handleMirror = useCallback(async (t:EliteTrader)=>{
    await supabase.from('aippie_user_portfolio').insert({
      user_id:null, ticker:t.ticker, direction:t.dir,
      entry_price:0, target_price:0, probability:0.99,
      outcome:'pending', pnl_eur:0, broker_stub:'traderepublic',
    });
  },[]);

  const handleJointMove = useCallback(async ()=>{
    await supabase.from('aippie_user_portfolio').insert({
      user_id:null, ticker:'SPY', direction:'BUY',
      entry_price:0, target_price:0, probability:0.93,
      outcome:'pending', pnl_eur:0, broker_stub:'revolut',
    });
  },[]);

  const handleFrontRun = useCallback((t:DarkPoolTick)=>{
    setDpAlert(t);
    // Auto-clear the chart overlay after 10s
    setTimeout(()=>setDpAlert(null),10000);
  },[]);

  // ── Gatekeeper ───────────────────────────────────────────────────────────────
  if (!unlocked) {
    return (
      <>
        {showPayModal&&<PayModal onClose={()=>setShowPayModal(false)} onSuccess={()=>{setUnlocked(true);setShowPayModal(false);}}/>}
        <SofiaTabShell
          greeting="Aippie Trading Alpha monitors institutional dark pools and front-running signals before they hit public exchanges. Unlock to act first."
          serviceLabel="Trading Alpha · Locked"
          trustLine="AIPPIETAX S.A. · Quantitative AI Engine"
          btnLabel="UNLOCK TRADING ALPHA — €99.99/mo"
          onHoldStart={()=>setShowPayModal(true)}
        >
          <div className="ta-lock-overlay">
            <div className="ta-lock-card">
              <Lock size={26} className="ta-lock-card__icon"/>
              <div className="ta-lock-card__title">Aippie Trading Alpha</div>
              <div className="ta-lock-card__price">€99.99 <span>/month</span></div>
              <ul className="ta-lock-card__perks">
                <li>Dark Pool institutional block tracker</li>
                <li>AI Front-Running dispatch alerts</li>
                <li>Real-time AI signal engine (&gt;85% accuracy)</li>
                <li>Billionaire copy-trading hub</li>
                <li>One-tap broker execution (TR · REV · DGR)</li>
              </ul>
              <button className="ta-lock-card__btn" onClick={()=>setShowPayModal(true)}>
                <Lock size={13}/> Unlock Now
              </button>
            </div>
          </div>
        </SofiaTabShell>
      </>
    );
  }

  return (
    <div className="ta-root">

      {/* Status bar */}
      <div className="ta-status-bar">
        <span className="ta-status-bar__dot"/>
        <span className="ta-status-bar__text">LIVE QUANT CORE ACTIVE · {ticker}</span>
        <span className="ta-status-bar__badge">ALPHA</span>
      </div>

      {/* Upper: Aippie portrait */}
      <div className="ta-avatar-wrap">
        <img
          src="/Jouw_alineatekst_(2).png"
          alt="Aippie Trading Analyst" className="ta-avatar" draggable={false}
        />
        <div className="ta-avatar__fade"/>

        {/* Dark pool front-run badge */}
        {dpAlert && (
          <div className="ta-dp-avatar-badge">
            <span className="ta-dp-avatar-badge__dot"/>
            <Activity size={12}/>
            <span>FRONT-RUN · {dpAlert.ticker} {dpAlert.direction} · {dpAlert.momentum_pct.toFixed(1)}%</span>
          </div>
        )}

        {/* Regular signal badge when no dark pool */}
        {!dpAlert && signal && (
          <div className={`ta-signal-badge ta-signal-badge--${signal.direction==='BUY'?'buy':'sell'}`}>
            <span className="ta-signal-badge__dot"/>
            {signal.direction==='BUY'?<TrendingUp size={13}/>:<TrendingDown size={13}/>}
            <span>{signal.direction} SIGNAL · {(signal.probability*100).toFixed(0)}% PROB</span>
          </div>
        )}

        <div className="ta-avatar__plate">
          <div className="ta-avatar__plate-name">Aippie</div>
          <div className="ta-avatar__plate-role">Quant Analyst · AIPPIETAX S.A. · v147</div>
        </div>
      </div>

      {/* Typewriter subtitle strip — mirrors avatar speech below portrait */}
      {isSpeaking && avatarText && (
        <div className="ta-avatar-subtitle">
          <span className="ta-avatar-subtitle__text">{avatarText.split(' ').slice(0, 12).join(' ')}&hellip;</span>
        </div>
      )}

      {/* Panel tab bar */}
      <div className="ta-panel-tabs">
        {PANELS.map(p=>(
          <button key={p.key}
            className={`ta-panel-tab${panel===p.key?' ta-panel-tab--active':''}`}
            onClick={()=>setPanel(p.key)}>{p.label}
          </button>
        ))}
      </div>

      <div className="ta-panel-body">

        {/* Chart */}
        {panel==='chart'&&(
          <>
            <div className="ta-ticker-tabs">
              {TICKERS.map(t=>(
                <button key={t} className={`ta-ticker-tab${ticker===t?' ta-ticker-tab--active':''}`}
                  onClick={()=>switchTicker(t)}>{t}</button>
              ))}
            </div>
            <div className="ta-chart-wrap">
              <CandleChart candles={candles} signal={signal} waveAmps={waveAmps} dpAlert={dpAlert}/>
            </div>
            <div className="ta-signal-strip">
              {dpAlert
                ? <div className="ta-signal-strip__active ta-signal-strip__active--dp">
                    <Activity size={12}/>
                    <span>DARK POOL · {dpAlert.ticker} {dpAlert.direction} ${dpAlert.price_hint.toFixed(2)} · {dpAlert.momentum_pct.toFixed(1)}% momentum · {dpAlert.institution}</span>
                  </div>
                : signal
                  ? <div className={`ta-signal-strip__active ta-signal-strip__active--${signal.direction==='BUY'?'buy':'sell'}`}>
                      {signal.direction==='BUY'?<TrendingUp size={12}/>:<TrendingDown size={12}/>}
                      <span>{signal.ticker} · {signal.direction} TARGET ${signal.target.toFixed(2)} · {(signal.probability*100).toFixed(0)}% probability</span>
                    </div>
                  : <div className="ta-signal-strip__idle">Scanning dark pools and public exchanges…</div>
              }
            </div>
            <BrokerRow ticker={ticker} signal={signal} darkPoolAlert={dpAlert} onExecute={handleBrokerExecute}/>
          </>
        )}

        {panel==='darkpool'&&<DarkPoolTracker onFrontRun={handleFrontRun}/>}
        {panel==='copy'    &&<CopyTradingHub onMirror={handleMirror}/>}
        {panel==='news'    &&<NewsSentimentShifter onJointMove={handleJointMove}/>}
        {panel==='ledger'  &&<PortfolioLedger/>}
        {panel==='partner' &&<PartnerAffiliatePortal/>}

        {/* Hold-to-talk — always visible */}
        <div className="ta-talk-row">
          <button
            className={`sts-hold-btn ta-hold-btn${listening?' sts-hold-btn--active':''}`}
            onPointerDown={startListening} onPointerUp={stopListening}
            onPointerLeave={stopListening} onPointerCancel={stopListening}
            aria-label="Hold to talk to Aippie"
          >
            <span className="sts-hold-btn__ring sts-hold-btn__ring--1"/>
            <span className="sts-hold-btn__ring sts-hold-btn__ring--2"/>
            <span className="sts-hold-btn__core">HOLD TO TALK TO AIPPIE</span>
          </button>
        </div>
      </div>

      <AippieVoiceOverlay context="trading" />

      <div className="ta-footer">
        <ShieldCheck size={10}/>
        AIPPIETAX S.A. · Simulated data · Not financial advice
      </div>
    </div>
  );
}
