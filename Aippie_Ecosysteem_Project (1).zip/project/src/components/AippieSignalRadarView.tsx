import { useEffect, useState, useRef } from 'react';
import {
  Radio, Radar, Zap, TrendingUp, TrendingDown,
  Activity, Play, Pause, Shield, AlertTriangle, Globe, Newspaper,
  RefreshCw,
} from 'lucide-react';
import { supabase } from '../lib/supabase';

interface SignalItem {
  id: string;
  type: 'news' | 'signal';
  source: string;
  headline: string;
  sentiment: 'bullish' | 'bearish' | 'neutral' | null;
  sentiment_score: number | null;
  asset: string | null;
  direction: 'BUY' | 'SELL' | 'HOLD' | null;
  confidence: number | null;
  status: 'pending' | 'executing' | 'completed' | 'cancelled';
  pnl: number | null;
  created_at: string;
}

const SENTIMENT_COLOR: Record<string, string> = {
  bullish: '#4ade80', bearish: '#f87171', neutral: '#94a3b8',
};
const STATUS_COLOR: Record<string, string> = {
  pending: '#fbbf24', executing: '#38bdf8', completed: '#4ade80', cancelled: '#64748b',
};
const DIR_COLOR: Record<string, string> = {
  BUY: '#4ade80', SELL: '#f87171', HOLD: '#fbbf24',
};

export default function AippieSignalRadarView() {
  const [items, setItems]       = useState<SignalItem[]>([]);
  const [loading, setLoading]   = useState(true);
  const [running, setRunning]   = useState(true);
  const [filter, setFilter]     = useState<'all' | 'news' | 'signal'>('all');
  const [sentiment, setSentiment] = useState<'all' | 'bullish' | 'bearish' | 'neutral'>('all');
  const [scanAngle, setScanAngle] = useState(0);
  const rafRef = useRef<number>(0);
  const angleRef = useRef(0);

  const load = async () => {
    const { data } = await supabase
      .from('signal_radar_items')
      .select('*')
      .order('created_at', { ascending: false })
      .limit(50);
    if (data) setItems(data as SignalItem[]);
    setLoading(false);
  };

  useEffect(() => { load(); }, []);

  // Radar sweep animation
  useEffect(() => {
    const tick = () => {
      if (running) {
        angleRef.current = (angleRef.current + 0.6) % 360;
        setScanAngle(angleRef.current);
      }
      rafRef.current = requestAnimationFrame(tick);
    };
    rafRef.current = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(rafRef.current);
  }, [running]);

  // Realtime subscription for new signals
  useEffect(() => {
    const channel = supabase
      .channel('signal_radar_realtime')
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'signal_radar_items' }, payload => {
        setItems(prev => [payload.new as SignalItem, ...prev.slice(0, 49)]);
      })
      .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'signal_radar_items' }, payload => {
        setItems(prev => prev.map(i => i.id === (payload.new as SignalItem).id ? payload.new as SignalItem : i));
      })
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  }, []);

  const filtered = items.filter(i => {
    if (filter !== 'all' && i.type !== filter) return false;
    if (sentiment !== 'all' && i.sentiment !== sentiment) return false;
    return true;
  });

  const news    = filtered.filter(i => i.type === 'news');
  const signals = filtered.filter(i => i.type === 'signal');

  return (
    <div className="sr-root">
      {/* Header */}
      <div className="sr-header">
        <div className="sr-header__left">
          <div className="sr-header__icon-wrap">
            <Radar size={20} className="sr-header__icon" />
          </div>
          <div>
            <div className="sr-header__title">Signal Radar</div>
            <div className="sr-header__sub">Live AI news · {items.length} signals geladen</div>
          </div>
        </div>
        <div className="sr-header__right">
          <button className="sr-control-btn" onClick={() => setRunning(r => !r)}>
            {running ? <Pause size={13} /> : <Play size={13} />}
            {running ? 'Pauzeer' : 'Hervat'}
          </button>
          <button className="sr-control-btn" onClick={() => { setLoading(true); load(); }}>
            <RefreshCw size={12} className={loading ? 'mb-spin' : ''} />
          </button>
        </div>
      </div>

      {/* Radar + stats */}
      <div className="sr-top-grid">
        {/* Radar canvas */}
        <div className="sr-radar-wrap">
          <svg width="160" height="160" viewBox="0 0 160 160">
            {[1,2,3,4].map(r => (
              <circle key={r} cx="80" cy="80" r={r*18} fill="none" stroke="rgba(56,189,248,0.12)" strokeWidth="1" />
            ))}
            <line x1="80" y1="80" x2="80" y2="10" stroke="rgba(56,189,248,0.15)" strokeWidth="1" />
            <line x1="80" y1="80" x2="150" y2="80" stroke="rgba(56,189,248,0.15)" strokeWidth="1" />
            <line x1="80" y1="80" x2="80" y2="150" stroke="rgba(56,189,248,0.15)" strokeWidth="1" />
            <line x1="80" y1="80" x2="10" y2="80" stroke="rgba(56,189,248,0.15)" strokeWidth="1" />
            {/* Sweep */}
            <defs>
              <linearGradient id="sweep-grad" x1="0" y1="0" x2="1" y2="0">
                <stop offset="0%" stopColor="#38bdf8" stopOpacity="0" />
                <stop offset="100%" stopColor="#38bdf8" stopOpacity="0.35" />
              </linearGradient>
            </defs>
            <path
              d={`M80,80 L${80 + 70 * Math.cos((scanAngle - 90) * Math.PI / 180)},${80 + 70 * Math.sin((scanAngle - 90) * Math.PI / 180)}`}
              stroke="#38bdf8"
              strokeWidth="2"
              strokeLinecap="round"
            />
            {/* Blips */}
            {signals.slice(0, 6).map((s, i) => {
              const angle = (i * 60 + scanAngle * 0.3) % 360;
              const r = 20 + (i * 11) % 45;
              const x = 80 + r * Math.cos((angle - 90) * Math.PI / 180);
              const y = 80 + r * Math.sin((angle - 90) * Math.PI / 180);
              return (
                <circle key={s.id} cx={x} cy={y} r="3.5"
                  fill={s.direction === 'BUY' ? '#4ade80' : '#f87171'}
                  opacity="0.9">
                  <animate attributeName="opacity" values="0.9;0.3;0.9" dur="1.5s" repeatCount="indefinite" />
                </circle>
              );
            })}
          </svg>
          <div className="sr-radar-label">
            <Activity size={10} />
            {running ? 'SCANNING' : 'PAUSED'}
          </div>
        </div>

        {/* Stats */}
        <div className="sr-stats">
          {[
            { label: 'Signalen', val: signals.length, color: '#38bdf8' },
            { label: 'Nieuws', val: news.length, color: '#94a3b8' },
            { label: 'BUY', val: signals.filter(s => s.direction === 'BUY').length, color: '#4ade80' },
            { label: 'SELL', val: signals.filter(s => s.direction === 'SELL').length, color: '#f87171' },
          ].map(s => (
            <div key={s.label} className="sr-stat-card">
              <div className="sr-stat-card__val" style={{ color: s.color }}>{s.val}</div>
              <div className="sr-stat-card__label">{s.label}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Filters */}
      <div className="sr-filters">
        {(['all','news','signal'] as const).map(f => (
          <button key={f} className={`sr-filter-btn${filter === f ? ' sr-filter-btn--active' : ''}`}
            onClick={() => setFilter(f)}>
            {f === 'all' ? 'Alles' : f === 'news' ? 'Nieuws' : 'Signalen'}
          </button>
        ))}
        <div className="sr-filters__sep" />
        {(['all','bullish','bearish','neutral'] as const).map(s => (
          <button key={s} className={`sr-filter-btn${sentiment === s ? ' sr-filter-btn--active' : ''}`}
            onClick={() => setSentiment(s)}
            style={sentiment === s && s !== 'all' ? { color: SENTIMENT_COLOR[s], borderColor: SENTIMENT_COLOR[s] + '44' } : undefined}>
            {s === 'all' ? 'Alle sentiment' : s}
          </button>
        ))}
      </div>

      {/* Signals list */}
      {signals.length > 0 && (
        <div className="sr-section">
          <div className="sr-section-label"><Zap size={10} /> Actieve Trading Signalen</div>
          <div className="sr-signals-list">
            {signals.map(s => (
              <div key={s.id} className="sr-signal-card" style={{ borderColor: (s.direction ? DIR_COLOR[s.direction] : '#38bdf8') + '33' }}>
                <div className="sr-signal-card__top">
                  <span className="sr-signal-card__asset">{s.asset}</span>
                  {s.direction && (
                    <span className="sr-signal-card__dir" style={{ color: DIR_COLOR[s.direction], background: DIR_COLOR[s.direction] + '18' }}>
                      {s.direction === 'BUY' ? <TrendingUp size={10} /> : <TrendingDown size={10} />}
                      {s.direction}
                    </span>
                  )}
                  <span className="sr-signal-card__status" style={{ color: STATUS_COLOR[s.status] }}>
                    {s.status.toUpperCase()}
                  </span>
                </div>
                <div className="sr-signal-card__headline">{s.headline}</div>
                <div className="sr-signal-card__bottom">
                  <span className="sr-signal-card__source">{s.source}</span>
                  {s.confidence != null && (
                    <span className="sr-signal-card__conf">
                      <Shield size={9} /> {s.confidence}% confidence
                    </span>
                  )}
                  {s.pnl != null && (
                    <span className={s.pnl >= 0 ? 'mb-pos' : 'mb-neg'}>
                      {s.pnl >= 0 ? '+' : ''}${s.pnl.toFixed(0)}
                    </span>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* News list */}
      {news.length > 0 && (
        <div className="sr-section">
          <div className="sr-section-label"><Newspaper size={10} /> Nieuws Feed</div>
          <div className="sr-news-list">
            {news.map(n => (
              <div key={n.id} className="sr-news-item">
                <div className="sr-news-item__left">
                  <span className="sr-news-item__source">{n.source}</span>
                  {n.sentiment && (
                    <span className="sr-news-item__sentiment" style={{ color: SENTIMENT_COLOR[n.sentiment] }}>
                      {n.sentiment}
                    </span>
                  )}
                </div>
                <div className="sr-news-item__headline">{n.headline}</div>
                <div className="sr-news-item__right">
                  {n.asset && <span className="sr-news-item__asset">{n.asset}</span>}
                  {n.sentiment_score != null && (
                    <span className="sr-news-item__score"
                      style={{ color: (n.sentiment_score ?? 0) >= 0 ? '#4ade80' : '#f87171' }}>
                      {(n.sentiment_score ?? 0) >= 0 ? '+' : ''}{(n.sentiment_score ?? 0).toFixed(2)}
                    </span>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {loading && items.length === 0 && (
        <div style={{ display: 'flex', justifyContent: 'center', padding: '40px' }}>
          <div className="cag-checking__spinner" />
        </div>
      )}

      <div className="sr-footer">
        <Globe size={10} /> AIPPIETAX S.A. · Signal Radar · Alleen informatief, geen beleggingsadvies
        <Radio size={10} style={{ marginLeft: 8 }} />
      </div>
    </div>
  );
}
