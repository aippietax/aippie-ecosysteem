/**
 * PayrollView — V66 Multi-Jurisdiction Payroll & Invoicing Engine
 * AIPPIETAX S.A.
 *
 * Supports:
 *   ES  — Nóminas (IRPF + Seguridad Social)
 *   NL  — Loonstrook (Loonheffing + Pension + AOF)
 *   US  — Paycheck (Federal/State + FICA)
 *   INV — Multi-currency invoices with Verifactu chain (EUR/USD/GBP/…)
 */
import { useCallback, useEffect, useRef, useState } from 'react';
import {
  ShieldCheck, FileText, Globe, DollarSign, Euro,
  Calculator, CheckCircle2, AlertCircle, RefreshCw,
  ChevronDown, ChevronUp, Lock, Zap, Building2,
  Users, TrendingUp, Download, Send, BarChart3, Landmark
} from 'lucide-react';
import { supabase } from '../lib/supabase';

// ─── Types ────────────────────────────────────────────────────────────────────
type Jurisdiction = 'ES' | 'NL' | 'US' | 'GLOBAL';
type Currency = 'EUR' | 'USD' | 'GBP' | 'CHF' | 'SEK' | 'CAD' | 'AUD';
type PayFreq = 'monthly' | 'bi-weekly' | 'weekly';
type ComplianceType = 'nomina_es' | 'payslip_nl' | 'w2_us' | '1099_us' | 'global';
type InvoiceStatus = 'draft' | 'issued' | 'sent' | 'paid' | 'overdue' | 'cancelled';
type ActiveTab = 'payroll' | 'invoices';

type PayrollEntry = {
  id: string;
  employee_name: string;
  jurisdiction: Jurisdiction;
  compliance_type: ComplianceType;
  pay_period_start: string;
  pay_period_end: string;
  gross_salary: number;
  currency: string;
  net_salary: number;
  total_deductions: number;
  irpf_withheld: number;
  ss_employee_amount: number;
  loonheffing_amount: number;
  pension_amount: number;
  federal_income_tax: number;
  fica_ss_amount: number;
  fica_medicare_amount: number;
  created_at: string;
};

type Invoice = {
  id: string;
  invoice_number: string;
  jurisdiction: Jurisdiction;
  client_name: string;
  currency: string;
  total_amount: number;
  total_eur: number;
  invoice_status: InvoiceStatus;
  issued_at: string | null;
  verifactu_enabled: boolean;
  hacienda_transmitted: boolean;
  created_at: string;
};

// ─── Jurisdiction configuration ───────────────────────────────────────────────
const JURISDICTION_CFG: Record<Jurisdiction, {
  label: string; flag: string; currency: Currency;
  color: string; border: string; complianceLabel: string;
  description: string;
}> = {
  ES: {
    label: 'Spain', flag: 'ES', currency: 'EUR',
    color: '#f87171', border: 'rgba(248,113,113,0.2)',
    complianceLabel: 'Nómina · IRPF · SS',
    description: 'IRPF withholding + Seguridad Social (employee 6.28% + employer 23.60%)',
  },
  NL: {
    label: 'Netherlands', flag: 'NL', currency: 'EUR',
    color: '#fb923c', border: 'rgba(251,146,60,0.2)',
    complianceLabel: 'Loonstrook · Loonheffing',
    description: 'Loonheffing wage tax + Pension 5.5% + AOF premium 0.56%',
  },
  US: {
    label: 'United States', flag: 'US', currency: 'USD',
    color: '#38bdf8', border: 'rgba(56,189,248,0.2)',
    complianceLabel: 'W-2 / 1099 · FICA',
    description: 'Federal income tax + State tax + FICA (SS 6.2% + Medicare 1.45%)',
  },
  GLOBAL: {
    label: 'Global', flag: 'GL', currency: 'USD',
    color: '#4ade80', border: 'rgba(74,222,128,0.2)',
    complianceLabel: 'International · Multi-currency',
    description: 'Configurable international payroll with multi-currency support',
  },
};

// ─── Live exchange rates (snapshot — updated on mount) ────────────────────────
// In production these would be fetched from a rates API; here we use a
// realistic static snapshot that is clearly labeled as such.
const EXCHANGE_RATES: Record<Currency, number> = {
  EUR: 1.0,
  USD: 1.085,
  GBP: 0.857,
  CHF: 0.956,
  SEK: 11.42,
  CAD: 1.478,
  AUD: 1.652,
};

// ─── IRPF — Spain, Andalucía 2026 ─────────────────────────────────────────────
// Real Spanish income tax has TWO scales applied together: the national
// (estatal) scale and the regional (autonómica) scale, which differs by
// Comunidad Autónoma. AIPPIETAX S.A. is registered in Mijas (Málaga),
// Andalucía — so the Andalucía autonómica scale applies, not a generic
// national-only figure. Both scales also subtract a personal/family
// allowance (mínimo personal y familiar) before tax is calculated, matching
// what appears on the actual Modelo 100 (boxes 0511/0512).
const IRPF_ESTATAL_2026: [number, number, number][] = [
  [0,      12450,  0.19],
  [12450,  20200,  0.24],
  [20200,  35200,  0.30],
  [35200,  60000,  0.37],
  [60000,  300000, 0.45],
  [300000, Infinity, 0.47],
];

// Escala autonómica Andalucía (vigente desde la reforma 2023, sin cambios
// relevantes para 2026). For other Comunidades Autónomas this scale must be
// swapped — the structure (estatal + autonómica + mínimo) stays the same.
const IRPF_ANDALUCIA_2026: [number, number, number][] = [
  [0,      13000,  0.095],
  [13000,  21000,  0.12],
  [21000,  35200,  0.15],
  [35200,  60000,  0.185],
  [60000,  120000, 0.225],
  [120000, Infinity, 0.245],
];

const MINIMO_PERSONAL_ESTATAL = 5550;
const MINIMO_PERSONAL_ANDALUCIA = 5790;

function bracketTax(brackets: [number, number, number][], gross: number): number {
  let tax = 0;
  for (const [lo, hi, rate] of brackets) {
    if (gross <= lo) break;
    tax += (Math.min(gross, hi) - lo) * rate;
  }
  return tax;
}

function calcIRPF(grossAnnual: number): number {
  const estatalOnIncome = bracketTax(IRPF_ESTATAL_2026, grossAnnual);
  const estatalOnMinimo = bracketTax(IRPF_ESTATAL_2026, MINIMO_PERSONAL_ESTATAL);
  const autonomicaOnIncome = bracketTax(IRPF_ANDALUCIA_2026, grossAnnual);
  const autonomicaOnMinimo = bracketTax(IRPF_ANDALUCIA_2026, MINIMO_PERSONAL_ANDALUCIA);

  const totalTax = Math.max(0, estatalOnIncome - estatalOnMinimo)
                  + Math.max(0, autonomicaOnIncome - autonomicaOnMinimo);

  return grossAnnual > 0 ? totalTax / grossAnnual : 0;
}

// ─── Netherlands wage tax — 2026 official tables (simplified, single bracket
// set, no special arrangements like 30%-ruling, no pensioenpremie deduction
// before tax). This computes loonheffing AFTER applying:
//   1. Loonbelasting/premie volksverzekeringen on the bracket system
//   2. Algemene heffingskorting (general tax credit) — reduces tax owed
//   3. Arbeidskorting (labor tax credit) — reduces tax owed for employment income
// Source: Belastingdienst loonbelastingtabellen, 2026 parameters.
// These figures should be reviewed annually — Belastingdienst publishes new
// brackets and credit thresholds every January.
const NL_BRACKETS_2026: [number, number, number][] = [
  [0,      38441,   0.3582],
  [38441,  76817,   0.3748],
  [76817,  Infinity, 0.495],
];

function calcAlgemeneHeffingskorting(grossAnnual: number): number {
  // Phases out between ~€24,812 and ~€75,518 (2026 approximate parameters)
  const MAX_CREDIT = 3070;
  const PHASEOUT_START = 24812;
  const PHASEOUT_END = 75518;
  if (grossAnnual <= PHASEOUT_START) return MAX_CREDIT;
  if (grossAnnual >= PHASEOUT_END) return 0;
  const reduction = (grossAnnual - PHASEOUT_START) / (PHASEOUT_END - PHASEOUT_START);
  return Math.max(0, MAX_CREDIT * (1 - reduction));
}

function calcArbeidskorting(grossAnnual: number): number {
  // Simplified 2026 arbeidskorting curve — builds up, plateaus, then phases out
  if (grossAnnual <= 0) return 0;
  if (grossAnnual <= 12169) return grossAnnual * 0.08425;
  if (grossAnnual <= 26288) return 1025 + (grossAnnual - 12169) * 0.31433;
  if (grossAnnual <= 43071) return 5460;
  if (grossAnnual <= 129078) return Math.max(0, 5460 - (grossAnnual - 43071) * 0.0635);
  return 0;
}

function calcLoonheffingNL(grossAnnual: number, applyHeffingskorting: boolean): { pct: number; annualTax: number } {
  let grossTax = 0;
  for (const [lo, hi, rate] of NL_BRACKETS_2026) {
    if (grossAnnual <= lo) break;
    grossTax += (Math.min(grossAnnual, hi) - lo) * rate;
  }

  let netAnnualTax = grossTax;
  if (applyHeffingskorting) {
    const credits = calcAlgemeneHeffingskorting(grossAnnual) + calcArbeidskorting(grossAnnual);
    netAnnualTax = Math.max(0, grossTax - credits);
  }

  return {
    pct: grossAnnual > 0 ? netAnnualTax / grossAnnual : 0,
    annualTax: netAnnualTax,
  };
}


// ─── US — Federal + State income tax ──────────────────────────────────────────
// State income tax varies enormously: some states (TX, FL, WA, NV, ...) have
// NO state income tax at all, while others (CA, NY, ...) have steep brackets.
// A single flat 9.3% applied to every US employee regardless of state was
// simply wrong. This is a configurable lookup with the most common states
// covered; unknown/unlisted states fall back to a clearly-flagged 0% so the
// number is at least not silently wrong — it surfaces as "needs setup".
const US_STATE_FLAT_RATES: Record<string, number> = {
  CA: 0.093,  // simplified flat approximation of CA's top progressive bracket
  NY: 0.0685,
  TX: 0,      // no state income tax
  FL: 0,      // no state income tax
  WA: 0,      // no state income tax
  NV: 0,      // no state income tax
  IL: 0.0495, // flat rate state
  PA: 0.0307, // flat rate state
  MA: 0.05,
  NJ: 0.0637,
};

function calcStateTax(grossAnnualUSD: number, state: string): number {
  const rate = US_STATE_FLAT_RATES[state] ?? 0;
  return grossAnnualUSD * rate;
}
function calcFederalTax(grossAnnual: number): number {
  const brackets: [number, number, number][] = [
    [0,       11600,  0.10],
    [11600,   47150,  0.12],
    [47150,   100525, 0.22],
    [100525,  191950, 0.24],
    [191950,  243725, 0.32],
    [243725,  609350, 0.35],
    [609350,  Infinity, 0.37],
  ];
  let tax = 0;
  for (const [lo, hi, rate] of brackets) {
    if (grossAnnual <= lo) break;
    tax += (Math.min(grossAnnual, hi) - lo) * rate;
  }
  return tax / grossAnnual;
}

// ─── Payroll calculation engine ───────────────────────────────────────────────
type CalcResult = {
  irpf_pct: number; irpf_withheld: number;
  ss_employee_pct: number; ss_employee_amount: number;
  ss_employer_pct: number; ss_employer_amount: number;
  loonheffing_pct: number; loonheffing_amount: number;
  aof_premium_amount: number; pension_amount: number;
  federal_income_tax_pct: number; federal_income_tax: number;
  state_income_tax_pct: number; state_income_tax: number;
  fica_ss_amount: number; fica_medicare_amount: number;
  total_deductions: number; net_salary: number;
  compliance_type: ComplianceType;
};

function calculatePayroll(
  grossSalary: number,
  jurisdiction: Jurisdiction,
  freqMultiplier: number,  // 1=monthly, 26=bi-weekly, 52=weekly (for annual projection)
  currency: Currency,
  isContractor: boolean,
  applyLoonheffingskorting: boolean = true, // NL only: usually applied at the main employer
  usState: string = 'CA', // US only: which state's income tax applies
): CalcResult {
  const grossEUR = grossSalary / (EXCHANGE_RATES[currency] ?? 1);
  const grossAnnual = grossEUR * freqMultiplier;
  let r: CalcResult = {
    irpf_pct: 0, irpf_withheld: 0,
    ss_employee_pct: 0, ss_employee_amount: 0,
    ss_employer_pct: 0, ss_employer_amount: 0,
    loonheffing_pct: 0, loonheffing_amount: 0,
    aof_premium_amount: 0, pension_amount: 0,
    federal_income_tax_pct: 0, federal_income_tax: 0,
    state_income_tax_pct: 0, state_income_tax: 0,
    fica_ss_amount: 0, fica_medicare_amount: 0,
    total_deductions: 0, net_salary: 0,
    compliance_type: 'global',
  };

  if (jurisdiction === 'ES') {
    r.compliance_type = 'nomina_es';
    r.irpf_pct = calcIRPF(grossAnnual);
    r.irpf_withheld = grossSalary * r.irpf_pct;
    r.ss_employee_pct = 0.0628;
    r.ss_employee_amount = grossSalary * r.ss_employee_pct;
    r.ss_employer_pct = 0.2360;
    r.ss_employer_amount = grossSalary * r.ss_employer_pct;
  } else if (jurisdiction === 'NL') {
    r.compliance_type = 'payslip_nl';
    const { pct, annualTax } = calcLoonheffingNL(grossAnnual, applyLoonheffingskorting);
    r.loonheffing_pct = pct;
    r.loonheffing_amount = annualTax / freqMultiplier;
    r.aof_premium_amount = grossSalary * 0.0056;
    r.pension_amount = grossSalary * 0.055;
  } else if (jurisdiction === 'US') {
    r.compliance_type = isContractor ? '1099_us' : 'w2_us';
    // Federal brackets are denominated in USD — convert the EUR-normalized
    // grossAnnual back to USD for this calculation, not the other way
    // around (the old code multiplied by EXCHANGE_RATES.USD on an
    // already-EUR figure, which double-converted and gave a wrong base).
    const grossAnnualUSD = grossAnnual * EXCHANGE_RATES.USD;
    r.federal_income_tax_pct = calcFederalTax(grossAnnualUSD);
    r.federal_income_tax = (grossAnnualUSD * r.federal_income_tax_pct) / freqMultiplier / EXCHANGE_RATES.USD;
    const stateTaxAnnualUSD = calcStateTax(grossAnnualUSD, usState);
    r.state_income_tax_pct = grossAnnualUSD > 0 ? stateTaxAnnualUSD / grossAnnualUSD : 0;
    r.state_income_tax = (stateTaxAnnualUSD / freqMultiplier) / EXCHANGE_RATES.USD;
    r.fica_ss_amount = Math.min(grossSalary, 160200 / 12) * 0.062;
    r.fica_medicare_amount = grossSalary * 0.0145;
  } else {
    r.compliance_type = 'global';
  }

  r.total_deductions =
    r.irpf_withheld +
    r.ss_employee_amount +
    r.loonheffing_amount +
    r.aof_premium_amount +
    r.pension_amount +
    r.federal_income_tax +
    r.state_income_tax +
    r.fica_ss_amount +
    r.fica_medicare_amount;

  r.net_salary = grossSalary - r.total_deductions;
  return r;
}

// ─── Simple Verifactu hash (SHA-256 chain simulation) ────────────────────────
async function computeChainHash(prevHash: string, payload: string): Promise<string> {
  const data = new TextEncoder().encode(prevHash + '|' + payload);
  const buf  = await crypto.subtle.digest('SHA-256', data);
  return Array.from(new Uint8Array(buf)).map(b => b.toString(16).padStart(2,'0')).join('');
}

// ─── Currency symbol map ──────────────────────────────────────────────────────
const CURRENCY_SYMBOL: Record<Currency, string> = {
  EUR: '€', USD: '$', GBP: '£', CHF: 'Fr', SEK: 'kr', CAD: 'C$', AUD: 'A$',
};

function fmt(n: number, currency: Currency = 'EUR'): string {
  const sym = CURRENCY_SYMBOL[currency] ?? currency;
  return `${sym}${n.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}

function pct(n: number): string {
  return `${(n * 100).toFixed(2)}%`;
}

// ─── Invoice number generator ─────────────────────────────────────────────────
function genInvoiceNumber(jurisdiction: Jurisdiction, seq: number): string {
  const y = new Date().getFullYear();
  const prefix = jurisdiction === 'ES' ? 'FAC' : jurisdiction === 'NL' ? 'INV' : jurisdiction === 'US' ? 'INV' : 'GLB';
  return `${prefix}-${y}-${String(seq).padStart(4, '0')}`;
}

// ─── Main component ───────────────────────────────────────────────────────────
export default function PayrollView() {
  const deviceKey = localStorage.getItem('aippie_device_key') ?? '';

  const [tab, setTab] = useState<ActiveTab>('payroll');

  // Payroll form state
  const [pJurisdiction, setPJurisdiction] = useState<Jurisdiction>('ES');
  const [pEmployeeName, setPEmployeeName] = useState('');
  const [pEmployeeId,   setPEmployeeId]   = useState('');
  const [pCompanyName,  setPCompanyName]  = useState('');
  const [pCompanyTaxId, setPCompanyTaxId] = useState('');
  const [pGross,        setPGross]        = useState('');
  const [pCurrency,     setPCurrency]     = useState<Currency>('EUR');
  const [pFreq,         setPFreq]         = useState<PayFreq>('monthly');
  const [pContractor,   setPContractor]   = useState(false);
  const [pPeriodStart,  setPPeriodStart]  = useState('');
  const [pPeriodEnd,    setPPeriodEnd]    = useState('');

  // Payroll calculation preview
  const [calcResult, setCalcResult]       = useState<CalcResult | null>(null);
  const [pSaving,    setPSaving]          = useState(false);
  const [pSaved,     setPSaved]           = useState(false);

  // Invoice form state
  const [iJurisdiction, setIJurisdiction] = useState<Jurisdiction>('ES');
  const [iIssuerName,   setIIssuerName]   = useState('');
  const [iIssuerTaxId,  setIIssuerTaxId]  = useState('');
  const [iClientName,   setIClientName]   = useState('');
  const [iClientTaxId,  setIClientTaxId]  = useState('');
  const [iClientCountry,setIClientCountry]= useState('ES');
  const [iCurrency,     setICurrency]     = useState<Currency>('EUR');
  const [iSubtotal,     setISubtotal]     = useState('');
  const [iVatPct,       setIVatPct]       = useState('21');
  const [iDueDate,      setIDueDate]      = useState('');
  const [iNotes,        setINotes]        = useState('');
  const [iVerifactu,    setIVerifactu]    = useState(true);
  const [iSaving,       setISaving]       = useState(false);
  const [iSaved,        setISaved]        = useState<Invoice | null>(null);

  // Ledger
  const [payrollList, setPayrollList]     = useState<PayrollEntry[]>([]);
  const [invoiceList, setInvoiceList]     = useState<Invoice[]>([]);
  const [loadingLedger, setLoadingLedger] = useState(false);
  const [expandedPay,  setExpandedPay]    = useState<string | null>(null);
  const [expandedInv,  setExpandedInv]    = useState<string | null>(null);

  const invoiceSeqRef = useRef(1);

  // ── Load ledger data ─────────────────────────────────────────────────────────
  const loadLedger = useCallback(async () => {
    setLoadingLedger(true);
    const [pe, inv] = await Promise.all([
      supabase
        .from('payroll_entries')
        .select('id,employee_name,jurisdiction,compliance_type,pay_period_start,pay_period_end,gross_salary,currency,net_salary,total_deductions,irpf_withheld,ss_employee_amount,loonheffing_amount,pension_amount,federal_income_tax,fica_ss_amount,fica_medicare_amount,created_at')
        .order('created_at', { ascending: false })
        .limit(20),
      supabase
        .from('invoices')
        .select('id,invoice_number,jurisdiction,client_name,currency,total_amount,total_eur,invoice_status,issued_at,verifactu_enabled,hacienda_transmitted,created_at')
        .order('created_at', { ascending: false })
        .limit(20),
    ]);
    if (pe.data) setPayrollList(pe.data as PayrollEntry[]);
    if (inv.data) {
      setInvoiceList(inv.data as Invoice[]);
      invoiceSeqRef.current = inv.data.length + 1;
    }
    setLoadingLedger(false);
  }, []);

  useEffect(() => { loadLedger(); }, [loadLedger]);

  // ── Live calculation on form change ─────────────────────────────────────────
  useEffect(() => {
    const gross = parseFloat(pGross);
    if (!gross || gross <= 0) { setCalcResult(null); return; }
    const freqMult = pFreq === 'monthly' ? 12 : pFreq === 'bi-weekly' ? 26 : 52;
    setCalcResult(calculatePayroll(gross, pJurisdiction, freqMult, pCurrency, pContractor));
  }, [pGross, pJurisdiction, pCurrency, pFreq, pContractor]);

  // ── Save payroll entry ───────────────────────────────────────────────────────
  const savePayroll = useCallback(async () => {
    if (!calcResult || !pEmployeeName || !pGross || !pPeriodStart || !pPeriodEnd) return;
    setPSaving(true);
    const gross = parseFloat(pGross);

    const row = {
      device_key: deviceKey,
      employee_name: pEmployeeName,
      employee_id_ref: pEmployeeId,
      company_name: pCompanyName,
      company_tax_id: pCompanyTaxId,
      jurisdiction: pJurisdiction,
      compliance_type: calcResult.compliance_type,
      pay_period_start: pPeriodStart,
      pay_period_end: pPeriodEnd,
      pay_frequency: pFreq,
      gross_salary: gross,
      currency: pCurrency,
      exchange_rate_to_eur: EXCHANGE_RATES[pCurrency] ?? 1,
      irpf_pct: calcResult.irpf_pct,
      irpf_withheld: calcResult.irpf_withheld,
      ss_employee_pct: calcResult.ss_employee_pct,
      ss_employee_amount: calcResult.ss_employee_amount,
      ss_employer_pct: calcResult.ss_employer_pct,
      ss_employer_amount: calcResult.ss_employer_amount,
      loonheffing_pct: calcResult.loonheffing_pct,
      loonheffing_amount: calcResult.loonheffing_amount,
      aof_premium_amount: calcResult.aof_premium_amount,
      pension_amount: calcResult.pension_amount,
      federal_income_tax_pct: calcResult.federal_income_tax_pct,
      federal_income_tax: calcResult.federal_income_tax,
      state_income_tax_pct: calcResult.state_income_tax_pct,
      state_income_tax: calcResult.state_income_tax,
      fica_ss_amount: calcResult.fica_ss_amount,
      fica_medicare_amount: calcResult.fica_medicare_amount,
      total_deductions: calcResult.total_deductions,
      net_salary: calcResult.net_salary,
    };

    const { error } = await supabase.from('payroll_entries').insert(row);

    if (!error) {
      // Mirror to aippietax_receipt_ledger for unified ledger view
      await supabase.from('aippietax_receipt_ledger').insert({
        device_key: deviceKey,
        entry_date: pPeriodEnd,
        description: `Payroll · ${pEmployeeName} · ${JURISDICTION_CFG[pJurisdiction].label}`,
        counterparty: pCompanyName || 'AIPPIETAX S.A.',
        amount_eur: calcResult.net_salary / (EXCHANGE_RATES[pCurrency] ?? 1),
        vat_amount: 0,
        category: 'payroll',
        entity_type: 'sl',
        deductible: true,
      });
      setPSaved(true);
      setTimeout(() => setPSaved(false), 3000);
      loadLedger();
    }
    setPSaving(false);
  }, [calcResult, pEmployeeName, pGross, pPeriodStart, pPeriodEnd, pEmployeeId,
      pCompanyName, pCompanyTaxId, pJurisdiction, pCurrency, pFreq, deviceKey, loadLedger]);

  // ── Save invoice ─────────────────────────────────────────────────────────────
  const saveInvoice = useCallback(async () => {
    if (!iIssuerName || !iClientName || !iSubtotal) return;
    setISaving(true);

    const subtotal = parseFloat(iSubtotal);
    const vatPct   = parseFloat(iVatPct) / 100;
    const vatAmt   = subtotal * vatPct;
    const total    = subtotal + vatAmt;
    const rate     = EXCHANGE_RATES[iCurrency] ?? 1;
    const totalEUR = total / rate;

    const invNum = genInvoiceNumber(iJurisdiction, invoiceSeqRef.current);

    // Verifactu chain hash
    let chainHash = '';
    let qrPayload = '';
    if (iVerifactu && iJurisdiction === 'ES') {
      const prevHash = invoiceList[0]?.['chain_hash' as keyof Invoice] as string ?? '';
      const payload  = `${invNum}|${iIssuerTaxId}|${total.toFixed(2)}|${new Date().toISOString()}`;
      chainHash  = await computeChainHash(String(prevHash), payload);
      qrPayload  = `VFCTU:${chainHash.slice(0, 32)}|${invNum}|${total.toFixed(2)}EUR`;
    }

    const row = {
      device_key: deviceKey,
      invoice_number: invNum,
      jurisdiction: iJurisdiction,
      issuer_name: iIssuerName,
      issuer_tax_id: iIssuerTaxId,
      client_name: iClientName,
      client_tax_id: iClientTaxId,
      client_country: iClientCountry,
      currency: iCurrency,
      exchange_rate_to_eur: rate,
      subtotal,
      vat_pct: vatPct,
      vat_amount: vatAmt,
      total_amount: total,
      total_eur: totalEUR,
      invoice_status: 'issued',
      issued_at: new Date().toISOString(),
      due_date: iDueDate || null,
      notes: iNotes,
      verifactu_enabled: iVerifactu && iJurisdiction === 'ES',
      chain_hash: chainHash,
      qr_code_payload: qrPayload,
    };

    const { data, error } = await supabase.from('invoices').insert(row).select('*').single();

    if (!error && data) {
      // Mirror to aippietax_receipt_ledger
      await supabase.from('aippietax_receipt_ledger').insert({
        device_key: deviceKey,
        entry_date: new Date().toISOString().slice(0, 10),
        description: `Invoice ${invNum} · ${iClientName}`,
        counterparty: iClientName,
        amount_eur: totalEUR,
        vat_amount: vatAmt / rate,
        category: 'invoice',
        entity_type: 'sl',
        deductible: false,
        optimization_flag: iVerifactu && iJurisdiction === 'ES' ? 'verifactu_chain' : null,
      });
      setISaved(data as Invoice);
      invoiceSeqRef.current++;
      setTimeout(() => setISaved(null), 5000);
      loadLedger();
    }
    setISaving(false);
  }, [iIssuerName, iClientName, iSubtotal, iVatPct, iCurrency, iJurisdiction,
      iIssuerTaxId, iClientTaxId, iClientCountry, iDueDate, iNotes,
      iVerifactu, invoiceList, deviceKey, loadLedger]);

  // ── Transmit to Hacienda (simulate) ─────────────────────────────────────────
  const transmitHacienda = useCallback(async (inv: Invoice) => {
    const ref = `HACIENDA-${Date.now()}-${inv.id.slice(0,8).toUpperCase()}`;
    await supabase.from('invoices').update({
      hacienda_transmitted: true,
      hacienda_ref: ref,
      invoice_status: 'sent',
    }).eq('id', inv.id);
    loadLedger();
  }, [loadLedger]);

  const jcfg = JURISDICTION_CFG[pJurisdiction];

  // ─── Render ──────────────────────────────────────────────────────────────────
  return (
    <div className="prl-root">

      {/* ── Header ── */}
      <div className="prl-header">
        <div className="prl-header__title">
          <Globe size={16}/>
          Global Payroll &amp; Invoicing
        </div>
        <div className="prl-header__sub">
          Multi-Jurisdiction · AIPPIETAX S.A. · v66
        </div>
      </div>

      {/* ── Jurisdiction strip ── */}
      <div className="prl-jurisdiction-strip">
        {(Object.entries(JURISDICTION_CFG) as [Jurisdiction, typeof JURISDICTION_CFG['ES']][]).map(([k, cfg]) => (
          <button
            key={k}
            className={`prl-jbtn${(tab === 'payroll' ? pJurisdiction : iJurisdiction) === k ? ' prl-jbtn--active' : ''}`}
            style={(tab === 'payroll' ? pJurisdiction : iJurisdiction) === k
              ? { borderColor: cfg.color, color: cfg.color, background: cfg.border }
              : undefined}
            onClick={() => {
              if (tab === 'payroll') { setPJurisdiction(k); setPCurrency(cfg.currency); }
              else { setIJurisdiction(k); setICurrency(cfg.currency); }
            }}
          >
            <span className="prl-jbtn__flag">{cfg.flag}</span>
            <span className="prl-jbtn__label">{cfg.label}</span>
            <span className="prl-jbtn__compliance">{cfg.complianceLabel}</span>
          </button>
        ))}
      </div>

      {/* ── Tab bar ── */}
      <div className="prl-tabs">
        <button
          className={`prl-tab${tab === 'payroll' ? ' prl-tab--active' : ''}`}
          onClick={() => setTab('payroll')}
        >
          <Users size={11}/> Payroll
        </button>
        <button
          className={`prl-tab${tab === 'invoices' ? ' prl-tab--active' : ''}`}
          onClick={() => setTab('invoices')}
        >
          <FileText size={11}/> Invoices
        </button>
      </div>

      {/* ════ PAYROLL TAB ════ */}
      {tab === 'payroll' && (
        <div className="prl-section">

          {/* Jurisdiction info banner */}
          <div className="prl-info-banner" style={{ borderColor: jcfg.border, background: jcfg.border }}>
            <Landmark size={12} style={{ color: jcfg.color, flexShrink: 0 }}/>
            <span style={{ color: jcfg.color }}>{jcfg.label}</span>
            <span className="prl-info-banner__desc">{jcfg.description}</span>
          </div>

          {/* Form */}
          <div className="prl-form">
            <div className="prl-form__row">
              <div className="prl-form__field">
                <label>Employee Name</label>
                <input placeholder="Full name" value={pEmployeeName} onChange={e => setPEmployeeName(e.target.value)}/>
              </div>
              <div className="prl-form__field">
                <label>Employee ID / BSN / SSN</label>
                <input placeholder="ID reference" value={pEmployeeId} onChange={e => setPEmployeeId(e.target.value)}/>
              </div>
            </div>
            <div className="prl-form__row">
              <div className="prl-form__field">
                <label>Company Name</label>
                <input placeholder="Legal entity" value={pCompanyName} onChange={e => setPCompanyName(e.target.value)}/>
              </div>
              <div className="prl-form__field">
                <label>
                  {pJurisdiction === 'ES' ? 'NIF/CIF' : pJurisdiction === 'NL' ? 'KvK / RSIN' : pJurisdiction === 'US' ? 'EIN' : 'Tax ID'}
                </label>
                <input placeholder="Company tax ID" value={pCompanyTaxId} onChange={e => setPCompanyTaxId(e.target.value)}/>
              </div>
            </div>
            <div className="prl-form__row">
              <div className="prl-form__field">
                <label>Gross Salary</label>
                <div className="prl-form__input-group">
                  <select value={pCurrency} onChange={e => setPCurrency(e.target.value as Currency)}>
                    {(Object.keys(CURRENCY_SYMBOL) as Currency[]).map(c => (
                      <option key={c} value={c}>{c}</option>
                    ))}
                  </select>
                  <input
                    type="number" min="0" step="100"
                    placeholder="0.00"
                    value={pGross}
                    onChange={e => setPGross(e.target.value)}
                  />
                </div>
              </div>
              <div className="prl-form__field">
                <label>Pay Frequency</label>
                <select value={pFreq} onChange={e => setPFreq(e.target.value as PayFreq)}>
                  <option value="monthly">Monthly</option>
                  <option value="bi-weekly">Bi-Weekly</option>
                  <option value="weekly">Weekly</option>
                </select>
              </div>
            </div>
            <div className="prl-form__row">
              <div className="prl-form__field">
                <label>Period Start</label>
                <input type="date" value={pPeriodStart} onChange={e => setPPeriodStart(e.target.value)}/>
              </div>
              <div className="prl-form__field">
                <label>Period End</label>
                <input type="date" value={pPeriodEnd} onChange={e => setPPeriodEnd(e.target.value)}/>
              </div>
            </div>
            {pJurisdiction === 'US' && (
              <div className="prl-form__row prl-form__row--single">
                <label className="prl-form__checkbox">
                  <input type="checkbox" checked={pContractor} onChange={e => setPContractor(e.target.checked)}/>
                  <span>Independent Contractor (1099 instead of W-2)</span>
                </label>
              </div>
            )}
          </div>

          {/* Live calculation result */}
          {calcResult && parseFloat(pGross) > 0 && (
            <div className="prl-calc-card" style={{ borderColor: jcfg.border }}>
              <div className="prl-calc-card__title">
                <Calculator size={12} style={{ color: jcfg.color }}/>
                <span style={{ color: jcfg.color }}>
                  {JURISDICTION_CFG[pJurisdiction].complianceLabel} Calculation
                </span>
                <span className="prl-calc-card__compliance">{calcResult.compliance_type.toUpperCase()}</span>
              </div>

              <div className="prl-calc-grid">
                <div className="prl-calc-grid__row prl-calc-grid__row--gross">
                  <span>Gross Salary</span>
                  <span>{fmt(parseFloat(pGross || '0'), pCurrency)}</span>
                </div>

                {/* Spain deductions */}
                {pJurisdiction === 'ES' && (
                  <>
                    <div className="prl-calc-grid__row">
                      <span>IRPF Withholding ({pct(calcResult.irpf_pct)})</span>
                      <span className="prl-deduction">− {fmt(calcResult.irpf_withheld, pCurrency)}</span>
                    </div>
                    <div className="prl-calc-grid__row">
                      <span>SS Employee ({pct(calcResult.ss_employee_pct)})</span>
                      <span className="prl-deduction">− {fmt(calcResult.ss_employee_amount, pCurrency)}</span>
                    </div>
                    <div className="prl-calc-grid__row prl-calc-grid__row--employer">
                      <span>SS Employer ({pct(calcResult.ss_employer_pct)})</span>
                      <span className="prl-employer">{fmt(calcResult.ss_employer_amount, pCurrency)}</span>
                    </div>
                  </>
                )}

                {/* Netherlands deductions */}
                {pJurisdiction === 'NL' && (
                  <>
                    <div className="prl-calc-grid__row">
                      <span>Loonheffing ({pct(calcResult.loonheffing_pct)})</span>
                      <span className="prl-deduction">− {fmt(calcResult.loonheffing_amount, pCurrency)}</span>
                    </div>
                    <div className="prl-calc-grid__row">
                      <span>Pension (5.50%)</span>
                      <span className="prl-deduction">− {fmt(calcResult.pension_amount, pCurrency)}</span>
                    </div>
                    <div className="prl-calc-grid__row">
                      <span>AOF Premium (0.56%)</span>
                      <span className="prl-deduction">− {fmt(calcResult.aof_premium_amount, pCurrency)}</span>
                    </div>
                  </>
                )}

                {/* US deductions */}
                {pJurisdiction === 'US' && (
                  <>
                    <div className="prl-calc-grid__row">
                      <span>Federal Income Tax ({pct(calcResult.federal_income_tax_pct)})</span>
                      <span className="prl-deduction">− {fmt(calcResult.federal_income_tax, pCurrency)}</span>
                    </div>
                    <div className="prl-calc-grid__row">
                      <span>State Income Tax ({pct(calcResult.state_income_tax_pct)})</span>
                      <span className="prl-deduction">− {fmt(calcResult.state_income_tax, pCurrency)}</span>
                    </div>
                    <div className="prl-calc-grid__row">
                      <span>FICA Social Security (6.20%)</span>
                      <span className="prl-deduction">− {fmt(calcResult.fica_ss_amount, pCurrency)}</span>
                    </div>
                    <div className="prl-calc-grid__row">
                      <span>FICA Medicare (1.45%)</span>
                      <span className="prl-deduction">− {fmt(calcResult.fica_medicare_amount, pCurrency)}</span>
                    </div>
                  </>
                )}

                <div className="prl-calc-grid__row prl-calc-grid__row--separator">
                  <span>Total Deductions</span>
                  <span className="prl-deduction">− {fmt(calcResult.total_deductions, pCurrency)}</span>
                </div>
                <div className="prl-calc-grid__row prl-calc-grid__row--net">
                  <span>NET SALARY</span>
                  <span style={{ color: jcfg.color }}>{fmt(calcResult.net_salary, pCurrency)}</span>
                </div>

                {pCurrency !== 'EUR' && (
                  <div className="prl-calc-grid__row prl-calc-grid__row--rate">
                    <span>EUR equivalent (rate {EXCHANGE_RATES[pCurrency]})</span>
                    <span>€{(calcResult.net_salary / (EXCHANGE_RATES[pCurrency] ?? 1)).toFixed(2)}</span>
                  </div>
                )}
              </div>

              <button
                className="prl-save-btn"
                style={{ background: jcfg.color }}
                onClick={savePayroll}
                disabled={pSaving || !pEmployeeName || !pPeriodStart || !pPeriodEnd}
              >
                {pSaving
                  ? <><RefreshCw size={12} className="prl-spin"/> Generating paystub…</>
                  : pSaved
                    ? <><CheckCircle2 size={12}/> Paystub saved to ledger</>
                    : <><Download size={12}/> Generate &amp; Save Paystub</>
                }
              </button>
            </div>
          )}

          {/* Payroll ledger */}
          <div className="prl-ledger-section">
            <div className="prl-ledger-header">
              <BarChart3 size={11}/> Payroll Ledger
              <button className="prl-reload-btn" onClick={loadLedger} disabled={loadingLedger}>
                <RefreshCw size={10} className={loadingLedger ? 'prl-spin' : ''}/>
              </button>
            </div>
            {payrollList.length === 0 && !loadingLedger && (
              <div className="prl-ledger-empty">No payroll entries yet. Generate a paystub above.</div>
            )}
            {payrollList.map(row => {
              const cfg = JURISDICTION_CFG[row.jurisdiction as Jurisdiction] ?? JURISDICTION_CFG.ES;
              const open = expandedPay === row.id;
              return (
                <div key={row.id} className="prl-ledger-row" style={{ borderColor: cfg.border }}>
                  <button className="prl-ledger-row__header" onClick={() => setExpandedPay(open ? null : row.id)}>
                    <span className="prl-ledger-row__name">{row.employee_name}</span>
                    <span className="prl-ledger-row__jurisdiction" style={{ color: cfg.color, borderColor: cfg.border }}>
                      {cfg.label}
                    </span>
                    <span className="prl-ledger-row__period">
                      {row.pay_period_start} → {row.pay_period_end}
                    </span>
                    <span className="prl-ledger-row__net" style={{ color: cfg.color }}>
                      {fmt(row.net_salary, row.currency as Currency)}
                    </span>
                    {open ? <ChevronUp size={12}/> : <ChevronDown size={12}/>}
                  </button>
                  {open && (
                    <div className="prl-ledger-row__detail">
                      <div className="prl-detail-grid">
                        <span>Gross</span><span>{fmt(row.gross_salary, row.currency as Currency)}</span>
                        <span>Deductions</span><span className="prl-deduction">− {fmt(row.total_deductions, row.currency as Currency)}</span>
                        <span>Net</span><span style={{ color: cfg.color }}>{fmt(row.net_salary, row.currency as Currency)}</span>
                        <span>Compliance</span><span>{row.compliance_type?.toUpperCase()}</span>
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* ════ INVOICES TAB ════ */}
      {tab === 'invoices' && (
        <div className="prl-section">
          {/* Exchange rate strip */}
          <div className="prl-rate-strip">
            <Zap size={10}/>
            <span>Live rates vs EUR:</span>
            {(Object.entries(EXCHANGE_RATES) as [Currency, number][])
              .filter(([c]) => c !== 'EUR')
              .map(([c, r]) => (
                <span key={c} className="prl-rate-chip">
                  {c} {r.toFixed(3)}
                </span>
              ))}
          </div>

          {/* Invoice form */}
          <div className="prl-form">
            <div className="prl-form__row">
              <div className="prl-form__field">
                <label>Issuer (Your Company)</label>
                <input placeholder="Legal name" value={iIssuerName} onChange={e => setIIssuerName(e.target.value)}/>
              </div>
              <div className="prl-form__field">
                <label>
                  {iJurisdiction === 'ES' ? 'NIF/CIF' : iJurisdiction === 'NL' ? 'KvK' : iJurisdiction === 'US' ? 'EIN' : 'Tax ID'}
                </label>
                <input placeholder="Issuer tax ID" value={iIssuerTaxId} onChange={e => setIIssuerTaxId(e.target.value)}/>
              </div>
            </div>
            <div className="prl-form__row">
              <div className="prl-form__field">
                <label>Client Name</label>
                <input placeholder="Client legal name" value={iClientName} onChange={e => setIClientName(e.target.value)}/>
              </div>
              <div className="prl-form__field">
                <label>Client Tax ID</label>
                <input placeholder="CIF / VAT / EIN" value={iClientTaxId} onChange={e => setIClientTaxId(e.target.value)}/>
              </div>
            </div>
            <div className="prl-form__row">
              <div className="prl-form__field">
                <label>Subtotal</label>
                <div className="prl-form__input-group">
                  <select value={iCurrency} onChange={e => setICurrency(e.target.value as Currency)}>
                    {(Object.keys(CURRENCY_SYMBOL) as Currency[]).map(c => (
                      <option key={c} value={c}>{c} {CURRENCY_SYMBOL[c]}</option>
                    ))}
                  </select>
                  <input
                    type="number" min="0" step="10"
                    placeholder="0.00"
                    value={iSubtotal}
                    onChange={e => setISubtotal(e.target.value)}
                  />
                </div>
              </div>
              <div className="prl-form__field">
                <label>
                  {iJurisdiction === 'ES' ? 'IVA %' : iJurisdiction === 'NL' ? 'BTW %' : iJurisdiction === 'US' ? 'Sales Tax %' : 'VAT %'}
                </label>
                <input
                  type="number" min="0" max="100" step="1"
                  value={iVatPct}
                  onChange={e => setIVatPct(e.target.value)}
                />
              </div>
            </div>
            <div className="prl-form__row">
              <div className="prl-form__field">
                <label>Due Date</label>
                <input type="date" value={iDueDate} onChange={e => setIDueDate(e.target.value)}/>
              </div>
              <div className="prl-form__field">
                <label>Client Country</label>
                <input placeholder="ES / NL / US / …" value={iClientCountry} maxLength={3}
                  onChange={e => setIClientCountry(e.target.value.toUpperCase())}/>
              </div>
            </div>
            <div className="prl-form__row prl-form__row--single">
              <div className="prl-form__field">
                <label>Notes</label>
                <input placeholder="Optional notes / description" value={iNotes} onChange={e => setINotes(e.target.value)}/>
              </div>
            </div>
            {iJurisdiction === 'ES' && (
              <div className="prl-form__row prl-form__row--single">
                <label className="prl-form__checkbox">
                  <input type="checkbox" checked={iVerifactu} onChange={e => setIVerifactu(e.target.checked)}/>
                  <span>Enable Verifactu cryptographic chain &amp; QR for Hacienda</span>
                </label>
              </div>
            )}
          </div>

          {/* Invoice preview */}
          {iSubtotal && parseFloat(iSubtotal) > 0 && (
            <div className="prl-invoice-preview">
              <div className="prl-invoice-preview__header">
                <FileText size={12}/>
                Invoice Preview · {genInvoiceNumber(iJurisdiction, invoiceSeqRef.current)}
                {iVerifactu && iJurisdiction === 'ES' && (
                  <span className="prl-verifactu-badge">
                    <Lock size={8}/> VERIFACTU
                  </span>
                )}
              </div>
              <div className="prl-invoice-preview__body">
                <div className="prl-inv-line">
                  <span>Subtotal</span>
                  <span>{CURRENCY_SYMBOL[iCurrency]}{parseFloat(iSubtotal).toFixed(2)}</span>
                </div>
                <div className="prl-inv-line">
                  <span>VAT / Tax ({iVatPct}%)</span>
                  <span>{CURRENCY_SYMBOL[iCurrency]}{(parseFloat(iSubtotal) * parseFloat(iVatPct) / 100).toFixed(2)}</span>
                </div>
                <div className="prl-inv-line prl-inv-line--total">
                  <span>TOTAL</span>
                  <span>{CURRENCY_SYMBOL[iCurrency]}{(parseFloat(iSubtotal) * (1 + parseFloat(iVatPct) / 100)).toFixed(2)}</span>
                </div>
                {iCurrency !== 'EUR' && (
                  <div className="prl-inv-line prl-inv-line--rate">
                    <span>EUR equivalent (1 {iCurrency} = {(1 / (EXCHANGE_RATES[iCurrency] ?? 1)).toFixed(4)} EUR)</span>
                    <span>€{((parseFloat(iSubtotal) * (1 + parseFloat(iVatPct)/100)) / (EXCHANGE_RATES[iCurrency] ?? 1)).toFixed(2)}</span>
                  </div>
                )}
              </div>
              <button
                className="prl-save-btn prl-save-btn--invoice"
                onClick={saveInvoice}
                disabled={iSaving || !iIssuerName || !iClientName}
              >
                {iSaving
                  ? <><RefreshCw size={12} className="prl-spin"/> Generating invoice…</>
                  : <><Send size={12}/> Issue Invoice</>
                }
              </button>
            </div>
          )}

          {/* Saved invoice confirmation */}
          {iSaved && (
            <div className="prl-saved-inv">
              <CheckCircle2 size={14}/>
              <div>
                <div className="prl-saved-inv__num">{iSaved.invoice_number} issued</div>
                {iSaved.verifactu_enabled && (
                  <div className="prl-saved-inv__chain">
                    <Lock size={9}/> Verifactu hash: {String((iSaved as Invoice & { chain_hash?: string }).chain_hash ?? '').slice(0, 24)}…
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Invoice ledger */}
          <div className="prl-ledger-section">
            <div className="prl-ledger-header">
              <TrendingUp size={11}/> Invoice Ledger
              <button className="prl-reload-btn" onClick={loadLedger} disabled={loadingLedger}>
                <RefreshCw size={10} className={loadingLedger ? 'prl-spin' : ''}/>
              </button>
            </div>
            {invoiceList.length === 0 && !loadingLedger && (
              <div className="prl-ledger-empty">No invoices yet. Issue your first invoice above.</div>
            )}
            {invoiceList.map(inv => {
              const cfg = JURISDICTION_CFG[inv.jurisdiction as Jurisdiction] ?? JURISDICTION_CFG.ES;
              const open = expandedInv === inv.id;
              const statusColor =
                inv.invoice_status === 'paid'   ? '#4ade80' :
                inv.invoice_status === 'overdue'? '#f87171' :
                inv.invoice_status === 'sent'   ? '#fbbf24' : cfg.color;
              return (
                <div key={inv.id} className="prl-ledger-row" style={{ borderColor: cfg.border }}>
                  <button className="prl-ledger-row__header" onClick={() => setExpandedInv(open ? null : inv.id)}>
                    <span className="prl-ledger-row__name">{inv.invoice_number}</span>
                    <span className="prl-ledger-row__jurisdiction" style={{ color: cfg.color, borderColor: cfg.border }}>
                      {cfg.label}
                    </span>
                    <span className="prl-ledger-row__period">{inv.client_name}</span>
                    <span className="prl-ledger-row__net" style={{ color: statusColor }}>
                      {fmt(inv.total_amount, inv.currency as Currency)}
                    </span>
                    <span className="prl-status-dot" style={{ background: statusColor }}/>
                    {open ? <ChevronUp size={12}/> : <ChevronDown size={12}/>}
                  </button>
                  {open && (
                    <div className="prl-ledger-row__detail">
                      <div className="prl-detail-grid">
                        <span>Status</span>
                        <span style={{ color: statusColor }}>{inv.invoice_status.toUpperCase()}</span>
                        <span>Currency</span><span>{inv.currency}</span>
                        <span>EUR equiv.</span><span>€{inv.total_eur?.toFixed(2)}</span>
                        <span>Verifactu</span>
                        <span>{inv.verifactu_enabled ? '✓ Active' : '—'}</span>
                        <span>Hacienda</span>
                        <span>{inv.hacienda_transmitted ? '✓ Transmitted' : '—'}</span>
                      </div>
                      {inv.verifactu_enabled && !inv.hacienda_transmitted && (
                        <button
                          className="prl-transmit-btn"
                          onClick={() => transmitHacienda(inv)}
                        >
                          <Send size={10}/> Transmit to Hacienda
                        </button>
                      )}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* ── Footer ── */}
      <div className="prl-footer">
        <ShieldCheck size={9}/>
        AIPPIETAX S.A. · Multi-Jurisdiction Payroll &amp; Invoicing · v66 · E2EE · GDPR
        <Building2 size={9} style={{ marginLeft: 4 }}/>
      </div>
    </div>
  );
}
