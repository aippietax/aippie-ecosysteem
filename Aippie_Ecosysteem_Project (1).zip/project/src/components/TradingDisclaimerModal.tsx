/**
 * TradingDisclaimerModal — v1
 * One-time legal consent gate for Aippie Trading.
 * Stored in DB (trading_consents) + localStorage fallback.
 * Must be accepted before accessing any trading functionality.
 */
import { useState, useCallback } from 'react';
import { AlertTriangle, CheckCircle, Shield, FileText, X } from 'lucide-react';
import type { User } from '@supabase/supabase-js';
import { supabase } from '../lib/supabase';

const CONSENT_VERSION = 'v1';
const LS_KEY = 'aippie_trading_consent_v1';

const CHECKS = [
  {
    id: 'tool',
    text: 'Aippie Trading is an automated software tool ("algo bot"). It is NOT investment advice, portfolio management, or a regulated financial service.',
  },
  {
    id: 'risk',
    text: 'Trading financial instruments involves a high level of risk. I may lose my entire investment. Past performance does not guarantee future results.',
  },
  {
    id: 'own_account',
    text: 'I trade exclusively with my own funds on my own broker account. Aippie never has access to withdrawals or fund transfers.',
  },
  {
    id: 'responsibility',
    text: 'I accept full personal responsibility for all trading actions executed by the software. AIPPIETAX S.A. is not liable for any losses incurred.',
  },
  {
    id: 'age',
    text: 'I am 18 years of age or older and legally authorised to trade in my jurisdiction.',
  },
];

interface Props {
  user: User | null;
  deviceKey: string;
  onAccepted: () => void;
}

export function TradingDisclaimerModal({ user, deviceKey, onAccepted }: Props) {
  const [checked,  setChecked]  = useState<Record<string, boolean>>({});
  const [confirm,  setConfirm]  = useState('');
  const [saving,   setSaving]   = useState(false);
  const [error,    setError]    = useState('');

  const allChecked = CHECKS.every(c => checked[c.id]);
  const canAccept  = allChecked && confirm.trim().toUpperCase() === 'I UNDERSTAND';

  const toggle = useCallback((id: string) => {
    setChecked(p => ({ ...p, [id]: !p[id] }));
  }, []);

  const accept = useCallback(async () => {
    if (!canAccept) return;
    setSaving(true);
    setError('');

    // Always save to localStorage first — this is the primary gate.
    // DB storage is best-effort: a policy error must never block the user.
    localStorage.setItem(LS_KEY, JSON.stringify({ accepted: true, ts: Date.now(), uid: user?.id ?? deviceKey }));

    try {
      if (user) {
        await supabase.from('trading_consents').upsert({
          user_id: user.id,
          device_key: deviceKey,
          version: CONSENT_VERSION,
        }, { onConflict: 'user_id,version' });
      } else {
        await supabase.from('trading_consents').insert({
          user_id: null,
          device_key: deviceKey,
          version: CONSENT_VERSION,
        });
      }
    } catch {
      // DB error is non-blocking — localStorage consent is already saved above.
    }

    onAccepted();
  }, [canAccept, user, deviceKey, onAccepted]);

  return (
    <div className="tdm-overlay">
      <div className="tdm-modal">
        {/* Header */}
        <div className="tdm-header">
          <div className="tdm-header__icon">
            <AlertTriangle size={20} />
          </div>
          <div>
            <h2 className="tdm-title">Risk Disclosure &amp; Terms of Use</h2>
            <p className="tdm-subtitle">Read and accept before accessing Aippie Trading</p>
          </div>
        </div>

        {/* Legal classification banner */}
        <div className="tdm-banner">
          <Shield size={13} />
          <span>
            <strong>Legal classification:</strong> Aippie Trading is an algorithmic trading software tool. It falls under the exemption of Article 2(1)(d) MiFID II for "execution-only" automation on user-owned accounts. It is not a licensed investment service.
          </span>
        </div>

        {/* Checkboxes */}
        <div className="tdm-checks">
          {CHECKS.map(c => (
            <label key={c.id} className={`tdm-check${checked[c.id] ? ' tdm-check--on' : ''}`}>
              <span className={`tdm-box${checked[c.id] ? ' tdm-box--on' : ''}`} onClick={() => toggle(c.id)}>
                {checked[c.id] && <CheckCircle size={12} />}
              </span>
              <span className="tdm-check__text">{c.text}</span>
            </label>
          ))}
        </div>

        {/* Confirmation input */}
        <div className="tdm-confirm-wrap">
          <label className="tdm-confirm-label">
            Type <strong>I UNDERSTAND</strong> to confirm that you have read and accepted all points above:
          </label>
          <input
            className="tdm-confirm-input"
            placeholder="I UNDERSTAND"
            value={confirm}
            onChange={e => setConfirm(e.target.value)}
            disabled={!allChecked}
            autoComplete="off"
            spellCheck={false}
          />
        </div>

        {error && (
          <p className="tdm-error"><X size={11}/> {error}</p>
        )}

        {/* Footer */}
        <div className="tdm-footer">
          <div className="tdm-footer__note">
            <FileText size={10}/>
            <span>Your acceptance is stored with a timestamp as evidence of informed consent (GDPR Art. 7).</span>
          </div>
          <button
            className={`tdm-btn${canAccept ? ' tdm-btn--active' : ''}`}
            disabled={!canAccept || saving}
            onClick={accept}
          >
            {saving
              ? <><span className="tdm-spinner"/>Saving…</>
              : <><Shield size={13}/>Accept &amp; Continue</>
            }
          </button>
        </div>
      </div>
    </div>
  );
}

/** Call this to check if the user has already consented (localStorage fast-path). */
export function hasLocalConsent(): boolean {
  try {
    const raw = localStorage.getItem(LS_KEY);
    if (!raw) return false;
    const data = JSON.parse(raw) as { accepted?: boolean };
    return data.accepted === true;
  } catch {
    return false;
  }
}
