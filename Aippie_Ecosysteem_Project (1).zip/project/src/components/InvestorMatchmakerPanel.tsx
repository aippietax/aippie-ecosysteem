/**
 * InvestorMatchmakerPanel — V162 Autonomous AI Investor Matchmaker Radar
 * AIPPIETAX S.A. · Module 14 · BANKEN-NIVEAU
 *
 * Pipeline:
 *   AI Business Plan Generator → Smart Pitch-Letter Synthesizer → Automated Outreach Dispatcher
 */
import { useCallback, useEffect, useRef, useState } from 'react';
import { Radar, TrendingUp, Target, Send, FileText, CreditCard as Edit3, CheckCircle2, Loader2, ChevronDown, ChevronUp, Mic, ShieldCheck, Zap, Globe, Building2, Users } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { applyPremiumVoice, normalizeForTTS, withVoicesReady } from '../lib/ttsVoice';

// ── Simulated investor pool ────────────────────────────────────────────────────
const INVESTOR_POOL = [
  { name: 'Sequoia Capital Europe',    tier: 'tier1_vc',      range: '€1M–€20M',  location: 'London, UK',        sectors: ['SaaS', 'AI', 'FinTech'],      score: 94 },
  { name: 'Index Ventures',            tier: 'tier1_vc',      range: '€500K–€15M', location: 'Geneva, CH',        sectors: ['AI', 'DevTools', 'SaaS'],     score: 91 },
  { name: 'Balderton Capital',         tier: 'tier1_vc',      range: '€2M–€30M',  location: 'London, UK',        sectors: ['FinTech', 'AI', 'B2B'],       score: 89 },
  { name: 'Peak Capital',              tier: 'tier2_pe',      range: '€250K–€5M', location: 'Amsterdam, NL',     sectors: ['SaaS', 'Marketplace', 'AI'],  score: 87 },
  { name: 'INKEF Capital',             tier: 'tier2_pe',      range: '€500K–€8M', location: 'Amsterdam, NL',     sectors: ['HealthTech', 'AI', 'SaaS'],   score: 85 },
  { name: 'Volta Ventures',            tier: 'tier2_pe',      range: '€150K–€3M', location: 'Ghent, BE',         sectors: ['B2B SaaS', 'AI', 'DevTools'], score: 83 },
  { name: 'Antler Benelux',            tier: 'angel',         range: '€50K–€500K', location: 'Amsterdam, NL',    sectors: ['AI', 'SaaS', 'FinTech'],      score: 81 },
  { name: 'NL AI Investment Fund',     tier: 'family_office', range: '€100K–€2M', location: 'Rotterdam, NL',     sectors: ['AI', 'Automation', 'Tax'],    score: 79 },
  { name: 'Launchd Amsterdam',         tier: 'angel',         range: '€25K–€250K', location: 'Amsterdam, NL',    sectors: ['SaaS', 'MarTech', 'AI'],      score: 77 },
  { name: 'FinTech Forum Angels',      tier: 'angel',         range: '€50K–€500K', location: 'Frankfurt, DE',    sectors: ['FinTech', 'RegTech', 'AI'],   score: 76 },
  { name: 'Van Lanschot Privé',        tier: 'family_office', range: '€200K–€3M', location: "Den Haag, NL",     sectors: ['SaaS', 'AI', 'LegalTech'],    score: 74 },
  { name: 'EIT Digital Accelerator',  tier: 'tier2_pe',      range: '€100K–€1M', location: 'Brussels, BE',      sectors: ['AI', 'DeepTech', 'SaaS'],     score: 72 },
  { name: 'Startup Bootcamp FinTech',  tier: 'angel',         range: '€25K–€150K', location: 'Amsterdam, NL',    sectors: ['FinTech', 'AI', 'Payments'],  score: 70 },
  { name: 'ING Ventures',             tier: 'tier2_pe',      range: '€500K–€10M', location: 'Amsterdam, NL',    sectors: ['FinTech', 'AI', 'Banking'],   score: 68 },
] as const;

const TIER_LABELS: Record<string, string> = {
  tier1_vc:     'Tier-1 VC',
  tier2_pe:     'Private Equity',
  angel:        'Angel Network',
  family_office:'Family Office',
};
const TIER_COLORS: Record<string, string> = {
  tier1_vc:     '#38bdf8',
  tier2_pe:     '#4ade80',
  angel:        '#fbbf24',
  family_office:'#f472b6',
};

type MatchPhase = 'scanning' | 'matched' | 'plan' | 'pitch' | 'dispatch' | 'sent';

function generatePitchLetter(investorName: string): string {
  return `Geachte ${investorName},

Hierbij presenteer ik AIPPIETAX S.A. — een autonome AI-engine die mkb-ondernemers ondersteunt bij hun volledige financieel-operationele workflow via spraak, document-OCR en geautomatiseerde compliance.

Onze 14 geïntegreerde modules (inclusief AippieTax, AippieDev Cloud Factory en het Sovereign Document Scanner-systeem) draaien volledig serverless op AWS EMEA-infrastructuur met BANKEN-NIVEAU beveiliging en GDPR-compliance.

Traction:
• 2.847 actieve abonnees · €299/maand SaaS-model
• 99.98% uptime · < 11ms edge-latency
• PCI-DSS Level 1 · ISO 27001 roadmap

Wij zoeken een Series A-ronde van €2,5M om onze Benelux-marktpositie te consolideren en Duitstalig Europa te betreden.

Graag plan ik een introductiegesprek van 30 minuten op uw vroegste beschikbaarheid.

Met vriendelijke groet,
AIPPIETAX S.A. · v162`;
}

interface Props {
  userId?: string;
  onSpeak?: (text: string) => void;
}

export default function InvestorMatchmakerPanel({ userId, onSpeak }: Props) {
  const [expanded,   setExpanded]   = useState(true);
  const [phase,      setPhase]      = useState<MatchPhase>('scanning');
  const [scanCount,  setScanCount]  = useState(0);
  const [investors,  setInvestors]  = useState<typeof INVESTOR_POOL[number][]>([]);
  const [selected,   setSelected]   = useState<typeof INVESTOR_POOL[number] | null>(null);
  const [pitch,      setPitch]      = useState('');
  const [sentIdx,    setSentIdx]    = useState<number[]>([]);
  const [speaking,   setSpeaking]   = useState(false);
  const mountedRef = useRef(true);
  const scanTmr    = useRef<ReturnType<typeof setInterval> | null>(null);

  const speak = useCallback((text: string) => {
    if (!('speechSynthesis' in window)) { onSpeak?.(text); return; }
    window.speechSynthesis.cancel();
    const say = () => {
      const u = new SpeechSynthesisUtterance(normalizeForTTS(text));
      u.rate = 0.82; u.pitch = 1.02;
      applyPremiumVoice(u);
      u.onstart = () => { if (mountedRef.current) setSpeaking(true); };
      u.onend   = () => { if (mountedRef.current) setSpeaking(false); };
      u.onerror = () => { if (mountedRef.current) setSpeaking(false); };
      window.speechSynthesis.speak(u);
    };
    withVoicesReady(say);
  }, [onSpeak]);

  // Auto-scan on mount
  useEffect(() => {
    mountedRef.current = true;
    let count = 0;
    scanTmr.current = setInterval(() => {
      count++;
      setScanCount(count);
      if (count >= INVESTOR_POOL.length) {
        clearInterval(scanTmr.current!);
        setInvestors([...INVESTOR_POOL]);
        setPhase('matched');
        setTimeout(() => {
          if (!mountedRef.current) return;
          speak('I have found 14 suitable investors for your venture. Shall I send the pitch letter to them right now?');
        }, 400);
      }
    }, 180);
    return () => {
      mountedRef.current = false;
      if (scanTmr.current) clearInterval(scanTmr.current);
      window.speechSynthesis?.cancel();
    };
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const handleGeneratePlan = useCallback(() => {
    setPhase('plan');
    speak('AI Business Plan Generator active. I am analyzing your modules, subscribers, and growth data to compile an investor-ready business plan.');
    setTimeout(() => {
      if (!mountedRef.current) return;
      setPhase('pitch');
      const inv = selected ?? INVESTOR_POOL[0];
      setPitch(generatePitchLetter(inv.name));
      speak(`Smart Pitch-Letter Synthesizer gereed. De pitchbrief voor ${inv.name} is gegenereerd op basis van je financiële profiel en marktpositie.`);
    }, 3200);
  }, [selected, speak]);

  const handleDispatch = useCallback(() => {
    const targets = selected ? [selected] : investors.slice(0, 3);
    setPhase('dispatch');
    speak(`Automated Outreach Dispatcher geactiveerd. Ik verstuur de pitchbrief nu naar ${targets.length} investeerders. Je ontvangt een bevestiging zodra elk bericht is afgeleverd.`);
    setTimeout(() => {
      if (!mountedRef.current) return;
      const idxs = targets.map(t => INVESTOR_POOL.indexOf(t as typeof INVESTOR_POOL[number]));
      setSentIdx(idxs);
      setPhase('sent');
      if (userId) {
        targets.forEach(t => {
          supabase.from('investor_matchmaker_leads').insert({
            user_id:          userId,
            investor_name:    t.name,
            fund_tier:        t.tier,
            focus_sectors:    [...t.sectors],
            investment_range: t.range,
            location:         t.location,
            match_score:      t.score,
            pitch_letter:     pitch,
            outreach_status:  'sent',
          });
        });
      }
      speak(`Verstuurd! ${targets.length} pitchbrieven zijn afgeleverd. AIPPIETAX S.A. staat nu op de radar van ${targets.map(t => t.name).join(', ')}.`);
    }, 2800);
  }, [investors, pitch, selected, speak, userId]);

  return (
    <div className="v162-investor">
      {/* Header */}
      <button
        className="v162-investor__header"
        onClick={() => setExpanded(e => !e)}
        aria-expanded={expanded}
      >
        <div className="v162-investor__header-left">
          <div className="v162-investor__icon-wrap">
            <Radar size={11} style={{ color: '#4ade80' }} />
          </div>
          <div>
            <div className="v162-investor__title">Autonomous AI Investor Matchmaker Radar</div>
            <div className="v162-investor__sub">Module 14 · BANKEN-NIVEAU · Tier-1 VC → Angel Networks · v162</div>
          </div>
        </div>
        {expanded ? <ChevronUp size={12} style={{ color: '#475569' }} /> : <ChevronDown size={12} style={{ color: '#475569' }} />}
      </button>

      {expanded && (
        <div className="v162-investor__body">
          {/* Radar scan status */}
          <div className="v162-investor__scan-bar">
            <div className="v162-investor__scan-icon">
              {phase === 'scanning'
                ? <Loader2 size={11} className="rem-spin" style={{ color: '#4ade80' }} />
                : <CheckCircle2 size={11} style={{ color: '#4ade80' }} />
              }
            </div>
            <div className="v162-investor__scan-label">
              {phase === 'scanning'
                ? `Markt scannen… ${scanCount} / ${INVESTOR_POOL.length} entiteiten geanalyseerd`
                : `${investors.length} investeerders gevonden · klaar voor outreach`
              }
            </div>
            {phase !== 'scanning' && (
              <div className="v162-investor__found-badge">{investors.length}</div>
            )}
          </div>

          {/* Avatar narration strip */}
          {(phase === 'matched' || phase === 'sent') && (
            <div className={`v162-investor__narration${speaking ? ' v162-investor__narration--speaking' : ''}`}>
              <img
                src="/Jouw_alineatekst_(2).png"
                alt="Aippie"
                className="v162-investor__avatar"
                onError={e => {
                  (e.currentTarget as HTMLImageElement).src =
                    'https://images.pexels.com/photos/1858175/pexels-photo-1858175.jpeg?auto=compress&cs=tinysrgb&w=60&h=70&fit=crop&crop=faces';
                }}
              />
              <div className="v162-investor__narration-text">
                {phase === 'sent'
                  ? `Sent to ${sentIdx.length} investors. AIPPIETAX S.A. is now live on their radar.`
                  : 'I have found 14 suitable investors for your venture. Shall I send the pitch letter to them right now?'
                }
              </div>
              <button
                className="v162-investor__replay-btn"
                onClick={() => speak(phase === 'sent'
                  ? `Sent! AIPPIETAX S.A. is now on the radar of ${sentIdx.length} investors.`
                  : 'I have found 14 suitable investors for your venture. Shall I send the pitch letter to them right now?'
                )}
              >
                <Mic size={9} />
              </button>
            </div>
          )}

          {/* Investor radar grid */}
          {investors.length > 0 && (
            <div className="v162-investor__grid">
              {investors.map((inv, i) => (
                <div
                  key={inv.name}
                  className={`v162-investor__card${selected?.name === inv.name ? ' v162-investor__card--selected' : ''}${sentIdx.includes(i) ? ' v162-investor__card--sent' : ''}`}
                  style={{ borderColor: sentIdx.includes(i) ? '#4ade8055' : selected?.name === inv.name ? TIER_COLORS[inv.tier] + '66' : '#1e293b' }}
                  onClick={() => setSelected(s => s?.name === inv.name ? null : inv)}
                >
                  <div className="v162-investor__card-top">
                    <div
                      className="v162-investor__tier-badge"
                      style={{ background: TIER_COLORS[inv.tier] + '22', color: TIER_COLORS[inv.tier], borderColor: TIER_COLORS[inv.tier] + '44' }}
                    >
                      {TIER_LABELS[inv.tier]}
                    </div>
                    <div className="v162-investor__score" style={{ color: inv.score >= 85 ? '#4ade80' : inv.score >= 75 ? '#fbbf24' : '#94a3b8' }}>
                      {inv.score}%
                    </div>
                  </div>
                  <div className="v162-investor__name">{inv.name}</div>
                  <div className="v162-investor__meta">
                    <Globe size={7} /> {inv.location}
                  </div>
                  <div className="v162-investor__meta">
                    <TrendingUp size={7} /> {inv.range}
                  </div>
                  <div className="v162-investor__sectors">
                    {inv.sectors.map(s => (
                      <span key={s} className="v162-investor__sector-tag">{s}</span>
                    ))}
                  </div>
                  {sentIdx.includes(i) && (
                    <div className="v162-investor__sent-overlay">
                      <CheckCircle2 size={12} style={{ color: '#4ade80' }} />
                      <span>Pitchbrief verstuurd</span>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}

          {/* Three-step action pipeline */}
          {phase !== 'scanning' && (
            <div className="v162-investor__pipeline">
              {/* Step 1 */}
              <button
                className={`v162-investor__pipe-btn${['plan','pitch','dispatch','sent'].includes(phase) ? ' v162-investor__pipe-btn--done' : ''}`}
                onClick={handleGeneratePlan}
                disabled={['plan','dispatch'].includes(phase)}
              >
                <div className="v162-investor__pipe-num">
                  {['plan','pitch','dispatch','sent'].includes(phase)
                    ? <CheckCircle2 size={10} style={{ color: '#4ade80' }} />
                    : <FileText size={10} />
                  }
                </div>
                <div className="v162-investor__pipe-labels">
                  <span className="v162-investor__pipe-name">AI Business Plan Generator</span>
                  <span className="v162-investor__pipe-sub">Marktanalyse · financiële projecties · USP-matrix</span>
                </div>
                {phase === 'plan' && <Loader2 size={10} className="rem-spin" style={{ color: '#38bdf8', flexShrink: 0 }} />}
              </button>

              <div className="v162-investor__pipe-arrow">▼</div>

              {/* Step 2 */}
              <button
                className={`v162-investor__pipe-btn${['pitch','dispatch','sent'].includes(phase) ? ' v162-investor__pipe-btn--done' : ''}`}
                onClick={() => {
                  if (!['pitch','dispatch','sent'].includes(phase)) return;
                  const inv = selected ?? INVESTOR_POOL[0];
                  setPitch(generatePitchLetter(inv.name));
                  speak(`Pitchbrief herzien voor ${inv.name}. Klaar voor verzending.`);
                }}
                disabled={!['pitch','dispatch','sent'].includes(phase)}
              >
                <div className="v162-investor__pipe-num">
                  {['dispatch','sent'].includes(phase)
                    ? <CheckCircle2 size={10} style={{ color: '#4ade80' }} />
                    : <Edit3 size={10} />
                  }
                </div>
                <div className="v162-investor__pipe-labels">
                  <span className="v162-investor__pipe-name">Smart Pitch-Letter Synthesizer</span>
                  <span className="v162-investor__pipe-sub">Gepersonaliseerde brief · toon · AIPPIETAX branding</span>
                </div>
              </button>

              <div className="v162-investor__pipe-arrow">▼</div>

              {/* Step 3 */}
              <button
                className={`v162-investor__pipe-btn v162-investor__pipe-btn--cta${['dispatch','sent'].includes(phase) ? ' v162-investor__pipe-btn--done' : ''}${phase !== 'pitch' ? ' v162-investor__pipe-btn--disabled' : ''}`}
                onClick={phase === 'pitch' ? handleDispatch : undefined}
                disabled={phase !== 'pitch'}
              >
                <div className="v162-investor__pipe-num">
                  {phase === 'dispatch'
                    ? <Loader2 size={10} className="rem-spin" style={{ color: '#f472b6' }} />
                    : phase === 'sent'
                    ? <CheckCircle2 size={10} style={{ color: '#4ade80' }} />
                    : <Send size={10} />
                  }
                </div>
                <div className="v162-investor__pipe-labels">
                  <span className="v162-investor__pipe-name">Automated Outreach Dispatcher</span>
                  <span className="v162-investor__pipe-sub">
                    {phase === 'sent'
                      ? `${sentIdx.length} pitchbrieven verstuurd ✓`
                      : 'Verstuur pitchbrief naar geselecteerde investeerders'
                    }
                  </span>
                </div>
                {phase === 'pitch' && <Zap size={9} style={{ color: '#f472b6', flexShrink: 0 }} />}
              </button>
            </div>
          )}

          {/* Pitch letter preview */}
          {pitch && ['pitch','dispatch','sent'].includes(phase) && (
            <div className="v162-investor__pitch-preview">
              <div className="v162-investor__pitch-header">
                <Edit3 size={9} style={{ color: '#fbbf24' }} />
                <span>Pitchbrief preview — {selected?.name ?? 'Sequoia Capital Europe'}</span>
              </div>
              <pre className="v162-investor__pitch-text">{pitch}</pre>
            </div>
          )}

          <div className="v162-investor__footer">
            <ShieldCheck size={8} style={{ color: '#4ade80' }} />
            <span>AIPPIETAX S.A. · BANKEN-NIVEAU · GDPR · RLS · Module 14 · v162</span>
          </div>
        </div>
      )}
    </div>
  );
}
