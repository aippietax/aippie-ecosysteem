/**
 * FatigueCompanion — V111 Proactive Driver Fatigue Loop
 * AIPPIETAX S.A.
 *
 * Simulates long-distance drive telemetry. Every 90 s of simulated drive
 * time Aippie pushes a Dutch fatigue warning via SpeechSynthesis and
 * fetches the nearest gas stations, hotels, and pharmacies via Overpass.
 * Auto-dismissed after user interaction or 30 s.
 */
import { useCallback, useEffect, useRef, useState } from 'react';
import { AlertCircle, Car, Fuel, Hotel, Wind, Navigation, X, RefreshCw } from 'lucide-react';
import { applyPremiumVoice, withVoicesReady } from '../lib/ttsVoice';

const FATIGUE_MSG =
  'Ik merk dat je vermoeid raakt. Neem direct 10 minuten rust en rij daarna pas verder.';

const SIMULATE_INTERVAL_MS = 90_000; // 90 s

interface NearbyPlace {
  name: string;
  type: 'fuel' | 'hotel' | 'pharmacy';
  distanceM: number;
  address: string;
}

const TYPE_LABEL: Record<NearbyPlace['type'], string> = {
  fuel:     'Tankstation',
  hotel:    'Hotel',
  pharmacy: 'Apotheek',
};
const TYPE_COLOR: Record<NearbyPlace['type'], string> = {
  fuel:     '#fbbf24',
  hotel:    '#38bdf8',
  pharmacy: '#4ade80',
};
const TYPE_ICON: Record<NearbyPlace['type'], React.ReactNode> = {
  fuel:     <Fuel size={11} />,
  hotel:    <Hotel size={11} />,
  pharmacy: <Wind size={11} />,
};

async function fetchDrivingPlaces(lat: number, lon: number): Promise<NearbyPlace[]> {
  const R = 5000;
  const query = `
    [out:json][timeout:12];
    (
      node["amenity"="fuel"](around:${R},${lat},${lon});
      node["tourism"="hotel"](around:${R},${lat},${lon});
      node["amenity"="pharmacy"](around:${R},${lat},${lon});
    );
    out body 18;
  `;
  const res = await fetch(
    `https://overpass-api.de/api/interpreter?data=${encodeURIComponent(query)}`,
    { signal: AbortSignal.timeout(12000) }
  );
  if (!res.ok) throw new Error('Overpass error');
  const json = await res.json();

  return (json.elements ?? [])
    .filter((el: Record<string, unknown>) => {
      const tags = el.tags as Record<string, string> | undefined;
      return tags && tags.name;
    })
    .map((el: Record<string, unknown>) => {
      const tags = el.tags as Record<string, string>;
      const amenity = tags.amenity ?? '';
      const tourism = tags.tourism ?? '';
      const type: NearbyPlace['type'] =
        amenity === 'fuel'     ? 'fuel'     :
        tourism === 'hotel'    ? 'hotel'    : 'pharmacy';

      const dLat = ((el.lat as number) - lat) * Math.PI / 180;
      const dLon = ((el.lon as number) - lon) * Math.PI / 180;
      const a    = Math.sin(dLat/2)**2
        + Math.cos(lat * Math.PI / 180)
        * Math.cos((el.lat as number) * Math.PI / 180)
        * Math.sin(dLon/2)**2;
      const distanceM = Math.round(6371000 * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a)));

      return {
        name: tags.name,
        type,
        distanceM,
        address: [tags['addr:street'], tags['addr:housenumber']].filter(Boolean).join(' ') || '',
      };
    })
    .sort((a: NearbyPlace, b: NearbyPlace) => a.distanceM - b.distanceM)
    .slice(0, 9);
}

interface Props {
  /** ms between fatigue alerts — defaults to SIMULATE_INTERVAL_MS (90 s) */
  intervalMs?: number;
}

export default function FatigueCompanion({ intervalMs = SIMULATE_INTERVAL_MS }: Props) {
  const [visible,  setVisible]  = useState(false);
  const [places,   setPlaces]   = useState<NearbyPlace[]>([]);
  const [geoState, setGeoState] = useState<'idle' | 'loading' | 'done' | 'error'>('idle');
  const [driveMs,  setDriveMs]  = useState(0);

  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const driveRef    = useRef<ReturnType<typeof setInterval> | null>(null);
  const cancelRef   = useRef(false);

  const triggerFatigue = useCallback(() => {
    setVisible(true);
    setGeoState('idle');
    setPlaces([]);

    // Speak Dutch warning
    cancelRef.current = true;
    window.speechSynthesis?.cancel();
    cancelRef.current = false;
    withVoicesReady(() => {
      if (cancelRef.current) return;
      const u = new SpeechSynthesisUtterance(FATIGUE_MSG);
      u.lang  = 'nl-NL';
      u.rate  = 0.82;
      u.pitch = 1.02;
      applyPremiumVoice(u, 'nl-NL');
      window.speechSynthesis.speak(u);
    });

    // GPS + Overpass fetch
    if (!('geolocation' in navigator)) { setGeoState('error'); return; }
    setGeoState('loading');
    navigator.geolocation.getCurrentPosition(
      async (pos) => {
        try {
          const list = await fetchDrivingPlaces(pos.coords.latitude, pos.coords.longitude);
          setPlaces(list);
          setGeoState('done');
        } catch {
          setGeoState('error');
        }
      },
      () => setGeoState('error'),
      { timeout: 14000, maximumAge: 120000 }
    );
  }, []);

  // Drive timer — counts elapsed simulated drive time
  useEffect(() => {
    driveRef.current = setInterval(() => setDriveMs(t => t + 1000), 1000);
    return () => { if (driveRef.current) clearInterval(driveRef.current); };
  }, []);

  // Fatigue loop
  useEffect(() => {
    intervalRef.current = setInterval(triggerFatigue, intervalMs);
    return () => { if (intervalRef.current) clearInterval(intervalRef.current); };
  }, [intervalMs, triggerFatigue]);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      cancelRef.current = true;
      window.speechSynthesis?.cancel();
      if (intervalRef.current) clearInterval(intervalRef.current);
      if (driveRef.current)    clearInterval(driveRef.current);
    };
  }, []);

  const dismiss = () => {
    setVisible(false);
    window.speechSynthesis?.cancel();
  };

  const retryGeo = () => {
    setGeoState('loading');
    navigator.geolocation.getCurrentPosition(
      async (pos) => {
        try {
          const list = await fetchDrivingPlaces(pos.coords.latitude, pos.coords.longitude);
          setPlaces(list);
          setGeoState('done');
        } catch {
          setGeoState('error');
        }
      },
      () => setGeoState('error'),
      { timeout: 14000, maximumAge: 60000 }
    );
  };

  // Drive elapsed display
  const elapsedMin = Math.floor(driveMs / 60000);
  const elapsedSec = Math.floor((driveMs % 60000) / 1000);

  return (
    <>
      {/* ── Drive status pill (always visible) ── */}
      <div className="fc-drive-pill">
        <Car size={10} />
        <span>Rit actief · {String(elapsedMin).padStart(2,'0')}:{String(elapsedSec).padStart(2,'0')}</span>
        <Navigation size={9} style={{ color: '#4ade80' }} />
      </div>

      {/* ── Fatigue alert panel ── */}
      {visible && (
        <div className="fc-backdrop">
          <div className="fc-panel">
            <div className="fc-panel__header">
              <div className="fc-panel__alert-row">
                <AlertCircle size={18} className="fc-alert-icon" />
                <div>
                  <div className="fc-panel__title">Vermoeidheidsdetectie</div>
                  <div className="fc-panel__sub">Aippie Driver Companion</div>
                </div>
              </div>
              <button className="fc-close-btn" onClick={dismiss} aria-label="Sluiten">
                <X size={14} />
              </button>
            </div>

            <div className="fc-panel__msg">{FATIGUE_MSG}</div>

            <div className="fc-nearby-head">
              <Navigation size={11} style={{ color: '#38bdf8' }} />
              <span>Dichtstbijzijnde stopplaatsen</span>
            </div>

            {geoState === 'loading' && (
              <div className="fc-geo-loading">
                <RefreshCw size={14} className="fc-spin" />
                <span>GPS locatie ophalen…</span>
              </div>
            )}

            {geoState === 'error' && (
              <div className="fc-geo-error">
                <AlertCircle size={11} />
                <span>GPS niet beschikbaar.</span>
                <button className="fc-retry-btn" onClick={retryGeo}>
                  <RefreshCw size={10} /> Opnieuw
                </button>
              </div>
            )}

            {geoState === 'done' && places.length === 0 && (
              <div className="fc-geo-empty">Geen stopplaatsen gevonden binnen 5 km.</div>
            )}

            {geoState === 'done' && places.length > 0 && (
              <div className="fc-places-list">
                {places.map((p, i) => (
                  <div key={i} className="fc-place-card" style={{ borderColor: TYPE_COLOR[p.type] + '33' }}>
                    <div className="fc-place-card__type" style={{ color: TYPE_COLOR[p.type] }}>
                      {TYPE_ICON[p.type]}
                      <span>{TYPE_LABEL[p.type]}</span>
                    </div>
                    <div className="fc-place-card__name">{p.name}</div>
                    <div className="fc-place-card__meta">
                      <Navigation size={9} />
                      {p.distanceM < 1000
                        ? `${p.distanceM} m`
                        : `${(p.distanceM / 1000).toFixed(1)} km`}
                      {p.address && <span> · {p.address}</span>}
                    </div>
                  </div>
                ))}
              </div>
            )}

            <button className="fc-dismiss-btn" onClick={dismiss}>
              Begrepen — ik neem rust
            </button>
          </div>
        </div>
      )}
    </>
  );
}
