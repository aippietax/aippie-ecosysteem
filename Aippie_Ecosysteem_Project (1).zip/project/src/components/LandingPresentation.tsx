/**
 * LandingPresentation — V178 Split-Screen Avatar & Demo Cinema
 * AIPPIETAX S.A.
 *
 * V163: Product Demo Cinema added to center column (right of avatar).
 * On every module select (click or hover), three simultaneous pipeline events fire:
 *   1. window.speechSynthesis.cancel() — flush audio queue
 *   2. Avatar narrates product breakdown at locked rate 0.82, typewriter subtitles sync
 *   3. Demo Cinema updates to the contextual animated demonstration asset
 *
 * Architecture: split-screen Control Center (3 columns) + inner cinema split.
 *   Left sidebar · Center [avatar | demo cinema] · Right sidebar
 * rate=0.82, pitch=1.02 locked. Google US English preferred (Tier 1).
 */
import { useCallback, useEffect, useRef, useState } from 'react';
import {
  Building2, Mic, Wifi, Heart, Hand, TrendingUp, Car,
  ShieldCheck, Glasses, CheckCircle2, Lock,
  Radio, Activity,
  ChevronRight, ChevronLeft, Zap, FileText, Stethoscope,
  Home, MessageSquare, GraduationCap, Cpu, Briefcase
} from 'lucide-react';
import { applyPremiumVoice, withVoicesReady, normalizeForTTS } from '../lib/ttsVoice';
import { detectBrowserLang, storeLang, type LangCode } from '../lib/i18n';
import PlatformAdBanner from './PlatformAdBanner';
import PlatformAdSubmitView from './PlatformAdSubmitView';
import GlobalLangSelector from './GlobalLangSelector';
import CheckoutGate, { type CheckoutProduct } from './CheckoutGate';
import AippieScoreWidget from './AippieScoreWidget';

// Central brand image — update this ONE constant to refresh all avatars/card backgrounds instantly
const AIPPIE_CORE_LOGO = '/aippieremix_aippieremix_In_generated_file_3_keep_the_split_human-robot_face_the_aippie_1ada2b19-20fd-43ac-bcd7-e099712720a6_(2).png';

// Paid appTabs — these get CheckoutGate before navigating
const PAID_TABS = new Set(['tax', 'voice', 'trading', 'doctor', 'silentvoice', 'realestate', 'aippiedev', 'academy']);

// ─── Module definitions ───────────────────────────────────────────────────────
interface Module {
  id: string;
  appTab: string;       // AppTab value used for deep-link navigation
  label: string;
  icon: React.ReactNode;
  price: string;
  priceDetail: string;
  accentColor: string;
  speech: string;       // pre-normalised TTS string
  tagline: string;      // short display line shown in sidebar button
  bullets: string[];    // feature bullets in detail card
}

const MODULES: Module[] = [
  // ── Left sidebar (indices 0-4) ────────────────────────────────────────────
  // ── ID 0 — AippieTax ─────────────────────────────────────────────────────
  {
    id: 'tax', appTab: 'tax',
    label: 'AippieTax',
    icon: <FileText size={16} />,
    price: '€100',
    priceDetail: '/month',
    accentColor: '#4ade80',
    tagline: 'AI Accountant · Global tax & payroll',
    speech:
      'eye-pee Tax. Your AI-powered corporate accountant at one hundred Euros per month. ' +
      'We handle worldwide tax minimization across Spain, the Netherlands, the United States, and every major jurisdiction. ' +
      'Our proprietary OCR ledger scrapes and categorizes every invoice automatically. ' +
      'Automated Nominas payroll runs for your full team — IRPF withholding, Social Security, and Dutch Loonheffing included. ' +
      'Verifactu cryptographic invoice chaining keeps every transaction immutable and audit-ready. ' +
      'Direct one-click filing to Hacienda, Belastingdienst, and the I.R.S.',
    bullets: [
      'OCR invoice scraper — automated expense tracking',
      'Cross-border payroll: IRPF · Social Security · Loonheffing',
      'Verifactu cryptographic invoice chaining',
      'S.L. · S.R.L. · LLC · Ltd. · B.V. · GmbH globally',
      'Direct filing: Hacienda · Belastingdienst · IRS',
    ],
  },
  // ── ID 1 — AippieVoice & Document Scanner (V165 3-in-1 master hub) ─────────
  {
    id: 'voice', appTab: 'voice',
    label: 'AippieVoice & Document Scanner',
    icon: <Mic size={16} />,
    price: '€29.99',
    priceDetail: '/month',
    accentColor: '#38bdf8',
    tagline: 'Live Translation · Medical Dictation · OCR Mail Reader',
    speech:
      'eye-pee Voice and Document Scanner. The premium three-in-one master hub at twenty-nine ninety-nine per month. ' +
      'Module one: Live Translation — connect to an accredited interpreter in under ten seconds across forty plus languages, with automated twenty-five Euro cent per minute bank transfers to the translator in real time. ' +
      'Module two: Medical Dictation — speak your symptoms or clinical notes at natural pace and receive a fully formatted medical letter with ICD-10 codes, drug names, and dosages inserted automatically. ' +
      'Module three: OCR Mail Reader — photograph any letter, contract, invoice, or government form and receive an instant full plain-language summary and a certified translation in your language. ' +
      'Every session is end-to-end encrypted over WebRTC. Your first forty minutes are completely free.',
    bullets: [
      'Live Translation — 40+ languages · E2EE WebRTC',
      'Automated €0.25/min bank transfer to interpreters',
      'Medical Dictation — ICD-10 · drug names · auto-formatted',
      'OCR Mail Reader — photo any letter → instant summary',
      '€29.99/month · first 40 minutes free',
    ],
  },
  // ── ID 2 — AippieWiFi ─────────────────────────────────────────────────────
  {
    id: 'wifi', appTab: 'wifi',
    label: 'AippieWiFi',
    icon: <Wifi size={16} />,
    price: '€0.05',
    priceDetail: '/GB',
    accentColor: '#fbbf24',
    tagline: 'Decentralized internet sharing',
    speech:
      'eye-pee WiFi. Secure decentralized internet sharing at zero point zero five Euros per Gigabyte. ' +
      'Our WireGuard-encrypted tunneling creates private peer-to-peer sharing loops between trusted devices. ' +
      'Every Gigabyte sold triggers an automatic sixty-forty database split — sixty percent flows directly to you, the host. ' +
      'No hardware to install. No long-term contracts. Pure passive income from your existing connection, starting immediately.',
    bullets: [
      'WireGuard VPN encrypted tunnels',
      'Automatic 60/40 split — 60% goes directly to you',
      'No hardware · No contracts',
      'Pure passive income from your connection',
    ],
  },
  // ── ID 3 — AI Companion ───────────────────────────────────────────────────
  {
    id: 'companion', appTab: 'companion',
    label: 'AI Companion',
    icon: <Heart size={16} />,
    price: 'FREE',
    priceDetail: '100% Gratis',
    accentColor: '#fb7185',
    tagline: 'Luna · Bella · Scarlett',
    speech:
      'AI Companion. Meet Luna, Bella, and Scarlett — your three emotional AI relationship partners, one hundred percent free. ' +
      'Luna is warm and empathetic, with persistent vector memory that remembers every conversation you have ever had. ' +
      'Bella is playful and creative, powered by deep sentiment analysis to match your emotional tone. ' +
      'Scarlett is bold and confident, with advanced vocal tone analysis for direct, honest engagement. ' +
      'Available twenty-four seven. No subscription. No hidden fees. Completely gratis.',
    bullets: [
      'Luna — Warm · Empathetic · Vector memory',
      'Bella — Playful · Creative · Sentiment AI',
      'Scarlett — Bold · Confident · Tone analysis',
      'Available 24/7 · No subscription · No hidden fees',
    ],
  },
  // ── ID 4 — Autisme & Gebarentaal AI Radar ────────────────────────────────
  {
    id: 'silentvoice', appTab: 'silentvoice',
    label: 'Autisme AI Radar',
    icon: <Hand size={16} />,
    price: '€5',
    priceDetail: '/donation',
    accentColor: '#38bdf8',
    tagline: 'Gebarentaal · 5-Signal CV Radar',
    speech:
      'Autisme and Gebarentaal AI Radar. Real-time five-signal computer vision radar for autism support and sign language interpretation, at five Euros per donation. ' +
      'Signal one: facial micro-expression mapping — minute muscle distortions reveal stress levels and sensory overstimulation in real time. ' +
      'Signal two: hand gesture and international sign language translation into spoken language. ' +
      'Signal three: full spine and posture alignment monitoring with motor tic detection. ' +
      'Signal four: ocular iris vector gaze tracking for focus coaching and eye contact diagnostics. ' +
      'Signal five: Aippie live vocal coach — fusing all four signals into a single spoken evaluation with word-for-word typewriter subtitles.',
    bullets: [
      'Facial micro-expression stress & emotion mapping',
      'Hand gestures → international sign language speech',
      'Spine posture · motor tic detection (12-pt skeleton)',
      'Iris vector gaze stability · focus coaching',
      '€5 Donation · 5-signal fused AI vocal output · GDPR',
    ],
  },
  // ── Right sidebar (indices 5-9) ───────────────────────────────────────────
  // ── ID 5 — Trading Alpha ──────────────────────────────────────────────────
  {
    id: 'trading', appTab: 'trading',
    label: 'Trading Alpha',
    icon: <TrendingUp size={16} />,
    price: '€499',
    priceDetail: '/month',
    accentColor: '#f59e0b',
    tagline: 'Autonomous quant AI algorithms',
    speech:
      'Trading Alpha. Proprietary autonomous quantitative AI market algorithms at four hundred ninety-nine Euros per month. ' +
      'Our deep-learning models run on autopilot, ingesting real-time order book imbalance data across major exchanges simultaneously. ' +
      'The dark pool institutional block detection engine identifies large hidden buy and sell orders before they surface on public feeds. ' +
      'Macroeconomic dataset pipelines feed live central bank signals, inflation prints, and earnings surprises directly into the model. ' +
      'Elite copy trading signals are generated and delivered in under fifty milliseconds.',
    bullets: [
      'Deep-learning quant algorithms on autopilot',
      'Real-time order book imbalance ingestion',
      'Dark pool institutional block detection',
      'Macroeconomic dataset feeds · Elite copy signals',
    ],
  },
  // ── ID 6 — AippieParking ──────────────────────────────────────────────────
  {
    id: 'parking', appTab: 'parking',
    label: 'AippieParking',
    icon: <Car size={16} />,
    price: 'FREE',
    priceDetail: '100% Gratis',
    accentColor: '#34d399',
    tagline: '3D smart city parking maps',
    speech:
      'eye-pee Parking. Live WebGL three-dimensional vector smart city maps, one hundred percent free. ' +
      'When your phone disconnects from your car Bluetooth, the GPS coordinates are logged instantly as your parking spot. ' +
      'A full isometric three-dimensional city map renders your exact location in real time. ' +
      'Tap the Route button to activate live navigation directly to your parked vehicle. ' +
      'No subscription. No ads. Always free.',
    bullets: [
      'Bluetooth disconnect → GPS slot log instantly',
      'WebGL 3D isometric city vector map',
      'Tap Route for live navigation mode',
      'Free · Always',
    ],
  },
  // ── ID 7 — Guardian Shield ────────────────────────────────────────────────
  {
    id: 'guardian', appTab: 'safecheckin',
    label: 'Guardian Shield',
    icon: <ShieldCheck size={16} />,
    price: 'FREE',
    priceDetail: '100% Gratis',
    accentColor: '#60a5fa',
    tagline: 'Autonomous safe check-in timer',
    speech:
      'eye-pee Guardian Shield. Standalone autonomous safe check-in countdown timer for personal emergency tracking, one hundred percent free. ' +
      'Set a five, ten, fifteen, or fully custom minute safety window before entering any unsecured environment. ' +
      'If you do not check in before the timer expires, a sixty-second grace window opens with a vibration alarm and a biometric challenge — PIN, Face I.D., or Touch I.D. ' +
      'If that challenge is not completed, the system fires your G.P.S. coordinates and an automated emergency S.M.S. to all registered emergency contacts instantly.',
    bullets: [
      'Set 5, 10, 15 or custom minute safety window',
      'Vibration alarm + PIN / Face ID / Touch ID challenge',
      '60-second grace window before distress fires',
      'GPS lock + auto-SMS to emergency contacts',
    ],
  },
  // ── ID 8 — Smart Glass & Quantum Time Machine / Chrono-Cinema ───────────
  {
    id: 'wearable', appTab: 'quantumcinema',
    label: 'Smart Glass · Chrono-Cinema',
    icon: <Glasses size={16} />,
    price: 'FREE',
    priceDetail: '100% Gratis',
    accentColor: '#38bdf8',
    tagline: 'AI Chrono-Cinema — past & future',
    speech:
      'Smart Glass Chrono-Cinema. Aippie narrates a personalised fictional film with you as the main character, ' +
      'set in a historical or futuristic era of your choice. ' +
      'From Ancient Egypt to the year three thousand — fully narrated at rate zero point eighty-two with typewriter subtitles. ' +
      'All story content is entirely fictional and for entertainment purposes only. One hundred percent free.',
    bullets: [
      'Choose from 4 historical + 2 futuristic time eras',
      'Personalised story featuring your name',
      'Live narration at rate 0.82 with typewriter subtitles',
      'DISCLAIMER: Fictional AI film · Entertainment only',
    ],
  },
  // ── ID 9 — Aippie Doctor Medical Suite ───────────────────────────────────
  {
    id: 'doctor', appTab: 'doctor',
    label: 'Aippie Doctor',
    icon: <Stethoscope size={16} />,
    price: '€30',
    priceDetail: '/consult',
    accentColor: '#34d399',
    tagline: 'Medical Suite · PPG · Skin · GPS Care',
    speech:
      'eye-pee Doctor. Your AI health consultation module at thirty Euros per session. ' +
      'Place your fingertip over the smartphone camera lens. ' +
      'Our real-time photoplethysmography engine reads your blood flow patterns and calculates your Heart Rate in beats per minute, your Stress Index through heart rate variability, and your blood oxygen saturation as a SpO2 percentage. ' +
      'The skin and lesion analyser uses your camera to detect redness, texture anomalies, and hydration levels in real time. ' +
      'The GPS medical radar finds the nearest clinics, pharmacies, and doctors within three kilometres. ' +
      'Please remember: I am an AI health guide, not a licensed physician. For any official diagnosis, always consult your own doctor.',
    bullets: [
      'PPG fingertip scan — HR · HRV · SpO2 real-time',
      'Camera skin & lesion CV analyser',
      'GPS medical radar — clinics · pharmacies · doctors',
      '€30/consult · Dual-camera consultation room',
      'AI health guide — always consult your GP',
    ],
  },
  // ── ID 10 — Aippie Real Estate Manager ───────────────────────────────────
  {
    id: 'realestate', appTab: 'realestate',
    label: 'Real Estate AI',
    icon: <Home size={16} />,
    price: '€149',
    priceDetail: '/month',
    accentColor: '#f59e0b',
    tagline: 'AI property valuation & rental management',
    speech:
      'eye-pee Real Estate. Your autonomous property portfolio manager at one hundred and forty-nine Euros per month. ' +
      'Real-time market valuations for Spanish and global property portfolios updated daily. ' +
      'Automated rental management: tenant screening, contract generation, and rent collection. ' +
      'Direct integration with Catastro, Registro de la Propiedad, and IBI municipal tax filings. ' +
      'Live yield calculations and ROI projections across your entire portfolio.',
    bullets: [
      'Real-time property valuations — Spain & global',
      'Automated tenant screening & contract generation',
      'Catastro · Registro · IBI tax integration',
      'Live rental yield & ROI portfolio dashboard',
      '€149/month · unlimited properties',
    ],
  },
  // ── ID 11 — AippieDev All-in-One Cloud Engine (V165) ─────────────────────
  {
    id: 'aippiedev', appTab: 'aippiedev',
    label: 'AippieDev Cloud Engine',
    icon: <Zap size={16} />,
    price: '€299',
    priceDetail: '/month',
    accentColor: '#818cf8',
    tagline: 'Autonomous AI Frontend · AWS Injector · Direct-to-Store',
    speech:
      'eye-pee Dev All-in-One Cloud Engine at two hundred and ninety-nine Euros per month. ' +
      'The complete autonomous software factory — no developers required. ' +
      'The Multimodal Canvas Layer lets you design your entire frontend using voice, image, or text commands, with real-time AI rendering across React, Vue, and native mobile. ' +
      'The Serverless AWS Database Injector auto-provisions Lambda functions, RDS instances, and S3 buckets in under sixty seconds — zero DevOps configuration. ' +
      'The Binary App Compiler cross-compiles your project for iOS, Android, and Progressive Web App in a single command. ' +
      'The Direct-to-Store Gateway handles certificate signing, App Store review metadata, and Play Store submission fully autonomously. ' +
      'Four pipeline nodes. One subscription. Total autonomy.',
    bullets: [
      'AI Frontend Canvas — voice · image · text design',
      'Serverless AWS Injector — Lambda · RDS · S3 auto-provisioned',
      'Binary Compiler — iOS · Android · PWA in one command',
      'Direct-to-Store Gateway — cert signing · auto-submission',
      '€299/month · 100% autonomous · zero DevOps',
    ],
  },
  // ── ID 13 — Aippie AI Academy & Education Hub ────────────────────────────
  {
    id: 'academy', appTab: 'academy',
    label: 'Aippie AI Academy',
    icon: <GraduationCap size={16} />,
    price: '€5',
    priceDetail: '/month',
    accentColor: '#f59e0b',
    tagline: 'AI-powered learning · B2C kids courses · B2B school portal',
    speech:
      'eye-pee A.I. Academy and Education Hub. ' +
      'The B2C Kids Learning plan at five Euros per month gives children access to adaptive AI-guided courses in maths, science, and coding — with live progress tracking, auto-grading, and animated AI tutors. ' +
      'The subscription auto-terminates upon course-completion so families never overpay. ' +
      'The B2B School Enterprise License at one hundred and ninety-nine Euros per month delivers a full white-label school portal plugin — custom branding, class roster management, teacher dashboards, and real-time learning analytics for every student. ' +
      'Holographic AI modules, automated grading charts, and live curriculum sync are included in both plans. ' +
      'GDPR-compliant. Available in Dutch, English, and Spanish.',
    bullets: [
      'B2C Kids Learning — €5/mo · auto-terminates on course completion',
      'B2B School Enterprise — €199/mo · white-label portal plugin',
      'AI-guided adaptive courses: maths · science · coding',
      'Live learning metrics · auto-grading · holographic tutors',
      'GDPR-compliant · Dutch · English · Spanish',
    ],
  },
  // ── ID 13+ — B2B Automation Hub (LEFT-8 / below Academy) ────────────────
  {
    id: 'b2b', appTab: 'b2b',
    label: 'B2B Automation Hub',
    icon: <Briefcase size={16} />,
    price: '€3.100',
    priceDetail: '/month',
    accentColor: '#38bdf8',
    tagline: 'Enterprise AIaaS & Licensing Matrix',
    speech:
      'eye-pee B2B Automation Hub. The complete enterprise AI-as-a-service and licensing matrix at three thousand one hundred Euros per month. ' +
      'Inbound audio and video greeting — the moment a new enterprise client arrives, the three-dimensional cybernetic AI face initialises Cinematic Mode and delivers an immediate multilingual voice greeting in Spanish, English, German, or Dutch. ' +
      'The Multi-Language Lead Automator compresses eighty hours of manual sales follow-up pipeline down to just eighty minutes across your entire enterprise network. ' +
      'The B2B multi-tenant API token generator issues unique cryptographic licence keys in AIPPIE format, deployable on any local Spanish Real Estate, Legal, or Medical website in seconds. ' +
      'The forty-eight hour invoicing and lockout system manages your bi-weekly fifteen fifty Euro payment cycles with a real-time grace countdown — automated server freeze if unsettled.',
    bullets: [
      'Cinematic AI Face — multilingual instant client greeting: ES · EN · DE · NL',
      'Lead Automator — 80h manual pipeline → 80 min AI-automated',
      'API token generator — AIPPIE-XXXX-XXXX-XXXX enterprise keys',
      'Sectors: Real Estate · Legal · Medical — embed on any domain',
      '48h billing lockout · bi-weekly €1,550 cycle · AML compliant',
    ],
  },
  // ── ID 14 — Aippie Autonomous Assistant & Call Script (Center Core) ───────
  {
    id: 'assistant', appTab: 'assistant',
    label: 'AI Assistant',
    icon: <MessageSquare size={16} />,
    price: 'FREE',
    priceDetail: 'Free Tier',
    accentColor: '#34d399',
    tagline: 'Message assistant & call script generator',
    speech:
      'eye-pee Autonomous Assistant and Call Script. Your personal AI message assistant and phone script generator — completely free. ' +
      'Paste or type any letter, contract, or email and Aippie reads it aloud and helps you draft a professional reply. ' +
      'The Call Script generator produces complete word-for-word scripts for hotel, restaurant, doctor, or service bookings. ' +
      'Aippie reads each sentence at a calm pace so you can follow along during a live phone call. ' +
      'Available in Dutch, English, and Spanish. Free to use with no subscription required.',
    bullets: [
      'Message reader & professional reply assistant',
      'Word-for-word phone booking script generator',
      'Hotel · restaurant · doctor · service scripts',
      'Dutch · English · Spanish support',
      '100% free — no subscription required',
    ],
  },
  // ── ID 16 — SecureChat & Video Vault ─────────────────────────────────────
  {
    id: 'securechat', appTab: 'securechat',
    label: 'SecureChat & Video Vault',
    icon: <Lock size={16} />,
    price: 'FREE',
    priceDetail: '100% Gratis',
    accentColor: '#22d3ee',
    tagline: 'E2EE · Sneak Guard · Voice Masking · P2P Video',
    speech:
      'eye-pee Secure Chat and Video Vault. The most private communication platform available, at nine ninety-nine per month. ' +
      'All messages are end-to-end encrypted with AES-256-GCM — zero server storage, zero metadata. ' +
      'The Sneak Guard module uses TinyFaceDetector computer vision to detect any unauthorised viewer over your shoulder in real time. ' +
      'AI Voice Masking shifts your vocal pitch by fifteen percent, making voice cloning mathematically impossible. ' +
      'The Video Vault boardroom connects up to six participants fully peer-to-peer — video never touches our servers. ' +
      'Messages self-destruct automatically after thirty-two seconds. One tap kills the entire session.',
    bullets: [
      'AES-256-GCM E2EE · zero server storage · zero metadata',
      'Sneak Guard — TinyFaceDetector over-shoulder CV detection',
      'AI Voice Masking — +15% pitch shift · anti voice-clone',
      'P2P Video Boardroom — up to 6 · no server video relay',
      '32s self-destruct · session kill switch · 100% FREE',
    ],
  },
  // ── ID 15 — Aippie Humanoid Robotics & Cybernetic Interface (RIGHT-7 · Module 18)
  {
    id: 'robotics', appTab: 'robotics',
    label: 'Humanoid Robotics',
    icon: <Cpu size={16} />,
    price: 'STAGING',
    priceDetail: 'Pre-production',
    accentColor: '#38bdf8',
    tagline: 'Cybernetic Interface · 5G/6G Cloud Brain · Safety OS',
    speech:
      'eye-pee Humanoid Robotics and Cybernetic Interface. Module eighteen — currently in engineering staging mode. ' +
      'The cloud-to-hardware telemetry layer streams over five-G and six-G uplinks to the Aippie Cloud Brain, with a confirmed round-trip latency of four point two milliseconds. ' +
      'The integrated three-dimensional spatial core runs stereo RGB-D computer vision at three hundred and twelve frames per second, enabling full autonomous navigation. ' +
      'All core directives and safety protocols operate under an immutable system safety override compliant with ISO ten-two-one-eight and I.E.C. sixty-two-four-four-three. ' +
      'Twenty-four servo motors are online. Power cell is at ninety-four percent. Neural net core integrity at ninety-eight point seven percent. ' +
      'This is a pre-production engineering blueprint — physical hardware is not yet available for purchase.',
    bullets: [
      'Cloud-to-Hardware Telemetry · 5G/6G · 4.2ms latency',
      'CV Navigation · Stereo RGB-D · 312 fps · 3D spatial core',
      'Core Safety OS · ISO 10218 · IEC 62443 · Immutable override',
      '24-DOF servo array · Edge TPU · 8 TOPS processing',
      'STAGING — Engineering Blueprint · Pre-production',
    ],
  },
];

// Layer 1 — 5 core products shown prominently in the left sidebar
const LEFT_IDS   = ['tax', 'securechat', 'trading', 'silentvoice', 'doctor'] as const;
// Layer 2 — all other products in the right sidebar
const RIGHT_IDS  = ['voice', 'wifi', 'companion', 'parking', 'guardian', 'wearable', 'realestate', 'aippiedev', 'academy', 'b2b', 'robotics'] as const;
const CENTER_ID  = 'assistant';

const MODULE_MAP: Record<string, Module> = {
  tax:         MODULES[0],   // LAYER1 1 — AippieTax AI Accountant              €100/month
  voice:       MODULES[1],   // LAYER2   — AippieVoice & Doc Scanner 3-in-1     €29.99/month
  wifi:        MODULES[2],   // LAYER2   — AippieWiFi Sharing                   €0.05/GB
  companion:   MODULES[3],   // LAYER2   — AI Relationship Companion            FREE
  silentvoice: MODULES[4],   // LAYER1 4 — Autisme AI Radar                     €5 donation
  trading:     MODULES[5],   // LAYER1 3 — Trading Alpha Signals                €499/month
  parking:     MODULES[6],   // LAYER2   — AippieParking 3D Map                 FREE
  guardian:    MODULES[7],   // LAYER2   — Aippie Guardian Shield               FREE
  wearable:    MODULES[8],   // LAYER2   — Smart Glass · Chrono-Cinema          FREE
  doctor:      MODULES[9],   // LAYER1 5 — Aippie Doctor Medical Suite          €30/consult
  realestate:  MODULES[10],  // LAYER2   — Aippie Real Estate Manager           €149/month
  aippiedev:   MODULES[11],  // LAYER2   — AippieDev Cloud Engine               €299/month
  assistant:   MODULES[14],  // CENTER   — Aippie Assistant & Call Script       FREE
  academy:     MODULES[12],  // LAYER2   — Aippie AI Academy & Education Hub    €5–€199/month
  b2b:         MODULES[13],  // LAYER2   — B2B Automation Hub                   €3.100/month
  securechat:  MODULES[15],  // LAYER1 2 — SecureChat & Video Vault             €9.99/month
  robotics:    MODULES[16],  // LAYER2   — Humanoid Robotics & Cybernetic Interface  STAGING
};

// V94: rate + pitch constants — locked, never overridden. Google US English preferred.
const SPEECH_RATE  = 0.82;
const SPEECH_PITCH = 1.02;

// Welcome speech — fires once on mount, then UI is static
const WELCOME_SPEECH       = 'Welcome to eye-pee. We are your all-in-one autonomous global ecosystem. Select a product to explore.';
const WELCOME_DISPLAY_TEXT = 'Welcome to Aippie. We are your all-in-one autonomous global ecosystem.';

function LipSyncMouth({ active, color }: { active: boolean; color: string }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const frameRef  = useRef<number>(0);
  const s = useRef({ open: 0, target: 0, nextAt: 0 });

  useEffect(() => {
    const canvas = canvasRef.current; if (!canvas) return;
    const ctx = canvas.getContext('2d'); if (!ctx) return;
    const W = canvas.width, H = canvas.height;

    const draw = (ts: number) => {
      if (ts > s.current.nextAt) {
        s.current.target = active ? 0.15 + Math.random() * 0.75 : 0;
        s.current.nextAt = ts + (active ? 55 + Math.random() * 95 : 300);
      }
      s.current.open += (s.current.target - s.current.open) * (active ? 0.38 : 0.22);

      ctx.clearRect(0, 0, W, H);
      const op = s.current.open;
      if (op > 0.03) {
        const mw = W * 0.78, mh = Math.max(1.5, H * op);
        const cx = W / 2, cy = H * 0.52;
        ctx.beginPath();
        ctx.ellipse(cx, cy, mw/2, mh/2, 0, 0, Math.PI*2);
        ctx.fillStyle = 'rgba(15,5,5,0.85)';
        ctx.fill();
        ctx.beginPath();
        ctx.ellipse(cx, cy + mh*0.28, mw*0.4, mh*0.18, 0, 0, Math.PI);
        ctx.fillStyle = color + '2a';
        ctx.fill();
      }
      ctx.beginPath();
      ctx.moveTo(W*0.1, H*0.52);
      ctx.bezierCurveTo(W*0.3, H*0.52 - H*op*0.35, W*0.7, H*0.52 - H*op*0.35, W*0.9, H*0.52);
      ctx.strokeStyle = 'rgba(80,40,40,0.5)';
      ctx.lineWidth = 1.5;
      ctx.stroke();

      frameRef.current = requestAnimationFrame(draw);
    };
    frameRef.current = requestAnimationFrame(draw);
    return () => cancelAnimationFrame(frameRef.current);
  }, [active, color]);

  return (
    <canvas
      ref={canvasRef}
      width={44}
      height={16}
      className="lp80-mouth-canvas"
      aria-hidden="true"
    />
  );
}

function Waveform({ active, color }: { active: boolean; color: string }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const frameRef  = useRef<number>(0);
  const tickRef   = useRef(0);
  useEffect(() => {
    const canvas = canvasRef.current; if (!canvas) return;
    const ctx = canvas.getContext('2d'); if (!ctx) return;
    const BARS = 28;
    const draw = () => {
      tickRef.current++;
      const tk = tickRef.current, W = canvas.width, H = canvas.height;
      ctx.clearRect(0, 0, W, H);
      const gap = W / BARS, barW = Math.max(2, gap - 2);
      for (let i = 0; i < BARS; i++) {
        const phase = (i / BARS) * Math.PI * 2;
        const rawH = active
          ? (0.12 + 0.88 * Math.abs(Math.sin(tk * 0.07 + phase))) * H
          : (0.06 + 0.04 * Math.abs(Math.sin(tk * 0.015 + phase))) * H;
        const x = i * gap + (gap - barW) / 2, y = (H - rawH) / 2;
        ctx.fillStyle = color + (active ? 'ee' : '2a');
        ctx.beginPath();
        ctx.roundRect(x, y, barW, rawH, Math.min(barW / 2, 4));
        ctx.fill();
      }
      frameRef.current = requestAnimationFrame(draw);
    };
    frameRef.current = requestAnimationFrame(draw);
    return () => cancelAnimationFrame(frameRef.current);
  }, [active, color]);
  return (
    <canvas
      ref={canvasRef}
      width={260}
      height={36}
      aria-hidden="true"
      className="lp80-waveform"
    />
  );
}

// ─── Typewriter subtitle hook ─────────────────────────────────────────────────
function useWordSubtitle(text: string, active: boolean) {
  const [sub, setSub] = useState('');
  const tmr = useRef<ReturnType<typeof setInterval> | null>(null);
  const idx  = useRef(0);
  useEffect(() => {
    if (tmr.current) { clearInterval(tmr.current); tmr.current = null; }
    setSub('');
    if (!active || !text.trim()) return;
    const words = text.split(/\s+/);
    idx.current = 0;
    tmr.current = setInterval(() => {
      idx.current++;
      setSub(words.slice(Math.max(0, idx.current - 9), idx.current).join(' '));
      if (idx.current >= words.length && tmr.current) {
        clearInterval(tmr.current); tmr.current = null;
      }
    }, 510); // ~510 ms/word matches rate=0.82 (~115 wpm)
    return () => { if (tmr.current) { clearInterval(tmr.current); tmr.current = null; } };
  }, [text, active]);
  return sub;
}

// Layer 1 product IDs — these get the AIPPIE_CORE_LOGO card background
const LAYER1_IDS = new Set(['tax', 'securechat', 'trading', 'silentvoice', 'doctor']);

// ─── Sidebar nav button ───────────────────────────────────────────────────────
function SideBtn({
  mod, active, onClick, onHover, side,
}: {
  mod: Module; active: boolean; onClick: (e: React.MouseEvent) => void; onHover?: () => void; side: 'left' | 'right';
}) {
  return (
    <button
      className={`lp80-side-btn lp80-side-btn--${side}${active ? ' lp80-side-btn--active' : ''}`}
      style={{
        borderColor: active ? mod.accentColor + '99' : mod.accentColor + '44',
        background: active ? mod.accentColor + '18' : mod.accentColor + '08',
        boxShadow: active ? `0 0 18px ${mod.accentColor}33` : `0 0 8px ${mod.accentColor}11`,
      }}
      onClick={(e) => { e.stopPropagation(); onClick(e); }}
      onMouseEnter={onHover}
    >
      <span className="lp80-side-btn__icon" style={{ color: mod.accentColor }}>
        {mod.icon}
      </span>
      <div className="lp80-side-btn__text">
        <span className="lp80-side-btn__label" style={{ color: active ? mod.accentColor : mod.accentColor + 'cc' }}>
          {mod.label}
        </span>
        <span className="lp80-side-btn__tag">{mod.tagline}</span>
      </div>
      <span
        className="lp80-side-btn__price"
        style={{ color: active ? mod.accentColor : mod.accentColor + '99' }}
      >
        {mod.price}
      </span>
      <span className="lp80-side-btn__active-dot" style={{ background: active ? mod.accentColor : mod.accentColor + '55' }} />
    </button>
  );
}

// ─── Product detail card ──────────────────────────────────────────────────────
function ProductCard({ mod, bgImg }: { mod: Module; bgImg?: string }) {
  return (
    <div
      className="lp80-product-card"
      style={{ borderColor: mod.accentColor + '44', position: 'relative', overflow: 'hidden' }}
      key={mod.id}
    >
      {bgImg && (
        <div
          aria-hidden="true"
          style={{
            position: 'absolute', inset: 0,
            backgroundImage: `url(${bgImg})`,
            backgroundSize: 'cover',
            backgroundPosition: 'center top',
            opacity: 0.07,
            pointerEvents: 'none',
          }}
        />
      )}
      <div className="lp80-product-card__header">
        <span className="lp80-product-card__icon" style={{ color: mod.accentColor, background: mod.accentColor + '15' }}>
          {mod.icon}
        </span>
        <div className="lp80-product-card__title-wrap">
          <span className="lp80-product-card__label" style={{ color: mod.accentColor }}>
            {mod.label}
          </span>
          <span className="lp80-product-card__tagline">{mod.tagline}</span>
        </div>
        <div className="lp80-product-card__price-wrap">
          <span className="lp80-product-card__price" style={{ color: mod.accentColor }}>
            {mod.price}
          </span>
          <span className="lp80-product-card__period">{mod.priceDetail}</span>
        </div>
      </div>
      <div className="lp80-product-card__bullets">
        {mod.bullets.map(b => (
          <div key={b} className="lp80-product-card__bullet">
            <CheckCircle2 size={10} style={{ color: mod.accentColor, flexShrink: 0 }} />
            <span>{b}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── Demo Cinema scene definitions ───────────────────────────────────────────
interface DemoScene {
  id:      string;
  label:   string;
  color:   string;
  frames:  { image: string; caption: string }[];
  bgClass: string;
}

const DEMO_SCENES: Record<string, DemoScene> = {
  tax: {
    id: 'tax', label: 'AippieTax · AI Accountant', color: '#4ade80', bgClass: 'dc-scene--tax',
    frames: [
      { image: 'https://images.pexels.com/photos/6863183/pexels-photo-6863183.jpeg?auto=compress&cs=tinysrgb&w=600&h=340&fit=crop', caption: 'AI scanning invoices with OCR…' },
      { image: 'https://images.pexels.com/photos/4386321/pexels-photo-4386321.jpeg?auto=compress&cs=tinysrgb&w=600&h=340&fit=crop', caption: 'IRPF + Loonheffing calculated automatically' },
      { image: 'https://images.pexels.com/photos/3760067/pexels-photo-3760067.jpeg?auto=compress&cs=tinysrgb&w=600&h=340&fit=crop', caption: 'Verifactu chain sealed ✓' },
      { image: 'https://images.pexels.com/photos/7821937/pexels-photo-7821937.jpeg?auto=compress&cs=tinysrgb&w=600&h=340&fit=crop', caption: 'Filed to Hacienda · Belastingdienst ✓' },
    ],
  },
  voice: {
    id: 'voice', label: 'AippieVoice · Translation · Dictation · OCR', color: '#38bdf8', bgClass: 'dc-scene--voice',
    frames: [
      { image: 'https://images.pexels.com/photos/7256247/pexels-photo-7256247.jpeg?auto=compress&cs=tinysrgb&w=600&h=340&fit=crop', caption: 'Live translation: interpreter connected NL→EN' },
      { image: 'https://images.pexels.com/photos/4226140/pexels-photo-4226140.jpeg?auto=compress&cs=tinysrgb&w=600&h=340&fit=crop', caption: 'Medical dictation: ICD-10 codes auto-inserted' },
      { image: 'https://images.pexels.com/photos/6214476/pexels-photo-6214476.jpeg?auto=compress&cs=tinysrgb&w=600&h=340&fit=crop', caption: 'OCR mail reader: letter photographed · parsing…' },
      { image: 'https://images.pexels.com/photos/5668772/pexels-photo-5668772.jpeg?auto=compress&cs=tinysrgb&w=600&h=340&fit=crop', caption: 'Certified translation delivered · E2EE sealed ✓' },
    ],
  },
  wifi: {
    id: 'wifi', label: 'AippieWiFi · Data Share', color: '#a78bfa', bgClass: 'dc-scene--wifi',
    frames: [
      { image: 'https://images.pexels.com/photos/1181345/pexels-photo-1181345.jpeg?auto=compress&cs=tinysrgb&w=600&h=340&fit=crop', caption: 'Hotspot broadcasting · WPA3 active…' },
      { image: 'https://images.pexels.com/photos/4482900/pexels-photo-4482900.jpeg?auto=compress&cs=tinysrgb&w=600&h=340&fit=crop', caption: '3 devices connected · 2.4 GB shared · €0.12 earned' },
    ],
  },
  companion: {
    id: 'companion', label: 'AI Companion', color: '#fb7185', bgClass: 'dc-scene--companion',
    frames: [
      { image: 'https://images.pexels.com/photos/7176319/pexels-photo-7176319.jpeg?auto=compress&cs=tinysrgb&w=600&h=340&fit=crop', caption: 'AI companion conversation started…' },
      { image: 'https://images.pexels.com/photos/4101143/pexels-photo-4101143.jpeg?auto=compress&cs=tinysrgb&w=600&h=340&fit=crop', caption: 'Emotional context analysed · empathy response generated' },
      { image: 'https://images.pexels.com/photos/5699516/pexels-photo-5699516.jpeg?auto=compress&cs=tinysrgb&w=600&h=340&fit=crop', caption: 'Daily check-in complete · mood score improved ↑' },
    ],
  },
  silentvoice: {
    id: 'silentvoice', label: 'Autism AI · Clinical 3D Scene', color: '#818cf8', bgClass: 'dc-scene--silent',
    frames: [
      { image: 'https://images.pexels.com/photos/3807517/pexels-photo-3807517.jpeg?auto=compress&cs=tinysrgb&w=600&h=340&fit=crop', caption: 'Clinical practitioner monitoring child patient…' },
      { image: 'https://images.pexels.com/photos/8376277/pexels-photo-8376277.jpeg?auto=compress&cs=tinysrgb&w=600&h=340&fit=crop', caption: 'Gaze tracking active · iris vector 94% · micro-saccades mapped' },
      { image: 'https://images.pexels.com/photos/4226264/pexels-photo-4226264.jpeg?auto=compress&cs=tinysrgb&w=600&h=340&fit=crop', caption: 'PPG telemetry: HR 88bpm · HRV 42ms · SpO2 98%' },
      { image: 'https://images.pexels.com/photos/7089401/pexels-photo-7089401.jpeg?auto=compress&cs=tinysrgb&w=600&h=340&fit=crop', caption: 'Clinical summary generated · GDPR compliant ✓' },
    ],
  },
  interpreter: {
    id: 'interpreter', label: 'Live Interpreter', color: '#f59e0b', bgClass: 'dc-scene--interp',
    frames: [
      { image: 'https://images.pexels.com/photos/7516347/pexels-photo-7516347.jpeg?auto=compress&cs=tinysrgb&w=600&h=340&fit=crop', caption: 'Certified interpreter live · E2EE WebRTC' },
      { image: 'https://images.pexels.com/photos/5935791/pexels-photo-5935791.jpeg?auto=compress&cs=tinysrgb&w=600&h=340&fit=crop', caption: '40+ languages · €0.25/min · auto-transfer' },
    ],
  },
  trading: {
    id: 'trading', label: 'Trading Alpha · Multi-Monitor Workspace', color: '#fbbf24', bgClass: 'dc-scene--trading',
    frames: [
      { image: 'https://images.pexels.com/photos/6771985/pexels-photo-6771985.jpeg?auto=compress&cs=tinysrgb&w=600&h=340&fit=crop', caption: 'Multi-monitor trading workspace · live candle charts' },
      { image: 'https://images.pexels.com/photos/6801648/pexels-photo-6801648.jpeg?auto=compress&cs=tinysrgb&w=600&h=340&fit=crop', caption: 'Candle chart: BTC/USD · 4H · 847 bars · VWAP · RSI live' },
      { image: 'https://images.pexels.com/photos/7567443/pexels-photo-7567443.jpeg?auto=compress&cs=tinysrgb&w=600&h=340&fit=crop', caption: 'Dark-pool liquidity: $2.4B block detected · algorithm fired' },
      { image: 'https://images.pexels.com/photos/6771900/pexels-photo-6771900.jpeg?auto=compress&cs=tinysrgb&w=600&h=340&fit=crop', caption: 'LONG entry $43,210 · position closed · +4.7% · P&L +€21,500' },
    ],
  },
  parking: {
    id: 'parking', label: 'AippieParking · Smart City Garage', color: '#34d399', bgClass: 'dc-scene--parking',
    frames: [
      { image: 'https://images.pexels.com/photos/1004409/pexels-photo-1004409.jpeg?auto=compress&cs=tinysrgb&w=600&h=340&fit=crop', caption: 'Smart city garage · vehicle approaching slot B-14…' },
      { image: 'https://images.pexels.com/photos/3562975/pexels-photo-3562975.jpeg?auto=compress&cs=tinysrgb&w=600&h=340&fit=crop', caption: 'Slot C-07: VACANT · docking sequence active' },
      { image: 'https://images.pexels.com/photos/3593922/pexels-photo-3593922.jpeg?auto=compress&cs=tinysrgb&w=600&h=340&fit=crop', caption: 'Parked & logged · GPS anchor set · 0 min wait ✓' },
    ],
  },
  guardian: {
    id: 'guardian', label: 'Guardian Shield · Safe Check-In', color: '#4ade80', bgClass: 'dc-scene--guardian',
    frames: [
      { image: 'https://images.pexels.com/photos/6963944/pexels-photo-6963944.jpeg?auto=compress&cs=tinysrgb&w=600&h=340&fit=crop', caption: 'Safe check-in timer armed · 45 min countdown active' },
      { image: 'https://images.pexels.com/photos/5699479/pexels-photo-5699479.jpeg?auto=compress&cs=tinysrgb&w=600&h=340&fit=crop', caption: 'Location transmitted to emergency contact' },
      { image: 'https://images.pexels.com/photos/8363028/pexels-photo-8363028.jpeg?auto=compress&cs=tinysrgb&w=600&h=340&fit=crop', caption: 'Safe check-in confirmed · all contacts notified ✓' },
    ],
  },
  wearable: {
    id: 'wearable', label: 'Smart Glass · Chrono-Cinema', color: '#c084fc', bgClass: 'dc-scene--wearable',
    frames: [
      { image: 'https://images.pexels.com/photos/3778608/pexels-photo-3778608.jpeg?auto=compress&cs=tinysrgb&w=600&h=340&fit=crop', caption: 'Smart Glass AR overlay active · time era: 1920s Paris' },
      { image: 'https://images.pexels.com/photos/2901581/pexels-photo-2901581.jpeg?auto=compress&cs=tinysrgb&w=600&h=340&fit=crop', caption: 'Chrono-Cinema rendering · immersive experience live ✓' },
    ],
  },
  doctor: {
    id: 'doctor', label: 'Aippie Doctor · Smart Band · Biometric Monitor', color: '#4ade80', bgClass: 'dc-scene--doctor',
    frames: [
      { image: 'https://images.pexels.com/photos/5407206/pexels-photo-5407206.jpeg?auto=compress&cs=tinysrgb&w=600&h=340&fit=crop', caption: 'Female doctor reviewing patient vitals in real time' },
      { image: 'https://images.pexels.com/photos/4386467/pexels-photo-4386467.jpeg?auto=compress&cs=tinysrgb&w=600&h=340&fit=crop', caption: 'Male doctor and patient consultation · PPG sensor live' },
      { image: 'https://images.pexels.com/photos/7089020/pexels-photo-7089020.jpeg?auto=compress&cs=tinysrgb&w=600&h=340&fit=crop', caption: 'Smart Band: HR 74bpm · HRV 61ms · SpO2 98% · BLE paired' },
      { image: 'https://images.pexels.com/photos/4226219/pexels-photo-4226219.jpeg?auto=compress&cs=tinysrgb&w=600&h=340&fit=crop', caption: 'Heart anomaly detected → 112 emergency dispatch · ETA 6 min' },
    ],
  },
  realestate: {
    id: 'realestate', label: 'Real Estate Manager', color: '#38bdf8', bgClass: 'dc-scene--re',
    frames: [
      { image: 'https://images.pexels.com/photos/1732414/pexels-photo-1732414.jpeg?auto=compress&cs=tinysrgb&w=600&h=340&fit=crop', caption: 'Portfolio loading 12 properties · ROI analysis: +8.4% YTD' },
      { image: 'https://images.pexels.com/photos/7578875/pexels-photo-7578875.jpeg?auto=compress&cs=tinysrgb&w=600&h=340&fit=crop', caption: 'Tenant lease auto-renewed · rent received €4,200/month' },
    ],
  },
  assistant: {
    id: 'assistant', label: 'AI Assistant · Call Script', color: '#34d399', bgClass: 'dc-scene--assistant',
    frames: [
      { image: 'https://images.pexels.com/photos/3182812/pexels-photo-3182812.jpeg?auto=compress&cs=tinysrgb&w=600&h=340&fit=crop', caption: 'Message analysed · professional reply drafted in 1.2s' },
      { image: 'https://images.pexels.com/photos/7709238/pexels-photo-7709238.jpeg?auto=compress&cs=tinysrgb&w=600&h=340&fit=crop', caption: 'Phone script generated · AI reading aloud to user ✓' },
    ],
  },
  aippiedev: {
    id: 'aippiedev', label: 'AippieDev · 4-Node Cloud Factory', color: '#818cf8', bgClass: 'dc-scene--aippiedev',
    frames: [
      { image: 'https://images.pexels.com/photos/546819/pexels-photo-546819.jpeg?auto=compress&cs=tinysrgb&w=600&h=340&fit=crop', caption: '4-node dev workspace · UI generated via voice command' },
      { image: 'https://images.pexels.com/photos/1181271/pexels-photo-1181271.jpeg?auto=compress&cs=tinysrgb&w=600&h=340&fit=crop', caption: 'AWS Lambda + RDS + S3 provisioned · build running…' },
      { image: 'https://images.pexels.com/photos/3861969/pexels-photo-3861969.jpeg?auto=compress&cs=tinysrgb&w=600&h=340&fit=crop', caption: 'App Store & Play Store: submitted autonomously ✓' },
    ],
  },
  robotics: {
    id: 'robotics', label: 'Aippie Humanoid Robotics · v214', color: '#38bdf8', bgClass: 'dc-scene--robotics',
    frames: [
      { image: 'https://images.pexels.com/photos/8566526/pexels-photo-8566526.jpeg?auto=compress&cs=tinysrgb&w=600&h=340&fit=crop', caption: 'Humanoid robot online · cybernetic wireframe syncing live' },
      { image: 'https://images.pexels.com/photos/8566472/pexels-photo-8566472.jpeg?auto=compress&cs=tinysrgb&w=600&h=340&fit=crop', caption: '24 servo motors · CV navigation · 312 fps · ISO 10218 compliant' },
    ],
  },
  academy: {
    id: 'academy', label: 'Aippie AI Academy · Teacher Console', color: '#f59e0b', bgClass: 'dc-scene--academy',
    frames: [
      { image: 'https://images.pexels.com/photos/4145153/pexels-photo-4145153.jpeg?auto=compress&cs=tinysrgb&w=600&h=340&fit=crop', caption: 'Teacher console live · 4 classes · 100 students enrolled' },
      { image: 'https://images.pexels.com/photos/5212345/pexels-photo-5212345.jpeg?auto=compress&cs=tinysrgb&w=600&h=340&fit=crop', caption: 'Interactive lesson active · avg score 85.4% ↑' },
      { image: 'https://images.pexels.com/photos/8199562/pexels-photo-8199562.jpeg?auto=compress&cs=tinysrgb&w=600&h=340&fit=crop', caption: 'Week 12 certificate · all nodes PASS ✓' },
    ],
  },
  securechat: {
    id: 'securechat', label: 'SecureChat & Video Vault · E2EE', color: '#22d3ee', bgClass: 'dc-scene--securechat',
    frames: [
      { image: 'https://images.pexels.com/photos/5473298/pexels-photo-5473298.jpeg?auto=compress&cs=tinysrgb&w=600&h=340&fit=crop', caption: 'E2EE message sent · AES-256-GCM sealed · 32s timer armed' },
      { image: 'https://images.pexels.com/photos/5380664/pexels-photo-5380664.jpeg?auto=compress&cs=tinysrgb&w=600&h=340&fit=crop', caption: 'Sneak Guard active · 0 unauthorized viewers detected' },
      { image: 'https://images.pexels.com/photos/7544458/pexels-photo-7544458.jpeg?auto=compress&cs=tinysrgb&w=600&h=340&fit=crop', caption: 'P2P Video Boardroom · 3 peers connected · voice masked ✓' },
      { image: 'https://images.pexels.com/photos/5380642/pexels-photo-5380642.jpeg?auto=compress&cs=tinysrgb&w=600&h=340&fit=crop', caption: 'Message self-destructed · zero traces · session sealed ✓' },
    ],
  },
  b2b: {
    id: 'b2b', label: 'B2B Automation Hub · Enterprise License Gateway', color: '#38bdf8', bgClass: 'dc-scene--b2b',
    frames: [
      { image: 'https://images.pexels.com/photos/3182781/pexels-photo-3182781.jpeg?auto=compress&cs=tinysrgb&w=600&h=340&fit=crop', caption: '80h manual pipeline → 80 min AI-automated · 20-module core online' },
      { image: 'https://images.pexels.com/photos/7567455/pexels-photo-7567455.jpeg?auto=compress&cs=tinysrgb&w=600&h=340&fit=crop', caption: 'Multi-language outreach: ES · EN · DE · NL · license SECURE ✓' },
    ],
  },
};
const DEFAULT_SCENE = DEMO_SCENES['tax'];

// ─── Live telemetry bar — simulates rolling 3D metrics ───────────────────────
const TELEMETRY_SETS: Record<string, { label: string; getValue: () => string }[]> = {
  securechat: [
    { label: 'E2EE',     getValue: () => 'AES-256' },
    { label: 'SNEAK',    getValue: () => `${Math.random() > 0.9 ? 1 : 0} alerts` },
    { label: 'TIMER',    getValue: () => `${Math.floor(32 - Math.random() * 30)}s` },
    { label: 'PEERS',    getValue: () => `${Math.floor(1 + Math.random() * 5)}` },
  ],
  trading:    [
    { label: 'BTC/USD',  getValue: () => `$${(43000 + Math.random() * 2000).toFixed(0)}` },
    { label: 'VOL 24H',  getValue: () => `${(18 + Math.random() * 8).toFixed(1)}B` },
    { label: 'RSI(14)',  getValue: () => `${(44 + Math.random() * 18).toFixed(1)}` },
    { label: 'P&L',      getValue: () => `+€${(800 + Math.random() * 600).toFixed(0)}` },
  ],
  parking:    [
    { label: 'VACANT',   getValue: () => `${Math.floor(3 + Math.random() * 12)}` },
    { label: 'OCCUPIED', getValue: () => `${Math.floor(28 + Math.random() * 10)}` },
    { label: 'ETA',      getValue: () => `${Math.floor(1 + Math.random() * 4)}min` },
    { label: 'LEVEL',    getValue: () => `B${Math.floor(1 + Math.random() * 3)}` },
  ],
  doctor:     [
    { label: 'HR',       getValue: () => `${Math.floor(68 + Math.random() * 20)}bpm` },
    { label: 'SpO2',     getValue: () => `${(97 + Math.random() * 2.5).toFixed(1)}%` },
    { label: 'HRV',      getValue: () => `${Math.floor(38 + Math.random() * 30)}ms` },
    { label: 'STRESS',   getValue: () => `${Math.floor(20 + Math.random() * 40)}%` },
  ],
  silentvoice:[
    { label: 'GAZE',     getValue: () => `${(88 + Math.random() * 10).toFixed(1)}%` },
    { label: 'HR',       getValue: () => `${Math.floor(70 + Math.random() * 25)}bpm` },
    { label: 'POSTURE',  getValue: () => `${Math.floor(70 + Math.random() * 28)}%` },
    { label: 'SIGNAL',   getValue: () => `5/5` },
  ],
  aippiedev:  [
    { label: 'NODES',    getValue: () => `4/4` },
    { label: 'BUNDLE',   getValue: () => `${(900 + Math.random() * 80).toFixed(0)}kB` },
    { label: 'LATENCY',  getValue: () => `${(8 + Math.random() * 6).toFixed(0)}ms` },
    { label: 'BUILDS',   getValue: () => `${Math.floor(3 + Math.random() * 5)}` },
  ],
  academy:    [
    { label: 'STUDENTS', getValue: () => `${Math.floor(300 + Math.random() * 40)}` },
    { label: 'AVG SCORE',getValue: () => `${(82 + Math.random() * 12).toFixed(0)}%` },
    { label: 'GRADED',   getValue: () => `${Math.floor(40 + Math.random() * 20)}` },
    { label: 'COURSES',  getValue: () => `${Math.floor(6 + Math.random() * 4)}` },
  ],
  b2b:        [
    { label: 'EFFICIENCY', getValue: () => '80h→80min' },
    { label: 'LEADS',      getValue: () => `${51 + Math.floor(Math.random() * 4)}` },
    { label: 'LOCKOUT',    getValue: (() => {
        const start = Date.now();
        return () => {
          const rem = Math.max(0, 47 * 3600 + 58 * 60 + 43 - Math.floor((Date.now() - start) / 1000));
          const h = Math.floor(rem / 3600);
          const m = Math.floor((rem % 3600) / 60);
          const s = rem % 60;
          return `${String(h).padStart(2,'0')}:${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}`;
        };
      })()
    },
    { label: 'KEYS',       getValue: () => '4' },
  ],
};

function LiveTelemetry({ sceneId, color }: { sceneId: string; color: string }) {
  const metrics = TELEMETRY_SETS[sceneId];
  const [vals, setVals] = useState(() => metrics?.map(m => m.getValue()) ?? []);
  useEffect(() => {
    if (!metrics) return;
    const tmr = setInterval(() => setVals(metrics.map(m => m.getValue())), 900);
    return () => clearInterval(tmr);
  }, [metrics]);
  if (!metrics) return null;
  return (
    <div className="lp165-telemetry">
      {metrics.map((m, i) => (
        <div key={m.label} className="lp165-telemetry__item">
          <span className="lp165-telemetry__label">{m.label}</span>
          <span className="lp165-telemetry__val" style={{ color }}>{vals[i]}</span>
        </div>
      ))}
    </div>
  );
}

// ─── Demo Cinema component ────────────────────────────────────────────────────
function DemoCinema({ sceneId, accentColor }: { sceneId: string; accentColor: string }) {
  const scene = DEMO_SCENES[sceneId] ?? DEFAULT_SCENE;
  const [frameIdx, setFrameIdx] = useState(0);
  const tmrRef = useRef<ReturnType<typeof setInterval> | null>(null);

  // Restart frame cycle whenever scene changes — 1.4s for high-fidelity feel
  useEffect(() => {
    setFrameIdx(0);
    if (tmrRef.current) clearInterval(tmrRef.current);
    tmrRef.current = setInterval(() => {
      setFrameIdx(i => (i + 1) % scene.frames.length);
    }, 1400);
    return () => { if (tmrRef.current) clearInterval(tmrRef.current); };
  }, [sceneId, scene.frames.length]);

  const frame = scene.frames[frameIdx];
  const hasTelemetry = Boolean(TELEMETRY_SETS[sceneId]);

  return (
    <div className={`lp163-cinema ${scene.bgClass}`} style={{ '--dc-accent': accentColor } as React.CSSProperties}>
      {/* Header bar */}
      <div className="lp163-cinema__bar">
        <span className="lp163-cinema__dot lp163-cinema__dot--red" />
        <span className="lp163-cinema__dot lp163-cinema__dot--yellow" />
        <span className="lp163-cinema__dot lp163-cinema__dot--green" />
        <span className="lp163-cinema__bar-label">Product Demo Cinema · 3D Simulation</span>
        <span className="lp163-cinema__live-badge" style={{ color: accentColor, borderColor: accentColor + '55', background: accentColor + '11' }}>
          ▶ LIVE
        </span>
      </div>

      {/* Scene display */}
      <div className="lp163-cinema__stage">
        {/* Real product photo — keyed to frameIdx for crossfade */}
        <img
          key={`img-${sceneId}-${frameIdx}`}
          src={frame.image}
          alt={frame.caption}
          className="lp163-cinema__photo"
          onError={e => { (e.currentTarget as HTMLImageElement).style.display = 'none'; }}
        />

        {/* Accent overlay so caption is always readable */}
        <div className="lp163-cinema__photo-overlay" style={{ background: `linear-gradient(to top, ${accentColor}55 0%, transparent 60%)` }} />

        {/* Frame caption */}
        <div
          key={`cap-${sceneId}-${frameIdx}`}
          className="lp163-cinema__caption"
          style={{ color: '#fff' }}
        >
          {frame.caption}
        </div>

        {/* Progress dots */}
        <div className="lp163-cinema__progress">
          {scene.frames.map((_, i) => (
            <span
              key={i}
              className="lp163-cinema__progress-dot"
              style={{ background: i === frameIdx ? accentColor : 'rgba(255,255,255,0.3)' }}
            />
          ))}
        </div>

        {/* Scan line sweep */}
        <div className="lp163-cinema__scanline" style={{ background: `linear-gradient(180deg, transparent, ${accentColor}22, transparent)` }} />
      </div>

      {/* Live telemetry strip for high-fidelity 3D scenes */}
      {hasTelemetry && <LiveTelemetry sceneId={sceneId} color={accentColor} />}

      {/* Scene label footer */}
      <div className="lp163-cinema__footer">
        <span className="lp163-cinema__scene-name" style={{ color: accentColor }}>{scene.label}</span>
        <span className="lp163-cinema__frame-counter">{frameIdx + 1}/{scene.frames.length}</span>
      </div>
    </div>
  );
}

// ─── Main component ───────────────────────────────────────────────────────────
type Props = {
  onComplete: () => void;
  onNavigate?: (appTab: string) => void;
  lang?: LangCode;
  onLangChange?: (l: LangCode) => void;
  user?: import('@supabase/supabase-js').User | null;
};

export default function LandingPresentation({ onComplete, onNavigate, lang: langProp, onLangChange, user }: Props) {
  const [activeId,       setActiveId]       = useState<string>('tax');
  const [speaking,       setSpeaking]       = useState(false);
  const [subtitleText,   setSubtitleText]   = useState(WELCOME_DISPLAY_TEXT);
  const [lang,           setLang]           = useState<LangCode>(langProp ?? detectBrowserLang());
  const [checkoutProduct, setCheckoutProduct] = useState<CheckoutProduct | null>(null);
  const [flashColor,     setFlashColor]     = useState<string | null>(null);
  const [detailOpen,     setDetailOpen]     = useState(false);
  const [adModalOpen,    setAdModalOpen]    = useState(false);

  const onCompleteRef  = useRef(onComplete);
  const onNavigateRef  = useRef(onNavigate);
  const cancelledRef   = useRef(false);

  // Sync external lang prop changes
  useEffect(() => { if (langProp) setLang(langProp); }, [langProp]);

  const handleLangChange = (l: LangCode) => {
    setLang(l);
    storeLang(l);
    window.speechSynthesis?.cancel();
    onLangChange?.(l);
  };

  useEffect(() => { onCompleteRef.current = onComplete; }, [onComplete]);
  useEffect(() => { onNavigateRef.current = onNavigate; }, [onNavigate]);

  // V90: direct map lookup — never undefined, never wrong module
  const activeMod = MODULE_MAP[activeId] ?? MODULES[0];
  const subtitle  = useWordSubtitle(subtitleText, speaking);

  // ── speak() — V94: avatar activates immediately on click, not on onstart ─
  //
  // Chrome/Chromium bug: onstart is sometimes never called (short utterances,
  // missing voice selection, suspended AudioContext). We cannot rely on it to
  // show the avatar. Fix: setSpeaking(true) synchronously before withVoicesReady
  // so rings/waveform/subtitles are always visible from the moment of click.
  // onstart is kept as a secondary no-op guard; onend/onerror clear the state.
  const speak = useCallback((ttsText: string, displayText: string) => {
    if (!('speechSynthesis' in window)) return;

    // Cancel any running utterance and mark previous session stale
    cancelledRef.current = true;
    window.speechSynthesis.cancel();

    // Update display text and activate avatar visuals IMMEDIATELY
    setSubtitleText(displayText);
    setSpeaking(true);

    // Stamp a fresh session token
    const sessionId = Symbol();
    const sessionRef = { id: sessionId };
    cancelledRef.current = false;

    const fire = () => {
      if (cancelledRef.current) { setSpeaking(false); return; }

      const normalised = normalizeForTTS(ttsText);
      const u = new SpeechSynthesisUtterance(normalised);
      u.rate  = SPEECH_RATE;
      u.pitch = SPEECH_PITCH;
      applyPremiumVoice(u);

      // onstart is a safety re-confirm; the visual is already active above
      u.onstart = () => { if (!cancelledRef.current) setSpeaking(true); };
      u.onend   = () => { if (sessionRef.id === sessionId) setSpeaking(false); };
      u.onerror = () => { if (sessionRef.id === sessionId) setSpeaking(false); };

      window.speechSynthesis.speak(u);
    };

    withVoicesReady(fire);
  }, []);

  // ── Mount: fire welcome speech instantly — V106 zero-delay hook ──────────
  // withVoicesReady already handles the browser voice-list race internally.
  // No setTimeout here — avatar activates on the same render tick as mount.
  useEffect(() => {
    cancelledRef.current = false;
    speak(WELCOME_SPEECH, WELCOME_DISPLAY_TEXT);
    return () => {
      cancelledRef.current = true;
      window.speechSynthesis?.cancel();
    };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // ── V202: User click — explicit id routing, no closure capture on activeMod ─
  const handleSelect = useCallback((id: string, e?: React.MouseEvent) => {
    e?.stopPropagation();
    const mod = MODULE_MAP[id];
    if (!mod) return;
    setActiveId(id);
    setDetailOpen(true);
    speak(mod.speech, mod.speech);
  }, [speak]);

  // ── V163: hover updates cinema scene only — no speech on hover ───────────
  const handleHover = useCallback((id: string) => {
    if (id === activeId) return;
    setActiveId(id);
    // No speech on hover — only update the cinema/product card visually
  }, [activeId]);

  // ── Enter Aippie (skip landing) ───────────────────────────────────────────
  const handleEnter = useCallback(() => {
    cancelledRef.current = true;
    window.speechSynthesis?.cancel();
    // Flash the active product's color, then navigate
    const mod = MODULE_MAP[activeId];
    const color = mod?.accentColor ?? '#38bdf8';
    setFlashColor(color);
    setTimeout(() => {
      onCompleteRef.current();
    }, 420);
  }, [activeId]);

  // ── V202: "Go to [Product]" — appTab passed explicitly from the module's own
  //    data, never inferred from activeMod closure (prevents Module 2 / 16 collision)
  const handleGoToProduct = useCallback((appTab: string, e?: React.MouseEvent) => {
    e?.stopPropagation();
    // Look up by appTab first; fall back to id lookup for modules whose id === appTab
    const mod = Object.values(MODULE_MAP).find(m => m.appTab === appTab) ?? MODULE_MAP[appTab];
    if (!mod) return;

    if (PAID_TABS.has(appTab)) {
      // Pause speech, show checkout — do NOT unmount landing yet
      cancelledRef.current = true;
      window.speechSynthesis?.cancel();
      setSpeaking(false);
      setCheckoutProduct({
        label:       mod.label,
        price:       mod.price,
        priceDetail: mod.priceDetail,
        accentColor: mod.accentColor,
        appTab:      mod.appTab,    // always the module's own appTab, never stale state
      });
      return;
    }

    // Free module — flash product color then navigate
    cancelledRef.current = true;
    window.speechSynthesis?.cancel();
    setFlashColor(mod.accentColor);
    setTimeout(() => {
      onCompleteRef.current();
      setTimeout(() => { onNavigateRef.current?.(appTab); }, 0);
    }, 420);
  }, []);

  // ── CheckoutGate callbacks ─────────────────────────────────────────────
  const handleCheckoutUnlocked = useCallback((_key: string) => {
    const appTab = checkoutProduct?.appTab;
    setCheckoutProduct(null);
    if (!appTab) return;
    cancelledRef.current = true;
    window.speechSynthesis?.cancel();
    onCompleteRef.current();
    setTimeout(() => { onNavigateRef.current?.(appTab); }, 0);
  }, [checkoutProduct]);

  const handleCheckoutClose = useCallback(() => {
    setCheckoutProduct(null);
    // Resume welcome speech after dismissal
    setTimeout(() => {
      cancelledRef.current = false;
      speak(WELCOME_SPEECH, WELCOME_DISPLAY_TEXT);
    }, 200);
  }, [speak]);

  const centerMod  = MODULE_MAP[CENTER_ID];

  return (
    <div
      className="lp80-root"
      style={{ '--lp80-accent': activeMod.accentColor } as React.CSSProperties}
    >
      <div className="lp80-bg" />

      {/* ── Product entry color flash overlay ── */}
      {flashColor && (
        <div
          key={flashColor + Date.now()}
          className="lp-entry-flash"
          style={{ background: flashColor }}
        />
      )}

      {/* ── CheckoutGate overlay — shown over landing for paid modules ── */}
      {checkoutProduct && (
        <CheckoutGate
          product={checkoutProduct}
          onUnlocked={handleCheckoutUnlocked}
          onClose={handleCheckoutClose}
        />
      )}

      {/* ── Top bar ── */}
      <div className="lp80-topbar">
        <div className="lp80-topbar__brand">
          <Building2 size={14} style={{ color: '#60a5fa' }} />
          <span className="lp80-topbar__name">Aippie</span>
          <span className="lp80-topbar__badge">AIPPIETAX S.A. · v214</span>
        </div>
        <div className="lp80-topbar__right">
          <GlobalLangSelector lang={lang} onLangChange={handleLangChange} />
          <button className="lp80-skip-btn" onClick={handleEnter}>
            Enter Aippie <ChevronRight size={11} />
          </button>
        </div>
      </div>

      {/* ── FULLSCREEN PRODUCT DETAIL VIEW ── */}
      {detailOpen && (
        <div
          className="lpd-overlay lp203-fade-in"
          style={{ '--lpd-color': activeMod.accentColor } as React.CSSProperties}
        >
          {/* Gradient background in product color */}
          <div className="lpd-overlay__bg" style={{
            background: `radial-gradient(ellipse 120% 80% at 50% 0%, ${activeMod.accentColor}22 0%, transparent 60%),
                         radial-gradient(ellipse 100% 100% at 50% 50%, rgba(3,8,16,0.75) 0%, rgba(3,8,16,0.92) 100%)`
          }} />

          {/* Top bar with back button */}
          <div className="lpd-overlay__topbar">
            <button
              className="lpd-back-btn"
              onClick={() => setDetailOpen(false)}
              style={{ color: activeMod.accentColor, borderColor: activeMod.accentColor + '44' }}
            >
              <ChevronLeft size={16} />
              Back
            </button>
            <div className="lpd-overlay__brand">
              <span className="lpd-overlay__brand-name" style={{ color: activeMod.accentColor }}>
                {activeMod.icon} {activeMod.label}
              </span>
            </div>
            <button className="lpd-enter-small" onClick={handleEnter}>
              All modules <ChevronRight size={11} />
            </button>
          </div>

          {/* Product hero */}
          <div className="lpd-hero">
            <div
              className="lpd-hero__icon-wrap"
              style={{ background: activeMod.accentColor + '18', border: `2px solid ${activeMod.accentColor}55`, boxShadow: `0 0 40px ${activeMod.accentColor}33` }}
            >
              <span style={{ color: activeMod.accentColor, fontSize: 36 }}>{activeMod.icon}</span>
            </div>
            <h1 className="lpd-hero__title" style={{ color: activeMod.accentColor }}>{activeMod.label}</h1>
            <p className="lpd-hero__tagline">{activeMod.tagline}</p>
            <div className="lpd-hero__price" style={{ color: activeMod.accentColor }}>
              {activeMod.price}
              <span className="lpd-hero__price-detail">{activeMod.priceDetail}</span>
            </div>
          </div>

          {/* Feature bullets */}
          <div className="lpd-bullets">
            {activeMod.bullets.map(b => (
              <div key={b} className="lpd-bullet" style={{ borderColor: activeMod.accentColor + '33', background: activeMod.accentColor + '0a' }}>
                <CheckCircle2 size={14} style={{ color: activeMod.accentColor, flexShrink: 0 }} />
                <span>{b}</span>
              </div>
            ))}
          </div>

          {/* Demo cinema */}
          <div key={`lpd-cinema-${activeMod.id}`} className="lpd-cinema lp203-fade-in">
            <DemoCinema sceneId={activeId} accentColor={activeMod.accentColor} />
          </div>

          {/* CTA */}
          <div className="lpd-cta">
            {(() => {
              const capturedTab = activeMod.appTab;
              return (
                <button
                  className="lpd-open-btn"
                  style={{
                    background: `linear-gradient(135deg, ${activeMod.accentColor}cc, ${activeMod.accentColor}88)`,
                    boxShadow: `0 8px 32px ${activeMod.accentColor}44`,
                    color: '#0f172a',
                  }}
                  onClick={(e) => { e.stopPropagation(); handleGoToProduct(capturedTab, e); }}
                >
                  {activeMod.icon}
                  <span>Open {activeMod.label}</span>
                  <ChevronRight size={16} />
                </button>
              );
            })()}
            <button
              className="lpd-back-btn-bottom"
              onClick={() => setDetailOpen(false)}
            >
              <ChevronLeft size={14} />
              Back to overview
            </button>
          </div>

          <div className="lpd-footer">
            <Building2 size={8} />
            AIPPIETAX S.A. · v214 · All rights reserved
          </div>
        </div>
      )}

      {/* ── MAIN LANDING VIEW ── */}
      {/* ── Hero section ── */}
      <div className="lp-hero">
        <div className="lp-hero__glow" />
        <div className="lp-hero__inner">
          <div className="lp-hero__eyebrow">
            <span className="lp-hero__dot" />
            AI Platform · 20+ Modules · Live Now
          </div>
          <h1 className="lp-hero__title">
            Your entire life,<br />
            <span className="lp-hero__accent">run by AI.</span>
          </h1>
          <p className="lp-hero__sub">
            Tax · Trading · Doctor · Legal · Life Assistant · Real Estate<br />
            One platform. One AI. Everything automated.
          </p>
          <div className="lp-hero__actions">
            <button className="lp-hero__cta" onClick={handleEnter}>
              Open Aippie <ChevronRight size={14} />
            </button>
            <div className="lp-hero__stats">
              {[
                { val: '20+', label: 'AI Products' },
                { val: '€0', label: 'Free to start' },
                { val: '24/7', label: 'Always on' },
              ].map(s => (
                <div key={s.val} className="lp-hero__stat">
                  <span className="lp-hero__stat-val">{s.val}</span>
                  <span className="lp-hero__stat-label">{s.label}</span>
                </div>
              ))}
            </div>
          </div>
          {/* Quick-launch product pills — Layer 1 only */}
          <div className="lp-hero__pills">
            {MODULES.filter(m => LAYER1_IDS.has(m.id)).map(m => (
              <button
                key={m.id}
                className="lp-hero__pill"
                style={{ '--pill-color': m.accentColor } as React.CSSProperties}
                onClick={e => { setActiveId(m.id); handleGoToProduct(m.appTab, e); }}
              >
                {m.icon}
                <span>{m.label.split(' ')[0]}</span>
              </button>
            ))}
            <button className="lp-hero__pill lp-hero__pill--more" onClick={handleEnter}>
              +{MODULES.length - 5} more
            </button>
          </div>
        </div>
        <div className="lp-hero__avatar-wrap">
          <img
            src="/Jouw_alineatekst_(2).png"
            alt="Aippie Logo"
            className="lp-hero__avatar"
            onError={e => { (e.currentTarget as HTMLImageElement).style.display = 'none'; }}
          />
        </div>
      </div>

      {/* ── Sidebar product list ── */}
      <div className="lp80-columns">
        <aside className="lp80-sidebar lp80-sidebar--left">
          <div className="lp80-sidebar__label">
            <Zap size={9} />Core Products
          </div>
          {MODULES.filter(m => (LEFT_IDS as readonly string[]).includes(m.id)).map(m => (
            <SideBtn
              key={m.id}
              mod={m}
              active={activeId === m.id}
              onClick={(e) => { setActiveId(m.id); handleGoToProduct(m.appTab, e); }}
              onHover={() => handleHover(m.id)}
              side="left"
            />
          ))}
        </aside>

        <div className="lp80-center">
          {/* Avatar */}
          <div className="lp163-split">
            <div className="lp163-split__avatar-col">
              <div
                className={`lp80-avatar-wrap${speaking ? ' lp80-avatar-wrap--speaking' : ''}`}
                style={{ '--lp80-ring': activeMod.accentColor } as React.CSSProperties}
              >
                <img
                  src={AIPPIE_CORE_LOGO}
                  alt="Aippie"
                  className={`lp80-avatar-img${speaking ? ' lp80-avatar-img--speaking' : ''}`}
                  draggable={false}
                  onError={e => {
                    (e.currentTarget as HTMLImageElement).src =
                      'https://images.pexels.com/photos/1858175/pexels-photo-1858175.jpeg?auto=compress&cs=tinysrgb&w=600&h=800&fit=crop&crop=faces';
                  }}
                />
                <div className="lp80-avatar-fade" />
                <LipSyncMouth active={speaking} color={activeMod.accentColor} />
                {speaking && (
                  <>
                    <span className="lp80-ring lp80-ring--1" style={{ borderColor: activeMod.accentColor + 'cc' }} />
                    <span className="lp80-ring lp80-ring--2" style={{ borderColor: activeMod.accentColor + '77' }} />
                    <span className="lp80-ring lp80-ring--3" style={{ borderColor: activeMod.accentColor + '33' }} />
                  </>
                )}
                <div className="lp80-live-pip">
                  <span className={`lp80-live-dot${speaking ? ' lp80-live-dot--pulse' : ''}`} style={{ background: speaking ? activeMod.accentColor : '#475569' }} />
                  <Lock size={7} /><span>E2EE</span>
                  <span className="lp80-pip-sep">·</span>
                  <Radio size={7} /><span>LIVE</span>
                </div>
              </div>
              <div className="lp80-wave-row">
                {speaking && <Mic size={11} style={{ color: activeMod.accentColor, flexShrink: 0 }} />}
                <Waveform active={speaking} color={activeMod.accentColor} />
                {speaking && <span className="lp80-wave-live" style={{ color: activeMod.accentColor }}>Live</span>}
              </div>
              <div className={`lp80-subtitle${speaking && subtitle ? ' lp80-subtitle--active' : ''}`}>
                <span>{speaking && subtitle ? subtitle : '\u00A0'}</span>
              </div>
              <button
                className="lp80-did-btn"
                onClick={() => window.open('https://studio.d-id.com/share?id=05a847891293dbaa81a30f3079afb0ae&utm_source=copy', '_blank', 'width=420,height=620,resizable=yes,scrollbars=yes')}
              >
                <span className="lp80-did-btn__dot" />
                TALK TO AIPPIE LIVE
              </button>
            </div>
            <div key={`cinema-${activeMod.id}`} className="lp163-split__cinema-col lp203-fade-in">
              <DemoCinema sceneId={activeId} accentColor={activeMod.accentColor} />
              {/* ── Platform Ad Banner — rotates every 3s ── */}
              <PlatformAdBanner
                accentColor={activeMod.accentColor}
                onPlaceAd={() => setAdModalOpen(true)}
              />
            </div>
          </div>

          {/* All products button */}
          <button
            className="lp80-all-products-btn"
            onClick={() => {
              const allIds = [...(LEFT_IDS as readonly string[]), ...(RIGHT_IDS as readonly string[]), CENTER_ID];
              const next = allIds[(allIds.indexOf(activeId) + 1) % allIds.length];
              handleSelect(next);
            }}
            style={{ borderColor: activeMod.accentColor + '44', color: activeMod.accentColor }}
          >
            <Zap size={11} />
            View all {MODULES.length + 1} products
            <ChevronRight size={11} />
          </button>

          <div className="lp80-footer">
            <Building2 size={8} />
            AIPPIETAX S.A. · v214 · All rights reserved
          </div>
        </div>
      </div>

      {/* ── Aippie Score Tool ── */}
      <div className="lp-score-section">
        <AippieScoreWidget onNavigate={(tab) => { onNavigateRef.current?.(tab); }} />
      </div>

      {/* ── Platform ad submission modal ── */}
      {adModalOpen && (
        <PlatformAdSubmitView user={user ?? null} onClose={() => setAdModalOpen(false)} />
      )}
    </div>
  );
}
