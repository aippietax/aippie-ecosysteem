import { useState, useEffect, useRef } from 'react';
import { Flame, Activity, Shield, BatteryCharging, Cpu, Zap, RefreshCw } from 'lucide-react';

// ── Inline matrix canvas (self-contained, does not conflict with root MatrixCodeBackground) ──
const MATRIX_STRINGS = [
  'CIPHER.AES_256_GCM;','ECDH.P256.handshake();','TLS_1.3.established;',
  'SELECT * FROM logs;','WHERE risk > 0.9;','jwt.sign({id,exp});',
  'bcrypt.hash(pw, 12);','monitor.start(5000);','auth.mfa.verify();',
  'token.refresh(3600);','// uptime: 99.98%','// threats blocked: 0',
  'vault.seal(keyPair);','session.encrypt();','rsa.sign(payload);',
  'hmac.verify(sig);','p2p.handshake();','block.finalize();',
  'function decrypt(k) {','  const h = SHA256(k);','  return AES.init(h);',
  '}','class AippieShield {','  async scan() {',
  '    if (threat > 0.85) {','      this.block();','    }','  }','}',
];
const NEON = ['#FF3B30','#FF9500','#007AFF','#AF52DE','#34C759'];

function hexRgb(hex: string) {
  const r = parseInt(hex.slice(1,3),16), g = parseInt(hex.slice(3,5),16), b = parseInt(hex.slice(5,7),16);
  return `${r},${g},${b}`;
}

function PulseMatrixBg() {
  const ref = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const canvas = ref.current; if (!canvas) return;
    const ctx = canvas.getContext('2d'); if (!ctx) return;
    let id: number;
    type Col = { x:number; y:number; speed:number; text:string; color:string; opacity:number };
    let cols: Col[] = [];
    const init = () => {
      const w = 40, total = Math.floor(canvas.width / w);
      cols = Array.from({ length: total }, (_,i) => ({
        x: i * w, y: canvas.height + Math.random() * canvas.height,
        speed: -(0.6 + Math.random() * 1.2),
        text: MATRIX_STRINGS[Math.floor(Math.random() * MATRIX_STRINGS.length)],
        color: NEON[Math.floor(Math.random() * NEON.length)],
        opacity: 0.15 + Math.random() * 0.20,
      }));
    };
    const resize = () => { canvas.width = window.innerWidth; canvas.height = window.innerHeight; init(); };
    const draw = () => {
      ctx.fillStyle = '#020617'; ctx.fillRect(0, 0, canvas.width, canvas.height);
      ctx.font = '600 13px monospace';
      for (const c of cols) {
        ctx.fillStyle = `rgba(${hexRgb(c.color)},${c.opacity})`;
        ctx.fillText(c.text, c.x, c.y);
        c.y += c.speed;
        if (c.y < -50) { c.y = canvas.height + Math.random()*150; c.text = MATRIX_STRINGS[Math.floor(Math.random()*MATRIX_STRINGS.length)]; c.color = NEON[Math.floor(Math.random()*NEON.length)]; c.opacity = 0.15+Math.random()*0.20; }
      }
      id = requestAnimationFrame(draw);
    };
    window.addEventListener('resize', resize); resize(); draw();
    return () => { window.removeEventListener('resize', resize); cancelAnimationFrame(id); };
  }, []);
  return <canvas ref={ref} aria-hidden="true" className="fixed inset-0 pointer-events-none -z-50" />;
}

// ── Stat card ───────────────────────────────────────────────────────────────
function StatCard({ label, value, color }: { label: string; value: string; color: string }) {
  return (
    <div className="flex justify-between items-center bg-slate-950/70 px-3 py-2.5 rounded-xl border border-slate-800/60">
      <span className="text-xs text-slate-400">{label}</span>
      <span className="text-xs font-bold font-mono" style={{ color }}>{value}</span>
    </div>
  );
}

// ── Main component ───────────────────────────────────────────────────────────
export default function AippiePowerPulse() {
  const [active, setActive]           = useState(true);
  const [handContact, setHandContact] = useState(true);

  const [bodyHeat, setBodyHeat]       = useState(6.8);         // mW
  const [ambient, setAmbient]         = useState(14.5);        // µW/cm²
  const [coreTemp, setCoreTemp]       = useState(24.5);        // °C

  const [drained, setDrained]         = useState(345);         // mW saved
  const [pulseHz, setPulseHz]         = useState(62);          // Hz

  const [totalMw, setTotalMw]         = useState(1420);
  const [ecoCredits, setEcoCredits]   = useState(512.4550);
  const [battBoost, setBattBoost]     = useState(0.0650);      // hours

  // ── Session hydration ────────────────────────────────────────────────────
  useEffect(() => {
    try {
      const raw = localStorage.getItem('aippie_ai_account_secure_state_v1');
      if (!raw) return;
      const s = JSON.parse(raw);
      if (s.pulse_ecoCredits)  setEcoCredits(s.pulse_ecoCredits);
      if (s.pulse_totalMw)     setTotalMw(s.pulse_totalMw);
      if (s.pulse_battBoost)   setBattBoost(s.pulse_battBoost);
      if (s.pulse_active !== undefined) setActive(s.pulse_active);
    } catch { /* noop */ }
  }, []);

  useEffect(() => {
    try {
      const raw = localStorage.getItem('aippie_ai_account_secure_state_v1');
      const base = raw ? JSON.parse(raw) : {};
      localStorage.setItem('aippie_ai_account_secure_state_v1', JSON.stringify({
        ...base, pulse_ecoCredits: ecoCredits, pulse_totalMw: totalMw,
        pulse_battBoost: battBoost, pulse_active: active, timestamp: Date.now(),
      }));
    } catch { /* noop */ }
  }, [ecoCredits, totalMw, battBoost, active]);

  // ── Live simulation loop ─────────────────────────────────────────────────
  useEffect(() => {
    if (!active) return;
    const id = setInterval(() => {
      if (handContact) {
        setBodyHeat(p => +Math.max(5.0, Math.min(12.0, p + (Math.random()*1.6-0.8))).toFixed(2));
        setAmbient(p => +Math.max(8.0, Math.min(22.0, p + (Math.random()*4-2))).toFixed(1));
        setCoreTemp(p => +Math.min(34.6, p + 0.1).toFixed(1));
        setDrained(p => Math.max(300, Math.min(410, p + Math.round(Math.random()*14-7))));
        setPulseHz(p => Math.max(55, Math.min(68, p + Math.round(Math.random()*4-2))));
        const yield_ = (bodyHeat / 1000) + (drained / 1000);
        setTotalMw(p => p + Math.round(yield_ * 100));
        setEcoCredits(p => +(p + yield_ / 100).toFixed(4));
        setBattBoost(p => +(p + 0.0007).toFixed(4));
      } else {
        setCoreTemp(p => +Math.max(21.5, p - 0.2).toFixed(1));
        setBodyHeat(0); setAmbient(3.2); setDrained(0); setPulseHz(0);
      }
    }, 1000);
    return () => clearInterval(id);
  }, [active, handContact, bodyHeat, drained]);

  const statusColor = active && handContact ? '#34C759' : '#FF3B30';

  return (
    <div className="min-h-screen bg-[#020617] text-slate-100 flex flex-col items-center justify-center p-4 md:p-8 font-mono selection:bg-[#34C759]/20 relative">
      <PulseMatrixBg />

      <div className="w-full max-w-lg z-10 flex flex-col gap-4">

        {/* ── Header ── */}
        <div className="bg-slate-950/80 border-2 border-[#34C759]/60 rounded-2xl p-4 backdrop-blur-xl shadow-[0_0_40px_rgba(52,199,89,0.12)] flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Activity className="w-5 h-5 text-[#34C759] animate-pulse" />
            <div>
            <span className="text-sm font-black tracking-widest text-transparent bg-clip-text bg-gradient-to-r from-[#34C759] to-[#007AFF] uppercase">AIPPIE POWER PULSE™</span>
              <p className="text-[9px] text-slate-500 tracking-widest">AMBIENT ENERGY RECOVERY ENGINE</p>
            </div>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full animate-pulse" style={{ backgroundColor: statusColor }} />
            <span className="text-[9px] font-bold text-slate-400 uppercase tracking-wider">
              {active && handContact ? 'PULSE ACTIVE' : active ? 'STANDBY' : 'LOOP IDLE'}
            </span>
          </div>
        </div>

        {/* ── Fase 1: Thermal & Ambient Input ── */}
        <div className="bg-slate-950/70 border border-slate-800/60 rounded-2xl p-4 backdrop-blur-xl">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <Flame className="w-4 h-4 text-[#FF3B30]" />
              <span className="text-xs font-bold text-slate-200 uppercase tracking-wider">1. Energie-Absorptie</span>
            </div>
            <span className="text-[9px] text-[#FF3B30] bg-[#FF3B30]/10 border border-[#FF3B30]/20 px-2 py-0.5 rounded font-bold">THERMAL INPUT</span>
          </div>
          <div className="flex flex-col gap-2">
            <StatCard label="Menselijke Lichaamswarmte" value={`+${bodyHeat.toFixed(2)} mW`} color="#FF3B30" />
            <StatCard label="Ambient RF Signaalsterkte" value={`${ambient.toFixed(1)} µW/cm²`} color="#FF9500" />
            <StatCard label="Telefoon Kerntemperatuur" value={`${coreTemp.toFixed(1)} °C`} color="#007AFF" />
          </div>
        </div>

        {/* ── Fase 2: Digital Throttle Buffer ── */}
        <div className="bg-slate-950/70 border border-slate-800/60 rounded-2xl p-4 backdrop-blur-xl">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <Cpu className="w-4 h-4 text-[#AF52DE]" />
              <span className="text-xs font-bold text-slate-200 uppercase tracking-wider">2. Digitale Throttle Buffer</span>
            </div>
            <span className="text-[9px] text-[#AF52DE] bg-[#AF52DE]/10 border border-[#AF52DE]/20 px-2 py-0.5 rounded font-bold">OPTIMIZER</span>
          </div>
          <div className="flex flex-col gap-2">
            <StatCard label="Geblokkeerde App-stroom" value={`${drained} mW bespaard`} color="#AF52DE" />
            <StatCard label="Actieve Pulsfrequentie" value={`${pulseHz} Hz`} color="#34C759" />
          </div>
        </div>

        {/* ── Fase 3: Eco Vault ── */}
        <div className="bg-slate-950/70 border-2 border-[#34C759]/40 rounded-2xl p-4 backdrop-blur-xl shadow-[0_0_30px_rgba(52,199,89,0.08)]">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <BatteryCharging className="w-4 h-4 text-[#34C759]" />
              <span className="text-xs font-bold text-slate-200 uppercase tracking-wider">3. Energie Vault</span>
            </div>
            <span className="text-[9px] text-[#34C759] bg-[#34C759]/10 border border-[#34C759]/20 px-2 py-0.5 rounded font-bold">SECURE LEDGER</span>
          </div>
          <div className="flex flex-col gap-2">
            <StatCard label="Totaal Teruggewonnen" value={`${totalMw.toLocaleString()} mW`} color="#34C759" />
            <StatCard label="Aippie Eco-Credits (AEC)" value={ecoCredits.toFixed(4)} color="#FF9500" />
            <StatCard label="Batterijverlenging" value={`+${battBoost.toFixed(4)} uur`} color="#007AFF" />
          </div>
        </div>

        {/* ── Security Shield Status ── */}
        <div className="bg-slate-950/70 border border-slate-800/60 rounded-2xl p-4 backdrop-blur-xl">
          <div className="flex items-center gap-2 mb-3">
            <Shield className="w-4 h-4 text-[#007AFF]" />
            <span className="text-xs font-bold text-slate-200 uppercase tracking-wider">AippieShield Status</span>
          </div>
          <div className="flex flex-col gap-2">
            <StatCard label="Bedreigingen Geblokkeerd" value="0" color="#34C759" />
            <StatCard label="Systeem Uptime" value="99.98%" color="#34C759" />
            <StatCard label="Encryptie" value="AES-256-GCM / TLS 1.3" color="#007AFF" />
          </div>
        </div>

        {/* ── Control Panel ── */}
        <div className="bg-slate-950/70 border border-slate-800/60 rounded-2xl p-4 backdrop-blur-xl">
          <div className="flex items-center gap-2 mb-4">
            <Zap className="w-4 h-4 text-[#FF9500]" />
            <span className="text-xs font-bold text-slate-200 uppercase tracking-wider">Systeem Controle</span>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <button
              onClick={() => setActive(p => !p)}
              className={`flex items-center justify-center gap-2 px-4 py-3 rounded-xl border text-xs font-bold uppercase tracking-wider transition-all duration-200 ${
                active
                  ? 'bg-[#34C759]/10 border-[#34C759]/50 text-[#34C759]'
                  : 'bg-[#FF3B30]/10 border-[#FF3B30]/50 text-[#FF3B30]'
              }`}
            >
              <Activity className="w-3.5 h-3.5" />
              {active ? 'Systeem AAN' : 'Systeem UIT'}
            </button>
            <button
              onClick={() => setHandContact(p => !p)}
              className={`flex items-center justify-center gap-2 px-4 py-3 rounded-xl border text-xs font-bold uppercase tracking-wider transition-all duration-200 ${
                handContact
                  ? 'bg-[#FF9500]/10 border-[#FF9500]/50 text-[#FF9500]'
                  : 'bg-slate-800/40 border-slate-700/50 text-slate-500'
              }`}
            >
              <Flame className="w-3.5 h-3.5" />
              {handContact ? 'Hand: AAN' : 'Hand: UIT'}
            </button>
          </div>
          <button
            onClick={() => { setTotalMw(0); setEcoCredits(0); setBattBoost(0); setBodyHeat(6.8); setAmbient(14.5); setCoreTemp(24.5); setDrained(345); setPulseHz(62); }}
            className="mt-3 w-full flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl border border-slate-700/50 text-xs font-bold text-slate-400 hover:text-slate-200 hover:border-slate-600 transition-all duration-200"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            Reset Vault
          </button>
        </div>

      </div>
    </div>
  );
}
