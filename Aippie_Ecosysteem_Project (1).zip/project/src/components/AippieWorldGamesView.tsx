import { useCallback, useEffect, useRef, useState } from 'react';
import { X, Coins, Star, Brain, Trophy, Heart, RefreshCw, Clock, CheckCircle, XCircle, Zap } from 'lucide-react';
import { supabase } from '../lib/supabase';

// ── Types ─────────────────────────────────────────────────────────────────────
type GameId = 'catcher' | 'memory' | 'quiz' | 'snake' | 'slots';
type GamePhase = 'menu' | 'playing' | 'result';

interface Props { onClose: () => void; onApcEarned: (n: number) => void; }

// ── Quiz data ─────────────────────────────────────────────────────────────────
const ALL_QUESTIONS = [
  { q: 'What is an APC coin?', opts: ['Aippie Platform Coin','Advanced Protocol Currency','Automated Payment Code','Application Program Core'], a: 0 },
  { q: 'How many zones does the Aippie Virtual World have?', opts: ['4','5','6','8'], a: 2 },
  { q: 'What does E2EE mean?', opts: ['End-to-End Encryption','Extra Enhanced Exchange','Electronic Engine','Extended Edge Endpoint'], a: 0 },
  { q: 'Which protocol does Bitcoin use?', opts: ['Proof of Stake','Proof of Work','Proof of Authority','Proof of History'], a: 1 },
  { q: 'What is the AI assistant in the Aippie World?', opts: ['AIPPIE GUIDE','SOFIA AI','AIPPIE ORACLE','WORLD MASTER'], a: 2 },
  { q: 'How many APC maximum per daily wheel?', opts: ['25','50','100','10'], a: 1 },
  { q: 'What does AippieShield do?', opts: ['Speeds up network','Encrypts communication','Manages wallet','Controls notifications'], a: 1 },
  { q: 'What is DeFi?', opts: ['Digital Finance','Decentralized Finance','Distributed Fiat','Dynamic Funding'], a: 1 },
  { q: 'Which icon does the Live Stage zone have?', opts: ['🎭','🎵','🎬','🎪'], a: 0 },
  { q: 'What does a smart contract do?', opts: ['Smart paper document','Self-executing blockchain code','AI-generated contract','Encrypted document'], a: 1 },
  { q: 'How do you earn APC in the Virtual World?', opts: ['Only buy','Present + games + wheel','Only via quiz','Only via shop'], a: 1 },
  { q: 'What is Ethereum?', opts: ['A coin', 'A blockchain platform','A wallet app','An exchange'], a: 1 },
  { q: 'Which zone is for documents?', opts: ['Aippie Plaza','Trading Floor','Business Tower','Secure Vault'], a: 3 },
  { q: 'What is a blockchain?', opts: ['An encrypted file','A distributed ledger','A type of database','A network protocol'], a: 1 },
  { q: 'Which color does the Trading Floor zone have?', opts: ['Blue','Green','Gold','Pink'], a: 1 },
];

const MEMORY_PAIRS = ['⬡','📈','🏢','📚','🎭','🔒'];

// ── Helper ────────────────────────────────────────────────────────────────────
async function creditApc(amount: number) {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return;
  await supabase.from('apc_wallets').upsert({ user_id: user.id, balance_apc: amount }, { onConflict: 'user_id' });
  await supabase.from('world_presence_log').insert({ user_id: user.id, zone_id: 'game_reward', apc_earned: amount });
}

// ══════════════════════════════════════════════════════════════════════════════
//  Main component
// ══════════════════════════════════════════════════════════════════════════════
export default function AippieWorldGamesView({ onClose, onApcEarned }: Props) {
  const [game, setGame] = useState<GameId>('catcher');

  const switchGame = (g: GameId) => setGame(g);

  return (
    <div className="wg-overlay" onClick={onClose}>
      <div className="wg-modal" onClick={e => e.stopPropagation()}>
        {/* Header */}
        <div className="wg-header">
          <div className="wg-header__left">
            <span className="wg-header__icon">🎮</span>
            <span className="wg-header__title">Aippie Games</span>
            <span className="wg-header__sub">Earn APC by playing</span>
          </div>
          <button className="wg-close" onClick={onClose}><X size={16}/></button>
        </div>

        {/* Game tabs */}
        <div className="wg-tabs wg-tabs--scroll">
          <button className={`wg-tab${game==='catcher'?' wg-tab--active':''}`} onClick={()=>switchGame('catcher')}>
            <Coins size={11}/> Catcher
          </button>
          <button className={`wg-tab${game==='memory'?' wg-tab--active':''}`} onClick={()=>switchGame('memory')}>
            <Star size={11}/> Memory
          </button>
          <button className={`wg-tab${game==='quiz'?' wg-tab--active':''}`} onClick={()=>switchGame('quiz')}>
            <Brain size={11}/> Quiz
          </button>
          <button className={`wg-tab${game==='snake'?' wg-tab--active':''}`} onClick={()=>switchGame('snake')}>
            🐍 Snake
          </button>
          <button className={`wg-tab${game==='slots'?' wg-tab--active':''}`} onClick={()=>switchGame('slots')}>
            🎰 Slots
          </button>
        </div>

        {/* Active game */}
        <div className="wg-game-area">
          {game === 'catcher' && <CoinCatcher onEarn={async n=>{onApcEarned(n);await creditApc(n);}}/>}
          {game === 'memory'  && <MemoryMatch  onEarn={async n=>{onApcEarned(n);await creditApc(n);}}/>}
          {game === 'quiz'    && <DailyQuiz    onEarn={async n=>{onApcEarned(n);await creditApc(n);}}/>}
          {game === 'snake'   && <SnakeGame    onEarn={async n=>{onApcEarned(n);await creditApc(n);}}/>}
          {game === 'slots'   && <SlotsGame    onEarn={async n=>{onApcEarned(n);await creditApc(n);}} onSpend={n=>onApcEarned(-n)}/>}
        </div>
      </div>
    </div>
  );
}

// ══════════════════════════════════════════════════════════════════════════════
//  GAME 1 — Coin Catcher (canvas)
// ══════════════════════════════════════════════════════════════════════════════
interface CatcherItem { id:number; x:number; y:number; type:'coin'|'gem'|'bomb'; size:number; }

function CoinCatcher({ onEarn }: { onEarn:(n:number)=>void }) {
  const canvasRef  = useRef<HTMLCanvasElement>(null);
  const rafRef     = useRef(0);
  const stateRef   = useRef({
    phase: 'menu' as GamePhase,
    player: 180, score: 0, lives: 3,
    items: [] as CatcherItem[], tick: 0, speed: 2, nextId: 0, timeLeft: 60,
  });
  const keysRef = useRef({ left: false, right: false });
  const [phase, setPhase] = useState<GamePhase>('menu');
  const [score, setScore] = useState(0);
  const [lives, setLives] = useState(3);
  const [timeLeft, setTimeLeft] = useState(60);

  const startGame = useCallback(() => {
    stateRef.current = { phase:'playing', player:180, score:0, lives:3, items:[], tick:0, speed:2, nextId:0, timeLeft:60 };
    setPhase('playing'); setScore(0); setLives(3); setTimeLeft(60);
  }, []);

  useEffect(() => {
    const dn = (e:KeyboardEvent) => {
      if (e.key==='ArrowLeft'||e.key==='a') keysRef.current.left=true;
      if (e.key==='ArrowRight'||e.key==='d') keysRef.current.right=true;
    };
    const up = (e:KeyboardEvent) => {
      if (e.key==='ArrowLeft'||e.key==='a') keysRef.current.left=false;
      if (e.key==='ArrowRight'||e.key==='d') keysRef.current.right=false;
    };
    window.addEventListener('keydown', dn); window.addEventListener('keyup', up);
    return () => { window.removeEventListener('keydown', dn); window.removeEventListener('keyup', up); };
  }, []);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d')!;
    const W = canvas.width, H = canvas.height;
    let lastSec = performance.now();

    const loop = (now: number) => {
      const st = stateRef.current;
      st.tick++;

      // Timer
      if (st.phase==='playing' && now - lastSec >= 1000) {
        lastSec = now;
        st.timeLeft = Math.max(0, st.timeLeft - 1);
        setTimeLeft(st.timeLeft);
        if (st.timeLeft === 0) { st.phase='result'; setPhase('result'); onEarn(Math.max(0, st.score)); return; }
      }

      if (st.phase !== 'playing') { rafRef.current=requestAnimationFrame(loop); return; }

      // Move player
      const SPEED = 6;
      if (keysRef.current.left)  st.player = Math.max(30,  st.player - SPEED);
      if (keysRef.current.right) st.player = Math.min(W-30, st.player + SPEED);

      // Spawn items
      const spawnRate = Math.max(18, 40 - Math.floor(st.tick/120));
      if (st.tick % spawnRate === 0) {
        const roll = Math.random();
        const type: CatcherItem['type'] = roll < 0.55 ? 'coin' : roll < 0.80 ? 'gem' : 'bomb';
        st.items.push({ id: st.nextId++, x: 20 + Math.random()*(W-40), y: -20, type, size: type==='gem'?22:18 });
      }

      // Increase speed
      st.speed = 2 + (60 - st.timeLeft) * 0.05;

      // Move items
      st.items = st.items.map(i => ({ ...i, y: i.y + st.speed }));

      // Collision
      const PW = 60, PH = 12, PY = H - 24;
      const toRemove = new Set<number>();
      st.items.forEach(i => {
        if (i.y + i.size/2 >= PY && i.y - i.size/2 <= PY+PH &&
            i.x >= st.player-PW/2 && i.x <= st.player+PW/2) {
          toRemove.add(i.id);
          if (i.type==='coin') { st.score += 1; }
          if (i.type==='gem')  { st.score += 5; }
          if (i.type==='bomb') {
            st.lives = Math.max(0, st.lives-1);
            setLives(st.lives);
            if (st.lives===0) { st.phase='result'; setPhase('result'); onEarn(Math.max(0,st.score)); return; }
          }
        }
        if (i.y > H + 20) toRemove.add(i.id);
      });
      st.items = st.items.filter(i => !toRemove.has(i.id));
      setScore(st.score);

      // Draw
      // Background
      ctx.fillStyle='#020810'; ctx.fillRect(0,0,W,H);

      // Grid lines
      ctx.strokeStyle='rgba(56,189,248,0.06)'; ctx.lineWidth=1;
      for(let x=0;x<W;x+=40){ctx.beginPath();ctx.moveTo(x,0);ctx.lineTo(x,H);ctx.stroke();}
      for(let y=0;y<H;y+=40){ctx.beginPath();ctx.moveTo(0,y);ctx.lineTo(W,y);ctx.stroke();}

      // Items
      st.items.forEach(i => {
        ctx.font = `${i.size}px sans-serif`;
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        if (i.type==='coin') {
          ctx.shadowColor='#fcd34d'; ctx.shadowBlur=8;
        } else if (i.type==='gem') {
          ctx.shadowColor='#38bdf8'; ctx.shadowBlur=10;
        } else {
          ctx.shadowColor='#ef4444'; ctx.shadowBlur=8;
        }
        ctx.fillText(i.type==='coin'?'🪙':i.type==='gem'?'💎':'💣', i.x, i.y);
        ctx.shadowBlur=0;
      });

      // Player platform
      const grd = ctx.createLinearGradient(st.player-PW/2, PY, st.player+PW/2, PY+PH);
      grd.addColorStop(0,'#38bdf8'); grd.addColorStop(0.5,'#7dd3fc'); grd.addColorStop(1,'#38bdf8');
      ctx.shadowColor='#38bdf8'; ctx.shadowBlur=12;
      ctx.fillStyle=grd;
      ctx.beginPath(); ctx.roundRect(st.player-PW/2, PY, PW, PH, 6); ctx.fill();
      ctx.shadowBlur=0;

      // Score display
      ctx.fillStyle='rgba(2,8,24,0.7)';
      ctx.beginPath(); ctx.roundRect(8,8,90,28,6); ctx.fill();
      ctx.fillStyle='#fcd34d'; ctx.font='bold 11px monospace'; ctx.textAlign='left'; ctx.textBaseline='middle';
      ctx.fillText(`🪙 ${st.score} APC`, 14, 22);

      ctx.textAlign='left'; ctx.textBaseline='alphabetic';
      rafRef.current = requestAnimationFrame(loop);
    };

    rafRef.current = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(rafRef.current);
  }, [onEarn]);

  const earned = Math.max(0, stateRef.current.score);

  return (
    <div className="wg-catcher">
      <canvas ref={canvasRef} width={400} height={280} className="wg-canvas" />
      <div className="wg-catcher__hud">
        <div className="wg-hud-stat"><Heart size={12} style={{color:'#ef4444'}}/><span>{lives}</span></div>
        <div className="wg-hud-stat"><Clock size={12} style={{color:'#94a3b8'}}/><span>{timeLeft}s</span></div>
        <div className="wg-hud-stat"><Coins size={12} style={{color:'#fcd34d'}}/><span>{score} APC</span></div>
      </div>

      {phase==='menu' && (
        <div className="wg-overlay-msg">
          <div className="wg-overlay-msg__title">Coin Catcher</div>
          <p>Catch coins 🪙 (+1) and jewels 💎 (+5).<br/>Avoid bombs 💣. Move with ← → or A/D.</p>
          <p className="wg-overlay-msg__sub">60 seconds. Earn your score in APC!</p>
          <button className="wg-play-btn" onClick={startGame}>Play!</button>
        </div>
      )}

      {phase==='result' && (
        <div className="wg-overlay-msg">
          <Trophy size={32} style={{color:'#fcd34d'}}/>
          <div className="wg-overlay-msg__title">Score: {score}</div>
          <div className="wg-result-earn"><Coins size={16} style={{color:'#fcd34d'}}/> +{earned} APC earned!</div>
          <button className="wg-play-btn" onClick={startGame}><RefreshCw size={13}/> Again</button>
        </div>
      )}

      {phase==='menu' || phase==='result' ? null : (
        <div className="wg-mobile-btns">
          <button className="wg-move-btn"
            onPointerDown={()=>keysRef.current.left=true}
            onPointerUp={()=>keysRef.current.left=false}
            onPointerLeave={()=>keysRef.current.left=false}>◀</button>
          <button className="wg-move-btn"
            onPointerDown={()=>keysRef.current.right=true}
            onPointerUp={()=>keysRef.current.right=false}
            onPointerLeave={()=>keysRef.current.right=false}>▶</button>
        </div>
      )}
    </div>
  );
}

// ══════════════════════════════════════════════════════════════════════════════
//  GAME 2 — Memory Match
// ══════════════════════════════════════════════════════════════════════════════
interface MemCard { id:number; icon:string; faceUp:boolean; matched:boolean; }

function MemoryMatch({ onEarn }: { onEarn:(n:number)=>void }) {
  const makeCards = (): MemCard[] =>
    [...MEMORY_PAIRS, ...MEMORY_PAIRS]
      .sort(()=>Math.random()-.5)
      .map((icon, id) => ({ id, icon, faceUp:false, matched:false }));

  const [cards, setCards]     = useState<MemCard[]>(makeCards);
  const [selected, setSelected] = useState<number[]>([]);
  const [moves, setMoves]     = useState(0);
  const [phase, setPhase]     = useState<GamePhase>('menu');
  const [elapsed, setElapsed] = useState(0);
  const [earned, setEarned]   = useState(0);
  const timerRef = useRef<ReturnType<typeof setInterval>|null>(null);
  const blockRef = useRef(false);

  const startGame = () => {
    setCards(makeCards()); setSelected([]); setMoves(0); setElapsed(0); setPhase('playing');
    timerRef.current = setInterval(() => setElapsed(e=>e+1), 1000);
  };

  // Flip logic
  const flip = useCallback((id: number) => {
    if (blockRef.current || phase!=='playing') return;
    setCards(prev => {
      const card = prev.find(c=>c.id===id);
      if (!card || card.faceUp || card.matched) return prev;
      return prev.map(c=>c.id===id?{...c,faceUp:true}:c);
    });
    setSelected(prev => {
      if (prev.includes(id)) return prev;
      return [...prev, id];
    });
  }, [phase]);

  // Check match when 2 selected
  useEffect(()=>{
    if (selected.length !== 2) return;
    blockRef.current = true;
    setMoves(m=>m+1);
    const [a,b] = selected;
    setCards(prev=>{
      const ca = prev.find(c=>c.id===a)!, cb = prev.find(c=>c.id===b)!;
      if (ca.icon===cb.icon) {
        // Match
        return prev.map(c=>c.id===a||c.id===b?{...c,matched:true,faceUp:true}:c);
      } else {
        // No match - flip back after delay
        setTimeout(()=>{
          setCards(p=>p.map(c=>c.id===a||c.id===b?{...c,faceUp:false}:c));
          blockRef.current=false;
        },900);
        return prev;
      }
    });
    setSelected([]);
    // Check all matched after a tick
    setTimeout(()=>{
      blockRef.current=false;
      setCards(prev=>{
        const allMatched=prev.every(c=>c.matched);
        if (allMatched) {
          clearInterval(timerRef.current!);
          setPhase('result');
        }
        return prev;
      });
    },950);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  },[selected]);

  // Calc earned on result
  useEffect(()=>{
    if (phase==='result'){
      const bonus = Math.max(0, 60 - elapsed);
      const reward = 15 + bonus;
      setEarned(reward);
      onEarn(reward);
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  },[phase]);

  // Cleanup timer
  useEffect(()=>()=>{if(timerRef.current)clearInterval(timerRef.current);},[]);

  const paired = cards.filter(c=>c.matched).length/2;

  return (
    <div className="wg-memory">
      {phase==='menu' && (
        <div className="wg-overlay-msg">
          <div className="wg-overlay-msg__title">Memory Match</div>
          <p>Find all 6 pairs of Aippie zone icons.<br/>Faster = more bonus APC!</p>
          <p className="wg-overlay-msg__sub">Base: 15 APC + time bonus</p>
          <button className="wg-play-btn" onClick={startGame}>Play!</button>
        </div>
      )}

      {phase==='result' && (
        <div className="wg-overlay-msg">
          <Trophy size={32} style={{color:'#fcd34d'}}/>
          <div className="wg-overlay-msg__title">Done in {elapsed}s!</div>
          <p style={{color:'#94a3b8',fontSize:12}}>{moves} moves · Time bonus: {Math.max(0,60-elapsed)} APC</p>
          <div className="wg-result-earn"><Coins size={16} style={{color:'#fcd34d'}}/> +{earned} APC earned!</div>
          <button className="wg-play-btn" onClick={startGame}><RefreshCw size={13}/> Again</button>
        </div>
      )}

      {phase==='playing' && (
        <>
          <div className="wg-memory__stats">
            <span><Clock size={11}/> {elapsed}s</span>
            <span>{paired}/6 pairs</span>
            <span>{moves} moves</span>
          </div>
          <div className="wg-memory__grid">
            {cards.map(card=>(
              <button key={card.id} className={`wg-mem-card${card.faceUp||card.matched?' wg-mem-card--up':''}${card.matched?' wg-mem-card--matched':''}`} onClick={()=>flip(card.id)}>
                <div className="wg-mem-card__inner">
                  <div className="wg-mem-card__back">?</div>
                  <div className="wg-mem-card__front">{card.icon}</div>
                </div>
              </button>
            ))}
          </div>
        </>
      )}
    </div>
  );
}

// ══════════════════════════════════════════════════════════════════════════════
//  GAME 3 — Daily Quiz
// ══════════════════════════════════════════════════════════════════════════════
function DailyQuiz({ onEarn }: { onEarn:(n:number)=>void }) {
  const today = new Date().toISOString().slice(0,10);
  const [usedToday, setUsedToday]   = useState(false);
  const [questions]                 = useState(()=>[...ALL_QUESTIONS].sort(()=>Math.random()-.5).slice(0,5));
  const [current, setCurrent]       = useState(0);
  const [answers, setAnswers]       = useState<(number|null)[]>(Array(5).fill(null));
  const [phase, setPhase]           = useState<GamePhase>('menu');
  const [earned, setEarned]         = useState(0);

  useEffect(()=>{
    const key = `aippie_quiz_${today}`;
    if (localStorage.getItem(key)) setUsedToday(true);
  },[today]);

  const answer = (opt: number) => {
    if (phase!=='playing') return;
    const newAnswers = [...answers]; newAnswers[current] = opt;
    setAnswers(newAnswers);
    if (current < 4) {
      setTimeout(()=>setCurrent(c=>c+1), 600);
    } else {
      // Done
      setTimeout(()=>{
        const correct = newAnswers.filter((a,i)=>a===questions[i].a).length;
        const reward = correct * 10;
        setEarned(reward);
        setPhase('result');
        onEarn(reward);
        localStorage.setItem(`aippie_quiz_${today}`, '1');
        setUsedToday(true);
      }, 700);
    }
  };

  const q = questions[current];
  const answered = answers[current];

  return (
    <div className="wg-quiz">
      {phase==='menu' && (
        <div className="wg-overlay-msg">
          <div className="wg-overlay-msg__title">Daily Quiz</div>
          <p>5 questions about Aippie, crypto and AI.<br/>Each correct answer = 10 APC!</p>
          <p className="wg-overlay-msg__sub">Maximum: 50 APC per day</p>
          {usedToday
            ? <p className="wg-used-msg">You already played the quiz today. Come back tomorrow!</p>
            : <button className="wg-play-btn" onClick={()=>setPhase('playing')}>Start!</button>
          }
        </div>
      )}

      {phase==='result' && (
        <div className="wg-quiz-result">
          <Trophy size={32} style={{color:'#fcd34d'}}/>
          <div className="wg-overlay-msg__title">{answers.filter((a,i)=>a===questions[i].a).length}/5 correct!</div>
          <div className="wg-result-earn"><Coins size={16} style={{color:'#fcd34d'}}/> +{earned} APC earned!</div>
          <div className="wg-quiz-answers">
            {questions.map((q,i)=>{
              const correct = answers[i]===q.a;
              return (
                <div key={i} className={`wg-quiz-ans${correct?' wg-quiz-ans--ok':' wg-quiz-ans--wrong'}`}>
                  {correct?<CheckCircle size={11}/>:<XCircle size={11}/>}
                  <span>{q.q.slice(0,40)}</span>
                  {!correct&&<span className="wg-quiz-ans__correct">→ {q.opts[q.a]}</span>}
                </div>
              );
            })}
          </div>
        </div>
      )}

      {phase==='playing' && (
        <div className="wg-quiz-play">
          <div className="wg-quiz-progress">
            {questions.map((_,i)=>(
              <div key={i} className={`wg-quiz-dot${i<current?' wg-quiz-dot--done':i===current?' wg-quiz-dot--active':''}`}/>
            ))}
          </div>
          <div className="wg-quiz-q">{q.q}</div>
          <div className="wg-quiz-opts">
            {q.opts.map((opt,i)=>{
              let cls = 'wg-quiz-opt';
              if (answered !== null) {
                if (i === q.a) cls += ' wg-quiz-opt--correct';
                else if (i === answered && answered !== q.a) cls += ' wg-quiz-opt--wrong';
                else cls += ' wg-quiz-opt--dim';
              }
              return (
                <button key={i} className={cls} onClick={()=>answer(i)} disabled={answered!==null}>
                  <span className="wg-quiz-opt__letter">{['A','B','C','D'][i]}</span>
                  {opt}
                </button>
              );
            })}
          </div>
          <div className="wg-quiz-counter">Question {current+1} of 5</div>
        </div>
      )}
    </div>
  );
}

// ══════════════════════════════════════════════════════════════════════════════
//  GAME 4 — Snake
// ══════════════════════════════════════════════════════════════════════════════
const COLS = 20, ROWS = 14, CELL = 20;
type Pt = { x: number; y: number };

function SnakeGame({ onEarn }: { onEarn:(n:number)=>void }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const rafRef    = useRef(0);
  const stateRef  = useRef({
    phase: 'menu' as GamePhase,
    snake: [{ x:10, y:7 },{ x:9, y:7 },{ x:8, y:7 }] as Pt[],
    dir: { x:1, y:0 } as Pt, nextDir: { x:1, y:0 } as Pt,
    food: { x:15, y:7 } as Pt,
    score: 0, tick: 0, speed: 8,
  });
  const [phase, setPhase]   = useState<GamePhase>('menu');
  const [score, setScore]   = useState(0);

  const spawnFood = (snake: Pt[]): Pt => {
    let f: Pt;
    do { f = { x: Math.floor(Math.random()*COLS), y: Math.floor(Math.random()*ROWS) }; }
    while (snake.some(s => s.x===f.x && s.y===f.y));
    return f;
  };

  const startGame = useCallback(() => {
    stateRef.current = {
      phase:'playing',
      snake:[{x:10,y:7},{x:9,y:7},{x:8,y:7}],
      dir:{x:1,y:0}, nextDir:{x:1,y:0},
      food:spawnFood([{x:10,y:7}]),
      score:0, tick:0, speed:8,
    };
    setPhase('playing'); setScore(0);
  }, []);

  useEffect(() => {
    const dn = (e: KeyboardEvent) => {
      const st = stateRef.current;
      if (e.key==='ArrowUp'    || e.key==='w') { if(st.dir.y!==1)  st.nextDir={x:0,y:-1}; }
      if (e.key==='ArrowDown'  || e.key==='s') { if(st.dir.y!==-1) st.nextDir={x:0,y:1};  }
      if (e.key==='ArrowLeft'  || e.key==='a') { if(st.dir.x!==1)  st.nextDir={x:-1,y:0}; }
      if (e.key==='ArrowRight' || e.key==='d') { if(st.dir.x!==-1) st.nextDir={x:1,y:0};  }
    };
    window.addEventListener('keydown', dn);
    return () => window.removeEventListener('keydown', dn);
  }, []);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d')!;
    const W = COLS*CELL, H = ROWS*CELL;

    const loop = () => {
      const st = stateRef.current;
      st.tick++;
      if (st.phase === 'playing') {
        if (st.tick % st.speed === 0) {
          st.dir = { ...st.nextDir };
          const head = { x: (st.snake[0].x+st.dir.x+COLS)%COLS, y: (st.snake[0].y+st.dir.y+ROWS)%ROWS };
          // Self collision
          if (st.snake.some(s=>s.x===head.x&&s.y===head.y)) {
            st.phase = 'result'; setPhase('result'); onEarn(st.score*2);
            rafRef.current=requestAnimationFrame(loop); return;
          }
          const ate = head.x===st.food.x && head.y===st.food.y;
          st.snake = [head, ...st.snake.slice(0, ate ? undefined : -1)];
          if (ate) {
            st.score++;
            st.food = spawnFood(st.snake);
            st.speed = Math.max(4, 8 - Math.floor(st.score/5));
            setScore(st.score);
          }
        }
      }

      // Draw
      ctx.fillStyle='#020810'; ctx.fillRect(0,0,W,H);
      // Grid
      ctx.strokeStyle='rgba(56,189,248,0.05)'; ctx.lineWidth=0.5;
      for(let x=0;x<=W;x+=CELL){ctx.beginPath();ctx.moveTo(x,0);ctx.lineTo(x,H);ctx.stroke();}
      for(let y=0;y<=H;y+=CELL){ctx.beginPath();ctx.moveTo(0,y);ctx.lineTo(W,y);ctx.stroke();}

      // Food
      ctx.shadowColor='#fcd34d'; ctx.shadowBlur=12;
      ctx.font=`${CELL-2}px sans-serif`; ctx.textAlign='center'; ctx.textBaseline='middle';
      ctx.fillText('🪙', st.food.x*CELL+CELL/2, st.food.y*CELL+CELL/2);
      ctx.shadowBlur=0;

      // Snake
      st.snake.forEach((s,i)=>{
        const t = i/st.snake.length;
        const r = Math.floor(56 + (1-t)*120), g = Math.floor(189 - t*100), b = Math.floor(248 - t*60);
        ctx.fillStyle=`rgb(${r},${g},${b})`;
        ctx.shadowColor=`rgb(${r},${g},${b})`; ctx.shadowBlur=i===0?8:2;
        ctx.beginPath(); ctx.roundRect(s.x*CELL+2, s.y*CELL+2, CELL-4, CELL-4, 4); ctx.fill();
        ctx.shadowBlur=0;
        if (i===0) {
          ctx.fillStyle='#fff'; ctx.font='bold 9px monospace';
          ctx.fillText('▶', s.x*CELL+CELL/2, s.y*CELL+CELL/2);
        }
      });

      // Score
      ctx.fillStyle='rgba(2,8,24,.8)'; ctx.beginPath(); ctx.roundRect(6,6,100,24,5); ctx.fill();
      ctx.fillStyle='#fcd34d'; ctx.font='bold 11px monospace'; ctx.textAlign='left'; ctx.textBaseline='middle';
      ctx.fillText(`🐍 ${st.score} × 2 APC`, 12, 18);
      ctx.textAlign='left'; ctx.textBaseline='alphabetic';

      rafRef.current=requestAnimationFrame(loop);
    };
    rafRef.current=requestAnimationFrame(loop);
    return ()=>cancelAnimationFrame(rafRef.current);
  }, [onEarn]);

  const dir = (dx:number,dy:number) => {
    const st = stateRef.current;
    if(dx===0&&st.dir.y!==dy*-1) st.nextDir={x:0,y:dy};
    if(dy===0&&st.dir.x!==dx*-1) st.nextDir={x:dx,y:0};
  };

  return (
    <div className="wg-catcher">
      <canvas ref={canvasRef} width={COLS*CELL} height={ROWS*CELL} className="wg-canvas"/>
      <div className="wg-catcher__hud">
        <div className="wg-hud-stat"><Coins size={12} style={{color:'#fcd34d'}}/><span>{score*2} APC</span></div>
        <div className="wg-hud-stat" style={{color:'#64748b',fontSize:10}}>Eat 🪙 = +2 APC · Higher score = faster</div>
      </div>
      {phase==='menu' && (
        <div className="wg-overlay-msg">
          <div className="wg-overlay-msg__title">🐍 Snake</div>
          <p>Move with arrow keys or WASD.<br/>Eat coins 🪙 to grow and earn APC.</p>
          <p className="wg-overlay-msg__sub">Each coin = 2 APC · No walls, but self-collision!</p>
          <button className="wg-play-btn" onClick={startGame}>Play!</button>
        </div>
      )}
      {phase==='result'&&(
        <div className="wg-overlay-msg">
          <Trophy size={32} style={{color:'#fcd34d'}}/>
          <div className="wg-overlay-msg__title">Score: {score}</div>
          <div className="wg-result-earn"><Coins size={16} style={{color:'#fcd34d'}}/> +{score*2} APC earned!</div>
          <button className="wg-play-btn" onClick={startGame}><RefreshCw size={13}/> Again</button>
        </div>
      )}
      {phase==='playing'&&(
        <div className="wg-snake-dpad">
          <button className="wg-dpad-btn" style={{gridColumn:2}} onPointerDown={()=>dir(0,-1)}>▲</button>
          <button className="wg-dpad-btn" style={{gridColumn:1,gridRow:2}} onPointerDown={()=>dir(-1,0)}>◀</button>
          <button className="wg-dpad-btn" style={{gridColumn:2,gridRow:2,background:'rgba(56,189,248,.1)'}} onClick={()=>{}}>·</button>
          <button className="wg-dpad-btn" style={{gridColumn:3,gridRow:2}} onPointerDown={()=>dir(1,0)}>▶</button>
          <button className="wg-dpad-btn" style={{gridColumn:2,gridRow:3}} onPointerDown={()=>dir(0,1)}>▼</button>
        </div>
      )}
    </div>
  );
}

// ══════════════════════════════════════════════════════════════════════════════
//  GAME 5 — APC Slots
// ══════════════════════════════════════════════════════════════════════════════
const SLOT_SYMBOLS = ['🪙','💎','⬡','📈','🏢','🎭','🔒','⚡'];
const REEL_H = 3; // visible rows per reel

interface SlotsProps { onEarn:(n:number)=>void; onSpend:(n:number)=>void; }

function SlotsGame({ onEarn, onSpend }: SlotsProps) {
  const [reels, setReels]     = useState([['🪙','💎','⬡'],['🎭','🔒','📈'],['🏢','⚡','🪙']]);
  const [spinning, setSpinning] = useState(false);
  const [result, setResult]   = useState<string|null>(null);
  const [win, setWin]         = useState<number|null>(null);
  const [balance, setBalance] = useState<number|null>(null);
  const [bet]                 = useState(5);
  const spinRef = useRef<ReturnType<typeof setInterval>|null>(null);

  useEffect(()=>{
    supabase.auth.getUser().then(({data:{user}})=>{
      if(!user)return;
      supabase.from('apc_wallets').select('balance_apc').eq('user_id',user.id).maybeSingle()
        .then(({data})=>{ if(data) setBalance(Math.floor(data.balance_apc)); });
    });
  },[]);

  const spin = useCallback(async () => {
    if(spinning) return;
    if(balance !== null && balance < bet) { setResult('Not enough APC!'); return; }
    setSpinning(true); setResult(null); setWin(null);
    onSpend(bet);
    if(balance!==null) setBalance(b=>(b??0)-bet);

    // Animate reels
    let tick=0;
    spinRef.current = setInterval(()=>{
      tick++;
      setReels(()=>[
        Array.from({length:REEL_H},()=>SLOT_SYMBOLS[Math.floor(Math.random()*SLOT_SYMBOLS.length)]),
        Array.from({length:REEL_H},()=>SLOT_SYMBOLS[Math.floor(Math.random()*SLOT_SYMBOLS.length)]),
        Array.from({length:REEL_H},()=>SLOT_SYMBOLS[Math.floor(Math.random()*SLOT_SYMBOLS.length)]),
      ]);
      if(tick>14) {
        clearInterval(spinRef.current!);
        // Final result
        const final = [
          Array.from({length:REEL_H},()=>SLOT_SYMBOLS[Math.floor(Math.random()*SLOT_SYMBOLS.length)]),
          Array.from({length:REEL_H},()=>SLOT_SYMBOLS[Math.floor(Math.random()*SLOT_SYMBOLS.length)]),
          Array.from({length:REEL_H},()=>SLOT_SYMBOLS[Math.floor(Math.random()*SLOT_SYMBOLS.length)]),
        ];
        setReels(final);
        // Check middle row
        const mid = [final[0][1], final[1][1], final[2][1]];
        let reward = 0;
        let msg = '';
        if(mid[0]===mid[1]&&mid[1]===mid[2]) {
          if(mid[0]==='💎')      { reward=100; msg='💎 JACKPOT! +100 APC!'; }
          else if(mid[0]==='🪙') { reward=50;  msg='🪙 TRIPLE! +50 APC!'; }
          else                   { reward=30;  msg=`${mid[0]} Three of a kind! +30 APC!`; }
        } else if(mid[0]===mid[1]||mid[1]===mid[2]||mid[0]===mid[2]) {
          if(mid.includes('💎')) { reward=20; msg='💎 Pair of diamonds! +20 APC!'; }
          else                   { reward=8;  msg='Pair found! +8 APC!'; }
        } else {
          msg='Too bad! Try again.';
        }
        setResult(msg); setWin(reward);
        if(reward>0){ onEarn(reward); setBalance(b=>(b??0)+reward); }
        setSpinning(false);
      }
    }, 80);
  }, [spinning, balance, bet, onEarn, onSpend]);

  useEffect(()=>()=>{if(spinRef.current)clearInterval(spinRef.current);},[]);

  return (
    <div className="wg-slots">
      <div className="wg-slots__machine">
        <div className="wg-slots__header">
          <Zap size={14} style={{color:'#fcd34d'}}/> APC SLOTS <Zap size={14} style={{color:'#fcd34d'}}/>
        </div>
        <div className="wg-slots__reels">
          {reels.map((reel,ri)=>(
            <div key={ri} className={`wg-slots__reel${spinning?' wg-slots__reel--spin':''}`}>
              {reel.map((sym,si)=>(
                <div key={si} className={`wg-slots__sym${si===1?' wg-slots__sym--mid':''}`}>
                  {sym}
                </div>
              ))}
            </div>
          ))}
        </div>
        <div className="wg-slots__payline"/>
      </div>

      <div className="wg-slots__info">
        {balance !== null && (
          <div className="wg-slots__bal"><Coins size={11}/> {balance} APC available</div>
        )}
        {result && (
          <div className={`wg-slots__result${win&&win>0?' wg-slots__result--win':' wg-slots__result--loss'}`}>
            {result}
          </div>
        )}
      </div>

      <div className="wg-slots__paytable">
        <div>💎💎💎 = 100 APC</div>
        <div>🪙🪙🪙 = 50 APC</div>
        <div>3 of a kind = 30 APC</div>
        <div>💎 pair = 20 APC</div>
        <div>Pair = 8 APC</div>
      </div>

      <button
        className={`wg-slots__spinbtn${spinning?' wg-slots__spinbtn--disabled':''}`}
        onClick={spin} disabled={spinning}
      >
        {spinning ? 'Spinning…' : `Spin! (${bet} APC)`}
      </button>
    </div>
  );
}
