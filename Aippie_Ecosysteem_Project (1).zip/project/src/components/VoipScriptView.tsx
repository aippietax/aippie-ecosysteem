/**
 * VoipScriptView — V122 Reservation & VoIP Script Generator
 * AIPPIETAX S.A.
 *
 * Generates natural Dutch/English/Spanish phone scripts for hotel, restaurant,
 * doctor, and service reservations. The user fills in their details and the
 * script is rendered sentence-by-sentence. Aippie reads each sentence aloud
 * at rate 0.82 so the user can follow during a live call.
 */
import { useCallback, useEffect, useRef, useState } from 'react';
import {
  Phone, Play, Square, Copy, CheckCircle2, ChevronRight,
  RotateCcw, Volume2, Building2, Utensils, Stethoscope,
  Wrench, Globe, User, Calendar, Clock, Users,
  AlertCircle, ChevronDown, ChevronUp, History, Check
} from 'lucide-react';
import { applyPremiumVoice, withVoicesReady, normalizeForTTS } from '../lib/ttsVoice';
import { notifyScriptReady, notificationsGranted } from '../lib/notificationService';
import { supabase } from '../lib/supabase';

const SPEECH_RATE  = 0.82;
const SPEECH_PITCH = 1.02;

// ── Script types ───────────────────────────────────────────────────────────────
type ScriptType = 'hotel' | 'restaurant' | 'doctor' | 'service';
type ScriptLang = 'nl' | 'en' | 'es';

interface ScriptParams {
  type:       ScriptType;
  lang:       ScriptLang;
  userName:   string;
  targetName: string; // hotel/restaurant/doctor name
  date:       string;
  time:       string;
  guests:     string;
  notes:      string;
}

const SCRIPT_META: Record<ScriptType, { label: string; icon: React.ReactNode; color: string; placeholderTarget: string }> = {
  hotel:      { label: 'Hotel',       icon: <Building2 size={14} />, color: '#38bdf8', placeholderTarget: 'e.g. Hotel Majestic Barcelona' },
  restaurant: { label: 'Restaurant',  icon: <Utensils  size={14} />, color: '#4ade80', placeholderTarget: 'e.g. Restaurant El Bulli' },
  doctor:     { label: 'Doctor',      icon: <Stethoscope size={14} />, color: '#f472b6', placeholderTarget: 'e.g. City Medical Practice' },
  service:    { label: 'Service',     icon: <Wrench    size={14} />, color: '#fbbf24', placeholderTarget: 'e.g. QuickFix Plumbing' },
};

const LANG_LABELS: Record<ScriptLang, string> = {
  nl: 'Nederlands', en: 'English', es: 'Español',
};

// ── Script generator ──────────────────────────────────────────────────────────
function buildScript(p: ScriptParams): string[] {
  const name   = p.userName.trim()   || 'the caller';
  const target = p.targetName.trim() || 'your establishment';
  const date   = p.date  || 'a date to be confirmed';
  const time   = p.time  || 'a time to be confirmed';
  const guests = p.guests || '2 guests';
  const notes  = p.notes.trim();

  if (p.lang === 'nl') {
    const base: Record<ScriptType, string[]> = {
      hotel: [
        `Goedemiddag, u spreekt met de AI-assistent van ${name}.`,
        `Ik bel namens ${name} om een kamerreservering te maken bij ${target}.`,
        `Wij wensen in te checken op ${date} om ${time}.`,
        `Het gaat om ${guests}.`,
        notes ? `Aanvullende wensen: ${notes}.` : `Heeft u een rustige kamer beschikbaar, bij voorkeur met uitzicht?`,
        `Kunt u bevestigen of er beschikbaarheid is en wat de tarieven zijn?`,
        `Dank u wel. Wij zien uw bevestiging graag tegemoet.`,
      ],
      restaurant: [
        `Goedemiddag, u spreekt met de AI-assistent van ${name}.`,
        `Ik bel om een tafelreservering te maken bij ${target}.`,
        `De gewenste datum is ${date} om ${time} voor ${guests}.`,
        notes ? `Speciale verzoeken: ${notes}.` : `Zijn er mogelijkheden voor een rustig tafeltje, bij voorkeur binnen?`,
        `Kunt u de reservering bevestigen en eventueel het menupakket toelichten?`,
        `Hartelijk dank. Tot dan.`,
      ],
      doctor: [
        `Goedemiddag, u spreekt met de AI-assistent van ${name}.`,
        `Ik bel namens ${name} om een afspraak te maken bij ${target}.`,
        `De voorkeursdatum is ${date} rond ${time}.`,
        notes ? `De klacht betreft: ${notes}.` : `Het gaat om een reguliere controle-afspraak.`,
        `Kunt u aangeven wat de eerstvolgende beschikbare tijd is?`,
        `Graag ontvangen wij een bevestiging per sms of e-mail. Dank u.`,
      ],
      service: [
        `Goedemiddag, u spreekt met de AI-assistent van ${name}.`,
        `Ik bel namens ${name} voor een serviceafspraak bij ${target}.`,
        `De gewenste datum is ${date} rond ${time}.`,
        notes ? `Omschrijving van het probleem: ${notes}.` : `Het gaat om een technische inspectie.`,
        `Kunt u bevestigen of een monteur beschikbaar is en wat de voorrijkosten zijn?`,
        `Wij ontvangen graag een bevestiging. Dank u wel.`,
      ],
    };
    return base[p.type];
  }

  if (p.lang === 'en') {
    const base: Record<ScriptType, string[]> = {
      hotel: [
        `Good afternoon, this is the AI assistant calling on behalf of ${name}.`,
        `I am calling to make a room reservation at ${target}.`,
        `The check-in date would be ${date} at approximately ${time}.`,
        `The booking is for ${guests}.`,
        notes ? `Special requests: ${notes}.` : `We would prefer a quiet room, ideally with a view.`,
        `Could you confirm availability and current rates?`,
        `Thank you very much. We look forward to your confirmation.`,
      ],
      restaurant: [
        `Good afternoon, this is the AI assistant calling on behalf of ${name}.`,
        `I am calling to reserve a table at ${target}.`,
        `The reservation would be for ${date} at ${time} for ${guests}.`,
        notes ? `Special requests: ${notes}.` : `We would prefer a quiet table indoors if possible.`,
        `Could you confirm the reservation and let us know about any set menus?`,
        `Thank you very much. We look forward to our visit.`,
      ],
      doctor: [
        `Good afternoon, this is the AI assistant calling on behalf of ${name}.`,
        `I am calling to schedule an appointment at ${target}.`,
        `The preferred date is ${date} around ${time}.`,
        notes ? `The reason for the appointment is: ${notes}.` : `This is for a routine check-up.`,
        `Could you let us know the earliest available slot?`,
        `A confirmation by SMS or email would be greatly appreciated. Thank you.`,
      ],
      service: [
        `Good afternoon, this is the AI assistant calling on behalf of ${name}.`,
        `I am calling to book a service appointment at ${target}.`,
        `The preferred date is ${date} around ${time}.`,
        notes ? `Issue description: ${notes}.` : `This is for a technical inspection.`,
        `Could you confirm technician availability and call-out charges?`,
        `We would appreciate a written confirmation. Thank you very much.`,
      ],
    };
    return base[p.type];
  }

  // Spanish
  const base: Record<ScriptType, string[]> = {
    hotel: [
      `Buenas tardes, le llama el asistente de IA en nombre de ${name}.`,
      `Le llamo para realizar una reserva de habitación en ${target}.`,
      `La fecha de entrada sería el ${date} a las ${time}.`,
      `La reserva es para ${guests}.`,
      notes ? `Peticiones especiales: ${notes}.` : `Preferimos una habitación tranquila, a ser posible con vistas.`,
      `¿Podría confirmar la disponibilidad y las tarifas actuales?`,
      `Muchas gracias. Quedamos a la espera de su confirmación.`,
    ],
    restaurant: [
      `Buenas tardes, le llama el asistente de IA en nombre de ${name}.`,
      `Le llamo para reservar una mesa en ${target}.`,
      `La reserva sería para el ${date} a las ${time} para ${guests}.`,
      notes ? `Peticiones especiales: ${notes}.` : `Preferimos una mesa tranquila en el interior si es posible.`,
      `¿Puede confirmar la reserva y comentarnos los menús disponibles?`,
      `Muchas gracias. Hasta pronto.`,
    ],
    doctor: [
      `Buenas tardes, le llama el asistente de IA en nombre de ${name}.`,
      `Le llamo para concertar una cita en ${target}.`,
      `La fecha preferida es el ${date} sobre las ${time}.`,
      notes ? `El motivo de la consulta es: ${notes}.` : `Es para una revisión rutinaria.`,
      `¿Cuál sería la primera cita disponible?`,
      `Agradeceríamos una confirmación por SMS o correo electrónico. Gracias.`,
    ],
    service: [
      `Buenas tardes, le llama el asistente de IA en nombre de ${name}.`,
      `Le llamo para concertar una visita de servicio técnico en ${target}.`,
      `La fecha preferida es el ${date} sobre las ${time}.`,
      notes ? `Descripción de la avería: ${notes}.` : `Se trata de una inspección técnica.`,
      `¿Puede confirmar la disponibilidad de un técnico y los gastos de desplazamiento?`,
      `Agradecemos una confirmación por escrito. Muchas gracias.`,
    ],
  };
  return base[p.type];
}

export default function VoipScriptView() {
  // Form state
  const [scriptType,  setScriptType]  = useState<ScriptType>('restaurant');
  const [scriptLang,  setScriptLang]  = useState<ScriptLang>('nl');
  const [userName,    setUserName]    = useState('');
  const [targetName,  setTargetName]  = useState('');
  const [date,        setDate]        = useState('');
  const [time,        setTime]        = useState('');
  const [guests,      setGuests]      = useState('2 guests');
  const [notes,       setNotes]       = useState('');

  // Script runtime state
  const [script,      setScript]      = useState<string[]>([]);
  const [activeIdx,   setActiveIdx]   = useState(-1);
  const [speaking,    setSpeaking]    = useState(false);
  const [copied,      setCopied]      = useState(false);
  const [showForm,    setShowForm]    = useState(true);
  const [savedId,     setSavedId]     = useState<string | null>(null);
  const [history,     setHistory]     = useState<{id:string;script_type:string;target_name:string|null;created_at:string;completed:boolean}[]>([]);
  const [showHistory, setShowHistory] = useState(false);

  const cancelRef = useRef(false);
  const deviceKey = localStorage.getItem('aippie_device_key') ?? 'anon';

  useEffect(() => {
    loadHistory();
    return () => { cancelRef.current = true; window.speechSynthesis?.cancel(); };
  }, []);

  const loadHistory = async () => {
    const { data } = await supabase
      .from('voip_script_history')
      .select('id,script_type,target_name,created_at,completed')
      .eq('device_key', deviceKey)
      .order('created_at', { ascending: false })
      .limit(10);
    if (data) setHistory(data as typeof history);
  };

  // ── speak single sentence ────────────────────────────────────────────────
  const speakSentence = useCallback((text: string, onEnd: () => void) => {
    if (!('speechSynthesis' in window)) { onEnd(); return; }
    cancelRef.current = false;
    setSpeaking(true);
    const fire = () => {
      const u = new SpeechSynthesisUtterance(normalizeForTTS(text));
      u.rate  = SPEECH_RATE;
      u.pitch = SPEECH_PITCH;
      applyPremiumVoice(u);
      u.onend   = () => { if (!cancelRef.current) { setSpeaking(false); onEnd(); } };
      u.onerror = () => { setSpeaking(false); };
      window.speechSynthesis.speak(u);
    };
    withVoicesReady(fire);
  }, []);

  const stopSpeech = useCallback(() => {
    cancelRef.current = true;
    window.speechSynthesis?.cancel();
    setSpeaking(false);
    setActiveIdx(-1);
  }, []);

  // ── Play all sentences sequentially ─────────────────────────────────────
  const playFrom = useCallback((idx: number, sentences: string[]) => {
    if (idx >= sentences.length) { setActiveIdx(-1); return; }
    setActiveIdx(idx);
    speakSentence(sentences[idx], () => {
      if (!cancelRef.current) playFrom(idx + 1, sentences);
    });
  }, [speakSentence]);

  const handleGenerate = async () => {
    const sentences = buildScript({ type: scriptType, lang: scriptLang, userName, targetName, date, time, guests, notes });
    setScript(sentences);
    setActiveIdx(-1);
    setShowForm(false);
    window.speechSynthesis?.cancel();
    if (notificationsGranted()) {
      notifyScriptReady({ scriptType: SCRIPT_META[scriptType].label, target: targetName.trim() || scriptType });
    }
    // Save to history
    const { data } = await supabase.from('voip_script_history').insert({
      device_key: deviceKey, script_type: scriptType, language: scriptLang,
      user_name: userName || null, target_name: targetName || null,
      date_str: date || null, time_str: time || null,
      guests: guests || null, notes: notes || null,
    }).select('id').maybeSingle();
    if (data) { setSavedId(data.id); loadHistory(); }
  };

  const handlePlayAll = () => {
    if (speaking) { stopSpeech(); return; }
    cancelRef.current = false;
    playFrom(0, script);
  };

  const handlePlaySentence = (idx: number) => {
    stopSpeech();
    setTimeout(() => playFrom(idx, script), 80);
  };

  const handleCopyAll = () => {
    navigator.clipboard.writeText(script.join('\n')).catch(() => {});
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleReset = async () => {
    stopSpeech();
    // Mark as completed in DB
    if (savedId) {
      await supabase.from('voip_script_history').update({ completed: true }).eq('id', savedId);
      setSavedId(null);
      loadHistory();
    }
    setScript([]);
    setShowForm(true);
    setActiveIdx(-1);
  };

  const meta = SCRIPT_META[scriptType];

  return (
    <div className="vs-root">

      {/* ── Header ── */}
      <div className="vs-header">
        <div className="vs-header__icon" style={{ color: '#38bdf8', background: 'rgba(56,189,248,0.1)', borderColor: 'rgba(56,189,248,0.25)' }}>
          <Phone size={18} />
        </div>
        <div>
          <div className="vs-header__title">Reservation Script Generator</div>
          <div className="vs-header__sub">Aippie reads the script at rate 0.82 · AIPPIETAX S.A. v132</div>
        </div>
      </div>

      {/* ── Script type tabs ── */}
      <div className="vs-type-tabs">
        {(Object.entries(SCRIPT_META) as [ScriptType, typeof SCRIPT_META[ScriptType]][]).map(([key, m]) => (
          <button
            key={key}
            className={`vs-type-tab${scriptType === key ? ' vs-type-tab--active' : ''}`}
            style={scriptType === key ? { borderColor: m.color + '66', color: m.color, background: m.color + '10' } : undefined}
            onClick={() => { setScriptType(key); if (!showForm) setShowForm(true); }}
          >
            {m.icon} {m.label}
          </button>
        ))}
      </div>

      {/* ── Form ── */}
      {showForm && (
        <div className="vs-form">
          <div className="vs-form__toggle" onClick={() => setShowForm(f => !f)}>
            <span>Script Parameters</span>
            {showForm ? <ChevronUp size={13} /> : <ChevronDown size={13} />}
          </div>

          {/* Language */}
          <div className="vs-field-label">Script Language</div>
          <div className="vs-pill-row">
            {(Object.keys(LANG_LABELS) as ScriptLang[]).map(l => (
              <button
                key={l}
                className={`vs-pill${scriptLang === l ? ' vs-pill--active' : ''}`}
                onClick={() => setScriptLang(l)}
              >
                <Globe size={10} /> {LANG_LABELS[l]}
              </button>
            ))}
          </div>

          <div className="vs-form__grid">
            <div className="vs-form__field">
              <label className="vs-field-label">
                <User size={10} /> Your Name
              </label>
              <input
                className="vs-input"
                value={userName}
                onChange={e => setUserName(e.target.value)}
                placeholder="e.g. Maria García"
              />
            </div>
            <div className="vs-form__field">
              <label className="vs-field-label">
                {meta.icon} {meta.label} Name
              </label>
              <input
                className="vs-input"
                value={targetName}
                onChange={e => setTargetName(e.target.value)}
                placeholder={meta.placeholderTarget}
              />
            </div>
            <div className="vs-form__field">
              <label className="vs-field-label">
                <Calendar size={10} /> Date
              </label>
              <input
                className="vs-input"
                type="date"
                value={date}
                onChange={e => setDate(e.target.value)}
              />
            </div>
            <div className="vs-form__field">
              <label className="vs-field-label">
                <Clock size={10} /> Time
              </label>
              <input
                className="vs-input"
                type="time"
                value={time}
                onChange={e => setTime(e.target.value)}
              />
            </div>
            {(scriptType === 'hotel' || scriptType === 'restaurant') && (
              <div className="vs-form__field">
                <label className="vs-field-label">
                  <Users size={10} /> Number of Guests
                </label>
                <input
                  className="vs-input"
                  value={guests}
                  onChange={e => setGuests(e.target.value)}
                  placeholder="e.g. 2 adults"
                />
              </div>
            )}
            <div className="vs-form__field vs-form__field--full">
              <label className="vs-field-label">Additional Information (optional)</label>
              <input
                className="vs-input"
                value={notes}
                onChange={e => setNotes(e.target.value.slice(0, 200))}
                placeholder="e.g. allergies, wheelchair access, reason for consultation…"
              />
            </div>
          </div>

          <button
            className="vs-btn-generate"
            style={{ background: meta.color, color: '#0a0f1e' }}
            onClick={handleGenerate}
          >
            <Phone size={13} /> Generate Script
            <ChevronRight size={12} />
          </button>
        </div>
      )}

      {/* ── Script output ── */}
      {script.length > 0 && !showForm && (
        <div className="vs-script-panel">
          <div className="vs-script-toolbar">
            <div className="vs-script-title">
              {meta.icon}
              <span style={{ color: meta.color }}>{meta.label} Script</span>
              <span className="vs-script-lang-badge">{LANG_LABELS[scriptLang]}</span>
            </div>
            <div className="vs-script-actions">
              <button className="vs-btn-sm" onClick={() => setShowForm(true)}>
                <RotateCcw size={11} /> Edit
              </button>
              <button className="vs-btn-sm" onClick={handleCopyAll}>
                {copied ? <><CheckCircle2 size={11} /> Copied</> : <><Copy size={11} /> Copy All</>}
              </button>
              <button
                className={`vs-btn-play${speaking ? ' vs-btn-play--stop' : ''}`}
                style={!speaking ? { background: meta.color, color: '#0a0f1e' } : undefined}
                onClick={handlePlayAll}
              >
                {speaking ? <><Square size={12} /> Stop</> : <><Play size={12} /> Play All</>}
              </button>
            </div>
          </div>

          <div className="vs-sentences">
            {script.map((sentence, i) => (
              <div
                key={i}
                className={`vs-sentence${activeIdx === i ? ' vs-sentence--active' : ''}`}
                style={activeIdx === i ? { borderColor: meta.color + '66', background: meta.color + '0c' } : undefined}
              >
                <span className="vs-sentence__num" style={activeIdx === i ? { color: meta.color } : undefined}>
                  {i + 1}
                </span>
                <span className="vs-sentence__text">{sentence}</span>
                <button
                  className="vs-sentence__play"
                  style={{ color: meta.color }}
                  onClick={() => handlePlaySentence(i)}
                  title="Play sentence"
                >
                  {activeIdx === i && speaking ? <Square size={11} /> : <Volume2 size={11} />}
                </button>
              </div>
            ))}
          </div>

          <div className="vs-tip">
            <AlertCircle size={10} style={{ color: '#334155', flexShrink: 0 }} />
            Press "Play All" just before you call. Aippie reads each sentence at a calm pace. You can also play each sentence individually.
          </div>

          <button className="vs-btn-new" onClick={handleReset}>
            <Phone size={12} /> New Script
          </button>
        </div>
      )}
      {/* ── History ── */}
      {history.length > 0 && (
        <div className="vs-history">
          <button className="vs-history__toggle" onClick={() => setShowHistory(h => !h)}>
            <History size={11} /> Recente scripts ({history.length})
            {showHistory ? <ChevronUp size={11} /> : <ChevronDown size={11} />}
          </button>
          {showHistory && (
            <div className="vs-history__list">
              {history.map(h => (
                <div key={h.id} className="vs-history__item">
                  <span className="vs-history__type">{h.script_type}</span>
                  <span className="vs-history__target">{h.target_name ?? '—'}</span>
                  <span className="vs-history__date">{new Date(h.created_at).toLocaleDateString('nl-NL')}</span>
                  {h.completed && <Check size={10} style={{ color: '#4ade80' }} />}
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
