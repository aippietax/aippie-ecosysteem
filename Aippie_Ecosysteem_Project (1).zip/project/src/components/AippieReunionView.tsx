import { useCallback, useEffect, useRef, useState } from 'react';
import {
  Heart, FolderOpen, UserCheck, Send, RefreshCw, Plus,
  CheckCircle, Clock, AlertTriangle, Check, ChevronRight,
  ShieldCheck, Landmark, Users, FileText, Search
} from 'lucide-react';
import { supabase } from '../lib/supabase';
import type { User } from '@supabase/supabase-js';

// ── Types ─────────────────────────────────────────────────────────────────────
interface ReunionCase {
  case_id: string;
  subject_full_name: string;
  case_type: 'FAMILY_REUNIFICATION' | 'OFFICIAL_MISSING_PERSON';
  years_of_separation: number;
  case_chronology_details: string;
  is_dossier_ready_for_legal_authorities: boolean;
  created_at: string;
}

interface RegistryEntry {
  registry_id: string;
  registered_search_name: string;
  is_identity_verified: boolean;
  consent_to_match_shared: boolean;
  created_at: string;
}

interface AuthorityDispatch {
  dispatch_id: string;
  case_id: string;
  authorized_agency_name: string;
  dispatch_status: 'DOSSIER_SENT' | 'UNDER_REVIEW' | 'INVESTIGATION_ACTIVE';
  notes: string;
  created_at: string;
}

interface BillingRecord {
  billing_id: string;
  case_id: string;
  initial_activation_fee_eur: number;
  success_delivery_fee_eur: number;
  payment_status: 'INITIAL_PAID' | 'SUCCESS_PENDING' | 'FULLY_CLOSED';
}

type ActivePanel = 'cases' | 'registry' | 'search' | 'billing';

// ── Helpers ───────────────────────────────────────────────────────────────────
function statusColor(s: AuthorityDispatch['dispatch_status']) {
  return s === 'INVESTIGATION_ACTIVE' ? 'text-emerald-400'
       : s === 'UNDER_REVIEW'         ? 'text-amber-400'
       : 'text-sky-400';
}

function billingColor(s: BillingRecord['payment_status']) {
  return s === 'FULLY_CLOSED'   ? 'text-emerald-400'
       : s === 'SUCCESS_PENDING' ? 'text-amber-400'
       : 'text-sky-400';
}

function caseTypeLabel(t: ReunionCase['case_type']) {
  return t === 'FAMILY_REUNIFICATION' ? 'Family Reunification' : 'Official Missing Person';
}

function caseTypeColor(t: ReunionCase['case_type']) {
  return t === 'FAMILY_REUNIFICATION' ? 'ar-type--family' : 'ar-type--missing';
}

// ── Case card ─────────────────────────────────────────────────────────────────
function CaseCard({
  rc,
  dispatches,
  billing,
  onDispatch,
}: {
  rc: ReunionCase;
  dispatches: AuthorityDispatch[];
  billing: BillingRecord | undefined;
  onDispatch: (caseId: string) => void;
}) {
  const [expanded, setExpanded] = useState(false);
  const myDispatches = dispatches.filter(d => d.case_id === rc.case_id);
  const latestDispatch = myDispatches[0];

  return (
    <div className="ar-case-card">
      <div className="ar-case-card__top">
        <div className="ar-case-card__icon-wrap">
          <Heart size={18} className="text-rose-400" />
        </div>
        <div className="ar-case-card__info">
          <div className="ar-case-card__name-row">
            <span className="ar-case-card__name">{rc.subject_full_name}</span>
            <span className={`ar-type ${caseTypeColor(rc.case_type)}`}>{caseTypeLabel(rc.case_type)}</span>
          </div>
          <p className="ar-case-card__meta">
            {rc.years_of_separation > 0 ? `${rc.years_of_separation} yr${rc.years_of_separation !== 1 ? 's' : ''} separated · ` : ''}
            {new Date(rc.created_at).toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' })}
          </p>
        </div>
        <div className="ar-case-card__right">
          {rc.is_dossier_ready_for_legal_authorities && (
            <span className="ar-ready-badge"><CheckCircle size={10} /> Ready</span>
          )}
          <button className="ar-expand-btn" onClick={() => setExpanded(e => !e)}>
            <ChevronRight size={14} style={{ transform: expanded ? 'rotate(90deg)' : 'none', transition: 'transform 0.2s' }} />
          </button>
        </div>
      </div>

      {expanded && (
        <div className="ar-case-card__body">
          {rc.case_chronology_details && (
            <div className="ar-case-card__chronology">
              <p className="ar-field-label">Case Summary</p>
              <p className="ar-field-text">{rc.case_chronology_details}</p>
            </div>
          )}

          {/* Authority dispatch status */}
          {latestDispatch ? (
            <div className="ar-dispatch-status">
              <Landmark size={13} className="text-sky-400" />
              <div>
                <p className="ar-field-label">{latestDispatch.authorized_agency_name}</p>
                <p className={`ar-dispatch-val ${statusColor(latestDispatch.dispatch_status)}`}>
                  {latestDispatch.dispatch_status.replace(/_/g, ' ')}
                </p>
              </div>
            </div>
          ) : (
            <button className="ar-dispatch-btn" onClick={() => onDispatch(rc.case_id)}>
              <Send size={13} /> Submit Dossier to Legal Authorities
            </button>
          )}

          {/* Billing summary */}
          {billing && (
            <div className="ar-billing-row">
              <span className="ar-field-label">Billing</span>
              <span className="ar-billing-row__fees">
                Activation €{Number(billing.initial_activation_fee_eur).toFixed(0)} ·
                Success €{Number(billing.success_delivery_fee_eur).toFixed(0)}
              </span>
              <span className={`ar-billing-status ${billingColor(billing.payment_status)}`}>
                {billing.payment_status.replace(/_/g, ' ')}
              </span>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

// ── Main component ────────────────────────────────────────────────────────────
export default function AippieReunionView({ user }: { user: User | null }) {
  const [panel, setPanel]           = useState<ActivePanel>('cases');
  const [cases, setCases]           = useState<ReunionCase[]>([]);
  const [dispatches, setDispatches] = useState<AuthorityDispatch[]>([]);
  const [billing, setBilling]       = useState<BillingRecord[]>([]);
  const [myRegistry, setMyRegistry] = useState<RegistryEntry | null>(null);
  const [searchResults, setSearchResults] = useState<RegistryEntry[]>([]);
  const [loading, setLoading]       = useState(true);
  const [busy, setBusy]             = useState(false);
  const [feedback, setFeedback]     = useState<{ ok: boolean; msg: string } | null>(null);

  // New case form
  const [newName, setNewName]       = useState('');
  const [newType, setNewType]       = useState<ReunionCase['case_type']>('FAMILY_REUNIFICATION');
  const [newYears, setNewYears]     = useState('');
  const [newDetails, setNewDetails] = useState('');
  const [showNewForm, setShowNewForm] = useState(false);

  // Registry form
  const [regName, setRegName]       = useState('');
  const [regConsent, setRegConsent] = useState(true);

  // Search
  const [searchQuery, setSearchQuery] = useState('');

  const mountedRef = useRef(true);

  const flash = (ok: boolean, msg: string) => {
    setFeedback({ ok, msg });
    setTimeout(() => { if (mountedRef.current) setFeedback(null); }, 4500);
  };

  // ── Load ────────────────────────────────────────────────────────────────────
  const load = useCallback(async () => {
    if (!user) { setLoading(false); return; }
    setLoading(true);

    const [casesRes, dispatchRes, billingRes, regRes] = await Promise.all([
      supabase
        .from('aippie_legal_reunion_cases')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false }),
      supabase
        .from('aippie_authority_dispatches')
        .select('*')
        .order('created_at', { ascending: false }),
      supabase
        .from('aippie_reunion_billing')
        .select('*'),
      supabase
        .from('aippie_verified_registry')
        .select('*')
        .eq('user_id', user.id)
        .maybeSingle(),
    ]);

    if (!mountedRef.current) return;
    setCases((casesRes.data ?? []) as ReunionCase[]);
    setDispatches((dispatchRes.data ?? []) as AuthorityDispatch[]);
    setBilling((billingRes.data ?? []) as BillingRecord[]);
    setMyRegistry(regRes.data as RegistryEntry | null);
    setLoading(false);
  }, [user]);

  useEffect(() => {
    mountedRef.current = true;
    load();
    return () => { mountedRef.current = false; };
  }, [load]);

  // ── Create case ─────────────────────────────────────────────────────────────
  const handleCreateCase = async () => {
    if (!user) { flash(false, 'Sign in to create a case'); return; }
    if (!newName.trim()) { flash(false, 'Subject name is required'); return; }
    if (!newDetails.trim()) { flash(false, 'Case chronology details are required'); return; }

    setBusy(true);
    const { data: caseData, error: caseErr } = await supabase
      .from('aippie_legal_reunion_cases')
      .insert({
        user_id: user.id,
        subject_full_name: newName.trim(),
        case_type: newType,
        years_of_separation: parseInt(newYears) || 0,
        case_chronology_details: newDetails.trim(),
        is_dossier_ready_for_legal_authorities: true,
      })
      .select('case_id')
      .single();

    if (caseErr || !caseData) {
      flash(false, caseErr?.message ?? 'Failed to create case');
      setBusy(false);
      return;
    }

    // Create billing record
    await supabase.from('aippie_reunion_billing').insert({
      case_id: caseData.case_id,
    });

    setBusy(false);
    flash(true, 'Case dossier created successfully');
    setNewName(''); setNewType('FAMILY_REUNIFICATION'); setNewYears(''); setNewDetails('');
    setShowNewForm(false);
    load();
  };

  // ── Dispatch to authorities ─────────────────────────────────────────────────
  const handleDispatch = async (caseId: string) => {
    if (!user) return;
    setBusy(true);
    const { error } = await supabase.from('aippie_authority_dispatches').insert({
      case_id: caseId,
      authorized_agency_name: 'OFFICIAL_LEGAL_COUNSEL',
      dispatch_status: 'DOSSIER_SENT',
      notes: 'Dossier submitted via AippieLegal platform',
    });
    setBusy(false);
    if (error) { flash(false, error.message); return; }
    flash(true, 'Dossier submitted to legal authorities');
    load();
  };

  // ── Register / update registry entry ───────────────────────────────────────
  const handleRegistry = async () => {
    if (!user) { flash(false, 'Sign in to register'); return; }
    if (!regName.trim()) { flash(false, 'Enter your name to register'); return; }
    setBusy(true);

    if (myRegistry) {
      const { error } = await supabase
        .from('aippie_verified_registry')
        .update({ registered_search_name: regName.trim(), consent_to_match_shared: regConsent })
        .eq('user_id', user.id);
      setBusy(false);
      if (error) { flash(false, error.message); return; }
      flash(true, 'Registry entry updated');
    } else {
      const { error } = await supabase.from('aippie_verified_registry').insert({
        user_id: user.id,
        registered_search_name: regName.trim(),
        is_identity_verified: true,
        consent_to_match_shared: regConsent,
      });
      setBusy(false);
      if (error) { flash(false, error.message); return; }
      flash(true, 'You are now registered in the opt-in reunion registry');
    }
    load();
  };

  const handleRevokeConsent = async () => {
    if (!user || !myRegistry) return;
    setBusy(true);
    const { error } = await supabase
      .from('aippie_verified_registry')
      .update({ consent_to_match_shared: false })
      .eq('user_id', user.id);
    setBusy(false);
    if (error) { flash(false, error.message); return; }
    flash(true, 'Consent revoked — your entry is no longer searchable');
    load();
  };

  // ── Search registry ─────────────────────────────────────────────────────────
  const handleSearch = async () => {
    if (!searchQuery.trim()) { flash(false, 'Enter a name to search'); return; }
    setBusy(true);
    const { data, error } = await supabase
      .from('aippie_verified_registry')
      .select('registry_id, registered_search_name, is_identity_verified, consent_to_match_shared, created_at')
      .eq('consent_to_match_shared', true)
      .eq('is_identity_verified', true)
      .ilike('registered_search_name', `%${searchQuery.trim()}%`);
    setBusy(false);
    if (error) { flash(false, error.message); return; }
    setSearchResults((data ?? []) as RegistryEntry[]);
    if (!data?.length) flash(false, 'No matching entries found in the opt-in registry');
  };

  // Pre-fill registry form from loaded data
  useEffect(() => {
    if (myRegistry) {
      setRegName(myRegistry.registered_search_name);
      setRegConsent(myRegistry.consent_to_match_shared);
    }
  }, [myRegistry]);

  if (!user) {
    return (
      <div className="ar-root ar-root--empty">
        <Heart size={40} className="ar-empty__icon" />
        <p className="ar-empty__title">Aippie Reunion</p>
        <p className="ar-empty__sub">Sign in to access the legal family reunification platform</p>
      </div>
    );
  }

  return (
    <div className="ar-root">
      {/* Header */}
      <div className="ar-header">
        <div className="ar-header__left">
          <Heart size={22} className="ar-header__icon" />
          <div>
            <h1 className="ar-header__title">Aippie Reunion</h1>
            <p className="ar-header__sub">Legal Family Reunification · Missing Persons · AIPPIETAX S.A.</p>
          </div>
        </div>
        <button className="ar-refresh-btn" onClick={load} aria-label="Refresh">
          <RefreshCw size={14} className={loading ? 'animate-spin' : ''} />
        </button>
      </div>

      {/* Feedback */}
      {feedback && (
        <div className={`ar-feedback${feedback.ok ? ' ar-feedback--ok' : ' ar-feedback--err'}`}>
          {feedback.ok ? <Check size={14} /> : <AlertTriangle size={14} />}
          {feedback.msg}
        </div>
      )}

      {/* Legal disclaimer banner */}
      <div className="ar-disclaimer-banner">
        <ShieldCheck size={14} className="text-amber-400" />
        <p className="ar-disclaimer-text">
          This platform manages legal dossiers for official authority submission only.
          All data is user-submitted and consent-based. AIPPIETAX S.A. does not conduct
          investigations or access third-party data.
        </p>
      </div>

      {/* Tabs */}
      <div className="ar-tabs">
        {([
          { id: 'cases',    icon: <FolderOpen size={13} />, label: 'My Cases',   count: cases.length },
          { id: 'registry', icon: <UserCheck size={13} />,  label: 'My Registry',count: 0 },
          { id: 'search',   icon: <Search size={13} />,     label: 'Search',     count: 0 },
          { id: 'billing',  icon: <Landmark size={13} />,   label: 'Billing',    count: billing.length },
        ] as { id: ActivePanel; icon: React.ReactNode; label: string; count: number }[]).map(t => (
          <button
            key={t.id}
            className={`ar-tab${panel === t.id ? ' ar-tab--active' : ''}`}
            onClick={() => setPanel(t.id)}
          >
            {t.icon}
            {t.label}
            {t.count > 0 && <span className="ar-tab__count">{t.count}</span>}
          </button>
        ))}
      </div>

      {/* ── Cases panel ──────────────────────────────────────────────────────── */}
      {panel === 'cases' && (
        <div className="ar-panel">
          <button className="ar-new-btn" onClick={() => setShowNewForm(f => !f)}>
            <Plus size={14} />
            {showNewForm ? 'Cancel' : 'Open New Case Dossier'}
          </button>

          {showNewForm && (
            <div className="ar-form">
              <h2 className="ar-form__title">New Legal Case Dossier</h2>

              <label className="ar-label">Subject Full Name</label>
              <input
                className="ar-input"
                placeholder="Full name of the person you are searching for"
                value={newName}
                onChange={e => setNewName(e.target.value)}
              />

              <label className="ar-label" style={{ marginTop: 12 }}>Case Type</label>
              <div className="ar-radio-group">
                {(['FAMILY_REUNIFICATION', 'OFFICIAL_MISSING_PERSON'] as const).map(t => (
                  <label key={t} className={`ar-radio${newType === t ? ' ar-radio--active' : ''}`}>
                    <input type="radio" name="case_type" value={t} checked={newType === t} onChange={() => setNewType(t)} />
                    {t === 'FAMILY_REUNIFICATION' ? <Heart size={12} /> : <Users size={12} />}
                    {caseTypeLabel(t)}
                  </label>
                ))}
              </div>

              <label className="ar-label" style={{ marginTop: 12 }}>Years of Separation</label>
              <input
                type="number"
                className="ar-input"
                placeholder="0"
                min="0"
                value={newYears}
                onChange={e => setNewYears(e.target.value)}
              />

              <label className="ar-label" style={{ marginTop: 12 }}>Case Chronology & Details</label>
              <textarea
                className="ar-textarea"
                rows={5}
                placeholder="Describe the circumstances, last known location, relevant dates, and any supporting information for the legal dossier…"
                value={newDetails}
                onChange={e => setNewDetails(e.target.value)}
              />

              <button
                className="ar-action-btn ar-action-btn--primary"
                onClick={handleCreateCase}
                disabled={busy || !newName.trim() || !newDetails.trim()}
              >
                {busy ? <RefreshCw size={14} className="animate-spin" /> : <FileText size={14} />}
                {busy ? 'Creating…' : 'Create Dossier'}
              </button>
            </div>
          )}

          {loading ? (
            <div className="ar-loading"><RefreshCw size={16} className="animate-spin" /> Loading cases…</div>
          ) : cases.length === 0 ? (
            <div className="ar-empty-state">
              <FolderOpen size={28} className="ar-empty-state__icon" />
              <p>No cases yet. Open your first legal dossier above.</p>
            </div>
          ) : (
            <div className="ar-case-list">
              {cases.map(rc => (
                <CaseCard
                  key={rc.case_id}
                  rc={rc}
                  dispatches={dispatches}
                  billing={billing.find(b => b.case_id === rc.case_id)}
                  onDispatch={handleDispatch}
                />
              ))}
            </div>
          )}
        </div>
      )}

      {/* ── Registry panel ───────────────────────────────────────────────────── */}
      {panel === 'registry' && (
        <div className="ar-panel">
          <div className="ar-registry-intro">
            <UserCheck size={16} className="text-emerald-400" />
            <div>
              <p className="ar-registry-intro__title">Opt-In Reunion Registry</p>
              <p className="ar-registry-intro__sub">
                Register your name so others searching for you can find you.
                You control your visibility and can revoke consent at any time.
              </p>
            </div>
          </div>

          {myRegistry?.consent_to_match_shared && (
            <div className="ar-registry-active">
              <CheckCircle size={14} className="text-emerald-400" />
              <span>Your entry is <strong>active</strong> and searchable in the registry.</span>
              <button className="ar-revoke-btn" onClick={handleRevokeConsent} disabled={busy}>
                Revoke
              </button>
            </div>
          )}

          <label className="ar-label">Your Name (as it will appear in the registry)</label>
          <input
            className="ar-input"
            placeholder="Your full name"
            value={regName}
            onChange={e => setRegName(e.target.value)}
          />

          <label className="ar-consent-label">
            <input
              type="checkbox"
              checked={regConsent}
              onChange={e => setRegConsent(e.target.checked)}
              className="ar-consent-box"
            />
            <span className="ar-consent-text">
              I consent to my name being visible in the opt-in reunion registry.
              I understand I can revoke this at any time.
            </span>
          </label>

          <button
            className="ar-action-btn ar-action-btn--registry"
            onClick={handleRegistry}
            disabled={busy || !regName.trim()}
          >
            {busy ? <RefreshCw size={14} className="animate-spin" /> : <UserCheck size={14} />}
            {myRegistry ? 'Update Registry Entry' : 'Register My Name'}
          </button>
        </div>
      )}

      {/* ── Search panel ─────────────────────────────────────────────────────── */}
      {panel === 'search' && (
        <div className="ar-panel">
          <div className="ar-search-intro">
            <Search size={16} className="text-sky-400" />
            <div>
              <p className="ar-search-intro__title">Search Opt-In Registry</p>
              <p className="ar-search-intro__sub">
                Only entries where the person has explicitly consented to being found are shown.
              </p>
            </div>
          </div>

          <div className="ar-search-row">
            <input
              className="ar-input ar-input--search"
              placeholder="Search by name…"
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && handleSearch()}
            />
            <button className="ar-search-btn" onClick={handleSearch} disabled={busy}>
              {busy ? <RefreshCw size={14} className="animate-spin" /> : <Search size={14} />}
            </button>
          </div>

          {searchResults.length > 0 && (
            <div className="ar-results">
              {searchResults.map(r => (
                <div key={r.registry_id} className="ar-result-row">
                  <div className="ar-result-row__avatar"><UserCheck size={16} /></div>
                  <div className="ar-result-row__body">
                    <p className="ar-result-row__name">{r.registered_search_name}</p>
                    <p className="ar-result-row__meta">
                      Registered · {new Date(r.created_at).toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' })}
                    </p>
                  </div>
                  {r.is_identity_verified && (
                    <span className="ar-verified-badge"><CheckCircle size={12} /> Verified</span>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* ── Billing panel ────────────────────────────────────────────────────── */}
      {panel === 'billing' && (
        <div className="ar-panel">
          {billing.length === 0 ? (
            <div className="ar-empty-state">
              <Landmark size={28} className="ar-empty-state__icon" />
              <p>No billing records yet. Create a case to generate a billing record.</p>
            </div>
          ) : (
            <div className="ar-billing-list">
              {billing.map(b => {
                const rc = cases.find(c => c.case_id === b.case_id);
                return (
                  <div key={b.billing_id} className="ar-billing-card">
                    <div className="ar-billing-card__header">
                      <Landmark size={15} className="text-amber-400" />
                      <span className="ar-billing-card__name">{rc?.subject_full_name ?? 'Case'}</span>
                      <span className={`ar-billing-badge ${billingColor(b.payment_status)}`}>
                        {b.payment_status.replace(/_/g, ' ')}
                      </span>
                    </div>
                    <div className="ar-billing-card__fees">
                      <div className="ar-billing-fee-row">
                        <span>Initial Activation Fee</span>
                        <span className="text-sky-400">€{Number(b.initial_activation_fee_eur).toLocaleString()}</span>
                      </div>
                      <div className="ar-billing-fee-row">
                        <span>Success Delivery Fee</span>
                        <span className="text-emerald-400">€{Number(b.success_delivery_fee_eur).toLocaleString()}</span>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* Footer */}
      <div className="ar-footer">
        <ShieldCheck size={10} />
        AIPPIETAX S.A. · Consent-Based · No Covert Data Collection · GDPR Compliant · Official Authorities Only
      </div>
    </div>
  );
}
