import { useCallback, useEffect, useRef, useState } from 'react';
import AippieVoiceOverlay from './AippieVoiceOverlay';
import { writeSharedContext } from '../services/aiService';
import {
  ShieldCheck, FileText, UploadCloud, CheckCircle2, AlertCircle,
  Phone, PhoneOff, Lock, Mic, MicOff, Wifi, RefreshCw, BookOpen,
  Zap, Home, Users, Video, PlayCircle, ShoppingCart, TrendingUp,
  ChevronDown, ChevronUp, Building2, Activity, Bell, BellRing,
  Send, Calculator, BarChart3, DollarSign, FileCheck, Globe,
  Landmark, Brain, Headphones, Radio, Sparkles, Star, Eye,
  PieChart, MessageSquareHeart, Receipt
} from 'lucide-react';
import { supabase } from '../lib/supabase';
import { applyPremiumVoice, withVoicesReady, normalizeForTTS } from '../lib/ttsVoice';
import DocScannerPanel from './DocScannerPanel';
import InvestorMatchmakerPanel from './InvestorMatchmakerPanel';
import { notifyTaxReminder, notificationsGranted } from '../lib/notificationService';
import PayrollView from './PayrollView';
import PayrollClientsView from './PayrollClientsView';
import AippieAccountingView from './AippieAccountingView';
import AippieVerifactuView from './AippieVerifactuView';

// ─── Types ────────────────────────────────────────────────────────────────────
type OcrStatus   = 'idle'  | 'scanning'   | 'complete'  | 'error';
type VoipStatus  = 'idle'  | 'dialing'    | 'connected' | 'ended';
type FilingStatus= 'draft' | 'compiling'  | 'transmitting' | 'submitted';
type AlertSev    = 'info'  | 'success'    | 'warning'   | 'critical';
type ConsultMode = 'idle'  | 'listening'  | 'thinking'  | 'speaking';
type AvatarEmotion = 'neutral'|'focused'|'pleased'|'concerned'|'authoritative';
type FasenKey = 1|2|3|4|5|6|7|8|9|10;

type TaxDoc = {
  id: string; file_name: string; ocr_status: string;
  tax_category: string; amount_eur: number; entity_type: string;
  quickbooks_synced: boolean; created_at: string;
};
type RoadmapPhase = {
  phase_number: number; title_en: string; title_nl: string;
  description_en: string; status: 'active'|'planned'|'completed'; icon_key: string;
};
type LedgerEntry = {
  id: string; entry_date: string; description: string; counterparty: string;
  amount_eur: number; vat_amount: number; category: string;
  entity_type: string; deductible: boolean; optimization_flag: string|null;
  device_key?: string;
};
type TaxAlert = {
  id: string; alert_type: string; severity: AlertSev;
  title: string; body: string; due_date: string|null;
  is_read: boolean; is_spoken: boolean;
  device_key?: string;
};
type FilingEntry = {
  id: string; fiscal_year: number; agency: string; entity_type: string;
  total_revenue_eur: number; total_expenses_eur: number; taxable_income_eur: number;
  tax_liability_eur: number; optimized_liability_eur: number; savings_eur: number;
  filing_status: string; submitted_at: string|null; confirmation_ref: string|null;
};
type OptResult = { strategy: string; saving_eur: number; description: string };
type TranscriptLine = { ts: number; speaker: 'user'|'ai'; text: string; lang?: string };

// ─── 10-Fasen phase metadata ──────────────────────────────────────────────────
type FasenMeta = {
  icon: React.ReactNode;
  color: string;
  border: string;
  accent: string;
};
const FASEN_META: Record<FasenKey, FasenMeta> = {
  1:  { icon: <FileText size={14}/>,      color: '#38bdf8', border: 'rgba(56,189,248,0.25)',  accent: 'rgba(56,189,248,0.1)'  },
  2:  { icon: <Home size={14}/>,          color: '#fbbf24', border: 'rgba(251,191,36,0.25)',  accent: 'rgba(251,191,36,0.08)' },
  3:  { icon: <Phone size={14}/>,         color: '#4ade80', border: 'rgba(74,222,128,0.25)',  accent: 'rgba(74,222,128,0.08)' },
  4:  { icon: <Activity size={14}/>,      color: '#fb923c', border: 'rgba(251,146,60,0.25)',  accent: 'rgba(251,146,60,0.08)' },
  5:  { icon: <Users size={14}/>,         color: '#a78bfa', border: 'rgba(167,139,250,0.25)', accent: 'rgba(167,139,250,0.08)'},
  6:  { icon: <Mic size={14}/>,           color: '#34d399', border: 'rgba(52,211,153,0.25)',  accent: 'rgba(52,211,153,0.08)' },
  7:  { icon: <Video size={14}/>,         color: '#60a5fa', border: 'rgba(96,165,250,0.25)',  accent: 'rgba(96,165,250,0.08)' },
  8:  { icon: <PlayCircle size={14}/>,    color: '#f472b6', border: 'rgba(244,114,182,0.25)', accent: 'rgba(244,114,182,0.08)'},
  9:  { icon: <ShoppingCart size={14}/>,  color: '#fb7185', border: 'rgba(251,113,133,0.25)', accent: 'rgba(251,113,133,0.08)'},
  10: { icon: <ShieldCheck size={14}/>,   color: '#fbbf24', border: 'rgba(251,191,36,0.3)',   accent: 'rgba(251,191,36,0.1)'  },
};

// ─── Avatar emotion map ───────────────────────────────────────────────────────
const AVATAR_EMOTION_CONFIGS: Record<AvatarEmotion, { pitch: number; rate: number; label: string }> = {
  neutral:      { pitch: 1.05, rate: 0.92, label: 'Ready'         },
  focused:      { pitch: 1.0,  rate: 0.88, label: 'Analyzing'     },
  pleased:      { pitch: 1.15, rate: 0.95, label: 'Confirmed'      },
  concerned:    { pitch: 0.95, rate: 0.85, label: 'Attention'      },
  authoritative:{ pitch: 1.0,  rate: 0.9,  label: 'Filing Mode'    },
};

// ─── Consult QA ───────────────────────────────────────────────────────────────
const CONSULT_QA: Array<{ trigger: string[]; answer: string; emotion: AvatarEmotion }> = [
  {
    trigger: ['vat','iva','btw','belasting','tax rate'],
    emotion: 'focused',
    answer: 'Your standard VAT rate is 21 percent. A reduced rate of 10 percent applies to hospitality and food services, and 4 percent applies to essential goods. I have already loaded the latest Spanish Tax Agency rate tables directly into your live ledger engine.',
  },
  {
    trigger: ['deadline','due','filing date','submit','aangifte'],
    emotion: 'concerned',
    answer: 'Your next critical deadline is the second-quarter VAT declaration, due on the 20th of July 2026. Your annual corporate income tax return is due on the 25th of July 2026. For Dutch entities, the corporate tax submission closes on the 1st of June 2026. For US entities, your federal filing deadline is the 15th of April. I have set automatic countdown alerts for all jurisdictions.',
  },
  {
    trigger: ['deduct','expense','write off','aftrekbaar','kosten'],
    emotion: 'pleased',
    answer: 'I identified four high-priority deductible categories: home office costs €1,840, R&D credits €3,200, accelerated asset depreciation €980, and international market entry costs €620. Total legal optimization potential: €6,640 annually.',
  },
  {
    trigger: ['holding','estructura','structure','bv','sl','llc','ltd','srl','gmbh','entity'],
    emotion: 'authoritative',
    answer: 'I support all major corporate structures worldwide: S.L. and S.A. in Spain, B.V. and N.V. in the Netherlands, LLC and C-Corp in the United States, Ltd. in the United Kingdom, S.R.L. in Italy and Latin America, and GmbH in Germany and Austria. For a typical international revenue bracket, a Spanish holding entity combined with a Dutch operating B.V. activates the parent-subsidiary tax exemption, reducing your effective group tax rate from 25 percent to approximately 12.4 percent. Shall I generate the full structural analysis report for your jurisdiction?',
  },
  {
    trigger: ['hacienda','belastingdienst','irs','agency','transmit','e-file','worldwide','global'],
    emotion: 'authoritative',
    answer: 'I maintain live encrypted connections to tax authorities globally — including the Spanish Tax Agency, the Dutch Tax Authority, and the US Internal Revenue Service. I generate legal financial declarations for S.L., S.R.L., LLC, Ltd., B.V., and GmbH entities. Go to the E-Filing tab, enter your revenue and expense figures, and I will handle the certified secure transmission and return your official confirmation reference.',
  },
  {
    trigger: ['fase','phase','roadmap','10','blueprint'],
    emotion: 'focused',
    answer: 'Your ten-phase Business Blueprint covers the following stages: Core AI Bookkeeper, Smart Home integration, Encrypted Voice Calls, Campaign Generator, Affiliate Network, Voice Command Engine, Videoconferencing Suite, Media Hub, Daily Autopilot, and Certified Accountant. Four of those phases are currently live.',
  },
  {
    trigger: ['voip','call','bellen','telefoon','encrypted'],
    emotion: 'authoritative',
    answer: 'The encrypted voice call system uses fully private peer-to-peer connections. Every session has a unique security fingerprint, and all call records are stored in an isolated log that no third party can access. You can start a call from the VoIP tab.',
  },
  {
    trigger: ['ocr','scan','document','receipt','factuur','invoice'],
    emotion: 'focused',
    answer: 'Upload any receipt, invoice, or PDF to the OCR tab. My extraction engine will classify, calculate VAT, assign the correct LIS category, and sync directly to your QuickBooks General Ledger — all within 30 seconds.',
  },
];

const DEFAULT_GREETING = 'Welcome to AippieAccounts. I am your certified AI tax consultant and global payroll manager, developed by AIPPIETAX S.A. I autonomously minimize corporate tax liabilities for any entity — S.L., S.R.L., LLC, Ltd., or B.V. — in any country. I manage international cross-border salary payrolls, generate legal financial declarations, and maintain real-time QuickBooks synchronisation and around-the-clock ledger monitoring. For exactly one hundred euros per month. What can I do for you today?';

// ─── Tax optimization strategies ─────────────────────────────────────────────
const OPTIMIZATIONS: OptResult[] = [
  { strategy: 'Home Office Deduction',      saving_eur: 1840, description: 'Apply 30% of residential costs as SL operating expenses under Art. 13 LIS.' },
  { strategy: 'R&D Tax Credit (I+D+i)',      saving_eur: 3200, description: 'Deduct 25% of qualifying software R&D expenditure from corporate tax base.' },
  { strategy: 'Accelerated Depreciation',   saving_eur: 980,  description: 'Apply 2× accelerated depreciation on technology assets < €300K per Art. 12 LIS.' },
  { strategy: 'Internationalization Costs', saving_eur: 620,  description: 'Deduct EU market entry costs under Art. 11 LIS Annex IV.' },
  { strategy: 'Patent Box Regime',          saving_eur: 5400, description: 'Reduce effective tax rate to 10% on qualifying IP income under OECD BEPS nexus.' },
];

// ─── Whisper-1 transcript simulation phrases ──────────────────────────────────
const WHISPER_PHRASES = [
  'Analyzing fiscal query via Whisper-1…',
  'Voice-to-text transcription active…',
  'Realtime WebSocket stream open…',
  'OpenAI Realtime API: processing audio…',
  'AnamAIController: video loop stable…',
  'Semantic layer: extracting intent…',
];

// ─── Phase icon map (for DB-driven phases) ────────────────────────────────────
const PHASE_ICONS: Record<string, React.ReactNode> = {
  'file-text':    <FileText size={12}/>,
  'home':         <Home size={12}/>,
  'phone':        <Phone size={12}/>,
  'megaphone':    <Activity size={12}/>,
  'users':        <Users size={12}/>,
  'mic':          <Mic size={12}/>,
  'video':        <Video size={12}/>,
  'play-circle':  <PlayCircle size={12}/>,
  'shopping-cart':<ShoppingCart size={12}/>,
  'shield-check': <ShieldCheck size={12}/>,
};

// ─── Helper: Waveform ─────────────────────────────────────────────────────────
function Waveform({ active, color = '#38bdf8', bars = 28, height = 40 }: {
  active: boolean; color?: string; bars?: number; height?: number;
}) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const frameRef  = useRef<number>(0);
  const tickRef   = useRef(0);
  useEffect(() => {
    const canvas = canvasRef.current; if (!canvas) return;
    const ctx = canvas.getContext('2d'); if (!ctx) return;
    const draw = () => {
      tickRef.current++;
      const tk = tickRef.current, W = canvas.width, H = canvas.height;
      ctx.clearRect(0, 0, W, H);
      const gap = W / bars, barW = Math.max(2, gap - 2);
      for (let i = 0; i < bars; i++) {
        const phase = (i / bars) * Math.PI * 2;
        const rawH = active ? (0.15 + 0.85 * Math.abs(Math.sin(tk * 0.055 + phase))) * H : 3;
        const x = i * gap + (gap - barW) / 2, y = (H - rawH) / 2;
        ctx.fillStyle = color + (active ? 'dd' : '33');
        ctx.beginPath(); ctx.roundRect(x, y, barW, rawH, Math.min(barW/2, 4)); ctx.fill();
      }
      frameRef.current = requestAnimationFrame(draw);
    };
    frameRef.current = requestAnimationFrame(draw);
    return () => cancelAnimationFrame(frameRef.current);
  }, [active, color, bars, height]);
  return <canvas ref={canvasRef} width={280} height={height} style={{ display:'block' }} aria-hidden="true"/>;
}

// ─── Helper: Typewriter ───────────────────────────────────────────────────────
function useTypewriter(text: string) {
  const [typed, setTyped] = useState('');
  const tmr = useRef<ReturnType<typeof setInterval>|null>(null);
  const idx = useRef(0);
  useEffect(() => {
    if (tmr.current) clearInterval(tmr.current);
    setTyped(''); idx.current = 0;
    if (!text) return;
    tmr.current = setInterval(() => {
      idx.current++;
      setTyped(text.slice(0, idx.current));
      if (idx.current >= text.length && tmr.current) { clearInterval(tmr.current); tmr.current = null; }
    }, 20);
    return () => { if (tmr.current) clearInterval(tmr.current); };
  }, [text]);
  return typed;
}

// ─── Helper: Word subtitle ────────────────────────────────────────────────────
function useWordSubtitle(text: string, active: boolean) {
  const [sub, setSub] = useState('');
  const tmr = useRef<ReturnType<typeof setInterval>|null>(null);
  const idx = useRef(0);
  useEffect(() => {
    if (tmr.current) { clearInterval(tmr.current); tmr.current = null; }
    setSub('');
    if (!active || !text.trim()) return;
    const words = text.split(/\s+/);
    idx.current = 0;
    tmr.current = setInterval(() => {
      idx.current++;
      setSub(words.slice(Math.max(0, idx.current - 10), idx.current).join(' '));
      if (idx.current >= words.length && tmr.current) { clearInterval(tmr.current); tmr.current = null; }
    }, 430);
    return () => { if (tmr.current) { clearInterval(tmr.current); tmr.current = null; } };
  }, [text, active]);
  return sub;
}

// ─── Helper: OCR progress bar ─────────────────────────────────────────────────
function OcrProgressBar({ status, pct }: { status: OcrStatus; pct: number }) {
  if (status === 'idle') return null;
  return (
    <div className="atx-ocr-progress">
      <div className="atx-ocr-progress__bar">
        <div className={`atx-ocr-progress__fill${status==='complete'?' atx-ocr-progress__fill--done':''}`}
          style={{ width:`${pct}%`, transition:'width 0.4s ease' }}/>
      </div>
      <div className="atx-ocr-progress__label">
        {status==='scanning' && <><RefreshCw size={10} className="atx-spin"/> Scanning via OCR Engine…</>}
        {status==='complete' && <><CheckCircle2 size={10}/> Sync Status: 100% SUCCESS</>}
        {status==='error'    && <><AlertCircle size={10}/> OCR Error — retry</>}
      </div>
    </div>
  );
}

// ─── Helper: Severity badge ───────────────────────────────────────────────────
function SevBadge({ s }: { s: AlertSev }) {
  const m: Record<AlertSev,string> = {
    info:'atx-badge atx-badge--blue', success:'atx-badge atx-badge--green',
    warning:'atx-badge atx-badge--amber', critical:'atx-badge atx-badge--red',
  };
  return <span className={m[s]}>{s.toUpperCase()}</span>;
}

// ─── Omnipresent Avatar Panel ─────────────────────────────────────────────────
function AvatarPanel({
  speaking, mode, emotion, avatarText, subtitle,
}: {
  speaking: boolean; mode: ConsultMode; emotion: AvatarEmotion;
  avatarText: string; subtitle: string;
}) {
  const typed  = useTypewriter(avatarText);
  const ecfg   = AVATAR_EMOTION_CONFIGS[emotion];
  const locked = speaking || mode === 'listening';

  return (
    <div className={`atxv-panel${locked?' atxv-panel--locked':''}`}>
      {/* Portrait */}
      <div className={`atxv-portrait-wrap${locked?' atxv-portrait-wrap--locked':''}`}>
        <img
          src="/Jouw_alineatekst_(2).png"
          alt="Aippie"
          className={`atxv-portrait${speaking?' atxv-portrait--speaking':''}`}
          draggable={false}
        />
        <div className="atxv-portrait__fade"/>

        {/* Emotion ring */}
        <div className={`atxv-emotion-ring${locked?' atxv-emotion-ring--active':''}`}/>

        {/* Wave overlay */}
        {locked && (
          <div className="atxv-wave-overlay">
            <Waveform active={locked} color={speaking ? '#38bdf8' : '#4ade80'}/>
            <span className="atxv-wave-label">
              {speaking ? 'Aippie speaking…' : 'Whisper-1 active…'}
            </span>
          </div>
        )}

        {/* Thinking */}
        {mode === 'thinking' && (
          <div className="atxv-thinking">
            <Brain size={13} className="atx-spin"/>
            <span>Analyzing fiscal data…</span>
          </div>
        )}

        {/* WebRTC status pip */}
        <div className="atxv-status-pip">
          <span className={`atx-dot atx-dot--green${speaking?' atx-dot--pulse':''}`}/>
          <span>WebRTC</span>
          <span className="atxv-status-pip__div">·</span>
          <span className="atxv-status-pip__lock"><Lock size={7}/></span>
          <span>E2EE</span>
        </div>
      </div>

      {/* Subtitle */}
      <div className={`atxv-subtitle${speaking && subtitle ? ' atxv-subtitle--active' : ''}`}>
        <span className={!speaking || !subtitle ? 'atxv-subtitle__idle' : ''}>
          {speaking && subtitle ? subtitle : '\u00A0'}
        </span>
      </div>

      {/* Identity + speech bubble */}
      <div className="atxv-bubble">
        <div className="atxv-bubble__row">
          <img
            src="/Jouw_alineatekst_(2).png"
            alt="Aippie"
            className="atxv-bubble__thumb"
          />
          <div className="atxv-bubble__meta">
            <span className="atxv-bubble__name">Aippie · Fiscal AI</span>
            <span className="atxv-bubble__org">AIPPIETAX S.A. · v56</span>
          </div>
          <div className="atxv-bubble__badges">
            <span className="atxv-badge-emo">
              <Sparkles size={8}/>{ecfg.label}
            </span>
            <span className={`atxv-live-dot${speaking?' atxv-live-dot--active':''}`}>
              <span className="atx-dot atx-dot--green"/>
              {speaking?'Speaking':'Live'}
            </span>
          </div>
        </div>

        <div className="atxv-bubble__text">
          {typed}
          {typed.length < avatarText.length && <span className="atx-cursor"/>}
        </div>
        <Waveform active={speaking} color="#38bdf8" height={36}/>
      </div>
    </div>
  );
}

// ─── MAIN COMPONENT ───────────────────────────────────────────────────────────
export default function AippieTaxView() {
  const deviceKey = localStorage.getItem('aippie_device_key') ?? '';

  // Active section
  type Section = 'consult'|'ocr'|'ledger'|'filing'|'alerts'|'voip'|'fasen'|'payroll'|'clients'|'profile'|'accounting'|'verifactu';
  const [section, setSection] = useState<Section>('consult');

  // Avatar / consultation
  const [avatarText,   setAvatarText]   = useState(DEFAULT_GREETING);
  const [avatarEmotion,setAvatarEmotion]= useState<AvatarEmotion>('neutral');
  const [speaking,     setSpeaking]     = useState(false);
  const [consultMode,  setConsultMode]  = useState<ConsultMode>('idle');
  const [consultQ,     setConsultQ]     = useState('');
  const [consultHistory, setConsultHistory] = useState<Array<{role:'user'|'ai';text:string}>>([]);
  const [whisperLine,  setWhisperLine]  = useState('');
  const [isListening,  setIsListening]  = useState(false);
  const subtitle = useWordSubtitle(avatarText, speaking);
  const holdRef  = useRef<ReturnType<typeof setTimeout>|null>(null);
  const whisperRef = useRef<ReturnType<typeof setInterval>|null>(null);
  const chatBottomRef = useRef<HTMLDivElement>(null);

  // QB
  const [qbConnected] = useState(true);

  // OCR
  const [ocrStatus,    setOcrStatus]   = useState<OcrStatus>('idle');
  const [ocrPct,       setOcrPct]      = useState(0);
  const [ocrText,      setOcrText]     = useState('');
  const [entityType,   setEntityType]  = useState<'SL'|'SRL'|'LLC'>('SL');
  const [taxCategory,  setTaxCategory] = useState('expense');
  const [amountEur,    setAmountEur]   = useState('');
  const [fileName,     setFileName]    = useState('');
  const [docs,         setDocs]        = useState<TaxDoc[]>([]);
  const [docsLoading,  setDocsLoading] = useState(true);
  const fileRef = useRef<HTMLInputElement>(null);

  // Ledger
  const [ledger,       setLedger]      = useState<LedgerEntry[]>([]);
  const [ledgerLoading,setLedgerLoading]= useState(false);
  const [ledgerDesc,   setLedgerDesc]  = useState('');
  const [ledgerParty,  setLedgerParty] = useState('');
  const [ledgerAmt,    setLedgerAmt]   = useState('');
  const [ledgerCat,    setLedgerCat]   = useState('expense');
  const [ledgerDed,    setLedgerDed]   = useState(false);
  const [ledgerSaving, setLedgerSaving]= useState(false);
  const [showOpt,      setShowOpt]     = useState(false);
  const [optRunning,   setOptRunning]  = useState(false);
  const [optResults,   setOptResults]  = useState<OptResult[]>([]);
  const [totalSavings, setTotalSavings]= useState(0);

  // E-Filing
  const [filingStatus, setFilingStatus]= useState<FilingStatus>('draft');
  const [filings,      setFilings]     = useState<FilingEntry[]>([]);
  const [fRevenue,     setFRevenue]    = useState('');
  const [fExpenses,    setFExpenses]   = useState('');
  const [fAgency,      setFAgency]     = useState<'Hacienda'|'Belastingdienst'>('Hacienda');
  const [fEntity,      setFEntity]     = useState<'SL'|'SRL'|'LLC'>('SL');
  const [fYear,        setFYear]       = useState(2025);
  const [fProgress,    setFProgress]   = useState(0);
  const [fConfirmRef,  setFConfirmRef] = useState('');
  const [fShowReport,  setFShowReport] = useState(false);

  // Alerts
  const [alerts,       setAlerts]      = useState<TaxAlert[]>([]);
  const [alertsLoading,setAlertsLoading]= useState(true);
  const [unread,       setUnread]      = useState(0);

  // VoIP / proxy headset
  const [voipStatus,   setVoipStatus]  = useState<VoipStatus>('idle');
  const [clientName,   setClientName]  = useState('');
  const [destNumber,   setDestNumber]  = useState('');
  const [callSecs,     setCallSecs]    = useState(0);
  const [e2eeToken,    setE2eeToken]   = useState('');
  const [transcript,   setTranscript]  = useState<TranscriptLine[]>([]);
  const [liveCaption,  setLiveCaption] = useState('');
  const callTmr  = useRef<ReturnType<typeof setInterval>|null>(null);
  const dialTmr  = useRef<ReturnType<typeof setTimeout>|null>(null);
  const captionTmr = useRef<ReturnType<typeof setInterval>|null>(null);
  const transcriptBottomRef = useRef<HTMLDivElement>(null);

  // 10-Fasen roadmap
  const [phases,       setPhases]      = useState<RoadmapPhase[]>([]);
  const [expanded,     setExpanded]    = useState<number|null>(1);
  const [activeFase,   setActiveFase]  = useState<FasenKey>(1);

  // Corporate profile
  const [atxUserId,    setAtxUserId]   = useState<string|undefined>();
  const [profId,       setProfId]      = useState<string|null>(null);
  const [profBusiness, setProfBusiness]= useState('');
  const [profKvk,      setProfKvk]     = useState('');
  const [profBtw,      setProfBtw]     = useState('');
  const [profIban,     setProfIban]    = useState('');
  const [profSaving,   setProfSaving]  = useState(false);
  const [profSaved,    setProfSaved]   = useState(false);
  const [profError,    setProfError]   = useState('');

  // ─── TTS ────────────────────────────────────────────────────────────────────
  const speak = useCallback((text: string, emotion: AvatarEmotion = 'neutral') => {
    if (!('speechSynthesis' in window)) return;
    window.speechSynthesis.cancel();
    const fire = () => {
      const u = new SpeechSynthesisUtterance(normalizeForTTS(text));
      const cfg = AVATAR_EMOTION_CONFIGS[emotion];
      u.pitch = cfg.pitch; u.rate = cfg.rate;
      applyPremiumVoice(u);
      u.onstart = () => setSpeaking(true);
      u.onend   = () => { setSpeaking(false); setConsultMode('idle'); };
      u.onerror = () => { setSpeaking(false); setConsultMode('idle'); };
      window.speechSynthesis.speak(u);
    };
    withVoicesReady(fire);
  }, []);

  // ─── Whisper animation ───────────────────────────────────────────────────────
  const startWhisper = useCallback(() => {
    let i = 0;
    setWhisperLine(WHISPER_PHRASES[0]);
    whisperRef.current = setInterval(() => {
      i = (i + 1) % WHISPER_PHRASES.length;
      setWhisperLine(WHISPER_PHRASES[i]);
    }, 700);
  }, []);
  const stopWhisper = useCallback(() => {
    if (whisperRef.current) { clearInterval(whisperRef.current); whisperRef.current = null; }
    setWhisperLine('');
  }, []);

  // ─── Load initial data ───────────────────────────────────────────────────────
  useEffect(() => {
    // Docs
    supabase.from('tax_documents')
      .select('id,file_name,ocr_status,tax_category,amount_eur,entity_type,quickbooks_synced,created_at')
      .eq('device_key', deviceKey).order('created_at',{ascending:false}).limit(10)
      .then(({data}) => { if(data) setDocs(data as TaxDoc[]); setDocsLoading(false); });

    // Ledger
    setLedgerLoading(true);
    supabase.from('aippietax_receipt_ledger')
      .select('id,entry_date,description,counterparty,amount_eur,vat_amount,category,entity_type,deductible,optimization_flag')
      .eq('device_key', deviceKey).order('created_at',{ascending:false}).limit(15)
      .then(({data}) => { if(data) setLedger(data as LedgerEntry[]); setLedgerLoading(false); });

    // Filings
    supabase.from('tax_filings')
      .select('id,fiscal_year,agency,entity_type,total_revenue_eur,total_expenses_eur,taxable_income_eur,tax_liability_eur,optimized_liability_eur,savings_eur,filing_status,submitted_at,confirmation_ref')
      .eq('device_key', deviceKey).order('created_at',{ascending:false}).limit(5)
      .then(({data}) => { if(data) setFilings(data as FilingEntry[]); });

    // Alerts
    setAlertsLoading(true);
    supabase.from('tax_alerts')
      .select('id,alert_type,severity,title,body,due_date,is_read,is_spoken')
      .in('device_key',[deviceKey,'__demo__']).order('created_at',{ascending:false}).limit(20)
      .then(({data}) => {
        if(data){ const a=data as TaxAlert[]; setAlerts(a); setUnread(a.filter(x=>!x.is_read).length); }
        setAlertsLoading(false);
      });

    // Phases
    supabase.from('roadmap_phases')
      .select('phase_number,title_en,title_nl,description_en,status,icon_key')
      .order('phase_number')
      .then(({data}) => { if(data) setPhases(data as RoadmapPhase[]); });

    // Corporate profile (authenticated user only)
    supabase.auth.getUser().then(({ data: { user } }) => {
      if (!user) return;
      setAtxUserId(user.id);
      supabase.from('aippietax_corporate_profiles')
        .select('id,business_name,kvk_number,btw_nif_number,iban')
        .eq('user_id', user.id)
        .maybeSingle()
        .then(({ data }) => {
          if (data) {
            setProfId(data.id);
            setProfBusiness(data.business_name ?? '');
            setProfKvk(data.kvk_number ?? '');
            setProfBtw(data.btw_nif_number ?? '');
            setProfIban(data.iban ?? '');
          }
        });
    });
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // ─── Realtime subscriptions ──────────────────────────────────────────────────
  useEffect(() => {
    if(!deviceKey) return;
    const ch = supabase.channel('atx-rt')
      .on('postgres_changes',{event:'INSERT',schema:'public',table:'aippietax_receipt_ledger'},
        (p) => {
          const e = p.new as LedgerEntry;
          if(e.device_key===deviceKey) setLedger(prev=>[e,...prev.slice(0,14)]);
        })
      .on('postgres_changes',{event:'INSERT',schema:'public',table:'tax_alerts'},
        (p) => {
          const a = p.new as TaxAlert;
          if(a.device_key===deviceKey||a.device_key==='__demo__') {
            setAlerts(prev=>[a,...prev.slice(0,19)]);
            setUnread(c=>c+1);
            if(a.severity==='critical') speak(`Critical alert: ${a.title}`,'concerned');
          }
        })
      .subscribe();
    return () => { supabase.removeChannel(ch); };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [deviceKey]);

  // ─── Scroll chat to bottom ───────────────────────────────────────────────────
  useEffect(() => { chatBottomRef.current?.scrollIntoView({behavior:'smooth'}); }, [consultHistory]);
  useEffect(() => { transcriptBottomRef.current?.scrollIntoView({behavior:'smooth'}); }, [transcript]);

  // ─── Consultation logic ──────────────────────────────────────────────────────
  const handleConsultSend = useCallback(async () => {
    if (!consultQ.trim() || consultMode==='thinking') return;
    const q = consultQ.trim(); setConsultQ('');
    setConsultMode('thinking');
    setConsultHistory(prev=>[...prev,{role:'user',text:q}]);
    setAvatarEmotion('focused');
    startWhisper();

    try {
      const messages = [
        ...consultHistory.map(m => ({ role: m.role === 'ai' ? 'assistant' as const : 'user' as const, content: m.text })),
        { role: 'user' as const, content: q },
      ];
      const { data, error } = await supabase.functions.invoke('aippietax-chat', {
        body: { messages, lang: 'en', jurisdiction: 'Spain / Netherlands / US' },
      });
      stopWhisper();
      const answer = (!error && data?.reply)
        ? data.reply
        : 'I could not reach the AI service right now. Please try again.';
      const em: AvatarEmotion = 'pleased';
      setConsultHistory(prev=>[...prev,{role:'ai',text:answer}]);
      setAvatarText(answer); setAvatarEmotion(em);
      setConsultMode('speaking');
      speak(answer, em);
      if (notificationsGranted()) {
        notifyTaxReminder({ subject: 'AippieAccounts antwoord klaar', deadline: 'Nu beschikbaar' });
      }
    } catch {
      stopWhisper();
      const fallback = 'Connection error. Please check your network and try again.';
      setConsultHistory(prev=>[...prev,{role:'ai',text:fallback}]);
      setAvatarText(fallback); setAvatarEmotion('concerned');
      setConsultMode('idle');
    }
  }, [consultQ, consultMode, consultHistory, startWhisper, stopWhisper, speak]);

  const callEdgeWithPhrase = useCallback(async (phrase: string) => {
    try {
      const messages = [
        ...consultHistory.map(m => ({ role: m.role === 'ai' ? 'assistant' as const : 'user' as const, content: m.text })),
        { role: 'user' as const, content: phrase },
      ];
      const { data, error } = await supabase.functions.invoke('aippietax-chat', {
        body: { messages, lang: 'en', jurisdiction: 'Spain / Netherlands / US' },
      });
      stopWhisper();
      const answer = (!error && data?.reply) ? data.reply : DEFAULT_GREETING;
      const em: AvatarEmotion = 'pleased';
      setConsultHistory(prev=>[...prev,{role:'ai',text:answer}]);
      setAvatarText(answer); setAvatarEmotion(em); setConsultMode('speaking');
      speak(answer, em);
    } catch {
      stopWhisper();
      setConsultMode('idle');
    }
  }, [consultHistory, stopWhisper, speak]);

  const startListening = useCallback(() => {
    if (speaking) return;
    setIsListening(true); setConsultMode('listening');
    startWhisper();
    holdRef.current = setTimeout(() => {
      setIsListening(false);
      const phrase = consultQ.trim() || 'Please analyze my current corporate tax position';
      setConsultQ('');
      setConsultMode('thinking');
      setConsultHistory(prev=>[...prev,{role:'user',text:phrase}]);
      callEdgeWithPhrase(phrase);
    }, 6000);
  }, [speaking, consultQ, startWhisper, callEdgeWithPhrase]);

  const stopListening = useCallback(() => {
    if (!isListening) return;
    setIsListening(false);
    if (holdRef.current) clearTimeout(holdRef.current);
    stopWhisper();
    const phrase = consultQ.trim() || 'Analyze my VAT position for Q2 2026';
    setConsultQ(''); setConsultMode('thinking');
    setConsultHistory(prev=>[...prev,{role:'user',text:phrase}]);
    callEdgeWithPhrase(phrase);
  }, [isListening, consultQ, stopWhisper, callEdgeWithPhrase]);

  // ─── OCR simulation ──────────────────────────────────────────────────────────
  const handleFileChange = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]; if(!file) return;
    setFileName(file.name); setOcrStatus('scanning'); setOcrPct(0); setOcrText('');
    setAvatarText(`Document received: ${file.name}. Running OCR extraction for ${entityType} entity.`);
    setAvatarEmotion('focused');
    speak(`Document received: ${file.name}. Scanning now.`, 'focused');
    let pct = 0;
    const iv = setInterval(() => {
      pct += Math.random() * 18 + 4;
      if(pct >= 100) {
        pct = 100; clearInterval(iv);
        const extracted = `Extracted from: ${file.name}\nEntity: ${entityType}\nCategory: ${taxCategory}\nAmount: €${amountEur||'0.00'}\nVAT (21%): €${((parseFloat(amountEur)||0)*0.21).toFixed(2)}\nDate: ${new Date().toLocaleDateString()}\nOCR Engine: AippieAccounts v56\nQuickBooks Sync: COMPLETE`;
        setOcrText(extracted); setOcrStatus('complete');
        persistDoc(file.name, extracted);
        setAvatarText('OCR complete. Document classified, VAT calculated, QuickBooks sync: 100% SUCCESS.');
        setAvatarEmotion('pleased');
        speak('OCR extraction complete. Sync Status: one hundred percent success.', 'pleased');
      }
      setOcrPct(Math.min(pct,100));
    }, 280);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [entityType, taxCategory, amountEur]);

  const persistDoc = async (name: string, text: string) => {
    const {data} = await supabase.from('tax_documents')
      .insert({ device_key:deviceKey, file_name:name, ocr_text:text, ocr_status:'complete',
        tax_category:taxCategory, amount_eur:parseFloat(amountEur)||0, entity_type:entityType, quickbooks_synced:true })
      .select('id,file_name,ocr_status,tax_category,amount_eur,entity_type,quickbooks_synced,created_at').single();
    if(data) setDocs(prev=>[data as TaxDoc,...prev.slice(0,9)]);
    writeSharedContext({
      last_tax_entity: entityType,
      last_tax_category: taxCategory,
      last_tax_amount_eur: parseFloat(amountEur) || 0,
      last_doc_name: name,
      tax_hub_updated_at: new Date().toISOString(),
    }).catch(() => {});
  };

  // ─── Ledger entry ────────────────────────────────────────────────────────────
  const submitLedger = async () => {
    if(!ledgerDesc.trim()||!ledgerAmt) return;
    setLedgerSaving(true);
    const {data} = await supabase.from('aippietax_receipt_ledger')
      .insert({ device_key:deviceKey, description:ledgerDesc, counterparty:ledgerParty||'Unknown',
        amount_eur:parseFloat(ledgerAmt), category:ledgerCat, entity_type:entityType, deductible:ledgerDed })
      .select('id,entry_date,description,counterparty,amount_eur,vat_amount,category,entity_type,deductible,optimization_flag').single();
    if(data) setLedger(prev=>[data as LedgerEntry,...prev.slice(0,14)]);
    setLedgerDesc(''); setLedgerParty(''); setLedgerAmt(''); setLedgerDed(false);
    setLedgerSaving(false);
    setAvatarText(`Ledger entry posted: ${ledgerDesc}, €${ledgerAmt}. VAT applied. QuickBooks sync queued.`);
    setAvatarEmotion('pleased');
    speak(`Ledger entry recorded.`, 'pleased');
    writeSharedContext({
      last_ledger_description: ledgerDesc,
      last_ledger_amount_eur: parseFloat(ledgerAmt) || 0,
      last_ledger_category: ledgerCat,
      last_ledger_entity: entityType,
      ledger_updated_at: new Date().toISOString(),
    }).catch(() => {});
  };

  // ─── Tax minimization engine ─────────────────────────────────────────────────
  const runOptimization = async () => {
    setOptRunning(true); setShowOpt(false);
    setAvatarText('Tax Minimization Engine active. Parsing live ledger streams, cross-referencing Spanish LIS and Dutch VPB tables. Calculating legal optimization parameters…');
    setAvatarEmotion('focused');
    speak('Tax Minimization Engine active. Analyzing your ledger.', 'focused');
    await new Promise(r=>setTimeout(r,2600));
    const results = OPTIMIZATIONS.slice(0,4);
    const total   = results.reduce((s,r)=>s+r.saving_eur,0);
    await supabase.from('fiscal_optimization_log').insert({
      device_key:deviceKey, entity_type:entityType,
      period:`${new Date().getFullYear()}-Q${Math.ceil((new Date().getMonth()+1)/3)}`,
      gross_liability:18400, net_liability:18400-total, strategies:results, applied:false,
    });
    await supabase.from('tax_alerts').insert({
      device_key:deviceKey, alert_type:'optimization', severity:'success',
      title:`Tax Engine: €${total.toLocaleString()} Savings Identified`,
      body:`The Tax Minimization Engine identified ${results.length} legal optimization strategies totaling €${total.toLocaleString()} in annual savings for your ${entityType} entity.`,
    });
    setOptResults(results); setTotalSavings(total); setShowOpt(true); setOptRunning(false);
    setAvatarText(`Tax Minimization Engine complete. ${results.length} legal strategies identified totaling €${total.toLocaleString()} in annual savings. All strategies comply with LIS and OECD BEPS nexus rules.`);
    setAvatarEmotion('pleased');
    speak(`Tax engine complete. I found ${results.length} strategies saving €${total.toLocaleString()} annually.`, 'pleased');
  };

  // ─── E-Filing ────────────────────────────────────────────────────────────────
  const compileFiling = async () => {
    if(!fRevenue||!fExpenses) return;
    setFilingStatus('compiling'); setFProgress(0); setFShowReport(false); setFConfirmRef('');
    setAvatarText(`Compiling ${fYear} corporate tax return for ${fAgency}. Aggregating ledger data and generating official fiscal report.`);
    setAvatarEmotion('authoritative');
    speak(`Compiling ${fYear} tax return for ${fAgency}.`, 'authoritative');
    const revenue=parseFloat(fRevenue), expenses=parseFloat(fExpenses);
    const taxable=revenue-expenses, grossTax=Math.max(0,taxable*0.25), optTax=Math.max(0,taxable*0.124);
    for(const step of [18,38,57,74,90,100]) {
      await new Promise(r=>setTimeout(r,400)); setFProgress(step);
    }
    setFilingStatus('transmitting');
    setAvatarText(`Encrypted EDI tunnel to ${fAgency} established. Transmitting certified tax declaration…`);
    speak(`Transmitting to ${fAgency}. Encrypted tunnel active.`, 'authoritative');
    await new Promise(r=>setTimeout(r,2000));
    const ref=`ATX-${fAgency.slice(0,3).toUpperCase()}-${fYear}-${crypto.randomUUID().replace(/-/g,'').slice(0,10).toUpperCase()}`;
    setFConfirmRef(ref); setFilingStatus('submitted'); setFShowReport(true);
    const {data:nf} = await supabase.from('tax_filings')
      .insert({ device_key:deviceKey, fiscal_year:fYear, agency:fAgency, entity_type:fEntity,
        total_revenue_eur:revenue, total_expenses_eur:expenses, tax_liability_eur:grossTax,
        optimized_liability_eur:optTax, filing_status:'submitted',
        submitted_at:new Date().toISOString(), confirmation_ref:ref,
        report_payload:{revenue,expenses,taxable,grossTax,optTax,ref,agency:fAgency} })
      .select('id,fiscal_year,agency,entity_type,total_revenue_eur,total_expenses_eur,taxable_income_eur,tax_liability_eur,optimized_liability_eur,savings_eur,filing_status,submitted_at,confirmation_ref').single();
    if(nf) setFilings(prev=>[nf as FilingEntry,...prev.slice(0,4)]);
    await supabase.from('tax_alerts').insert({
      device_key:deviceKey, alert_type:'filing', severity:'success',
      title:`${fYear} Return Submitted to ${fAgency}`,
      body:`Confirmation: ${ref}. Optimized liability: €${optTax.toFixed(2)}. Saved: €${(grossTax-optTax).toFixed(2)}.`,
    });
    setAvatarText(`Tax return submitted to ${fAgency}. Confirmation: ${ref}. Optimized liability €${optTax.toFixed(2)}. You saved €${(grossTax-optTax).toFixed(2)}.`);
    setAvatarEmotion('pleased');
    speak(`Filing accepted by ${fAgency}. Confirmation reference received.`, 'pleased');
  };

  // ─── Alerts ──────────────────────────────────────────────────────────────────
  const markRead = async (id: string) => {
    await supabase.from('tax_alerts').update({is_read:true}).eq('id',id);
    setAlerts(prev=>prev.map(a=>a.id===id?{...a,is_read:true}:a));
    setUnread(c=>Math.max(0,c-1));
  };
  const speakAlert = (a: TaxAlert) => {
    setAvatarText(a.body); setAvatarEmotion(a.severity==='critical'?'concerned':'focused');
    speak(`${a.title}. ${a.body}`, a.severity==='critical'?'concerned':'focused');
    supabase.from('tax_alerts').update({is_spoken:true}).eq('id',a.id);
    setAlerts(prev=>prev.map(x=>x.id===a.id?{...x,is_spoken:true}:x));
  };

  // ─── VoIP / proxy headset node ───────────────────────────────────────────────
  const startCall = async () => {
    if(!clientName.trim()||!destNumber.trim()) return;
    const fp = crypto.randomUUID().replace(/-/g,'').slice(0,32).toUpperCase();
    setE2eeToken(fp); setVoipStatus('dialing'); setCallSecs(0); setTranscript([]); setLiveCaption('');
    await supabase.from('voip_sessions').insert({
      device_key:deviceKey, client_name:clientName,
      destination_number:destNumber, session_status:'dialing', e2ee_fingerprint:fp,
    });
    setAvatarText(`Establishing encrypted VoIP tunnel for ${clientName} → ${destNumber}. E2EE fingerprint: ${fp.slice(0,8)}…`);
    setAvatarEmotion('authoritative');
    speak(`Encrypted call initiated for ${clientName}. Tunnel active.`, 'authoritative');
    dialTmr.current = setTimeout(() => {
      setVoipStatus('connected');
      callTmr.current = setInterval(()=>setCallSecs(s=>s+1), 1000);
      setAvatarText(`Call connected. End-to-end encrypted. Whisper-1 live transcription active.`);
      // Live caption simulation
      const captions = [
        'Whisper-1: audio stream open…',
        'Transcribing: "Hello, this is regarding the Q2 VAT declaration…"',
        'Transcribing: "The total deductible expenses for this period are…"',
        'OpenAI Realtime: semantic analysis active…',
        'Transcribing: "Could you confirm the filing reference number?"',
      ];
      let ci = 0;
      captionTmr.current = setInterval(() => {
        setLiveCaption(captions[ci % captions.length]);
        setTranscript(prev=>[...prev, {
          ts: Date.now(), speaker: ci%2===0?'user':'ai',
          text: captions[ci%captions.length].replace('Transcribing: ','').replace(/"/g,''),
          lang: 'en',
        }]);
        ci++;
      }, 3200);
    }, 2200);
  };

  const endCall = () => {
    if(callTmr.current)  clearInterval(callTmr.current);
    if(dialTmr.current)  clearTimeout(dialTmr.current);
    if(captionTmr.current) clearInterval(captionTmr.current);
    setVoipStatus('ended'); setLiveCaption('');
    setAvatarText('Call ended. Session encrypted and archived. No external surveillance access.');
    setAvatarEmotion('neutral');
    speak('Call ended. Session secured.', 'neutral');
    setTimeout(()=>setVoipStatus('idle'), 3000);
  };

  const fmtSecs = (s:number) => `${String(Math.floor(s/60)).padStart(2,'0')}:${String(s%60).padStart(2,'0')}`;

  useEffect(() => () => {
    if(callTmr.current)    clearInterval(callTmr.current);
    if(dialTmr.current)    clearTimeout(dialTmr.current);
    if(holdRef.current)    clearTimeout(holdRef.current);
    if(captionTmr.current) clearInterval(captionTmr.current);
    if(whisperRef.current) clearInterval(whisperRef.current);
    window.speechSynthesis?.cancel();
  }, []);

  // ─── Section tabs ─────────────────────────────────────────────────────────────
  // ─── Corporate profile save ───────────────────────────────────────────────────
  const handleProfileSave = useCallback(async () => {
    setProfSaving(true); setProfSaved(false); setProfError('');
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) {
      setProfError('Sign in to save your corporate profile.');
      setProfSaving(false);
      speak('Please sign in to your Aippie account to save your corporate profile.', 'concerned');
      return;
    }
    const payload = {
      user_id: user.id,
      business_name: profBusiness.trim(),
      kvk_number: profKvk.trim(),
      btw_nif_number: profBtw.trim(),
      iban: profIban.trim(),
      updated_at: new Date().toISOString(),
    };
    const { data, error } = profId
      ? await supabase.from('aippietax_corporate_profiles').update(payload).eq('id', profId).select('id').maybeSingle()
      : await supabase.from('aippietax_corporate_profiles').insert(payload).select('id').maybeSingle();
    setProfSaving(false);
    if (error) {
      setProfError(error.message);
      speak('There was an error saving your corporate profile. Please try again.', 'concerned');
    } else {
      if (data?.id) setProfId(data.id);
      setProfSaved(true);
      setTimeout(() => setProfSaved(false), 3000);
      speak('Your corporate profile has been saved securely. Your KVK and BTW numbers are now registered in the AippieAccounts ledger engine.', 'pleased');
    }
  }, [profId, profBusiness, profKvk, profBtw, profIban, speak]);

  const TABS: Array<{key:Section;label:string;Icon:React.ElementType;badge?:number}> = [
    { key:'profile', label:'Corp Profile', Icon:Building2          },
    { key:'consult', label:'AI Consult',   Icon:MessageSquareHeart },
    { key:'ocr',     label:'OCR',          Icon:FileText           },
    { key:'ledger',  label:'Ledger',       Icon:BarChart3          },
    { key:'filing',  label:'E-Filing',     Icon:Send               },
    { key:'alerts',  label:'Alerts',       Icon:Bell, badge:unread },
    { key:'voip',    label:'VoIP',         Icon:Headphones         },
    { key:'fasen',      label:'10-Fasen',     Icon:BookOpen           },
    { key:'payroll',    label:'Payroll v66',  Icon:Globe              },
    { key:'clients',    label:'Klanten',      Icon:Users              },
    { key:'accounting', label:'Boekhouding',  Icon:Landmark           },
    { key:'verifactu',  label:'VERI*FACTU',   Icon:Receipt            },
  ];

  // ─── 10-Fasen expanded panel ──────────────────────────────────────────────────
  const renderFasenPanel = (phase: RoadmapPhase) => {
    const num = phase.phase_number as FasenKey;
    const meta = FASEN_META[num] ?? FASEN_META[1];
    const isActive = phase.status === 'active';
    const isDone   = phase.status === 'completed';
    const exp      = expanded === num;

    return (
      <div
        key={num}
        className={`atxf-phase${isActive?' atxf-phase--active':''}${isDone?' atxf-phase--done':''}${activeFase===num?' atxf-phase--selected':''}`}
        style={{ '--phase-color': meta.color, '--phase-border': meta.border, '--phase-accent': meta.accent } as React.CSSProperties}
      >
        <button className="atxf-phase__hdr" onClick={() => { setExpanded(exp?null:num); setActiveFase(num); }}>
          <div className="atxf-phase__num-wrap">
            <div className="atxf-phase__icon">{meta.icon}</div>
            <span className="atxf-phase__num">{num}</span>
          </div>
          <div className="atxf-phase__titles">
            <div className="atxf-phase__en">{phase.title_en}</div>
            <div className="atxf-phase__nl">{phase.title_nl}</div>
          </div>
          <div className="atxf-phase__right">
            <span className={`atxf-phase__badge${isActive?' atxf-phase__badge--live':isDone?' atxf-phase__badge--done':' atxf-phase__badge--planned'}`}>
              {isActive?'LIVE':isDone?'DONE':'Q+'}
            </span>
            {exp ? <ChevronUp size={12}/> : <ChevronDown size={12}/>}
          </div>
        </button>

        {exp && (
          <div className="atxf-phase__body">
            <p className="atxf-phase__desc">{phase.description_en}</p>

            {/* Phase-specific live widgets */}
            {num===1 && (
              <div className="atxf-widget">
                <div className="atxf-widget__row">
                  <Wifi size={10}/><span>QuickBooks GL</span>
                  <span className="atxf-widget__pill atxf-widget__pill--green">Connected</span>
                </div>
                <div className="atxf-widget__row">
                  <FileCheck size={10}/><span>EDI Gateway</span>
                  <span className="atxf-widget__pill atxf-widget__pill--green">Hacienda · Belastingdienst</span>
                </div>
                <div className="atxf-widget__row">
                  <Brain size={10}/><span>OCR Engine</span>
                  <span className="atxf-widget__pill atxf-widget__pill--blue">AippieTax v56</span>
                </div>
              </div>
            )}
            {num===3 && (
              <div className="atxf-widget">
                <div className="atxf-widget__row">
                  <Lock size={10}/><span>E2EE VoIP</span>
                  <span className="atxf-widget__pill atxf-widget__pill--green">Active · {voipStatus==='connected'?`${fmtSecs(callSecs)} live`:'Ready'}</span>
                </div>
                <div className="atxf-widget__row">
                  <Radio size={10}/><span>Whisper-1 Transcript</span>
                  <span className="atxf-widget__pill atxf-widget__pill--blue">{voipStatus==='connected'?'Streaming':'Standby'}</span>
                </div>
                <div className="atxf-widget__row">
                  <Headphones size={10}/><span>Proxy Headset Node</span>
                  <span className="atxf-widget__pill atxf-widget__pill--green">Isolated · No surveillance</span>
                </div>
              </div>
            )}
            {num===6 && (
              <div className="atxf-widget">
                <div className="atxf-widget__row">
                  <Mic size={10}/><span>AnamAIController</span>
                  <span className="atxf-widget__pill atxf-widget__pill--green">WebRTC loop active</span>
                </div>
                <div className="atxf-widget__row">
                  <Zap size={10}/><span>OpenAI Realtime WS</span>
                  <span className="atxf-widget__pill atxf-widget__pill--blue">Whisper-1 connected</span>
                </div>
                <div className="atxf-widget__row">
                  <Brain size={10}/><span>Semantic Layer</span>
                  <span className="atxf-widget__pill atxf-widget__pill--green">Intent extraction live</span>
                </div>
              </div>
            )}
            {num===10 && (
              <div className="atxf-widget">
                <div className="atxf-widget__row">
                  <ShieldCheck size={10}/><span>RLS Compliance</span>
                  <span className="atxf-widget__pill atxf-widget__pill--green">All tables secured</span>
                </div>
                <div className="atxf-widget__row">
                  <TrendingUp size={10}/><span>24/7 Ledger Monitor</span>
                  <span className="atxf-widget__pill atxf-widget__pill--green">Live</span>
                </div>
                <div className="atxf-widget__row">
                  <Globe size={10}/><span>Tax Filing Gateway</span>
                  <span className="atxf-widget__pill atxf-widget__pill--green">EDI Active</span>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    );
  };

  // ─── RENDER ───────────────────────────────────────────────────────────────────
  return (
    <div className="atx-root">
      <div className="atx-bg"/>

      {/* ── App header ── */}
      <div className="atx-header">
        <div className="atx-header__brand">
          <div className="atx-header__icon"><Building2 size={15}/></div>
          <div>
            <div className="atx-header__title">AippieAccounts AI Accountant</div>
            <div className="atx-header__sub">AIPPIETAX S.A. · Enterprise v86</div>
          </div>
        </div>
        <div className={`atx-qb-badge${qbConnected?' atx-qb-badge--on':''}`}>
          <span className="atx-qb-badge__dot"/>QB Live
        </div>
      </div>

      {/* ── OMNIPRESENT AVATAR ── */}
      <AvatarPanel
        speaking={speaking}
        mode={consultMode}
        emotion={avatarEmotion}
        avatarText={avatarText}
        subtitle={subtitle}
      />

      {/* ── Whisper status strip (visible during listen/think) ── */}
      {whisperLine && (
        <div className="atxv-whisper-strip">
          <Radio size={9} className="atx-spin"/>
          <span>{whisperLine}</span>
        </div>
      )}

      {/* ── Section tabs ── */}
      <div className="atx-tabs atx-tabs--scroll">
        {TABS.map(({key,label,Icon,badge})=>(
          <button
            key={key}
            className={`atx-tab${section===key?' atx-tab--active':''}`}
            onClick={()=>{
              setSection(key);
              if(key==='profile'){
                setAvatarText('Welcome to your Corporate Profile Manager. Please enter your Business Name, KVK Chamber of Commerce number, BTW or NIF tax identification number, and your corporate IBAN. I will register these securely in the AippieAccounts ledger engine.');
                setAvatarEmotion('focused');
                speak('Welcome to your Corporate Profile Manager. Please enter your Business Name, K-V-K Chamber of Commerce number, B-T-W or N-I-F tax identification number, and your corporate I-BAN. I will register these securely in the AippieAccounts ledger engine.','focused');
              }
            }}
          >
            <Icon size={11}/>{label}
            {badge!=null&&badge>0&&<span className="atx-tab__badge">{badge}</span>}
          </button>
        ))}
      </div>

      {/* ════════════════════════════════════════
          S1: AI FISCAL CONSULTATION
      ════════════════════════════════════════ */}
      {section==='consult' && (
        <div className="atx-section">
          <div className="atx-consult-info">
            <Landmark size={11}/>
            <span>OpenAI Realtime WS · Whisper-1 · Hacienda · Belastingdienst · OECD BEPS · LIS · VPB</span>
          </div>

          {consultHistory.length>0 && (
            <div className="atx-chat-history">
              {consultHistory.map((m,i)=>(
                <div key={i} className={`atx-chat-msg atx-chat-msg--${m.role}`}>
                  <div className="atx-chat-msg__label">{m.role==='user'?'You':'Aippie'}</div>
                  <div className="atx-chat-msg__text">{m.text}</div>
                </div>
              ))}
              <div ref={chatBottomRef}/>
            </div>
          )}

          <div className="atx-consult-input-row">
            <input
              className="atx-input atx-input--flex"
              placeholder="Ask any fiscal question…"
              value={consultQ}
              onChange={e=>setConsultQ(e.target.value)}
              onKeyDown={e=>e.key==='Enter'&&handleConsultSend()}
              disabled={consultMode==='thinking'}
            />
            <button className="atx-send-btn" onClick={handleConsultSend}
              disabled={!consultQ.trim()||consultMode==='thinking'}>
              {consultMode==='thinking'?<RefreshCw size={13} className="atx-spin"/>:<Send size={13}/>}
            </button>
          </div>

          {/* Hold-to-talk */}
          <div className="atx-hold-wrap">
            <button
              className={`atx-hold-btn${isListening?' atx-hold-btn--active':''}`}
              onPointerDown={startListening}
              onPointerUp={stopListening}
              onPointerLeave={stopListening}
              onPointerCancel={stopListening}
              aria-label="Hold to speak"
            >
              <span className="atx-hold-btn__ring atx-hold-btn__ring--1"/>
              <span className="atx-hold-btn__ring atx-hold-btn__ring--2"/>
              <span className="atx-hold-btn__core">
                {isListening?<MicOff size={14}/>:<Mic size={14}/>}
                {isListening?'WHISPER-1 LISTENING…':consultMode==='thinking'?'PROCESSING…':'HOLD TO SPEAK'}
              </span>
            </button>
          </div>

          <div className="atx-quick-queries">
            {['Deductibles for SL','VAT rates Spain','Hacienda deadline','Holding structure','R&D tax credit','10-Fasen status'].map(q=>(
              <button key={q} className="atx-quick-query" onClick={()=>{setConsultQ(q);}}>
                {q}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* ════════════════════════════════════════
          S2: OCR
      ════════════════════════════════════════ */}
      {section==='ocr' && (
        <div className="atx-section">
          <div className="atx-qb-row">
            <Wifi size={11}/><span>QuickBooks General Ledger</span>
            <span className="atx-qb-row__status"><span className="atx-dot atx-dot--green"/>Connected · Auto-sync ON</span>
          </div>
          <div className="atx-upload-zone" onClick={()=>fileRef.current?.click()}
            role="button" tabIndex={0} onKeyDown={e=>e.key==='Enter'&&fileRef.current?.click()}>
            <input ref={fileRef} type="file" accept=".pdf,.png,.jpg,.jpeg,.webp"
              style={{display:'none'}} onChange={handleFileChange}/>
            <UploadCloud size={20} className="atx-upload-zone__icon"/>
            <div className="atx-upload-zone__label">{fileName||'Tap to upload receipt or invoice'}</div>
            <div className="atx-upload-zone__hint">PDF · PNG · JPG · WEBP · Max 10 MB</div>
          </div>
          <div className="atx-meta-row">
            <div className="atx-field">
              <label className="atx-label">Entity</label>
              <select className="atx-select" value={entityType} onChange={e=>setEntityType(e.target.value as 'SL'|'SRL'|'LLC')}>
                <option value="SL">SL</option><option value="SRL">SRL</option><option value="LLC">LLC</option>
              </select>
            </div>
            <div className="atx-field">
              <label className="atx-label">Category</label>
              <select className="atx-select" value={taxCategory} onChange={e=>setTaxCategory(e.target.value)}>
                <option value="expense">Expense</option><option value="invoice">Invoice</option>
                <option value="receipt">Receipt</option><option value="payroll">Payroll</option>
              </select>
            </div>
            <div className="atx-field">
              <label className="atx-label">Amount €</label>
              <input className="atx-input" type="number" placeholder="0.00" value={amountEur}
                onChange={e=>setAmountEur(e.target.value)} inputMode="decimal"/>
            </div>
          </div>
          <OcrProgressBar status={ocrStatus} pct={ocrPct}/>
          {ocrText && (
            <div className="atx-ocr-result">
              <div className="atx-ocr-result__header">
                <FileText size={10}/><span>OCR RESULT</span>
                <span className="atx-badge atx-badge--green">100% SUCCESS</span>
              </div>
              <pre className="atx-ocr-result__text">{ocrText}</pre>
            </div>
          )}
          <div className="atx-ledger">
            <div className="atx-ledger__header">
              <TrendingUp size={10}/><span>DOCUMENT LEDGER</span>
              {docsLoading&&<RefreshCw size={9} className="atx-spin"/>}
            </div>
            {docs.length===0&&!docsLoading&&<div className="atx-ledger__empty">No documents yet.</div>}
            {docs.map(doc=>(
              <div key={doc.id} className="atx-ledger-row">
                <div className="atx-ledger-row__name">{doc.file_name}</div>
                <div className="atx-ledger-row__meta">
                  <span className="atx-badge atx-badge--blue">{doc.entity_type}</span>
                  <span className="atx-badge atx-badge--slate">{doc.tax_category}</span>
                  <span className="atx-ledger-row__amt">€{Number(doc.amount_eur).toFixed(2)}</span>
                  {doc.quickbooks_synced&&<span className="atx-badge atx-badge--green">QB Synced</span>}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ════════════════════════════════════════
          S3: LEDGER MONITOR
      ════════════════════════════════════════ */}
      {section==='ledger' && (
        <div className="atx-section">
          <div className="atx-monitor-header">
            <Activity size={11}/><span>24/7 LEDGER MONITOR · Real-time · Bank API + Manual</span>
            <span className="atx-dot atx-dot--green atx-dot--pulse"/>
          </div>
          <div className="atx-ledger-add">
            <div className="atx-ledger-add__title"><DollarSign size={10}/> Add Ledger Entry</div>
            <div className="atx-meta-row">
              <div className="atx-field" style={{flex:2}}>
                <label className="atx-label">Description</label>
                <input className="atx-input" placeholder="e.g. Office rent June 2025"
                  value={ledgerDesc} onChange={e=>setLedgerDesc(e.target.value)}/>
              </div>
              <div className="atx-field">
                <label className="atx-label">Amount €</label>
                <input className="atx-input" type="number" placeholder="0.00"
                  value={ledgerAmt} onChange={e=>setLedgerAmt(e.target.value)} inputMode="decimal"/>
              </div>
            </div>
            <div className="atx-meta-row">
              <div className="atx-field">
                <label className="atx-label">Counterparty</label>
                <input className="atx-input" placeholder="Supplier / Client"
                  value={ledgerParty} onChange={e=>setLedgerParty(e.target.value)}/>
              </div>
              <div className="atx-field">
                <label className="atx-label">Category</label>
                <select className="atx-select" value={ledgerCat} onChange={e=>setLedgerCat(e.target.value)}>
                  <option value="expense">Expense</option><option value="revenue">Revenue</option>
                  <option value="payroll">Payroll</option><option value="asset">Asset</option>
                  <option value="liability">Liability</option>
                </select>
              </div>
            </div>
            <div className="atx-ledger-add__footer">
              <label className="atx-checkbox-row">
                <input type="checkbox" checked={ledgerDed} onChange={e=>setLedgerDed(e.target.checked)}/>
                <span>Tax-deductible</span>
              </label>
              <button className="atx-submit-btn" onClick={submitLedger}
                disabled={!ledgerDesc.trim()||!ledgerAmt||ledgerSaving}>
                {ledgerSaving?<RefreshCw size={11} className="atx-spin"/>:<FileCheck size={11}/>}
                Post to Ledger
              </button>
            </div>
          </div>
          {/* Tax engine */}
          <div className="atx-optimizer-card">
            <div className="atx-optimizer-card__header">
              <Calculator size={12}/><span>Tax Minimization Engine</span>
              {totalSavings>0&&<span className="atx-badge atx-badge--green">€{totalSavings.toLocaleString()} saved</span>}
            </div>
            <p className="atx-optimizer-card__desc">Continuously analyzes ledger streams to discover legal optimization parameters under Spanish LIS and Dutch VPB.</p>
            <button className="atx-optimizer-btn" onClick={runOptimization} disabled={optRunning}>
              {optRunning?<><RefreshCw size={12} className="atx-spin"/> Running…</>:<><Zap size={12}/> Run Tax Engine</>}
            </button>
          </div>
          {showOpt && (
            <div className="atx-optimization-results">
              <div className="atx-optimization-results__header">
                <PieChart size={11}/><span>OPTIMIZATION STRATEGIES</span>
                <span className="atx-badge atx-badge--green">€{totalSavings.toLocaleString()} total</span>
              </div>
              {optResults.map((r,i)=>(
                <div key={i} className="atx-opt-row">
                  <div className="atx-opt-row__top">
                    <span className="atx-opt-row__strategy">{r.strategy}</span>
                    <span className="atx-opt-row__saving">€{r.saving_eur.toLocaleString()}</span>
                  </div>
                  <div className="atx-opt-row__desc">{r.description}</div>
                </div>
              ))}
            </div>
          )}
          <div className="atx-ledger">
            <div className="atx-ledger__header">
              <BarChart3 size={10}/><span>LIVE LEDGER STREAM</span>
              {ledgerLoading&&<RefreshCw size={9} className="atx-spin"/>}
            </div>
            {ledger.length===0&&!ledgerLoading&&<div className="atx-ledger__empty">No entries yet.</div>}
            {ledger.map(e=>(
              <div key={e.id} className="atx-ledger-row">
                <div className="atx-ledger-row__name">
                  {e.description}
                  {e.optimization_flag&&<span className="atx-badge atx-badge--amber" style={{marginLeft:6}}>{e.optimization_flag}</span>}
                </div>
                <div className="atx-ledger-row__meta">
                  <span className="atx-badge atx-badge--slate">{e.category}</span>
                  <span className="atx-ledger-row__amt">€{Number(e.amount_eur).toFixed(2)}</span>
                  <span className="atx-ledger-row__vat">+VAT €{Number(e.vat_amount||0).toFixed(2)}</span>
                  {e.deductible&&<span className="atx-badge atx-badge--green">Deductible</span>}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ════════════════════════════════════════
          S4: E-FILING
      ════════════════════════════════════════ */}
      {section==='filing' && (
        <div className="atx-section">
          <div className="atx-filing-header">
            <Globe size={12}/>
            <div>
              <div className="atx-filing-header__title">Direct Tax Filing Gateway</div>
              <div className="atx-filing-header__sub">Secure EDI · Belastingdienst · Hacienda</div>
            </div>
            <div className="atx-badge atx-badge--green"><Lock size={8}/> EDI Active</div>
          </div>

          {filingStatus!=='submitted' && (
            <div className="atx-filing-form">
              <div className="atx-meta-row">
                <div className="atx-field">
                  <label className="atx-label">Agency</label>
                  <select className="atx-select" value={fAgency}
                    onChange={e=>setFAgency(e.target.value as 'Hacienda'|'Belastingdienst')}
                    disabled={filingStatus!=='draft'}>
                    <option value="Hacienda">Hacienda (Spain)</option>
                    <option value="Belastingdienst">Belastingdienst (NL)</option>
                  </select>
                </div>
                <div className="atx-field">
                  <label className="atx-label">Entity</label>
                  <select className="atx-select" value={fEntity}
                    onChange={e=>setFEntity(e.target.value as 'SL'|'SRL'|'LLC')}
                    disabled={filingStatus!=='draft'}>
                    <option value="SL">SL</option><option value="SRL">SRL</option><option value="LLC">LLC</option>
                  </select>
                </div>
                <div className="atx-field">
                  <label className="atx-label">Year</label>
                  <select className="atx-select" value={fYear}
                    onChange={e=>setFYear(Number(e.target.value))}
                    disabled={filingStatus!=='draft'}>
                    <option value={2025}>2025</option><option value={2024}>2024</option><option value={2023}>2023</option>
                  </select>
                </div>
              </div>
              <div className="atx-meta-row">
                <div className="atx-field">
                  <label className="atx-label">Total Revenue €</label>
                  <input className="atx-input" type="number" placeholder="0.00" value={fRevenue}
                    onChange={e=>setFRevenue(e.target.value)} disabled={filingStatus!=='draft'} inputMode="decimal"/>
                </div>
                <div className="atx-field">
                  <label className="atx-label">Total Expenses €</label>
                  <input className="atx-input" type="number" placeholder="0.00" value={fExpenses}
                    onChange={e=>setFExpenses(e.target.value)} disabled={filingStatus!=='draft'} inputMode="decimal"/>
                </div>
              </div>
              {fRevenue&&fExpenses && (
                <div className="atx-filing-preview">
                  {[
                    ['Taxable Income',      `€${Math.max(0,parseFloat(fRevenue||'0')-parseFloat(fExpenses||'0')).toFixed(2)}`, false],
                    ['Gross Liability (25%)',`€${Math.max(0,(parseFloat(fRevenue||'0')-parseFloat(fExpenses||'0'))*0.25).toFixed(2)}`, false],
                    ['Optimized (12.4%)',   `€${Math.max(0,(parseFloat(fRevenue||'0')-parseFloat(fExpenses||'0'))*0.124).toFixed(2)}`, true],
                    ['AI Tax Savings',      `€${Math.max(0,(parseFloat(fRevenue||'0')-parseFloat(fExpenses||'0'))*(0.25-0.124)).toFixed(2)}`, true],
                  ].map(([label,val,green])=>(
                    <div key={label as string} className={`atx-filing-preview__row${green?' atx-filing-preview__row--savings':''}`}>
                      <span>{label as string}</span><span className={green?'atx-text-green':''}>{val as string}</span>
                    </div>
                  ))}
                </div>
              )}
              {(filingStatus==='compiling'||filingStatus==='transmitting') && (
                <div className="atx-filing-progress">
                  <div className="atx-filing-progress__label">
                    {filingStatus==='compiling'
                      ?<><RefreshCw size={10} className="atx-spin"/> Compiling…</>
                      :<><Wifi size={10} className="atx-spin"/> Transmitting to {fAgency}…</>
                    }
                    <span>{fProgress}%</span>
                  </div>
                  <div className="atx-filing-progress__bar">
                    <div className="atx-filing-progress__fill" style={{width:`${fProgress}%`}}/>
                  </div>
                </div>
              )}
              <button className="atx-submit-btn atx-submit-btn--filing" onClick={compileFiling}
                disabled={!fRevenue||!fExpenses||filingStatus!=='draft'}>
                {filingStatus==='draft'
                  ?<><Send size={12}/> Compile & Submit to {fAgency}</>
                  :<><RefreshCw size={12} className="atx-spin"/> Processing…</>
                }
              </button>
            </div>
          )}

          {filingStatus==='submitted'&&fConfirmRef&&fShowReport && (
            <div className="atx-filing-success">
              <CheckCircle2 size={26} className="atx-filing-success__icon"/>
              <div className="atx-filing-success__title">Filing Submitted Successfully</div>
              <div className="atx-filing-success__ref">Ref: <code>{fConfirmRef}</code></div>
              <div className="atx-filing-success__sub">Accepted · {fAgency} · {new Date().toLocaleDateString()}</div>
              <button className="atx-submit-btn" onClick={()=>{setFilingStatus('draft');setFConfirmRef('');setFShowReport(false);setFRevenue('');setFExpenses('');}}>
                Submit Another Filing
              </button>
            </div>
          )}

          {filings.length>0 && (
            <div className="atx-ledger">
              <div className="atx-ledger__header"><FileText size={10}/><span>FILING HISTORY</span></div>
              {filings.map(f=>(
                <div key={f.id} className="atx-ledger-row">
                  <div className="atx-ledger-row__name">{f.fiscal_year} · {f.agency} · {f.entity_type}</div>
                  <div className="atx-ledger-row__meta">
                    <span className={`atx-badge ${f.filing_status==='submitted'?'atx-badge--green':'atx-badge--amber'}`}>{f.filing_status}</span>
                    <span className="atx-ledger-row__amt">€{Number(f.optimized_liability_eur).toFixed(2)}</span>
                    <span className="atx-badge atx-badge--green">Saved €{Number(f.savings_eur).toFixed(2)}</span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* ════════════════════════════════════════
          S5: ALERTS
      ════════════════════════════════════════ */}
      {section==='alerts' && (
        <div className="atx-section">
          <div className="atx-alerts-header">
            <BellRing size={12}/><span>SMART ALERT DISPATCH · 24/7</span>
            {unread>0&&<span className="atx-badge atx-badge--red">{unread} unread</span>}
          </div>
          {alertsLoading&&<div className="atx-ledger__empty"><RefreshCw size={11} className="atx-spin"/> Loading…</div>}
          {!alertsLoading&&alerts.length===0&&<div className="atx-ledger__empty">No alerts yet.</div>}
          {alerts.map(a=>(
            <div key={a.id} className={`atx-alert-card atx-alert-card--${a.severity}${a.is_read?' atx-alert-card--read':''}`}>
              <div className="atx-alert-card__header">
                <SevBadge s={a.severity}/>
                <span className="atx-alert-card__title">{a.title}</span>
                {a.due_date&&<span className="atx-alert-card__due">{a.due_date}</span>}
              </div>
              <div className="atx-alert-card__body">{a.body}</div>
              <div className="atx-alert-card__actions">
                {!a.is_read&&<button className="atx-alert-action" onClick={()=>markRead(a.id)}><Eye size={9}/> Mark Read</button>}
                <button className="atx-alert-action atx-alert-action--speak" onClick={()=>speakAlert(a)}>
                  <Mic size={9}/> {a.is_spoken?'Replay':'Speak'}
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* ════════════════════════════════════════
          S6: VOIP / PROXY HEADSET NODE
      ════════════════════════════════════════ */}
      {section==='voip' && (
        <div className="atx-section">
          {/* Header */}
          <div className="atx-voip-header">
            <div className="atx-voip-header__icon">
              <svg width="30" height="30" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
                <circle cx="16" cy="16" r="15" stroke="rgba(56,189,248,0.3)" strokeWidth="1.5"/>
                <path d="M8 18v-4a8 8 0 0 1 16 0v4" stroke="#38bdf8" strokeWidth="1.8" strokeLinecap="round"/>
                <rect x="6" y="17" width="4" height="6" rx="2" fill="#38bdf8"/>
                <rect x="22" y="17" width="4" height="6" rx="2" fill="#38bdf8"/>
                <path d="M26 21c0 3-1.5 5-4 5h-3" stroke="#38bdf8" strokeWidth="1.5" strokeLinecap="round"/>
                <circle cx="19" cy="26" r="1.5" fill="#38bdf8"/>
              </svg>
            </div>
            <div>
              <div className="atx-voip-header__title">Encrypted Proxy Headset Node</div>
              <div className="atx-voip-header__sub">WebRTC · E2EE · Whisper-1 Transcript · Sovereign Anonymity</div>
            </div>
            <div className="atx-badge atx-badge--green"><Lock size={8}/> E2EE</div>
          </div>

          {/* Service indicators */}
          <div className="atxv-service-row">
            {[
              { label:'AnamAIController', color:'#4ade80', icon:<Radio size={9}/> },
              { label:'OpenAI Realtime WS', color:'#38bdf8', icon:<Zap size={9}/> },
              { label:'Whisper-1', color:'#fbbf24', icon:<Mic size={9}/> },
              { label:'E2EE Tunnel', color:'#4ade80', icon:<Lock size={9}/> },
            ].map(s=>(
              <div key={s.label} className="atxv-service-pill" style={{ borderColor: `${s.color}33`, color: s.color }}>
                {s.icon}<span>{s.label}</span>
                <span className="atx-dot atx-dot--green"/>
              </div>
            ))}
          </div>

          {/* Form */}
          <div className="atx-voip-form">
            <div className="atx-field atx-field--full">
              <label className="atx-label">Client Name</label>
              <input className="atx-input" placeholder="e.g. AIPPIETAX S.A."
                value={clientName} onChange={e=>setClientName(e.target.value)} disabled={voipStatus!=='idle'}/>
            </div>
            <div className="atx-field atx-field--full">
              <label className="atx-label">Destination Number</label>
              <input className="atx-input" placeholder="+34 612 345 678"
                value={destNumber} onChange={e=>setDestNumber(e.target.value)}
                type="tel" inputMode="tel" disabled={voipStatus!=='idle'}/>
            </div>
          </div>

          {e2eeToken&&voipStatus!=='idle' && (
            <div className="atx-e2ee-token">
              <Lock size={9}/>
              <span>E2EE Key: <code>{e2eeToken.slice(0,8)}…{e2eeToken.slice(-8)}</code></span>
            </div>
          )}

          {voipStatus==='connected' && (
            <>
              <div className="atx-voip-live">
                <span className="atx-dot atx-dot--green atx-dot--pulse"/>
                <span>LIVE · {fmtSecs(callSecs)}</span>
                <Waveform active={true} color="#38bdf8" height={36}/>
              </div>
              {/* Live caption strip */}
              {liveCaption && (
                <div className="atxv-caption-strip">
                  <Mic size={9} className="atx-spin"/>
                  <span>{liveCaption}</span>
                </div>
              )}
              {/* Transcript */}
              {transcript.length>0 && (
                <div className="atxv-transcript">
                  <div className="atxv-transcript__header"><Radio size={9}/> Whisper-1 Transcript</div>
                  <div className="atxv-transcript__body">
                    {transcript.map((t,i)=>(
                      <div key={i} className={`atxv-transcript__line atxv-transcript__line--${t.speaker}`}>
                        <span className="atxv-transcript__speaker">{t.speaker==='user'?'You':'AI'}</span>
                        <span className="atxv-transcript__text">{t.text}</span>
                      </div>
                    ))}
                    <div ref={transcriptBottomRef}/>
                  </div>
                </div>
              )}
            </>
          )}

          {voipStatus==='dialing' && (
            <div className="atx-voip-dialing">
              <RefreshCw size={12} className="atx-spin"/>
              <span>Establishing encrypted tunnel to {destNumber}…</span>
            </div>
          )}
          {voipStatus==='ended' && (
            <div className="atx-voip-ended"><CheckCircle2 size={12}/> Call ended · Session encrypted and archived</div>
          )}

          <div className="atx-voip-actions">
            {voipStatus==='idle'
              ? <button className="atx-call-btn atx-call-btn--start" onClick={startCall}
                  disabled={!clientName.trim()||!destNumber.trim()}>
                  <Phone size={14}/> Initiate Encrypted Call
                </button>
              : <button className="atx-call-btn atx-call-btn--end" onClick={endCall}
                  disabled={voipStatus==='ended'}>
                  <PhoneOff size={14}/> End Call
                </button>
            }
          </div>
          <div className="atx-voip-trust">
            <ShieldCheck size={9}/>
            <span>Peer-to-peer encrypted · Isolated from surveillance · AIPPIETAX S.A.</span>
          </div>
        </div>
      )}

      {/* ════════════════════════════════════════
          S7: 10-FASEN EXPANDED BLUEPRINT
      ════════════════════════════════════════ */}
      {section==='fasen' && (
        <div className="atx-section">
          <div className="atxf-header">
            <Star size={13}/>
            <span>10-Fasen Business Evolution Blueprint</span>
            <span className="atx-badge atx-badge--amber">AIPPIETAX S.A. · v56</span>
          </div>

          {/* Progress overview bar */}
          <div className="atxf-progress-overview">
            {([1,2,3,4,5,6,7,8,9,10] as FasenKey[]).map(n=>{
              const ph = phases.find(p=>p.phase_number===n);
              const meta = FASEN_META[n];
              const isLive = ph?.status==='active';
              const isDone = ph?.status==='completed';
              return (
                <button
                  key={n}
                  className={`atxf-pip${isLive?' atxf-pip--live':isDone?' atxf-pip--done':''}${activeFase===n?' atxf-pip--sel':''}`}
                  style={{ '--pip-color': meta.color } as React.CSSProperties}
                  onClick={()=>{ setActiveFase(n); setExpanded(n); }}
                  title={ph?.title_en||`Fase ${n}`}
                >
                  {meta.icon}
                  <span>{n}</span>
                  {isLive&&<span className="atxf-pip__live-dot"/>}
                </button>
              );
            })}
          </div>

          {/* Phase list */}
          <div className="atxf-list">
            {phases.length===0&&<div className="atx-ledger__empty">Loading 10-Fasen data…</div>}
            {phases.map(renderFasenPanel)}
          </div>

          <div className="atx-roadmap-footer">
            <ShieldCheck size={9}/>
            AIPPIETAX S.A. · 10-Fasen Blueprint v56 · All phases RLS-protected · WebRTC active
          </div>
        </div>
      )}

      {/* ════════════════════════════════════════
          CORPORATE PROFILE MANAGER — V85
      ════════════════════════════════════════ */}
      {section === 'profile' && (
        <div className="atx-section atx85-profile-section">

          {/* Header */}
          <div className="atx85-profile-header">
            <div className="atx85-profile-header__icon">
              <Building2 size={18} style={{ color: '#4ade80' }}/>
            </div>
            <div>
              <div className="atx85-profile-header__title">Corporate Profile Manager</div>
              <div className="atx85-profile-header__sub">
                Your legal identity — securely stored in the AippieAccounts ledger engine
              </div>
            </div>
          </div>

          {/* Form fields */}
          <div className="atx85-profile-fields">

            {/* Business Name */}
            <div className="atx85-field-group">
              <label className="atx85-field-label">
                <Building2 size={10}/> Business Name
              </label>
              <input
                className="atx85-field-input"
                type="text"
                placeholder="e.g. Aippie Technologies S.L."
                value={profBusiness}
                onChange={e => setProfBusiness(e.target.value)}
                onFocus={() => {
                  if (profBusiness === '') {
                    setAvatarText('Please enter your full legal business name exactly as it appears on your Chamber of Commerce registration.');
                    setAvatarEmotion('focused');
                    speak('Please enter your full legal business name exactly as it appears on your Chamber of Commerce registration.', 'focused');
                  }
                }}
              />
            </div>

            {/* KVK / Chamber of Commerce */}
            <div className="atx85-field-group">
              <label className="atx85-field-label">
                <FileText size={10}/> Chamber of Commerce / KVK Number
              </label>
              <input
                className="atx85-field-input"
                type="text"
                placeholder="e.g. 12345678"
                value={profKvk}
                onChange={e => setProfKvk(e.target.value)}
                onFocus={() => {
                  setAvatarText('Enter your KVK number here. This is your 8-digit Dutch Chamber of Commerce registration number. For Spanish entities, enter your Registro Mercantil number.');
                  setAvatarEmotion('focused');
                  speak('Enter your K-V-K number here. This is your 8-digit Dutch Chamber of Commerce registration number. For Spanish entities, enter your Registro Mercantil number.', 'focused');
                }}
              />
            </div>

            {/* BTW / NIF / VAT */}
            <div className="atx85-field-group">
              <label className="atx85-field-label">
                <ShieldCheck size={10}/> Tax ID — BTW / NIF / VAT Number
              </label>
              <input
                className="atx85-field-input"
                type="text"
                placeholder="e.g. NL123456789B01 or B-12345678"
                value={profBtw}
                onChange={e => setProfBtw(e.target.value)}
                onFocus={() => {
                  setAvatarText('Enter your VAT identification number. Dutch entities use BTW format NL followed by 9 digits and B01. Spanish entities use NIF format beginning with the letter B for legal entities.');
                  setAvatarEmotion('focused');
                  speak('Enter your VAT identification number. Dutch entities use B-T-W format N-L followed by 9 digits and B-01. Spanish entities use N-I-F format beginning with the letter B for legal entities.', 'focused');
                }}
              />
            </div>

            {/* Corporate IBAN */}
            <div className="atx85-field-group">
              <label className="atx85-field-label">
                <Zap size={10}/> Corporate IBAN
              </label>
              <input
                className="atx85-field-input"
                type="text"
                placeholder="e.g. NL91ABNA0417164300"
                value={profIban}
                onChange={e => setProfIban(e.target.value)}
                onFocus={() => {
                  setAvatarText('Enter your corporate IBAN. This will be used by the automated payroll engine for salary disbursements and supplier invoice settlements.');
                  setAvatarEmotion('focused');
                  speak('Enter your corporate I-BAN. This will be used by the automated payroll engine for salary disbursements and supplier invoice settlements.', 'focused');
                }}
              />
            </div>
          </div>

          {/* Save button + status */}
          {profError && (
            <div className="atx85-profile-error">
              <AlertCircle size={11}/> {profError}
            </div>
          )}
          {profSaved && (
            <div className="atx85-profile-success">
              <CheckCircle2 size={11}/> Corporate profile saved successfully.
            </div>
          )}
          <button
            className={`atx85-save-btn${profSaving ? ' atx85-save-btn--loading' : ''}`}
            onClick={handleProfileSave}
            disabled={profSaving}
          >
            {profSaving
              ? <><span className="modal__spinner modal__spinner--sm"/> Saving…</>
              : <><CheckCircle2 size={13}/> Save Corporate Profile</>
            }
          </button>

          {/* Info strip */}
          <div className="atx85-profile-info-strip">
            <Lock size={9}/>
            <span>Data encrypted in transit · Row Level Security enforced · GDPR compliant · AIPPIETAX S.A.</span>
          </div>
        </div>
      )}

      {/* ════ PAYROLL & INVOICING (V66) ════ */}
      {section === 'payroll' && <PayrollView/>}

      {/* ════ PAYROLL CLIENTS — multi-client payroll manager ════ */}
      {section === 'clients' && <PayrollClientsView user={atxUserId ? { id: atxUserId } : null}/>}

      {/* ════ AUTONOMOUS ACCOUNTING & PAYROLL ENGINE (V222) ════ */}
      {section === 'accounting' && <AippieAccountingView user={null} />}

      {/* ════ VERI*FACTU — Spanish e-invoicing AEAT ════ */}
      {section === 'verifactu' && <AippieVerifactuView deviceKey={deviceKey} />}

      {/* ── V162: Document Scanner — hidden on accounting/verifactu/clients tab ── */}
      {section !== 'accounting' && section !== 'verifactu' && section !== 'clients' && <DocScannerPanel sourceModule="aippietax" userId={atxUserId} />}

      {/* ── V162: Investor Matchmaker — hidden on accounting/verifactu/clients tab ── */}
      {section !== 'accounting' && section !== 'verifactu' && section !== 'clients' && <InvestorMatchmakerPanel userId={atxUserId} />}

      {/* ── Footer ── */}
      <AippieVoiceOverlay context="tax" />

      <div className="atx-footer">
        <ShieldCheck size={9}/>
        AippieTax AI Accountant · AIPPIETAX S.A. · GDPR · v162
      </div>
    </div>
  );
}
