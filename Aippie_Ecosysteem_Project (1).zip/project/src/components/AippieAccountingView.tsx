/**
 * AippieAccountingView — V222
 * Enterprise-Grade International Autonomous Accounting & Payroll System
 * AippieTax S.A. — Spain · Netherlands · USA
 */
import { useCallback, useEffect, useRef, useState, lazy, Suspense } from 'react';
import {
  Activity, AlertTriangle, BarChart3, Building2, CheckCircle2,
  ChevronDown, ChevronUp, DollarSign, Download, Euro, FileText,
  Globe, Landmark, Lock, RefreshCw, Send, ShieldCheck,
  TrendingDown, TrendingUp, Users, Zap, Play, Square,
  CircleDot, ArrowUpRight, ArrowDownRight, Server, Bell, X,
  MessageSquare, Bot, Volume2, Mic, MicOff, Trash2, Copy, ScrollText,
} from 'lucide-react';
import { applyPremiumVoice, withVoicesReady, normalizeForTTS } from '../lib/ttsVoice';
import { notifyInfo, requestNotificationPermission } from '../lib/notificationService';
import { supabase } from '../lib/supabase';
import type { User } from '@supabase/supabase-js';

const AippieVerifactuView = lazy(() => import('./AippieVerifactuView'));

// ─── Types ────────────────────────────────────────────────────────────────────

type JurisCode = 'ES' | 'NL' | 'US';
type TxCategory = 'revenue' | 'cogs' | 'payroll' | 'rent' | 'software' |
  'marketing' | 'legal' | 'travel' | 'bank_charge' | 'tax_reserve' | 'other';

interface AccTx {
  id: string;
  tx_date: string;
  description: string;
  category: TxCategory;
  debit: number;
  credit: number;
  currency: string;
  jurisdiction: string;
  reconciled: boolean;
  auto_categorized: boolean;
}

interface Employee {
  id: string;
  full_name: string;
  role: string;
  jurisdiction: JurisCode;
  gross_annual: number;
  currency: string;
  active: boolean;
}

interface PayrollRun {
  id: string;
  employee_id: string;
  period: string;
  gross: number;
  tax_withheld: number;
  ss_employee: number;
  ss_employer: number;
  net_pay: number;
  currency: string;
  status: 'pending' | 'processed' | 'paid' | 'filed';
}

interface TaxSub {
  id: string;
  authority: string;
  form_type: string;
  period: string;
  amount: number;
  currency: string;
  status: 'pending' | 'transmitting' | 'accepted' | 'rejected' | 'paid';
  reference?: string;
  submitted_at?: string;
}

type ActiveTab = 'pl' | 'ledger' | 'payroll' | 'gateway' | 'chat' | 'verifactu';

// ─── Constants ────────────────────────────────────────────────────────────────

const JURIS_META: Record<JurisCode, { flag: string; label: string; taxAuth: string; taxRate: number; ss: number; ssEmployer: number }> = {
  ES: { flag: '🇪🇸', label: 'Spain', taxAuth: 'AEAT', taxRate: 0.21, ss: 0.063, ssEmployer: 0.236 },
  NL: { flag: '🇳🇱', label: 'Netherlands', taxAuth: 'Belastingdienst', taxRate: 0.195, ss: 0.278, ssEmployer: 0.19 },
  US: { flag: '🇺🇸', label: 'United States', taxAuth: 'IRS', taxRate: 0.22, ss: 0.0765, ssEmployer: 0.0765 },
};

const CAT_COLORS: Record<TxCategory, string> = {
  revenue: '#22c55e', cogs: '#f59e0b', payroll: '#3b82f6', rent: '#8b5cf6',
  software: '#06b6d4', marketing: '#ec4899', legal: '#f97316', travel: '#84cc16',
  bank_charge: '#94a3b8', tax_reserve: '#ef4444', other: '#64748b',
};

const CAT_LABELS: Record<TxCategory, string> = {
  revenue: 'Revenue', cogs: 'COGS', payroll: 'Payroll', rent: 'Rent',
  software: 'Software', marketing: 'Marketing', legal: 'Legal', travel: 'Travel',
  bank_charge: 'Bank Charges', tax_reserve: 'Tax Reserve', other: 'Other',
};

const DEMO_TX: Omit<AccTx, 'id'>[] = [
  { tx_date: '2026-06-01', description: 'AippieTax SaaS Subscription — 847 licenses', category: 'revenue', debit: 0, credit: 169400, currency: 'EUR', jurisdiction: 'ES', reconciled: true, auto_categorized: true },
  { tx_date: '2026-06-02', description: 'B2B Enterprise Contract — NL Corp', category: 'revenue', debit: 0, credit: 48500, currency: 'EUR', jurisdiction: 'NL', reconciled: true, auto_categorized: true },
  { tx_date: '2026-06-03', description: 'AWS Cloud Infrastructure Q2', category: 'software', debit: 12400, credit: 0, currency: 'EUR', jurisdiction: 'ES', reconciled: true, auto_categorized: true },
  { tx_date: '2026-06-03', description: 'Nóminas Junio — España', category: 'payroll', debit: 38700, credit: 0, currency: 'EUR', jurisdiction: 'ES', reconciled: true, auto_categorized: true },
  { tx_date: '2026-06-04', description: 'Office Rent — Madrid HQ', category: 'rent', debit: 4800, credit: 0, currency: 'EUR', jurisdiction: 'ES', reconciled: true, auto_categorized: true },
  { tx_date: '2026-06-05', description: 'US License Revenue — Q2', category: 'revenue', debit: 0, credit: 92100, currency: 'USD', jurisdiction: 'US', reconciled: false, auto_categorized: true },
  { tx_date: '2026-06-06', description: 'Google Ads — International Campaigns', category: 'marketing', debit: 8200, credit: 0, currency: 'EUR', jurisdiction: 'GLOBAL', reconciled: true, auto_categorized: true },
  { tx_date: '2026-06-06', description: 'IVA Reserve — Q2 España', category: 'tax_reserve', debit: 35574, credit: 0, currency: 'EUR', jurisdiction: 'ES', reconciled: true, auto_categorized: true },
  { tx_date: '2026-06-07', description: 'Legal Compliance — EU AI Act', category: 'legal', debit: 3500, credit: 0, currency: 'EUR', jurisdiction: 'ES', reconciled: true, auto_categorized: true },
  { tx_date: '2026-06-07', description: 'Netherlands B2B Consulting Rev.', category: 'revenue', debit: 0, credit: 21000, currency: 'EUR', jurisdiction: 'NL', reconciled: false, auto_categorized: true },
  { tx_date: '2026-06-08', description: 'SWIFT Transfer fee', category: 'bank_charge', debit: 240, credit: 0, currency: 'EUR', jurisdiction: 'ES', reconciled: true, auto_categorized: true },
  { tx_date: '2026-06-08', description: 'Business Travel — Amsterdam summit', category: 'travel', debit: 1850, credit: 0, currency: 'EUR', jurisdiction: 'NL', reconciled: false, auto_categorized: true },
];

const DEMO_EMPLOYEES: Omit<Employee, 'id'>[] = [
  { full_name: 'Carlos Martínez Ruiz', role: 'CTO', jurisdiction: 'ES', gross_annual: 96000, currency: 'EUR', active: true },
  { full_name: 'Sofía López García', role: 'AI Product Lead', jurisdiction: 'ES', gross_annual: 78000, currency: 'EUR', active: true },
  { full_name: 'Erik van den Berg', role: 'Head of Engineering', jurisdiction: 'NL', gross_annual: 88000, currency: 'EUR', active: true },
  { full_name: 'Anna de Vries', role: 'Compliance Officer', jurisdiction: 'NL', gross_annual: 72000, currency: 'EUR', active: true },
  { full_name: 'James Walker', role: 'VP Sales Americas', jurisdiction: 'US', gross_annual: 130000, currency: 'USD', active: true },
];

const DEMO_TAX_SUBS: Omit<TaxSub, 'id'>[] = [
  { authority: 'AEAT', form_type: 'Modelo 111 — IRPF Retenciones', period: '2026-Q2', amount: 18420, currency: 'EUR', status: 'accepted', reference: 'AEAT-2026-Q2-111-8847', submitted_at: '2026-06-01T09:14:00Z' },
  { authority: 'AEAT', form_type: 'Modelo 303 — IVA Trimestral', period: '2026-Q2', amount: 35574, currency: 'EUR', status: 'transmitting', reference: 'AEAT-2026-Q2-303-3312' },
  { authority: 'Belastingdienst', form_type: 'OB — Omzetbelasting Q2', period: '2026-Q2', amount: 12960, currency: 'EUR', status: 'pending' },
  { authority: 'Belastingdienst', form_type: 'Loonheffing — Juni 2026', period: '2026-06', amount: 9240, currency: 'EUR', status: 'accepted', reference: 'BD-2026-06-LH-5521', submitted_at: '2026-06-03T14:30:00Z' },
  { authority: 'IRS', form_type: 'Form 941 — Employer Q2', period: '2026-Q2', amount: 14820, currency: 'USD', status: 'pending' },
  { authority: 'IRS', form_type: 'Form 1120 — Corp Tax Estimate', period: '2026-Q2', amount: 42100, currency: 'USD', status: 'pending' },
];

// ─── Helpers ──────────────────────────────────────────────────────────────────

const fmt = (n: number, cur = 'EUR') =>
  new Intl.NumberFormat('nl-NL', { style: 'currency', currency: cur, maximumFractionDigits: 0 }).format(n);

const fmtDate = (s: string) => new Date(s).toLocaleDateString('en-GB', { day: '2-digit', month: 'short' });

function computePayroll(emp: Employee): Omit<PayrollRun, 'id' | 'employee_id' | 'period' | 'status'> {
  const jm = JURIS_META[emp.jurisdiction];
  const grossMonthly = emp.gross_annual / 12;
  const tax = grossMonthly * jm.taxRate;
  const ssEmp = grossMonthly * jm.ss;
  const ssEr = grossMonthly * jm.ssEmployer;
  const net = grossMonthly - tax - ssEmp;
  return { gross: grossMonthly, tax_withheld: tax, ss_employee: ssEmp, ss_employer: ssEr, net_pay: net, currency: emp.currency };
}

// ─── Sub-components ───────────────────────────────────────────────────────────

function StatusBadge({ s }: { s: string }) {
  const map: Record<string, string> = {
    accepted: '#22c55e', paid: '#22c55e', processed: '#22c55e', filed: '#22c55e',
    transmitting: '#f59e0b', pending: '#94a3b8', rejected: '#ef4444',
  };
  const color = map[s] ?? '#94a3b8';
  return (
    <span style={{
      display: 'inline-flex', alignItems: 'center', gap: 4,
      padding: '2px 8px', borderRadius: 4,
      background: `${color}18`, color, border: `1px solid ${color}30`,
      fontSize: 10, fontWeight: 800, letterSpacing: '0.05em', textTransform: 'uppercase',
    }}>
      <CircleDot size={7} />
      {s}
    </span>
  );
}

function MiniBar({ value, max, color }: { value: number; max: number; color: string }) {
  return (
    <div style={{ flex: 1, height: 4, borderRadius: 2, background: 'rgba(255,255,255,0.06)', overflow: 'hidden' }}>
      <div style={{ width: `${Math.min(100, (value / max) * 100)}%`, height: '100%', background: color, borderRadius: 2, transition: 'width 0.6s ease' }} />
    </div>
  );
}

// ─── AI Voice Avatar ──────────────────────────────────────────────────────────

function AccountingAvatar({ speaking, caption }: { speaking: boolean; caption: string }) {
  return (
    <div className="acc-avatar">
      <div className="acc-avatar__rings">
        <div className={`acc-av-ring acc-av-ring--1${speaking ? ' acc-av-ring--lit' : ''}`} />
        <div className={`acc-av-ring acc-av-ring--2${speaking ? ' acc-av-ring--lit' : ''}`} />
        <img
          src="/Jouw_alineatekst_(2).png"
          alt="Aippie CFO"
          className={`acc-avatar__face${speaking ? ' acc-avatar__face--active' : ''}`}
          onError={e => { (e.currentTarget as HTMLImageElement).src = 'https://images.pexels.com/photos/3760529/pexels-photo-3760529.jpeg?auto=compress&cs=tinysrgb&w=400&h=400&fit=crop'; }}
        />
      </div>
      <div className="acc-avatar__caption">{caption || 'AI CFO ready'}</div>
    </div>
  );
}

// ─── Main component ───────────────────────────────────────────────────────────

export default function AippieAccountingView({ user }: { user: User | null }) {
  const [activeTab, setActiveTab]   = useState<ActiveTab>('pl');
  const [transactions, setTxs]      = useState<AccTx[]>([]);
  const [employees, setEmps]        = useState<Employee[]>([]);
  const [payrollRuns, setRuns]      = useState<PayrollRun[]>([]);
  const [taxSubs, setTaxSubs]       = useState<TaxSub[]>([]);
  const [engineRunning, setEngine]  = useState(false);
  const [processing, setProcessing] = useState(false);
  const [speaking, setSpeaking]     = useState(false);
  const [caption, setCaption]       = useState('AippieTax Autonomous Accounting Engine — ready');
  const [expandedEmp, setExpEmp]    = useState<string | null>(null);
  const cancelRef = useRef(false);
  const lastSpkRef = useRef(0);
  const marginRef = useRef(0);

  // ── AI Chat state ─────────────────────────────────────────────────────────
  type ChatMsg = { id: string; role: 'user' | 'assistant'; content: string; ts: number };
  const [chatMessages, setChatMsgs] = useState<ChatMsg[]>([
    { id: 'intro', role: 'assistant', content: 'Good day! I am Aippie AI CFO. Ask me a question about taxes, accounting, VAT, payroll administration or invoicing — for Spain, Netherlands or USA. I will calculate everything for you.', ts: Date.now() },
  ]);
  const [chatInput, setChatInput]   = useState('');
  const [chatLang, setChatLang]     = useState<'nl'|'en'|'es'>('nl');
  const [chatLoading, setChatLoad]  = useState(false);
  const [chatVoice, setChatVoice]   = useState(true);
  const chatEndRef = useRef<HTMLDivElement>(null);
  const sessionId  = useRef(crypto.randomUUID());
  const deviceKey  = localStorage.getItem('aippie_device_key') ?? 'anon';

  // ── In-app push alert queue ───────────────────────────────────────────────
  type PushAlert = { id: string; title: string; body: string; type: 'warn' | 'info' | 'ok' };
  const [alerts, setAlerts] = useState<PushAlert[]>([]);

  const pushAlert = useCallback((title: string, body: string, type: PushAlert['type'] = 'info') => {
    const id = crypto.randomUUID();
    setAlerts(q => [...q, { id, title, body, type }]);
    setTimeout(() => setAlerts(q => q.filter(a => a.id !== id)), 14000);
  }, []);

  const dismissAlert = (id: string) => setAlerts(q => q.filter(a => a.id !== id));

  // ── Boot with demo data ───────────────────────────────────────────────────
  useEffect(() => {
    setTxs(DEMO_TX.map((t, i) => ({ ...t, id: `tx-${i}` })));
    setEmps(DEMO_EMPLOYEES.map((e, i) => ({ ...e, id: `emp-${i}` })));
    setTaxSubs(DEMO_TAX_SUBS.map((s, i) => ({ ...s, id: `sub-${i}` })));
    // auto-generate payroll runs for this month
    const runs: PayrollRun[] = DEMO_EMPLOYEES.map((e, i) => {
      const calc = computePayroll({ ...e, id: `emp-${i}` });
      return { id: `run-${i}`, employee_id: `emp-${i}`, period: '2026-06', status: 'paid', ...calc };
    });
    setRuns(runs);
  }, []);

  // ── TTS speak ─────────────────────────────────────────────────────────────
  const speak = useCallback((text: string) => {
    const now = Date.now();
    if (now - lastSpkRef.current < 4000) return;
    lastSpkRef.current = now;
    cancelRef.current = false;
    setSpeaking(true);
    setCaption(text);
    withVoicesReady(() => {
      window.speechSynthesis.cancel();
      const utter = new SpeechSynthesisUtterance(text);
      applyPremiumVoice(utter, 'authoritative');
      utter.onend = () => { if (!cancelRef.current) setSpeaking(false); };
      utter.onerror = () => setSpeaking(false);
      window.speechSynthesis.speak(utter);
    });
  }, []);

  // ── Auto-scroll chat ───────────────────────────────────────────────────────
  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [chatMessages]);

  // ── Send chat message ─────────────────────────────────────────────────────
  const sendChat = useCallback(async (text?: string) => {
    const msg = (text ?? chatInput).trim();
    if (!msg || chatLoading) return;
    setChatInput('');

    const userMsg: ChatMsg = { id: crypto.randomUUID(), role: 'user', content: msg, ts: Date.now() };
    setChatMsgs(prev => [...prev, userMsg]);
    setChatLoad(true);

    // Persist user message
    supabase.from('aippietax_chat_messages').insert({
      device_key: deviceKey, session_id: sessionId.current,
      role: 'user', content: msg, lang: chatLang,
    }).then(() => {});

    try {
      const history = [...chatMessages.slice(-10), userMsg]
        .map(m => ({ role: m.role, content: m.content }));

      const { data } = await supabase.functions.invoke('aippietax-chat', {
        body: { messages: history, lang: chatLang, jurisdiction: 'ES/NL/US' },
      });

      const reply = (data as { reply?: string })?.reply ?? 'An error occurred. Please try again.';
      const aiMsg: ChatMsg = { id: crypto.randomUUID(), role: 'assistant', content: reply, ts: Date.now() };
      setChatMsgs(prev => [...prev, aiMsg]);

      // Persist AI reply
      supabase.from('aippietax_chat_messages').insert({
        device_key: deviceKey, session_id: sessionId.current,
        role: 'assistant', content: reply, lang: chatLang,
      }).then(() => {});

      // TTS read-aloud if enabled
      if (chatVoice) {
        withVoicesReady(() => {
          window.speechSynthesis.cancel();
          const u = new SpeechSynthesisUtterance(normalizeForTTS(reply.slice(0, 300)));
          applyPremiumVoice(u, 'authoritative');
          u.lang = chatLang === 'nl' ? 'nl-NL' : chatLang === 'es' ? 'es-ES' : 'en-US';
          window.speechSynthesis.speak(u);
        });
      }
    } catch {
      setChatMsgs(prev => [...prev, { id: crypto.randomUUID(), role: 'assistant', content: 'Connection failed. Check your internet connection.', ts: Date.now() }]);
    } finally {
      setChatLoad(false);
    }
  }, [chatInput, chatMessages, chatLang, chatLoading, chatVoice, deviceKey]);

  const clearChat = () => {
    sessionId.current = crypto.randomUUID();
    setChatMsgs([{ id: 'intro', role: 'assistant', content: 'New session started. How can I help?', ts: Date.now() }]);
  };

  // ── Proactive AI alerts engine ─────────────────────────────────────────────
  useEffect(() => {
    requestNotificationPermission();

    const PROACTIVE_ALERTS = [
      {
        delay: 6000, type: 'warn' as const,
        title: 'VAT Filing Deadline Approaching',
        body: 'Modelo 303 — deadline July 20, 2026. Outstanding amount: €35,574. Approval required.',
        speech: 'Attention. The VAT return for Spain, Modelo 303, is approaching its deadline of July 20th. The outstanding amount is thirty-five thousand five hundred and seventy-four euros. I recommend submitting this immediately.',
      },
      {
        delay: 14000, type: 'info' as const,
        title: 'Payroll Cycle Ready',
        body: 'June 2026 payroll processed for 5 employees. Net payment: €22,840 equivalent.',
        speech: 'The payroll run for June 2026 is complete for all five employees in Spain, the Netherlands, and the United States. Total net payment is twenty-two thousand eight hundred and forty euros.',
      },
      {
        delay: 24000, type: 'warn' as const,
        title: 'Unreconciled Transactions',
        body: '3 transactions awaiting reconciliation. Open the Ledger tab to review.',
        speech: 'There are three transactions that have not yet been reconciled. These are the US license revenue, the Netherlands B2B consultancy invoice, and the business travel expense to Amsterdam. I recommend processing these now.',
      },
      {
        delay: 38000, type: 'ok' as const,
        title: 'IRS Form 941 Prepared',
        body: 'Q2 2026 US quarterly return automatically compiled. Amount: $14,820.',
        speech: 'Good news. IRS Form 941 for the second quarter has been automatically generated. The total amount due is fourteen thousand eight hundred and twenty US dollars. I am ready to submit as soon as you approve.',
      },
      {
        delay: 52000, type: 'warn' as const,
        title: 'Seguridad Social Deadline',
        body: 'Employer contribution June — deadline June 28. Total: €9,128. SEPA payment scheduled.',
        speech: 'The Spanish Social Security employer contribution for June has a deadline of June 28th. The total is nine thousand one hundred and twenty-eight euros. The SEPA payment has been scheduled but not yet confirmed.',
      },
      {
        delay: 70000, type: 'info' as const,
        title: 'P&L Update — Net Margin Rising',
        body: `Net margin improved to ${marginRef.current.toFixed(1)}%. Q2 target of 18% nearly reached.`,
        speech: `Financial update. Net margin is now ${marginRef.current.toFixed(1)} percent, close to the quarterly target of eighteen percent. Revenue growth in the Netherlands and the United States is offsetting rising payroll costs in Spain.`,
      },
    ];

    const timers: ReturnType<typeof setTimeout>[] = [];

    PROACTIVE_ALERTS.forEach(({ delay, type, title, body, speech }) => {
      timers.push(setTimeout(() => {
        pushAlert(title, body, type);
        notifyInfo(title, body, 12000);
        speak(speech);
      }, delay));
    });

    return () => timers.forEach(clearTimeout);
  }, [pushAlert, speak]);

  // ── Greet on mount ─────────────────────────────────────────────────────────
  useEffect(() => {
    const t = setTimeout(() => {
      speak('Welcome to AippieTax AI Accountant. I manage your international bookkeeping, payroll, and tax filings for Spain, the Netherlands, and the United States — fully autonomous, with zero manual intervention required.');
    }, 1800);
    return () => clearTimeout(t);
  }, [speak]);

  // ── P&L Calculations ──────────────────────────────────────────────────────
  const grossRevenue = transactions.filter(t => t.category === 'revenue').reduce((s, t) => s + t.credit, 0);
  const totalOpEx = transactions.filter(t => t.category !== 'revenue' && t.category !== 'tax_reserve').reduce((s, t) => s + t.debit, 0);
  const taxReserve = transactions.filter(t => t.category === 'tax_reserve').reduce((s, t) => s + t.debit, 0);
  const grossProfit = grossRevenue - transactions.filter(t => t.category === 'cogs').reduce((s, t) => s + t.debit, 0);
  const netProfit = grossRevenue - totalOpEx - taxReserve;
  const margin = grossRevenue > 0 ? (netProfit / grossRevenue) * 100 : 0;
  marginRef.current = margin;

  // VAT reserves by jurisdiction
  const vatES = grossRevenue * 0.21 * 0.5;
  const vatNL = grossRevenue * 0.21 * 0.2;
  const corpTaxUS = Math.max(0, netProfit * 0.21);

  // ── Autonomous engine simulate ────────────────────────────────────────────
  const runEngine = useCallback(async () => {
    if (processing) return;
    setProcessing(true);
    setEngine(true);
    speak('Autonomous accounting engine activated. Scanning all transactions, reconciling ledger entries, and computing multi-jurisdiction tax reserves. Stand by.');

    await new Promise(r => setTimeout(r, 1200));
    setTxs(prev => prev.map(t => ({ ...t, reconciled: true })));

    await new Promise(r => setTimeout(r, 800));
    speak(`Ledger reconciled. Gross revenue: ${fmt(grossRevenue)}. Net profit: ${fmt(netProfit)}. Margin: ${margin.toFixed(1)} percent. Tax reserves computed for Spain, Netherlands, and United States.`);

    await new Promise(r => setTimeout(r, 2000));
    // Update pending tax subs to transmitting
    setTaxSubs(prev => prev.map(s =>
      s.status === 'pending' ? { ...s, status: 'transmitting' } : s
    ));
    speak('Initiating encrypted gateway transmissions to AEAT, Belastingdienst, and IRS portals. All filings comply with current regulations.');

    await new Promise(r => setTimeout(r, 1500));
    setTaxSubs(prev => prev.map(s =>
      s.status === 'transmitting' ? { ...s, status: 'accepted', reference: `AUTO-${Date.now().toString(36).toUpperCase()}`, submitted_at: new Date().toISOString() } : s
    ));
    speak('All government submissions accepted. Zero manual intervention required. AippieTax autonomous cycle complete.');

    setProcessing(false);
  }, [processing, grossRevenue, netProfit, margin, speak]);

  // ── Run payroll ───────────────────────────────────────────────────────────
  const runPayroll = useCallback(async () => {
    setProcessing(true);
    speak('Executing international payroll run for June 2026. Computing IRPF, Seguridad Social, Loonheffing, and Federal withholding for all jurisdictions.');
    await new Promise(r => setTimeout(r, 1000));
    setRuns(prev => prev.map(r => ({ ...r, status: 'paid' })));
    speak(`Payroll complete. ${employees.length} employees paid across Spain, Netherlands, and United States. All payslips digitally generated and dispatched.`);
    setProcessing(false);
  }, [employees.length, speak]);

  // ── Category breakdown ────────────────────────────────────────────────────
  const catBreakdown = (['revenue', 'cogs', 'payroll', 'rent', 'software', 'marketing', 'legal', 'travel', 'bank_charge', 'tax_reserve', 'other'] as TxCategory[]).map(cat => {
    const total = transactions.filter(t => t.category === cat).reduce((s, t) => s + (cat === 'revenue' ? t.credit : t.debit), 0);
    return { cat, total };
  }).filter(x => x.total > 0).sort((a, b) => b.total - a.total);
  const maxCat = Math.max(...catBreakdown.map(x => x.total), 1);

  return (
    <div className="acc-wrap">
      {/* ── Push alert overlay ──────────────────────────────────────────────── */}
      <div className="acc-alerts">
        {alerts.map(a => (
          <div key={a.id} className={`acc-alert acc-alert--${a.type}`}>
            <div className="acc-alert__icon">
              {a.type === 'warn' ? <AlertTriangle size={14} /> : a.type === 'ok' ? <CheckCircle2 size={14} /> : <Bell size={14} />}
            </div>
            <div className="acc-alert__body">
              <div className="acc-alert__title">{a.title}</div>
              <div className="acc-alert__text">{a.body}</div>
            </div>
            <button className="acc-alert__close" onClick={() => dismissAlert(a.id)}><X size={12} /></button>
          </div>
        ))}
      </div>

      {/* ── Header ──────────────────────────────────────────────────────────── */}
      <div className="acc-header">
        <div className="acc-header__left">
          <div className="acc-header__logo">
            <Landmark size={18} />
          </div>
          <div>
            <div className="acc-header__title">AippieTax AI Accountant</div>
            <div className="acc-header__sub">AIPPIETAX S.A. · Enterprise v86 · ES · NL · US</div>
          </div>
          <span className={`acc-chip ${engineRunning ? 'acc-chip--green acc-chip--pulse' : 'acc-chip--dim'}`}>
            {engineRunning ? '● AUTONOMOUS ACTIVE' : '○ READY'}
          </span>
        </div>
        <button
          className={`acc-engine-btn ${processing ? 'acc-engine-btn--running' : ''}`}
          onClick={runEngine}
          disabled={processing}
        >
          {processing
            ? <><RefreshCw size={12} className="acc-spin" /> Processing…</>
            : <><Zap size={12} /> Run Full AI Cycle</>
          }
        </button>
      </div>

      {/* ── AI Avatar strip ─────────────────────────────────────────────────── */}
      <div className="acc-avatar-strip">
        <AccountingAvatar speaking={speaking} caption={caption} />
        <div className="acc-kpis">
          <div className="acc-kpi acc-kpi--revenue">
            <TrendingUp size={16} />
            <div>
              <div className="acc-kpi__val">{fmt(grossRevenue)}</div>
              <div className="acc-kpi__lbl">Gross Revenue</div>
            </div>
          </div>
          <div className="acc-kpi acc-kpi--opex">
            <TrendingDown size={16} />
            <div>
              <div className="acc-kpi__val">{fmt(totalOpEx + taxReserve)}</div>
              <div className="acc-kpi__lbl">Total OpEx + Tax</div>
            </div>
          </div>
          <div className={`acc-kpi ${netProfit >= 0 ? 'acc-kpi--profit' : 'acc-kpi--loss'}`}>
            <BarChart3 size={16} />
            <div>
              <div className="acc-kpi__val">{fmt(netProfit)}</div>
              <div className="acc-kpi__lbl">Net Profit</div>
            </div>
          </div>
          <div className="acc-kpi acc-kpi--margin">
            <Activity size={16} />
            <div>
              <div className="acc-kpi__val">{margin.toFixed(1)}%</div>
              <div className="acc-kpi__lbl">Net Margin</div>
            </div>
          </div>
        </div>
      </div>

      {/* ── Tabs ────────────────────────────────────────────────────────────── */}
      <div className="acc-tabs">
        {([
          ['pl',         <BarChart3 size={13} />,    'P&L Dashboard'],
          ['ledger',     <FileText size={13} />,     'Ledger'],
          ['payroll',    <Users size={13} />,         'Payroll Engine'],
          ['gateway',    <ShieldCheck size={13} />,  'Gov Gateways'],
          ['chat',       <MessageSquare size={13} />, 'AI CFO Chat'],
          ['verifactu',  <ScrollText size={13} />,   'Verifactu ES'],
        ] as [ActiveTab, JSX.Element, string][]).map(([id, icon, label]) => (
          <button
            key={id}
            className={`acc-tab ${activeTab === id ? 'acc-tab--active' : ''}`}
            onClick={() => setActiveTab(id)}
          >
            {icon} {label}
          </button>
        ))}
      </div>

      {/* ═══════════════════════════════════════════════════════════════════════
          TAB: P&L Dashboard
      ═══════════════════════════════════════════════════════════════════════ */}
      {activeTab === 'pl' && (
        <div className="acc-panel">
          {/* Tax reserve cards */}
          <div className="acc-pl-reserves">
            <div className="acc-reserve-card acc-reserve-card--es">
              <div className="acc-reserve-card__flag">🇪🇸</div>
              <div className="acc-reserve-card__body">
                <div className="acc-reserve-card__authority">AEAT — España</div>
                <div className="acc-reserve-card__line"><span>IVA/VAT Reserve (21%)</span><strong>{fmt(vatES)}</strong></div>
                <div className="acc-reserve-card__line"><span>IRPF Retenciones</span><strong>{fmt(employees.filter(e => e.jurisdiction === 'ES').reduce((s, e) => s + computePayroll(e).tax_withheld, 0))}</strong></div>
                <div className="acc-reserve-card__line"><span>Seguridad Social</span><strong>{fmt(employees.filter(e => e.jurisdiction === 'ES').reduce((s, e) => s + computePayroll(e).ss_employer * 12, 0) / 12)}</strong></div>
              </div>
            </div>
            <div className="acc-reserve-card acc-reserve-card--nl">
              <div className="acc-reserve-card__flag">🇳🇱</div>
              <div className="acc-reserve-card__body">
                <div className="acc-reserve-card__authority">Belastingdienst — NL</div>
                <div className="acc-reserve-card__line"><span>BTW Reserve (21%)</span><strong>{fmt(vatNL)}</strong></div>
                <div className="acc-reserve-card__line"><span>Loonheffing</span><strong>{fmt(employees.filter(e => e.jurisdiction === 'NL').reduce((s, e) => s + computePayroll(e).tax_withheld, 0))}</strong></div>
                <div className="acc-reserve-card__line"><span>Werkgeverspremies</span><strong>{fmt(employees.filter(e => e.jurisdiction === 'NL').reduce((s, e) => s + computePayroll(e).ss_employer, 0))}</strong></div>
              </div>
            </div>
            <div className="acc-reserve-card acc-reserve-card--us">
              <div className="acc-reserve-card__flag">🇺🇸</div>
              <div className="acc-reserve-card__body">
                <div className="acc-reserve-card__authority">IRS — United States</div>
                <div className="acc-reserve-card__line"><span>Corp Tax Reserve (21%)</span><strong>{fmt(corpTaxUS, 'USD')}</strong></div>
                <div className="acc-reserve-card__line"><span>FICA Withholding</span><strong>{fmt(employees.filter(e => e.jurisdiction === 'US').reduce((s, e) => s + computePayroll(e).ss_employee, 0), 'USD')}</strong></div>
                <div className="acc-reserve-card__line"><span>Employer FICA</span><strong>{fmt(employees.filter(e => e.jurisdiction === 'US').reduce((s, e) => s + computePayroll(e).ss_employer, 0), 'USD')}</strong></div>
              </div>
            </div>
          </div>

          {/* P&L summary */}
          <div className="acc-pl-summary">
            <div className="acc-pl-row acc-pl-row--revenue">
              <span>Gross Revenue</span>
              <span>{fmt(grossRevenue)}</span>
            </div>
            <div className="acc-pl-row acc-pl-row--sub">
              <span>— Cost of Goods Sold</span>
              <span>({fmt(transactions.filter(t => t.category === 'cogs').reduce((s, t) => s + t.debit, 0))})</span>
            </div>
            <div className="acc-pl-row acc-pl-row--gross">
              <span>Gross Profit</span>
              <span>{fmt(grossProfit)}</span>
            </div>
            <div className="acc-pl-row acc-pl-row--sub">
              <span>— Operating Expenses</span>
              <span>({fmt(totalOpEx)})</span>
            </div>
            <div className="acc-pl-row acc-pl-row--sub">
              <span>— Tax Reserves</span>
              <span>({fmt(taxReserve)})</span>
            </div>
            <div className="acc-pl-row acc-pl-row--net">
              <span>Net Profit</span>
              <span>{fmt(netProfit)}</span>
            </div>
            <div className="acc-pl-row acc-pl-row--margin">
              <span>Net Margin</span>
              <span>{margin.toFixed(1)}%</span>
            </div>
          </div>

          {/* Category bars */}
          <div className="acc-cat-section">
            <div className="acc-section-title"><BarChart3 size={12} /> Expense Breakdown</div>
            <div className="acc-cat-list">
              {catBreakdown.map(({ cat, total }) => (
                <div key={cat} className="acc-cat-row">
                  <span className="acc-cat-dot" style={{ background: CAT_COLORS[cat] }} />
                  <span className="acc-cat-name">{CAT_LABELS[cat]}</span>
                  <MiniBar value={total} max={maxCat} color={CAT_COLORS[cat]} />
                  <span className="acc-cat-val">{fmt(total)}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* ═══════════════════════════════════════════════════════════════════════
          TAB: Ledger
      ═══════════════════════════════════════════════════════════════════════ */}
      {activeTab === 'ledger' && (
        <div className="acc-panel">
          <div className="acc-section-title" style={{ marginBottom: 10 }}>
            <FileText size={12} /> Automated Transaction Ledger
            <span style={{ marginLeft: 'auto', fontSize: 10, color: 'rgba(148,163,184,0.6)' }}>
              {transactions.filter(t => t.reconciled).length}/{transactions.length} reconciled
            </span>
          </div>
          <div className="acc-ledger-table">
            <div className="acc-ledger-head">
              <span>Date</span>
              <span>Description</span>
              <span>Category</span>
              <span>Debit</span>
              <span>Credit</span>
              <span>Status</span>
            </div>
            {transactions.map(tx => (
              <div key={tx.id} className={`acc-ledger-row ${!tx.reconciled ? 'acc-ledger-row--unreconciled' : ''}`}>
                <span className="acc-ledger-date">{fmtDate(tx.tx_date)}</span>
                <span className="acc-ledger-desc">
                  {tx.auto_categorized && <span className="acc-ai-badge">AI</span>}
                  {tx.description}
                </span>
                <span>
                  <span className="acc-cat-pill" style={{ background: `${CAT_COLORS[tx.category]}18`, color: CAT_COLORS[tx.category], borderColor: `${CAT_COLORS[tx.category]}30` }}>
                    {CAT_LABELS[tx.category]}
                  </span>
                </span>
                <span className="acc-debit">{tx.debit > 0 ? fmt(tx.debit, tx.currency) : '—'}</span>
                <span className="acc-credit">{tx.credit > 0 ? fmt(tx.credit, tx.currency) : '—'}</span>
                <span><StatusBadge s={tx.reconciled ? 'accepted' : 'pending'} /></span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ═══════════════════════════════════════════════════════════════════════
          TAB: Payroll Engine
      ═══════════════════════════════════════════════════════════════════════ */}
      {activeTab === 'payroll' && (
        <div className="acc-panel">
          <div className="acc-payroll-header">
            <div className="acc-section-title"><Users size={12} /> Payroll Engine — June 2026</div>
            <button className="acc-run-btn" onClick={runPayroll} disabled={processing}>
              {processing ? <><RefreshCw size={11} className="acc-spin" /> Computing…</> : <><Play size={11} /> Run Payroll Cycle</>}
            </button>
          </div>

          {employees.map(emp => {
            const calc = computePayroll(emp);
            const jm = JURIS_META[emp.jurisdiction];
            const run = payrollRuns.find(r => r.employee_id === emp.id);
            const isOpen = expandedEmp === emp.id;
            return (
              <div key={emp.id} className="acc-emp-card">
                <div className="acc-emp-card__top" onClick={() => setExpEmp(isOpen ? null : emp.id)}>
                  <div className="acc-emp-flag">{jm.flag}</div>
                  <div className="acc-emp-info">
                    <div className="acc-emp-name">{emp.full_name}</div>
                    <div className="acc-emp-role">{emp.role} · {jm.label}</div>
                  </div>
                  <div className="acc-emp-net">
                    <div className="acc-emp-net__val">{fmt(calc.net_pay, emp.currency)}</div>
                    <div className="acc-emp-net__lbl">Net / month</div>
                  </div>
                  <StatusBadge s={run?.status ?? 'pending'} />
                  {isOpen ? <ChevronUp size={14} /> : <ChevronDown size={14} />}
                </div>
                {isOpen && (
                  <div className="acc-emp-breakdown">
                    <div className="acc-payslip">
                      <div className="acc-payslip__title">Digital Payslip — June 2026</div>
                      <div className="acc-payslip__row"><span>Gross Salary</span><span>{fmt(calc.gross, emp.currency)}</span></div>
                      <div className="acc-payslip__row acc-payslip__row--deduct">
                        <span>{emp.jurisdiction === 'ES' ? 'IRPF Retención' : emp.jurisdiction === 'NL' ? 'Loonheffing' : 'Federal/State Tax'} ({(jm.taxRate * 100).toFixed(1)}%)</span>
                        <span>- {fmt(calc.tax_withheld, emp.currency)}</span>
                      </div>
                      <div className="acc-payslip__row acc-payslip__row--deduct">
                        <span>{emp.jurisdiction === 'ES' ? 'Cuota S.S. Trabajador' : emp.jurisdiction === 'NL' ? 'Werknemerspremies' : 'FICA Employee'} ({(jm.ss * 100).toFixed(1)}%)</span>
                        <span>- {fmt(calc.ss_employee, emp.currency)}</span>
                      </div>
                      <div className="acc-payslip__row acc-payslip__row--net"><span>NET PAY</span><span>{fmt(calc.net_pay, emp.currency)}</span></div>
                      <div className="acc-payslip__row acc-payslip__row--employer">
                        <span>{emp.jurisdiction === 'ES' ? 'Cuota S.S. Empresa' : emp.jurisdiction === 'NL' ? 'Werkgeverspremies' : 'FICA Employer'} ({(jm.ssEmployer * 100).toFixed(1)}%)</span>
                        <span>{fmt(calc.ss_employer, emp.currency)}</span>
                      </div>
                      <div className="acc-payslip__actions">
                        <button className="acc-payslip__btn"><Download size={11} /> Download PDF</button>
                        <button className="acc-payslip__btn"><Send size={11} /> Email Employee</button>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            );
          })}

          {/* Payroll totals */}
          <div className="acc-payroll-totals">
            <div className="acc-pt-row">
              <span>Total Gross Salaries</span>
              <span>{fmt(payrollRuns.reduce((s, r) => s + r.gross, 0))}</span>
            </div>
            <div className="acc-pt-row">
              <span>Total Tax Withheld</span>
              <span>{fmt(payrollRuns.reduce((s, r) => s + r.tax_withheld, 0))}</span>
            </div>
            <div className="acc-pt-row">
              <span>Total Social Security (All)</span>
              <span>{fmt(payrollRuns.reduce((s, r) => s + r.ss_employee + r.ss_employer, 0))}</span>
            </div>
            <div className="acc-pt-row acc-pt-row--total">
              <span>Total Net Pay</span>
              <span>{fmt(payrollRuns.reduce((s, r) => s + r.net_pay, 0))}</span>
            </div>
          </div>
        </div>
      )}

      {/* ═══════════════════════════════════════════════════════════════════════
          TAB: Government Gateways
      ═══════════════════════════════════════════════════════════════════════ */}
      {activeTab === 'gateway' && (
        <div className="acc-panel">
          <div className="acc-section-title"><ShieldCheck size={12} /> Government Submission Gateways</div>
          <div className="acc-gw-legend">
            <Lock size={10} /> All transmissions use TLS 1.3 · AES-256 end-to-end encryption · Qualified e-signature
          </div>

          {(['AEAT', 'Belastingdienst', 'IRS'] as const).map(auth => {
            const subs = taxSubs.filter(s => s.authority === auth);
            const flag = auth === 'AEAT' ? '🇪🇸' : auth === 'Belastingdienst' ? '🇳🇱' : '🇺🇸';
            const allOk = subs.length > 0 && subs.every(s => s.status === 'accepted' || s.status === 'paid');
            return (
              <div key={auth} className="acc-gw-block">
                <div className="acc-gw-block__header">
                  <span className="acc-gw-flag">{flag}</span>
                  <span className="acc-gw-auth">{auth}</span>
                  <div className="acc-gw-tunnel">
                    <div className="acc-gw-tunnel__dots">
                      {[0,1,2,3,4].map(i => (
                        <div key={i} className={`acc-gw-dot ${allOk ? 'acc-gw-dot--green' : 'acc-gw-dot--amber'}`} style={{ animationDelay: `${i * 0.15}s` }} />
                      ))}
                    </div>
                    <span className="acc-gw-tunnel__label">ENCRYPTED TUNNEL {allOk ? '✓ SECURE' : '⟳ ACTIVE'}</span>
                  </div>
                  <Server size={13} style={{ color: allOk ? '#22c55e' : '#f59e0b' }} />
                </div>
                <div className="acc-gw-subs">
                  {subs.map(sub => (
                    <div key={sub.id} className="acc-gw-sub">
                      <div className="acc-gw-sub__left">
                        <div className="acc-gw-sub__form">{sub.form_type}</div>
                        <div className="acc-gw-sub__meta">
                          Period: {sub.period}
                          {sub.reference && <> · Ref: <code>{sub.reference}</code></>}
                          {sub.submitted_at && <> · {new Date(sub.submitted_at).toLocaleDateString('en-GB')}</>}
                        </div>
                      </div>
                      <div className="acc-gw-sub__right">
                        <span className="acc-gw-amount">{fmt(sub.amount, sub.currency)}</span>
                        <StatusBadge s={sub.status} />
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            );
          })}

          {/* API log */}
          <div className="acc-api-log">
            <div className="acc-section-title"><Activity size={12} /> Live API Transmission Log</div>
            <div className="acc-log-frame">
              {taxSubs.filter(s => s.submitted_at).map((s, i) => (
                <div key={i} className="acc-log-line">
                  <span className="acc-log-ts">{s.submitted_at ? new Date(s.submitted_at).toISOString().replace('T', ' ').slice(0, 19) : ''}</span>
                  <span className="acc-log-method">POST</span>
                  <span className="acc-log-url">https://api.{s.authority.toLowerCase()}.eu/v3/submit</span>
                  <span className="acc-log-status acc-log-status--ok">200 OK</span>
                  <span className="acc-log-ref">{s.reference}</span>
                </div>
              ))}
              {taxSubs.filter(s => s.status === 'transmitting').map((s, i) => (
                <div key={`tx-${i}`} className="acc-log-line acc-log-line--active">
                  <span className="acc-log-ts">{new Date().toISOString().replace('T', ' ').slice(0, 19)}</span>
                  <span className="acc-log-method">POST</span>
                  <span className="acc-log-url">https://api.{s.authority.toLowerCase()}.eu/v3/submit</span>
                  <span className="acc-log-status acc-log-status--pending">TRANSMITTING…</span>
                </div>
              ))}
              {taxSubs.filter(s => s.status !== 'accepted' && s.status !== 'paid' && s.status !== 'transmitting').map((s, i) => (
                <div key={`pend-${i}`} className="acc-log-line acc-log-line--dim">
                  <span className="acc-log-ts">--:--:--</span>
                  <span className="acc-log-method">—</span>
                  <span className="acc-log-url">{s.form_type} · Awaiting period close</span>
                  <span className="acc-log-status acc-log-status--pending">QUEUED</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* ═══════════════════════════════════════════════════════════════════════
          TAB: AI CFO Chat
      ═══════════════════════════════════════════════════════════════════════ */}
      {activeTab === 'chat' && (
        <div className="acc-panel acc-chat-panel">
          {/* Chat header */}
          <div className="acc-chat-header">
            <div className="acc-chat-header__left">
              <div className="acc-chat-avatar">
                <Bot size={18} style={{ color: '#38bdf8' }} />
              </div>
              <div>
                <div className="acc-chat-header__title">Aippie AI CFO</div>
                <div className="acc-chat-header__sub">Tax · Accounting · Payroll · VAT · ES · NL · US</div>
              </div>
              <span className="acc-chip acc-chip--green" style={{ marginLeft: 8 }}>● ONLINE</span>
            </div>
            <div className="acc-chat-header__right">
              {/* Lang selector */}
              <div className="acc-chat-lang-btns">
                {(['nl','en','es'] as const).map(l => (
                  <button key={l} className={`acc-chat-lang-btn${chatLang === l ? ' acc-chat-lang-btn--active' : ''}`}
                    onClick={() => setChatLang(l)}>
                    {l.toUpperCase()}
                  </button>
                ))}
              </div>
              {/* Voice toggle */}
              <button className={`acc-chat-icon-btn${chatVoice ? ' acc-chat-icon-btn--active' : ''}`}
                onClick={() => setChatVoice(v => !v)} title="Aippie reads answers aloud">
                {chatVoice ? <Volume2 size={14} /> : <MicOff size={14} />}
              </button>
              {/* Clear */}
              <button className="acc-chat-icon-btn" onClick={clearChat} title="New session">
                <Trash2 size={14} />
              </button>
            </div>
          </div>

          {/* Quick prompts */}
          <div className="acc-chat-quick">
            {[
              { nl: 'Calculate VAT return', en: 'Calculate VAT return', es: 'Calculate VAT return' }[chatLang],
              { nl: 'Explain payslip', en: 'Explain payslip', es: 'Explain payslip' }[chatLang],
              { nl: 'Deductible expenses overview', en: 'Deductible expenses', es: 'Deductible expenses' }[chatLang],
              { nl: 'File IRS Form 941', en: 'File IRS Form 941', es: 'File IRS Form 941' }[chatLang],
              { nl: 'P&L analysis', en: 'P&L analysis', es: 'P&L analysis' }[chatLang],
            ].map(p => p && (
              <button key={p} className="acc-chat-quick-btn" onClick={() => sendChat(p)}>
                {p}
              </button>
            ))}
          </div>

          {/* Messages */}
          <div className="acc-chat-messages">
            {chatMessages.map(msg => (
              <div key={msg.id} className={`acc-chat-msg acc-chat-msg--${msg.role}`}>
                {msg.role === 'assistant' && (
                  <div className="acc-chat-msg__avatar">
                    <Bot size={13} style={{ color: '#38bdf8' }} />
                  </div>
                )}
                <div className="acc-chat-msg__bubble">
                  <div className="acc-chat-msg__text">{msg.content}</div>
                  <div className="acc-chat-msg__footer">
                    <span className="acc-chat-msg__time">
                      {new Date(msg.ts).toLocaleTimeString('nl-NL', { hour: '2-digit', minute: '2-digit' })}
                    </span>
                    {msg.role === 'assistant' && (
                      <button className="acc-chat-copy-btn"
                        onClick={() => navigator.clipboard.writeText(msg.content)}
                        title="Kopieer">
                        <Copy size={9} />
                      </button>
                    )}
                  </div>
                </div>
                {msg.role === 'user' && (
                  <div className="acc-chat-msg__avatar acc-chat-msg__avatar--user">
                    <Users size={13} style={{ color: '#94a3b8' }} />
                  </div>
                )}
              </div>
            ))}
            {chatLoading && (
              <div className="acc-chat-msg acc-chat-msg--assistant">
                <div className="acc-chat-msg__avatar"><Bot size={13} style={{ color: '#38bdf8' }} /></div>
                <div className="acc-chat-msg__bubble acc-chat-typing">
                  <span /><span /><span />
                </div>
              </div>
            )}
            <div ref={chatEndRef} />
          </div>

          {/* Input bar */}
          <div className="acc-chat-input-bar">
            <input
              className="acc-chat-input"
              placeholder={
                chatLang === 'nl' ? 'Ask a question about taxes, VAT, payroll…' :
                chatLang === 'es' ? 'Ask a question about taxes, VAT, payroll…' :
                'Ask about taxes, VAT, payroll, bookkeeping…'
              }
              value={chatInput}
              onChange={e => setChatInput(e.target.value)}
              onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendChat(); } }}
              disabled={chatLoading}
              autoComplete="off"
            />
            <button
              className={`acc-chat-send-btn${chatLoading ? ' acc-chat-send-btn--loading' : ''}`}
              onClick={() => sendChat()}
              disabled={chatLoading || !chatInput.trim()}
            >
              {chatLoading ? <RefreshCw size={15} className="acc-spin" /> : <Send size={15} />}
            </button>
          </div>

          <div className="acc-chat-footer">
            <Lock size={9} /> Encrypted · Aippie AI CFO · AIPPIETAX S.A. · Not for official tax advice
          </div>
        </div>
      )}

      {/* ═══════════════════════════════════════════════════════════════════════
          TAB: VERIFACTU — Spanish Fiscal Compliance
      ═══════════════════════════════════════════════════════════════════════ */}
      {activeTab === 'verifactu' && (
        <div className="acc-panel" style={{ padding: 0, overflow: 'hidden' }}>
          <Suspense fallback={
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 48, color: '#64748b', gap: 10 }}>
              <RefreshCw size={16} className="acc-spin" /> Verifactu laden…
            </div>
          }>
            <AippieVerifactuView deviceKey={deviceKey} />
          </Suspense>
        </div>
      )}
    </div>
  );
}
