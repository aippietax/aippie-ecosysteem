import { useState, useCallback, useEffect } from 'react';
import { Megaphone, Check, X, AlertTriangle, Eye, ChevronRight, Wallet } from 'lucide-react';
import { supabase } from '../lib/supabase';
import type { User as AuthUser } from '@supabase/supabase-js';

const AD_RATE_PER_WEEK = 5; // €5 per week

interface Props {
  user: AuthUser | null;
  onClose: () => void;
}

const WEEKS = [1, 2, 4, 8, 12];

export default function PlatformAdSubmitView({ user, onClose }: Props) {
  const [company, setCompany] = useState('');
  const [text, setText] = useState('');
  const [imageUrl, setImageUrl] = useState('');
  const [linkUrl, setLinkUrl] = useState('');
  const [weeks, setWeeks] = useState(1);
  const [step, setStep] = useState<'form' | 'preview' | 'pay' | 'done'>('form');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [walletBalance, setWalletBalance] = useState<number | null>(null);
  const [useWallet, setUseWallet] = useState(true);

  const price = weeks * AD_RATE_PER_WEEK;

  // Fetch APC wallet balance
  useEffect(() => {
    if (!user) return;
    supabase
      .from('digital_wallets')
      .select('balance')
      .eq('user_id', user.id)
      .maybeSingle()
      .then(({ data }) => { if (data) setWalletBalance(data.balance); });
  }, [user]);

  const handleSubmit = useCallback(async () => {
    if (!user) { setError('Please log in first.'); return; }
    if (!company.trim() || !text.trim()) { setError('Please enter company name and ad text.'); return; }
    setBusy(true);
    setError('');

    // APC wallet auto-deduction
    if (useWallet && walletBalance !== null) {
      if (walletBalance < price) { setError(`Insufficient APC balance (€${walletBalance.toFixed(2)}). Choose IBAN payment.`); setBusy(false); return; }
      const { error: walErr } = await supabase
        .from('digital_wallets')
        .update({ balance: walletBalance - price })
        .eq('user_id', user.id);
      if (walErr) { setError('Wallet payment failed: ' + walErr.message); setBusy(false); return; }
    }

    const paidUntil = new Date(Date.now() + weeks * 7 * 24 * 60 * 60 * 1000).toISOString();
    const { error: dbErr } = await supabase.from('platform_ads').insert({
      user_id: user.id,
      company_name: company.trim(),
      ad_text: text.trim(),
      image_url: imageUrl.trim() || null,
      link_url: linkUrl.trim() || null,
      paid_until: paidUntil,
      approved: true,
    });
    setBusy(false);
    if (dbErr) { setError(dbErr.message); return; }
    setStep('done');
  }, [user, company, text, imageUrl, linkUrl, weeks, price, useWallet, walletBalance]);

  return (
    <div className="pad-submit-overlay" onClick={onClose}>
      <div className="pad-submit-modal" onClick={e => e.stopPropagation()}>

        {/* Header */}
        <div className="pad-submit-header">
          <Megaphone size={18} style={{ color: '#38bdf8' }} />
          <span>Advertise on Aippie</span>
          <button className="pad-submit-close" onClick={onClose}><X size={16} /></button>
        </div>

        {step === 'done' ? (
          <div className="pad-submit-done">
            <div className="pad-submit-done__icon"><Check size={32} style={{ color: '#22c55e' }} /></div>
            <h3>Advertisement posted!</h3>
            <p>Your ad now appears in the rotating banner throughout the Aippie app.</p>
            <p className="pad-submit-done__detail">Active for <strong>{weeks} week{weeks > 1 ? 's' : ''}</strong> (€{price})</p>
            <button className="pad-submit-primary" onClick={onClose}>Close</button>
          </div>
        ) : step === 'preview' ? (
          <div className="pad-submit-preview">
            <p className="pad-submit-section-label">Here's how your ad looks:</p>
            <div className="pad-preview-bar">
              <div className="pad-preview-bar__left">
                <Megaphone size={11} style={{ color: '#38bdf8' }} />
                <span className="pad-bar__label" style={{ fontSize: 9 }}>AD</span>
              </div>
              <div className="pad-preview-bar__content">
                {imageUrl && <img src={imageUrl} alt="" className="pad-bar__img" />}
                <span style={{ color: '#38bdf8', fontWeight: 700, fontSize: 11 }}>{company || 'Company Name'}</span>
                <span style={{ color: '#94a3b8', fontSize: 11 }}>{text || 'Your ad text...'}</span>
              </div>
            </div>
            <div className="pad-submit-pricing">
              <div className="pad-submit-pricing__row">
                <span>Duration</span><span><strong>{weeks} week{weeks > 1 ? 's' : ''}</strong></span>
              </div>
              <div className="pad-submit-pricing__row">
                <span>Price</span><span style={{ color: '#22c55e', fontWeight: 700, fontSize: 18 }}>€{price}</span>
              </div>
              <div className="pad-submit-pricing__row pad-submit-pricing__row--note">
                <span>Reach</span><span>All Aippie users · 3-second rotation</span>
              </div>
              {walletBalance !== null && (
                <div className="pad-submit-pricing__row">
                  <span>APC Balance</span>
                  <span style={{ color: walletBalance >= price ? '#22c55e' : '#ef4444', fontWeight: 600 }}>
                    €{walletBalance.toFixed(2)}
                  </span>
                </div>
              )}
            </div>
            {/* Payment method */}
            {walletBalance !== null && (
              <div className="pad-submit-pay-method">
                <button
                  className={`pad-submit-pay-btn${useWallet ? ' pad-submit-pay-btn--active' : ''}`}
                  onClick={() => setUseWallet(true)}
                >
                  <Wallet size={13} /> APC Wallet (automatic)
                </button>
                <button
                  className={`pad-submit-pay-btn${!useWallet ? ' pad-submit-pay-btn--active' : ''}`}
                  onClick={() => setUseWallet(false)}
                >
                  IBAN transfer
                </button>
              </div>
            )}
            {error && <p className="pad-submit-error"><AlertTriangle size={12} />{error}</p>}
            <div className="pad-submit-actions">
              <button className="pad-submit-secondary" onClick={() => setStep('form')}>Back</button>
              <button className="pad-submit-primary" onClick={handleSubmit} disabled={busy}>
                {busy ? <span className="modal__spinner" style={{ width: 12, height: 12 }} /> : <ChevronRight size={14} />}
                Pay €{price} &amp; Activate
              </button>
            </div>
            <p className="pad-submit-disclaimer">Payment via IBAN transfer to AIPPIETAX S.A. — ad remains active after verification.</p>
          </div>
        ) : (
          <div className="pad-submit-form">
            <div className="pad-submit-field">
              <label>Company Name / Name *</label>
              <input value={company} onChange={e => setCompany(e.target.value)} placeholder="E.g. My Company BV" maxLength={60} />
            </div>
            <div className="pad-submit-field">
              <label>Ad Text * <span>(max. 120 characters)</span></label>
              <textarea value={text} onChange={e => setText(e.target.value)} placeholder="Your message to Aippie users..." maxLength={120} rows={2} />
              <span className="pad-submit-char">{text.length}/120</span>
            </div>
            <div className="pad-submit-field">
              <label>Image URL <span>(optional)</span></label>
              <input value={imageUrl} onChange={e => setImageUrl(e.target.value)} placeholder="https://..." type="url" />
            </div>
            <div className="pad-submit-field">
              <label>Website URL <span>(optional)</span></label>
              <input value={linkUrl} onChange={e => setLinkUrl(e.target.value)} placeholder="https://yoursite.com" type="url" />
            </div>
            <div className="pad-submit-field">
              <label>Ad Duration</label>
              <div className="pad-submit-weeks">
                {WEEKS.map(w => (
                  <button
                    key={w}
                    className={`pad-submit-week-btn${weeks === w ? ' pad-submit-week-btn--active' : ''}`}
                    onClick={() => setWeeks(w)}
                  >
                    {w}w<span>€{w * 5}</span>
                  </button>
                ))}
              </div>
            </div>
            <div className="pad-submit-actions">
              <button className="pad-submit-secondary" onClick={onClose}>Cancel</button>
              <button
                className="pad-submit-primary"
                onClick={() => {
                  if (!company.trim() || !text.trim()) { setError('Please enter company name and ad text.'); return; }
                  setError('');
                  setStep('preview');
                }}
              >
                <Eye size={14} /> Preview
              </button>
            </div>
            {error && <p className="pad-submit-error"><AlertTriangle size={12} />{error}</p>}
          </div>
        )}
      </div>
    </div>
  );
}
