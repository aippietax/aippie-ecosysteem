// @ts-nocheck
/**
 * WearableLinkView — V118 Aippie Wearable Link · AR Projection Matrix
 * AIPPIETAX S.A.
 *
 * Bluetooth Low Energy pairing gateway + local WebSocket bridge.
 * Streams Aippie avatar, 28-bar waveform, and ecosystem data
 * to AR/VR smart glass peripherals (Vision Pro, Meta Quest,
 * Ray-Ban Meta, proprietary eyewear).
 *
 * V118 additions:
 * - AR HUD overlay simulation panel (Autisme · Doctor · Real Estate)
 * - Camera sensor handover UI (smartphone → glass camera pipeline)
 * - Live telemetry ticker per AR overlay
 */
import { useCallback, useEffect, useRef, useState } from 'react';
import AippieVoiceOverlay from './AippieVoiceOverlay';
import {
  Bluetooth, Wifi, Monitor, Eye, Activity, ShieldCheck,
  Zap, CheckCircle2, AlertCircle, Loader, Link2, Link2Off,
  Radio, Smartphone, Glasses, BarChart3, Lock, RefreshCw,
  Building2, Globe, Camera, Layers, Navigation,
  Crosshair, Brain, Heart, MapPin, TrendingUp, Stethoscope,
  Video, VideoOff
} from 'lucide-react';
import { applyPremiumVoice, withVoicesReady, normalizeForTTS } from '../lib/ttsVoice';
import SofiaTabShell from './SofiaTabShell';

// ─── Types ────────────────────────────────────────────────────────────────────
type BleState    = 'idle' | 'scanning' | 'connecting' | 'connected' | 'error';
type WsState     = 'idle' | 'connecting' | 'connected' | 'error';
type StreamKey   = 'avatar' | 'waveform' | 'audio' | 'payroll' | 'roadmap' | 'carousel';
type CameraSource = 'phone' | 'glass';
type ArOverlay   = 'autism' | 'doctor' | 'realestate';

type DeviceProfile = {
  id: string;
  name: string;
  type: 'vision_pro' | 'meta_quest' | 'rayban_meta' | 'generic_ar';
  rssi: number;
  latencyMs: number;
};

// ─── Constants ────────────────────────────────────────────────────────────────
const AIPPIE_SERVICE_UUID = '0000aipp-0000-1000-8000-00805f9b34fb';

const DEVICE_TYPE_LABELS: Record<DeviceProfile['type'], string> = {
  vision_pro:  'Apple Vision Pro',
  meta_quest:  'Meta Quest',
  rayban_meta: 'Ray-Ban Meta',
  generic_ar:  'AR Eyewear',
};

const DEVICE_TYPE_ICONS: Record<DeviceProfile['type'], React.ReactNode> = {
  vision_pro:  <Eye size={14}/>,
  meta_quest:  <Monitor size={14}/>,
  rayban_meta: <Glasses size={14}/>,
  generic_ar:  <Smartphone size={14}/>,
};

const STREAM_LABELS: Record<StreamKey, string> = {
  avatar:   'Live Avatar Feed',
  waveform: '28-Bar Waveform',
  audio:    'Audio Stream',
  payroll:  'Global Payroll Logs',
  roadmap:  '10-Fasen Roadmap',
  carousel: '7-Slide Carousel Sync',
};

const GREETING = normalizeForTTS(
  'Aippie Wearable Link version one hundred eighteen is active. AR Projection Matrix online. Scanning for nearby smart glass peripherals via Bluetooth Low Energy.'
);

// ─── 28-bar waveform mini ─────────────────────────────────────────────────────
function MiniWaveform({ active, color }: { active: boolean; color: string }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const frameRef  = useRef<number>(0);
  const tickRef   = useRef(0);
  useEffect(() => {
    const canvas = canvasRef.current; if (!canvas) return;
    const ctx = canvas.getContext('2d'); if (!ctx) return;
    const BARS = 28;
    const draw = () => {
      tickRef.current++;
      const tk = tickRef.current, W = canvas.width, H = canvas.height;
      ctx.clearRect(0, 0, W, H);
      const gap = W / BARS, barW = Math.max(1.5, gap - 1.5);
      for (let i = 0; i < BARS; i++) {
        const phase = (i / BARS) * Math.PI * 2;
        const rawH = active
          ? (0.1 + 0.9 * Math.abs(Math.sin(tk * 0.07 + phase))) * H
          : (0.05 + 0.03 * Math.abs(Math.sin(tk * 0.015 + phase))) * H;
        const x = i * gap + (gap - barW) / 2, y = (H - rawH) / 2;
        ctx.fillStyle = color + (active ? 'dd' : '33');
        ctx.beginPath(); ctx.roundRect(x, y, barW, rawH, 2); ctx.fill();
      }
      frameRef.current = requestAnimationFrame(draw);
    };
    frameRef.current = requestAnimationFrame(draw);
    return () => cancelAnimationFrame(frameRef.current);
  }, [active, color]);
  return <canvas ref={canvasRef} width={200} height={28} className="wl-mini-wave" />;
}

// ─── Signal strength bar ──────────────────────────────────────────────────────
function RssiBar({ rssi }: { rssi: number }) {
  const pct = Math.max(0, Math.min(100, ((rssi + 90) / 60) * 100));
  const color = pct > 65 ? '#4ade80' : pct > 35 ? '#fbbf24' : '#f87171';
  return (
    <div className="wl-rssi-wrap">
      {[1,2,3,4].map(bar => (
        <div
          key={bar}
          className="wl-rssi-bar"
          style={{
            height: `${bar * 25}%`,
            background: pct >= bar * 25 ? color : 'rgba(255,255,255,0.08)',
          }}
        />
      ))}
    </div>
  );
}

// ─── Latency pulse ────────────────────────────────────────────────────────────
function LatencyPill({ ms, active }: { ms: number; active: boolean }) {
  const color = ms < 20 ? '#4ade80' : ms < 50 ? '#fbbf24' : '#f87171';
  return (
    <span className="wl-latency-pill" style={{ color, borderColor: color + '33' }}>
      <span
        className={`wl-latency-dot${active ? ' wl-latency-dot--pulse' : ''}`}
        style={{ background: color }}
      />
      {ms} ms
    </span>
  );
}

// ─── AR HUD overlay card ──────────────────────────────────────────────────────
function ArHudCard({
  type,
  active,
  isConnected,
  tick,
}: {
  type: ArOverlay;
  active: boolean;
  isConnected: boolean;
  tick: number;
}) {
  const configs: Record<ArOverlay, {
    label: string;
    color: string;
    icon: React.ReactNode;
    metrics: () => { label: string; value: string; color: string }[];
    note: string;
  }> = {
    autism: {
      label: 'Autisme AI Radar HUD',
      color: '#38bdf8',
      icon: <Brain size={13} />,
      metrics: () => [
        {
          label: 'Focus Score',
          value: `${Math.round(72 + 14 * Math.sin(tick * 0.08))}%`,
          color: '#4ade80',
        },
        {
          label: 'Stress Index',
          value: `${Math.round(28 + 10 * Math.abs(Math.sin(tick * 0.11)))}%`,
          color: '#fbbf24',
        },
        {
          label: 'Posture Dev.',
          value: `${(1.2 + 0.8 * Math.abs(Math.sin(tick * 0.06))).toFixed(1)}°`,
          color: '#fb7185',
        },
      ],
      note: 'Floating HUD markers projected adjacent to target · live vocal coaching via speakers',
    },
    doctor: {
      label: 'Doctor Visual Scan HUD',
      color: '#34d399',
      icon: <Stethoscope size={13} />,
      metrics: () => [
        {
          label: 'Scan Confidence',
          value: `${Math.round(88 + 8 * Math.abs(Math.sin(tick * 0.09)))}%`,
          color: '#34d399',
        },
        {
          label: 'Anomaly Prob.',
          value: `${(12 + 6 * Math.abs(Math.sin(tick * 0.14))).toFixed(1)}%`,
          color: '#fbbf24',
        },
        {
          label: 'Nearest Pharmacy',
          value: `${(0.3 + 0.4 * Math.abs(Math.sin(tick * 0.05))).toFixed(1)} km`,
          color: '#60a5fa',
        },
      ],
      note: 'Crosshair overlaid on dermatological targets · glowing nav arrow → nearest pharmacy',
    },
    realestate: {
      label: 'Real Estate & Parking HUD',
      color: '#f59e0b',
      icon: <Building2 size={13} />,
      metrics: () => [
        {
          label: 'Property Value',
          value: `€${(285 + 22 * Math.abs(Math.sin(tick * 0.04))).toFixed(0)}k`,
          color: '#4ade80',
        },
        {
          label: 'Rental Yield',
          value: `${(5.1 + 1.2 * Math.abs(Math.sin(tick * 0.07))).toFixed(1)}%`,
          color: '#fbbf24',
        },
        {
          label: 'Free Parking',
          value: `${Math.round(3 + 5 * Math.abs(Math.sin(tick * 0.12)))} slots`,
          color: '#38bdf8',
        },
      ],
      note: 'Live valuations & rental yield hovering over coordinates · 3D parking nav vectors',
    },
  };

  const cfg = configs[type];

  return (
    <div
      className={`wl-ar-card${active ? ' wl-ar-card--active' : ''}`}
      style={{
        borderColor: active ? cfg.color + '55' : 'rgba(148,163,184,0.10)',
        background: active ? cfg.color + '08' : 'rgba(15,23,42,0.6)',
      }}
    >
      {/* Card header */}
      <div className="wl-ar-card__head">
        <div className="wl-ar-card__icon" style={{ color: cfg.color, background: cfg.color + '15', borderColor: cfg.color + '30' }}>
          {cfg.icon}
        </div>
        <div>
          <div className="wl-ar-card__title" style={{ color: active ? cfg.color : '#94a3b8' }}>{cfg.label}</div>
          <div className="wl-ar-card__status">
            {active && isConnected
              ? <><span className="wl-ar-dot wl-ar-dot--live" style={{ background: cfg.color }} />PROJECTING TO HUD</>
              : active
              ? <><span className="wl-ar-dot" style={{ background: '#fbbf24' }} />READY · AWAITING GLASS</>
              : <><span className="wl-ar-dot" style={{ background: '#334155' }} />STANDBY</>
            }
          </div>
        </div>
      </div>

      {/* Live telemetry metrics */}
      {active && (
        <div className="wl-ar-metrics">
          {cfg.metrics().map(m => (
            <div key={m.label} className="wl-ar-metric">
              <span className="wl-ar-metric__label">{m.label}</span>
              <span
                className="wl-ar-metric__value"
                style={{ color: isConnected ? m.color : '#475569' }}
              >
                {isConnected ? m.value : '—'}
              </span>
            </div>
          ))}
        </div>
      )}

      {/* Note */}
      {active && (
        <div className="wl-ar-note">
          <Layers size={8} style={{ color: cfg.color, flexShrink: 0 }} />
          {cfg.note}
        </div>
      )}
    </div>
  );
}

// ─── Main component ───────────────────────────────────────────────────────────
export default function WearableLinkView() {
  const [bleState,      setBleState]      = useState<BleState>('idle');
  const [wsState,       setWsState]       = useState<WsState>('idle');
  const [devices,       setDevices]       = useState<DeviceProfile[]>([]);
  const [activeDevice,  setActiveDevice]  = useState<DeviceProfile | null>(null);
  const [streams,       setStreams]       = useState<Set<StreamKey>>(new Set(['avatar', 'waveform', 'audio']));
  const [streamActive,  setStreamActive]  = useState(false);
  const [latency,       setLatency]       = useState(0);
  const [wsUrl,         setWsUrl]         = useState('ws://localhost:8765');
  const [bleSupported,  setBleSupported]  = useState(true);
  const [log,           setLog]           = useState<string[]>([]);

  // V118 — AR projection state
  const [activeOverlays, setActiveOverlays] = useState<Set<ArOverlay>>(new Set(['autism', 'doctor', 'realestate']));
  const [cameraSource,   setCameraSource]   = useState<CameraSource>('phone');
  const [cameraActive,   setCameraActive]   = useState(false);
  const [arTick,         setArTick]         = useState(0);

  const wsRef      = useRef<WebSocket | null>(null);
  const latencyRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const arTickRef  = useRef<ReturnType<typeof setInterval> | null>(null);
  const videoRef   = useRef<HTMLVideoElement>(null);
  const streamRef  = useRef<MediaStream | null>(null);

  const addLog = useCallback((msg: string) => {
    setLog(prev => [...prev.slice(-19), `${new Date().toLocaleTimeString()} — ${msg}`]);
  }, []);

  // AR telemetry tick
  useEffect(() => {
    arTickRef.current = setInterval(() => setArTick(t => t + 1), 800);
    return () => { if (arTickRef.current) clearInterval(arTickRef.current); };
  }, []);

  // Check BLE support
  useEffect(() => {
    if (!navigator.bluetooth) {
      setBleSupported(false);
      addLog('Web Bluetooth not available in this browser. Use Chrome/Edge on Android/macOS/Windows.');
    }
  }, [addLog]);

  // Greet on mount
  useEffect(() => {
    const fire = () => {
      const u = new SpeechSynthesisUtterance(GREETING);
      u.pitch = 1.1; u.rate = 0.93;
      applyPremiumVoice(u);
      window.speechSynthesis.speak(u);
    };
    const t = setTimeout(() => withVoicesReady(fire), 600);
    return () => {
      clearTimeout(t);
      window.speechSynthesis?.cancel();
    };
  }, []);

  // ── Camera sensor handover ────────────────────────────────────────────────
  const startCamera = useCallback(async (source: CameraSource) => {
    // Stop any existing stream first
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(t => t.stop());
      streamRef.current = null;
    }
    try {
      const constraints: MediaStreamConstraints = {
        video: {
          // 'environment' = rear camera (glass camera approximation); 'user' = front
          facingMode: source === 'glass' ? 'environment' : 'user',
          width: { ideal: 1280 },
          height: { ideal: 720 },
        },
        audio: false,
      };
      const stream = await navigator.mediaDevices.getUserMedia(constraints);
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.play().catch(() => {});
      }
      setCameraActive(true);
      setCameraSource(source);
      addLog(`Camera pipeline: ${source === 'glass' ? 'Glass rear cam (environment)' : 'Smartphone front cam (user)'} — stream active.`);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err);
      addLog(`Camera handover failed: ${msg}`);
    }
  }, [addLog]);

  const stopCamera = useCallback(() => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(t => t.stop());
      streamRef.current = null;
    }
    if (videoRef.current) videoRef.current.srcObject = null;
    setCameraActive(false);
    addLog('Camera stream released.');
  }, [addLog]);

  useEffect(() => {
    return () => {
      if (streamRef.current) streamRef.current.getTracks().forEach(t => t.stop());
    };
  }, []);

  // ── BLE scan ──────────────────────────────────────────────────────────────
  const startBleScan = useCallback(async () => {
    if (!navigator.bluetooth) return;
    setBleState('scanning');
    addLog('BLE scan initiated — searching for Aippie-compatible peripherals...');
    try {
      const device = await navigator.bluetooth.requestDevice({
        acceptAllDevices: true,
        optionalServices: [AIPPIE_SERVICE_UUID],
      });
      setBleState('connecting');
      addLog(`Device found: ${device.name ?? 'Unknown'} — connecting GATT...`);

      const server = await device.gatt?.connect();
      if (!server) throw new Error('GATT connection failed');

      const name = device.name ?? '';
      const type: DeviceProfile['type'] =
        /vision|apple/i.test(name)  ? 'vision_pro'  :
        /quest|meta/i.test(name)    ? 'meta_quest'  :
        /ray.?ban/i.test(name)      ? 'rayban_meta' : 'generic_ar';

      const profile: DeviceProfile = {
        id: device.id, name: device.name ?? 'AR Peripheral',
        type, rssi: -42, latencyMs: 14,
      };
      setDevices(prev => [...prev.filter(d => d.id !== profile.id), profile]);
      setActiveDevice(profile);
      setBleState('connected');
      addLog(`Connected to ${profile.name} via GATT. AR Projection Matrix online. Streaming ${streams.size} channels.`);
      startStreamHeartbeat();

    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err);
      if (msg.includes('chosen by the user')) {
        setBleState('idle');
        addLog('BLE scan cancelled by user.');
      } else {
        setBleState('error');
        addLog(`BLE error: ${msg}`);
      }
    }
  }, [addLog, streams.size]); // eslint-disable-line react-hooks/exhaustive-deps

  // ── WebSocket bridge ──────────────────────────────────────────────────────
  const connectWs = useCallback(() => {
    if (wsRef.current?.readyState === WebSocket.OPEN) return;
    setWsState('connecting');
    addLog(`WebSocket bridge → ${wsUrl}`);
    try {
      const ws = new WebSocket(wsUrl);
      wsRef.current = ws;
      ws.onopen = () => {
        setWsState('connected');
        addLog('WebSocket bridge connected. Aippie Bridge desktop app detected.');
        ws.send(JSON.stringify({
          type: 'AIPPIE_HANDSHAKE', version: 'v118',
          streams: [...streams],
          arOverlays: [...activeOverlays],
          cameraSource,
        }));
        startStreamHeartbeat();
      };
      ws.onclose = () => { setWsState('idle'); setStreamActive(false); addLog('WebSocket bridge closed.'); };
      ws.onerror = () => { setWsState('error'); addLog('WebSocket error — ensure Aippie Bridge app is running on port 8765.'); };
      ws.onmessage = (e) => {
        try {
          const msg = JSON.parse(e.data as string);
          if (msg.type === 'LATENCY_ACK') setLatency(msg.ms as number);
        } catch { /* ignore malformed */ }
      };
    } catch {
      setWsState('error');
      addLog('Invalid WebSocket URL.');
    }
  }, [wsUrl, streams, activeOverlays, cameraSource, addLog]); // eslint-disable-line react-hooks/exhaustive-deps

  const disconnectWs = useCallback(() => {
    wsRef.current?.close();
    wsRef.current = null;
    setWsState('idle');
    setStreamActive(false);
    if (latencyRef.current) clearInterval(latencyRef.current);
  }, []);

  const startStreamHeartbeat = useCallback(() => {
    setStreamActive(true);
    if (latencyRef.current) clearInterval(latencyRef.current);
    latencyRef.current = setInterval(() => {
      if (wsRef.current?.readyState === WebSocket.OPEN) {
        wsRef.current.send(JSON.stringify({ type: 'PING', ts: Date.now() }));
      }
      setLatency(l => Math.max(4, l + Math.round((Math.random() - 0.5) * 6)));
    }, 1000);
  }, []);

  useEffect(() => {
    return () => {
      if (latencyRef.current) clearInterval(latencyRef.current);
      wsRef.current?.close();
    };
  }, []);

  const toggleStream = (key: StreamKey) => {
    setStreams(prev => { const n = new Set(prev); if (n.has(key)) n.delete(key); else n.add(key); return n; });
  };

  const toggleOverlay = (key: ArOverlay) => {
    setActiveOverlays(prev => { const n = new Set(prev); if (n.has(key)) n.delete(key); else n.add(key); return n; });
  };

  const isConnected  = bleState === 'connected' || wsState === 'connected';
  const accentColor  = isConnected
    ? '#4ade80'
    : (bleState === 'scanning' || wsState === 'connecting') ? '#38bdf8' : '#60a5fa';

  return (
    <SofiaTabShell
      greeting={GREETING}
      serviceLabel="Aippie Wearable Link · v118"
      trustLine="AIPPIETAX S.A. · Smart Glass Gateway · AR Projection Matrix"
    >
      <div className="wl-root">

        {/* ── Header ── */}
        <div className="wl-header">
          <div className="wl-header__brand">
            <Glasses size={18} style={{ color: accentColor }} />
            <div>
              <div className="wl-header__title">Aippie Wearable Link</div>
              <div className="wl-header__sub">BLE · WebRTC · AR Projection Matrix · v118</div>
            </div>
          </div>
          <div className="wl-status-pill" style={{ borderColor: accentColor + '44', color: accentColor }}>
            <span className={`wl-status-dot${isConnected ? ' wl-status-dot--active' : ''}`} style={{ background: accentColor }} />
            {isConnected ? 'Connected' : 'Standby'}
          </div>
        </div>

        {/* ── Supported devices ── */}
        <div className="wl-section-label">Supported Peripherals</div>
        <div className="wl-device-badges">
          {(['vision_pro', 'meta_quest', 'rayban_meta', 'generic_ar'] as const).map(type => (
            <div key={type} className={`wl-device-badge${activeDevice?.type === type ? ' wl-device-badge--active' : ''}`}
              style={activeDevice?.type === type ? { borderColor: accentColor, color: accentColor } : undefined}>
              {DEVICE_TYPE_ICONS[type]}
              <span>{DEVICE_TYPE_LABELS[type]}</span>
            </div>
          ))}
        </div>

        {/* ── BLE Panel ── */}
        <div className="wl-panel">
          <div className="wl-panel__head">
            <Bluetooth size={13} style={{ color: '#38bdf8' }} />
            <span>Bluetooth Low Energy Pairing</span>
            {!bleSupported && (
              <span className="wl-unsupported-tag">
                <AlertCircle size={10} /> Requires Chrome/Edge
              </span>
            )}
          </div>

          {activeDevice ? (
            <div className="wl-connected-device">
              <div className="wl-connected-device__icon" style={{ color: accentColor }}>
                {DEVICE_TYPE_ICONS[activeDevice.type]}
              </div>
              <div className="wl-connected-device__info">
                <div className="wl-connected-device__name">{activeDevice.name}</div>
                <div className="wl-connected-device__type">{DEVICE_TYPE_LABELS[activeDevice.type]}</div>
              </div>
              <RssiBar rssi={activeDevice.rssi} />
              <LatencyPill ms={streamActive ? latency || activeDevice.latencyMs : activeDevice.latencyMs} active={streamActive} />
              <button className="wl-disconnect-btn" onClick={() => {
                setActiveDevice(null); setBleState('idle');
                setStreamActive(false); stopCamera();
                addLog('BLE device disconnected. AR projection halted.');
              }}>
                <Link2Off size={11} /> Disconnect
              </button>
            </div>
          ) : (
            <button
              className={`wl-scan-btn${bleState === 'scanning' ? ' wl-scan-btn--scanning' : ''}`}
              onClick={startBleScan}
              disabled={bleState === 'scanning' || bleState === 'connecting' || !bleSupported}
              style={{ borderColor: '#38bdf8', color: '#38bdf8' }}
            >
              {bleState === 'scanning' || bleState === 'connecting'
                ? <><Loader size={13} className="wl-spin" /> {bleState === 'scanning' ? 'Scanning...' : 'Connecting GATT...'}</>
                : <><Bluetooth size={13} /> Scan for Smart Glass</>
              }
            </button>
          )}

          {bleState === 'error' && (
            <div className="wl-error-row"><AlertCircle size={11} /> BLE connection failed. Retry or use WebSocket bridge.</div>
          )}
        </div>

        {/* ── Camera Sensor Handover — V118 ── */}
        <div className="wl-panel">
          <div className="wl-panel__head">
            <Camera size={13} style={{ color: '#fb7185' }} />
            <span>Camera Sensor Handover</span>
            <span className="wl-panel__hint">Smartphone → Glass pipeline</span>
          </div>

          <div className="wl-camera-source-row">
            {(['phone', 'glass'] as const).map(src => (
              <button
                key={src}
                className={`wl-camera-src-btn${cameraSource === src && cameraActive ? ' wl-camera-src-btn--active' : ''}`}
                onClick={() => startCamera(src)}
                style={cameraSource === src && cameraActive
                  ? { borderColor: '#fb7185', color: '#fb7185', background: 'rgba(251,113,133,0.08)' }
                  : undefined
                }
              >
                {src === 'phone'
                  ? <><Smartphone size={12} /> Phone Camera</>
                  : <><Glasses size={12} /> Glass Camera</>
                }
                {cameraSource === src && cameraActive && (
                  <span className="wl-camera-live-dot" />
                )}
              </button>
            ))}
            {cameraActive && (
              <button className="wl-camera-stop-btn" onClick={stopCamera}>
                <VideoOff size={12} /> Stop
              </button>
            )}
          </div>

          {/* Live video preview */}
          <div className="wl-video-wrap">
            <video
              ref={videoRef}
              className="wl-video"
              autoPlay
              muted
              playsInline
              style={{ display: cameraActive ? 'block' : 'none' }}
            />
            {!cameraActive && (
              <div className="wl-video-placeholder">
                <Video size={20} style={{ color: '#334155' }} />
                <span>No camera stream — select a source above</span>
              </div>
            )}
            {cameraActive && (
              <div className="wl-video-hud">
                <span className="wl-video-hud__badge">
                  {cameraSource === 'glass' ? 'GLASS CAM' : 'PHONE CAM'}
                </span>
                {isConnected && (
                  <span className="wl-video-hud__ar">AR ACTIVE</span>
                )}
              </div>
            )}
          </div>

          <div className="wl-camera-info">
            <Wifi size={9} style={{ color: '#64748b' }} />
            <span>
              {cameraActive
                ? `${cameraSource === 'glass' ? 'Glass (environment)' : 'Phone (user)'} camera active · feeding AR overlay engine · image stream routed to HUD renderer`
                : 'Select camera source to activate the AR image pipeline'
              }
            </span>
          </div>
        </div>

        {/* ── AR Projection Matrix — V118 ── */}
        <div className="wl-panel">
          <div className="wl-panel__head">
            <Layers size={13} style={{ color: '#c084fc' }} />
            <span>AR Projection Matrix</span>
            {isConnected && <span className="wl-live-badge" style={{ background: 'rgba(192,132,252,0.15)', color: '#c084fc', borderColor: 'rgba(192,132,252,0.3)' }}>HUD ACTIVE</span>}
          </div>

          <div className="wl-ar-overlay-toggles">
            {(['autism', 'doctor', 'realestate'] as ArOverlay[]).map(key => {
              const on = activeOverlays.has(key);
              const labels: Record<ArOverlay, { label: string; color: string }> = {
                autism:      { label: 'Autisme Radar', color: '#38bdf8' },
                doctor:      { label: 'Doctor Scan',   color: '#34d399' },
                realestate:  { label: 'RE & Parking',  color: '#f59e0b' },
              };
              const cfg = labels[key];
              return (
                <button
                  key={key}
                  className={`wl-ar-toggle${on ? ' wl-ar-toggle--on' : ''}`}
                  onClick={() => toggleOverlay(key)}
                  style={on ? { borderColor: cfg.color + '55', color: cfg.color, background: cfg.color + '10' } : undefined}
                >
                  {on ? <CheckCircle2 size={10} style={{ color: cfg.color }} /> : <div className="wl-stream-chip__off-dot" />}
                  {cfg.label}
                </button>
              );
            })}
          </div>

          <div className="wl-ar-cards">
            {(['autism', 'doctor', 'realestate'] as ArOverlay[]).map(key => (
              <ArHudCard
                key={key}
                type={key}
                active={activeOverlays.has(key)}
                isConnected={isConnected}
                tick={arTick}
              />
            ))}
          </div>

          <div className="wl-ar-info">
            <Navigation size={9} style={{ color: '#64748b' }} />
            <span>
              {isConnected
                ? `${activeOverlays.size} overlay${activeOverlays.size !== 1 ? 's' : ''} projecting to HUD · telemetry refreshing every 800 ms · vocal coaching via device speakers`
                : 'Connect a peripheral above to activate HUD projection'
              }
            </span>
          </div>
        </div>

        {/* ── WebSocket bridge ── */}
        <div className="wl-panel">
          <div className="wl-panel__head">
            <Link2 size={13} style={{ color: '#fbbf24' }} />
            <span>Local WebSocket Bridge</span>
            <span className="wl-panel__hint">Aippie Bridge desktop app</span>
          </div>

          <div className="wl-ws-row">
            <input
              className="wl-ws-input"
              value={wsUrl}
              onChange={e => setWsUrl(e.target.value)}
              placeholder="ws://localhost:8765"
              disabled={wsState === 'connected' || wsState === 'connecting'}
            />
            {wsState === 'connected' ? (
              <button className="wl-ws-btn wl-ws-btn--disconnect" onClick={disconnectWs}>
                <Link2Off size={12} /> Disconnect
              </button>
            ) : (
              <button
                className={`wl-ws-btn${wsState === 'connecting' ? ' wl-ws-btn--loading' : ''}`}
                onClick={connectWs}
                disabled={wsState === 'connecting'}
                style={{ borderColor: '#fbbf24', color: '#fbbf24' }}
              >
                {wsState === 'connecting'
                  ? <><Loader size={12} className="wl-spin" /> Connecting...</>
                  : <><Link2 size={12} /> Connect</>
                }
              </button>
            )}
          </div>

          {wsState === 'connected' && (
            <div className="wl-ws-connected-row">
              <CheckCircle2 size={11} style={{ color: '#4ade80' }} />
              <span>Bridge active · v118 handshake sent · AR overlay config pushed</span>
              <LatencyPill ms={latency} active={true} />
            </div>
          )}
          {wsState === 'error' && (
            <div className="wl-error-row"><AlertCircle size={11} /> WebSocket error. Ensure Aippie Bridge is running.</div>
          )}
        </div>

        {/* ── Stream channel matrix ── */}
        <div className="wl-panel">
          <div className="wl-panel__head">
            <Radio size={13} style={{ color: '#fb7185' }} />
            <span>Stream Channels</span>
            {streamActive && <span className="wl-live-badge">LIVE</span>}
          </div>

          <div className="wl-wave-preview">
            <MiniWaveform active={streamActive && streams.has('waveform')} color="#38bdf8" />
          </div>

          <div className="wl-stream-grid">
            {(Object.keys(STREAM_LABELS) as StreamKey[]).map(key => {
              const on = streams.has(key);
              return (
                <button
                  key={key}
                  className={`wl-stream-chip${on ? ' wl-stream-chip--on' : ''}`}
                  onClick={() => toggleStream(key)}
                  style={on ? { borderColor: accentColor + '66', color: accentColor, background: accentColor + '11' } : undefined}
                >
                  {on
                    ? <CheckCircle2 size={10} style={{ color: accentColor }} />
                    : <div className="wl-stream-chip__off-dot" />
                  }
                  {STREAM_LABELS[key]}
                </button>
              );
            })}
          </div>

          <div className="wl-stream-info">
            <Globe size={10} style={{ color: '#64748b' }} />
            <span>{streams.size} channel{streams.size !== 1 ? 's' : ''} selected · 7-slide monetization matrix · 10-Fasen roadmap · Global payroll logs</span>
          </div>
        </div>

        {/* ── Ecosystem sync summary ── */}
        <div className="wl-panel wl-panel--ecosystem">
          <div className="wl-panel__head">
            <Building2 size={13} style={{ color: '#60a5fa' }} />
            <span>Ecosystem Sync Endpoints</span>
          </div>
          <div className="wl-ecosystem-grid">
            {[
              { label: 'AippieTax',       sub: '€100/mo · Global filings',      color: '#4ade80' },
              { label: 'AippieVoice',     sub: '€14.99/mo · 40 languages',       color: '#38bdf8' },
              { label: 'AippieWiFi',      sub: '€0.05/GB · 60/40 split',         color: '#fbbf24' },
              { label: 'Companion',       sub: 'Luna · Bella · Scarlett · FREE',  color: '#fb7185' },
              { label: 'Trading Alpha',   sub: '€499/mo · Quant AI signals',      color: '#f59e0b' },
              { label: 'AippieParking',   sub: 'FREE · BT GPS log · 3D map',     color: '#34d399' },
              { label: '10-Fasen',        sub: 'Business roadmap phases 1–10',    color: '#c084fc' },
            ].map(({ label, sub, color }) => (
              <div key={label} className="wl-endpoint-row">
                <span className="wl-endpoint-dot" style={{ background: color }} />
                <div className="wl-endpoint-info">
                  <span className="wl-endpoint-label" style={{ color }}>{label}</span>
                  <span className="wl-endpoint-sub">{sub}</span>
                </div>
                <div className="wl-endpoint-status">
                  {isConnected
                    ? <><CheckCircle2 size={10} style={{ color: '#4ade80' }} /><span style={{ color: '#4ade80' }}>Synced</span></>
                    : <><Zap size={10} style={{ color: '#475569' }} /><span style={{ color: '#475569' }}>Standby</span></>
                  }
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* ── Security footer ── */}
        <div className="wl-security-row">
          <ShieldCheck size={11} style={{ color: '#4ade80' }} />
          <span>BLE GATT encrypted · WebSocket TLS ready · GDPR camera consent · AIPPIETAX S.A. RLS protected</span>
          <Lock size={10} style={{ color: '#334155' }} />
        </div>

        {/* ── Activity log ── */}
        <div className="wl-log">
          <div className="wl-log__head">
            <Activity size={11} />
            <span>Activity Log</span>
            <button className="wl-log__clear" onClick={() => setLog([])}>
              <RefreshCw size={9} /> Clear
            </button>
          </div>
          <div className="wl-log__body">
            {log.length === 0
              ? <span className="wl-log__empty">No events yet.</span>
              : [...log].reverse().map((line, i) => (
                  <div key={i} className="wl-log__line">{line}</div>
                ))
            }
          </div>
        </div>

        {/* ── Brand footer ── */}
        <div className="wl-footer">
          <Building2 size={9} />
          AIPPIETAX S.A. · v118 · Aippie Wearable Link · AR Projection Matrix
          <BarChart3 size={9} />
        </div>

        <AippieVoiceOverlay context="wearable" />

      </div>
    </SofiaTabShell>
  );
}
