import { useEffect, useMemo, useState } from 'react';
import { TrendingUp, Clock, Calendar, Euro } from 'lucide-react';
import { supabase, RATE_PER_MINUTE, currentMonthStart } from '../lib/supabase';
import type { User } from '@supabase/supabase-js';

type Props = {
  user: User;
  isCallActive: boolean;
  callSeconds: number;
};

function fmt(n: number, decimals = 2) {
  return n.toFixed(decimals);
}

export default function EarningsDashboard({ user, isCallActive, callSeconds }: Props) {
  const [monthMinutes, setMonthMinutes]     = useState(0);
  const [historicEarned, setHistoricEarned] = useState(0);
  const [loading, setLoading]               = useState(true);

  const liveMinutes = callSeconds / 60;
  const liveEarned  = liveMinutes * RATE_PER_MINUTE;

  const totalMinutes = monthMinutes + (isCallActive ? liveMinutes : 0);
  const totalEarned  = historicEarned + (isCallActive ? liveEarned : 0);

  const monthLabel  = useMemo(() => new Date().toLocaleString('en-GB', { month: 'long', year: 'numeric' }), []);
  const payoutDate  = useMemo(() => {
    const now = new Date();
    return new Date(now.getFullYear(), now.getMonth() + 1, 1)
      .toLocaleDateString('en-GB', { day: 'numeric', month: 'long', year: 'numeric' });
  }, []);

  useEffect(() => {
    supabase
      .from('call_minutes')
      .select('minutes, earned')
      .eq('translator_user_id', user.id)
      .gte('month_start', currentMonthStart())
      .then(({ data }) => {
        if (data) {
          setMonthMinutes(data.reduce((s, r) => s + Number(r.minutes), 0));
          setHistoricEarned(data.reduce((s, r) => s + Number(r.earned), 0));
        }
        setLoading(false);
      });
  }, [user.id]);

  return (
    <div className="earnings-dashboard">
      <div className="earnings-dashboard__header">
        <TrendingUp size={14} className="earnings-dashboard__header-icon" />
        <span>Earnings — {monthLabel}</span>
      </div>

      <div className="earnings-dashboard__grid">
        <div className="earnings-card">
          <div className="earnings-card__icon-wrap earnings-card__icon-wrap--blue">
            <Clock size={14} />
          </div>
          <div className="earnings-card__body">
            <span className="earnings-card__label">Minutes Spoken</span>
            <span className={`earnings-card__value${isCallActive ? ' earnings-card__value--live' : ''}`}>
              {loading ? '—' : fmt(totalMinutes, 1)}
              {isCallActive && <span className="earnings-card__live-dot" />}
            </span>
          </div>
        </div>

        <div className="earnings-card earnings-card--highlight">
          <div className="earnings-card__icon-wrap earnings-card__icon-wrap--green">
            <Euro size={14} />
          </div>
          <div className="earnings-card__body">
            <span className="earnings-card__label">Earned This Month</span>
            <span className={`earnings-card__value${isCallActive ? ' earnings-card__value--live' : ''}`}>
              €{loading ? '—' : fmt(totalEarned)}
              {isCallActive && <span className="earnings-card__live-dot" />}
            </span>
          </div>
        </div>

        <div className="earnings-card">
          <div className="earnings-card__icon-wrap earnings-card__icon-wrap--amber">
            <TrendingUp size={14} />
          </div>
          <div className="earnings-card__body">
            <span className="earnings-card__label">Rate</span>
            <span className="earnings-card__value">€{fmt(RATE_PER_MINUTE)} / min</span>
          </div>
        </div>

        <div className="earnings-card">
          <div className="earnings-card__icon-wrap earnings-card__icon-wrap--teal">
            <Calendar size={14} />
          </div>
          <div className="earnings-card__body">
            <span className="earnings-card__label">Next Payout</span>
            <span className="earnings-card__value earnings-card__value--sm">{payoutDate}</span>
          </div>
        </div>
      </div>

      {isCallActive && (
        <div className="earnings-live-bar">
          <span className="earnings-live-bar__dot" />
          Live: +€{fmt(liveEarned)} (+{fmt(liveMinutes, 2)} min this call)
        </div>
      )}
    </div>
  );
}
