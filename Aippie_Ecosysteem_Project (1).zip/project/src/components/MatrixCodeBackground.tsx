import { useEffect, useRef } from 'react';

const CODE_STRINGS = [
  'CIPHER.AES_256_GCM;',
  'ECDH.P256.handshake();',
  'TLS_1.3.established;',
  'SELECT * FROM logs;',
  'WHERE risk > 0.9;',
  'jwt.sign({id,exp});',
  'bcrypt.hash(pw, 12);',
  'monitor.start(5000);',
  'auth.mfa.verify();',
  'token.refresh(3600);',
  '// uptime: 99.98%',
  '// threats blocked: 0',
  'vault.seal(keyPair);',
  'session.encrypt();',
  'rsa.sign(payload);',
  'hmac.verify(sig);',
  '2kp.prove(secret);',
  'p2p.handshake();',
  'block.finalize();',
  'function decrypt(k) {',
  '  const h = SHA256(k);',
  '  return AES.init(h);',
  '}',
  'class AippieShield {',
  '  async scan() {',
  '    if (threat > 0.85) {',
  '      this.block();',
  '    }',
  '  }',
  '}',
];

const NEON_COLORS = [
  '#FF3B30', // Security Red
  '#FF9500', // Cashflow Orange
  '#007AFF', // Bank Blue
  '#AF52DE', // Account Purple
  '#34C759', // Yield Green
];

interface CodeColumn {
  x: number;
  y: number;
  speed: number;
  text: string;
  color: string;
  opacity: number;
}

const hexToRgb = (hex: string): string => {
  const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
  return result
    ? `${parseInt(result[1], 16)}, ${parseInt(result[2], 16)}, ${parseInt(result[3], 16)}`
    : '0, 0, 0';
};

export default function MatrixCodeBackground() {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;
    let columns: CodeColumn[] = [];

    const initializeColumns = () => {
      const columnWidth = 40;
      const totalColumns = Math.floor(canvas.width / columnWidth);
      columns = [];
      for (let i = 0; i < totalColumns; i++) {
        columns.push({
          x: i * columnWidth,
          y: canvas.height + Math.random() * canvas.height,
          speed: -(Math.random() * (1.8 - 0.6) + 0.6),
          text: CODE_STRINGS[Math.floor(Math.random() * CODE_STRINGS.length)],
          color: NEON_COLORS[Math.floor(Math.random() * NEON_COLORS.length)],
          opacity: Math.random() * (0.35 - 0.15) + 0.15,
        });
      }
    };

    const resizeCanvas = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
      initializeColumns();
    };

    const render = () => {
      ctx.fillStyle = '#020617';
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      ctx.font = '600 13px monospace';

      for (const col of columns) {
        ctx.fillStyle = `rgba(${hexToRgb(col.color)}, ${col.opacity})`;
        ctx.fillText(col.text, col.x, col.y);
        col.y += col.speed;
        if (col.y < -50) {
          col.y = canvas.height + Math.random() * 150;
          col.text = CODE_STRINGS[Math.floor(Math.random() * CODE_STRINGS.length)];
          col.color = NEON_COLORS[Math.floor(Math.random() * NEON_COLORS.length)];
          col.opacity = Math.random() * (0.35 - 0.15) + 0.15;
          col.speed = -(Math.random() * (1.8 - 0.6) + 0.6);
        }
      }

      animationFrameId = requestAnimationFrame(render);
    };

    window.addEventListener('resize', resizeCanvas);
    resizeCanvas();
    render();

    return () => {
      window.removeEventListener('resize', resizeCanvas);
      cancelAnimationFrame(animationFrameId);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      aria-hidden="true"
      style={{
        position: 'fixed',
        inset: 0,
        zIndex: 0,
        pointerEvents: 'none',
        display: 'block',
      }}
    />
  );
}
