import { useEffect, useRef, useState } from 'react';
import { Mic, MicOff, ShieldCheck, Wifi, Volume2, PhoneOff } from 'lucide-react';
import type { User } from '@supabase/supabase-js';
import { supabase, type Subscription } from '../lib/supabase';
import PropertyGrid, { type Property } from './PropertyGrid';

type Props = { user: User | null; subscription: Subscription | null };

// Aippie's conversation state machine:
//   idle        → waiting for user input
//   connecting  → premium path: flashing "Connecting to Aippie AI Core…"
//   connected   → live session active (green pulsing, wave grid, live timer)
//   listening   → user is holding mic (wave animation)
//   responding  → Aippie is generating a reply
type AippieState = 'idle' | 'connecting' | 'connected' | 'listening' | 'responding';

// Integration stub: replace with live WebRTC session URL from streaming provider
const AIPPIE_STREAM_URL: string | null = null;

// Aippie's entry greeting for the Assistant tab
const ASSISTANT_GREETING = "Hello! I am your personal concierge assistant for everything in Spain. Ask me anything you need.";

const AIPPIE_REPLIES = [
  "Hola! Soy Aippie, tu asistente personal de AIPPIETAX S.A. ¿En qué puedo ayudarte hoy?",
  "Hello! I'm here to assist you with anything you need on the Costa del Sol.",
  "Claro, puedo ayudarte con eso. Dame un momento para preparar la información.",
  "Of course. Let me look that up for you right away.",
  "Buenas tardes. El servicio de AippieVoice tiene intérpretes disponibles en este momento.",
  "Understood. I'll arrange that for you immediately.",
  "Perfecto. ¿Hay algo más que necesites?",
];

const PROPERTY_KEYWORDS = [
  'property', 'villa', 'apartment', 'penthouse', 'house', 'finca', 'townhouse',
  'real estate', 'buy', 'purchase', 'find', 'looking for', 'marbella', 'mijas',
  'fuengirola', 'costa del sol', 'inmueble', 'casa', 'piso', 'chalet', 'buscar',
];

const LOCATION_MAP: Record<string, string> = {
  marbella: 'Marbella', mijas: 'Mijas', fuengirola: 'Fuengirola',
};

const TYPE_MAP: Record<string, string> = {
  villa: 'villa', apartment: 'apartment', piso: 'apartment',
  penthouse: 'penthouse', ático: 'penthouse', atico: 'penthouse',
  townhouse: 'townhouse', finca: 'finca',
};

const DEMO_QUERIES = [
  'Find me a villa in Mijas under €500k',
  'Show apartments in Marbella',
  'I want a penthouse in Fuengirola',
  'Find a villa in Marbella',
  'Any fincas available?',
];

function looksLikePropertyQuery(text: string) {
  const lower = text.toLowerCase();
  return PROPERTY_KEYWORDS.some(k => lower.includes(k));
}

function extractFilters(text: string) {
  const lower = text.toLowerCase();
  const location = Object.keys(LOCATION_MAP).find(k => lower.includes(k));
  const type     = Object.keys(TYPE_MAP).find(k => lower.includes(k));
  const priceMatch = lower.match(/[€$£]?\s*(\d[\d.,]*)\s*(k|m|million|mil|thousand)?/);
  let maxPrice: number | undefined;
  if (priceMatch) {
    let n = parseFloat(priceMatch[1].replace(/[.,]/g, ''));
    const unit = (priceMatch[2] ?? '').toLowerCase();
    if (unit === 'k' || unit === 'thousand' || unit === 'mil') n *= 1_000;
    if (unit === 'm' || unit === 'million') n *= 1_000_000;
    if (n > 10_000) maxPrice = n;
  }
  return {
    location: location ? LOCATION_MAP[location] : undefined,
    type:     type     ? TYPE_MAP[type]         : undefined,
    maxPrice,
  };
}

function getReply(isProperty: boolean, filters: ReturnType<typeof extractFilters>): string {
  if (isProperty) {
    const parts: string[] = [];
    if (filters.location) parts.push(`in ${filters.location}`);
    if (filters.type)     parts.push(`${filters.type}s`);
    if (filters.maxPrice) parts.push(`under €${(filters.maxPrice / 1000).toFixed(0)}k`);
    return `Of course! Let me find the best properties ${parts.length ? parts.join(' ') : 'on the Costa del Sol'} for you right now.`;
  }
  return AIPPIE_REPLIES[Math.floor(Math.random() * AIPPIE_REPLIES.length)];
}

function formatTimer(s: number) {
  const m = Math.floor(s / 60).toString().padStart(2, '0');
  const sec = (s % 60).toString().padStart(2, '0');
  return `${m}:${sec}`;
}

// Wave bar heights driven by a phase offset per bar index
function computeWave(tick: number, intensity: number, bars: number): number[] {
  return Array.from({ length: bars }, (_, i) => {
    const phase  = (tick * 0.18 + i * 0.62) % (Math.PI * 2);
    const jitter = (Math.sin(tick * 0.09 + i * 1.3) * 0.3 + 0.7);
    return Math.max(3, intensity * Math.abs(Math.sin(phase)) * jitter);
  });
}

export default function AssistantView({ user: _user, subscription }: Props) {
  const hasPremium = subscription !== null;

  // ── Core state ─────────────────────────────────────────────────────────────
  const [sofiaState, setSofiaState]     = useState<AippieState>('idle');
  const [transcript, setTranscript]     = useState('');
  const [connectStatus, setConnectStatus] = useState('');  // status flash text
  const [sessionSecs, setSessionSecs]   = useState(0);
  const [waveTick, setWaveTick]         = useState(0);
  const [waveAmps, setWaveAmps]         = useState<number[]>(Array(28).fill(4));
  const [holdProgress, setHoldProgress] = useState(0);

  // ── Property search state ───────────────────────────────────────────────────
  const [properties, setProperties]       = useState<Property[]>([]);
  const [propertyQuery, setPropertyQuery] = useState('');
  const [showProperties, setShowProperties] = useState(false);

  // ── Refs (mutable, never cause re-renders) ─────────────────────────────────
  const sofiaStateRef  = useRef<AippieState>('idle');
  const isHoldingRef   = useRef(false);
  const holdStartRef   = useRef(0);
  const holdTimerRef   = useRef<ReturnType<typeof setInterval> | null>(null);
  const waveTimerRef   = useRef<ReturnType<typeof setInterval> | null>(null);
  const sessionTimerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const responseTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  // Keep ref in sync with state so event handlers always read current value
  const setState = (s: AippieState) => {
    sofiaStateRef.current = s;
    setSofiaState(s);
  };

  // ── Wave animation ──────────────────────────────────────────────────────────
  const startWave = (intensity: number) => {
    if (waveTimerRef.current) clearInterval(waveTimerRef.current);
    let t = 0;
    waveTimerRef.current = setInterval(() => {
      t++;
      setWaveTick(t);
      setWaveAmps(computeWave(t, intensity, 28));
    }, 60);
  };

  const stopWave = () => {
    if (waveTimerRef.current) { clearInterval(waveTimerRef.current); waveTimerRef.current = null; }
    setWaveAmps(Array(28).fill(4));
    setWaveTick(0);
  };

  // ── Session timer ───────────────────────────────────────────────────────────
  const startSessionTimer = () => {
    setSessionSecs(1);
    sessionTimerRef.current = setInterval(() => setSessionSecs(s => s + 1), 1000);
  };

  const stopSessionTimer = () => {
    if (sessionTimerRef.current) { clearInterval(sessionTimerRef.current); sessionTimerRef.current = null; }
    setSessionSecs(0);
  };

  // ── Premium connect sequence ────────────────────────────────────────────────
  // Mirrors the interpreter flow: connecting flash → connected state + live timer
  const enterConnectedMode = () => {
    setState('connecting');
    setConnectStatus('Connecting to Aippie AI Core...');

    setTimeout(() => {
      setConnectStatus('Connected');
      setState('connected');
      startWave(18);
      startSessionTimer();
    }, 1400);
  };

  const exitConnectedMode = () => {
    stopWave();
    stopSessionTimer();
    setState('idle');
    setConnectStatus('');
    setTranscript('');
  };

  // ── Pointer handlers ────────────────────────────────────────────────────────
  const handlePointerDown = () => {
    const s = sofiaStateRef.current;
    if (s === 'responding' || s === 'connecting') return;

    if (s === 'idle') {
      // Premium users enter the live connected session immediately
      if (hasPremium) {
        enterConnectedMode();
        return;
      }
      // Free users go straight to listening
      isHoldingRef.current = true;
      holdStartRef.current = Date.now();
      setState('listening');
      setTranscript('');
      setShowProperties(false);
      startWave(22);
      holdTimerRef.current = setInterval(() => {
        setHoldProgress(Math.min((Date.now() - holdStartRef.current) / 8000, 1));
      }, 50);
      return;
    }

    if (s === 'connected') {
      // Already in a live session — hold to speak
      isHoldingRef.current = true;
      holdStartRef.current = Date.now();
      setState('listening');
      setTranscript('');
      setShowProperties(false);
      startWave(22);
      holdTimerRef.current = setInterval(() => {
        setHoldProgress(Math.min((Date.now() - holdStartRef.current) / 8000, 1));
      }, 50);
    }
  };

  const handlePointerUp = () => {
    const s = sofiaStateRef.current;
    if (s !== 'listening') return;

    // Clear hold progress
    isHoldingRef.current = false;
    if (holdTimerRef.current) { clearInterval(holdTimerRef.current); holdTimerRef.current = null; }
    setHoldProgress(0);

    const held = Date.now() - holdStartRef.current;
    if (held < 300) {
      // Too short — return to previous state
      if (hasPremium) { setState('connected'); startWave(18); }
      else { setState('idle'); stopWave(); }
      return;
    }

    // Simulate spoken query
    const q = DEMO_QUERIES[Math.floor(Math.random() * DEMO_QUERIES.length)];
    setState('responding');
    startWave(14);

    const isProperty = looksLikePropertyQuery(q);
    const filters    = isProperty ? extractFilters(q) : {};

    responseTimerRef.current = setTimeout(async () => {
      setTranscript(getReply(isProperty, filters as ReturnType<typeof extractFilters>));

      if (isProperty) {
        setPropertyQuery(q);
        let query = supabase
          .from('aippie_properties')
          .select('*')
          .eq('status', 'available')
          .order('is_featured', { ascending: false })
          .order('price_eur', { ascending: true });

        const f = filters as ReturnType<typeof extractFilters>;
        if (f.location) query = query.eq('location', f.location);
        if (f.type)     query = query.eq('property_type', f.type);
        if (f.maxPrice) query = query.lte('price_eur', f.maxPrice);

        const { data } = await query.limit(9);
        setProperties((data as Property[]) ?? []);
        setShowProperties(true);
      }

      if (hasPremium) {
        setState('connected');
        startWave(18);
      } else {
        setState('idle');
        stopWave();
      }
    }, 2200);
  };

  // Cleanup all timers on unmount
  useEffect(() => () => {
    if (holdTimerRef.current)     clearInterval(holdTimerRef.current);
    if (waveTimerRef.current)     clearInterval(waveTimerRef.current);
    if (sessionTimerRef.current)  clearInterval(sessionTimerRef.current);
    if (responseTimerRef.current) clearTimeout(responseTimerRef.current);
  }, []);

  // ── Derived display values ──────────────────────────────────────────────────
  const isConnected   = sofiaState === 'connected' || sofiaState === 'listening' || sofiaState === 'responding';
  const isConnecting  = sofiaState === 'connecting';

  const btnHint = {
    idle:       '🎙️ HOLD TO TALK TO AIPPIE',
    connecting: 'Connecting…',
    connected:  '🎙️ HOLD TO TALK TO AIPPIE',
    listening:  'Release to send',
    responding: 'Aippie is responding…',
  }[sofiaState];

  return (
    <div className="sofia-root">
      <div className="sofia-bg" />

      {/* ── Stream viewport ─────────────────────────────────── */}
      <div className="sofia-viewport">
        <div className="sofia-stream-area">
          {AIPPIE_STREAM_URL ? (
            <video className="sofia-stream-video" src={AIPPIE_STREAM_URL} autoPlay playsInline muted={false} />
          ) : (
            <div className="sofia-avatar-placeholder">
              <img
                src="/Jouw_alineatekst_(2).png"
                alt="Aippie — Premium AI Companion"
                className="sofia-avatar-photo"
                draggable={false}
              />
              <div className="sofia-avatar-photo-overlay" />
              <div className="sofia-avatar-particle sofia-avatar-particle--1" />
              <div className="sofia-avatar-particle sofia-avatar-particle--2" />
              <div className="sofia-avatar-particle sofia-avatar-particle--3" />
            </div>
          )}

          {/* Lipsync overlay during responding */}
          {sofiaState === 'responding' && (
            <div className="sofia-lipsync-overlay">
              <div className="sofia-lipsync-bars">
                {waveAmps.slice(0, 14).map((h, i) => (
                  <div key={i} className="sofia-lipsync-bar" style={{ height: `${h}px` }} />
                ))}
              </div>
            </div>
          )}

          <div className="sofia-identity-plate">
            <div className="sofia-identity-plate__name">Aippie</div>
            <div className="sofia-identity-plate__title">AI Concierge · Aippie Ecosystem</div>
          </div>
        </div>

        {/* ── Status bar ─────────────────────────────────────── */}
        <div className={`sofia-status-bar${isConnected ? ' sofia-status-bar--live' : ''}`}>
          <div className="sofia-status-bar__left">
            {/* Connecting flash */}
            {isConnecting && (
              <>
                <span className="sofia-live-dot sofia-live-dot--connecting" />
                <span className="sofia-status-bar__text sofia-status-bar__text--connecting">
                  {connectStatus}
                </span>
              </>
            )}
            {/* Connected live */}
            {isConnected && !isConnecting && (
              <>
                <span className="sofia-live-dot sofia-live-dot--pulse sofia-live-dot--green" />
                <span className="sofia-status-bar__text sofia-status-bar__text--connected">
                  Connected · {formatTimer(sessionSecs)}
                </span>
              </>
            )}
            {/* Idle */}
            {!isConnected && !isConnecting && (
              <>
                <span className="sofia-live-dot" />
                <span className="sofia-status-bar__text">Aippie is Live · Secure · WebRTC</span>
              </>
            )}
          </div>
          <div className="sofia-status-bar__right">
            <ShieldCheck size={11} />
            <span>Secure</span>
            <Wifi size={11} />
            <span>WebRTC</span>
          </div>
        </div>
      </div>

      {/* ── Live session wave grid (28 bars, premium connected mode) ─────────
          Mirrors the interpreter real-time audio visualization.
      ──────────────────────────────────────────────────────────────────────── */}
      {(isConnected || isConnecting) && (
        <div className="sofia-wave-strip sofia-wave-strip--session">
          <div className="sofia-wave-strip__label">
            {sofiaState === 'listening'  ? 'Listening to you…'
            : sofiaState === 'responding' ? 'Generating lifelike response…'
            : isConnecting               ? connectStatus
            : 'AI Core Active'}
          </div>
          <div className="sofia-waveform sofia-waveform--live">
            {waveAmps.map((h, i) => (
              <div key={i} className="sofia-wave-bar sofia-wave-bar--green" style={{ height: `${Math.round(h)}px` }} />
            ))}
          </div>
        </div>
      )}

      {/* ── Listening wave strip (free mode) ─────────────────────────────── */}
      {sofiaState === 'listening' && !hasPremium && (
        <div className="sofia-wave-strip">
          <div className="sofia-wave-strip__label">Aippie is listening…</div>
          <div className="sofia-waveform">
            {waveAmps.map((h, i) => (
              <div key={i} className="sofia-wave-bar" style={{ height: `${Math.round(h)}px` }} />
            ))}
          </div>
        </div>
      )}

      {/* ── Property grid ─────────────────────────────────────────────────── */}
      {showProperties && (
        <PropertyGrid
          properties={properties}
          query={propertyQuery}
          onClose={() => setShowProperties(false)}
        />
      )}

      {/* ── Response transcript / entry greeting ─────────────────────────── */}
      {!showProperties && (
        <div className={`sofia-transcript${(transcript || sofiaState === 'idle') ? ' sofia-transcript--visible' : ''}`}>
          {transcript && (
            <>
              <Volume2 size={13} className="sofia-transcript__icon" />
              <span className="sofia-transcript__text">{transcript}</span>
            </>
          )}
          {sofiaState === 'idle' && !transcript && (
            <>
              <Volume2 size={13} className="sofia-transcript__icon" />
              <span className="sofia-transcript__text">{ASSISTANT_GREETING}</span>
            </>
          )}
          {sofiaState === 'responding' && !transcript && (
            <div className="sofia-generating">
              <span className="sofia-generating__dot" />
              <span className="sofia-generating__dot" />
              <span className="sofia-generating__dot" />
              <span className="sofia-generating__label">Generating real-time lifelike response…</span>
            </div>
          )}
        </div>
      )}

      {/* ── Hold-to-talk + end-call controls ─────────────────────────────── */}
      <div className="sofia-talk-area">
        <div className="sofia-talk-hint">{btnHint}</div>

        <div className="sofia-talk-controls">
          <button
            className={`sofia-talk-btn sofia-talk-btn--${sofiaState}`}
            onPointerDown={handlePointerDown}
            onPointerUp={handlePointerUp}
            onPointerLeave={handlePointerUp}
            onPointerCancel={handlePointerUp}
            aria-label="Talk to Aippie"
          >
            <svg className="sofia-talk-btn__progress" viewBox="0 0 100 100">
              <circle cx="50" cy="50" r="46" className="sofia-talk-btn__track" />
              <circle
                cx="50" cy="50" r="46"
                className="sofia-talk-btn__arc"
                strokeDasharray={`${holdProgress * 289} 289`}
                transform="rotate(-90 50 50)"
              />
            </svg>
            <div className="sofia-talk-btn__rings">
              <div className="sofia-talk-btn__ring sofia-talk-btn__ring--1" />
              <div className="sofia-talk-btn__ring sofia-talk-btn__ring--2" />
            </div>
            <div className="sofia-talk-btn__core">
              {sofiaState === 'responding'
                ? <MicOff size={28} strokeWidth={1.8} />
                : <Mic    size={28} strokeWidth={1.8} />
              }
            </div>
          </button>

          {/* End-call button only visible during a live session */}
          {isConnected && (
            <button
              className="sofia-end-call-btn"
              onClick={exitConnectedMode}
              aria-label="End call"
            >
              <PhoneOff size={18} />
            </button>
          )}
        </div>

        <div className="sofia-branding">
          <ShieldCheck size={11} />
          AIPPIETAX S.A. — Premium Concierge Network
        </div>
      </div>
    </div>
  );
}
