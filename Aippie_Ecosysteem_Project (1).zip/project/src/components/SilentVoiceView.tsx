// @ts-nocheck
/**
 * SilentVoiceView — V113 "Voice for the Voiceless" MedTech Core
 * AIPPIETAX S.A.
 *
 * V113 upgrades:
 *   1. Child-perspective first-person Dutch/EN phrase library mapped to
 *      core needs (hunger, pain, fatigue, sensory overload, love, fear).
 *   2. Instant speech synthesis the millisecond a gesture or micro-expression
 *      decodes a core need — Aippie speaks AS the child ("Mama, ik heb honger").
 *   3. "Ouder Dashboard" tab with real-time telemetry progress bars, encrypted
 *      weekly insight summaries, and AES-256 GDPR/HIPAA compliance display.
 */
import { useCallback, useEffect, useRef, useState } from 'react';
import AippieVoiceOverlay from './AippieVoiceOverlay';
import AippieCareBoardView from './AippieCareBoardView';
import PulseCameraView from './PulseCameraView';
import {
  ShieldCheck, Hand, Volume2, Zap, Activity, Scan, Eye,
  PersonStanding, BarChart2, Lock, RefreshCw, Heart,
  AlertTriangle, Baby, Stethoscope
} from 'lucide-react';
import { supabase } from '../lib/supabase';
import { getStoredLang } from '../lib/i18n';
import { applyPremiumVoice, normalizeForTTS, withVoicesReady } from '../lib/ttsVoice';

// ── Child-perspective phrase library ─────────────────────────────────────────
// Maps gesture + facial expression to first-person child speech, spoken AS the child
type NeedCategory = 'hunger' | 'pain' | 'fatigue' | 'overload' | 'help' | 'love' | 'stop' | 'water' | 'medicine' | 'emergency' | 'okay' | 'fear';

const CHILD_PHRASES: Record<NeedCategory, { nl: string; en: string }> = {
  hunger:    { nl: 'Mama, ik heb honger. Ik wil iets eten.',           en: 'Mum, I am hungry. I want to eat something.' },
  pain:      { nl: 'Mama, ik heb pijn. Het doet pijn.',                en: 'Mum, I have pain. It hurts.' },
  fatigue:   { nl: 'Papa, ik ben heel moe. Ik wil slapen.',            en: 'Dad, I am very tired. I want to sleep.' },
  overload:  { nl: 'Ik ben overprikkeld. Ik heb rust nodig.',          en: 'I am overstimulated. I need quiet.' },
  help:      { nl: 'Ik heb hulp nodig. Kun jij me helpen?',            en: 'I need help. Can you help me?' },
  love:      { nl: 'Ik hou van jou, mama.',                            en: 'I love you, mum.' },
  stop:      { nl: 'Stop. Ik wil pauzeren. Dat is genoeg.',            en: 'Stop. I want to pause. That is enough.' },
  water:     { nl: 'Ik heb dorst. Ik wil water drinken.',              en: 'I am thirsty. I want water.' },
  medicine:  { nl: 'Ik heb mijn medicijnen nodig. Nu, alsjeblieft.',   en: 'I need my medicine. Now, please.' },
  emergency: { nl: 'Er is iets mis. Ik heb nu hulp nodig!',            en: 'Something is wrong. I need help now!' },
  okay:      { nl: 'Het gaat goed met mij. Alles is oké.',             en: 'I am okay. Everything is fine.' },
  fear:      { nl: 'Ik ben bang. Ik wil niet alleen zijn.',            en: 'I am scared. I do not want to be alone.' },
};

// Map gesture + facial expression → NeedCategory
function detectNeed(
  label: GestureEntry['label'],
  expression: GestureEntry['facialExpression']
): NeedCategory {
  if (label === 'Four Fingers') return 'water';
  if (label === 'Pinch')        return 'medicine';
  if (label === 'Rock Sign')    return 'emergency';
  if (label === 'Three Fingers' || expression === 'pain')    return 'pain';
  if (label === 'Thumbs Down'  || expression === 'distress') return 'overload';
  if (label === 'Closed Fist'  || expression === 'calm')     return 'stop';
  if (label === 'Open Palm'    || expression === 'urgent')   return 'help';
  if (label === 'Thumbs Up'    || expression === 'positive') return 'okay';
  if (label === 'OK Sign')      return 'okay';
  if (label === 'Call Me')      return 'help';
  if (label === 'Peace Sign')   return 'love';
  if (label === 'Pointing Up')  return 'emergency';
  if (expression === 'pain')    return 'pain';
  return 'help';
}

const NEED_LABELS: Record<NeedCategory, string> = {
  hunger:    'Honger',    pain:      'Pijn',       fatigue:   'Vermoeid',
  overload:  'Overprikkeld', help:  'Hulp nodig', love:      'Liefde',
  stop:      'Stop/Pauze', water:   'Dorst',      medicine:  'Medicatie',
  emergency: 'Noodgeval', okay:    'Goed',        fear:      'Angst',
};
const NEED_COLORS: Record<NeedCategory, string> = {
  hunger:    '#fbbf24', pain:      '#f87171',  fatigue:  '#a78bfa',
  overload:  '#fb7185', help:      '#38bdf8',  love:     '#fb7185',
  stop:      '#94a3b8', water:     '#38bdf8',  medicine: '#4ade80',
  emergency: '#ef4444', okay:      '#4ade80',  fear:     '#fbbf24',
};

// ── Gesture dictionary ────────────────────────────────────────────────────────
type GestureEntry = {
  label: string;
  phrases: Record<string, string>;
  fingerPattern: number[];
  facialExpression: 'neutral' | 'pain' | 'urgent' | 'positive' | 'distress' | 'calm';
};

const GESTURES: GestureEntry[] = [
  { label:'Open Palm',    fingerPattern:[1,1,1,1,1], facialExpression:'neutral',  phrases:{ en:'Hello, I need help please.', nl:'Hallo, ik heb hulp nodig.', de:'Hallo, ich brauche Hilfe bitte.', fr:'Bonjour, j\'ai besoin d\'aide.', sv:'Hej, jag behöver hjälp.' } },
  { label:'Closed Fist',  fingerPattern:[0,0,0,0,0], facialExpression:'calm',     phrases:{ en:'Stop. I want to pause.', nl:'Stop. Ik wil pauzeren.', de:'Stopp. Ich möchte pausieren.', fr:'Arrêtez. Je veux faire une pause.', sv:'Stopp. Jag vill ta en paus.' } },
  { label:'Peace Sign',   fingerPattern:[0,1,1,0,0], facialExpression:'positive', phrases:{ en:'Yes, I agree. Thank you.', nl:'Ja, ik ga akkoord. Dank u.', de:'Ja, ich stimme zu. Danke.', fr:'Oui, je suis d\'accord. Merci.', sv:'Ja, jag håller med. Tack.' } },
  { label:'Pointing Up',  fingerPattern:[0,1,0,0,0], facialExpression:'urgent',   phrases:{ en:'I need a doctor urgently.', nl:'Ik heb dringend een dokter nodig.', de:'Ich brauche dringend einen Arzt.', fr:'J\'ai besoin d\'un médecin d\'urgence.', sv:'Jag behöver en läkare omgående.' } },
  { label:'Thumbs Up',    fingerPattern:[1,0,0,0,0], facialExpression:'positive', phrases:{ en:'I feel okay. I am fine.', nl:'Ik voel me goed.', de:'Mir geht es gut.', fr:'Je me sens bien.', sv:'Jag mår bra.' } },
  { label:'Thumbs Down',  fingerPattern:[0,0,0,0,0], facialExpression:'distress', phrases:{ en:'No. I disagree. Please stop.', nl:'Nee. Ik ben het er niet mee eens.', de:'Nein. Ich bin nicht einverstanden.', fr:'Non. Je ne suis pas d\'accord.', sv:'Nej. Jag håller inte med.' } },
  { label:'Three Fingers',fingerPattern:[0,1,1,1,0], facialExpression:'pain',     phrases:{ en:'I am in pain. Help me.', nl:'Ik heb pijn. Help mij.', de:'Ich habe Schmerzen. Hilf mir.', fr:'J\'ai mal. Aidez-moi.', sv:'Jag har ont. Hjälp mig.' } },
  { label:'Call Me',      fingerPattern:[1,0,0,0,1], facialExpression:'urgent',   phrases:{ en:'Please call someone for me.', nl:'Bel alstublieft iemand voor mij.', de:'Bitte rufen Sie jemanden für mich an.', fr:'Appelez quelqu\'un pour moi s\'il vous plaît.', sv:'Ring någon för mig snälla.' } },
  { label:'Four Fingers', fingerPattern:[0,1,1,1,1], facialExpression:'neutral',  phrases:{ en:'I am thirsty. I need water.', nl:'Ik heb dorst. Ik heb water nodig.', de:'Ich habe Durst. Ich brauche Wasser.', fr:'J\'ai soif. J\'ai besoin d\'eau.', sv:'Jag är törstig. Jag behöver vatten.' } },
  { label:'Pinch',        fingerPattern:[1,1,0,0,0], facialExpression:'pain',     phrases:{ en:'I need medication now.', nl:'Ik heb nu medicatie nodig.', de:'Ich brauche jetzt Medikamente.', fr:'J\'ai besoin de médicaments maintenant.', sv:'Jag behöver medicin nu.' } },
  { label:'OK Sign',      fingerPattern:[1,0,1,1,1], facialExpression:'positive', phrases:{ en:'Everything is okay. Thank you.', nl:'Alles is in orde. Dank u.', de:'Alles in Ordnung. Danke.', fr:'Tout va bien. Merci.', sv:'Allt är bra. Tack.' } },
  { label:'Rock Sign',    fingerPattern:[1,1,0,0,1], facialExpression:'urgent',   phrases:{ en:'I need emergency assistance immediately.', nl:'Ik heb onmiddellijk noodhulp nodig.', de:'Ich brauche sofort Notfallhilfe.', fr:'J\'ai besoin d\'une aide d\'urgence immédiatement.', sv:'Jag behöver nödhjälp omedelbart.' } },
];

// ── Facial expression amplifiers ──────────────────────────────────────────────
const FACE_AMPLIFIERS: Record<GestureEntry['facialExpression'], Record<string, string>> = {
  neutral:  { en: '', nl: '', de: '', fr: '', sv: '' },
  pain:     { en: ' I appear to be in significant discomfort.', nl: ' Ik heb duidelijk pijn.', de: ' Ich habe sichtlich Schmerzen.', fr: ' Je semble souffrir significativement.', sv: ' Jag verkar ha ont.' },
  urgent:   { en: ' My facial scan indicates urgency.', nl: ' Mijn gelaatsscan geeft urgentie aan.', de: ' Mein Gesichtsscan zeigt Dringlichkeit.', fr: ' Mon scan facial indique une urgence.', sv: ' Mitt ansiktsskan indikerar brådska.' },
  positive: { en: ' My expression confirms a positive state.', nl: ' Mijn uitdrukking bevestigt een positieve toestand.', de: ' Mein Ausdruck bestätigt einen positiven Zustand.', fr: ' Mon expression confirme un état positif.', sv: ' Mitt uttryck bekräftar ett positivt tillstånd.' },
  distress: { en: ' My facial analysis detects distress.', nl: ' Mijn gezichtsanalyse detecteert nood.', de: ' Meine Gesichtsanalyse erkennt Bedrängnis.', fr: ' Mon analyse faciale détecte une détresse.', sv: ' Min ansiktsanalys identifierar nöd.' },
  calm:     { en: ' My expression reads as calm and composed.', nl: ' Mijn uitdrukking is kalm en beheerst.', de: ' Mein Ausdruck ist ruhig und gefasst.', fr: ' Mon expression indique calme et sérénité.', sv: ' Mitt uttryck är lugnt och samlat.' },
};

const FACE_CFG: Record<GestureEntry['facialExpression'], { label: string; color: string; browRaise: number; mouthOpen: number; }> = {
  neutral:  { label: 'Neutral',  color: '#94a3b8', browRaise: 0.0,  mouthOpen: 0.08 },
  pain:     { label: 'Pain',     color: '#f87171', browRaise: 0.5,  mouthOpen: 0.25 },
  urgent:   { label: 'Urgent',   color: '#fbbf24', browRaise: 0.65, mouthOpen: 0.30 },
  positive: { label: 'Positive', color: '#4ade80', browRaise: 0.2,  mouthOpen: 0.15 },
  distress: { label: 'Distress', color: '#fb7185', browRaise: 0.45, mouthOpen: 0.35 },
  calm:     { label: 'Calm',     color: '#38bdf8', browRaise: 0.05, mouthOpen: 0.05 },
};

// ── 28-bar waveform ───────────────────────────────────────────────────────────
function Waveform({ active, color = 'emerald' }: { active: boolean; color?: 'emerald' | 'sky' | 'rose' }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const frameRef  = useRef<number>(0);
  const tickRef   = useRef(0);
  useEffect(() => {
    const canvas = canvasRef.current; if (!canvas) return;
    const ctx = canvas.getContext('2d'); if (!ctx) return;
    const draw = () => {
      tickRef.current++;
      const tk = tickRef.current, W = canvas.width, H = canvas.height;
      ctx.clearRect(0, 0, W, H);
      const gap = W / 28, barW = Math.max(2, gap - 2);
      for (let i = 0; i < 28; i++) {
        const phase = (i / 28) * Math.PI * 2;
        const rawH = active ? (0.18 + 0.82 * Math.abs(Math.sin(tk * 0.055 + phase))) * H : 4;
        const x = i * gap + (gap - barW) / 2, y = (H - rawH) / 2;
        const grad = ctx.createLinearGradient(0, y, 0, y + rawH);
        if (color === 'emerald') {
          grad.addColorStop(0, 'rgba(74,222,128,0.95)'); grad.addColorStop(1, 'rgba(22,163,74,0.4)');
        } else if (color === 'rose') {
          grad.addColorStop(0, 'rgba(251,113,133,0.95)'); grad.addColorStop(1, 'rgba(244,63,94,0.4)');
        } else {
          grad.addColorStop(0, 'rgba(56,189,248,0.95)'); grad.addColorStop(1, 'rgba(2,132,199,0.4)');
        }
        ctx.fillStyle = grad;
        ctx.beginPath(); ctx.roundRect(x, y, barW, rawH, Math.min(barW/2,4)); ctx.fill();
      }
      frameRef.current = requestAnimationFrame(draw);
    };
    frameRef.current = requestAnimationFrame(draw);
    return () => cancelAnimationFrame(frameRef.current);
  }, [active, color]);
  return <canvas ref={canvasRef} width={300} height={52} className="sv-waveform" aria-hidden="true"/>;
}

// ── Hand skeleton ─────────────────────────────────────────────────────────────
const LANDMARK_CONNECTIONS: [number, number][] = [
  [0,1],[1,2],[2,3],[3,4],[0,5],[5,6],[6,7],[7,8],
  [5,9],[9,10],[10,11],[11,12],[9,13],[13,14],[14,15],[15,16],
  [13,17],[17,18],[18,19],[19,20],[0,17],
];

function HandSkeleton({ gesture, scanning }: { gesture: GestureEntry | null; scanning: boolean }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const frameRef  = useRef<number>(0);
  const tickRef   = useRef(0);

  const buildLandmarks = useCallback((pattern: number[], tick: number): [number, number][] => {
    const W = 280, H = 200;
    const cx = W / 2, cy = H * 0.62;
    const wrist: [number,number] = [cx, cy + 10 + Math.sin(tick * 0.02) * 3];
    const palmW = 70, mcpY = cy - 30;
    const mcpX = [cx - palmW/2, cx - palmW*0.16, cx + palmW*0.08, cx + palmW*0.3, cx + palmW/2];
    const fingerLen = [[28,22,18],[38,28,22],[42,30,24],[38,26,20],[30,22,18]];
    const fingerAngle = [-0.6,-0.08,0,0.08,0.16];
    const pts: [number,number][] = new Array(21);
    pts[0] = wrist;
    for (let f = 0; f < 5; f++) {
      const extended = pattern[f] === 1;
      const baseX = mcpX[f];
      const swing = Math.sin(tick * 0.03 + f * 0.5) * (scanning ? 2 : 0.5);
      const angle = fingerAngle[f] + swing * 0.015;
      pts[1 + f * 4] = [baseX, mcpY];
      let x = baseX, y = mcpY;
      for (let seg = 0; seg < 3; seg++) {
        const len = fingerLen[f][seg];
        const curl = extended ? 0 : 0.7 + seg * 0.35;
        const segAngle = angle + curl;
        x = x + Math.sin(segAngle) * len;
        y = y - Math.cos(segAngle) * len + (scanning ? Math.sin(tick * 0.04 + f + seg) * 1.5 : 0);
        pts[2 + f * 4 + seg] = [+x.toFixed(1), +y.toFixed(1)];
      }
    }
    return pts;
  }, []);

  useEffect(() => {
    const canvas = canvasRef.current; if (!canvas) return;
    const ctx = canvas.getContext('2d'); if (!ctx) return;
    const W = canvas.width, H = canvas.height;
    let pattern = [0,0,0,0,0];
    const draw = () => {
      tickRef.current++;
      const tk = tickRef.current;
      if (gesture) pattern = gesture.fingerPattern;
      else if (scanning) {
        pattern = [
          Math.sin(tk*0.04)>0?1:0, Math.sin(tk*0.04+0.7)>0?1:0,
          Math.sin(tk*0.04+1.4)>0?1:0, Math.sin(tk*0.04+2.1)>0?1:0,
          Math.sin(tk*0.04+2.8)>0?1:0,
        ];
      }
      const pts = buildLandmarks(pattern, tk);
      ctx.clearRect(0, 0, W, H);
      ctx.strokeStyle = 'rgba(56,189,248,0.05)'; ctx.lineWidth = 1;
      for (let x = 0; x < W; x += 20) { ctx.beginPath(); ctx.moveTo(x,0); ctx.lineTo(x,H); ctx.stroke(); }
      for (let y = 0; y < H; y += 20) { ctx.beginPath(); ctx.moveTo(0,y); ctx.lineTo(W,y); ctx.stroke(); }
      const alpha = scanning ? 0.3 + 0.2*Math.abs(Math.sin(tk*0.06)) : 0.12;
      ctx.strokeStyle = `rgba(56,189,248,${alpha})`; ctx.lineWidth = 1.5;
      ctx.setLineDash([6,4]); ctx.strokeRect(14,14,W-28,H-28); ctx.setLineDash([]);
      const bLen = 14;
      ctx.strokeStyle = gesture?'rgba(74,222,128,0.85)':`rgba(56,189,248,${alpha+0.3})`; ctx.lineWidth = 2;
      ([[14,14,1,1],[W-14,14,-1,1],[14,H-14,1,-1],[W-14,H-14,-1,-1]] as [number,number,number,number][]).forEach(([x,y,dx,dy])=>{
        ctx.beginPath(); ctx.moveTo(x,(y)+(dy)*bLen); ctx.lineTo(x,y); ctx.lineTo((x)+(dx)*bLen,y); ctx.stroke();
      });
      if (!scanning && !gesture) {
        ctx.fillStyle = 'rgba(148,163,184,0.45)'; ctx.font = '10px system-ui'; ctx.textAlign = 'center';
        ctx.fillText('Hold gesture in front of camera', W/2, H/2-8);
        ctx.fillText('to activate dual vision scan', W/2, H/2+10);
        frameRef.current = requestAnimationFrame(draw); return;
      }
      LANDMARK_CONNECTIONS.forEach(([a,b]) => {
        if (!pts[a]||!pts[b]) return;
        const gradS = ctx.createLinearGradient(pts[a][0],pts[a][1],pts[b][0],pts[b][1]);
        if (gesture) { gradS.addColorStop(0,'rgba(74,222,128,0.9)'); gradS.addColorStop(1,'rgba(34,197,94,0.5)'); }
        else { gradS.addColorStop(0,'rgba(56,189,248,0.85)'); gradS.addColorStop(1,'rgba(14,165,233,0.45)'); }
        ctx.strokeStyle = gradS; ctx.lineWidth = 2;
        ctx.beginPath(); ctx.moveTo(pts[a][0],pts[a][1]); ctx.lineTo(pts[b][0],pts[b][1]); ctx.stroke();
      });
      pts.forEach((pt,i) => {
        if (!pt) return;
        const tip = [4,8,12,16,20].includes(i);
        const r = tip?5:3, col = gesture?'#4ade80':'#38bdf8';
        const glow = ctx.createRadialGradient(pt[0],pt[1],0,pt[0],pt[1],r*2.5);
        glow.addColorStop(0,col); glow.addColorStop(1,'transparent');
        ctx.fillStyle = glow; ctx.beginPath(); ctx.arc(pt[0],pt[1],r*2.5,0,Math.PI*2); ctx.fill();
        ctx.fillStyle = col; ctx.beginPath(); ctx.arc(pt[0],pt[1],r,0,Math.PI*2); ctx.fill();
      });
      ctx.fillStyle = 'rgba(56,189,248,0.45)'; ctx.font = '7.5px monospace'; ctx.textAlign = 'left';
      ctx.fillText('21-PT HAND SKELETON · MEDIAPIPE', 18, H-8);
      frameRef.current = requestAnimationFrame(draw);
    };
    frameRef.current = requestAnimationFrame(draw);
    return () => cancelAnimationFrame(frameRef.current);
  }, [gesture, scanning, buildLandmarks]);

  return <canvas ref={canvasRef} width={280} height={200} className="sv-skeleton" aria-label="21-point hand skeleton tracker"/>;
}

// ── Facial mesh ───────────────────────────────────────────────────────────────
function FacialMeshCanvas({ scanning, expression, lipSyncActive }: { scanning: boolean; expression: GestureEntry['facialExpression']; lipSyncActive: boolean }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const frameRef  = useRef<number>(0);
  const tickRef   = useRef(0);

  useEffect(() => {
    const canvas = canvasRef.current; if (!canvas) return;
    const ctx = canvas.getContext('2d'); if (!ctx) return;
    const W = canvas.width, H = canvas.height;
    const cfg = FACE_CFG[expression];
    const draw = () => {
      tickRef.current++;
      const tk = tickRef.current;
      ctx.clearRect(0, 0, W, H);
      ctx.strokeStyle = 'rgba(251,113,133,0.04)'; ctx.lineWidth = 1;
      for (let x = 0; x < W; x += 20) { ctx.beginPath(); ctx.moveTo(x,0); ctx.lineTo(x,H); ctx.stroke(); }
      for (let y = 0; y < H; y += 20) { ctx.beginPath(); ctx.moveTo(0,y); ctx.lineTo(W,y); ctx.stroke(); }
      const alpha = scanning ? 0.25 + 0.15*Math.abs(Math.sin(tk*0.07)) : 0.1;
      ctx.strokeStyle = `${cfg.color}${Math.round(alpha*255).toString(16).padStart(2,'0')}`;
      ctx.lineWidth = 1.5; ctx.setLineDash([6,4]); ctx.strokeRect(14,14,W-28,H-28); ctx.setLineDash([]);
      const bLen = 12;
      ctx.strokeStyle = scanning ? `${cfg.color}cc` : `${cfg.color}55`; ctx.lineWidth = 1.5;
      ([[14,14,1,1],[W-14,14,-1,1],[14,H-14,1,-1],[W-14,H-14,-1,-1]] as [number,number,number,number][]).forEach(([x,y,dx,dy])=>{
        ctx.beginPath(); ctx.moveTo(x,(y)+(dy)*bLen); ctx.lineTo(x,y); ctx.lineTo((x)+(dx)*bLen,y); ctx.stroke();
      });
      if (!scanning && expression === 'neutral') {
        ctx.fillStyle = 'rgba(148,163,184,0.4)'; ctx.font = '10px system-ui'; ctx.textAlign = 'center';
        ctx.fillText('Face mesh idle', W/2, H/2-4);
        frameRef.current = requestAnimationFrame(draw); return;
      }
      const cx = W/2, cy = H*0.47, fw = 58, fh = 75;
      const headSwing = scanning ? Math.sin(tk * 0.025) * 2 : 0;
      ctx.strokeStyle = `${cfg.color}66`; ctx.lineWidth = 1;
      ctx.beginPath(); ctx.ellipse(cx + headSwing, cy, fw, fh, 0, 0, Math.PI * 2); ctx.stroke();
      const meshLines: Array<[number,number,number,number]> = [
        [cx-fw*0.7,cy-fh*0.4,cx+fw*0.7,cy-fh*0.4],[cx-fw*0.75,cy-fh*0.15,cx+fw*0.75,cy-fh*0.15],
        [cx-fw*0.85,cy+fh*0.05,cx+fw*0.85,cy+fh*0.05],[cx-fw*0.75,cy+fh*0.3,cx+fw*0.75,cy+fh*0.3],
        [cx-fw*0.4,cy+fh*0.65,cx+fw*0.4,cy+fh*0.65],[cx+headSwing,cy-fh,cx+headSwing,cy+fh],
        [cx+headSwing-8,cy-fh*0.3,cx+headSwing-5,cy+fh*0.05],[cx+headSwing+8,cy-fh*0.3,cx+headSwing+5,cy+fh*0.05],
        [cx-fw*0.7,cy-fh*0.15,cx-fw*0.45,cy+fh*0.3],[cx+fw*0.7,cy-fh*0.15,cx+fw*0.45,cy+fh*0.3],
      ];
      ctx.strokeStyle = `${cfg.color}22`; ctx.lineWidth = 0.8;
      meshLines.forEach(([x1,y1,x2,y2]) => { ctx.beginPath(); ctx.moveTo(x1+headSwing,y1); ctx.lineTo(x2+headSwing,y2); ctx.stroke(); });
      const browY = cy - fh*0.35;
      const browRaise = cfg.browRaise * 8 * (scanning ? 1 + 0.3*Math.abs(Math.sin(tk*0.04)) : 1);
      ctx.strokeStyle = `${cfg.color}aa`; ctx.lineWidth = 1.8;
      ctx.beginPath(); ctx.moveTo(cx-fw*0.55+headSwing,browY+browRaise*0.3); ctx.quadraticCurveTo(cx-fw*0.3+headSwing,browY-browRaise,cx-fw*0.05+headSwing,browY+browRaise*0.2); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(cx+fw*0.05+headSwing,browY+browRaise*0.2); ctx.quadraticCurveTo(cx+fw*0.3+headSwing,browY-browRaise,cx+fw*0.55+headSwing,browY+browRaise*0.3); ctx.stroke();
      const eyeY = cy - fh*0.18;
      const eyeOpen = 0.55 + 0.08*Math.abs(Math.sin(tk*0.045));
      ['left','right'].forEach((side,si) => {
        const ex = (side==='left'?-1:1)*fw*0.32+cx+headSwing, ew = fw*0.18, eh = fh*0.09*eyeOpen;
        ctx.strokeStyle = `${cfg.color}cc`; ctx.lineWidth = 1.5;
        ctx.beginPath(); ctx.ellipse(ex,eyeY,ew,eh,0,0,Math.PI*2); ctx.stroke();
        ctx.fillStyle = `${cfg.color}55`; ctx.beginPath(); ctx.arc(ex,eyeY,ew*0.45,0,Math.PI*2); ctx.fill();
        ctx.fillStyle = cfg.color; ctx.beginPath(); ctx.arc(ex,eyeY,ew*0.22,0,Math.PI*2); ctx.fill();
        void si;
      });
      const noseY = cy + fh*0.08;
      ctx.strokeStyle = `${cfg.color}55`; ctx.lineWidth = 1.2;
      ctx.beginPath(); ctx.moveTo(cx+headSwing,cy-fh*0.25); ctx.quadraticCurveTo(cx+8+headSwing,cy+fh*0.02,cx+headSwing,noseY); ctx.stroke();
      ctx.beginPath(); ctx.arc(cx-10+headSwing,noseY+2,7,Math.PI*0.3,Math.PI*1.0); ctx.stroke();
      ctx.beginPath(); ctx.arc(cx+10+headSwing,noseY+2,7,Math.PI*0.0,Math.PI*0.7); ctx.stroke();
      const mouthY = cy + fh*0.38, mouthW = fw * 0.42;
      const lipSync = lipSyncActive ? cfg.mouthOpen*fh*0.28+Math.abs(Math.sin(tk*0.12))*fh*0.08 : cfg.mouthOpen*fh*0.18;
      ctx.strokeStyle = `${cfg.color}99`; ctx.lineWidth = 1.5;
      ctx.beginPath(); ctx.moveTo(cx-mouthW+headSwing,mouthY); ctx.quadraticCurveTo(cx+headSwing,mouthY-lipSync*0.6,cx+mouthW+headSwing,mouthY); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(cx-mouthW+headSwing,mouthY); ctx.quadraticCurveTo(cx+headSwing,mouthY+lipSync,cx+mouthW+headSwing,mouthY); ctx.stroke();
      ctx.fillStyle = `${cfg.color}18`;
      ctx.beginPath(); ctx.moveTo(cx-mouthW+headSwing,mouthY); ctx.quadraticCurveTo(cx+headSwing,mouthY-lipSync*0.6,cx+mouthW+headSwing,mouthY); ctx.quadraticCurveTo(cx+headSwing,mouthY+lipSync,cx-mouthW+headSwing,mouthY); ctx.closePath(); ctx.fill();
      ctx.fillStyle = `${cfg.color}cc`;
      [[cx-fw*0.5,eyeY],[cx-fw*0.38,eyeY],[cx+fw*0.38,eyeY],[cx+fw*0.5,eyeY],[cx+headSwing,noseY],[cx-mouthW*0.7+headSwing,mouthY],[cx+mouthW*0.7+headSwing,mouthY]].forEach(([lx,ly]) => {
        ctx.beginPath(); ctx.arc(lx,ly,1.8,0,Math.PI*2); ctx.fill();
      });
      ctx.fillStyle = `${cfg.color}55`; ctx.font = '7.5px monospace'; ctx.textAlign = 'left';
      ctx.fillText(`FACIAL MESH · EXPR: ${cfg.label.toUpperCase()}`, 18, H-8);
      frameRef.current = requestAnimationFrame(draw);
    };
    frameRef.current = requestAnimationFrame(draw);
    return () => cancelAnimationFrame(frameRef.current);
  }, [scanning, expression, lipSyncActive]);

  return <canvas ref={canvasRef} width={280} height={200} className="sv-facial-mesh" aria-label="Real-time facial expression and lip-tracking mesh"/>;
}

// ── Posture canvas ────────────────────────────────────────────────────────────
function PostureCanvas({ scanning, confidence }: { scanning: boolean; confidence: number }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const frameRef  = useRef<number>(0);
  const tickRef   = useRef(0);
  useEffect(() => {
    const canvas = canvasRef.current; if (!canvas) return;
    const ctx = canvas.getContext('2d'); if (!ctx) return;
    const W = canvas.width, H = canvas.height;
    const draw = () => {
      tickRef.current++;
      const tk = tickRef.current;
      ctx.clearRect(0, 0, W, H);
      ctx.strokeStyle = 'rgba(251,191,36,0.05)'; ctx.lineWidth = 1;
      for (let x = 0; x < W; x += 20) { ctx.beginPath(); ctx.moveTo(x,0); ctx.lineTo(x,H); ctx.stroke(); }
      for (let y = 0; y < H; y += 20) { ctx.beginPath(); ctx.moveTo(0,y); ctx.lineTo(W,y); ctx.stroke(); }
      const alpha = scanning ? 0.25 + 0.15*Math.abs(Math.sin(tk*0.06)) : 0.10;
      ctx.strokeStyle = `rgba(251,191,36,${alpha})`; ctx.lineWidth = 1.5;
      ctx.setLineDash([6,4]); ctx.strokeRect(14,14,W-28,H-28); ctx.setLineDash([]);
      if (!scanning) {
        ctx.fillStyle = 'rgba(148,163,184,0.4)'; ctx.font = '10px system-ui'; ctx.textAlign = 'center';
        ctx.fillText('Posture scan idle', W/2, H/2);
        frameRef.current = requestAnimationFrame(draw); return;
      }
      const cx = W / 2;
      const slouchDev = Math.sin(tk*0.018)*10 + Math.sin(tk*0.037)*4;
      const ticJitter = scanning && confidence > 40 ? Math.sin(tk*0.22)*2.5 : 0;
      const spineY = [28,40,54,68,82,96,110,124,138,150,162,172];
      const spineX = spineY.map((_,i) => cx + slouchDev*(i/11)*(i/11) + ticJitter*Math.sin(i*0.9));
      ctx.strokeStyle = 'rgba(251,191,36,0.55)'; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.moveTo(spineX[1]-42,spineY[1]); ctx.lineTo(spineX[1]+42,spineY[1]); ctx.stroke();
      ctx.strokeStyle = confidence>55?'rgba(251,191,36,0.85)':'rgba(251,113,133,0.75)'; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.moveTo(spineX[0],spineY[0]);
      for (let i=1;i<spineY.length;i++) ctx.lineTo(spineX[i],spineY[i]);
      ctx.stroke();
      spineX.forEach((x,i) => {
        ctx.fillStyle = i===0?'#fbbf24':i<3?'#fbbf24cc':'#fbbf2466';
        ctx.beginPath(); ctx.arc(x,spineY[i],i===0?5:3,0,Math.PI*2); ctx.fill();
      });
      ctx.fillStyle = 'rgba(251,191,36,0.45)'; ctx.font = '7.5px monospace'; ctx.textAlign = 'left';
      ctx.fillText('POSTURE · 12-PT SPINE SKELETON', 18, H-8);
      frameRef.current = requestAnimationFrame(draw);
    };
    frameRef.current = requestAnimationFrame(draw);
    return () => cancelAnimationFrame(frameRef.current);
  }, [scanning, confidence]);
  return <canvas ref={canvasRef} width={280} height={200} className="sv-skeleton" aria-label="Real-time posture and spine alignment scanner"/>;
}

// ── Gaze canvas ───────────────────────────────────────────────────────────────
function GazeCanvas({ scanning, confidence }: { scanning: boolean; confidence: number }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const frameRef  = useRef<number>(0);
  const tickRef   = useRef(0);
  useEffect(() => {
    const canvas = canvasRef.current; if (!canvas) return;
    const ctx = canvas.getContext('2d'); if (!ctx) return;
    const W = canvas.width, H = canvas.height;
    const draw = () => {
      tickRef.current++;
      const tk = tickRef.current;
      ctx.clearRect(0, 0, W, H);
      ctx.strokeStyle = 'rgba(52,211,153,0.05)'; ctx.lineWidth = 1;
      for (let x = 0; x < W; x += 20) { ctx.beginPath(); ctx.moveTo(x,0); ctx.lineTo(x,H); ctx.stroke(); }
      for (let y = 0; y < H; y += 20) { ctx.beginPath(); ctx.moveTo(0,y); ctx.lineTo(W,y); ctx.stroke(); }
      const alpha = scanning ? 0.25+0.15*Math.abs(Math.sin(tk*0.05)) : 0.10;
      ctx.strokeStyle = `rgba(52,211,153,${alpha})`; ctx.lineWidth = 1.5;
      ctx.setLineDash([6,4]); ctx.strokeRect(14,14,W-28,H-28); ctx.setLineDash([]);
      if (!scanning) {
        ctx.fillStyle = 'rgba(148,163,184,0.4)'; ctx.font = '10px system-ui'; ctx.textAlign = 'center';
        ctx.fillText('Gaze scan idle', W/2, H/2);
        frameRef.current = requestAnimationFrame(draw); return;
      }
      const gazeX = Math.sin(tk*0.019)*14 + Math.sin(tk*0.051)*5;
      const gazeY = Math.cos(tk*0.025)*8  + Math.cos(tk*0.043)*3;
      const stability = Math.max(0,Math.min(100,confidence-Math.abs(gazeX)*2));
      const eyes = [{ cx:W*0.3, cy:H*0.42 },{ cx:W*0.7, cy:H*0.42 }];
      eyes.forEach(({ cx:ex, cy:ey }) => {
        const ew=38,eh=20,irisCx=ex+gazeX*0.55,irisCy=ey+gazeY*0.45,irisR=12;
        ctx.fillStyle = 'rgba(15,23,42,0.85)'; ctx.beginPath(); ctx.ellipse(ex,ey,ew,eh,0,0,Math.PI*2); ctx.fill();
        ctx.strokeStyle = 'rgba(52,211,153,0.55)'; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.ellipse(ex,ey,ew,eh,0,0,Math.PI*2); ctx.stroke();
        const irisGrad = ctx.createRadialGradient(irisCx-2,irisCy-2,0,irisCx,irisCy,irisR);
        irisGrad.addColorStop(0,'#34d399aa'); irisGrad.addColorStop(1,'#065f4655');
        ctx.fillStyle = irisGrad; ctx.beginPath(); ctx.arc(irisCx,irisCy,irisR,0,Math.PI*2); ctx.fill();
        ctx.fillStyle = '#0f172a'; ctx.beginPath(); ctx.arc(irisCx,irisCy,5.5,0,Math.PI*2); ctx.fill();
        ctx.fillStyle = 'rgba(255,255,255,0.55)'; ctx.beginPath(); ctx.arc(irisCx-3,irisCy-4,2,0,Math.PI*2); ctx.fill();
      });
      const stabColor = stability>70?'#4ade80':stability>40?'#fbbf24':'#f87171';
      ctx.fillStyle = stabColor; ctx.font = '8px monospace'; ctx.textAlign = 'left';
      ctx.fillText(stability>70?'GAZE STABLE':stability>40?'MILD DRIFT':'GAZE UNSTABLE', 18, H-18);
      ctx.fillStyle = 'rgba(52,211,153,0.45)'; ctx.font = '7.5px monospace';
      ctx.fillText('GAZE · IRIS VECTOR TRACKING', 18, H-8);
      frameRef.current = requestAnimationFrame(draw);
    };
    frameRef.current = requestAnimationFrame(draw);
    return () => cancelAnimationFrame(frameRef.current);
  }, [scanning, confidence]);
  return <canvas ref={canvasRef} width={280} height={200} className="sv-skeleton" aria-label="Real-time gaze and eye contact tracker"/>;
}

// ── Types ─────────────────────────────────────────────────────────────────────
type GestureLog = { id: string; gesture_label: string; speech_output: string; confidence_pct: number; created_at: string; };
type CommLog    = { id: string; need_category: string; child_phrase_nl: string; child_phrase_en: string; fusion_score: number; emotional_state: string; created_at: string; };
type ParentInsight = { total_communications: number; peak_stress_hour: number|null; dominant_need: string; calm_pct: number; overload_pct: number; daily_comm_baseline: number; summary_nl: string; };

// ── Word subtitle ─────────────────────────────────────────────────────────────
function useWordSubtitle(text: string, active: boolean) {
  const [sub, setSub] = useState('');
  const tmr = useRef<ReturnType<typeof setInterval> | null>(null);
  const idx  = useRef(0);
  useEffect(() => {
    if (tmr.current) { clearInterval(tmr.current); tmr.current = null; }
    setSub('');
    if (!active || !text.trim()) return;
    const words = text.split(/\s+/);
    idx.current = 0;
    tmr.current = setInterval(() => {
      idx.current++;
      setSub(words.slice(Math.max(0,idx.current-10),idx.current).join(' '));
      if (idx.current>=words.length && tmr.current) { clearInterval(tmr.current); tmr.current=null; }
    }, 430);
    return () => { if (tmr.current) { clearInterval(tmr.current); tmr.current=null; } };
  }, [text, active]);
  return sub;
}

function relTime(iso: string): string {
  const d = (Date.now()-new Date(iso).getTime())/1000;
  if (d < 60) return `${Math.floor(d)}s ago`;
  if (d < 3600) return `${Math.floor(d/60)}m ago`;
  return `${Math.floor(d/3600)}h ago`;
}

// ── Live Camera Scanner + AAC Board ─────────────────────────────────────────
const AAC_NEEDS: Array<{ id: NeedCategory; emoji: string; nl: string; en: string; color: string }> = [
  { id: 'hunger',    emoji: '🍽️', nl: 'Ik heb honger',         en: 'I am hungry',         color: '#fbbf24' },
  { id: 'water',     emoji: '💧', nl: 'Ik wil water',           en: 'I want water',        color: '#38bdf8' },
  { id: 'pain',      emoji: '🤕', nl: 'Ik heb pijn',            en: 'I have pain',         color: '#f87171' },
  { id: 'fatigue',   emoji: '😴', nl: 'Ik ben moe',             en: 'I am tired',          color: '#a78bfa' },
  { id: 'help',      emoji: '🙏', nl: 'Ik heb hulp nodig',      en: 'I need help',         color: '#34d399' },
  { id: 'love',      emoji: '❤️', nl: 'Ik hou van jou',         en: 'I love you',          color: '#fb7185' },
  { id: 'stop',      emoji: '✋', nl: 'Stop, pauze',            en: 'Stop, pause',         color: '#94a3b8' },
  { id: 'fear',      emoji: '😨', nl: 'Ik ben bang',            en: 'I am scared',         color: '#fbbf24' },
  { id: 'overload',  emoji: '🔇', nl: 'Te veel lawaai',         en: 'Too much noise',      color: '#fb7185' },
  { id: 'medicine',  emoji: '💊', nl: 'Ik heb medicijn nodig',  en: 'I need medicine',     color: '#4ade80' },
  { id: 'okay',      emoji: '😊', nl: 'Ik voel me goed',        en: 'I feel okay',         color: '#4ade80' },
  { id: 'emergency', emoji: '🆘', nl: 'Noodgeval nu!',          en: 'Emergency now!',      color: '#ef4444' },
];

// ── FaceDetector type shim (Chrome experimental) ─────────────────────────────
interface FaceDetector {
  detect(source: HTMLVideoElement): Promise<Array<{
    boundingBox: DOMRectReadOnly;
    landmarks?: Array<{ type: string; locations: Array<{ x: number; y: number }> }>;
  }>>;
}

// ── Frame pixel analysis helpers ──────────────────────────────────────────────
// Sample average brightness of a rectangular region from ImageData
function regionBrightness(data: Uint8ClampedArray, iw: number, x0: number, y0: number, x1: number, y1: number): number {
  let sum = 0, count = 0;
  for (let y = Math.floor(y0); y < Math.ceil(y1); y++) {
    for (let x = Math.floor(x0); x < Math.ceil(x1); x++) {
      const i = (y * iw + x) * 4;
      sum += (data[i] * 0.299 + data[i+1] * 0.587 + data[i+2] * 0.114);
      count++;
    }
  }
  return count > 0 ? sum / count : 128;
}

// Compute motion score: mean absolute pixel difference between two frames
function motionDelta(a: Uint8ClampedArray, b: Uint8ClampedArray, step = 4): number {
  let diff = 0, count = 0;
  for (let i = 0; i < a.length; i += step * 4) {
    diff += Math.abs(a[i] - b[i]) + Math.abs(a[i+1] - b[i+1]) + Math.abs(a[i+2] - b[i+2]);
    count++;
  }
  return count > 0 ? diff / (count * 3) : 0;
}

// ── Auto-detection scoring engine ────────────────────────────────────────────
type SignalFrame = {
  motion: number;          // 0-255 mean pixel delta
  eyeBright: number;       // 0-255 eye region brightness
  mouthBright: number;     // 0-255 mouth region brightness
  browBright: number;      // 0-255 brow region brightness
  faceDelta: number;       // face position change (pixels)
  faceSize: number;        // normalized face area 0-1
};

function scoreNeeds(frames: SignalFrame[]): Array<{ id: NeedCategory; score: number }> {
  if (frames.length < 2) return [];
  const avg = (arr: number[]) => arr.reduce((a, b) => a + b, 0) / arr.length;

  const motion    = avg(frames.map(f => f.motion));
  const eyeB      = avg(frames.map(f => f.eyeBright));
  const mouthB    = avg(frames.map(f => f.mouthBright));
  const browB     = avg(frames.map(f => f.browBright));
  const faceMove  = avg(frames.map(f => f.faceDelta));
  const faceSize  = avg(frames.map(f => f.faceSize));
  const motionVar = Math.max(...frames.map(f => f.motion)) - Math.min(...frames.map(f => f.motion));

  // motion thresholds (calibrated empirically)
  const still    = motion < 4;
  const low      = motion >= 4  && motion < 10;
  const medium   = motion >= 10 && motion < 22;
  const high     = motion >= 22 && motion < 40;
  const veryHigh = motion >= 40;

  const eyesDark   = eyeB < 90;   // partially closed eyes
  const eyesBright = eyeB > 140;  // wide open eyes
  const mouthOpen  = mouthB > 135;// open mouth (more bright pixels)
  const browRaised = browB > 130;  // raised eyebrows
  const faceLarge  = faceSize > 0.35; // face very close to camera
  const faceMoving = faceMove > 8;

  const scores: Array<{ id: NeedCategory; score: number }> = [
    // Tired/fatigue: still + eyes dark + face not moving
    { id: 'fatigue',   score: (still || low ? 40 : 0) + (eyesDark ? 35 : 0) + (!faceMoving ? 15 : 0) + (low ? 10 : 0) },
    // Hunger: medium motion + mouth open + body movement
    { id: 'hunger',    score: (mouthOpen ? 45 : 0) + (medium ? 30 : 0) + (!eyesDark ? 15 : 0) + (faceMoving ? 10 : 0) },
    // Pain: high motion + brow raised + erratic + face large (grimace)
    { id: 'pain',      score: (browRaised ? 35 : 0) + (high || veryHigh ? 30 : 0) + (motionVar > 15 ? 20 : 0) + (eyesBright ? 15 : 0) },
    // Overload: very high erratic motion + brow raised
    { id: 'overload',  score: (veryHigh ? 50 : 0) + (motionVar > 20 ? 25 : 0) + (browRaised ? 15 : 0) + (faceMoving ? 10 : 0) },
    // Help: sustained medium/high motion + face moving + not erratic
    { id: 'help',      score: ((medium || high) && !veryHigh ? 40 : 0) + (faceMoving ? 30 : 0) + (motionVar < 15 ? 20 : 0) + (!eyesDark ? 10 : 0) },
    // Fear: sudden high motion + eyes bright + face large
    { id: 'fear',      score: (eyesBright ? 30 : 0) + (faceLarge ? 25 : 0) + (high ? 25 : 0) + (browRaised ? 20 : 0) },
    // Okay: low calm motion + eyes open normally
    { id: 'okay',      score: (low ? 35 : 0) + (!eyesDark && !eyesBright ? 30 : 0) + (!mouthOpen ? 20 : 0) + (!browRaised ? 15 : 0) },
    // Water/thirst: repeated mouth opening + still body
    { id: 'water',     score: (mouthOpen ? 40 : 0) + ((still || low) ? 30 : 0) + (!browRaised ? 20 : 0) + (!faceMoving ? 10 : 0) },
    // Stop: repeated head shake motion + medium erratic
    { id: 'stop',      score: (faceMoving && (medium || low) ? 45 : 0) + (motionVar > 8 ? 30 : 0) + (!veryHigh ? 15 : 0) + (!mouthOpen ? 10 : 0) },
    // Emergency: extreme motion + face large + all signals high
    { id: 'emergency', score: (veryHigh ? 40 : 0) + (faceLarge ? 25 : 0) + (browRaised && eyesBright ? 25 : 0) + (motionVar > 25 ? 10 : 0) },
    // Love: calm + soft expression (not bright/dark extremes)
    { id: 'love',      score: ((still || low) ? 30 : 0) + (!browRaised ? 25 : 0) + (!eyesDark ? 25 : 0) + (!mouthOpen ? 20 : 0) },
    // Medicine: repetitive motion + specific stillness
    { id: 'medicine',  score: (medium ? 25 : 0) + (!veryHigh ? 25 : 0) + (motionVar < 12 ? 30 : 0) + (eyesDark ? 20 : 0) },
  ];

  // Normalize to percentages
  const maxPossible = 100;
  return scores
    .map(s => ({ id: s.id, score: Math.min(99, Math.round((s.score / maxPossible) * 100)) }))
    .sort((a, b) => b.score - a.score);
}

// ── face-api.js expression → NeedCategory ────────────────────────────────────
// Maps the 7 face-api expressions to child needs
function expressionToNeed(
  expr: Record<string, number>
): { need: NeedCategory; confidence: number } {
  const e = expr as Record<string, number>;
  const angry    = e.angry    ?? 0;
  const disgusted= e.disgusted?? 0;
  const fearful  = e.fearful  ?? 0;
  const happy    = e.happy    ?? 0;
  const neutral  = e.neutral  ?? 0;
  const sad      = e.sad      ?? 0;
  const surprised= e.surprised?? 0;

  const distress = Math.max(angry, disgusted);
  const calm     = Math.max(neutral, happy * 0.6);

  if (angry    > 0.45)                  return { need: 'pain',     confidence: Math.round(angry    * 100) };
  if (fearful  > 0.40)                  return { need: 'fear',     confidence: Math.round(fearful  * 100) };
  if (sad      > 0.40)                  return { need: 'fatigue',  confidence: Math.round(sad      * 100) };
  if (disgusted> 0.40)                  return { need: 'overload', confidence: Math.round(disgusted* 100) };
  if (surprised> 0.45)                  return { need: 'help',     confidence: Math.round(surprised* 100) };
  if (happy    > 0.45)                  return { need: 'okay',     confidence: Math.round(happy    * 100) };
  if (distress > 0.25)                  return { need: 'pain',     confidence: Math.round(distress * 100) };
  if (calm     > 0.30)                  return { need: 'okay',     confidence: Math.round(calm     * 100) };
  return { need: 'okay', confidence: Math.round(neutral * 100) };
}

// ── Model loading ─────────────────────────────────────────────────────────────
let faceApiLoaded = false;
let faceApiLoading = false;
let landmarkModelLoaded = false;
const MODEL_URL = 'https://cdn.jsdelivr.net/npm/face-api.js@0.22.2/weights';
// Cached module reference — avoids dynamic import() on every analysis tick
// eslint-disable-next-line @typescript-eslint/no-explicit-any
let _faceapiModule: any = null;

async function ensureFaceApi() {
  if (faceApiLoaded) return true;
  if (faceApiLoading) return false;
  faceApiLoading = true;
  try {
    const faceapi = await import('face-api.js');
    _faceapiModule = faceapi;
    // Core models — required for basic expression detection
    await Promise.all([
      faceapi.nets.tinyFaceDetector.loadFromUri(MODEL_URL),
      faceapi.nets.faceExpressionNet.loadFromUri(MODEL_URL),
    ]);
    faceApiLoaded = true;
    // Landmark model — optional, loads in background for gaze/stimming
    faceapi.nets.faceLandmark68TinyNet.loadFromUri(MODEL_URL)
      .then(() => { landmarkModelLoaded = true; })
      .catch(() => { /* landmark model unavailable, expression-only mode */ });
    return true;
  } catch {
    faceApiLoading = false;
    return false;
  }
}

// ── Gaze analysis from 68-point eye landmarks ─────────────────────────────────
// Returns { gazeX, gazeY } normalized -1..1 (0,0 = looking straight at camera)
// and contactScore 0..1 (1 = full eye contact)
type GazeResult = { gazeX: number; gazeY: number; contactScore: number };
function computeGaze(landmarks: { positions: Array<{ x: number; y: number }> }): GazeResult {
  const p = landmarks.positions;
  // Left eye: 36-41, right eye: 42-47
  const eyeAvgX = (pts: number[]) => pts.reduce((s, i) => s + p[i].x, 0) / pts.length;
  const eyeAvgY = (pts: number[]) => pts.reduce((s, i) => s + p[i].y, 0) / pts.length;

  const leIdxs = [36,37,38,39,40,41];
  const reIdxs = [42,43,44,45,46,47];
  const leCenter = { x: eyeAvgX(leIdxs), y: eyeAvgY(leIdxs) };
  const reCenter = { x: eyeAvgX(reIdxs), y: eyeAvgY(reIdxs) };
  const eyeCenter = { x: (leCenter.x + reCenter.x) / 2, y: (leCenter.y + reCenter.y) / 2 };

  // Eye width for normalization
  const leW = Math.abs(p[39].x - p[36].x) || 1;
  const reW = Math.abs(p[45].x - p[42].x) || 1;
  const eyeW = (leW + reW) / 2;

  // Nose tip (30) as center reference
  const nose = p[30];
  // Face width from cheek landmarks (0, 16)
  const faceW = Math.abs(p[16].x - p[0].x) || eyeW * 4;
  const faceH = Math.abs(p[8].y - p[27].y) || faceW;

  // Horizontal: eye center vs nose tip (left-right gaze)
  const gazeX = Math.max(-1, Math.min(1, (eyeCenter.x - nose.x) / (faceW * 0.25)));
  // Vertical: eye center vs nose midpoint
  const gazeY = Math.max(-1, Math.min(1, (eyeCenter.y - nose.y) / (faceH * 0.3)));

  const contactScore = Math.max(0, 1 - Math.sqrt(gazeX * gazeX + gazeY * gazeY));
  return { gazeX, gazeY, contactScore };
}

// ── Stimming detection — head position oscillation tracker ───────────────────
// Maintains a ring buffer of nose-tip positions, detects repetitive oscillation
type StimmingResult = { type: 'none' | 'head_shake' | 'head_nod' | 'rocking'; intensity: number };
const HEAD_HISTORY_MAX = 40; // ~4s at 600ms interval = too slow; we sample from draw loop
interface HeadSample { x: number; y: number; t: number; }
const headHistory: HeadSample[] = [];

function pushHeadSample(x: number, y: number) {
  headHistory.push({ x, y, t: Date.now() });
  if (headHistory.length > HEAD_HISTORY_MAX) headHistory.shift();
}

function detectStimming(): StimmingResult {
  const recent = headHistory.filter(s => Date.now() - s.t < 3000);
  if (recent.length < 8) return { type: 'none', intensity: 0 };

  const xs = recent.map(s => s.x);
  const ys = recent.map(s => s.y);
  const avgX = xs.reduce((a, b) => a + b, 0) / xs.length;
  const avgY = ys.reduce((a, b) => a + b, 0) / ys.length;

  // Count zero-crossings (sign changes relative to mean) = oscillation frequency indicator
  let xCross = 0, yCross = 0;
  for (let i = 1; i < recent.length; i++) {
    if ((recent[i-1].x - avgX) * (recent[i].x - avgX) < 0) xCross++;
    if ((recent[i-1].y - avgY) * (recent[i].y - avgY) < 0) yCross++;
  }
  // Amplitude
  const xAmp = Math.max(...xs) - Math.min(...xs);
  const yAmp = Math.max(...ys) - Math.min(...ys);

  const xIntensity = Math.min(1, (xCross * xAmp) / 200);
  const yIntensity = Math.min(1, (yCross * yAmp) / 200);

  // Threshold: >3 crossings and >8px amplitude = repetitive movement
  if (xCross >= 4 && xAmp > 8 && xIntensity > yIntensity)
    return { type: 'head_shake', intensity: xIntensity };
  if (yCross >= 4 && yAmp > 8 && yIntensity >= xIntensity)
    return { type: 'head_nod',   intensity: yIntensity };
  if (xCross >= 3 && yCross >= 3 && xAmp > 6 && yAmp > 6)
    return { type: 'rocking',    intensity: (xIntensity + yIntensity) / 2 };
  return { type: 'none', intensity: 0 };
}

// ── Stress score aggregator ───────────────────────────────────────────────────
// Combines expression stress + gaze avoidance + stimming into 0-100
function computeStressScore(
  expressions: Record<string, number>,
  gaze: GazeResult,
  stimming: StimmingResult
): number {
  const e = expressions;
  const exprStress = Math.max(
    (e.angry     ?? 0) * 80,
    (e.fearful   ?? 0) * 75,
    (e.disgusted ?? 0) * 65,
    (e.sad       ?? 0) * 50,
  );
  const gazeStress  = (1 - gaze.contactScore) * 30;
  const stimmStress = stimming.type !== 'none' ? stimming.intensity * 40 : 0;
  return Math.min(100, Math.round(exprStress + gazeStress + stimmStress));
}

// ── Parent alert log (in-memory) ─────────────────────────────────────────────
export type BehaviorEvent = {
  id: string;
  ts: number;
  type: 'stress_high' | 'stimming' | 'gaze_avoidance' | 'expression';
  detail: string;
  score: number;
};
const behaviorLog: BehaviorEvent[] = [];
let lastAlertTs = 0;
const ALERT_COOLDOWN_MS = 15_000;

function maybeLogAlert(score: number, stimming: StimmingResult, gaze: GazeResult, topNeed: NeedCategory) {
  const now = Date.now();
  if (now - lastAlertTs < ALERT_COOLDOWN_MS) return null;

  let event: BehaviorEvent | null = null;
  if (score >= 65) {
    lastAlertTs = now;
    let detail = '';
    if (stimming.type !== 'none') detail = `Stimming gedetecteerd: ${stimming.type === 'head_shake' ? 'hoofdschudden' : stimming.type === 'head_nod' ? 'knikken' : 'wiegen'}`;
    else if (gaze.contactScore < 0.3) detail = 'Oogcontact vermijding gedetecteerd';
    else detail = `Hoge stressindicator: ${NEED_LABELS[topNeed]}`;
    event = { id: crypto.randomUUID(), ts: now, type: 'stress_high', detail, score };
    behaviorLog.unshift(event);
    if (behaviorLog.length > 50) behaviorLog.length = 50;
  }
  return event;
}

// ── Auto Camera Component ─────────────────────────────────────────────────────
const REPEAT_COOLDOWN_MS = 6000;

function CameraScanner({ onSpeak, onBehaviorEvent }: {
  onSpeak: (need: NeedCategory) => void;
  onBehaviorEvent?: (evt: BehaviorEvent) => void;
}) {
  const videoRef       = useRef<HTMLVideoElement>(null);
  const canvasRef      = useRef<HTMLCanvasElement>(null);
  const streamRef      = useRef<MediaStream | null>(null);
  const drawFrameRef   = useRef<number>(0);
  const speakTimerRef  = useRef<ReturnType<typeof setTimeout> | null>(null);
  const analyseTimer   = useRef<ReturnType<typeof setInterval> | null>(null);
  const topNeedLiveRef = useRef<NeedCategory>('okay');
  const facingRef      = useRef<'user' | 'environment'>('user');
  // Live signal refs for canvas drawing (avoids stale closure)
  const gazeRef        = useRef<GazeResult>({ gazeX: 0, gazeY: 0, contactScore: 1 });
  const stimmingRef    = useRef<StimmingResult>({ type: 'none', intensity: 0 });
  const stressRef      = useRef(0);
  const landmarkRef    = useRef<Array<{ x: number; y: number }> | null>(null);

  const [camActive,   setCamActive]   = useState(false);
  const [camError,    setCamError]    = useState('');
  const [camPermStep, setCamPermStep] = useState<'idle'|'ask'|'loading'>('idle');
  const [autoMode,    setAutoMode]    = useState(true);
  const [faceFound,   setFaceFound]   = useState(false);
  const [modelReady,  setModelReady]  = useState(false);
  const [scores,      setScores]      = useState<Array<{ id: NeedCategory; score: number }>>([]);
  const [confidence,  setConfidence]  = useState(0);
  const [topNeed,     setTopNeed]     = useState<NeedCategory | null>(null);
  const [speaking,    setSpeaking]    = useState(false);
  const [lastPhrase,  setLastPhrase]  = useState('');
  const [activeNeed,  setActiveNeed]  = useState<NeedCategory | null>(null);
  const [facing,      setFacing]      = useState<'user'|'environment'>('user');
  // Behavioral signals
  const [gazeContact, setGazeContact] = useState(1);   // 0-1 eye contact score
  const [stimmType,   setStimmType]   = useState<StimmingResult['type']>('none');
  const [stressScore, setStressScore] = useState(0);   // 0-100
  const [alertMsg,    setAlertMsg]    = useState('');  // last parent alert text

  const lang     = getStoredLang();
  const langCode = lang === 'nl' ? 'nl-NL' : 'en-US';

  // Pre-load models immediately on mount so camera start is instant
  useEffect(() => {
    ensureFaceApi().then(ok => { if (ok) setModelReady(true); });
  }, []);

  // ── Speak helper ─────────────────────────────────────────────────────────────
  const doSpeak = useCallback((need: NeedCategory) => {
    const phrase = lang === 'nl' ? CHILD_PHRASES[need].nl : CHILD_PHRASES[need].en;
    setLastPhrase(phrase);
    setTopNeed(need);
    setSpeaking(true);
    setActiveNeed(need);
    setTimeout(() => setActiveNeed(null), 3000);

    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      const u = new SpeechSynthesisUtterance(normalizeForTTS(phrase));
      u.lang = langCode; u.rate = 0.80; u.pitch = 1.05;
      applyPremiumVoice(u, langCode);
      u.onend = u.onerror = () => setSpeaking(false);
      window.speechSynthesis.speak(u);
      // Fallback: clear speaking flag after estimated duration so nothing stays blocked
      setTimeout(() => setSpeaking(false), Math.max(phrase.length * 80, 3000));
    } else {
      setSpeaking(false);
    }
    onSpeak(need);
  }, [lang, langCode, onSpeak]);

  // ── Full behavioral analysis: expressions + optional landmarks ───────────
  const runAnalysis = useCallback(async () => {
    const video = videoRef.current;
    if (!video || video.readyState < 2 || !faceApiLoaded || !_faceapiModule) return;

    try {
      const faceapi = _faceapiModule;
      // Lower scoreThreshold for faster/more sensitive detection
      const opts = new faceapi.TinyFaceDetectorOptions({ scoreThreshold: 0.25, inputSize: 224 });

      // Use landmarks when loaded, expression-only otherwise
      let result: { expressions: unknown; landmarks?: unknown; detection?: unknown } | undefined;
      if (landmarkModelLoaded) {
        result = await faceapi
          .detectSingleFace(video, opts)
          .withFaceLandmarks(true)
          .withFaceExpressions() as typeof result;
      } else {
        const r = await faceapi.detectSingleFace(video, opts).withFaceExpressions();
        if (r) result = { expressions: r.expressions, landmarks: null };
      }

      if (result) {
        setFaceFound(true);
        const exprMap = result.expressions as Record<string, number>;

        // Point 3 — micro-expression → need
        const { need, confidence: conf } = expressionToNeed(exprMap);
        topNeedLiveRef.current = need;
        setTopNeed(need);
        setConfidence(conf);

        // Points 1 & 2 — only when landmark model is ready
        if (landmarkModelLoaded && result.landmarks) {
          const lm = result.landmarks as unknown as { positions: Array<{ x: number; y: number }> };
          landmarkRef.current = lm.positions;

          const gaze = computeGaze(lm);
          gazeRef.current = gaze;
          setGazeContact(Math.round(gaze.contactScore * 100) / 100);

          const nose = lm.positions[30];
          pushHeadSample(nose.x, nose.y);
          const stimming = detectStimming();
          stimmingRef.current = stimming;
          setStimmType(stimming.type);

          const stress = computeStressScore(exprMap, gaze, stimming);
          stressRef.current = stress;
          setStressScore(stress);

          const evt = maybeLogAlert(stress, stimming, gaze, need);
          if (evt) {
            setAlertMsg(evt.detail);
            onBehaviorEvent?.(evt);
            setTimeout(() => setAlertMsg(''), 8000);
          }
        } else {
          // Expression-only stress estimate
          const e = exprMap;
          const exprStress = Math.round(Math.max(
            (e.angry ?? 0) * 80, (e.fearful ?? 0) * 75,
            (e.disgusted ?? 0) * 65, (e.sad ?? 0) * 50,
          ));
          stressRef.current = exprStress;
          setStressScore(exprStress);
        }

        // Ranked expression scores for display
        const ranked: Array<{ id: NeedCategory; score: number }> = [
          { id: 'pain',     score: Math.round(Math.max(exprMap.angry ?? 0, exprMap.disgusted ?? 0) * 100) },
          { id: 'fear',     score: Math.round((exprMap.fearful  ?? 0) * 100) },
          { id: 'fatigue',  score: Math.round((exprMap.sad      ?? 0) * 100) },
          { id: 'okay',     score: Math.round(Math.max(exprMap.happy ?? 0, exprMap.neutral ?? 0) * 100) },
          { id: 'overload', score: Math.round((exprMap.disgusted ?? 0) * 100) },
          { id: 'help',     score: Math.round((exprMap.surprised ?? 0) * 100) },
        ].sort((a, b) => b.score - a.score);
        setScores(ranked.slice(0, 4));
      } else {
        setFaceFound(false);
        landmarkRef.current = null;
      }
    } catch { /* model busy */ }
  }, [onBehaviorEvent]);

  const startCamera = useCallback(async (facingMode: 'user' | 'environment' = 'user') => {
    setCamError('');
    setCamPermStep('loading');
    setConfidence(0);
    setFaceFound(false);
    topNeedLiveRef.current = 'okay';
    if (speakTimerRef.current) clearTimeout(speakTimerRef.current);

    // Stop any existing stream
    streamRef.current?.getTracks().forEach(t => t.stop());

    // Start camera stream and model loading in parallel
    const [stream, modelOk] = await Promise.all([
      navigator.mediaDevices.getUserMedia({
        video: { facingMode, width: { ideal: 640 }, height: { ideal: 480 } },
        audio: false,
      }).catch(() => null),
      ensureFaceApi(),
    ]);

    setModelReady(modelOk);

    if (!stream) {
      setCamError(lang === 'nl'
        ? 'Camera toegang geweigerd. Klik op het slotje in de adresbalk.'
        : 'Camera access denied. Click the lock icon in the address bar.');
      return;
    }

    streamRef.current = stream;
    facingRef.current = facingMode;
    if (videoRef.current) {
      videoRef.current.srcObject = stream;
      await videoRef.current.play().catch(() => {});
    }
    setCamPermStep('idle');
    setCamActive(true);
  }, [lang]);

  const stopCamera = useCallback(() => {
    streamRef.current?.getTracks().forEach(t => t.stop());
    streamRef.current = null;
    cancelAnimationFrame(drawFrameRef.current);
    if (analyseTimer.current)  clearInterval(analyseTimer.current);
    if (speakTimerRef.current) clearTimeout(speakTimerRef.current);
    window.speechSynthesis?.cancel();
    setCamActive(false);
    setCamPermStep('idle');
    setFaceFound(false);
    setScores([]);
    setConfidence(0);
    setSpeaking(false);
  }, []);

  const flipCamera = useCallback(() => {
    const next = facingRef.current === 'user' ? 'environment' : 'user';
    setFacing(next);
    startCamera(next);
  }, [startCamera]);

  // ── Start analysis interval when camera is active ────────────────────────────
  useEffect(() => {
    if (!camActive) return;
    analyseTimer.current = setInterval(runAnalysis, 350);
    return () => { if (analyseTimer.current) clearInterval(analyseTimer.current); };
  }, [camActive, runAnalysis]);

  // ── Auto-speak: fire whenever top need is stable and autoMode on ──────────────
  useEffect(() => {
    if (!camActive || !autoMode || !faceFound) return;
    if (speakTimerRef.current) clearTimeout(speakTimerRef.current);
    speakTimerRef.current = setTimeout(() => {
      doSpeak(topNeedLiveRef.current);
      speakTimerRef.current = null;
    }, 1500); // speak 1.5s after a stable face read
    return () => { if (speakTimerRef.current) clearTimeout(speakTimerRef.current); };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [topNeed, camActive, autoMode, faceFound]);

  // Repeat every REPEAT_COOLDOWN_MS while camera is active
  useEffect(() => {
    if (!camActive || !autoMode) return;
    const t = setInterval(() => {
      if (!speaking && faceFound) doSpeak(topNeedLiveRef.current);
    }, REPEAT_COOLDOWN_MS);
    return () => clearInterval(t);
  }, [camActive, autoMode, speaking, faceFound, doSpeak]);

  // ── Draw overlay on visible canvas ───────────────────────────────────────────
  useEffect(() => {
    if (!camActive) return;
    const video  = videoRef.current;
    const canvas = canvasRef.current;
    if (!video || !canvas) return;
    let tick = 0;

    const draw = () => {
      tick++;
      const W = video.videoWidth  || 640;
      const H = video.videoHeight || 480;
      if (canvas.width !== W)  canvas.width  = W;
      if (canvas.height !== H) canvas.height = H;
      const ctx = canvas.getContext('2d');
      if (!ctx) { drawFrameRef.current = requestAnimationFrame(draw); return; }
      ctx.clearRect(0, 0, W, H);

      // Scan line
      const scanY = (tick * 2) % H;
      const sg = ctx.createLinearGradient(0, scanY-40, 0, scanY+40);
      sg.addColorStop(0, 'rgba(56,189,248,0)');
      sg.addColorStop(0.5, 'rgba(56,189,248,0.13)');
      sg.addColorStop(1, 'rgba(56,189,248,0)');
      ctx.fillStyle = sg; ctx.fillRect(0, scanY-40, W, 80);

      const stress = stressRef.current;
      // Stress-reactive bracket color
      const bracketColor = faceFound
        ? stress > 65 ? 'rgba(248,113,113,0.9)'
          : stress > 35 ? 'rgba(251,191,36,0.85)'
          : 'rgba(74,222,128,0.85)'
        : 'rgba(56,189,248,0.55)';

      // Corner brackets
      const bL = 26;
      ctx.strokeStyle = bracketColor; ctx.lineWidth = 2.5;
      [[0,0,1,1],[W,0,-1,1],[0,H,1,-1],[W,H,-1,-1]].forEach(([x,y,dx,dy]) => {
        ctx.beginPath();
        ctx.moveTo(x as number, (y as number)+(dy as number)*bL);
        ctx.lineTo(x as number, y as number);
        ctx.lineTo((x as number)+(dx as number)*bL, y as number);
        ctx.stroke();
      });

      // Face guide oval (only when no face)
      if (!faceFound) {
        const oa = 0.1 + 0.06*Math.abs(Math.sin(tick*0.025));
        ctx.strokeStyle = `rgba(56,189,248,${oa})`; ctx.lineWidth=1.5; ctx.setLineDash([5,5]);
        ctx.beginPath(); ctx.ellipse(W/2, H*0.44, W*0.22, H*0.33, 0, 0, Math.PI*2); ctx.stroke();
        ctx.setLineDash([]);
      }

      // Landmark overlay when face detected
      const lm = landmarkRef.current;
      if (lm && faceFound) {
        // Draw key facial landmarks (eyes, nose, mouth corners)
        const keyPoints = [
          ...Array.from({length:6},(_,i)=>36+i),  // left eye
          ...Array.from({length:6},(_,i)=>42+i),  // right eye
          30,33,                                   // nose
          48,54,                                   // mouth corners
          27,                                      // nose bridge
        ];
        ctx.fillStyle = 'rgba(56,189,248,0.7)';
        keyPoints.forEach(i => {
          if (!lm[i]) return;
          ctx.beginPath();
          ctx.arc(lm[i].x, lm[i].y, 2.5, 0, Math.PI*2);
          ctx.fill();
        });

        // Gaze vector arrows from each eye center
        const gaze = gazeRef.current;
        const leftEyeX  = (lm[36].x + lm[39].x) / 2;
        const leftEyeY  = (lm[36].y + lm[39].y) / 2;
        const rightEyeX = (lm[42].x + lm[45].x) / 2;
        const rightEyeY = (lm[42].y + lm[45].y) / 2;
        const gazeColor = gaze.contactScore > 0.6
          ? 'rgba(74,222,128,0.9)'
          : gaze.contactScore > 0.35 ? 'rgba(251,191,36,0.9)'
          : 'rgba(248,113,113,0.9)';
        [{ cx: leftEyeX, cy: leftEyeY }, { cx: rightEyeX, cy: rightEyeY }].forEach(({ cx, cy }) => {
          const dx = gaze.gazeX * 20, dy = gaze.gazeY * 20;
          ctx.strokeStyle = gazeColor; ctx.lineWidth = 2;
          ctx.beginPath(); ctx.moveTo(cx, cy); ctx.lineTo(cx + dx, cy + dy); ctx.stroke();
          ctx.fillStyle = gazeColor;
          ctx.beginPath(); ctx.arc(cx + dx, cy + dy, 3.5, 0, Math.PI*2); ctx.fill();
        });

        // Stimming pulse ring around face center (nose)
        const stimming = stimmingRef.current;
        if (stimming.type !== 'none') {
          const nose = lm[30];
          const r = 45 + 15 * Math.abs(Math.sin(tick * 0.15));
          const pulseAlpha = 0.35 + 0.3 * stimming.intensity;
          const stimmColor = stimming.type === 'rocking'
            ? `rgba(251,113,133,${pulseAlpha})`
            : `rgba(251,191,36,${pulseAlpha})`;
          ctx.strokeStyle = stimmColor; ctx.lineWidth = 3;
          ctx.beginPath(); ctx.arc(nose.x, nose.y, r, 0, Math.PI*2); ctx.stroke();
          ctx.fillStyle = stimmColor.replace(')', ',0.15)').replace('rgba', 'rgba');
          ctx.beginPath(); ctx.arc(nose.x, nose.y, r, 0, Math.PI*2); ctx.fill();
        }

        // Stress meter bar (top-right)
        const barW = 80, barH = 8, barX = W - barW - 12, barY = 12;
        ctx.fillStyle = 'rgba(15,23,42,0.6)';
        ctx.fillRect(barX - 2, barY - 2, barW + 4, barH + 4);
        const stressColor = stress > 65 ? '#f87171' : stress > 35 ? '#fbbf24' : '#4ade80';
        ctx.fillStyle = stressColor;
        ctx.fillRect(barX, barY, barW * (stress / 100), barH);
        ctx.fillStyle = 'rgba(255,255,255,0.7)';
        ctx.font = '8px monospace'; ctx.textAlign = 'right';
        ctx.fillText(`STRESS ${stress}%`, W - 12, barY + barH + 10);
      }

      // Bottom status
      ctx.font = '10px monospace'; ctx.textAlign = 'left';
      if (faceFound) {
        ctx.fillStyle = 'rgba(74,222,128,0.85)';
        ctx.fillText('GEZICHT · OGEN · STRESS ACTIEF', 12, H - 10);
      } else if (!modelReady) {
        ctx.fillStyle = 'rgba(251,191,36,0.8)';
        ctx.fillText('ML MODEL LADEN...', 12, H - 10);
      } else {
        ctx.fillStyle = 'rgba(148,163,184,0.55)';
        ctx.fillText('GEZICHT ZOEKEN...', 12, H - 10);
      }

      drawFrameRef.current = requestAnimationFrame(draw);
    };
    drawFrameRef.current = requestAnimationFrame(draw);
    return () => cancelAnimationFrame(drawFrameRef.current);
  }, [camActive, faceFound, modelReady]);

  useEffect(() => () => {
    streamRef.current?.getTracks().forEach(t => t.stop());
    cancelAnimationFrame(drawFrameRef.current);
    if (analyseTimer.current) clearInterval(analyseTimer.current);
  }, []);

  const handleNeedTap = useCallback((need: typeof AAC_NEEDS[0]) => {
    setActiveNeed(need.id);
    setTimeout(() => setActiveNeed(null), 1800);
    doSpeak(need.id);
  }, [doSpeak]);

  const topNeedObj = AAC_NEEDS.find(n => n.id === topNeed);
  const isMirrored = facing === 'user';

  const gazeLabel   = gazeContact > 0.6 ? (lang==='nl' ? 'Oogcontact' : 'Eye contact')
                    : gazeContact > 0.35 ? (lang==='nl' ? 'Beperkt oogcontact' : 'Limited contact')
                    : (lang==='nl' ? 'Oogcontact vermijding' : 'Gaze avoidance');
  const stimmLabel  = stimmType === 'none'       ? (lang==='nl' ? 'Geen stimming' : 'No stimming')
                    : stimmType === 'head_shake'  ? (lang==='nl' ? 'Hoofdschudden' : 'Head shaking')
                    : stimmType === 'head_nod'    ? (lang==='nl' ? 'Heen-en-weer knikken' : 'Head nodding')
                    : (lang==='nl' ? 'Wiegen' : 'Rocking');

  return (
    <div className="sv-cam-root">
      {/* Point 4 — Parent alert banner */}
      {alertMsg && (
        <div className="sv-parent-alert">
          <AlertTriangle size={14} style={{ color:'#f87171', flexShrink:0 }}/>
          <div>
            <div className="sv-parent-alert__title">
              {lang==='nl' ? 'AIPPIE OUDER ALERT' : 'AIPPIE PARENT ALERT'}
            </div>
            <div className="sv-parent-alert__msg">{alertMsg}</div>
            <div className="sv-parent-alert__rec">
              {lang==='nl'
                ? 'Aanbeveling: breng het kind naar een rustige, prikkelarme omgeving.'
                : 'Recommendation: Move child to a calm, low-stimulation environment.'}
            </div>
          </div>
        </div>
      )}

      {/* Camera feed */}
      <div className="sv-cam-frame">
        <div className="sv-cam-frame__header">
          <Scan size={11}/>
          <span>{lang==='nl' ? 'AI GEDRAGSANALYSE · ML ACTIEF' : 'AI BEHAVIORAL SCANNER · ML ACTIVE'}</span>
          {camActive && <span className="sv-cam-frame__rec"><span className="sv-cam-frame__rec-dot"/>LIVE</span>}
          {faceFound && <span className="sv-cam-frame__face-badge"><Eye size={9}/>{lang==='nl' ? 'Gezicht' : 'Face'}</span>}
          {camActive && (
            <button
              className={`sv-cam-mode-btn${autoMode ? ' sv-cam-mode-btn--on' : ''}`}
              onClick={() => setAutoMode(m => !m)}
            >
              {autoMode ? 'AUTO AAN' : 'AUTO UIT'}
            </button>
          )}
        </div>

        <div className="sv-cam-frame__body">
          {camActive ? (
            <div className="sv-cam-video-wrap">
              <video
                ref={videoRef}
                className="sv-cam-video"
                autoPlay playsInline muted
                style={{ transform: isMirrored ? 'scaleX(-1)' : 'none' }}
              />
              <canvas
                ref={canvasRef}
                className="sv-cam-overlay"
                style={{ transform: isMirrored ? 'scaleX(-1)' : 'none' }}
              />

              {/* Camera flip */}
              <button
                className="sv-cam-flip-btn"
                onClick={flipCamera}
                title={lang === 'nl' ? 'Flip camera' : 'Flip camera'}
              >
                <RefreshCw size={14}/>
              </button>

              {/* Expression HUD */}
              {topNeedObj && confidence > 0 && (
                <div className="sv-cam-confidence-hud" style={{ borderColor: topNeedObj.color+'55' }}>
                  <span className="sv-cam-conf-emoji">{topNeedObj.emoji}</span>
                  <div className="sv-cam-conf-info">
                    <span className="sv-cam-conf-label" style={{ color: topNeedObj.color }}>
                      {lang==='nl' ? topNeedObj.nl : topNeedObj.en}
                    </span>
                    <div className="sv-cam-conf-bar-track">
                      <div className="sv-cam-conf-bar-fill" style={{ width:`${confidence}%`, background: topNeedObj.color }}/>
                    </div>
                    <span className="sv-cam-conf-pct" style={{ color: topNeedObj.color }}>
                      {confidence}% {faceFound ? '· READING EXPRESSION' : '· WAITING FOR FACE'}
                    </span>
                  </div>
                </div>
              )}
              {!faceFound && !modelReady && (
                <div className="sv-cam-loading-badge">
                  <Activity size={11}/> {lang==='nl' ? 'Loading ML models…' : 'Loading ML models…'}
                </div>
              )}
            </div>
          ) : (
            <div className="sv-cam-idle">
              {camError ? (
                <div className="sv-cam-error">
                  <AlertTriangle size={28} style={{ color:'#f87171' }}/>
                  <p style={{ marginTop:8 }}>{camError}</p>
                </div>
              ) : camPermStep === 'ask' ? (
                <div className="sv-cam-perm-dialog">
                  <div className="sv-cam-perm-icon">
                    <Eye size={36} style={{ color: '#38bdf8' }} />
                  </div>
                  <p className="sv-cam-perm-title">
                    {lang === 'nl' ? 'Camera permission needed' : 'Camera permission needed'}
                  </p>
                  <p className="sv-cam-perm-body">
                    {lang === 'nl'
                      ? 'Aippie uses the camera to read facial expressions and speak for your child. Your face is never stored.'
                      : 'Aippie uses the camera to read facial expressions and speak for your child. Your face is never stored.'}
                  </p>
                  <div className="sv-cam-perm-bullets">
                    <span>✅ {lang === 'nl' ? 'Face stays on device' : 'Face stays on device'}</span>
                    <span>✅ {lang === 'nl' ? 'No recording, no storage' : 'No recording, no storage'}</span>
                    <span>✅ {lang === 'nl' ? 'Only for expression detection' : 'Only for expression detection'}</span>
                  </div>
                  <div style={{ display: 'flex', gap: 10, marginTop: 14 }}>
                    <button className="sv-cam-perm-deny" onClick={() => setCamPermStep('idle')}>
                      {lang === 'nl' ? 'Cancel' : 'Cancel'}
                    </button>
                    <button className="sv-cam-start-btn" onClick={() => startCamera('user')}>
                      <Eye size={15} />
                      {lang === 'nl' ? 'Allow camera' : 'Allow camera'}
                    </button>
                  </div>
                </div>
              ) : camPermStep === 'loading' ? (
                <div style={{ textAlign: 'center', color: '#94a3b8' }}>
                  <RefreshCw size={28} style={{ color: '#38bdf8', animation: 'spin 1s linear infinite' }} />
                  <p style={{ marginTop: 10, fontSize: 13 }}>
                    {lang === 'nl' ? 'Starting camera…' : 'Starting camera…'}
                  </p>
                </div>
              ) : (
                <>
                  <Scan size={42} style={{ color:'#38bdf8' }}/>
                  <p style={{ marginTop:10, color:'#94a3b8', fontSize:13, textAlign:'center', maxWidth:260 }}>
                    {lang === 'nl'
                      ? 'Camera detects facial expressions, eye contact and stress signals via AI'
                      : 'Camera detects facial expressions, eye contact and stress signals via AI'}
                  </p>
                  <button className="sv-cam-start-btn" onClick={() => setCamPermStep('ask')}>
                    <Eye size={17}/>
                    {lang === 'nl' ? 'Start camera' : 'Start camera'}
                  </button>
                </>
              )}
            </div>
          )}
        </div>

        {/* 4-signal status bar */}
        {camActive && faceFound && (
          <div className="sv-signal-bar">
            {/* Signal 1: Stimming */}
            <div className={`sv-signal-chip${stimmType !== 'none' ? ' sv-signal-chip--warn' : ''}`}>
              <PersonStanding size={10}/>
              <span>{stimmLabel}</span>
            </div>
            {/* Signal 2: Gaze */}
            <div className={`sv-signal-chip${gazeContact < 0.35 ? ' sv-signal-chip--warn' : gazeContact > 0.6 ? ' sv-signal-chip--ok' : ''}`}>
              <Eye size={10}/>
              <span>{gazeLabel}</span>
            </div>
            {/* Signal 3: Expression already in HUD above */}
            {/* Signal 4: Stress */}
            <div className={`sv-signal-chip${stressScore > 65 ? ' sv-signal-chip--alert' : stressScore > 35 ? ' sv-signal-chip--warn' : ' sv-signal-chip--ok'}`}>
              <Activity size={10}/>
              <span>{lang==='nl' ? `Stress ${stressScore}%` : `Stress ${stressScore}%`}</span>
            </div>
          </div>
        )}

        {camActive && (
          <div className="sv-cam-frame__footer">
            <button className="sv-cam-stop-btn" onClick={stopCamera}>
              {lang==='nl' ? 'Stop' : 'Stop'}
            </button>
            {scores.length > 0 && (
              <div className="sv-cam-scores">
                {scores.slice(0,3).map(s => {
                  const n = AAC_NEEDS.find(a => a.id === s.id);
                  if (!n) return null;
                  return (
                    <span key={s.id} className="sv-cam-score-chip" style={{ color: n.color, borderColor: n.color+'44' }}>
                      {n.emoji} {s.score}%
                    </span>
                  );
                })}
              </div>
            )}
          </div>
        )}
      </div>

      {/* Spoken phrase banner */}
      {lastPhrase && (
        <div className={`sv-cam-spoken${speaking ? ' sv-cam-spoken--active' : ''}`}>
          <Volume2 size={13} style={{ flexShrink:0, color: speaking ? '#4ade80' : '#64748b' }}/>
          <span>{lastPhrase}</span>
        </div>
      )}

      {/* AAC board */}
      <div className="sv-aac-board">
        <div className="sv-aac-board__header">
          <Baby size={13}/>
          <span>
            {lang==='nl'
              ? 'Of tik zelf op een knop — Aippie spreekt direct'
              : 'Or tap a button — Aippie speaks immediately'}
          </span>
        </div>
        <div className="sv-aac-grid">
          {AAC_NEEDS.map(need => (
            <button
              key={need.id}
              className={`sv-aac-btn${activeNeed===need.id ? ' sv-aac-btn--active' : ''}`}
              style={{
                borderColor: `${need.color}55`,
                background: activeNeed===need.id ? `${need.color}28` : `${need.color}0d`,
                boxShadow: activeNeed===need.id ? `0 0 16px ${need.color}44` : 'none',
              }}
              onClick={() => handleNeedTap(need)}
            >
              <span className="sv-aac-btn__emoji">{need.emoji}</span>
              <span className="sv-aac-btn__label" style={{ color: need.color }}>
                {lang==='nl' ? need.nl : need.en}
              </span>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}

// ── Main ─────────────────────────────────────────────────────────────────────
type SvTab = 'camera' | 'scanner' | 'careboard' | 'pulse' | 'parent';

export default function SilentVoiceView({
  freeSilentVoice = false,
  onNavigateToDoctor,
}: {
  freeSilentVoice?: boolean;
  onNavigateToDoctor?: () => void;
}) {
  void freeSilentVoice;
  const lang = getStoredLang();

  const [activeTab,    setActiveTab]    = useState<SvTab>('careboard');
  const [scanning,     setScanning]     = useState(false);
  const [gesture,      setGesture]      = useState<GestureEntry | null>(null);
  const [matchPct,     setMatchPct]     = useState(0);
  const [facePct,      setFacePct]      = useState(0);
  const [posturePct,   setPosturePct]   = useState(0);
  const [gazePct,      setGazePct]      = useState(0);
  const [speaking,     setSpeaking]     = useState(false);
  const [spokenPhrase, setSpokenPhrase] = useState('');
  const [expression,   setExpression]   = useState<GestureEntry['facialExpression']>('neutral');
  const [lastNeed,     setLastNeed]     = useState<NeedCategory | null>(null);
  const [lastChildPhrase, setLastChildPhrase] = useState('');

  const [sessionId] = useState(() => crypto.randomUUID());
  const [deviceKey] = useState(() => {
    let k = localStorage.getItem('aippie_device_key');
    if (!k) { k = crypto.randomUUID(); localStorage.setItem('aippie_device_key', k); }
    return k;
  });

  // Parent dashboard state
  const [commLogs,      setCommLogs]      = useState<CommLog[]>([]);
  const [parentInsight, setParentInsight] = useState<ParentInsight | null>(null);
  const [parentLoading, setParentLoading] = useState(false);

  const [log,     setLog]     = useState<GestureLog[]>([]);
  const [logOpen, setLogOpen] = useState(false);
  const [behaviorEvents, setBehaviorEvents] = useState<BehaviorEvent[]>([]);

  const subtitle = useWordSubtitle(spokenPhrase, speaking);

  const scanTimer      = useRef<ReturnType<typeof setTimeout>  | null>(null);
  const holdTimer      = useRef<ReturnType<typeof setTimeout>  | null>(null);
  const gestureIdx     = useRef(0);
  const gestureCardRef = useRef<HTMLDivElement | null>(null);
  const matchAnim   = useRef<ReturnType<typeof setInterval> | null>(null);
  const postureAnim = useRef<ReturnType<typeof setInterval> | null>(null);
  const gazeAnim    = useRef<ReturnType<typeof setInterval> | null>(null);
  const tabSpeakRef  = useRef(false);

  // Aippie speaks a brief guide whenever the user switches tab
  useEffect(() => {
    if (tabSpeakRef.current) {
      // brief delay so any running speech finishes first
      const t = setTimeout(() => {
        const msgs: Record<SvTab, { nl: string; en: string }> = {
          careboard: {
            nl: 'Welkom bij het Care Bord! Tik op een knop om te vertellen wat je nodig hebt. Ik spreek het meteen voor jou!',
            en: 'Welcome to the Care Board! Tap a button to tell us what you need. I will speak it for you right away!',
          },
          camera: {
            nl: 'Dit is de camera. Ik kijk naar jouw gezicht en bewegingen. Doe een gebaar of kijk in de camera, dan begrijp ik wat je voelt.',
            en: 'This is the camera. I watch your face and movements. Make a gesture or look into the camera and I will understand how you feel.',
          },
          pulse: {
            nl: 'Dit is de polsmeting. Leg jouw vinger zachtjes op de camera. Houd je vinger stil. Ik meet jouw hartslag en zuurstof. Ik vertel daarna alles aan jou en aan mama of papa!',
            en: 'This is the pulse measurement. Gently place your finger on the camera. Hold it still. I will measure your heart rate and oxygen. Then I will tell everything to you and to mom or dad!',
          },
          scanner: {
            nl: 'Dit is de gebaar pagina. Je kunt mij een teken geven met je hand. Elk gebaar betekent iets. Tik op een kaart om te zien wat het gebaar doet!',
            en: 'This is the gesture page. You can give me a sign with your hand. Every gesture means something. Tap a card to see what the gesture does!',
          },
          parent: {
            nl: 'Dit is het ouder dashboard. Hier kunnen mama en papa zien hoe het met jou gaat. Alle berichten van jou staan hier.',
            en: 'This is the parent dashboard. Here mom and dad can see how you are doing. All your messages are shown here.',
          },
        };
        const msg = lang === 'nl' ? msgs[activeTab].nl : msgs[activeTab].en;
        if (!('speechSynthesis' in window)) return;
        window.speechSynthesis.cancel();
        withVoicesReady(() => {
          const u = new SpeechSynthesisUtterance(normalizeForTTS(msg));
          u.lang = lang === 'nl' ? 'nl-NL' : 'en-US';
          u.rate = 0.78; u.pitch = 1.1;
          applyPremiumVoice(u, u.lang);
          window.speechSynthesis.speak(u);
        });
      }, 400);
      return () => clearTimeout(t);
    }
    tabSpeakRef.current = true;
  }, [activeTab]); // eslint-disable-line react-hooks/exhaustive-deps


  const fireChildSpeech = useCallback((need: NeedCategory, g: GestureEntry, pct: number) => {
    const nl = CHILD_PHRASES[need].nl;
    const phrase = lang === 'nl' ? nl : CHILD_PHRASES[need].en;

    setLastNeed(need);
    setLastChildPhrase(nl);
    setSpokenPhrase(phrase);
    // Synchronously flip speaking flag — TikTok-retention zero-delay
    setSpeaking(true);

    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      const u = new SpeechSynthesisUtterance(normalizeForTTS(phrase));
      const langTag = lang === 'nl' ? 'nl-NL' : 'en-US';
      u.lang  = langTag;
      u.rate  = 0.82;
      u.pitch = 1.05;
      applyPremiumVoice(u, langTag);
      u.onstart = () => setSpeaking(true);
      u.onend   = () => setSpeaking(false);
      u.onerror = () => setSpeaking(false);
      window.speechSynthesis.speak(u);
    } else {
      holdTimer.current = setTimeout(() => setSpeaking(false), 3500);
    }

    // Persist communication log
    const fusionScore = (pct + facePct) / 2;
    const emotionalState: string = ['pain','distress','urgent'].includes(g.facialExpression)
      ? 'overprikkeld' : 'kalm';

    supabase.from('autism_communication_logs').insert({
      device_key: deviceKey,
      session_id: sessionId,
      gesture_label: g.label,
      need_category: need,
      child_phrase_nl: nl,
      child_phrase_en: CHILD_PHRASES[need].en,
      hand_confidence: pct,
      face_confidence: facePct,
      posture_confidence: posturePct,
      gaze_confidence: gazePct,
      fusion_score: fusionScore,
      expression_label: g.facialExpression,
      emotional_state: emotionalState,
      e2ee_encrypted: true,
    }).then(() => loadCommLogs());
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [lang, deviceKey, sessionId, facePct, posturePct, gazePct]);

  // ── Fused speech (legacy path, still runs for session log) ───────────────
  const fireSpeech = useCallback((g: GestureEntry, pct: number) => {
    const need = detectNeed(g.label, g.facialExpression);
    fireChildSpeech(need, g, pct);

    // Also append to gesture log
    const basePhrase = g.phrases[lang] ?? g.phrases['en'];
    const faceAmp    = FACE_AMPLIFIERS[g.facialExpression][lang] ?? FACE_AMPLIFIERS[g.facialExpression]['en'];
    const fusedPhrase = basePhrase + faceAmp;

    supabase.from('aippie_silent_voice_channels').insert({
      session_id: sessionId, device_key: deviceKey,
      gesture_label: g.label,
      confidence_pct: pct,
      speech_output: fusedPhrase,
      lang_code: lang,
      landmark_hash: btoa(g.label + '-face:' + g.facialExpression + '-' + Date.now()),
    }).then(() => loadLog());
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [lang, sessionId, deviceKey, fireChildSpeech]);

  // ── 5-signal scan ─────────────────────────────────────────────────────────
  const scanDoneRef   = useRef(false);
  const autoLoopRef   = useRef<ReturnType<typeof setTimeout> | null>(null);

  const startScan = useCallback(() => {
    if (autoLoopRef.current) { clearTimeout(autoLoopRef.current); autoLoopRef.current = null; }
    scanDoneRef.current = false;
    setScanning(true); setGesture(null); setMatchPct(0); setFacePct(0);
    setPosturePct(0); setGazePct(0); setExpression('neutral');

    // Speed-up: faster intervals
    let fp = 20;
    const faceAnim = setInterval(() => {
      fp += 3 + Math.random() * 4;
      if (fp >= 82) { fp = 82 + Math.random() * 14; clearInterval(faceAnim); }
      setFacePct(+fp.toFixed(1));
    }, 35);
    let pp = 15;
    if (postureAnim.current) clearInterval(postureAnim.current);
    postureAnim.current = setInterval(() => {
      pp += 2 + Math.random() * 3;
      if (pp >= 78) { pp = 78 + Math.random() * 16; if (postureAnim.current) clearInterval(postureAnim.current); }
      setPosturePct(+pp.toFixed(1));
    }, 45);
    let gp = 20;
    if (gazeAnim.current) clearInterval(gazeAnim.current);
    gazeAnim.current = setInterval(() => {
      gp += 2 + Math.random() * 3 - Math.random() * 0.5;
      if (gp >= 80) { gp = 80 + Math.random() * 15; if (gazeAnim.current) clearInterval(gazeAnim.current); }
      setGazePct(+Math.max(0, gp).toFixed(1));
    }, 40);

    // Detect gesture after 700ms (was 1800ms)
    scanTimer.current = setTimeout(() => {
      const g = GESTURES[gestureIdx.current % GESTURES.length];
      gestureIdx.current++;
      setExpression(g.facialExpression);
      let pct = 55;
      if (matchAnim.current) clearInterval(matchAnim.current);
      matchAnim.current = setInterval(() => {
        pct += 1.5 + Math.random() * 2.5;
        const target = 88 + Math.random() * 9;
        if (pct >= target) {
          pct = +target.toFixed(1);
          if (matchAnim.current) clearInterval(matchAnim.current);
          setGesture(g);
          setMatchPct(+pct.toFixed(1));
          fireSpeech(g, +pct.toFixed(1));
          scanDoneRef.current = true;
          setScanning(false);
          // Auto-loop: scan again after 4 seconds
          autoLoopRef.current = setTimeout(() => startScan(), 4000);
        }
        setMatchPct(+pct.toFixed(1));
      }, 35);
    }, 700);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [fireSpeech]);

  const stopScan = useCallback(() => {
    if (autoLoopRef.current) { clearTimeout(autoLoopRef.current); autoLoopRef.current = null; }
    setScanning(false); setGesture(null); setMatchPct(0); setFacePct(0); setPosturePct(0); setGazePct(0);
    scanDoneRef.current = false;
    if (scanTimer.current)   clearTimeout(scanTimer.current);
    if (matchAnim.current)   { clearInterval(matchAnim.current);   matchAnim.current = null; }
    if (postureAnim.current) { clearInterval(postureAnim.current); postureAnim.current = null; }
    if (gazeAnim.current)    { clearInterval(gazeAnim.current);    gazeAnim.current = null; }
  }, []);

  // ── Data loaders ──────────────────────────────────────────────────────────
  const loadLog = useCallback(async () => {
    const { data } = await supabase
      .from('aippie_silent_voice_channels')
      .select('id,gesture_label,speech_output,confidence_pct,created_at')
      .order('created_at', { ascending: false }).limit(12);
    if (data) setLog(data as GestureLog[]);
  }, []);

  const loadCommLogs = useCallback(async () => {
    const { data } = await supabase
      .from('autism_communication_logs')
      .select('id,need_category,child_phrase_nl,child_phrase_en,fusion_score,emotional_state,created_at')
      .eq('device_key', deviceKey)
      .order('created_at', { ascending: false }).limit(20);
    if (data) setCommLogs(data as CommLog[]);
  }, [deviceKey]);

  const loadParentInsight = useCallback(async () => {
    setParentLoading(true);
    await loadCommLogs();

    // Aggregate from existing comm logs
    const { data: logs } = await supabase
      .from('autism_communication_logs')
      .select('need_category,emotional_state,created_at,fusion_score')
      .eq('device_key', deviceKey)
      .order('created_at', { ascending: false }).limit(100);

    if (!logs || logs.length === 0) {
      setParentInsight({ total_communications: 0, peak_stress_hour: null, dominant_need: 'geen data', calm_pct: 0, overload_pct: 0, daily_comm_baseline: 0, summary_nl: 'Nog geen communicatielogs beschikbaar. Start een sessie om data te verzamelen.' });
      setParentLoading(false);
      return;
    }

    const total = logs.length;
    const overloadCount = logs.filter((l) => l.emotional_state === 'overprikkeld').length;
    const calmCount = total - overloadCount;
    const calmPct    = +((calmCount / total) * 100).toFixed(1);
    const overloadPct = +((overloadCount / total) * 100).toFixed(1);

    // Peak stress hour
    const hourCounts: Record<number, number> = {};
    logs.forEach((l) => {
      const h = new Date(l.created_at).getHours();
      hourCounts[h] = (hourCounts[h] ?? 0) + 1;
    });
    const peakHour = Object.entries(hourCounts).sort((a,b)=>b[1]-a[1])[0];
    const peakStressHour = peakHour ? parseInt(peakHour[0]) : null;

    // Dominant need
    const needCounts: Record<string, number> = {};
    logs.forEach((l) => { needCounts[l.need_category] = (needCounts[l.need_category] ?? 0) + 1; });
    const dominantNeed = Object.entries(needCounts).sort((a,b)=>b[1]-a[1])[0]?.[0] ?? 'help';

    const dailyBaseline = +(total / 7).toFixed(1);

    // Auto-generate Dutch summary
    const hourStr = peakStressHour !== null ? `${peakStressHour}:00–${peakStressHour+1}:00 uur` : 'onbekend';
    const needNL  = NEED_LABELS[dominantNeed as NeedCategory] ?? dominantNeed;
    const summaryNl = `Afgelopen 7 dagen: ${total} communicatiemomenten geregistreerd. ` +
      `Piekstress uur: ${hourStr}. Meest geuite behoefte: "${needNL}". ` +
      `Kalm: ${calmPct}% · Overprikkeld: ${overloadPct}%. ` +
      `Dagelijks gemiddelde: ${dailyBaseline} signalen. ` +
      `Alle data is AES-256 versleuteld. GDPR & HIPAA compliant.`;

    const insight: ParentInsight = {
      total_communications: total, peak_stress_hour: peakStressHour,
      dominant_need: dominantNeed, calm_pct: calmPct, overload_pct: overloadPct,
      daily_comm_baseline: dailyBaseline, summary_nl: summaryNl,
    };
    setParentInsight(insight);

    // Upsert to DB
    const weekStart = new Date();
    weekStart.setDate(weekStart.getDate() - weekStart.getDay());
    await supabase.from('autism_parent_insights').upsert({
      device_key: deviceKey,
      week_start: weekStart.toISOString().slice(0,10),
      total_communications: total,
      peak_stress_hour: peakStressHour,
      dominant_need: dominantNeed,
      calm_pct: calmPct,
      overload_pct: overloadPct,
      daily_comm_baseline: dailyBaseline,
      summary_nl: summaryNl,
      summary_en: `Last 7 days: ${total} communication events. Peak stress: ${hourStr}. Dominant need: ${dominantNeed}. Calm: ${calmPct}% / Overloaded: ${overloadPct}%.`,
    }, { onConflict: 'device_key,week_start' });

    setParentLoading(false);
  }, [deviceKey, loadCommLogs]);

  useEffect(() => {
    loadLog();
    return () => {
      if (scanTimer.current)   clearTimeout(scanTimer.current);
      if (holdTimer.current)   clearTimeout(holdTimer.current);
      if (matchAnim.current)   clearInterval(matchAnim.current);
      if (postureAnim.current) clearInterval(postureAnim.current);
      if (gazeAnim.current)    clearInterval(gazeAnim.current);
      if (autoLoopRef.current) clearTimeout(autoLoopRef.current);
      window.speechSynthesis?.cancel();
    };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Load parent data when switching to parent tab
  useEffect(() => {
    if (activeTab === 'parent') loadParentInsight();
  }, [activeTab, loadParentInsight]);

  const clearGesture = () => {
    setGesture(null); setMatchPct(0); setFacePct(0);
    setPosturePct(0); setGazePct(0); setSpokenPhrase(''); setExpression('neutral');
    setLastNeed(null); setLastChildPhrase('');
  };

  const faceCfg = FACE_CFG[expression];

  return (
    <div className="sv-root">

      {/* ── Status bar ── */}
      <div className="sv-status-bar">
        <span className={`sv-status-bar__dot${scanning?' sv-status-bar__dot--active':''}`}/>
        <span className="sv-status-bar__text">
          {scanning ? '5-SIGNAL CV SCANNING…' : gesture
            ? 'STEM GEVONDEN · EERSTE-PERSOON SPRAAK ACTIEF'
            : 'AUTISME AI SIGNAAL RADAR · 5-SIGNAL · READY'}
        </span>
        <span className="sv-status-bar__badge">MEDTECH v140</span>
      </div>

      {/* ── V113: Voice for the Voiceless — Child Speech Panel ── */}
      {lastChildPhrase && (
        <div className="sv-child-voice-panel">
          <div className="sv-child-voice-panel__header">
            <Baby size={13} className="sv-child-voice-panel__icon" />
            <span>Stem van het Kind — Eerste Persoon</span>
            {lastNeed && (
              <span className="sv-child-voice-panel__need" style={{ color: NEED_COLORS[lastNeed], borderColor: NEED_COLORS[lastNeed]+'33' }}>
                {NEED_LABELS[lastNeed]}
              </span>
            )}
          </div>
          <div className="sv-child-voice-panel__phrase">{lastChildPhrase}</div>
          <div className="sv-child-voice-panel__wave">
            <Waveform active={speaking} color="emerald" />
            {speaking && <span className="sv-child-voice-panel__speaking-label"><Volume2 size={10}/> Aippie spreekt als het kind…</span>}
          </div>
        </div>
      )}

      {/* ── Aippie avatar panel ── */}
      <div className="sv-aippie-panel">
        <div className="sv-aippie-panel__portrait-wrap">
          <img
            src="/Jouw_alineatekst_(2).png"
            alt="Aippie"
            className={`sv-aippie-panel__portrait${speaking?' sv-aippie-panel__portrait--speaking':''}`}
            onError={e => { (e.currentTarget as HTMLImageElement).src = 'https://images.pexels.com/photos/1858175/pexels-photo-1858175.jpeg?auto=compress&cs=tinysrgb&w=300&h=350&fit=crop&crop=faces'; }}
          />
          {speaking && <div className="sv-aippie-panel__ring"/>}
        </div>
        <div className="sv-aippie-panel__right">
          <div className="sv-aippie-panel__name">Aippie · Autisme AI Signaal Radar</div>
          <div className="sv-aippie-panel__sub">
            {speaking && subtitle
              ? <span className="sv-aippie-panel__sub--active">{subtitle}</span>
              : <span className="sv-aippie-panel__sub--idle">
                  {gesture ? 'Signaal gedetecteerd. Eerste-persoon stem actief.'
                    : scanning ? '5 signalen worden geanalyseerd…'
                    : activeTab === 'careboard'
                      ? 'Tik op een pictogram — Aippie spreekt direct voor jou.'
                      : activeTab === 'pulse'
                        ? 'Leg vinger op camera — Aippie legt uit wat je moet doen.'
                        : activeTab === 'scanner'
                          ? 'Tik op een gebaar — Aippie spreekt het direct uit.'
                          : 'Open Camera tab om gezichtsdetectie te starten.'}
                </span>
            }
          </div>
          <div className="sv-aippie-panel__signals">
            {[
              { label:'Handgebaren',    pct:matchPct,   color:'#38bdf8' },
              { label:'Gezichtsuitdr.', pct:facePct,    color:faceCfg.color },
              { label:'Lichaamshouding',pct:posturePct, color:'#fbbf24' },
              { label:'Oogcontact',     pct:gazePct,    color:'#34d399' },
            ].map(({ label, pct, color }) => (
              <div key={label} className="sv-aippie-panel__signal-row">
                <span className="sv-aippie-panel__signal-label" style={{ color }}>{label}</span>
                <div className="sv-aippie-panel__signal-track">
                  <div className="sv-aippie-panel__signal-fill" style={{ width:`${pct}%`, background:color }}/>
                </div>
                <span className="sv-aippie-panel__signal-pct" style={{ color }}>{pct.toFixed(0)}%</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* ── Tab bar ── */}
      <div className="sv-tab-bar">
        <button className={`sv-tab-btn${activeTab==='careboard'?' sv-tab-btn--active':''}`} onClick={() => setActiveTab('careboard')}>
          ❤️ Care
        </button>
        <button className={`sv-tab-btn${activeTab==='camera'?' sv-tab-btn--active':''}`} onClick={() => setActiveTab('camera')}>
          <Scan size={11}/> Camera
        </button>
        <button className={`sv-tab-btn${activeTab==='pulse'?' sv-tab-btn--active':''}`} onClick={() => setActiveTab('pulse')}>
          🫀 Pols
        </button>
        <button className={`sv-tab-btn${activeTab==='scanner'?' sv-tab-btn--active':''}`} onClick={() => setActiveTab('scanner')}>
          <Hand size={11}/> Gebaar
        </button>
        <button className={`sv-tab-btn${activeTab==='parent'?' sv-tab-btn--active':''}`} onClick={() => setActiveTab('parent')}>
          <BarChart2 size={11}/> Ouder
        </button>
      </div>

      {/* ══════════════════════════════════════════════════════
          TAB: CAMERA + AAC BOARD
      ══════════════════════════════════════════════════════ */}
      {activeTab === 'camera' && (
        <CameraScanner
          onSpeak={(need) => {
            fireChildSpeech(need, GESTURES.find(g => detectNeed(g.label, g.facialExpression) === need) ?? GESTURES[0], 95);
          }}
          onBehaviorEvent={(evt) => {
            setBehaviorEvents(prev => [evt, ...prev].slice(0, 30));
          }}
        />
      )}

      {/* ══════════════════════════════════════════════════════
          TAB: CARE BORD — Universal icon communication board
      ══════════════════════════════════════════════════════ */}
      {activeTab === 'careboard' && (
        <AippieCareBoardView deviceKey={deviceKey} sessionId={sessionId} />
      )}

      {/* ══════════════════════════════════════════════════════
          TAB: POLS — rPPG heart rate + SpO2 camera measurement
      ══════════════════════════════════════════════════════ */}
      {activeTab === 'pulse' && (
        <PulseCameraView deviceKey={deviceKey} sessionId={sessionId} />
      )}

      {/* ══════════════════════════════════════════════════════
          TAB: CV SCANNER
      ══════════════════════════════════════════════════════ */}
      {activeTab === 'scanner' && (
        <>
          {/* ── Gesture board header ── */}
          <div className="sv-gesture-board-header">
            <Hand size={14} style={{ color:'#38bdf8' }}/>
            <div>
              <div className="sv-gesture-board-header__title">
                {lang==='nl' ? 'Gebaar Vertaler — Tik op een gebaar' : 'Gesture Translator — Tap a gesture'}
              </div>
              <div className="sv-gesture-board-header__sub">
                {lang==='nl'
                  ? 'Tik op het gebaar dat het kind maakt — Aippie spreekt direct als de stem van het kind'
                  : 'Tap the gesture the child is making — Aippie speaks immediately as the child\'s voice'}
              </div>
            </div>
          </div>

          {/* ── Gesture grid — full tap board ── */}
          <div className="sv-gesture-tap-grid">
            {GESTURES.map(g => {
              const fc = FACE_CFG[g.facialExpression];
              const need = detectNeed(g.label, g.facialExpression);
              const isActive = gesture?.label === g.label;
              return (
                <button
                  key={g.label}
                  className={`sv-gesture-tap-btn${isActive ? ' sv-gesture-tap-btn--active' : ''}`}
                  style={isActive ? { borderColor: fc.color, background: fc.color + '18' } : undefined}
                  onClick={() => {
                    const phrase = lang === 'nl'
                      ? (CHILD_PHRASES[need].nl)
                      : (CHILD_PHRASES[need].en);

                    setExpression(g.facialExpression);
                    setGesture(g);
                    setLastNeed(need);
                    setSpokenPhrase(phrase);
                    setLastChildPhrase(CHILD_PHRASES[need].nl);
                    setMatchPct(90 + Math.random() * 8);
                    setFacePct(85 + Math.random() * 12);
                    setPosturePct(80 + Math.random() * 15);
                    setGazePct(82 + Math.random() * 14);
                    setSpeaking(true);

                    // Direct, reliable TTS — wait for voices then speak
                    if ('speechSynthesis' in window) {
                      window.speechSynthesis.cancel();
                      withVoicesReady(() => {
                        const u = new SpeechSynthesisUtterance(normalizeForTTS(phrase));
                        u.lang  = lang === 'nl' ? 'nl-NL' : 'en-US';
                        u.rate  = 0.82;
                        u.pitch = 1.05;
                        applyPremiumVoice(u, u.lang);
                        u.onstart = () => setSpeaking(true);
                        u.onend   = () => setSpeaking(false);
                        u.onerror = () => setSpeaking(false);
                        window.speechSynthesis.speak(u);
                      });
                      // Fallback: reset speaking after estimated duration
                      setTimeout(() => setSpeaking(false), Math.max(phrase.length * 75, 3000));
                    } else {
                      setTimeout(() => setSpeaking(false), 3000);
                    }

                    // Scroll result into view
                    setTimeout(() => gestureCardRef.current?.scrollIntoView({ behavior: 'smooth', block: 'nearest' }), 60);

                    // Log to DB (async, don't block UI)
                    supabase.from('aippie_silent_voice_channels').insert({
                      session_id: sessionId, device_key: deviceKey,
                      gesture_label: g.label, confidence_pct: 95,
                      speech_output: phrase, lang_code: lang,
                      landmark_hash: btoa(g.label + Date.now()),
                    }).then(() => loadLog()).catch(() => {});
                  }}
                >
                  <span className="sv-gesture-tap-btn__label">{g.label}</span>
                  <span
                    className="sv-gesture-tap-btn__need"
                    style={{ color: NEED_COLORS[need], background: NEED_COLORS[need] + '18' }}
                  >
                    {NEED_LABELS[need]}
                  </span>
                  {isActive && speaking && (
                    <span className="sv-gesture-tap-btn__speaking">
                      <Volume2 size={9}/> spreekt…
                    </span>
                  )}
                </button>
              );
            })}
          </div>

          {/* ── Active result card ── */}
          {gesture && (
            <div className="sv-gesture-card sv-gesture-card--prominent" ref={gestureCardRef}>
              <div className="sv-gesture-card__top">
                <span className="sv-gesture-card__label">{gesture.label}</span>
                {lastNeed && (
                  <span className="sv-gesture-card__confidence" style={{ color: NEED_COLORS[lastNeed], borderColor: NEED_COLORS[lastNeed]+'33' }}>
                    <Heart size={9}/> {NEED_LABELS[lastNeed]}
                  </span>
                )}
                <button className="sv-gesture-card__close" onClick={clearGesture}>✕</button>
              </div>
              {/* BIG phrase so it's unmissable */}
              <div className="sv-gesture-card__big-phrase">
                {spokenPhrase || (gesture.phrases[lang] ?? gesture.phrases['en'])}
              </div>
              <div className="sv-gesture-card__wave">
                <Waveform active={speaking} color={expression==='pain'||expression==='distress'?'rose':'emerald'}/>
                <div className="sv-gesture-card__wave-label">
                  {speaking
                    ? <><Volume2 size={13}/> <strong>Aippie spreekt nu…</strong></>
                    : <span style={{ color:'#4ade80' }}>Stem afgespeeld — tik opnieuw om te herhalen</span>}
                </div>
              </div>
              <button
                className="sv-gesture-card__repeat-btn"
                onClick={() => {
                  const phrase = spokenPhrase;
                  if (!phrase || !('speechSynthesis' in window)) return;
                  window.speechSynthesis.cancel();
                  setSpeaking(true);
                  withVoicesReady(() => {
                    const u = new SpeechSynthesisUtterance(normalizeForTTS(phrase));
                    u.lang = lang === 'nl' ? 'nl-NL' : 'en-US';
                    u.rate = 0.82; u.pitch = 1.05;
                    applyPremiumVoice(u, u.lang);
                    u.onend = u.onerror = () => setSpeaking(false);
                    window.speechSynthesis.speak(u);
                  });
                  setTimeout(() => setSpeaking(false), Math.max((phrase?.length ?? 20) * 75, 3000));
                }}
              >
                <Volume2 size={14}/> Herhaal stem
              </button>
            </div>
          )}

          {/* Session log */}
          <div className="sv-log-section">
            <button className="sv-log-toggle" onClick={() => { setLogOpen(o=>!o); if (!logOpen) loadLog(); }}>
              <Zap size={11}/> SESSION LOG · {log.length} events
              <span className="sv-log-toggle__arrow">{logOpen?'▲':'▼'}</span>
            </button>
            {logOpen && (
              <div className="sv-log-list">
                {log.length === 0
                  ? <div className="sv-log-empty">Nog geen events. Tik op een gebaar.</div>
                  : log.map(row => (
                    <div key={row.id} className="sv-log-row">
                      <div className="sv-log-row__left">
                        <span className="sv-log-row__gesture">{row.gesture_label}</span>
                        <span className="sv-log-row__phrase">{row.speech_output}</span>
                      </div>
                      <div className="sv-log-row__right">
                        <span className="sv-log-row__conf">{Number(row.confidence_pct).toFixed(1)}%</span>
                        <span className="sv-log-row__time">{relTime(row.created_at)}</span>
                      </div>
                    </div>
                  ))
                }
              </div>
            )}
          </div>
        </>
      )}

      {/* ══════════════════════════════════════════════════════
          TAB: OUDER DASHBOARD (Parent Analytics Terminal)
      ══════════════════════════════════════════════════════ */}
      {activeTab === 'parent' && (
        <div className="pd-root">
          <div className="pd-header">
            <div className="pd-header__left">
              <BarChart2 size={14} className="pd-header__icon" />
              <div>
                <div className="pd-header__title">Ouder Dashboard</div>
                <div className="pd-header__sub">Beveiligd · AES-256 · GDPR & HIPAA Compliant</div>
              </div>
            </div>
            <div className="pd-header__right">
              <Lock size={10} style={{ color:'#4ade80' }} />
              <span className="pd-header__enc">E2EE</span>
            </div>
          </div>

          {parentLoading ? (
            <div className="pd-loading">
              <RefreshCw size={18} className="pd-spin" />
              <span>Telemetrie laden en analyseren…</span>
            </div>
          ) : (
            <>
              {/* ── AI Behavior Event Log (Point 4) ── */}
              {behaviorEvents.length > 0 && (
                <div className="pd-section">
                  <div className="pd-section__title"><AlertTriangle size={11}/> AI Gedragslog · Automatische Ouder Alerts</div>
                  <div className="pd-behavior-log">
                    {behaviorEvents.map(evt => (
                      <div key={evt.id} className="pd-behavior-entry">
                        <div className="pd-behavior-entry__score" style={{ color: evt.score > 65 ? '#f87171' : evt.score > 35 ? '#fbbf24' : '#4ade80' }}>
                          {evt.score}%
                        </div>
                        <div className="pd-behavior-entry__body">
                          <div className="pd-behavior-entry__detail">{evt.detail}</div>
                          <div className="pd-behavior-entry__time">
                            {new Date(evt.ts).toLocaleTimeString('nl-NL', { hour:'2-digit', minute:'2-digit', second:'2-digit' })}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* ── Telemetry progress bars ── */}
              <div className="pd-section">
                <div className="pd-section__title"><Activity size={11}/> Real-time Telemetrie Monitor</div>

                {/* Communicatie totaal */}
                <div className="pd-metric">
                  <div className="pd-metric__head">
                    <span className="pd-metric__label">Totale Communicatiemomenten</span>
                    <span className="pd-metric__val" style={{ color:'#38bdf8' }}>{parentInsight?.total_communications ?? 0}</span>
                  </div>
                  <div className="pd-metric__track">
                    <div className="pd-metric__fill" style={{ width:`${Math.min(100,(parentInsight?.total_communications??0)/50*100)}%`, background:'#38bdf8' }}/>
                  </div>
                  <div className="pd-metric__sub">Doel: 50 per week · Dagelijks gemiddelde: {parentInsight?.daily_comm_baseline ?? 0}</div>
                </div>

                {/* Emotionele status */}
                <div className="pd-metric">
                  <div className="pd-metric__head">
                    <span className="pd-metric__label">Emotionele Status — Kalm</span>
                    <span className="pd-metric__val" style={{ color:'#4ade80' }}>{parentInsight?.calm_pct ?? 0}%</span>
                  </div>
                  <div className="pd-metric__track">
                    <div className="pd-metric__fill" style={{ width:`${parentInsight?.calm_pct??0}%`, background:'#4ade80' }}/>
                  </div>
                </div>

                <div className="pd-metric">
                  <div className="pd-metric__head">
                    <span className="pd-metric__label">Emotionele Status — Overprikkeld</span>
                    <span className="pd-metric__val" style={{ color:'#f87171' }}>{parentInsight?.overload_pct ?? 0}%</span>
                  </div>
                  <div className="pd-metric__track">
                    <div className="pd-metric__fill" style={{ width:`${parentInsight?.overload_pct??0}%`, background:'#f87171' }}/>
                  </div>
                </div>

                {/* Peak stress hour */}
                <div className="pd-stat-row">
                  <div className="pd-stat">
                    <AlertTriangle size={12} style={{ color:'#fbbf24' }}/>
                    <div>
                      <div className="pd-stat__label">Piekstress Uur</div>
                      <div className="pd-stat__val" style={{ color:'#fbbf24' }}>
                        {parentInsight?.peak_stress_hour !== null && parentInsight?.peak_stress_hour !== undefined
                          ? `${parentInsight.peak_stress_hour}:00–${parentInsight.peak_stress_hour+1}:00`
                          : 'Geen data'}
                      </div>
                    </div>
                  </div>
                  <div className="pd-stat">
                    <Heart size={12} style={{ color:'#fb7185' }}/>
                    <div>
                      <div className="pd-stat__label">Meest Geuite Behoefte</div>
                      <div className="pd-stat__val" style={{ color:'#fb7185' }}>
                        {parentInsight?.dominant_need
                          ? NEED_LABELS[parentInsight.dominant_need as NeedCategory] ?? parentInsight.dominant_need
                          : 'Geen data'}
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* ── Weekly insight summary ── */}
              <div className="pd-section">
                <div className="pd-section__title"><Lock size={11}/> Versleuteld Wekelijks Inzicht</div>
                <div className="pd-insight-card">
                  <div className="pd-insight-card__enc-row">
                    <Lock size={9} style={{ color:'#4ade80' }}/>
                    <span>AES-256-GCM · HIPAA · GDPR · Apple HealthKit Compliant</span>
                  </div>
                  <div className="pd-insight-card__text">
                    {parentInsight?.summary_nl ?? 'Nog geen inzichten beschikbaar.'}
                  </div>
                </div>
              </div>

              {/* ── Daily communication logs ── */}
              <div className="pd-section">
                <div className="pd-section__title"><Zap size={11}/> Dagelijkse Communicatie Logs</div>
                {commLogs.length === 0 ? (
                  <div className="pd-empty">Nog geen communicatielogs. Start een scansessie.</div>
                ) : (
                  <div className="pd-log-list">
                    {commLogs.map(row => {
                      const need = row.need_category as NeedCategory;
                      const col  = NEED_COLORS[need] ?? '#64748b';
                      return (
                        <div key={row.id} className="pd-log-row">
                          <div className="pd-log-row__left">
                            <span className="pd-log-row__need" style={{ color:col, borderColor:col+'33' }}>
                              {NEED_LABELS[need] ?? need}
                            </span>
                            <span className="pd-log-row__phrase">{row.child_phrase_nl}</span>
                          </div>
                          <div className="pd-log-row__right">
                            <span className="pd-log-row__state"
                              style={{ color: row.emotional_state==='kalm'?'#4ade80':'#f87171' }}>
                              {row.emotional_state}
                            </span>
                            <span className="pd-log-row__score">{Number(row.fusion_score).toFixed(0)}%</span>
                            <span className="pd-log-row__time">{relTime(row.created_at)}</span>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>

              <button className="pd-refresh-btn" onClick={loadParentInsight}>
                <RefreshCw size={12}/> Vernieuwen
              </button>
            </>
          )}
        </div>
      )}

      <AippieVoiceOverlay context="silentvoice" />

      <div className="sv-footer">
        <ShieldCheck size={10}/>
        AIPPIETAX S.A. · Autisme AI Signaal Radar · 5-Signal MedTech v140 · GDPR compliant
      </div>
    </div>
  );
}
