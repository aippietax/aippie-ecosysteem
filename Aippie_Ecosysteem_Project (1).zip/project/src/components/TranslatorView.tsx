import { useCallback, useEffect, useRef, useState } from 'react';
import { Phone, PhoneOff, ShieldCheck, ShieldAlert } from 'lucide-react';
import { supabase, type CallRequest, type TranslatorProfile, RATE_PER_MINUTE, currentMonthStart } from '../lib/supabase';
import { CORRIDORS, corridorCode } from '../lib/routingConfig';
import { applyPremiumVoice, withVoicesReady } from '../lib/ttsVoice';
import CallTimer from './CallTimer';
import KycModal from './KycModal';
import EarningsDashboard from './EarningsDashboard';
import SofiaTabShell from './SofiaTabShell';
import type { User } from '@supabase/supabase-js';

type TStatus = 'online' | 'offline' | 'busy';
type Props   = { user: User };

const GREETING = 'Hello! I am setting up your secure live translator gateway now. Hold the button and speak.';

export default function TranslatorView({ user }: Props) {
  const [profile, setProfile]               = useState<TranslatorProfile | null>(null);
  const [profileLoading, setProfileLoading] = useState(true);
  const [showKyc, setShowKyc]               = useState(false);
  const [status, setStatus]                 = useState<TStatus>('offline');
  const [corridor, setCorridor]             = useState(CORRIDORS[0]);
  const [incomingCall, setIncomingCall]     = useState<CallRequest | null>(null);
  const [callPhase, setCallPhase]           = useState<'idle' | 'ringing' | 'active'>('idle');
  const [callSeconds, setCallSeconds]       = useState(0);
  const [accepting, setAccepting]           = useState(false);

  const [avatarText,  setAvatarText]  = useState('');
  const [isSpeaking,  setIsSpeaking]  = useState(false);

  const timerRef     = useRef<ReturnType<typeof setInterval> | null>(null);
  const callStartRef = useRef<number>(0);
  const channelRef   = useRef<ReturnType<typeof supabase.channel> | null>(null);

  // ── Local TTS helper ──────────────────────────────────────────────────────
  const speak = useCallback((text: string) => {
    if (!('speechSynthesis' in window)) return;
    window.speechSynthesis.cancel();
    setAvatarText(text);
    setIsSpeaking(false);
    const fire = () => {
      const u = new SpeechSynthesisUtterance(text);
      u.pitch = 1.1; u.rate = 0.92;
      applyPremiumVoice(u);
      u.onstart = () => setIsSpeaking(true);
      u.onend   = () => setIsSpeaking(false);
      u.onerror = () => setIsSpeaking(false);
      window.speechSynthesis.speak(u);
    };
    withVoicesReady(fire);
  }, []);

  const isVerified = profile?.kyc_status === 'verified';

  useEffect(() => {
    supabase
      .from('translator_profiles')
      .select('id, user_id, kyc_status, full_name, iban, bic, country, submitted_at, verified_at, created_at')
      .eq('user_id', user.id)
      .maybeSingle()
      .then(({ data }) => {
        setProfile(data as TranslatorProfile | null);
        setProfileLoading(false);
      });
  }, [user.id]);

  const upsertSession = useCallback(async (s: TStatus) => {
    await supabase
      .from('translator_sessions')
      .upsert(
        { user_id: user.id, corridor: corridorCode(corridor), status: s, updated_at: new Date().toISOString() },
        { onConflict: 'user_id' }
      );
  }, [user.id, corridor]);

  const toggleOnline = async () => {
    if (!isVerified) { setShowKyc(true); return; }
    const next: TStatus = status === 'offline' ? 'online' : 'offline';
    await upsertSession(next);
    setStatus(next);
    if (next === 'online') {
      speak('You are now live on the Interpreter Gateway. Your active corridor is ready. I will alert you instantly when a client connects. Your automated payout runs every minute at the contracted rate.');
    } else {
      speak('You are now offline. Your session earnings have been logged to the payout ledger.');
    }
  };

  useEffect(() => {
    if (status !== 'online') return;
    const code = corridorCode(corridor);
    const ch = supabase
      .channel(`translator-calls-${user.id}`)
      .on('postgres_changes',
        { event: 'INSERT', schema: 'public', table: 'call_requests', filter: `corridor=eq.${code}` },
        (payload) => {
          const row = payload.new as CallRequest;
          if (row.status === 'pending' && callPhase === 'idle') {
            setIncomingCall(row);
            setCallPhase('ringing');
          }
        }
      ).subscribe();
    channelRef.current = ch;
    return () => { supabase.removeChannel(ch); channelRef.current = null; };
  }, [status, corridor, user.id, callPhase]);

  useEffect(() => {
    return () => {
      supabase.from('translator_sessions').update({ status: 'offline' }).eq('user_id', user.id);
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [user.id]);

  const startTimer = () => {
    callStartRef.current = Date.now();
    setCallSeconds(0);
    timerRef.current = setInterval(() => setCallSeconds(s => s + 1), 1000);
  };

  const stopTimer = () => {
    if (timerRef.current) { clearInterval(timerRef.current); timerRef.current = null; }
  };

  const acceptCall = async () => {
    if (!incomingCall) return;
    setAccepting(true);
    await Promise.all([
      upsertSession('busy'),
      supabase.from('call_requests').update({
        status: 'accepted',
        translator_user_id: user.id,
        accepted_at: new Date().toISOString(),
      }).eq('id', incomingCall.id),
    ]);
    setStatus('busy');
    setAccepting(false);
    setCallPhase('active');
    startTimer();
  };

  const declineCall = () => { setIncomingCall(null); setCallPhase('idle'); };

  const endCall = async () => {
    stopTimer();
    const minutes = Math.max((Date.now() - callStartRef.current) / 60000, 0.0167);
    const earned  = +(minutes * RATE_PER_MINUTE * 0.6).toFixed(2); // 60% translator share
    await Promise.all([
      incomingCall
        ? supabase.from('call_requests').update({ status: 'ended' }).eq('id', incomingCall.id)
        : Promise.resolve(),
      supabase.from('call_minutes').insert({
        call_request_id:    incomingCall?.id ?? null,
        translator_user_id: user.id,
        minutes,
        rate_per_minute:    RATE_PER_MINUTE,
        month_start:        currentMonthStart(),
      }),
      upsertSession('online'),
    ]);
    setStatus('online');
    setIncomingCall(null);
    setCallPhase('idle');
    setCallSeconds(0);
    // Contextual payout briefing
    speak(`Call completed. Duration: ${Math.floor(minutes)} minutes and ${Math.round((minutes % 1) * 60)} seconds. Your automated payout of ${earned} Euros has been credited to your balance. You are back online and ready for the next client.`);
  };

  const corridorLabel = `${corridor.from.flag} ${corridor.from.label} ⇄ ${corridor.to.flag} ${corridor.to.label}`;

  if (profileLoading) {
    return (
      <div className="sts-root" style={{ alignItems: 'center', justifyContent: 'center' }}>
        <span className="modal__spinner" />
      </div>
    );
  }

  return (
    <>
      {/* KYC modal */}
      {showKyc && (
        <KycModal
          user={user}
          existing={profile}
          onVerified={(p) => { setProfile(p); setShowKyc(false); }}
          onClose={() => setShowKyc(false)}
        />
      )}

      {/* Incoming call overlay */}
      {callPhase === 'ringing' && incomingCall && (
        <div className="incoming-overlay">
          <div className="incoming-card">
            <div className="incoming-card__ring">
              <div className="incoming-card__ring-inner">
                <Phone size={28} className="incoming-card__phone-icon" />
              </div>
            </div>
            <h2 className="incoming-card__title">Incoming Call</h2>
            <p className="incoming-card__corridor">{corridorLabel}</p>
            <p className="incoming-card__sub">Client needs a live interpreter · Rate: €{RATE_PER_MINUTE.toFixed(2)}/min</p>
            <div className="incoming-card__actions">
              <button className="incoming-card__decline" onClick={declineCall}>
                <PhoneOff size={20} /><span>Decline</span>
              </button>
              <button className="incoming-card__accept" onClick={acceptCall} disabled={accepting}>
                {accepting
                  ? <span className="modal__spinner modal__spinner--sm" />
                  : <><Phone size={20} /><span>Accept</span></>
                }
              </button>
            </div>
          </div>
        </div>
      )}

      <SofiaTabShell
        greeting={GREETING}
        serviceLabel="Interpreter Gateway · WebRTC · v86"
        trustLine="AIPPIETAX S.A. · v86 · End-to-End Encrypted"
        onHoldStart={toggleOnline}
        speakingText={avatarText}
        isSpeaking={isSpeaking}
      >
        {/* Earnings + status strip overlaid on portrait */}
        <div className="sts-translator-overlay">
          {/* KYC badge */}
          <div className="sts-translator-overlay__kyc">
            {isVerified
              ? <span className="kyc-badge kyc-badge--verified"><ShieldCheck size={10} /> Verified</span>
              : <button className="kyc-badge kyc-badge--pending" onClick={() => setShowKyc(true)}>
                  <ShieldAlert size={10} /> Verify Account
                </button>
            }
          </div>

          {/* Active call status */}
          {callPhase === 'active' && (
            <div className="sts-translator-overlay__call">
              <CallTimer seconds={callSeconds} />
              <div className="phase-badge phase-badge--connected">
                <Phone size={12} /> Live — {corridorLabel}
              </div>
              <button className="call-end-btn" onClick={endCall}>
                <PhoneOff size={18} /> End Call
              </button>
            </div>
          )}

          {/* Online status + corridor selector */}
          <div className="sts-translator-overlay__controls">
            <div className="corridor-tabs">
              {CORRIDORS.map(c => (
                <button
                  key={c.from.code}
                  className={`corridor-tab${corridor.from.code === c.from.code ? ' corridor-tab--active' : ''}`}
                  onClick={() => { if (callPhase === 'idle') setCorridor(c); }}
                  disabled={callPhase !== 'idle'}
                >
                  <span>{c.from.flag}</span>
                  <span className="corridor-tab__label">{c.from.label}</span>
                  <span className="corridor-tab__arrow">⇄</span>
                  <span>{c.to.flag}</span>
                  <span className="corridor-tab__label">ES</span>
                </button>
              ))}
            </div>

            <div className="translator-toggle-wrap" style={{ justifyContent: 'center' }}>
              <span className={`translator-status-label${status === 'online' ? ' translator-status-label--online' : ''}`}>
                <span className={`translator-status-dot${status === 'online' ? ' translator-status-dot--online' : ''}`} />
                {status === 'busy' ? 'Busy' : status === 'online' ? 'Online' : 'Offline'}
              </span>
              <button
                className={`translator-toggle${status !== 'offline' ? ' translator-toggle--on' : ''}`}
                onClick={toggleOnline}
                disabled={callPhase === 'active'}
                aria-label="Toggle availability"
              >
                <span className="translator-toggle__knob" />
              </button>
            </div>
          </div>

          <EarningsDashboard
            user={user}
            isCallActive={callPhase === 'active'}
            callSeconds={callSeconds}
          />
        </div>
      </SofiaTabShell>
    </>
  );
}
