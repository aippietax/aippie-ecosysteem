export default function StatusBar() {
  return (
    <div className="status-bar">
      <span className="status-dot" />
      <span className="status-text">142 Translators online in Spain</span>
    </div>
  );
}
