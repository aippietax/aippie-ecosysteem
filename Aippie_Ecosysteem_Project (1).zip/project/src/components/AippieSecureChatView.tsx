// @ts-nocheck
import { useState, useEffect, useRef, useCallback } from 'react';
import {
  ArrowLeft, Plus, Shield, Clock, Globe, Send, Lock,
  EyeOff, UserPlus, MessageCircle, Copy, Check, RefreshCw,
  Ghost, ShieldCheck, Zap, Video, AlertTriangle, Fingerprint,
  ShieldOff, Eye, Skull, Reply, Trash2, SmilePlus, Timer, X,
  Camera, Paperclip, FileText, Mic, MicOff, Play, Square,
  Image, Megaphone, MapPin, Wallet, CreditCard, BrainCircuit,
} from 'lucide-react';
import { supabase } from '../lib/supabase';
import { getOrCreatePublicKey, hasPrivateKey, encryptMessage, decryptMessage, clearKeys } from '../lib/e2ee';
import type { User } from '@supabase/supabase-js';
import type { RealtimeChannel } from '@supabase/supabase-js';
import AippieOpenWorldView from './AippieOpenWorldView';

type Screen = 'loading' | 'setup' | 'contacts' | 'chat' | 'add_contact' | 'guardian_challenge' | 'lockdown';

interface PinProfile {
  id: string;
  pin_code: string;
  display_name: string;
  avatar_color: string;
  ghost_mode: boolean;
  public_key: string | null;
  last_seen_at: string | null;
  is_locked?: boolean;
  locked_until?: string | null;
  failed_attempts?: number;
  avatar_url?: string | null;
  country_code?: string | null;
  country_name?: string | null;
  ad_text?: string | null;
  ad_enabled?: boolean;
  bg_color?: string | null;
  ad_paid_until?: string | null;
  verified_type?: 'none' | 'gold' | 'platinum';
  account_type?: 'personal' | 'business';
  passkey_credential_id?: string | null;
}

interface Contact {
  id: string;
  contact_pin: string;
  pin_code?: string;
  nickname: string | null;
  appear_offline_to: boolean;
  is_blocked: boolean;
  vanish_timer: number;
  profile: PinProfile | null;
}

interface Message {
  id: string;
  from_pin: string;
  to_pin: string;
  content: string;
  detected_lang: string | null;
  is_read: boolean;
  read_at: string | null;
  expires_at: string | null;
  is_deleted: boolean;
  created_at: string;
  reply_to_id: string | null;
  reply_preview: string | null;
  translation?: string;
  countdown?: number;
}

interface Reaction {
  id: string;
  message_id: string;
  from_pin: string;
  emoji: string;
}

interface ContactMeta {
  lastContent: string;
  lastAt: string;
  unreadCount: number;
}

const AVATAR_COLORS = ['#3B82F6', '#8B5CF6', '#10B981', '#F59E0B', '#EF4444', '#EC4899', '#06B6D4', '#F97316'];
const EMOJI_LIST = ['❤️', '👍', '😂', '😮', '😢', '🔥'];
const VANISH_OPTIONS = [
  { label: '5s',   value: 5 },
  { label: '15s',  value: 15 },
  { label: '32s',  value: 32 },
  { label: '1 min', value: 60 },
  { label: '3 min', value: 180 },
  { label: '5 min', value: 300 },
  { label: 'Off',  value: 0 },
];

function generatePin(): string {
  return String(Math.floor(10000 + Math.random() * 90000));
}

function getInitials(name: string): string {
  return name.split(' ').map(w => w[0]).join('').toUpperCase().slice(0, 2) || '?';
}

function timeAgo(ts: string): string {
  const diff = Date.now() - new Date(ts).getTime();
  if (diff < 60000) return 'now';
  if (diff < 3600000) return `${Math.floor(diff / 60000)}m`;
  if (diff < 86400000) return `${Math.floor(diff / 3600000)}h`;
  return `${Math.floor(diff / 86400000)}d`;
}

function randomColor(): string {
  return AVATAR_COLORS[Math.floor(Math.random() * AVATAR_COLORS.length)];
}

function countryFlag(code: string): string {
  return code.toUpperCase().replace(/./g, c =>
    String.fromCodePoint(c.codePointAt(0)! - 65 + 0x1F1E6)
  );
}

function formatLastSeen(ts: string): string {
  const d = new Date(ts);
  const now = new Date();
  const diff = now.getTime() - d.getTime();
  if (diff < 120000) return 'Now online';
  if (diff < 3600000) return `${Math.floor(diff / 60000)} min geleden`;
  if (diff < 86400000) {
    return `Vandaag ${d.toLocaleTimeString('nl-NL', { hour: '2-digit', minute: '2-digit' })}`;
  }
  return `${d.toLocaleDateString('nl-NL', { day: 'numeric', month: 'short' })} ${d.toLocaleTimeString('nl-NL', { hour: '2-digit', minute: '2-digit' })}`;
}

async function translateMessage(text: string, targetLang: string): Promise<string | null> {
  try {
    const { data } = await supabase.functions.invoke('secure-chat-translate', { body: { text, targetLang } });
    if (data?.same_lang) return null;
    return data?.translation ?? null;
  } catch {
    return null;
  }
}

// ── Inline auth gate for unauthenticated users ────────────────────────────
function SecureChatAuthGate() {
  const [mode, setMode] = useState<'login' | 'register' | 'reset'>('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  const handle = async () => {
    if (mode === 'reset') {
      if (!email.trim()) { setError('Enter your email address.'); return; }
      setLoading(true); setError(''); setSuccess('');
      try {
        const { error: e } = await supabase.auth.resetPasswordForEmail(email.trim(), {
          redirectTo: window.location.origin + '?reset=1',
        });
        if (e) { setError(e.message); } else { setSuccess('Reset link sent! Check your email.'); }
      } catch { setError('Something went wrong, try again.'); }
      setLoading(false);
      return;
    }
    if (!email.trim() || !password.trim()) { setError('Fill in email and password.'); return; }
    setLoading(true); setError(''); setSuccess('');
    try {
      if (mode === 'register') {
        const { error: e } = await supabase.auth.signUp({ email: email.trim(), password });
        if (e) { setError(e.message); } else { setSuccess('Account created! You are now signed in.'); }
      } else {
        const { error: e } = await supabase.auth.signInWithPassword({ email: email.trim(), password });
        if (e) { setError(e.message); }
      }
    } catch { setError('Something went wrong, try again.'); }
    setLoading(false);
  };

  return (
    <div className="scc-root">
      <div className="scc-auth-gate">
        <div className="scc-auth-gate__icon-wrap">
          <Lock size={36} className="scc-auth-gate__icon" />
        </div>
        <h2 className="scc-auth-gate__title">Aippie SecureChat</h2>
        <p className="scc-auth-gate__sub">E2EE · Sneak Guard · Voice Masking · P2P Video</p>

        {mode !== 'reset' && (
          <div className="scc-auth-gate__toggle">
            <button
              className={`scc-auth-gate__mode-btn${mode === 'login' ? ' scc-auth-gate__mode-btn--active' : ''}`}
              onClick={() => { setMode('login'); setError(''); setSuccess(''); }}
            >Sign In</button>
            <button
              className={`scc-auth-gate__mode-btn${mode === 'register' ? ' scc-auth-gate__mode-btn--active' : ''}`}
              onClick={() => { setMode('register'); setError(''); setSuccess(''); }}
            >Create Account</button>
          </div>
        )}

        {mode === 'reset' && (
          <p style={{ color: '#94a3b8', fontSize: '0.85rem', marginBottom: '0.75rem', textAlign: 'center' }}>
            Enter your email and we'll send a reset link.
          </p>
        )}

        <div className="scc-auth-gate__form">
          <input
            className="scc-auth-gate__input"
            type="email"
            placeholder="Email address"
            value={email}
            onChange={e => setEmail(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && handle()}
            autoComplete="email"
          />
          {mode !== 'reset' && (
            <input
              className="scc-auth-gate__input"
              type="password"
              placeholder="Password"
              value={password}
              onChange={e => setPassword(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && handle()}
              autoComplete={mode === 'register' ? 'new-password' : 'current-password'}
            />
          )}
          {error && <p className="scc-auth-gate__error">{error}</p>}
          {success && <p className="scc-auth-gate__success">{success}</p>}
          <button className="scc-auth-gate__submit" onClick={handle} disabled={loading}>
            {loading ? <span className="modal__spinner" /> : mode === 'register' ? 'Create Account & Sign In' : mode === 'reset' ? 'Send Reset Link' : 'Sign In & Open'}
          </button>

          {mode === 'login' && (
            <button
              className="scc-auth-gate__forgot"
              onClick={() => { setMode('reset'); setError(''); setSuccess(''); }}
            >
              Forgot password?
            </button>
          )}
          {mode === 'reset' && (
            <button
              className="scc-auth-gate__forgot"
              onClick={() => { setMode('login'); setError(''); setSuccess(''); }}
            >
              ← Back to sign in
            </button>
          )}
        </div>

        <p className="scc-auth-gate__footer">
          <ShieldCheck size={10} /> Zero server storage · AES-256-GCM · 100% Free
        </p>
      </div>
    </div>
  );
}

export default function AippieSecureChatView({ user, onStartVideoCall, onOpenLifeAssist }: { user: User | null; onStartVideoCall?: () => void; onOpenLifeAssist?: () => void }) {
  const [screen, setScreen] = useState<Screen>('loading');
  const [myProfile, setMyProfile] = useState<PinProfile | null>(null);
  const [contacts, setContacts] = useState<Contact[]>([]);
  const [activeContact, setActiveContact] = useState<Contact | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [setupName, setSetupName] = useState('');
  const [setupPin, setSetupPin] = useState(() => generatePin());
  const [addPinInput, setAddPinInput] = useState('');
  const [addNickInput, setAddNickInput] = useState('');
  const [addError, setAddError] = useState('');
  const [pinCopied, setPinCopied] = useState(false);
  const [sending, setSending] = useState(false);
  const [blurred, setBlurred] = useState(false);
  const [setupError, setSetupError] = useState('');

  // Guardian AI
  const [strikeCount, setStrikeCount] = useState(0);
  const [guardianInput, setGuardianInput] = useState('');
  const [guardianError, setGuardianError] = useState('');
  const [lockdownUntil, setLockdownUntil] = useState<Date | null>(null);
  const [lockdownSeconds, setLockdownSeconds] = useState(0);
  const [biometricAvailable, setBiometricAvailable] = useState(false);
  const [postLoginAttempts, setPostLoginAttempts] = useState(0);
  // Passkey (WebAuthn) offer shown after successful PIN login
  const [showPasskeyOffer, setShowPasskeyOffer] = useState(false);
  const [passkeyOfferWorking, setPasskeyOfferWorking] = useState(false);
  const prevScreenRef = useRef<Screen>('contacts');

  // E2EE
  const [e2eeActive, setE2eeActive] = useState(false);

  // Typing
  const [contactTyping, setContactTyping] = useState(false);
  const typingTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const typingSentAtRef = useRef(0);

  // Kill switch
  const [killSwitchOpen, setKillSwitchOpen] = useState(false);
  const [killSwitchInput, setKillSwitchInput] = useState('');
  const [killSwitchWorking, setKillSwitchWorking] = useState(false);

  // Super chat features
  const [replyTo, setReplyTo] = useState<Message | null>(null);
  const [reactions, setReactions] = useState<Record<string, Reaction[]>>({});
  const [emojiPickerMsgId, setEmojiPickerMsgId] = useState<string | null>(null);
  const [contextMenu, setContextMenu] = useState<{ msg: Message } | null>(null);
  const [vanishTimer, setVanishTimer] = useState(32);
  const [vanishPickerOpen, setVanishPickerOpen] = useState(false);
  const [contactMeta, setContactMeta] = useState<Record<string, ContactMeta>>({});
  const vanishTimerRef = useRef(32);
  const longPressTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  // DLP scanner
  const [dlpWarning, setDlpWarning] = useState<string | null>(null);
  const [dlpBypass, setDlpBypass]   = useState(false);

  // AippieShield: sneak detection
  const [sneakDetected, setSneakDetected] = useState(false);
  const sneakVideoRef = useRef<HTMLVideoElement | null>(null);
  const sneakCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const sneakIntervalRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const faceApiLoadedRef = useRef(false);

  // AippieShield: pitch shift active on WebRTC streams
  const pitchAudioCtxRef = useRef<AudioContext | null>(null);

  // ── Video call with PIN ──────────────────────────────────────────────────
  const [videoCallDialog, setVideoCallDialog] = useState<'idle' | 'caller_pin' | 'callee_pin' | 'ai_proxy'>('idle');
  const [videoCallPin, setVideoCallPin] = useState('');
  const [videoCallPinInput, setVideoCallPinInput] = useState('');

  // ── Document / file send ─────────────────────────────────────────────────
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [fileSending, setFileSending] = useState(false);

  // ── Voice messages ───────────────────────────────────────────────────────
  const [recording, setRecording] = useState(false);
  const [voiceSending, setVoiceSending] = useState(false);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const [playingVoiceId, setPlayingVoiceId] = useState<string | null>(null);

  // ── Profile picture ──────────────────────────────────────────────────────
  const avatarUploadRef = useRef<HTMLInputElement>(null);
  const [profileView, setProfileView] = useState<{ contact: Contact; pinInput: string; revealed: boolean } | null>(null);

  // ── Ad system ────────────────────────────────────────────────────────────
  const [adInput, setAdInput] = useState('');
  const [adEnabled, setAdEnabled] = useState(false);
  const [adPanelOpen, setAdPanelOpen] = useState(false);
  const [flashAd, setFlashAd] = useState<string | null>(null);

  // ── PIN reveal (hidden by default — biometric or AI voice required) ──────
  const [pinRevealed, setPinRevealed] = useState(false);
  const [pinRevealOpen, setPinRevealOpen] = useState(false);
  const [voiceVerifying, setVoiceVerifying] = useState(false);
  const [voiceStatus, setVoiceStatus] = useState('');
  // Scrambled key order for anti-shoulder-surfing (reshuffled every 10 seconds)
  const [pinKeyOrder, setPinKeyOrder] = useState<string[]>(['1','2','3','4','5','6','7','8','9','','0','⌫']);
  useEffect(() => {
    if (!pinRevealOpen) return;
    const shuffle = () => {
      const digits = ['1','2','3','4','5','6','7','8','9','0'];
      for (let i = digits.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [digits[i], digits[j]] = [digits[j], digits[i]];
      }
      const grid = [...digits.slice(0,9), '', digits[9], '⌫'];
      setPinKeyOrder(grid);
    };
    shuffle();
    const t = setInterval(shuffle, 10000);
    return () => clearInterval(t);
  }, [pinRevealOpen]);

  // ── Profile background color ─────────────────────────────────────────────
  const [bgColorPickerOpen, setBgColorPickerOpen] = useState(false);

  // ── 3D Workspace ─────────────────────────────────────────────────────────
  const [show3D, setShow3D] = useState(false);

  // ── Breaking News Ticker ──────────────────────────────────────────────────
  const [newsTickerVisible, setNewsTickerVisible] = useState(false);
  const [newsTickerIdx, setNewsTickerIdx] = useState(0);
  const newsTickerTimerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const newsTickerHideRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const BREAKING_NEWS = [
    { cat: 'TRADING', text: 'BTC breaks $112,000 — highest price ever in 2026.' },
    { cat: 'CRYPTO',  text: 'ETH +8.4% after approval of Ethereum ETF by SEC.' },
    { cat: 'AANDELEN',text: 'NVDA rises 5.2% after AI chip deal with Microsoft.' },
    { cat: 'MACRO',   text: 'ECB cuts rates to 2.75% — first time in 2 years.' },
    { cat: 'CRYPTO',  text: 'Solana reaches new ATH of $420 after massive inflow.' },
    { cat: 'TRADING', text: 'Gold at $3,100/oz — flight to safety continues.' },
    { cat: 'AANDELEN',text: 'Apple lanceert AI-chip M5 — koers +3.8% na-uren.' },
    { cat: 'BREAKING',text: 'FED: Rate hike paused — markets react positively.' },
    { cat: 'CRYPTO',  text: 'XRP wint rechtszaak — stijging 22% in 24 uur.' },
    { cat: 'MACRO',   text: 'Inflatie eurozone daalt naar 1.9% — onder ECB-target.' },
    { cat: 'TRADING', text: 'Oil prices -4% after OPEC+ decides to increase production.' },
    { cat: 'AANDELEN',text: 'Tesla Q2 results: 600,000 vehicles delivered, +15% YoY.' },
  ];

  useEffect(() => {
    newsTickerTimerRef.current = setInterval(() => {
      setNewsTickerIdx(i => (i + 1) % BREAKING_NEWS.length);
      setNewsTickerVisible(true);
      if (newsTickerHideRef.current) clearTimeout(newsTickerHideRef.current);
      newsTickerHideRef.current = setTimeout(() => setNewsTickerVisible(false), 8000);
    }, 28000);
    // Show first one after 10s
    const first = setTimeout(() => {
      setNewsTickerVisible(true);
      newsTickerHideRef.current = setTimeout(() => setNewsTickerVisible(false), 8000);
    }, 10000);
    return () => {
      if (newsTickerTimerRef.current) clearInterval(newsTickerTimerRef.current);
      if (newsTickerHideRef.current) clearTimeout(newsTickerHideRef.current);
      clearTimeout(first);
    };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // ── Life AI Phone Sensors ─────────────────────────────────────────────────
  const [batteryLevel, setBatteryLevel] = useState<number | null>(null);
  const [batteryCharging, setBatteryCharging] = useState<boolean | null>(null);
  const shakeCountRef = useRef(0);
  const lastShakeRef = useRef(0);
  const [sosAlertActive, setSosAlertActive] = useState(false);

  useEffect(() => {
    // Battery API
    if ('getBattery' in navigator) {
      (navigator as Navigator & { getBattery: () => Promise<{ level: number; charging: boolean; addEventListener: (e: string, cb: () => void) => void }> })
        .getBattery().then(bat => {
          setBatteryLevel(Math.round(bat.level * 100));
          setBatteryCharging(bat.charging);
          bat.addEventListener('levelchange', () => {
            const lvl = Math.round(bat.level * 100);
            setBatteryLevel(lvl);
            if (lvl <= 15 && onOpenLifeAssist) {
              setLifeAiIncomingMsg(`Battery almost empty: ${lvl}%. Charge your phone!`);
              setLifeAiBubbleOpen(true); setLifeAiMinimized(false);
            }
          });
          bat.addEventListener('chargingchange', () => setBatteryCharging(bat.charging));
        }).catch(() => {/* not supported */});
    }

    // Shake detection via accelerometer (3 quick shakes = SOS)
    const handleMotion = (e: DeviceMotionEvent) => {
      const acc = e.accelerationIncludingGravity;
      if (!acc) return;
      const total = Math.abs(acc.x ?? 0) + Math.abs(acc.y ?? 0) + Math.abs(acc.z ?? 0);
      const now = Date.now();
      if (total > 30 && now - lastShakeRef.current > 300) {
        lastShakeRef.current = now;
        shakeCountRef.current += 1;
        if (shakeCountRef.current >= 3) {
          shakeCountRef.current = 0;
          setSosAlertActive(true);
          if (onOpenLifeAssist) {
            setLifeAiIncomingMsg('Shake detected! Do you need help? Tap ↗ for full Life AI.');
            setLifeAiBubbleOpen(true); setLifeAiMinimized(false);
          }
        }
        setTimeout(() => { shakeCountRef.current = Math.max(0, shakeCountRef.current - 1); }, 1500);
      }
    };
    window.addEventListener('devicemotion', handleMotion);
    return () => window.removeEventListener('devicemotion', handleMotion);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [onOpenLifeAssist]);

  // ── Floating Life AI bubble ───────────────────────────────────────────────
  const [lifeAiBubbleOpen, setLifeAiBubbleOpen] = useState(false);
  const [lifeAiMsgIdx, setLifeAiMsgIdx] = useState(0);
  const [lifeAiIncomingMsg, setLifeAiIncomingMsg] = useState<string | null>(null);
  const [lifeAiMinimized, setLifeAiMinimized] = useState(false);
  const lifeAiTimerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const LIFE_AI_MESSAGES = [
    { type: 'tip',      text: 'Tip: Use the vanish timer to auto-delete messages.' },
    { type: 'ask',      text: 'How are you today? I\'m here if you need anything.' },
    { type: 'tip',      text: 'Did you know you can send APC coins via the wallet button?' },
    { type: 'ask',      text: 'Have you checked your daily briefing in Morning Briefing?' },
    { type: 'tip',      text: 'Tip: Enable Ghost Mode to be invisible to contacts.' },
    { type: 'ask',      text: 'Want to start a video call? Use the camera button.' },
    { type: 'tip',      text: 'Your messages are end-to-end encrypted. No one can read them.' },
    { type: 'ask',      text: 'Should I look something up or arrange something for you?' },
    { type: 'tip',      text: 'Tip: Press and hold a message to add reactions and reply.' },
    { type: 'ask',      text: 'Great job! You are securely connected via Aippie SecureChat.' },
    { type: 'tip',      text: 'You can share documents via the paperclip button.' },
    { type: 'ask',      text: 'Want to enter the Open World? Tap the 🌐 icon.' },
  ];

  useEffect(() => {
    if (lifeAiBubbleOpen && !lifeAiMinimized) {
      lifeAiTimerRef.current = setInterval(() => {
        setLifeAiMsgIdx(i => (i + 1) % LIFE_AI_MESSAGES.length);
      }, 5000);
    } else {
      if (lifeAiTimerRef.current) clearInterval(lifeAiTimerRef.current);
    }
    return () => { if (lifeAiTimerRef.current) clearInterval(lifeAiTimerRef.current); };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [lifeAiBubbleOpen, lifeAiMinimized]);

  // ── Ad slideshow ─────────────────────────────────────────────────────────
  const [adSlideIndex, setAdSlideIndex] = useState(0);

  // ── Wallet in chat ───────────────────────────────────────────────────────
  const [walletPanelOpen, setWalletPanelOpen] = useState(false);
  const [walletBalance, setWalletBalance] = useState<number | null>(null);
  const [walletAmt, setWalletAmt] = useState('');
  const [walletBusy, setWalletBusy] = useState(false);
  const [walletFeedback, setWalletFeedback] = useState<{ ok: boolean; msg: string } | null>(null);
  const [videoCallPinError, setVideoCallPinError] = useState('');
  const [videoCallFrom, setVideoCallFrom] = useState('');
  const [aiProxyMsg, setAiProxyMsg] = useState('');
  const [incomingCallMsgId, setIncomingCallMsgId] = useState<string | null>(null);

  // ── Notification permission ──────────────────────────────────────────────
  const notifPermRef = useRef<NotificationPermission>('default');

  const userLang = navigator.language.split('-')[0] ?? 'en';
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const channelRef = useRef<RealtimeChannel | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const lastSeenIntervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  useEffect(() => { vanishTimerRef.current = vanishTimer; }, [vanishTimer]);

  // ── Request notification permission on first load ────────────────────────
  useEffect(() => {
    if ('Notification' in window && Notification.permission === 'default') {
      Notification.requestPermission().then(p => { notifPermRef.current = p; });
    } else if ('Notification' in window) {
      notifPermRef.current = Notification.permission;
    }
  }, []);

  // ── TTS helper ───────────────────────────────────────────────────────────
  const speakNotification = useCallback((text: string) => {
    if (!window.speechSynthesis) return;
    window.speechSynthesis.cancel();
    const u = new SpeechSynthesisUtterance(text);
    u.lang = 'nl-NL'; u.rate = 0.88; u.pitch = 1.05; u.volume = 0.9;
    const voices = window.speechSynthesis.getVoices();
    const nl = voices.find(v => v.lang.startsWith('nl')) ?? voices.find(v => v.lang.startsWith('en'));
    if (nl) u.voice = nl;
    window.speechSynthesis.speak(u);
  }, []);

  // ── Show Web Notification + TTS for incoming message ────────────────────
  const notifyIncomingMessage = useCallback((fromName: string, preview: string) => {
    speakNotification(`Je hebt een bericht van ${fromName}`);
    if ('Notification' in window && Notification.permission === 'granted') {
      new Notification(`Bericht van ${fromName}`, {
        body: preview.length > 60 ? preview.slice(0, 60) + '…' : preview,
        icon: '/icons/icon.svg',
        badge: '/icons/icon.svg',
        tag: `msg-${fromName}`,
      });
    }
  }, [speakNotification]);

  // ── Show Web Notification + TTS for incoming call ────────────────────────
  const notifyIncomingCall = useCallback((fromName: string) => {
    speakNotification(`Je wordt gebeld door ${fromName}`);
    if ('Notification' in window && Notification.permission === 'granted') {
      new Notification(`Inkomende videooproep van ${fromName}`, {
        body: 'Tap to open and enter PIN to accept.',
        icon: '/icons/icon.svg',
        tag: `call-${fromName}`,
        requireInteraction: true,
      });
    }
  }, [speakNotification]);

  useEffect(() => {
    if (window.PublicKeyCredential) {
      // Mark biometric available if the API exists — actual capability check unreliable on Android
      setBiometricAvailable(true);
      window.PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable()
        .catch(() => {/* keep true */});
    }
  }, []);

  // ── Passkey helpers ────────────────────────────────────────────────────────
  const bufToBase64url = (buf: ArrayBuffer) =>
    btoa(String.fromCharCode(...new Uint8Array(buf)))
      .replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');

  const base64urlToBuf = (b64: string) => {
    const b = b64.replace(/-/g, '+').replace(/_/g, '/');
    const raw = atob(b);
    const buf = new Uint8Array(raw.length);
    for (let i = 0; i < raw.length; i++) buf[i] = raw.charCodeAt(i);
    return buf.buffer;
  };

  const savePasskey = async (profile: PinProfile) => {
    if (!biometricAvailable) return;
    try {
      const uvpa = await window.PublicKeyCredential
        ?.isUserVerifyingPlatformAuthenticatorAvailable?.().catch(() => false);
      if (!uvpa) return;
      const challenge = crypto.getRandomValues(new Uint8Array(32));
      const cred = await navigator.credentials.create({
        publicKey: {
          challenge,
          rp: { name: 'Aippie SecureChat', id: window.location.hostname },
          user: {
            id: new TextEncoder().encode(profile.pin_code),
            name: profile.pin_code,
            displayName: profile.display_name,
          },
          pubKeyCredParams: [
            { type: 'public-key', alg: -7 },
            { type: 'public-key', alg: -257 },
          ],
          authenticatorSelection: { authenticatorAttachment: 'platform', userVerification: 'required' },
          timeout: 60000,
        },
      }) as PublicKeyCredential | null;
      if (cred) {
        const credId = bufToBase64url(cred.rawId);
        await supabase.from('secure_chat_pins').update({ passkey_credential_id: credId }).eq('pin_code', profile.pin_code);
        setMyProfile(p => p ? { ...p, passkey_credential_id: credId } : p);
      }
    } catch { /* silent — user cancelled or not supported */ }
    finally { setPasskeyOfferWorking(false); setShowPasskeyOffer(false); }
  };

  const tryPasskeyLogin = async (credId: string): Promise<boolean> => {
    try {
      const uvpa = await window.PublicKeyCredential
        ?.isUserVerifyingPlatformAuthenticatorAvailable?.().catch(() => false);
      if (!uvpa) return false;
      const challenge = crypto.getRandomValues(new Uint8Array(32));
      const cred = await navigator.credentials.get({
        publicKey: {
          challenge,
          timeout: 60000,
          userVerification: 'required',
          rpId: window.location.hostname,
          allowCredentials: [{ type: 'public-key', id: base64urlToBuf(credId) }],
        },
      }) as PublicKeyCredential | null;
      return !!cred;
    } catch { return false; }
  };

  // Lockdown countdown
  useEffect(() => {
    if (screen !== 'lockdown' || !lockdownUntil) return;
    const tick = setInterval(() => {
      const remaining = Math.max(0, Math.ceil((lockdownUntil.getTime() - Date.now()) / 1000));
      setLockdownSeconds(remaining);
      if (remaining === 0) {
        setStrikeCount(0); setLockdownUntil(null); setPostLoginAttempts(0);
        setScreen('contacts');
      }
    }, 1000);
    return () => clearInterval(tick);
  }, [screen, lockdownUntil]);

  const recordFailedAttempt = useCallback(() => {
    const next = strikeCount + 1;
    setStrikeCount(next);
    if (next >= 3) {
      const until = new Date(Date.now() + 5 * 60 * 1000);
      setLockdownUntil(until); setLockdownSeconds(300); setScreen('lockdown');
      if (myProfile) {
        supabase.from('secure_chat_pins').update({ failed_attempts: next, is_locked: true, locked_until: until.toISOString() }).eq('pin_code', myProfile.pin_code);
      }
    } else {
      setGuardianError(`Warning: ${3 - next} attempt${3 - next === 1 ? '' : 's'} remaining before lockdown.`);
    }
  }, [strikeCount, myProfile]);

  const requireGuardian = useCallback((destination: Screen) => {
    prevScreenRef.current = destination;
    setGuardianInput(''); setGuardianError('');
    setScreen('guardian_challenge');
  }, []);

  const handleGuardianVerify = useCallback(() => {
    if (!myProfile) return;
    if (guardianInput === myProfile.pin_code) {
      setStrikeCount(0); setGuardianError(''); setPostLoginAttempts(0);
      setScreen(prevScreenRef.current);
    } else {
      recordFailedAttempt();
    }
  }, [myProfile, guardianInput, recordFailedAttempt]);

  const handleBiometricUnlock = useCallback(async () => {
    if (!biometricAvailable) return;
    try {
      // First check platform authenticator availability
      const uvpa = await window.PublicKeyCredential
        ?.isUserVerifyingPlatformAuthenticatorAvailable?.()
        .catch(() => false);

      if (!uvpa) { setBiometricAvailable(false); return; }

      // Real WebAuthn assertion — triggers device FaceID / TouchID / Android Biometric
      const challenge = crypto.getRandomValues(new Uint8Array(32));
      const credential = await navigator.credentials.get({
        publicKey: {
          challenge,
          timeout: 60000,
          userVerification: 'required',
          rpId: window.location.hostname,
          allowCredentials: [], // empty = any registered credential for this device
        },
      }) as PublicKeyCredential | null;

      if (credential) {
        // Bind the cryptographic response into auth state
        const response = credential.response as AuthenticatorAssertionResponse;
        const clientDataHash = response.clientDataJSON;
        if (clientDataHash) {
          setStrikeCount(0); setLockdownUntil(null); setPostLoginAttempts(0);
          setScreen('contacts');
          if (myProfile) {
            supabase.from('secure_chat_pins').update({ failed_attempts: 0, is_locked: false, locked_until: null }).eq('pin_code', myProfile.pin_code);
          }
        }
      } else {
        // No registered credential — fall back to PIN
        setBiometricAvailable(false);
      }
    } catch (err: unknown) {
      const name = (err as { name?: string })?.name;
      if (name === 'NotAllowedError') {
        // User cancelled or timed out — stay on current screen, don't break
        return;
      }
      if (name === 'NotSupportedError' || name === 'InvalidStateError') {
        // No registered credential for this origin — fall back to PIN grid gracefully
        setBiometricAvailable(false);
        return;
      }
      const next = postLoginAttempts + 1;
      setPostLoginAttempts(next);
      if (next >= 3) { const until = new Date(Date.now() + 15 * 60 * 1000); setLockdownUntil(until); setLockdownSeconds(900); }
    }
  }, [biometricAvailable, myProfile, postLoginAttempts]);

  // AippieShield Feature 1: Native hardware focus listeners — blackout on any tab/window blur
  useEffect(() => {
    const onHidden = () => setBlurred(true);
    const onVisible = () => { if (!document.hidden) setBlurred(false); };
    const onWinBlur = () => setBlurred(true);
    const onWinFocus = () => setBlurred(false);
    document.addEventListener('visibilitychange', onVisible);
    window.addEventListener('blur', onWinBlur);
    window.addEventListener('focus', onWinFocus);
    return () => {
      document.removeEventListener('visibilitychange', onVisible);
      window.removeEventListener('blur', onWinBlur);
      window.removeEventListener('focus', onWinFocus);
    };
    void onHidden; // referenced to suppress lint warning
  }, []);

  // last_seen_at heartbeat
  useEffect(() => {
    if (!myProfile) return;
    const update = () => {
      if (myProfile.ghost_mode) return;
      supabase.from('secure_chat_pins').update({ last_seen_at: new Date().toISOString() }).eq('pin_code', myProfile.pin_code);
    };
    update();
    lastSeenIntervalRef.current = setInterval(update, 30_000);
    return () => { if (lastSeenIntervalRef.current) clearInterval(lastSeenIntervalRef.current); };
  }, [myProfile?.pin_code, myProfile?.ghost_mode]); // eslint-disable-line

  // AippieShield Feature 4: Sneak Detection — TinyFaceDetector via face-api.js CDN
  // Loads the model lazily, then polls the camera every 2s in chat screen.
  // If 2+ faces are detected the vault is force-closed immediately.
  useEffect(() => {
    if (screen !== 'chat') {
      if (sneakIntervalRef.current) { clearInterval(sneakIntervalRef.current); sneakIntervalRef.current = null; }
      return;
    }

    let stream: MediaStream | null = null;
    let cancelled = false;

    const loadFaceApi = (): Promise<boolean> => {
      if (faceApiLoadedRef.current) return Promise.resolve(true);
      return new Promise(resolve => {
        if (document.querySelector('script[data-faceapi]')) {
          // Already injecting — wait for load
          const check = setInterval(() => {
            if ((window as Record<string, unknown>)['faceapi']) { clearInterval(check); faceApiLoadedRef.current = true; resolve(true); }
          }, 200);
          return;
        }
        const s = document.createElement('script');
        s.dataset.faceapi = '1';
        s.src = 'https://cdn.jsdelivr.net/npm/face-api.js@0.22.2/dist/face-api.min.js';
        s.onload = async () => {
          try {
            const fa = (window as Record<string, unknown>)['faceapi'] as { nets: { tinyFaceDetector: { loadFromUri: (u: string) => Promise<void> } } };
            await fa.nets.tinyFaceDetector.loadFromUri('https://cdn.jsdelivr.net/npm/@vladmandic/face-api/model');
            faceApiLoadedRef.current = true;
            resolve(true);
          } catch { resolve(false); }
        };
        s.onerror = () => resolve(false);
        document.head.appendChild(s);
      });
    };

    const startDetection = async () => {
      const loaded = await loadFaceApi();
      if (!loaded || cancelled) return;

      try {
        stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'user', width: 160, height: 120 }, audio: false });
      } catch { return; }
      if (cancelled) { stream.getTracks().forEach(t => t.stop()); return; }

      const video = document.createElement('video');
      video.srcObject = stream;
      video.width = 160; video.height = 120;
      video.muted = true; video.playsInline = true;
      sneakVideoRef.current = video;
      await video.play().catch(() => {});

      const canvas = document.createElement('canvas');
      canvas.width = 160; canvas.height = 120;
      sneakCanvasRef.current = canvas;

      sneakIntervalRef.current = setInterval(async () => {
        if (cancelled || !faceApiLoadedRef.current) return;
        const fa = (window as Record<string, unknown>)['faceapi'] as {
          detectAllFaces: (el: HTMLVideoElement, opts: unknown) => { withFaceLandmarks: () => Promise<unknown[]> };
          TinyFaceDetectorOptions: new (opts: { inputSize: number; scoreThreshold: number }) => unknown;
        };
        try {
          const detections = await fa.detectAllFaces(video, new fa.TinyFaceDetectorOptions({ inputSize: 128, scoreThreshold: 0.4 })).withFaceLandmarks();
          if (Array.isArray(detections) && detections.length >= 2) {
            setSneakDetected(true);
            // Force-close the chat after 800ms grace
            setTimeout(() => {
              if (!cancelled) {
                setSneakDetected(false);
                setScreen('contacts');
              }
            }, 800);
          }
        } catch { /* non-fatal */ }
      }, 2000);
    };

    startDetection();

    return () => {
      cancelled = true;
      if (sneakIntervalRef.current) { clearInterval(sneakIntervalRef.current); sneakIntervalRef.current = null; }
      if (stream) stream.getTracks().forEach(t => t.stop());
    };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [screen]);

  // AippieShield Feature 5: Web Audio API ScriptProcessor +15% pitch shift
  // Applied to any MediaStream audio tracks obtained during the session.
  const applyPitchShiftToStream = useCallback((mediaStream: MediaStream): MediaStream => {
    try {
      if (!pitchAudioCtxRef.current || pitchAudioCtxRef.current.state === 'closed') {
        pitchAudioCtxRef.current = new AudioContext();
      }
      const ctx = pitchAudioCtxRef.current;
      const source = ctx.createMediaStreamSource(mediaStream);
      const bufferSize = 4096;
      // eslint-disable-next-line @typescript-eslint/no-deprecated
      const processor = ctx.createScriptProcessor(bufferSize, 1, 1);
      const pitchFactor = 1.15; // +15%
      let readIndex = 0;
      const buffer = new Float32Array(bufferSize * 2);

      processor.onaudioprocess = (e) => {
        const input = e.inputBuffer.getChannelData(0);
        const output = e.outputBuffer.getChannelData(0);
        for (let i = 0; i < bufferSize; i++) {
          buffer[(readIndex + i) % buffer.length] = input[i];
        }
        for (let i = 0; i < bufferSize; i++) {
          const pos = (readIndex + i * pitchFactor) % buffer.length;
          const idx0 = Math.floor(pos) % buffer.length;
          const idx1 = (idx0 + 1) % buffer.length;
          const frac = pos - Math.floor(pos);
          output[i] = buffer[idx0] * (1 - frac) + buffer[idx1] * frac;
        }
        readIndex = (readIndex + bufferSize) % buffer.length;
      };

      source.connect(processor);
      processor.connect(ctx.destination);

      const dest = ctx.createMediaStreamDestination();
      source.connect(dest);
      // Return shifted stream merged with original video tracks
      const shifted = dest.stream;
      const videoTracks = mediaStream.getVideoTracks();
      videoTracks.forEach(t => shifted.addTrack(t));
      return shifted;
    } catch {
      return mediaStream;
    }
  }, []);

  // Expose pitch shift helper on window for VideoVaultView / WebRTC integration
  useEffect(() => {
    (window as Record<string, unknown>)['aippieShieldPitchShift'] = applyPitchShiftToStream;
    return () => { delete (window as Record<string, unknown>)['aippieShieldPitchShift']; };
  }, [applyPitchShiftToStream]);

  // Countdown ticker for vanishing messages — both sent AND received
  useEffect(() => {
    if (screen !== 'chat') return;
    const tick = setInterval(() => {
      const now = Date.now();
      setMessages(prev =>
        prev
          .filter(m => !m.expires_at || new Date(m.expires_at).getTime() > now)
          .map(m => {
            if (!m.expires_at) return m;
            const remaining = Math.max(0, Math.ceil((new Date(m.expires_at).getTime() - now) / 1000));
            return { ...m, countdown: remaining };
          })
      );
    }, 1000);
    return () => clearInterval(tick);
  }, [screen]);

  useEffect(() => { messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' }); }, [messages]);

  // ── Load my profile ────────────────────────────────────────────────────────
  const loadMyProfile = useCallback(async () => {
    if (!user) { setScreen('setup'); return; }
    const { data } = await supabase.from('secure_chat_pins').select('*').eq('user_id', user.id).maybeSingle();
    if (data) {
      const pinRow = data as PinProfile;
      setMyProfile(pinRow);
      if (!pinRow.public_key) {
        try {
          const pub = await getOrCreatePublicKey(pinRow.pin_code);
          await supabase.from('secure_chat_pins').update({ public_key: pub }).eq('user_id', user.id);
          setMyProfile(p => p ? { ...p, public_key: pub } : p);
        } catch { /* non-fatal */ }
      }
      if (pinRow.is_locked && pinRow.locked_until) {
        const until = new Date(pinRow.locked_until);
        if (until > new Date()) {
          setLockdownUntil(until);
          setLockdownSeconds(Math.ceil((until.getTime() - Date.now()) / 1000));
          setStrikeCount(pinRow.failed_attempts ?? 3);
          prevScreenRef.current = 'contacts';
          setScreen('lockdown');
          return;
        } else {
          await supabase.from('secure_chat_pins').update({ is_locked: false, failed_attempts: 0, locked_until: null }).eq('user_id', user.id);
        }
      }
      // If a passkey credential was previously saved, attempt silent biometric auto-login
      if (pinRow.passkey_credential_id && biometricAvailable) {
        const ok = await tryPasskeyLogin(pinRow.passkey_credential_id);
        if (ok) { setScreen('contacts'); return; }
        // Passkey failed / cancelled → fall through to contacts normally
      }
      setScreen('contacts');
    } else {
      setScreen('setup');
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user, biometricAvailable]);

  useEffect(() => { loadMyProfile(); }, [loadMyProfile]);

  // ── Detect country via IP and save to profile ────────────────────────────
  useEffect(() => {
    if (!myProfile) return;
    if (myProfile.country_code) return; // already known
    fetch('https://ipapi.co/json/')
      .then(r => r.json())
      .then((d: { country_code?: string; country_name?: string }) => {
        if (!d.country_code) return;
        supabase.from('secure_chat_pins').update({
          country_code: d.country_code,
          country_name: d.country_name ?? d.country_code,
        }).eq('pin_code', myProfile.pin_code);
        setMyProfile(p => p ? { ...p, country_code: d.country_code, country_name: d.country_name } : p);
      })
      .catch(() => {/* non-fatal */});
  }, [myProfile?.pin_code]);

  // Sync ad state from profile
  useEffect(() => {
    if (myProfile) {
      setAdInput(myProfile.ad_text ?? '');
      setAdEnabled(myProfile.ad_enabled ?? false);
    }
  }, [myProfile?.pin_code]);

  // ── Load contacts + meta ───────────────────────────────────────────────────
  const loadContacts = useCallback(async () => {
    if (!myProfile) return;
    const { data: rows } = await supabase
      .from('secure_chat_contacts')
      .select('*')
      .eq('owner_pin', myProfile.pin_code)
      .eq('is_blocked', false);
    if (!rows?.length) { setContacts([]); setContactMeta({}); return; }

    const pins = rows.map(r => r.contact_pin);
    const { data: profiles } = await supabase.from('secure_chat_pins').select('*').in('pin_code', pins);
    const profileMap = Object.fromEntries((profiles ?? []).map(p => [p.pin_code, p]));
    const loaded: Contact[] = rows.map(r => ({ ...r, vanish_timer: r.vanish_timer ?? 32, profile: profileMap[r.contact_pin] ?? null }));
    setContacts(loaded);

    // Load last message + unread count for the contact list preview
    const { data: recentMsgs } = await supabase
      .from('secure_chat_messages')
      .select('from_pin, to_pin, content, created_at, is_read')
      .or(`from_pin.eq.${myProfile.pin_code},to_pin.eq.${myProfile.pin_code}`)
      .eq('is_deleted', false)
      .order('created_at', { ascending: false })
      .limit(200);

    if (recentMsgs) {
      const meta: Record<string, ContactMeta> = {};
      for (const c of loaded) {
        const msgs = recentMsgs.filter(m =>
          (m.from_pin === myProfile.pin_code && m.to_pin === c.contact_pin) ||
          (m.from_pin === c.contact_pin && m.to_pin === myProfile.pin_code)
        );
        const last = msgs[0];
        const unread = msgs.filter(m => m.to_pin === myProfile.pin_code && !m.is_read).length;
        if (last) {
          meta[c.contact_pin] = {
            lastContent: last.content.length > 42 ? last.content.slice(0, 42) + '…' : last.content,
            lastAt: last.created_at,
            unreadCount: unread,
          };
        }
      }
      setContactMeta(meta);
    }
  }, [myProfile]);

  useEffect(() => { if (screen === 'contacts') loadContacts(); }, [screen, loadContacts]);

  // ── Open conversation ──────────────────────────────────────────────────────
  const openConversation = useCallback(async (contact: Contact) => {
    if (!myProfile) return;
    channelRef.current?.unsubscribe();
    setContactTyping(false); setReplyTo(null); setEmojiPickerMsgId(null); setContextMenu(null); setReactions({});

    const timer = contact.vanish_timer ?? 32;
    setVanishTimer(timer);
    vanishTimerRef.current = timer;

    const myPub = myProfile.public_key ?? null;
    const contactPub = contact.profile?.public_key ?? null;
    const deviceKey = myPub ? await hasPrivateKey(myProfile.pin_code).catch(() => false) : false;
    const canE2EE = !!(myPub && contactPub && deviceKey);
    setE2eeActive(canE2EE);

    const { data } = await supabase
      .from('secure_chat_messages')
      .select('*')
      .or(
        `and(from_pin.eq.${myProfile.pin_code},to_pin.eq.${contact.contact_pin}),` +
        `and(from_pin.eq.${contact.contact_pin},to_pin.eq.${myProfile.pin_code})`
      )
      .eq('is_deleted', false)
      .order('created_at', { ascending: true })
      .limit(50);

    const now = new Date().toISOString();
    const rows = (data ?? []) as Message[];
    const unreadIds = rows.filter(m => m.to_pin === myProfile.pin_code && !m.is_read).map(m => m.id);

    if (unreadIds.length > 0) {
      const expMs = timer > 0 ? timer * 1000 : null;
      const expiresAt = expMs ? new Date(Date.now() + expMs).toISOString() : null;
      await supabase.from('secure_chat_messages')
        .update({ is_read: true, read_at: now, expires_at: expiresAt })
        .in('id', unreadIds);
    }

    const processed: Message[] = await Promise.all(rows.map(async m => {
      const wasUnread = unreadIds.includes(m.id);
      const expMs = timer > 0 ? timer * 1000 : null;
      const finalExpires = wasUnread ? (expMs ? new Date(Date.now() + expMs).toISOString() : null) : m.expires_at;

      let content = m.content;
      if (canE2EE) {
        const senderPub = m.from_pin === myProfile.pin_code ? myPub! : contactPub!;
        const plain = await decryptMessage(m.content, myProfile.pin_code, senderPub).catch(() => null);
        if (plain !== null) content = plain;
      }

      let translation: string | undefined;
      if (m.from_pin !== myProfile.pin_code) {
        const t = await translateMessage(content, userLang);
        if (t) translation = t;
      }

      return {
        ...m,
        content,
        is_read: wasUnread ? true : m.is_read,
        expires_at: finalExpires,
        countdown: finalExpires ? Math.max(0, Math.ceil((new Date(finalExpires).getTime() - Date.now()) / 1000)) : undefined,
        translation,
      };
    }));

    setMessages(processed);

    // Load reactions for fetched messages
    const msgIds = rows.map(m => m.id);
    if (msgIds.length > 0) {
      const { data: rxData } = await supabase.from('secure_chat_reactions').select('*').in('message_id', msgIds);
      if (rxData) {
        const rxMap: Record<string, Reaction[]> = {};
        for (const rx of rxData as Reaction[]) {
          if (!rxMap[rx.message_id]) rxMap[rx.message_id] = [];
          rxMap[rx.message_id].push(rx);
        }
        setReactions(rxMap);
      }
    }

    // Realtime channel
    channelRef.current = supabase
      .channel(`scc_${myProfile.pin_code}_${contact.contact_pin}`, { config: { broadcast: { self: false } } })
      .on('postgres_changes', {
        event: 'INSERT', schema: 'public', table: 'secure_chat_messages',
        filter: `to_pin=eq.${myProfile.pin_code}`,
      }, async (payload) => {
        const newMsg = payload.new as Message;
        if (newMsg.from_pin !== contact.contact_pin) return;

        const readNow = new Date().toISOString();
        const currentTimer = vanishTimerRef.current;
        const expMs = currentTimer > 0 ? currentTimer * 1000 : null;
        const exp = expMs ? new Date(Date.now() + expMs).toISOString() : null;

        await supabase.from('secure_chat_messages').update({ is_read: true, read_at: readNow, expires_at: exp }).eq('id', newMsg.id);

        let content = newMsg.content;
        if (canE2EE && contactPub) {
          const plain = await decryptMessage(newMsg.content, myProfile.pin_code, contactPub).catch(() => null);
          if (plain !== null) content = plain;
        }

        const t = await translateMessage(content, userLang);
        setContactTyping(false);

        // ── Check for incoming video call system message ─────────────────
        if (content.startsWith('VIDEO_CALL_REQUEST:')) {
          const token = content.replace('VIDEO_CALL_REQUEST:', '').trim();
          setVideoCallPin(token);
          setVideoCallFrom(contact.profile?.display_name ?? contact.nickname ?? contact.contact_pin);
          setIncomingCallMsgId(newMsg.id);
          setVideoCallDialog('callee_pin');
          notifyIncomingCall(contact.profile?.display_name ?? contact.nickname ?? contact.contact_pin);
          // Auto-handshake: token received — negotiate in 4 seconds unless user declines
          setTimeout(() => {
            setVideoCallDialog(prev => {
              if (prev === 'callee_pin') {
                onStartVideoCall?.();
                return 'idle';
              }
              return prev;
            });
          }, 4000);
        } else {
          // Regular message notification
          notifyIncomingMessage(
            contact.nickname ?? contact.profile?.display_name ?? contact.contact_pin,
            content,
          );
        }

        setMessages(prev => [...prev, {
          ...newMsg, content, is_read: true, read_at: readNow,
          expires_at: exp,
          countdown: exp ? currentTimer : undefined,
          translation: t ?? undefined,
        }]);

        // Life AI: auto-show bubble with a context-aware response on new incoming message
        if (onOpenLifeAssist) {
          const lowerContent = content.toLowerCase();
          let lifeAiReaction = 'New message received. Want to respond?';
          if (lowerContent.includes('bel') || lowerContent.includes('call')) lifeAiReaction = 'Your contact wants to call. Tap the phone button.';
          else if (lowerContent.includes('betaal') || lowerContent.includes('apc') || lowerContent.includes('geld')) lifeAiReaction = 'Money is being discussed. Want to send APC via the wallet?';
          else if (lowerContent.includes('document') || lowerContent.includes('bestand') || lowerContent.includes('file')) lifeAiReaction = 'Your contact is sharing a file. Tap to view.';
          else if (lowerContent.includes('hoi') || lowerContent.includes('hey') || lowerContent.includes('hello') || lowerContent.includes('hallo')) lifeAiReaction = 'Your contact is greeting you! Send them a message back.';
          else if (lowerContent.includes('help') || lowerContent.includes('hulp')) lifeAiReaction = 'Your contact needs help. Can I arrange something?';
          setLifeAiIncomingMsg(lifeAiReaction);
          setLifeAiBubbleOpen(true);
          setLifeAiMinimized(false);
        }
      })
      .on('broadcast', { event: 'typing' }, () => {
        setContactTyping(true);
        if (typingTimeoutRef.current) clearTimeout(typingTimeoutRef.current);
        typingTimeoutRef.current = setTimeout(() => setContactTyping(false), 3000);
      })
      .on('broadcast', { event: 'delete' }, (payload) => {
        const { messageId } = payload.payload as { messageId: string };
        setMessages(prev => prev.filter(m => m.id !== messageId));
      })
      .on('broadcast', { event: 'reaction' }, async (payload) => {
        const { messageId } = payload.payload as { messageId: string };
        const { data: rxData } = await supabase.from('secure_chat_reactions').select('*').eq('message_id', messageId);
        if (rxData) setReactions(prev => ({ ...prev, [messageId]: rxData as Reaction[] }));
      })
      .subscribe();
  }, [myProfile, userLang]);

  // ── Register PIN ───────────────────────────────────────────────────────────
  const handleSetup = async () => {
    if (!user || !setupName.trim()) return;
    setSetupError('');
    let publicKey: string | null = null;
    try { publicKey = await getOrCreatePublicKey(setupPin); } catch { /* non-fatal */ }

    const { data, error } = await supabase.from('secure_chat_pins').insert({
      user_id: user.id, pin_code: setupPin, display_name: setupName.trim(),
      avatar_color: randomColor(), ghost_mode: false, public_key: publicKey,
      last_seen_at: new Date().toISOString(),
    }).select().single();

    if (error) {
      if (error.code === '23505') { setSetupPin(generatePin()); setSetupError('PIN collision — a new PIN was generated. Try again.'); }
      else setSetupError('Failed to register. Try again.');
      return;
    }
    setMyProfile(data as PinProfile);
    setScreen('contacts');
  };

  // ── Add contact ────────────────────────────────────────────────────────────
  const handleAddContact = async () => {
    if (!myProfile || addPinInput.length !== 5) return;
    setAddError('');
    if (addPinInput === myProfile.pin_code) { setAddError('You cannot add yourself.'); return; }
    const { data: pinData } = await supabase.from('secure_chat_pins').select('pin_code').eq('pin_code', addPinInput).maybeSingle();
    if (!pinData) { setAddError('PIN not found. Ask your contact to share their Aippie PIN.'); return; }
    const { error } = await supabase.from('secure_chat_contacts').insert({
      owner_pin: myProfile.pin_code, contact_pin: addPinInput,
      nickname: addNickInput.trim() || null, appear_offline_to: false, is_blocked: false, vanish_timer: 32,
    });
    if (error?.code === '23505') { setAddError('Contact already added.'); return; }
    if (error) { setAddError('Could not add contact. Try again.'); return; }
    setAddPinInput(''); setAddNickInput('');
    setScreen('contacts');
    loadContacts();
  };

  // ── DLP: detect sensitive data patterns ──────────────────────────────────
  const dlpScan = (text: string): string | null => {
    if (/\b[A-Z]{2}\d{6,9}\b/.test(text))                          return 'Possible passport number detected';
    if (/\b[A-Z]{2}\d{2}[A-Z0-9]{4}\d{7}([A-Z0-9]{0,16})?\b/.test(text)) return 'Possible IBAN account number detected';
    if (/\b(?:\d[ -]?){13,16}\b/.test(text) && /\b\d{16}\b/.test(text.replace(/[ -]/g, ''))) return 'Possible credit card number detected';
    if (/\b\d{3}-\d{2}-\d{4}\b/.test(text))                        return 'Possible BSN/SSN detected';
    if (/-----BEGIN (?:RSA |EC )?PRIVATE KEY-----/.test(text))      return 'Private key detected — NEVER send this!';
    return null;
  };

  // ── Send message ──────────────────────────────────────────────────────────
  const handleSend = async () => {
    if (!myProfile || !activeContact || !input.trim() || sending) return;

    // DLP gate — block if sensitive pattern found and user hasn't confirmed bypass
    if (!dlpBypass) {
      const warning = dlpScan(input);
      if (warning) { setDlpWarning(warning); return; }
    }
    setDlpWarning(null); setDlpBypass(false);
    setSending(true);
    const plaintext = input.trim();
    setInput('');
    const currentReplyTo = replyTo;
    setReplyTo(null);

    let storedContent = plaintext;
    const contactPub = activeContact.profile?.public_key ?? null;
    if (e2eeActive && contactPub && myProfile.public_key) {
      try { storedContent = await encryptMessage(plaintext, myProfile.pin_code, contactPub); } catch { /* fallback */ }
    }

    const insertPayload: Record<string, unknown> = {
      from_pin: myProfile.pin_code, to_pin: activeContact.contact_pin,
      content: storedContent, is_read: false, is_deleted: false,
    };
    if (currentReplyTo) {
      insertPayload.reply_to_id = currentReplyTo.id;
      insertPayload.reply_preview = currentReplyTo.content.slice(0, 80);
    }

    const { data, error } = await supabase.from('secure_chat_messages').insert(insertPayload).select().single();
    if (!error && data) {
      setMessages(prev => [...prev, {
        ...(data as Message), content: plaintext,
        reply_preview: currentReplyTo ? currentReplyTo.content.slice(0, 80) : null,
      }]);
    }
    setSending(false);
    if (activeContact) flashAdForContact(activeContact);
    inputRef.current?.focus();
  };

  // ── Typing broadcast ──────────────────────────────────────────────────────
  const sendTypingBroadcast = useCallback(() => {
    if (!myProfile || !activeContact) return;
    if (activeContact.appear_offline_to || myProfile.ghost_mode) return;
    const now = Date.now();
    if (now - typingSentAtRef.current < 2000) return;
    typingSentAtRef.current = now;
    channelRef.current?.send({ type: 'broadcast', event: 'typing', payload: { from: myProfile.pin_code } });
  }, [myProfile, activeContact]);

  // ── Video call: initiate (caller side) — auto-handshake ─────────────────
  const handleInitiateVideoCall = useCallback(() => {
    if (!myProfile || !activeContact) return;
    // Generate cryptographic session token
    const token = Array.from(crypto.getRandomValues(new Uint8Array(3)))
      .map(b => b.toString(16).padStart(2, '0')).join('').toUpperCase();
    setVideoCallPin(token);
    setVideoCallPinInput('');
    setVideoCallPinError('');
    setVideoCallDialog('caller_pin');
  }, [myProfile, activeContact]);

  const handleSendVideoCallRequest = useCallback(async () => {
    if (!myProfile || !activeContact) return;
    await supabase.from('secure_chat_messages').insert({
      from_pin: myProfile.pin_code,
      to_pin: activeContact.contact_pin,
      content: `VIDEO_CALL_REQUEST:${videoCallPin}`,
      is_read: false,
      is_deleted: false,
    });
    setMessages(prev => [...prev, {
      id: `local-${Date.now()}`, from_pin: myProfile.pin_code, to_pin: activeContact.contact_pin,
      content: `VIDEO_CALL_REQUEST:${videoCallPin}`, is_read: false, read_at: null,
      expires_at: null, is_deleted: false, created_at: new Date().toISOString(),
      reply_to_id: null, reply_preview: null, detected_lang: null,
    }]);
    // Auto-launch call for caller — token handshake complete
    setVideoCallDialog('idle');
    onStartVideoCall?.();
  }, [myProfile, activeContact, videoCallPin, onStartVideoCall]);

  const handleAcceptVideoCall = useCallback(() => {
    if (videoCallPinInput !== videoCallPin) {
      setVideoCallPinError('Verkeerde PIN, probeer opnieuw.');
      return;
    }
    setVideoCallDialog('idle');
    setVideoCallPinInput('');
    setVideoCallPinError('');
    onStartVideoCall?.();
  }, [videoCallPinInput, videoCallPin, onStartVideoCall]);

  // ── AI proxy: send message on behalf of callee ───────────────────────────
  const handleAiProxy = useCallback(async () => {
    if (!myProfile || !videoCallFrom || !aiProxyMsg.trim()) return;
    const contactPin = contacts.find(c =>
      (c.profile?.display_name ?? c.nickname) === videoCallFrom
    )?.contact_pin;
    if (!contactPin) return;
    await supabase.from('secure_chat_messages').insert({
      from_pin: myProfile.pin_code,
      to_pin: contactPin,
      content: `[Aippie AI]: ${aiProxyMsg.trim()}`,
      is_read: false, is_deleted: false,
    });
    setAiProxyMsg('');
    setVideoCallDialog('idle');
  }, [myProfile, videoCallFrom, aiProxyMsg, contacts]);

  // ── File / document send ────────────────────────────────────────────────
  const handleFileSelect = useCallback(async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !myProfile || !activeContact) return;
    setFileSending(true);

    const MAX_SIZE = 5 * 1024 * 1024; // 5 MB
    if (file.size > MAX_SIZE) {
      alert('File is too large. Maximum 5 MB allowed.');
      setFileSending(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
      return;
    }

    // Convert to base64 data URL (stored in message content as [FILE:name:base64])
    const reader = new FileReader();
    reader.onload = async () => {
      const dataUrl = reader.result as string;
      const content = `[FILE:${file.name}:${dataUrl}]`;
      await supabase.from('secure_chat_messages').insert({
        from_pin: myProfile.pin_code,
        to_pin: activeContact.contact_pin,
        content,
        is_read: false,
        is_deleted: false,
      }).select().single().then(({ data }) => {
        if (data) {
          setMessages(prev => [...prev, { ...(data as Message), content }]);
        }
      });
      setFileSending(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
    };
    reader.readAsDataURL(file);
  }, [myProfile, activeContact]);

  // ── Voice message recording ───────────────────────────────────────────────
  const startRecording = useCallback(async () => {
    if (!myProfile || !activeContact) return;
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mr = new MediaRecorder(stream, { mimeType: MediaRecorder.isTypeSupported('audio/webm') ? 'audio/webm' : 'audio/ogg' });
      audioChunksRef.current = [];
      mr.ondataavailable = e => { if (e.data.size > 0) audioChunksRef.current.push(e.data); };
      mr.onstop = async () => {
        stream.getTracks().forEach(t => t.stop());
        setVoiceSending(true);
        const blob = new Blob(audioChunksRef.current, { type: mr.mimeType });
        const reader = new FileReader();
        reader.onload = async () => {
          const dataUrl = reader.result as string;
          const content = `[VOICE:${dataUrl}]`;
          const { data } = await supabase.from('secure_chat_messages').insert({
            from_pin: myProfile.pin_code, to_pin: activeContact.contact_pin,
            content, is_read: false, is_deleted: false,
          }).select().single();
          if (data) setMessages(prev => [...prev, { ...(data as Message), content }]);
          setVoiceSending(false);
        };
        reader.readAsDataURL(blob);
      };
      mr.start();
      mediaRecorderRef.current = mr;
      setRecording(true);
    } catch { /* mic denied */ }
  }, [myProfile, activeContact]);

  const stopRecording = useCallback(() => {
    mediaRecorderRef.current?.stop();
    mediaRecorderRef.current = null;
    setRecording(false);
  }, []);

  // ── Avatar upload ─────────────────────────────────────────────────────────
  const handleAvatarUpload = useCallback(async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !myProfile) return;
    if (file.size > 2 * 1024 * 1024) { alert('Max 2 MB for profile picture.'); return; }
    const reader = new FileReader();
    reader.onload = async () => {
      const dataUrl = reader.result as string;
      await supabase.from('secure_chat_pins').update({ avatar_url: dataUrl }).eq('pin_code', myProfile.pin_code);
      setMyProfile(p => p ? { ...p, avatar_url: dataUrl } : p);
    };
    reader.readAsDataURL(file);
    if (avatarUploadRef.current) avatarUploadRef.current.value = '';
  }, [myProfile]);

  // ── Save ad ───────────────────────────────────────────────────────────────
  const handleSaveAd = useCallback(async () => {
    if (!myProfile) return;
    await supabase.from('secure_chat_pins').update({ ad_text: adInput.trim() || null, ad_enabled: adEnabled }).eq('pin_code', myProfile.pin_code);
    setMyProfile(p => p ? { ...p, ad_text: adInput.trim() || null, ad_enabled: adEnabled } : p);
    setAdPanelOpen(false);
  }, [myProfile, adInput, adEnabled]);

  // ── Flash ad when sending message ─────────────────────────────────────────
  const flashAdForContact = useCallback((contact: Contact) => {
    const ad = (contact.profile as PinProfile)?.ad_text;
    const enabled = (contact.profile as PinProfile)?.ad_enabled;
    const paidUntil = (contact.profile as PinProfile)?.ad_paid_until;
    const isPaid = paidUntil && new Date(paidUntil) > new Date();
    if (ad && enabled && isPaid) {
      setFlashAd(ad);
      setTimeout(() => setFlashAd(null), 4000);
    }
  }, []);

  // ── Ad slideshow ticker ───────────────────────────────────────────────────
  const activeAds = contacts.filter(c => c.profile?.ad_enabled && c.profile?.ad_text && c.profile?.ad_paid_until && new Date(c.profile.ad_paid_until) > new Date());
  useEffect(() => {
    if (activeAds.length < 2) return;
    const t = setInterval(() => setAdSlideIndex(i => (i + 1) % activeAds.length), 4000);
    return () => clearInterval(t);
  }, [activeAds.length]);

  // ── PIN reveal: in-app PIN keypad (WebAuthn not reliable on Android without pre-registered passkeys)
  const [pinKeypadInput, setPinKeypadInput] = useState('');
  const [pinKeypadError, setPinKeypadError] = useState('');

  const handlePinKeypadPress = useCallback((digit: string) => {
    setPinKeypadInput(prev => {
      const next = prev.length < 5 ? prev + digit : prev;
      if (next.length === 5) {
        // Auto-verify on 5th digit
        if (next === myProfile?.pin_code) {
          setPinRevealed(true);
          setPinRevealOpen(false);
          setPinKeypadInput('');
          setPinKeypadError('');
          // Offer to save fingerprint if biometrics available and no passkey saved yet
          if (biometricAvailable && !myProfile?.passkey_credential_id) {
            setTimeout(() => setShowPasskeyOffer(true), 400);
          }
        } else {
          setPinKeypadError('Incorrect code. Please try again.');
          setTimeout(() => { setPinKeypadInput(''); setPinKeypadError(''); }, 900);
        }
      }
      return next;
    });
  }, [myProfile, biometricAvailable]);

  // ── PIN reveal: AI voice (Life Assistant) ───────────────────────────────
  const handleVoicePinReveal = useCallback(() => {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const SR = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SR) {
      setVoiceStatus('Stemherkenning niet beschikbaar op dit apparaat.');
      return;
    }
    setVoiceVerifying(true);
    setVoiceStatus('Aippie AI spreekt...');

    const startListening = () => {
      setVoiceStatus('Zeg nu jouw 5-cijferige code...');
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      const recognition = new SR() as any;
      recognition.lang = 'nl-NL';
      recognition.continuous = false;
      recognition.interimResults = false;
      recognition.maxAlternatives = 5;
      recognition.onresult = (e: SpeechRecognitionEvent) => {
        const dutchDigits: Record<string, string> = {
          nul:'0', een:'1', twee:'2', drie:'3', vier:'4',
          vijf:'5', zes:'6', zeven:'7', acht:'8', negen:'9',
          zero:'0', one:'1', two:'2', three:'3', four:'4',
          five:'5', six:'6', seven:'7', eight:'8', nine:'9',
        };
        let matched = false;
        for (let i = 0; i < e.results[0].length; i++) {
          const transcript = e.results[0][i].transcript.toLowerCase().trim();
          const digits = transcript.replace(/[^0-9]/g, '');
          const words = transcript.split(/\s+/);
          const fromWords = words.map((w: string) => dutchDigits[w] ?? w.replace(/[^0-9]/g, '')).join('');
          if (digits === myProfile?.pin_code || fromWords === myProfile?.pin_code) {
            matched = true; break;
          }
        }
        if (matched) {
          setVoiceStatus('Code recognized!');
          setTimeout(() => { setPinRevealed(true); setPinRevealOpen(false); }, 600);
        } else {
          setVoiceStatus('Code not recognized. Please try again.');
        }
        setVoiceVerifying(false);
      };
      recognition.onerror = () => {
        setVoiceStatus('Recognition failed. Please try again.');
        setVoiceVerifying(false);
      };
      try { recognition.start(); } catch { setVoiceStatus('Kan microfoon niet starten.'); setVoiceVerifying(false); }
    };

    if (window.speechSynthesis) {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance('Vertel me jouw geheime code om je identiteit te bevestigen.');
      utterance.lang = 'nl-NL';
      utterance.rate = 0.9;
      utterance.onend = startListening;
      utterance.onerror = startListening; // if TTS fails, still start listening
      window.speechSynthesis.speak(utterance);
    } else {
      startListening();
    }
  }, [myProfile]);

  // ── Wallet: open panel & load balance ────────────────────────────────────
  const openWalletPanel = useCallback(async () => {
    setWalletPanelOpen(true);
    setWalletFeedback(null);
    setWalletAmt('');
    if (!user) return;
    const { data } = await supabase.from('apc_wallets').select('balance_apc').eq('user_id', user.id).maybeSingle();
    setWalletBalance(data?.balance_apc ?? 0);
  }, [user]);

  const handleWalletSend = useCallback(async () => {
    if (!activeContact || !walletAmt || walletBusy) return;
    const amount = parseFloat(walletAmt);
    if (isNaN(amount) || amount <= 0) { setWalletFeedback({ ok: false, msg: 'Enter a valid amount.' }); return; }
    setWalletBusy(true);
    setWalletFeedback(null);
    const { data, error } = await supabase.rpc('apc_transfer_by_chat_pin', {
      p_to_pin: activeContact.pin_code,
      p_amount: amount,
    });
    setWalletBusy(false);
    if (error || !data?.ok) {
      setWalletFeedback({ ok: false, msg: error?.message ?? data?.error ?? 'Betaling mislukt.' });
      return;
    }
    setWalletBalance(b => b !== null ? b - amount : b);
    setWalletFeedback({ ok: true, msg: `${amount} APC sent to ${activeContact.nickname || activeContact.pin_code}` });
    // Send a chat message showing the payment
    const payMsg = `[APC Betaling] Ik heb ${amount} APC naar jou gestuurd via Aippie Wallet.`;
    setInput(payMsg);
    setTimeout(() => { handleSend(); }, 100);
    setTimeout(() => setWalletPanelOpen(false), 1800);
  }, [activeContact, walletAmt, walletBusy, user]);

  // ── Save bg color ─────────────────────────────────────────────────────────
  const handleSaveBgColor = useCallback(async (color: string) => {
    if (!myProfile) return;
    await supabase.from('secure_chat_pins').update({ bg_color: color }).eq('pin_code', myProfile.pin_code);
    setMyProfile(p => p ? { ...p, bg_color: color } : p);
    setBgColorPickerOpen(false);
  }, [myProfile]);

  // ── Emoji reaction ────────────────────────────────────────────────────────
  const handleReact = async (messageId: string, emoji: string) => {
    if (!myProfile) return;
    setEmojiPickerMsgId(null); setContextMenu(null);
    const existing = (reactions[messageId] ?? []).find(r => r.from_pin === myProfile.pin_code);
    if (existing?.emoji === emoji) {
      await supabase.from('secure_chat_reactions').delete().eq('id', existing.id);
      setReactions(prev => ({ ...prev, [messageId]: (prev[messageId] ?? []).filter(r => r.id !== existing.id) }));
    } else {
      if (existing) await supabase.from('secure_chat_reactions').delete().eq('id', existing.id);
      const { data } = await supabase.from('secure_chat_reactions')
        .insert({ message_id: messageId, from_pin: myProfile.pin_code, emoji })
        .select().single();
      if (data) {
        setReactions(prev => ({
          ...prev,
          [messageId]: [...(prev[messageId] ?? []).filter(r => r.from_pin !== myProfile.pin_code), data as Reaction],
        }));
      }
    }
    channelRef.current?.send({ type: 'broadcast', event: 'reaction', payload: { messageId } });
  };

  // ── Delete for everyone ───────────────────────────────────────────────────
  const handleDeleteForEveryone = async (msg: Message) => {
    if (!myProfile) return;
    setContextMenu(null);
    await supabase.from('secure_chat_messages').update({ is_deleted: true, content: '[deleted]' }).eq('id', msg.id);
    setMessages(prev => prev.filter(m => m.id !== msg.id));
    channelRef.current?.send({ type: 'broadcast', event: 'delete', payload: { messageId: msg.id } });
  };

  // ── Vanish timer change ───────────────────────────────────────────────────
  const handleVanishTimerChange = async (value: number) => {
    if (!myProfile || !activeContact) return;
    setVanishPickerOpen(false);
    setVanishTimer(value); vanishTimerRef.current = value;
    await supabase.from('secure_chat_contacts').update({ vanish_timer: value }).eq('id', activeContact.id);
    setActiveContact(p => p ? { ...p, vanish_timer: value } : p);
  };

  // ── Long press / context menu ─────────────────────────────────────────────
  const startLongPress = (msg: Message) => {
    longPressTimer.current = setTimeout(() => { setContextMenu({ msg }); setEmojiPickerMsgId(null); }, 480);
  };
  const cancelLongPress = () => {
    if (longPressTimer.current) { clearTimeout(longPressTimer.current); longPressTimer.current = null; }
  };

  // ── Emergency Kill Switch ─────────────────────────────────────────────────
  const handleKillSwitch = async () => {
    if (!user || !myProfile || killSwitchInput !== 'WIPE') return;
    setKillSwitchWorking(true);
    try {
      await clearKeys(myProfile.pin_code).catch(() => {});
      await supabase.from('secure_chat_messages').update({ is_deleted: true, content: '[deleted]' })
        .or(`from_pin.eq.${myProfile.pin_code},to_pin.eq.${myProfile.pin_code}`);
      await supabase.from('secure_chat_contacts').delete().eq('owner_pin', myProfile.pin_code);
      await supabase.from('secure_chat_pins').delete().eq('user_id', user.id);
      await supabase.auth.signOut();
    } catch { /* sign out regardless */ }
    channelRef.current?.unsubscribe();
    setMyProfile(null); setMessages([]); setContacts([]);
    setKillSwitchOpen(false); setScreen('setup');
  };

  // ── Toggles ───────────────────────────────────────────────────────────────
  const toggleGhostMode = async () => {
    if (!myProfile) return;
    const next = !myProfile.ghost_mode;
    await supabase.from('secure_chat_pins').update({ ghost_mode: next }).eq('pin_code', myProfile.pin_code);
    setMyProfile(p => p ? { ...p, ghost_mode: next } : p);
  };

  const toggleAppearOffline = async () => {
    if (!activeContact) return;
    const next = !activeContact.appear_offline_to;
    await supabase.from('secure_chat_contacts').update({ appear_offline_to: next }).eq('id', activeContact.id);
    setActiveContact(p => p ? { ...p, appear_offline_to: next } : p);
    setContacts(prev => prev.map(c => c.id === activeContact.id ? { ...c, appear_offline_to: next } : c));
  };

  const copyPin = () => {
    if (!myProfile) return;
    navigator.clipboard.writeText(myProfile.pin_code);
    setPinCopied(true); setTimeout(() => setPinCopied(false), 2000);
  };

  const goBack = () => {
    channelRef.current?.unsubscribe();
    setMessages([]); setActiveContact(null); setReplyTo(null);
    setEmojiPickerMsgId(null); setContextMenu(null); setReactions({});
    setScreen('contacts');
  };

  const isMyMsg = (m: Message) => m.from_pin === myProfile?.pin_code;

  // ── Guard: not signed in — inline auth gate ──────────────────────────────
  if (!user) {
    return <SecureChatAuthGate />;
  }

  if (screen === 'loading') {
    return <div className="scc-root"><div className="scc-empty"><span className="modal__spinner" /></div></div>;
  }

  // ── Guardian challenge ────────────────────────────────────────────────────
  if (screen === 'guardian_challenge') {
    return (
      <div className="scc-root">
        <div className="scc-guardian">
          <div className="scc-guardian__icon-wrap"><div className="scc-guardian__icon-ring"><Eye size={34} className="scc-guardian__icon" /></div></div>
          <h2 className="scc-guardian__title">Guardian AI Checkpoint</h2>
          <p className="scc-guardian__sub">Do you have authorized access to this secure vault?</p>
          <p className="scc-guardian__prompt">Enter your 5-digit Aippie PIN to continue.</p>
          {strikeCount > 0 && (
            <div className="scc-guardian__strikes">
              {[0,1,2].map(i => <div key={i} className={`scc-guardian__strike-dot${i < strikeCount ? ' scc-guardian__strike-dot--filled' : ''}`} />)}
              <span className="scc-guardian__strikes-label">{strikeCount}/3 failed attempts</span>
            </div>
          )}
          <input
            className="scc-text-input scc-text-input--pin scc-text-input--guardian"
            placeholder="Enter your PIN..."
            type="password"
            value={guardianInput}
            onChange={e => setGuardianInput(e.target.value.replace(/\D/g, '').slice(0, 5))}
            maxLength={5} inputMode="numeric" autoFocus
            onKeyDown={e => { if (e.key === 'Enter' && guardianInput.length === 5) handleGuardianVerify(); }}
          />
          {guardianError && <p className="scc-error scc-guardian__error">{guardianError}</p>}
          <button className="scc-primary-btn" onClick={handleGuardianVerify} disabled={guardianInput.length !== 5}>
            <ShieldCheck size={16} /> Verify Identity
          </button>
          {biometricAvailable && (
            <button className="scc-guardian__biometric-btn" onClick={handleBiometricUnlock}>
              <Fingerprint size={20} /><span>Use Biometric (Face/Touch ID)</span>
            </button>
          )}
          <button className="scc-guardian__cancel" onClick={() => setScreen('contacts')}><ArrowLeft size={14} /> Go back</button>
          <button
            style={{
              marginTop: 8, padding: '9px 20px',
              background: 'rgba(56,189,248,0.08)',
              border: '1px solid rgba(56,189,248,0.2)',
              borderRadius: 10, color: '#38bdf8',
              fontSize: 12, fontWeight: 600, cursor: 'pointer',
              display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6,
              width: '100%',
            }}
            onClick={() => { setScreen('contacts'); setGuardianInput(''); setGuardianError(''); setStrikeCount(0); }}
          >
            <ArrowLeft size={13} /> Return to Main Chat &amp; Menu
          </button>
          <div className="scc-guardian__warning"><AlertTriangle size={12} /><span>3 failed attempts will trigger a 5-minute lockdown.</span></div>
        </div>
      </div>
    );
  }

  // ── Lockdown ──────────────────────────────────────────────────────────────
  if (screen === 'lockdown') {
    const minutes = Math.floor(lockdownSeconds / 60);
    const seconds = lockdownSeconds % 60;
    const progress = lockdownUntil ? Math.max(0, (lockdownUntil.getTime() - Date.now()) / (5 * 60 * 1000)) : 0;
    return (
      <div className="scc-root">
        <div className="scc-lockdown">
          <div className="scc-lockdown__icon-wrap">
            <div className="scc-lockdown__pulse-ring" /><div className="scc-lockdown__pulse-ring scc-lockdown__pulse-ring--2" />
            <ShieldOff size={42} className="scc-lockdown__icon" />
          </div>
          <h2 className="scc-lockdown__title">Vault Locked</h2>
          <p className="scc-lockdown__sub">Guardian AI detected 3 consecutive unauthorized access attempts.</p>
          <div className="scc-lockdown__timer-wrap">
            <div className="scc-lockdown__timer-label">Auto-unlock in</div>
            <div className="scc-lockdown__timer">{String(minutes).padStart(2,'0')}:{String(seconds).padStart(2,'0')}</div>
            <div className="scc-lockdown__progress-track"><div className="scc-lockdown__progress-fill" style={{ width: `${(1 - progress) * 100}%` }} /></div>
          </div>
          {biometricAvailable && (
            <div className="scc-lockdown__biometric-section">
              <p className="scc-lockdown__biometric-label">Or unlock immediately with biometrics:</p>
              <button className="scc-guardian__biometric-btn" onClick={handleBiometricUnlock}>
                <Fingerprint size={20} /><span>Unlock with Face/Touch ID</span>
              </button>
              {postLoginAttempts > 0 && (
                <p className="scc-error" style={{ marginTop: 8, fontSize: 12 }}>
                  Biometric failed {postLoginAttempts}/3 times.{postLoginAttempts >= 2 && ' Next failure extends lockdown to 15 minutes.'}
                </p>
              )}
            </div>
          )}
          <div className="scc-lockdown__event-log">
            <div className="scc-lockdown__log-title"><AlertTriangle size={12} /> Security Event Log</div>
            <div className="scc-lockdown__log-row"><span className="scc-lockdown__log-time">{new Date().toLocaleTimeString()}</span><span>3 failed PIN attempts — vault locked</span></div>
            <div className="scc-lockdown__log-row"><span className="scc-lockdown__log-time">Guardian AI</span><span>Unauthorized access blocked</span></div>
          </div>
          <div className="scc-lockdown__footer"><Lock size={11} /><span>Protected by Guardian AI</span></div>
        </div>
      </div>
    );
  }

  // ── Setup ─────────────────────────────────────────────────────────────────
  if (screen === 'setup') {
    return (
      <div className="scc-root">
        <div className="scc-setup">
          <div className="scc-setup__icon-wrap"><ShieldCheck size={38} className="scc-setup__icon" /></div>
          <h2 className="scc-setup__title">Aippie SecureChat</h2>
          <p className="scc-setup__sub">Privacy-first messaging. No phone number required — connect by PIN code.</p>
          <div className="scc-pin-preview">
            <span className="scc-pin-preview__label">Your PIN</span>
            <span className="scc-pin-preview__value">{setupPin}</span>
            <button className="scc-pin-preview__regen" onClick={() => setSetupPin(generatePin())}><RefreshCw size={14} /></button>
          </div>
          <input className="scc-text-input" placeholder="Your display name..." value={setupName} onChange={e => setSetupName(e.target.value)} maxLength={30} onKeyDown={e => { if (e.key === 'Enter') handleSetup(); }} />
          {setupError && <p className="scc-error">{setupError}</p>}
          <button className="scc-primary-btn" onClick={handleSetup} disabled={!setupName.trim()}><Shield size={16} /> Activate Secure Chat</button>
          <div className="scc-feature-grid">
            {[
              { icon: <Clock size={13} />, label: 'Messages vanish in 32s' },
              { icon: <Shield size={13} />, label: 'Screenshot protection' },
              { icon: <Globe size={13} />, label: 'AI live translation' },
              { icon: <Zap size={13} />, label: 'Add by PIN code' },
              { icon: <Ghost size={13} />, label: 'Ghost mode' },
              { icon: <EyeOff size={13} />, label: 'Selective offline' },
            ].map(f => <span key={f.label} className="scc-feature-badge">{f.icon} {f.label}</span>)}
          </div>
        </div>
      </div>
    );
  }

  // ── Add contact ───────────────────────────────────────────────────────────
  if (screen === 'add_contact') {
    return (
      <div className="scc-root">
        <div className="scc-topbar"><button className="scc-back-btn" onClick={() => setScreen('contacts')}><ArrowLeft size={18} /></button><span className="scc-topbar__title">Add Contact by PIN</span></div>
        <div className="scc-add-form">
          <div className="scc-add-form__icon"><UserPlus size={34} /></div>
          <p className="scc-add-form__desc">Ask your contact for their 5-digit Aippie PIN. No phone number or email needed.</p>
          <input className="scc-text-input scc-text-input--pin" placeholder="Enter 5-digit PIN..." value={addPinInput} onChange={e => setAddPinInput(e.target.value.replace(/\D/g, '').slice(0, 5))} maxLength={5} inputMode="numeric" autoFocus />
          <input className="scc-text-input" placeholder="Nickname (optional)..." value={addNickInput} onChange={e => setAddNickInput(e.target.value)} maxLength={20} />
          {addError && <p className="scc-error">{addError}</p>}
          <button className="scc-primary-btn" onClick={handleAddContact} disabled={addPinInput.length !== 5}><Plus size={16} /> Add Contact</button>
          <div className="scc-my-pin-share">
            <span>Share your PIN:</span><strong className="scc-my-pin-share__pin">{myProfile?.pin_code}</strong>
            <button className="scc-copy-btn" onClick={copyPin}>{pinCopied ? <Check size={13} /> : <Copy size={13} />}</button>
          </div>
        </div>
      </div>
    );
  }

  // ── Contacts list ─────────────────────────────────────────────────────────
  if (screen === 'contacts') {
    const bgStyle = myProfile?.bg_color
      ? { background: myProfile.bg_color }
      : {};
    return (
      <div className="scc-root" style={bgStyle}>
        <div className="scc-topbar scc-topbar--contacts">
          <div className="scc-topbar__identity">
            {/* Avatar with upload */}
            <div className="scc-avatar-upload-wrap" onClick={() => avatarUploadRef.current?.click()}>
              {myProfile?.avatar_url
                ? <img src={myProfile.avatar_url} className="scc-avatar scc-avatar--lg scc-avatar--photo" alt="profile" />
                : <div className="scc-avatar scc-avatar--lg" style={{ background: myProfile?.avatar_color }}>{getInitials(myProfile?.display_name ?? '?')}</div>
              }
              <div className="scc-avatar-upload-hint"><Camera size={10} /></div>
            </div>
            <input ref={avatarUploadRef} type="file" accept="image/*" style={{ display: 'none' }} onChange={handleAvatarUpload} />
            <div>
              <div className="scc-topbar__name">
                {myProfile?.display_name}
                {myProfile?.country_code && <span className="scc-flag">{countryFlag(myProfile.country_code)}</span>}
                {myProfile?.verified_type === 'gold' && <span className="scc-verified-badge scc-verified-badge--gold" title="Geverifieerd persoon">★</span>}
                {myProfile?.verified_type === 'platinum' && <span className="scc-verified-badge scc-verified-badge--platinum" title="Geverifieerd bedrijf">✦</span>}
              </div>
              {/* PIN hidden by default — tap lock to reveal */}
              <button className="scc-topbar__pin" onClick={() => { if (pinRevealed) { copyPin(); } else { setPinRevealOpen(true); } }}>
                {pinRevealed
                  ? <><strong>{myProfile?.pin_code}</strong>{pinCopied ? <Check size={11} /> : <Copy size={11} />}</>
                  : <><Lock size={11} /> <span style={{ letterSpacing: 2 }}>•••••</span> <span style={{ fontSize: 10, opacity: 0.7 }}>(tik om te onthullen)</span></>
                }
              </button>
            </div>
          </div>
          <div className="scc-topbar__actions">
            <button className="scc-icon-btn scc-icon-btn--world" onClick={() => setShow3D(true)} title="Aippie Virtual World">
              🌐
            </button>
            {onOpenLifeAssist && (
              <button
                className={`scc-icon-btn scc-icon-btn--lifeai${lifeAiBubbleOpen ? ' scc-icon-btn--active' : ''}`}
                onClick={() => { setLifeAiBubbleOpen(v => !v); setLifeAiMinimized(false); }}
                title="Life Assistant"
              >
                <BrainCircuit size={15} />{lifeAiBubbleOpen && <span className="scc-active-dot" />}
              </button>
            )}
            <button className="scc-icon-btn scc-icon-btn--bgpick" onClick={() => setBgColorPickerOpen(true)} title="Achtergrond"><Image size={14} /></button>
            <button className="scc-icon-btn scc-icon-btn--ad" onClick={() => setAdPanelOpen(true)} title="Mijn reclame"><Megaphone size={15} />{myProfile?.ad_enabled && <span className="scc-active-dot" />}</button>
            <button className={`scc-icon-btn${myProfile?.ghost_mode ? ' scc-icon-btn--active' : ''}`} onClick={toggleGhostMode} title="Ghost mode">
              <Ghost size={16} />{myProfile?.ghost_mode && <span className="scc-active-dot" />}
            </button>
            <button className="scc-icon-btn scc-icon-btn--add" onClick={() => setScreen('add_contact')}><UserPlus size={16} /></button>
            <button className="scc-icon-btn scc-icon-btn--kill" onClick={() => { setKillSwitchOpen(true); setKillSwitchInput(''); }} title="Emergency Kill Switch"><Skull size={15} /></button>
          </div>
        </div>

        {killSwitchOpen && (
          <div className="scc-kill-overlay" onClick={() => setKillSwitchOpen(false)}>
            <div className="scc-kill-modal" onClick={e => e.stopPropagation()}>
              <div className="scc-kill-modal__icon-wrap"><div className="scc-kill-modal__pulse" /><Skull size={34} className="scc-kill-modal__icon" /></div>
              <h2 className="scc-kill-modal__title">Emergency Kill Switch</h2>
              <p className="scc-kill-modal__sub">This will permanently and irreversibly wipe your entire secure vault:</p>
              <ul className="scc-kill-modal__list">
                <li>All E2EE private keys (IndexedDB)</li><li>All messages (both sides)</li>
                <li>All contacts and chat history</li><li>Your Aippie PIN profile</li><li>Your session (signed out)</li>
              </ul>
              <p className="scc-kill-modal__confirm-label">Type <strong>WIPE</strong> to confirm zero-trace destruction:</p>
              <input className="scc-text-input scc-kill-modal__input" placeholder="Type WIPE..." value={killSwitchInput} onChange={e => setKillSwitchInput(e.target.value.toUpperCase())} maxLength={4} autoFocus />
              <div className="scc-kill-modal__actions">
                <button className="scc-kill-modal__btn-cancel" onClick={() => setKillSwitchOpen(false)} disabled={killSwitchWorking}>Cancel</button>
                <button className="scc-kill-modal__btn-wipe" onClick={handleKillSwitch} disabled={killSwitchInput !== 'WIPE' || killSwitchWorking}>
                  {killSwitchWorking ? <><RefreshCw size={14} className="scc-spin" /> Wiping…</> : <><Skull size={14} /> Execute Wipe</>}
                </button>
              </div>
            </div>
          </div>
        )}

        {/* ── Ad slideshow banner ── */}
        {activeAds.length > 0 && (
          <div className="scc-ad-slideshow">
            <div className="scc-ad-slideshow__badge"><Megaphone size={11} /> Advertentie</div>
            <div className="scc-ad-slideshow__content">
              {activeAds[adSlideIndex % activeAds.length]?.profile?.avatar_url
                ? <img src={activeAds[adSlideIndex % activeAds.length].profile!.avatar_url!} className="scc-ad-slideshow__avatar" alt="" />
                : <div className="scc-ad-slideshow__avatar-placeholder" style={{ background: activeAds[adSlideIndex % activeAds.length]?.profile?.avatar_color }}>{getInitials(activeAds[adSlideIndex % activeAds.length]?.profile?.display_name ?? '?')}</div>
              }
              <div className="scc-ad-slideshow__text">
                <span className="scc-ad-slideshow__name">
                  {activeAds[adSlideIndex % activeAds.length]?.profile?.display_name}
                  {activeAds[adSlideIndex % activeAds.length]?.profile?.country_code && <span className="scc-flag">{countryFlag(activeAds[adSlideIndex % activeAds.length].profile!.country_code!)}</span>}
                </span>
                <span className="scc-ad-slideshow__msg">{activeAds[adSlideIndex % activeAds.length]?.profile?.ad_text}</span>
              </div>
            </div>
            {activeAds.length > 1 && (
              <div className="scc-ad-slideshow__dots">
                {activeAds.map((_, i) => <span key={i} className={`scc-ad-slideshow__dot${i === adSlideIndex % activeAds.length ? ' scc-ad-slideshow__dot--active' : ''}`} />)}
              </div>
            )}
          </div>
        )}

        <div className="scc-pin-rotation-bar">
          <Clock size={11} />
          <span>PIN rotates in {(() => {
            if (!myProfile) return '—';
            const exp = (myProfile as PinProfile & { pin_expires_at?: string }).pin_expires_at;
            if (!exp) return '7 days';
            const days = Math.max(0, Math.ceil((new Date(exp).getTime() - Date.now()) / 86400000));
            return days === 0 ? 'today' : `${days}d`;
          })()} · Auto-rotation keeps your identity secure</span>
          {onStartVideoCall && <button className="scc-videocall-shortcut" onClick={onStartVideoCall}><Video size={11} /> Video Vault</button>}
        </div>

        <div className="scc-shield-bar">
          <ShieldCheck size={13} />
          <span>E2E Protected · Vanish Timer · Screenshot Blocked · AI Translation</span>
        </div>

        <div className="scc-contacts-list">
          {contacts.length === 0 ? (
            <div className="scc-empty-contacts">
              <MessageCircle size={44} className="scc-empty-contacts__icon" />
              <p className="scc-empty-contacts__title">No contacts yet</p>
              <p className="scc-empty-contacts__sub">Add someone using their 5-digit PIN code</p>
              <button className="scc-primary-btn scc-primary-btn--sm" onClick={() => setScreen('add_contact')}><Plus size={14} /> Add First Contact</button>
            </div>
          ) : (
            contacts.map(c => {
              const name = c.nickname ?? c.profile?.display_name ?? c.contact_pin;
              const meta = contactMeta[c.contact_pin];
              const unread = meta?.unreadCount ?? 0;
              const lastSeenRaw = c.profile?.last_seen_at;
              const isOnline = !c.profile?.ghost_mode && !c.appear_offline_to && lastSeenRaw && (Date.now() - new Date(lastSeenRaw).getTime()) < 120000;
              const lastSeenStr = lastSeenRaw ? formatLastSeen(lastSeenRaw) : null;
              const flag = c.profile?.country_code ? countryFlag(c.profile.country_code) : null;
              const hasAd = c.profile?.ad_enabled && c.profile?.ad_text;
              return (
                <button
                  key={c.id}
                  className="scc-contact-row"
                  onClick={() => { setActiveContact(c); openConversation(c); prevScreenRef.current = 'chat'; requireGuardian('chat'); }}
                >
                  {/* Long-press/right-click to view profile */}
                  <div className="scc-avatar-wrap" onContextMenu={e => { e.preventDefault(); e.stopPropagation(); setProfileView({ contact: c, pinInput: '', revealed: false }); }}>
                    {c.profile?.avatar_url
                      ? <img src={c.profile.avatar_url} className="scc-avatar scc-avatar--photo" alt={name} />
                      : <div className="scc-avatar" style={{ background: c.profile?.avatar_color ?? '#475569' }}>{getInitials(name)}</div>
                    }
                    {isOnline && <span className="scc-avatar-online" />}
                  </div>
                  <div className="scc-contact-row__info">
                    <div className="scc-contact-row__top">
                      <span className="scc-contact-row__name">
                        {name}
                        {flag && <span className="scc-flag">{flag}</span>}
                        {hasAd && <span className="scc-ad-dot" title="Heeft reclame"><Megaphone size={10} /></span>}
                        {c.profile?.verified_type === 'gold' && <span className="scc-verified-badge scc-verified-badge--gold" title="Geverifieerd persoon">★</span>}
                        {c.profile?.verified_type === 'platinum' && <span className="scc-verified-badge scc-verified-badge--platinum" title="Geverifieerd bedrijf">✦</span>}
                      </span>
                      <span className="scc-contact-row__time">{meta ? timeAgo(meta.lastAt) : lastSeenStr ? lastSeenStr : ''}</span>
                    </div>
                    <div className="scc-contact-row__bottom">
                      {meta ? (
                        <span className={`scc-contact-row__preview${unread > 0 ? ' scc-contact-row__preview--unread' : ''}`}>{meta.lastContent}</span>
                      ) : (
                        <span className="scc-contact-row__status">
                          {c.appear_offline_to ? <><EyeOff size={11} /> Verborgen voor hem/haar</> : c.profile?.ghost_mode ? <><Ghost size={11} /> Ghost mode</> : isOnline ? <><span className="scc-online-dot" /> Online nu</> : lastSeenStr ? <><MapPin size={10} /> Laatst gezien {lastSeenStr}</> : <><span className="scc-online-dot" /> Geen berichten</>}
                        </span>
                      )}
                      {unread > 0 && <span className="scc-unread-badge">{unread > 9 ? '9+' : unread}</span>}
                    </div>
                    {hasAd && <div className="scc-contact-ad">{c.profile!.ad_text}</div>}
                  </div>
                </button>
              );
            })
          )}
        </div>

        {/* ── Aippie World banner ── */}
        <button className="scc-world-banner" onClick={() => setShow3D(true)}>
          <div className="scc-world-banner__glow" />
          <div className="scc-world-banner__left">
            <span className="scc-world-banner__icon">🌐</span>
            <div>
              <div className="scc-world-banner__title">Aippie Virtual World</div>
              <div className="scc-world-banner__sub">6 zones · APC coins · Avatar shop · AI Oracle</div>
            </div>
          </div>
          <span className="scc-world-banner__cta">Betreden →</span>
        </button>

        <div className="scc-coming-soon">
          <span className="scc-coming-soon__label">Nieuw</span>
          {['Groepschats', 'Enkryptie aanwezig', 'Push notificaties'].map(f => (
            <span key={f} className="scc-coming-badge">{f}</span>
          ))}
        </div>

        {/* ── Open World overlay ── */}
        {show3D && myProfile && (
          <AippieOpenWorldView
            displayName={myProfile.display_name}
            avatarColor={myProfile.avatar_color}
            badge={myProfile.verified_type ?? 'none'}
            onClose={() => setShow3D(false)}
            onNavigate={(action) => {
              setShow3D(false);
              window.dispatchEvent(new CustomEvent('aippie:navigate', { detail: action }));
            }}
          />
        )}

        {/* ── Breaking News Ticker ── */}
        <div className={`scc-news-ticker${newsTickerVisible ? ' scc-news-ticker--visible' : ''}`}>
          <div className="scc-news-ticker__inner">
            <div className="scc-news-ticker__live">
              <span className="scc-news-ticker__live-dot" />
              LIVE
            </div>
            <div className="scc-news-ticker__cat">{BREAKING_NEWS[newsTickerIdx].cat}</div>
            <p className="scc-news-ticker__text">{BREAKING_NEWS[newsTickerIdx].text}</p>
            <button className="scc-news-ticker__close" onClick={() => setNewsTickerVisible(false)}>
              <X size={10} />
            </button>
          </div>
        </div>

        {/* ── SOS shake alert ── */}
        {sosAlertActive && (
          <div className="scc-sos-alert" onClick={() => setSosAlertActive(false)}>
            <div className="scc-sos-alert__inner">
              <span className="scc-sos-alert__icon">🆘</span>
              <div>
                <div className="scc-sos-alert__title">SOS Schudden Gedetecteerd</div>
                <div className="scc-sos-alert__sub">Life AI is active. Do you need help?</div>
              </div>
              <button className="scc-sos-alert__dismiss" onClick={() => setSosAlertActive(false)}>OK</button>
            </div>
          </div>
        )}

        {/* ── Floating Life AI Bubble ── */}
        {lifeAiBubbleOpen && onOpenLifeAssist && (
          <div className={`scc-lifeai-bubble${lifeAiMinimized ? ' scc-lifeai-bubble--mini' : ''}`}>
            <div className="scc-lifeai-bubble__header">
              <div className="scc-lifeai-bubble__avatar">
                <BrainCircuit size={14} />
              </div>
              <span className="scc-lifeai-bubble__title">Life AI</span>
              {batteryLevel !== null && (
                <span className={`scc-lifeai-bubble__battery${batteryLevel <= 20 ? ' scc-lifeai-bubble__battery--low' : ''}`}>
                  {batteryCharging ? '⚡' : '🔋'}{batteryLevel}%
                </span>
              )}
              <div className="scc-lifeai-bubble__actions">
                <button
                  className="scc-lifeai-bubble__btn"
                  onClick={() => setLifeAiMinimized(v => !v)}
                  title={lifeAiMinimized ? 'Uitklappen' : 'Minimaliseren'}
                >
                  {lifeAiMinimized ? '▲' : '▼'}
                </button>
                <button
                  className="scc-lifeai-bubble__btn scc-lifeai-bubble__btn--open"
                  onClick={onOpenLifeAssist}
                  title="Open Life Assistant volledig"
                >
                  ↗
                </button>
                <button
                  className="scc-lifeai-bubble__btn scc-lifeai-bubble__btn--close"
                  onClick={() => setLifeAiBubbleOpen(false)}
                  title="Sluiten"
                >
                  <X size={12} />
                </button>
              </div>
            </div>
            {!lifeAiMinimized && (
              <div className="scc-lifeai-bubble__body">
                {lifeAiIncomingMsg ? (
                  <div className="scc-lifeai-bubble__msg scc-lifeai-bubble__msg--ask">
                    🤖 {lifeAiIncomingMsg}
                    <button
                      className="scc-lifeai-bubble__dismiss"
                      onClick={() => setLifeAiIncomingMsg(null)}
                    >✓ OK</button>
                  </div>
                ) : (
                  <div className={`scc-lifeai-bubble__msg scc-lifeai-bubble__msg--${LIFE_AI_MESSAGES[lifeAiMsgIdx].type}`}>
                    {LIFE_AI_MESSAGES[lifeAiMsgIdx].type === 'ask' ? '🤖 ' : '💡 '}
                    {LIFE_AI_MESSAGES[lifeAiMsgIdx].text}
                  </div>
                )}
                {!lifeAiIncomingMsg && (
                  <div className="scc-lifeai-bubble__dots">
                    {LIFE_AI_MESSAGES.map((_, i) => (
                      <span
                        key={i}
                        className={`scc-lifeai-bubble__dot${i === lifeAiMsgIdx ? ' scc-lifeai-bubble__dot--active' : ''}`}
                        onClick={() => setLifeAiMsgIdx(i)}
                      />
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>
        )}

        {/* ── Ad panel ── */}
        {adPanelOpen && (
          <div className="scc-vcall-overlay" onClick={() => setAdPanelOpen(false)}>
            <div className="scc-vcall-dialog" onClick={e => e.stopPropagation()}>
              <div className="scc-vcall-dialog__header"><Megaphone size={20} style={{ color: '#f59e0b' }} /><span>Mijn reclame/advertentie</span></div>
              <p className="scc-vcall-dialog__sub">Jouw bedrijfsreclame wordt zichtbaar voor al je contacten bij het zenden van berichten.</p>
              <textarea
                className="scc-vcall-textarea"
                placeholder="Bijv: &#x0A;Aippie Agency — AI-automatisering voor jouw bedrijf&#x0A;Bel: +31 6 12345678"
                value={adInput}
                onChange={e => setAdInput(e.target.value)}
                maxLength={120}
                rows={3}
              />
              <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 12 }}>
                <label style={{ display: 'flex', alignItems: 'center', gap: 6, color: '#94a3b8', fontSize: 13, cursor: 'pointer' }}>
                  <input type="checkbox" checked={adEnabled} onChange={e => setAdEnabled(e.target.checked)} />
                  Reclame inschakelen
                </label>
              </div>
              {/* Payment status */}
              {myProfile?.ad_paid_until && new Date(myProfile.ad_paid_until) > new Date() ? (
                <div className="scc-ad-paid-status">
                  <Check size={13} style={{ color: '#22c55e' }} />
                  <span>Actief tot {new Date(myProfile.ad_paid_until).toLocaleDateString('nl-NL')}</span>
                </div>
              ) : (
                <div className="scc-ad-paygate">
                  <div className="scc-ad-paygate__price">
                    <span className="scc-ad-paygate__amount">€5</span>
                    <span className="scc-ad-paygate__per">/week</span>
                  </div>
                  <p className="scc-ad-paygate__info">Jouw reclame verschijnt in de slideshow bovenin bij alle contacten die jou hebben opgeslagen. Betaal om te activeren.</p>
                  <button
                    className="scc-vcall-btn scc-vcall-btn--primary scc-ad-pay-btn"
                    onClick={async () => {
                      if (!myProfile) return;
                      // Simulate payment: in production connect to Stripe/checkout
                      const until = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString();
                      await supabase.from('secure_chat_pins').update({ ad_paid_until: until }).eq('pin_code', myProfile.pin_code);
                      setMyProfile(p => p ? { ...p, ad_paid_until: until } : p);
                    }}
                  >Betaal €5 — 1 week activeren</button>
                </div>
              )}
              <div className="scc-vcall-dialog__actions" style={{ marginTop: 12 }}>
                <button className="scc-vcall-btn scc-vcall-btn--cancel" onClick={() => setAdPanelOpen(false)}>Cancel</button>
                <button className="scc-vcall-btn scc-vcall-btn--primary" onClick={handleSaveAd}><Check size={14} /> Opslaan</button>
              </div>
            </div>
          </div>
        )}

        {/* ── PIN reveal dialog ── */}
        {pinRevealOpen && (
          <div className="scc-vcall-overlay" onClick={() => { setPinRevealOpen(false); setVoiceVerifying(false); setVoiceStatus(''); setPinKeypadInput(''); setPinKeypadError(''); }}>
            <div className="scc-vcall-dialog" onClick={e => e.stopPropagation()}>
              <div className="scc-vcall-dialog__header"><Lock size={20} style={{ color: '#38bdf8' }} /><span>Verifieer je identiteit</span></div>
              <p className="scc-vcall-dialog__sub">Use fingerprint, PIN, or voice recognition to view your code.</p>

              {/* Biometric scanner overlay — shown when biometrics available */}
              {biometricAvailable && (
                <div className="bio-scanner-overlay">
                  <div className="bio-scanner-overlay__face">
                    <div className="bio-scanner-overlay__sweep" />
                    <Fingerprint size={42} style={{ color: 'rgba(0,255,157,0.5)', position: 'relative', zIndex: 1 }} />
                  </div>
                  <div className="bio-scanner-overlay__corner bio-scanner-overlay__corner--tl" />
                  <div className="bio-scanner-overlay__corner bio-scanner-overlay__corner--tr" />
                  <div className="bio-scanner-overlay__corner bio-scanner-overlay__corner--bl" />
                  <div className="bio-scanner-overlay__corner bio-scanner-overlay__corner--br" />
                  <div className="bio-scanner-overlay__label">Scanning…</div>
                </div>
              )}

              {/* Biometric / fingerprint button — primary method */}
              {biometricAvailable && (
                <button
                  className="scc-pin-reveal-biometric-btn"
                  onClick={async () => {
                    try {
                      const uvpa = await window.PublicKeyCredential
                        ?.isUserVerifyingPlatformAuthenticatorAvailable?.()
                        .catch(() => false);
                      if (!uvpa) { setBiometricAvailable(false); return; }

                      // Real WebAuthn get — triggers device FaceID/TouchID/Android Biometric
                      const challenge = crypto.getRandomValues(new Uint8Array(32));
                      const credential = await navigator.credentials.get({
                        publicKey: {
                          challenge,
                          timeout: 60000,
                          userVerification: 'required',
                          rpId: window.location.hostname,
                          allowCredentials: [],
                        },
                      }) as PublicKeyCredential | null;

                      if (credential) {
                        setPinRevealed(true);
                        setPinRevealOpen(false);
                        setPinKeypadInput('');
                        setPinKeypadError('');
                      } else {
                        setBiometricAvailable(false);
                      }
                    } catch (err: unknown) {
                      const name = (err as { name?: string })?.name;
                      if (name === 'NotAllowedError') return; // user cancelled — do nothing
                      if (name === 'NotSupportedError' || name === 'InvalidStateError') {
                        setBiometricAvailable(false); return;
                      }
                      setPinKeypadError('Biometrische verificatie mislukt.');
                    }
                  }}
                >
                  <span className="scc-pin-reveal-biometric-btn__icon">&#x1F44B;</span>
                  <span>Vingerafdruk / Face ID</span>
                </button>
              )}

              <div className="scc-pin-reveal-divider"><span>of voer PIN in</span></div>

              {/* PIN keypad */}
              <div className="scc-pin-keypad">
                <div className="scc-pin-keypad__dots">
                  {[0,1,2,3,4].map(i => (
                    <div key={i} className={`scc-pin-keypad__dot${i < pinKeypadInput.length ? ' scc-pin-keypad__dot--filled' : ''}`} />
                  ))}
                </div>
                {pinKeypadError && <p className="scc-pin-keypad__error">{pinKeypadError}</p>}
                <div className="scc-pin-keypad__grid">
                  {pinKeyOrder.map((k, idx) => (
                    k === '' ? <div key={idx} /> :
                    <button key={idx} className="scc-pin-keypad__key"
                      onClick={() => {
                        if (navigator.vibrate) navigator.vibrate(30);
                        k === '⌫' ? setPinKeypadInput(p => p.slice(0,-1)) : handlePinKeypadPress(k);
                      }}>
                      {k}
                    </button>
                  ))}
                </div>
              </div>

              <div className="scc-pin-reveal-divider"><span>of</span></div>

              {/* Voice option */}
              {voiceStatus && <p className={`scc-voice-status${voiceVerifying ? ' scc-voice-status--active' : ''}`}>{voiceStatus}</p>}
              <button className="scc-pin-reveal-voice-btn" onClick={handleVoicePinReveal} disabled={voiceVerifying}>
                <Mic size={16} style={{ color: '#22c55e' }} />
                <span>{voiceVerifying ? 'Listening...' : 'AI Voice Recognition — say your code'}</span>
              </button>

              <button className="scc-vcall-btn scc-vcall-btn--cancel" style={{ marginTop: 12 }} onClick={() => { setPinRevealOpen(false); setVoiceStatus(''); setVoiceVerifying(false); setPinKeypadInput(''); setPinKeypadError(''); }}>Cancel</button>
            </div>
          </div>
        )}

        {/* ── Bg color picker ── */}
        {bgColorPickerOpen && (
          <div className="scc-vcall-overlay" onClick={() => setBgColorPickerOpen(false)}>
            <div className="scc-vcall-dialog" onClick={e => e.stopPropagation()}>
              <div className="scc-vcall-dialog__header"><span>Achtergrondkleur kiezen</span></div>
              <div className="scc-bgpicker">
                {[
                  { label: 'Standaard', value: '' },
                  { label: 'Nacht', value: 'linear-gradient(135deg,#0f172a,#1e293b)' },
                  { label: 'Ocean', value: 'linear-gradient(135deg,#0c4a6e,#0f172a)' },
                  { label: 'Forest', value: 'linear-gradient(135deg,#14532d,#1e293b)' },
                  { label: 'Sunset', value: 'linear-gradient(135deg,#7c2d12,#1e293b)' },
                  { label: 'Paars', value: 'linear-gradient(135deg,#4c1d95,#1e293b)' },
                  { label: 'Goud', value: 'linear-gradient(135deg,#713f12,#1e293b)' },
                  { label: 'Ijs', value: 'linear-gradient(135deg,#164e63,#1e293b)' },
                ].map(opt => (
                  <button key={opt.label} className={`scc-bgpicker__opt${(myProfile?.bg_color ?? '') === opt.value ? ' scc-bgpicker__opt--active' : ''}`} style={{ background: opt.value || '#0f172a' }} onClick={() => handleSaveBgColor(opt.value)}>
                    <span>{opt.label}</span>
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* ── Profile viewer (PIN-protected) ── */}
        {profileView && (
          <div className="scc-vcall-overlay" onClick={() => setProfileView(null)}>
            <div className="scc-vcall-dialog" onClick={e => e.stopPropagation()}>
              <div className="scc-vcall-dialog__header">
                <Shield size={20} style={{ color: '#38bdf8' }} />
                <span>Profiel van {profileView.contact.nickname ?? profileView.contact.profile?.display_name}</span>
              </div>
              {!profileView.revealed ? (
                <>
                  <p className="scc-vcall-dialog__sub">Enter this contact's PIN to view their full profile.</p>
                  <input
                    className="scc-vcall-input"
                    placeholder="PIN..."
                    value={profileView.pinInput}
                    onChange={e => setProfileView(p => p ? { ...p, pinInput: e.target.value.replace(/\D/g,'').slice(0,5) } : null)}
                    inputMode="numeric" maxLength={5}
                  />
                  <div className="scc-vcall-dialog__actions">
                    <button className="scc-vcall-btn scc-vcall-btn--cancel" onClick={() => setProfileView(null)}>Sluiten</button>
                    <button
                      className="scc-vcall-btn scc-vcall-btn--primary"
                      onClick={() => {
                        if (profileView.pinInput === profileView.contact.contact_pin) {
                          setProfileView(p => p ? { ...p, revealed: true } : null);
                        } else {
                          alert('Verkeerde PIN.');
                        }
                      }}
                      disabled={profileView.pinInput.length !== 5}
                    ><Lock size={14} /> Onthullen</button>
                  </div>
                </>
              ) : (
                <div className="scc-profile-revealed">
                  <div className="scc-profile-revealed__avatar">
                    {profileView.contact.profile?.avatar_url
                      ? <img src={profileView.contact.profile.avatar_url} className="scc-profile-big-photo" alt="profile" />
                      : <div className="scc-avatar scc-avatar--xl" style={{ background: profileView.contact.profile?.avatar_color }}>{getInitials(profileView.contact.profile?.display_name ?? '?')}</div>
                    }
                  </div>
                  <h3 className="scc-profile-revealed__name">
                    {profileView.contact.profile?.display_name}
                    {profileView.contact.profile?.country_code && <span className="scc-flag">{countryFlag(profileView.contact.profile.country_code)}</span>}
                  </h3>
                  {profileView.contact.profile?.country_name && (
                    <p className="scc-profile-revealed__location"><MapPin size={12} /> {profileView.contact.profile.country_name}</p>
                  )}
                  {profileView.contact.profile?.last_seen_at && (
                    <p className="scc-profile-revealed__seen"><Clock size={12} /> {formatLastSeen(profileView.contact.profile.last_seen_at)}</p>
                  )}
                  {profileView.contact.profile?.ad_enabled && profileView.contact.profile?.ad_text && (
                    <div className="scc-profile-revealed__ad"><Megaphone size={12} /> {profileView.contact.profile.ad_text}</div>
                  )}
                  <button className="scc-vcall-btn scc-vcall-btn--cancel" style={{ marginTop: 16 }} onClick={() => setProfileView(null)}>Sluiten</button>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    );
  }

  // ── Chat screen ───────────────────────────────────────────────────────────
  const contactName = activeContact ? (activeContact.nickname ?? activeContact.profile?.display_name ?? activeContact.contact_pin) : '';

  return (
    <div className="scc-root" onClick={() => { setContextMenu(null); setEmojiPickerMsgId(null); setVanishPickerOpen(false); }}>
      {/* Passkey offer — shown after successful PIN login if biometrics available */}
      {showPasskeyOffer && myProfile && (
        <div style={{ position: 'fixed', inset: 0, zIndex: 9800, background: 'rgba(3,5,8,0.85)', display: 'flex', alignItems: 'flex-end', justifyContent: 'center', padding: '0 0 32px' }}>
          <div style={{ background: '#0a1628', border: '1px solid rgba(0,255,157,0.25)', borderRadius: 18, padding: '24px 20px', width: '100%', maxWidth: 380, margin: '0 16px', boxShadow: '0 0 40px rgba(0,255,157,0.08)' }} onClick={e => e.stopPropagation()}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 12 }}>
              <Fingerprint size={22} style={{ color: '#00ff9d' }} />
              <span style={{ fontWeight: 700, fontSize: 15, color: '#f1f5f9' }}>Enable fingerprint login?</span>
            </div>
            <p style={{ fontSize: 12, color: '#64748b', marginBottom: 18, lineHeight: 1.5 }}>
              Save your fingerprint / Face ID so you can unlock this view instantly next time — no PIN needed.
            </p>
            <div style={{ display: 'flex', gap: 10 }}>
              <button
                disabled={passkeyOfferWorking}
                onClick={() => { setPasskeyOfferWorking(true); savePasskey(myProfile); }}
                style={{ flex: 1, padding: '11px 0', background: passkeyOfferWorking ? 'rgba(0,255,157,0.06)' : 'rgba(0,255,157,0.1)', border: '1px solid rgba(0,255,157,0.3)', borderRadius: 10, color: '#00ff9d', fontSize: 13, fontWeight: 700, cursor: passkeyOfferWorking ? 'not-allowed' : 'pointer' }}
              >
                {passkeyOfferWorking ? 'Saving…' : 'YES — Save fingerprint'}
              </button>
              <button
                onClick={() => setShowPasskeyOffer(false)}
                style={{ flex: 1, padding: '11px 0', background: 'rgba(100,116,139,0.08)', border: '1px solid rgba(100,116,139,0.2)', borderRadius: 10, color: '#64748b', fontSize: 13, cursor: 'pointer' }}
              >
                NO — Keep PIN
              </button>
            </div>
          </div>
        </div>
      )}

      {/* AippieShield: blackout overlay on tab/window blur */}
      {blurred && (
        <div className="scc-blur-overlay">
          <Shield size={44} style={{ color: '#22d3ee' }} />
          <p>AippieShield active</p>
          <span className="scc-blur-overlay__sub">Scherm beveiligd — terugkeren om berichten te zien</span>
          <div className="scc-shield-badges">
            <span><Lock size={10} /> E2EE</span>
            <span><EyeOff size={10} /> Anti-screenshot</span>
            <span><Skull size={10} /> Auto-wipe</span>
          </div>
        </div>
      )}

      {/* AippieShield Feature 4: Sneak detection alert */}
      {sneakDetected && (
        <div className="scc-sneak-overlay">
          <Camera size={40} className="scc-sneak-overlay__icon" />
          <p className="scc-sneak-overlay__title">Second Face Detected</p>
          <p className="scc-sneak-overlay__sub">Unauthorized viewer detected — closing vault</p>
        </div>
      )}

      <div className={`scc-chat${blurred ? ' scc-chat--blurred' : ''}`}>
        {/* Header */}
        <div className="scc-topbar scc-topbar--chat">
          <button className="scc-back-btn" onClick={goBack}><ArrowLeft size={18} /></button>
          <div className="scc-avatar scc-avatar--sm" style={{ background: activeContact?.profile?.avatar_color ?? '#475569' }}>{getInitials(contactName)}</div>
          <div className="scc-topbar__chat-info">
            <div className="scc-topbar__chat-name">{contactName}</div>
            {contactTyping ? (
              <div className="scc-topbar__chat-sub scc-typing-label">
                <span className="scc-typing-dot" /><span className="scc-typing-dot" /><span className="scc-typing-dot" /> typing…
              </div>
            ) : (
              <div className="scc-topbar__chat-sub">#{activeContact?.contact_pin}</div>
            )}
          </div>

          {/* Vanish timer control */}
          <div className="scc-vanish-wrap" onClick={e => e.stopPropagation()}>
            <button
              className={`scc-icon-btn scc-icon-btn--sm scc-vanish-btn${vanishPickerOpen ? ' scc-icon-btn--active' : ''}`}
              onClick={() => setVanishPickerOpen(p => !p)}
              title="Vanish timer"
            >
              <Timer size={13} />
              <span className="scc-vanish-label">{vanishTimer === 0 ? 'Off' : vanishTimer >= 60 ? `${vanishTimer / 60}m` : `${vanishTimer}s`}</span>
            </button>
            {vanishPickerOpen && (
              <div className="scc-vanish-picker">
                <div className="scc-vanish-picker__title"><Clock size={11} /> Vanish after reading</div>
                {VANISH_OPTIONS.map(opt => (
                  <button key={opt.value} className={`scc-vanish-opt${vanishTimer === opt.value ? ' scc-vanish-opt--active' : ''}`} onClick={() => handleVanishTimerChange(opt.value)}>{opt.label}</button>
                ))}
              </div>
            )}
          </div>

          {onStartVideoCall && (
            <button className="scc-icon-btn scc-icon-btn--sm scc-icon-btn--video" onClick={handleInitiateVideoCall} title="Start encrypted video call"><Video size={14} /></button>
          )}
          <button className="scc-icon-btn scc-icon-btn--sm scc-icon-btn--world" onClick={() => setShow3D(true)} title="Aippie Virtual World">🌐</button>
          {onOpenLifeAssist && (
            <button
              className={`scc-icon-btn scc-icon-btn--sm scc-icon-btn--lifeai${lifeAiBubbleOpen ? ' scc-icon-btn--active' : ''}`}
              onClick={() => { setLifeAiBubbleOpen(v => !v); setLifeAiMinimized(false); }}
              title="Life Assistant"
            ><BrainCircuit size={14} /></button>
          )}
          <button className={`scc-icon-btn scc-icon-btn--sm${activeContact?.appear_offline_to ? ' scc-icon-btn--active' : ''}`} onClick={toggleAppearOffline} title="Appear offline">
            <EyeOff size={14} />
          </button>
        </div>

        {/* Protection banner */}
        <div className="scc-protect-bar">
          <span><Shield size={11} /> AippieShield</span>
          <span><Clock size={11} /> {vanishTimer === 0 ? 'No wipe' : vanishTimer === 180 ? '3-min wipe' : vanishTimer >= 60 ? `${vanishTimer / 60}min wipe` : `${vanishTimer}s wipe`}</span>
          <span><Globe size={11} /> AI vertaling</span>
          <span><Skull size={11} /> DLP active</span>
        </div>

        {/* Messages */}
        <div
          className="scc-messages"
          style={{ userSelect: 'none', WebkitUserSelect: 'none' }}
          onCopy={e => { e.preventDefault(); }}
          onCut={e => { e.preventDefault(); }}
        >
          {messages.length === 0 && (
            <div className="scc-no-msgs">
              <Lock size={22} /><p>Start a secure conversation</p>
              <span>Long-press any message to reply, react, or delete</span>
            </div>
          )}

          {messages.map(msg => {
            const mine = isMyMsg(msg);
            const hasTimer = msg.countdown !== undefined && msg.countdown !== null;
            const urgent = hasTimer && (msg.countdown ?? 99) <= 10;
            const msgReactions = reactions[msg.id] ?? [];
            const reactionGroups = msgReactions.reduce((acc, r) => { acc[r.emoji] = (acc[r.emoji] ?? 0) + 1; return acc; }, {} as Record<string, number>);

            return (
              <div
                key={msg.id}
                className={`scc-msg-row${mine ? ' scc-msg-row--mine' : ''}`}
                onContextMenu={e => { e.preventDefault(); e.stopPropagation(); setContextMenu({ msg }); setEmojiPickerMsgId(null); }}
                onTouchStart={() => startLongPress(msg)}
                onTouchEnd={cancelLongPress}
                onTouchMove={cancelLongPress}
                onMouseDown={() => startLongPress(msg)}
                onMouseUp={cancelLongPress}
                onMouseLeave={cancelLongPress}
              >
                <div className={`scc-bubble${mine ? ' scc-bubble--mine' : ''}`}>
                  {msg.reply_preview && (
                    <div className="scc-reply-quote">
                      <div className="scc-reply-quote__bar" />
                      <span className="scc-reply-quote__text">{msg.reply_preview}</span>
                    </div>
                  )}
                  {msg.content.startsWith('VIDEO_CALL_REQUEST:') ? (
                    <div className="scc-bubble__vcall">
                      <Video size={16} style={{ color: '#38bdf8', flexShrink: 0 }} />
                      <span>Videogesprek uitnodiging</span>
                    </div>
                  ) : msg.content.startsWith('[Aippie AI]:') ? (
                    <div className="scc-bubble__ai-msg">
                      <Zap size={12} style={{ color: '#f59e0b', flexShrink: 0 }} />
                      <span>{msg.content.replace('[Aippie AI]: ', '')}</span>
                    </div>
                  ) : msg.content.startsWith('[FILE:') ? (() => {
                    const parts = msg.content.slice(6, -1).split(':');
                    const fileName = parts[0];
                    const dataUrl = parts.slice(1).join(':');
                    const isImage = dataUrl.startsWith('data:image');
                    return (
                      <div className="scc-bubble__file">
                        {isImage ? (
                          <img src={dataUrl} alt={fileName} className="scc-bubble__file-img" onClick={() => window.open(dataUrl, '_blank')} />
                        ) : (
                          <a href={dataUrl} download={fileName} className="scc-bubble__file-link">
                            <FileText size={18} />
                            <span>{fileName}</span>
                          </a>
                        )}
                      </div>
                    );
                  })() : msg.content.startsWith('[VOICE:') ? (() => {
                    const dataUrl = msg.content.slice(7, -1);
                    const isPlaying = playingVoiceId === msg.id;
                    return (
                      <div className="scc-bubble__voice">
                        <button
                          className={`scc-voice-play${isPlaying ? ' scc-voice-play--active' : ''}`}
                          onClick={() => {
                            if (isPlaying) {
                              setPlayingVoiceId(null);
                            } else {
                              setPlayingVoiceId(msg.id);
                              const audio = new Audio(dataUrl);
                              audio.play();
                              audio.onended = () => setPlayingVoiceId(null);
                            }
                          }}
                        >
                          {isPlaying ? <Square size={14} /> : <Play size={14} />}
                        </button>
                        <div className="scc-voice-wave">
                          {Array.from({ length: 20 }).map((_, i) => (
                            <div key={i} className={`scc-voice-bar${isPlaying ? ' scc-voice-bar--active' : ''}`} style={{ height: `${8 + Math.sin(i * 1.3) * 6 + Math.cos(i * 0.8) * 4}px` }} />
                          ))}
                        </div>
                        <span className="scc-voice-label">Spraakbericht</span>
                      </div>
                    );
                  })() : (
                    <span className="scc-bubble__text">{msg.content}</span>
                  )}
                  <div className="scc-bubble__meta">
                    {hasTimer && <span className={`scc-timer${urgent ? ' scc-timer--urgent' : ''}`}><Clock size={10} /> {msg.countdown}s</span>}
                    <span className="scc-bubble__time">{timeAgo(msg.created_at)}</span>
                    {mine && msg.is_read && <Check size={11} className="scc-bubble__read" />}
                  </div>
                </div>

                {/* Emoji picker for this message */}
                {emojiPickerMsgId === msg.id && (
                  <div className={`scc-emoji-picker${mine ? ' scc-emoji-picker--mine' : ''}`} onClick={e => e.stopPropagation()}>
                    {EMOJI_LIST.map(e => <button key={e} className="scc-emoji-btn" onClick={() => handleReact(msg.id, e)}>{e}</button>)}
                  </div>
                )}

                {/* Reactions */}
                {Object.keys(reactionGroups).length > 0 && (
                  <div className={`scc-reactions${mine ? ' scc-reactions--mine' : ''}`}>
                    {Object.entries(reactionGroups).map(([emoji, count]) => {
                      const myRx = msgReactions.find(r => r.from_pin === myProfile?.pin_code && r.emoji === emoji);
                      return (
                        <button key={emoji} className={`scc-reaction-pill${myRx ? ' scc-reaction-pill--mine' : ''}`}
                          onClick={e => { e.stopPropagation(); handleReact(msg.id, emoji); }}>
                          {emoji}{count > 1 && <span>{count}</span>}
                        </button>
                      );
                    })}
                  </div>
                )}

                {msg.translation && (
                  <div className={`scc-translation${mine ? ' scc-translation--mine' : ''}`}><Globe size={10} /> {msg.translation}</div>
                )}
              </div>
            );
          })}
          <div ref={messagesEndRef} />
        </div>

        {/* Context menu bottom sheet */}
        {contextMenu && (
          <div className="scc-ctx-overlay" onClick={() => setContextMenu(null)}>
            <div className="scc-ctx-sheet" onClick={e => e.stopPropagation()}>
              <div className="scc-ctx-preview">{contextMenu.msg.content.slice(0, 60)}{contextMenu.msg.content.length > 60 ? '…' : ''}</div>
              <div className="scc-ctx-actions">
                <button className="scc-ctx-btn" onClick={() => { setReplyTo(contextMenu.msg); setContextMenu(null); }}>
                  <Reply size={16} /><span>Reply</span>
                </button>
                <button className="scc-ctx-btn" onClick={() => { setEmojiPickerMsgId(contextMenu.msg.id); setContextMenu(null); }}>
                  <SmilePlus size={16} /><span>React</span>
                </button>
                {isMyMsg(contextMenu.msg) && (
                  <button className="scc-ctx-btn scc-ctx-btn--danger" onClick={() => handleDeleteForEveryone(contextMenu.msg)}>
                    <Trash2 size={16} /><span>Delete for everyone</span>
                  </button>
                )}
              </div>
            </div>
          </div>
        )}

        {/* DLP warning */}
        {dlpWarning && (
          <div className="scc-dlp-bar">
            <AlertTriangle size={14} className="scc-dlp-bar__icon" />
            <div className="scc-dlp-bar__body">
              <span className="scc-dlp-bar__title">AippieShield DLP</span>
              <span className="scc-dlp-bar__msg">{dlpWarning}</span>
            </div>
            <div className="scc-dlp-bar__actions">
              <button className="scc-dlp-btn scc-dlp-btn--cancel" onClick={() => { setDlpWarning(null); setDlpBypass(false); }}>Cancel</button>
              <button className="scc-dlp-btn scc-dlp-btn--send" onClick={() => { setDlpBypass(true); setDlpWarning(null); setTimeout(handleSend, 0); }}>Send anyway</button>
            </div>
          </div>
        )}

        {/* Reply preview bar */}
        {replyTo && (
          <div className="scc-reply-bar">
            <Reply size={13} className="scc-reply-bar__icon" />
            <div className="scc-reply-bar__content">
              <span className="scc-reply-bar__label">Replying to</span>
              <span className="scc-reply-bar__text">{replyTo.content.slice(0, 60)}{replyTo.content.length > 60 ? '…' : ''}</span>
            </div>
            <button className="scc-reply-bar__close" onClick={() => setReplyTo(null)}><X size={14} /></button>
          </div>
        )}

        {/* Flash ad banner when message is sent */}
        {flashAd && (
          <div className="scc-flash-ad">
            <Megaphone size={13} style={{ color: '#f59e0b', flexShrink: 0 }} />
            <span>{flashAd}</span>
          </div>
        )}

        {/* Input bar — large send button for mobile */}
        <div className="scc-input-bar">
          {/* Hidden file input */}
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*,application/pdf,.doc,.docx,.xls,.xlsx,.txt"
            style={{ display: 'none' }}
            onChange={handleFileSelect}
          />
          <button
            className="scc-attach-btn"
            onClick={() => fileInputRef.current?.click()}
            disabled={fileSending}
            title="Document of afbeelding sturen"
            aria-label="Add attachment"
          >
            {fileSending ? <span className="modal__spinner" style={{ width: 14, height: 14 }} /> : <Paperclip size={18} />}
          </button>
          {/* Wallet send button */}
          <button
            className="scc-attach-btn scc-attach-btn--wallet"
            onClick={openWalletPanel}
            title="Send APC money"
            aria-label="Wallet betaling"
          >
            <Wallet size={17} />
          </button>
          <input
            ref={inputRef}
            className="scc-input"
            placeholder={replyTo ? 'Typ je antwoord...' : 'Typ een beveiligd bericht...'}
            value={input}
            onChange={e => { setInput(e.target.value); sendTypingBroadcast(); }}
            onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handleSend(); } }}
            inputMode="text"
            enterKeyHint="send"
          />
          {/* Voice message button */}
          <button
            className={`scc-attach-btn${recording ? ' scc-attach-btn--recording' : ''}`}
            onMouseDown={startRecording}
            onMouseUp={stopRecording}
            onTouchStart={e => { e.preventDefault(); startRecording(); }}
            onTouchEnd={e => { e.preventDefault(); stopRecording(); }}
            disabled={voiceSending}
            title="Houd vast voor spraakbericht"
            aria-label="Spraakbericht"
          >
            {voiceSending ? <span className="modal__spinner" style={{ width: 14, height: 14 }} /> : recording ? <MicOff size={18} style={{ color: '#ef4444' }} /> : <Mic size={18} />}
          </button>
          <button
            className={`scc-send-btn${input.trim() ? ' scc-send-btn--ready' : ''}`}
            onClick={handleSend}
            disabled={!input.trim() || sending}
            aria-label="Verstuur bericht"
          >
            {sending ? <span className="modal__spinner" style={{ width: 14, height: 14 }} /> : <Send size={18} />}
          </button>
        </div>

        {/* ── Video call PIN dialogs ── */}
        {videoCallDialog === 'caller_pin' && (
          <div className="scc-vcall-overlay" onClick={() => setVideoCallDialog('idle')}>
            <div className="scc-vcall-dialog" onClick={e => e.stopPropagation()}>
              <div className="scc-vcall-dialog__header">
                <Video size={20} style={{ color: '#38bdf8' }} />
                <span>Videogesprek starten</span>
              </div>
              <p className="scc-vcall-dialog__sub">
                Encrypted session token generated. Send the call request to {activeContact?.nickname ?? activeContact?.profile?.display_name} — connection will auto-negotiate when they accept.
              </p>
              <div className="scc-vcall-pin-display" style={{ fontSize: 11, letterSpacing: '0.3em' }}>{videoCallPin}</div>
              <div className="scc-vcall-dialog__actions">
                <button className="scc-vcall-btn scc-vcall-btn--cancel" onClick={() => setVideoCallDialog('idle')}>Cancel</button>
                <button className="scc-vcall-btn scc-vcall-btn--primary" onClick={() => { handleSendVideoCallRequest(); }}>
                  <Send size={14} /> Verbinden
                </button>
              </div>
            </div>
          </div>
        )}

        {videoCallDialog === 'callee_pin' && (
          <div className="scc-vcall-overlay">
            <div className="scc-vcall-dialog" onClick={e => e.stopPropagation()}>
              <div className="scc-vcall-dialog__header">
                <Video size={20} style={{ color: '#10b981' }} />
                <span>Inkomende videooproep</span>
              </div>
              <p className="scc-vcall-dialog__sub">
                <strong>{videoCallFrom}</strong> is calling.
                Token handshake verified — connecting automatically in 4 seconds…
              </p>
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8, margin: '12px 0', color: '#10b981', fontSize: 12 }}>
                <span style={{ width: 8, height: 8, borderRadius: '50%', background: '#10b981', animation: 'scc-pulse 1s infinite', display: 'inline-block' }} />
                Auto-negotiating peer connection…
              </div>
              <div className="scc-vcall-pin-display" style={{ fontSize: 11, letterSpacing: '0.3em', opacity: 0.5 }}>{videoCallPin}</div>
              <div className="scc-vcall-dialog__actions">
                <button className="scc-vcall-btn scc-vcall-btn--cancel" onClick={() => { setVideoCallDialog('ai_proxy'); }}>
                  Weiger + AI reageert
                </button>
                <button className="scc-vcall-btn scc-vcall-btn--primary" onClick={() => { setVideoCallDialog('idle'); onStartVideoCall?.(); }}>
                  <Video size={14} /> Nu verbinden
                </button>
              </div>
            </div>
          </div>
        )}

        {videoCallDialog === 'ai_proxy' && (
          <div className="scc-vcall-overlay">

        {/* ── Wallet panel ── */}
        {walletPanelOpen && (
          <div className="scc-vcall-overlay" onClick={() => setWalletPanelOpen(false)}>
            <div className="scc-vcall-dialog" onClick={e => e.stopPropagation()}>
              <div className="scc-vcall-dialog__header">
                <Wallet size={20} style={{ color: '#22c55e' }} />
                <span>Send money to {activeContact?.nickname || activeContact?.pin_code}</span>
              </div>
              <p className="scc-vcall-dialog__sub">Betaal direct via jouw Aippie Wallet (APC). 1% fee van toepassing.</p>

              {/* Balance */}
              <div className="scc-wallet-balance">
                <CreditCard size={14} style={{ color: '#22c55e' }} />
                <span>Saldo: <strong>{walletBalance !== null ? `${walletBalance.toFixed(2)} APC` : '...'}</strong></span>
              </div>

              {/* Amount input */}
              <div className="scc-wallet-input-row">
                <span className="scc-wallet-currency">APC</span>
                <input
                  className="scc-wallet-input"
                  type="number"
                  inputMode="decimal"
                  placeholder="0.00"
                  min="0.01"
                  step="0.01"
                  value={walletAmt}
                  onChange={e => setWalletAmt(e.target.value)}
                />
              </div>

              {walletFeedback && (
                <div className={`scc-wallet-feedback${walletFeedback.ok ? ' scc-wallet-feedback--ok' : ' scc-wallet-feedback--err'}`}>
                  {walletFeedback.ok ? <Check size={13} /> : <AlertTriangle size={13} />}
                  <span>{walletFeedback.msg}</span>
                </div>
              )}

              <div className="scc-vcall-dialog__actions">
                <button className="scc-vcall-btn scc-vcall-btn--cancel" onClick={() => setWalletPanelOpen(false)}>Cancel</button>
                <button
                  className="scc-vcall-btn scc-vcall-btn--primary"
                  onClick={handleWalletSend}
                  disabled={walletBusy || !walletAmt}
                >
                  {walletBusy ? <span className="modal__spinner" style={{ width: 12, height: 12 }} /> : <Send size={13} />}
                  Stuur {walletAmt ? `${walletAmt} APC` : 'APC'}
                </button>
              </div>
            </div>
          </div>
        )}
            <div className="scc-vcall-dialog" onClick={e => e.stopPropagation()}>
              <div className="scc-vcall-dialog__header">
                <Zap size={20} style={{ color: '#f59e0b' }} />
                <span>Laat Aippie AI reageren</span>
              </div>
              <p className="scc-vcall-dialog__sub">Wat moet Aippie namens jou sturen naar <strong>{videoCallFrom}</strong>?</p>
              <textarea
                className="scc-vcall-textarea"
                placeholder="Bijv: Ik bel je straks terug, ben nu bezig..."
                value={aiProxyMsg}
                onChange={e => setAiProxyMsg(e.target.value)}
                rows={3}
              />
              <div className="scc-vcall-dialog__quick">
                {['I\'ll call you back shortly', 'I\'m busy now, call later', 'Send me a message'].map(q => (
                  <button key={q} className="scc-vcall-quick" onClick={() => setAiProxyMsg(q)}>{q}</button>
                ))}
              </div>
              <div className="scc-vcall-dialog__actions">
                <button className="scc-vcall-btn scc-vcall-btn--cancel" onClick={() => setVideoCallDialog('idle')}>Sluiten</button>
                <button className="scc-vcall-btn scc-vcall-btn--primary" onClick={handleAiProxy} disabled={!aiProxyMsg.trim()}>
                  <Send size={14} /> Stuur via AI
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
