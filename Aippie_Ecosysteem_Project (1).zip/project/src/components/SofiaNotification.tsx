import { useEffect, useRef, useState } from 'react';
import { X, Sparkles } from 'lucide-react';
import { t, type LangCode } from '../lib/i18n';

type Props = { lang: LangCode };

type NotifMessage = { id: string; text: string };

// Hour triggers (local time)
const TRIGGERS = [
  { hour: 8,  key: 'morning'   as const },
  { hour: 13, key: 'afternoon' as const },
  { hour: 21, key: 'evening'   as const },
];

const FIRED_KEY = 'aippie_notif_fired';

function getFired(): Set<string> {
  try { return new Set(JSON.parse(localStorage.getItem(FIRED_KEY) ?? '[]')); }
  catch { return new Set(); }
}

function markFired(k: string) {
  const s = getFired();
  s.add(k);
  localStorage.setItem(FIRED_KEY, JSON.stringify(Array.from(s).slice(-30)));
}

function dayKey(hour: number) {
  const d = new Date();
  return `${d.getFullYear()}-${d.getMonth()}-${d.getDate()}:${hour}`;
}

export default function SofiaNotification({ lang }: Props) {
  const [queue, setQueue] = useState<NotifMessage[]>([]);
  // Keep lang ref fresh so the interval closure always uses the current value
  const langRef = useRef<LangCode>(lang);
  langRef.current = lang;

  const dismiss = (id: string) => setQueue(q => q.filter(n => n.id !== id));

  const push = (text: string) => {
    const id = crypto.randomUUID();
    setQueue(q => [...q, { id, text }]);
    setTimeout(() => dismiss(id), 12000);
  };

  useEffect(() => {
    const check = () => {
      const now   = new Date();
      const hour  = now.getHours();
      const min   = now.getMinutes();
      const fired = getFired();
      const strings = t(langRef.current);

      for (const trigger of TRIGGERS) {
        if (hour === trigger.hour && min === 0) {
          const key = dayKey(trigger.hour);
          if (!fired.has(key)) {
            markFired(key);
            const text =
              trigger.key === 'morning'   ? strings.notifMorning   :
              trigger.key === 'afternoon' ? strings.notifAfternoon :
                                            strings.notifEvening;
            push(text);
          }
        }
      }
    };

    check();
    const id = setInterval(check, 30_000);
    return () => clearInterval(id);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  if (queue.length === 0) return null;

  return (
    <div className="sn-stack" role="region" aria-live="polite" aria-label="Aippie notifications">
      {queue.map(notif => (
        <div key={notif.id} className="sn-card">
          <div className="sn-card__avatar">
            <img
              src="/Jouw_alineatekst_(2).png"
              alt="Aippie"
              className="sn-card__avatar-img"
            />
            <span className="sn-card__avatar-dot" />
          </div>
          <div className="sn-card__body">
            <div className="sn-card__name">
              <Sparkles size={10} /> Aippie AI
            </div>
            <div className="sn-card__text">{notif.text}</div>
          </div>
          <button
            className="sn-card__close"
            onClick={() => dismiss(notif.id)}
            aria-label="Dismiss notification"
          >
            <X size={13} />
          </button>
        </div>
      ))}
    </div>
  );
}
