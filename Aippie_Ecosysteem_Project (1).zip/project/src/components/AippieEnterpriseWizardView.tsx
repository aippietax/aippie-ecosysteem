import { useState, useEffect, useCallback, useRef } from 'react';
import {
  Building2, ShieldCheck, CheckCircle2, ChevronRight, ChevronLeft,
  Upload, Lock, RefreshCw, AlertCircle, Key,
  FileText, Zap, Crown, Eye, EyeOff, X,
} from 'lucide-react';
import { supabase } from '../lib/supabase';

// ── Types ─────────────────────────────────────────────────────────────────────
interface EnterpriseCompany {
  id: string;
  name: string;
  nif: string | null;
  bank_name: string | null;
  operational_goals: unknown[];
  onboarding_step: number;
  onboarding_complete: boolean;
  created_at: string;
}

type WizardStep = 0 | 1 | 2 | 3 | 4;

interface StepMeta {
  label: string;
  title: string;
  subtitle: string;
  color: string;
  icon: React.ReactNode;
}

const STEPS: StepMeta[] = [
  {
    label: 'Identity',
    title: 'Corporate Identity',
    subtitle: 'Register your legal entity in the AIPPIE multi-tenant network',
    color: '#38bdf8',
    icon: <Building2 size={16} />,
  },
  {
    label: 'Credentials',
    title: 'Bank API Configuration',
    subtitle: 'Stream your bank integration credentials — AES-encrypted at rest',
    color: '#4ade80',
    icon: <Key size={16} />,
  },
  {
    label: 'Certificate',
    title: 'AEAT Digital Certificate',
    subtitle: 'Upload your .pfx/.p12 signing certificate for Verifactu compliance',
    color: '#fb923c',
    icon: <ShieldCheck size={16} />,
  },
  {
    label: 'Review',
    title: 'Review & Confirm',
    subtitle: 'Verify your corporate registration before activating the AI cabinet',
    color: '#a78bfa',
    icon: <FileText size={16} />,
  },
  {
    label: 'Active',
    title: 'Enterprise Activated',
    subtitle: 'Your autonomous AI boardroom cabinet is now live',
    color: '#fbbf24',
    icon: <Crown size={16} />,
  },
];

const BANK_OPTIONS = [
  'Sabadell', 'Qonto', 'Bankinter', 'BBVA', 'Santander',
  'ING Direct', 'CaixaBank', 'Revolut', 'Wise', 'Other',
];

// ── Helpers ───────────────────────────────────────────────────────────────────

async function callOnboarding(body: Record<string, unknown>) {
  const { data: { session } } = await supabase.auth.getSession();
  const token = session?.access_token;
  const url = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/enterprise-onboarding`;
  const res = await fetch(url, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token ?? import.meta.env.VITE_SUPABASE_ANON_KEY}`,
    },
    body: JSON.stringify(body),
  });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return res.json() as Promise<{ success?: boolean; company?: EnterpriseCompany; error?: string; role?: string }>;
}

// ── Sub-components ────────────────────────────────────────────────────────────
function ProgressBar({ step, total }: { step: number; total: number }) {
  const pct = (step / (total - 1)) * 100;
  return (
    <div style={{ width: '100%', height: 2, background: 'rgba(255,255,255,0.06)', borderRadius: 2, margin: '16px 0 24px' }}>
      <div style={{
        height: '100%', borderRadius: 2,
        width: `${pct}%`,
        background: 'linear-gradient(90deg, #38bdf8, #4ade80)',
        transition: 'width 0.4s cubic-bezier(0.4,0,0.2,1)',
        boxShadow: '0 0 8px rgba(56,189,248,0.4)',
      }} />
    </div>
  );
}

function StepDots({ current, total }: { current: number; total: number }) {
  return (
    <div style={{ display: 'flex', gap: 8, justifyContent: 'center', marginBottom: 28 }}>
      {Array.from({ length: total }).map((_, i) => {
        const done    = i < current;
        const active  = i === current;
        const meta    = STEPS[i];
        return (
          <div key={i} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 4 }}>
            <div style={{
              width: active ? 28 : 20, height: active ? 28 : 20,
              borderRadius: '50%',
              background: done ? meta.color : active ? meta.color : 'rgba(255,255,255,0.06)',
              border: `2px solid ${active || done ? meta.color : 'rgba(255,255,255,0.1)'}`,
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              transition: 'all 0.3s ease',
              boxShadow: active ? `0 0 12px ${meta.color}66` : 'none',
            }}>
              {done
                ? <CheckCircle2 size={11} color="#080d1a" strokeWidth={3} />
                : active
                  ? <span style={{ color: '#080d1a', fontSize: 10, fontWeight: 800 }}>{i + 1}</span>
                  : <span style={{ color: 'rgba(148,163,184,0.4)', fontSize: 9 }}>{i + 1}</span>
              }
            </div>
            <span style={{ fontSize: 8.5, color: active ? meta.color : done ? 'rgba(148,163,184,0.5)' : 'rgba(148,163,184,0.25)', letterSpacing: '0.06em', fontWeight: active ? 700 : 400 }}>
              {meta.label}
            </span>
          </div>
        );
      })}
    </div>
  );
}

function Field({
  label, value, onChange, placeholder, type = 'text', error, hint, maxLength, readOnly,
}: {
  label: string; value: string; onChange?: (v: string) => void;
  placeholder?: string; type?: string; error?: string; hint?: string;
  maxLength?: number; readOnly?: boolean;
}) {
  const [show, setShow] = useState(false);
  const isPassword = type === 'password';
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 4, marginBottom: 14 }}>
      <label style={{ fontSize: 10, fontWeight: 700, color: 'rgba(148,163,184,0.7)', letterSpacing: '0.08em', textTransform: 'uppercase' }}>
        {label}
      </label>
      <div style={{ position: 'relative' }}>
        <input
          type={isPassword && !show ? 'password' : 'text'}
          value={value}
          onChange={e => onChange?.(e.target.value)}
          placeholder={placeholder}
          maxLength={maxLength}
          readOnly={readOnly}
          style={{
            width: '100%', boxSizing: 'border-box',
            padding: `9px ${isPassword ? '34px' : '12px'} 9px 12px`,
            background: 'rgba(255,255,255,0.04)',
            border: `1px solid ${error ? 'rgba(248,113,113,0.4)' : 'rgba(255,255,255,0.1)'}`,
            borderRadius: 8, color: '#e2e8f0', fontSize: 12,
            outline: 'none', fontFamily: 'inherit',
            transition: 'border-color 0.15s',
          }}
        />
        {isPassword && (
          <button
            type="button"
            onClick={() => setShow(v => !v)}
            style={{ position: 'absolute', right: 10, top: '50%', transform: 'translateY(-50%)', background: 'none', border: 'none', cursor: 'pointer', color: 'rgba(148,163,184,0.5)' }}
          >
            {show ? <EyeOff size={13} /> : <Eye size={13} />}
          </button>
        )}
      </div>
      {error && <span style={{ fontSize: 9.5, color: '#f87171' }}>{error}</span>}
      {hint && !error && <span style={{ fontSize: 9.5, color: 'rgba(148,163,184,0.45)', lineHeight: 1.4 }}>{hint}</span>}
    </div>
  );
}

// ── Main Component ────────────────────────────────────────────────────────────
export default function AippieEnterpriseWizardView() {
  const [step, setStep]                   = useState<WizardStep>(0);
  const [loading, setLoading]             = useState(true);
  const [submitting, setSubmitting]       = useState(false);
  const [error, setError]                 = useState('');
  const [existingCompany, setExisting]    = useState<EnterpriseCompany | null>(null);
  const [companyId, setCompanyId]         = useState('');

  // Step 0 — Corporate Identity
  const [companyName, setCompanyName]     = useState('');
  const [vatNumber, setVatNumber]         = useState('');

  // Step 1 — Bank Credentials
  const [bankName, setBankName]           = useState('');
  const [bankApiKey, setBankApiKey]       = useState('');
  const [bankIban, setBankIban]           = useState('');
  const [bankWebhook, setBankWebhook]     = useState('');

  // Step 2 — AEAT Certificate
  const [certFile, setCertFile]           = useState<File | null>(null);
  const [certPassword, setCertPassword]   = useState('');
  const [certB64, setCertB64]             = useState('');
  const certRef = useRef<HTMLInputElement>(null);

  // Step 3 — Review
  const [confirmed, setConfirmed]         = useState(false);

  // Validation errors
  const [nameErr, setNameErr]   = useState('');

  const loadExisting = useCallback(async () => {
    setLoading(true);
    try {
      const result = await callOnboarding({ action: 'get_company' });
      if (result.company) {
        setExisting(result.company);
        setCompanyId(result.company.id);
        setCompanyName(result.company.name);
        setVatNumber(result.company.nif ?? '');
        setBankName(result.company.bank_name ?? '');
        const resumeStep = result.company.onboarding_complete ? 4 : (result.company.onboarding_step ?? 0) as WizardStep;
        setStep(resumeStep);
      }
    } catch { /* no company yet */ }
    setLoading(false);
  }, []);

  useEffect(() => { loadExisting(); }, [loadExisting]);

  const handleCertFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0];
    if (!f) return;
    setCertFile(f);
    const reader = new FileReader();
    reader.onload = ev => setCertB64(btoa(ev.target?.result as string));
    reader.readAsBinaryString(f);
  };

  // ── Step handlers ─────────────────────────────────────────────────────────

  const submitStep0 = async () => {
    setNameErr(''); setDunsErr('');
    if (!companyName.trim()) { setNameErr('Company name is required.'); return; }
    setSubmitting(true); setError('');
    try {
      const result = await callOnboarding({
        action: companyId ? 'update_step' : 'create_company',
        ...(companyId
          ? { company_id: companyId, onboarding_step: 1 }
          : {
              company_name: companyName.trim(),
              nif: vatNumber.trim() || undefined,
              bank_name: bankName.trim() || undefined,
              operational_goals: [],
            }
        ),
      });
      if (result.error) throw new Error(result.error);
      if (result.company && !companyId) setCompanyId(result.company.id);
      setStep(1);
    } catch (e) {
      setError(String(e));
    }
    setSubmitting(false);
  };

  const submitStep1 = async () => {
    setSubmitting(true); setError('');
    try {
      if (bankApiKey || bankIban) {
        await callOnboarding({
          action: 'update_credentials',
          company_id: companyId,
          bank_name: bankName || undefined,
          iban: bankIban || undefined,
          bic_swift: undefined,
          bank_api_config: bankApiKey ? { api_key: bankApiKey, webhook_url: bankWebhook } : undefined,
          onboarding_step: 2,
        });
      } else {
        await callOnboarding({ action: 'update_step', company_id: companyId, onboarding_step: 2 });
      }
      setStep(2);
    } catch (e) { setError(String(e)); }
    setSubmitting(false);
  };

  const submitStep2 = async () => {
    setSubmitting(true); setError('');
    try {
      if (certB64) {
        await callOnboarding({
          action: 'update_credentials',
          company_id: companyId,
          pfx_certificate_b64: certB64,
          pfx_password: certPassword || undefined,
          onboarding_step: 3,
        });
      } else {
        await callOnboarding({ action: 'update_step', company_id: companyId, onboarding_step: 3 });
      }
      setStep(3);
    } catch (e) { setError(String(e)); }
    setSubmitting(false);
  };

  const submitStep3 = async () => {
    if (!confirmed) return;
    setSubmitting(true); setError('');
    try {
      await callOnboarding({
        action: 'update_step',
        company_id: companyId,
        onboarding_step: 4,
        onboarding_complete: true,
      });
      setStep(4);
    } catch (e) { setError(String(e)); }
    setSubmitting(false);
  };

  const resetWizard = () => {
    setExisting(null); setCompanyId(''); setStep(0);
    setCompanyName(''); setVatNumber('');
    setBankName(''); setBankApiKey(''); setBankIban(''); setBankWebhook('');
    setCertFile(null); setCertPassword(''); setCertB64('');
    setConfirmed(false); setError('');
  };

  // ── Render ─────────────────────────────────────────────────────────────────
  const meta = STEPS[step];

  if (loading) {
    return (
      <div style={{
        minHeight: '100vh', background: '#080d1a', display: 'flex',
        alignItems: 'center', justifyContent: 'center', flexDirection: 'column', gap: 12,
      }}>
        <RefreshCw size={20} color="#38bdf8" style={{ animation: 'spin 0.8s linear infinite' }} />
        <span style={{ fontSize: 11, color: 'rgba(148,163,184,0.5)' }}>Loading enterprise profile…</span>
        <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
      </div>
    );
  }

  return (
    <div style={{
      minHeight: '100vh', background: '#080d1a', color: '#e2e8f0',
      padding: '24px 16px 80px', fontFamily: "'Inter', sans-serif",
    }}>
      <div style={{ maxWidth: 560, margin: '0 auto' }}>

        {/* ── Header ──────────────────────────────────────────── */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 4 }}>
          <Zap size={16} color="#38bdf8" />
          <span style={{ fontSize: 11, fontWeight: 700, color: '#38bdf8', letterSpacing: '0.12em', textTransform: 'uppercase' }}>
            Enterprise Setup Wizard
          </span>
          {existingCompany && (
            <span style={{
              marginLeft: 'auto', fontSize: 9, fontWeight: 700, color: '#4ade80',
              background: 'rgba(74,222,128,0.1)', border: '1px solid rgba(74,222,128,0.25)',
              padding: '2px 8px', borderRadius: 20,
            }}>
            RESUMING — {existingCompany.name}
            </span>
          )}
        </div>
        <p style={{ fontSize: 12, color: 'rgba(148,163,184,0.5)', marginBottom: 0 }}>
          AIPPIE Multi-Tenant B2B Activation · Zero-Trust Architecture
        </p>

        <ProgressBar step={step} total={STEPS.length} />
        <StepDots current={step} total={STEPS.length} />

        {/* ── Step Card ────────────────────────────────────────── */}
        <div style={{
          background: 'linear-gradient(135deg, rgba(255,255,255,0.03) 0%, rgba(255,255,255,0.015) 100%)',
          border: `1px solid ${meta.color}33`,
          borderRadius: 18, padding: '24px 24px 20px',
          boxShadow: `0 0 32px ${meta.color}11`,
          transition: 'border-color 0.3s, box-shadow 0.3s',
        }}>
          {/* Step header */}
          <div style={{ display: 'flex', alignItems: 'flex-start', gap: 12, marginBottom: 20 }}>
            <div style={{
              width: 38, height: 38, borderRadius: 10,
              background: `${meta.color}18`, border: `1px solid ${meta.color}33`,
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              color: meta.color, flexShrink: 0,
            }}>
              {meta.icon}
            </div>
            <div>
              <div style={{ fontSize: 15, fontWeight: 800, color: '#fff', marginBottom: 3 }}>{meta.title}</div>
              <div style={{ fontSize: 10.5, color: 'rgba(148,163,184,0.6)', lineHeight: 1.5 }}>{meta.subtitle}</div>
            </div>
          </div>

          {/* ── STEP 0: Corporate Identity ── */}
          {step === 0 && (
            <div>
              <Field
                label="Legal Entity Name *"
                value={companyName}
                onChange={setCompanyName}
                placeholder="e.g. AIPPIETAX S.A."
                error={nameErr}
                hint="Must match your official company registration."
                maxLength={255}
              />
              <Field
                label="NIF / VAT / BTW / EIN"
                value={vatNumber}
                onChange={setVatNumber}
                placeholder="e.g. B12345678 or NL123456789B01"
                hint="Spanish NIF/CIF, EU VAT, or US EIN — used for Verifactu compliance."
                maxLength={32}
              />
              <Field
                label="Bank Name (optional)"
                value={bankName}
                onChange={setBankName}
                placeholder="e.g. Sabadell, Qonto, Bankinter"
                hint="You can add bank credentials in the next step."
              />
            </div>
          )}

          {/* ── STEP 1: Bank API Credentials ── */}
          {step === 1 && (
            <div>
              <div style={{
                background: 'rgba(74,222,128,0.06)', border: '1px solid rgba(74,222,128,0.18)',
                borderRadius: 8, padding: '8px 12px', marginBottom: 14, fontSize: 9.5,
                color: 'rgba(74,222,128,0.8)', lineHeight: 1.55,
              }}>
                <Lock size={10} style={{ display: 'inline', marginRight: 4 }} />
                All credentials are encrypted with AES-256 via pgcrypto before reaching the database.
                The passphrase never leaves the AIPPIE secure server layer.
              </div>
              <Field
                label="Bank Name"
                value={bankName}
                onChange={setBankName}
                placeholder="e.g. Sabadell, Qonto, Bankinter"
              />
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
                <Field
                  label="API Key / Token"
                  value={bankApiKey}
                  onChange={setBankApiKey}
                  placeholder="sk_live_…"
                  type="password"
                  hint="OAuth token or API key"
                />
                <Field
                  label="IBAN"
                  value={bankIban}
                  onChange={setBankIban}
                  placeholder="ES76 0049 …"
                  hint="Primary account IBAN"
                />
              </div>
              <Field
                label="Webhook URL (optional)"
                value={bankWebhook}
                onChange={setBankWebhook}
                placeholder="https://…/webhook"
                hint="Qonto / Sabadell transaction push endpoint"
              />
              <p style={{ fontSize: 9.5, color: 'rgba(148,163,184,0.4)', marginTop: 4 }}>
                You can skip this step and configure bank credentials later from your company settings.
              </p>
            </div>
          )}

          {/* ── STEP 2: AEAT Certificate ── */}
          {step === 2 && (
            <div>
              <div style={{
                background: 'rgba(251,146,60,0.06)', border: '1px solid rgba(251,146,60,0.2)',
                borderRadius: 8, padding: '8px 12px', marginBottom: 14, fontSize: 9.5,
                color: 'rgba(251,146,60,0.85)', lineHeight: 1.55,
              }}>
                <ShieldCheck size={10} style={{ display: 'inline', marginRight: 4 }} />
                Your .pfx/.p12 file is read client-side, base64-encoded, and sent exclusively
                to the AIPPIE edge function where it is encrypted via pgcrypto before DB storage.
                It is never stored in plaintext.
              </div>

              {/* Upload zone */}
              <div
                onClick={() => certRef.current?.click()}
                style={{
                  border: `2px dashed ${certFile ? 'rgba(251,146,60,0.5)' : 'rgba(255,255,255,0.1)'}`,
                  borderRadius: 12, padding: '24px 16px', textAlign: 'center',
                  cursor: 'pointer', marginBottom: 14,
                  background: certFile ? 'rgba(251,146,60,0.05)' : 'rgba(255,255,255,0.02)',
                  transition: 'all 0.2s',
                }}
              >
                {certFile ? (
                  <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8 }}>
                    <CheckCircle2 size={14} color="#4ade80" />
                    <span style={{ fontSize: 11, color: '#4ade80', fontWeight: 600 }}>{certFile.name}</span>
                    <button
                      onClick={e => { e.stopPropagation(); setCertFile(null); setCertB64(''); }}
                      style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'rgba(248,113,113,0.7)', display: 'flex' }}
                    >
                      <X size={12} />
                    </button>
                  </div>
                ) : (
                  <>
                    <Upload size={18} color="rgba(148,163,184,0.3)" style={{ margin: '0 auto 8px', display: 'block' }} />
                    <div style={{ fontSize: 11, color: 'rgba(148,163,184,0.5)', marginBottom: 3 }}>
                      Click to upload .pfx or .p12 certificate
                    </div>
                    <div style={{ fontSize: 9.5, color: 'rgba(148,163,184,0.3)' }}>
                      Issued by FNMT, Camerfirma, or equivalent accredited CA
                    </div>
                  </>
                )}
                <input
                  ref={certRef} type="file" accept=".pfx,.p12"
                  style={{ display: 'none' }} onChange={handleCertFile}
                />
              </div>

              {certFile && (
                <Field
                  label="Certificate Password"
                  value={certPassword}
                  onChange={setCertPassword}
                  placeholder="Enter .pfx/.p12 passphrase"
                  type="password"
                  hint="Used to verify the certificate locally. Not transmitted."
                />
              )}
              <p style={{ fontSize: 9.5, color: 'rgba(148,163,184,0.4)' }}>
                You can skip this step and upload the certificate later. Without it, Verifactu live submissions will be disabled.
              </p>
            </div>
          )}

          {/* ── STEP 3: Review ── */}
          {step === 3 && (
            <div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 10, marginBottom: 18 }}>
                {[
                  { label: 'Legal Entity', value: companyName, color: '#38bdf8', icon: <Building2 size={11} /> },
                  { label: 'NIF / VAT', value: vatNumber || '— not provided —', color: '#4ade80', icon: <FileText size={11} /> },
                  { label: 'Bank Integration', value: bankApiKey ? `${bankName || 'Configured'} · API key encrypted` : '— skipped —', color: '#fb923c', icon: <Key size={11} /> },
                  { label: 'AEAT Certificate', value: certFile ? `${certFile.name} · encrypted` : '— skipped —', color: '#fb923c', icon: <ShieldCheck size={11} /> },
                ].map(row => (
                  <div key={row.label} style={{
                    display: 'flex', alignItems: 'flex-start', gap: 10, padding: '8px 12px',
                    background: `${row.color}08`, border: `1px solid ${row.color}22`, borderRadius: 8,
                  }}>
                    <span style={{ color: row.color, marginTop: 1 }}>{row.icon}</span>
                    <div>
                      <div style={{ fontSize: 9, fontWeight: 700, color: row.color, letterSpacing: '0.08em', textTransform: 'uppercase', marginBottom: 2 }}>{row.label}</div>
                      <div style={{ fontSize: 11, color: 'rgba(226,232,240,0.8)' }}>{row.value}</div>
                    </div>
                  </div>
                ))}
              </div>

              <div style={{ display: 'flex', alignItems: 'flex-start', gap: 8, marginBottom: 8 }}>
                <input
                  type="checkbox" id="ent-confirm"
                  checked={confirmed} onChange={e => setConfirmed(e.target.checked)}
                  style={{ marginTop: 2, accentColor: '#a78bfa', width: 14, height: 14, flexShrink: 0 }}
                />
                <label htmlFor="ent-confirm" style={{ fontSize: 10, color: 'rgba(226,232,240,0.7)', lineHeight: 1.55, cursor: 'pointer' }}>
                  I confirm that all provided corporate information is accurate and authorised for AIPPIE enterprise
                  multi-tenant activation. I accept that sensitive credentials are stored encrypted and that AIPPIETAX S.A.
                  is not liable for incorrect filings resulting from erroneous input data.
                </label>
              </div>
            </div>
          )}

          {/* ── STEP 4: Active ── */}
          {step === 4 && (
            <div style={{ textAlign: 'center', padding: '12px 0 4px' }}>
              <div style={{
                width: 64, height: 64, borderRadius: '50%', margin: '0 auto 16px',
                background: 'rgba(251,191,36,0.1)', border: '2px solid rgba(251,191,36,0.3)',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                boxShadow: '0 0 24px rgba(251,191,36,0.2)',
              }}>
                <Crown size={28} color="#fbbf24" />
              </div>
              <div style={{ fontSize: 16, fontWeight: 800, color: '#fbbf24', marginBottom: 8 }}>
                Enterprise Activated
              </div>
              <div style={{ fontSize: 11, color: 'rgba(148,163,184,0.65)', lineHeight: 1.6, marginBottom: 20 }}>
                <strong style={{ color: '#e2e8f0' }}>{companyName}</strong> is now live in the AIPPIE
                multi-tenant network. Your Autonomous AI Boardroom Cabinet is initialized and all
                four secretaries — Tax, Commerce, Defense, and Health — are standing by under
                your master corporate directive.
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 8, marginBottom: 20 }}>
                {[
                  { label: 'Company ID', value: companyId.slice(0, 8).toUpperCase() + '…', color: '#38bdf8' },
                  { label: 'Tenant Status', value: 'ISOLATED · LIVE', color: '#4ade80' },
                  { label: 'Encryption', value: 'AES-256 · pgcrypto', color: '#fb923c' },
                  { label: 'Cabinet', value: '4 Secretaries Active', color: '#fbbf24' },
                ].map(s => (
                  <div key={s.label} style={{
                    padding: '10px 12px', background: `${s.color}08`,
                    border: `1px solid ${s.color}22`, borderRadius: 10,
                  }}>
                    <div style={{ fontSize: 8.5, fontWeight: 700, color: s.color, letterSpacing: '0.1em', textTransform: 'uppercase', marginBottom: 3 }}>{s.label}</div>
                    <div style={{ fontSize: 10, color: 'rgba(226,232,240,0.8)', fontWeight: 600 }}>{s.value}</div>
                  </div>
                ))}
              </div>
              <button
                onClick={resetWizard}
                style={{
                  fontSize: 10, color: 'rgba(148,163,184,0.5)', background: 'none',
                  border: '1px solid rgba(255,255,255,0.07)', borderRadius: 20,
                  padding: '5px 14px', cursor: 'pointer',
                }}
              >
                Register another company
              </button>
            </div>
          )}

          {/* ── Error ── */}
          {error && (
            <div style={{
              display: 'flex', alignItems: 'center', gap: 7, marginTop: 12,
              padding: '8px 12px', background: 'rgba(248,113,113,0.08)',
              border: '1px solid rgba(248,113,113,0.25)', borderRadius: 8,
              fontSize: 10, color: '#f87171',
            }}>
              <AlertCircle size={12} />
              {error}
            </div>
          )}

          {/* ── Navigation buttons ── */}
          {step < 4 && (
            <div style={{ display: 'flex', gap: 10, marginTop: 20 }}>
              {step > 0 && (
                <button
                  onClick={() => { setStep((step - 1) as WizardStep); setError(''); }}
                  disabled={submitting}
                  style={{
                    display: 'flex', alignItems: 'center', gap: 5,
                    padding: '9px 16px', borderRadius: 20, fontSize: 11, fontWeight: 600,
                    background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.1)',
                    color: 'rgba(148,163,184,0.6)', cursor: 'pointer',
                  }}
                >
                  <ChevronLeft size={12} /> Back
                </button>
              )}
              <button
                onClick={() => {
                  if (step === 0) submitStep0();
                  else if (step === 1) submitStep1();
                  else if (step === 2) submitStep2();
                  else if (step === 3) submitStep3();
                }}
                disabled={submitting || (step === 3 && !confirmed)}
                style={{
                  flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6,
                  padding: '10px 20px', borderRadius: 20, fontSize: 11, fontWeight: 700,
                  background: (step === 3 && !confirmed)
                    ? 'rgba(255,255,255,0.04)'
                    : `linear-gradient(135deg, ${meta.color}33, ${meta.color}22)`,
                  border: `1px solid ${(step === 3 && !confirmed) ? 'rgba(255,255,255,0.08)' : meta.color + '55'}`,
                  color: (step === 3 && !confirmed) ? 'rgba(148,163,184,0.3)' : meta.color,
                  cursor: (submitting || (step === 3 && !confirmed)) ? 'not-allowed' : 'pointer',
                  transition: 'all 0.2s',
                  boxShadow: (step === 3 && !confirmed) ? 'none' : `0 0 16px ${meta.color}22`,
                }}
              >
                {submitting
                  ? <><RefreshCw size={12} style={{ animation: 'spin 0.8s linear infinite' }} /> Processing…</>
                  : step === 1 || step === 2
                    ? <>{step === 1 ? 'Save & Continue' : 'Upload & Continue'} <ChevronRight size={12} /></>
                    : step === 3
                      ? <><CheckCircle2 size={12} /> Activate Enterprise</>
                      : <>Continue <ChevronRight size={12} /></>
                }
              </button>
            </div>
          )}
        </div>

        {/* ── Security notice ─────────────────────────────────── */}
        <div style={{
          marginTop: 20, padding: '10px 14px',
          background: 'rgba(56,189,248,0.04)', border: '1px solid rgba(56,189,248,0.1)',
          borderRadius: 10, display: 'flex', alignItems: 'flex-start', gap: 8,
        }}>
          <Lock size={10} color="rgba(56,189,248,0.5)" style={{ marginTop: 1, flexShrink: 0 }} />
          <p style={{ fontSize: 9, color: 'rgba(148,163,184,0.4)', margin: 0, lineHeight: 1.5 }}>
            AIPPIE Enterprise uses PostgreSQL pgcrypto symmetric encryption (AES-256/Blowfish) for all
            credential fields. The encryption key is stored exclusively as a Supabase server secret and
            is never exposed to clients, browser bundles, or log files. Row Level Security enforces strict
            tenant isolation — cross-tenant data access is architecturally impossible.
            AIPPIETAX S.A. · NIF A22944987 · Zero-Trust Architecture
          </p>
        </div>
      </div>

      <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
    </div>
  );
}
