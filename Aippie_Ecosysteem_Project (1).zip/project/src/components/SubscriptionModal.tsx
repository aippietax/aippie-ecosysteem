// @ts-nocheck
import { X, Lock, Check, Zap, Globe, ChevronRight, Building2, Gavel, Star } from 'lucide-react';
import { useState } from 'react';
import { supabase, PLAN_CONFIG, splitPrice, type PlanTier } from '../lib/supabase';

type Props = {
  onClose: () => void;
  onSubscribed: () => void;
};

type Step = 'plans' | 'payment' | 'auth';
type PayMethod = 'card' | 'apple';

function CardIcon() {
  return (
    <svg width="32" height="22" viewBox="0 0 32 22" fill="none">
      <rect width="32" height="22" rx="4" fill="url(#cg)"/>
      <circle cx="12" cy="11" r="5" fill="#EB001B" fillOpacity="0.9"/>
      <circle cx="20" cy="11" r="5" fill="#F79E1B" fillOpacity="0.9"/>
      <path d="M16 7.27a5 5 0 0 1 0 7.46A5 5 0 0 1 16 7.27Z" fill="#FF5F00"/>
      <defs>
        <linearGradient id="cg" x1="0" y1="0" x2="32" y2="22" gradientUnits="userSpaceOnUse">
          <stop stopColor="#1e293b"/><stop offset="1" stopColor="#0f172a"/>
        </linearGradient>
      </defs>
    </svg>
  );
}

function ApplePayIcon() {
  return (
    <svg width="56" height="22" viewBox="0 0 56 22" fill="none">
      <text x="0" y="16" fontFamily="system-ui,-apple-system,sans-serif" fontSize="15" fontWeight="600" fill="white" letterSpacing="-0.3">Apple Pay</text>
    </svg>
  );
}

const PLAN_ICONS: Record<PlanTier, React.FC<{ size: number }>> = {
  turista_basic:  Globe,
  corporate_b2b:  Building2,
  premium_jurado: Gavel,
};

const PLAN_FEATURES: Record<PlanTier, string[]> = {
  turista_basic: [
    '40 live minutes included / month',
    'EN⇄ES and NL⇄ES corridors',
    '€0.50/min after 40 min',
    '24/7 availability across Spain',
    'AI fallback — always connected',
  ],
  corporate_b2b: [
    '200 live minutes included / month',
    'All language corridors',
    '€0.50/min after 200 min',
    'Priority dispatch queue',
    'Dedicated account support',
  ],
  premium_jurado: [
    '60 live minutes included / month',
    'Certified court & notary interpreters',
    '€0.50/min after 60 min',
    'Jurado-stamped session records',
    'Encrypted call archive',
  ],
};

function CreditCardMockup({ name, number, tier }: { name: string; number: string; tier: PlanTier }) {
  const digits  = number.replace(/\D/g, '').padEnd(16, '0');
  const display = digits.replace(/(.{4})/g, '$1 ').trim() || '•••• •••• •••• ••••';
  const cfg     = PLAN_CONFIG[tier];
  return (
    <div className="card-mockup">
      <div className="card-mockup__chip" />
      <div className="card-mockup__brand">
        <span className="card-mockup__brand-text">AippieVoice</span>
        <span className="card-mockup__brand-plan">{cfg.badge}</span>
      </div>
      <div className="card-mockup__number">{display}</div>
      <div className="card-mockup__footer">
        <div>
          <div className="card-mockup__meta-label">Card Holder</div>
          <div className="card-mockup__meta-value">{name || 'YOUR NAME'}</div>
        </div>
        <CardIcon />
      </div>
    </div>
  );
}

export default function SubscriptionModal({ onClose, onSubscribed }: Props) {
  const [selectedTier, setSelectedTier] = useState<PlanTier>('turista_basic');
  const [step, setStep]             = useState<Step>('plans');
  const [payMethod, setPayMethod]   = useState<PayMethod>('card');
  const [loading, setLoading]       = useState(false);
  const [email, setEmail]           = useState('');
  const [password, setPassword]     = useState('');
  const [cardName, setCardName]     = useState('');
  const [cardNumber, setCardNumber] = useState('');
  const [cardExpiry, setCardExpiry] = useState('');
  const [cardCvc, setCardCvc]       = useState('');
  const [error, setError]           = useState('');

  const cfg = PLAN_CONFIG[selectedTier];

  const fmtCard   = (v: string) => v.replace(/\D/g,'').slice(0,16).replace(/(.{4})/g,'$1 ').trim();
  const fmtExpiry = (v: string) => {
    const d = v.replace(/\D/g,'').slice(0,4);
    return d.length >= 3 ? d.slice(0,2)+' / '+d.slice(2) : d;
  };

  const handleSubscribe = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      let userId: string;
      const { data: si, error: sie } = await supabase.auth.signInWithPassword({ email, password });
      if (sie) {
        const { data: su, error: sue } = await supabase.auth.signUp({ email, password });
        if (sue) throw sue;
        userId = su.user!.id;
      } else {
        userId = si.user.id;
      }
      const { error: subErr } = await supabase.from('subscriptions').insert({
        user_id:          userId,
        email,
        status:           'active',
        plan:             'monthly',
        plan_tier:        selectedTier,
        included_minutes: cfg.includedMinutes,
        overage_rate:     cfg.overageRate,
        amount:           cfg.price,
        currency:         'EUR',
      });
      if (subErr && !subErr.message.includes('duplicate')) throw subErr;
      onSubscribed();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Something went wrong.');
    } finally {
      setLoading(false);
    }
  };

  const { whole: priceWhole, cents: priceCents } = splitPrice(cfg.price);

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal modal--wide" onClick={e => e.stopPropagation()}>
        <button className="modal__close" onClick={onClose} aria-label="Close"><X size={18}/></button>

        {/* ── PLAN SELECTOR ── */}
        {step === 'plans' && (
          <div className="modal-plans">
            <div className="modal-plans__header">
              <div className="modal-plan__icon-wrap">
                <Zap size={20} className="modal-plan__icon"/>
              </div>
              <div>
                <h2 className="modal-plan__title">Choose Your Plan</h2>
                <p className="modal-plan__sub">All plans include 24/7 AI fallback across Spain</p>
              </div>
            </div>

            <div className="plan-cards">
              {(Object.keys(PLAN_CONFIG) as PlanTier[]).map(tier => {
                const c    = PLAN_CONFIG[tier];
                const Icon = PLAN_ICONS[tier];
                const sel  = tier === selectedTier;
                const { whole: w, cents: d } = splitPrice(c.price);
                return (
                  <button
                    key={tier}
                    className={`plan-card${sel ? ' plan-card--selected' : ''}`}
                    onClick={() => setSelectedTier(tier)}
                  >
                    {sel && <span className="plan-card__check"><Check size={11}/></span>}
                    <div className="plan-card__top">
                      <div className={`plan-card__icon plan-card__icon--${tier}`}><Icon size={16}/></div>
                      <span className="plan-card__badge">{c.badge}</span>
                    </div>
                    <div className="plan-card__name">{c.label}</div>
                    <div className="plan-card__price">
                      <span className="plan-card__cur">€</span>
                      <span className="plan-card__amount">{w}</span>
                      <span className="plan-card__cents">.{d}</span>
                      <span className="plan-card__period">/mo</span>
                    </div>
                    <div className="plan-card__mins">{c.includedMinutes} min included</div>
                  </button>
                );
              })}
            </div>

            <div className="plan-features">
              <ul className="modal-plan__features">
                {PLAN_FEATURES[selectedTier].map(f => (
                  <li key={f} className="modal-plan__feature">
                    <span className="modal-plan__feature-dot"><Check size={11}/></span>
                    {f}
                  </li>
                ))}
              </ul>
            </div>

            <div className="modal-plans__price-row">
              <div style={{display:'flex',alignItems:'baseline',gap:'1px'}}>
                <span className="modal-plan__currency">€</span>
                <span className="modal-plan__amount">{priceWhole}</span>
                <span className="modal-plan__cents">.{priceCents}</span>
              </div>
              <span className="modal-plan__period" style={{marginLeft:'6px'}}>/month · Cancel anytime</span>
            </div>

            <button className="modal__cta" onClick={() => setStep('payment')}>
              Continue to Payment <ChevronRight size={16}/>
            </button>
            <div className="modal-plan__trust">
              <Lock size={12}/><span>256-bit SSL · GDPR compliant · No hidden fees</span>
            </div>
          </div>
        )}

        {/* ── PAYMENT ── */}
        {step === 'payment' && (
          <div className="modal-pay">
            <button className="modal__back-btn" onClick={()=>setStep('plans')}>← Back</button>
            <div className="modal-pay__header">
              <h2 className="modal-pay__title">Secure Checkout</h2>
              <div className="modal-pay__badge"><Lock size={11}/> Secured</div>
            </div>
            <div className="modal-pay__summary">
              <span className="modal-pay__summary-label">{cfg.label}</span>
              <span className="modal-pay__summary-price">€{cfg.price.toFixed(2)}<span>/mo</span></span>
            </div>
            <div className="modal-pay__tabs">
              <button className={`modal-pay__tab${payMethod==='card'?' modal-pay__tab--active':''}`} onClick={()=>setPayMethod('card')}>
                <CardIcon/><span>Credit Card</span>
              </button>
              <button className={`modal-pay__tab${payMethod==='apple'?' modal-pay__tab--active':''}`} onClick={()=>setPayMethod('apple')}>
                <ApplePayIcon/>
              </button>
            </div>

            {payMethod === 'card' && (
              <>
                <CreditCardMockup name={cardName} number={cardNumber.replace(/ /g,'')} tier={selectedTier}/>
                <div className="modal-pay__fields">
                  <div className="modal-pay__field modal-pay__field--full">
                    <label className="modal-pay__label">Cardholder Name</label>
                    <input className="modal-pay__input" placeholder="Jane Doe" value={cardName} onChange={e=>setCardName(e.target.value)}/>
                  </div>
                  <div className="modal-pay__field modal-pay__field--full">
                    <label className="modal-pay__label">Card Number</label>
                    <div className="modal-pay__input-icon-wrap">
                      <input className="modal-pay__input" placeholder="1234 5678 9012 3456" inputMode="numeric" maxLength={19}
                        value={cardNumber} onChange={e=>setCardNumber(fmtCard(e.target.value))}/>
                      <span className="modal-pay__input-icon"><CardIcon/></span>
                    </div>
                  </div>
                  <div className="modal-pay__field">
                    <label className="modal-pay__label">Expiry</label>
                    <input className="modal-pay__input" placeholder="MM / YY" inputMode="numeric" maxLength={7}
                      value={cardExpiry} onChange={e=>setCardExpiry(fmtExpiry(e.target.value))}/>
                  </div>
                  <div className="modal-pay__field">
                    <label className="modal-pay__label">CVC</label>
                    <input className="modal-pay__input" placeholder="•••" inputMode="numeric" maxLength={4}
                      value={cardCvc} onChange={e=>setCardCvc(e.target.value.replace(/\D/g,'').slice(0,4))}/>
                  </div>
                </div>
                <button className="modal__cta" onClick={()=>setStep('auth')}>
                  <Lock size={15}/> Pay €{cfg.price.toFixed(2)} / month
                </button>
              </>
            )}

            {payMethod === 'apple' && (
              <div className="modal-pay__apple">
                <p className="modal-pay__apple-hint">Tap below to pay securely with Apple Pay. Your biometric authentication will be requested.</p>
                <button className="modal-pay__apple-btn" onClick={()=>setStep('auth')}><ApplePayIcon/></button>
              </div>
            )}

            <div className="modal-plan__trust" style={{marginTop:'12px'}}>
              <Lock size={12}/><span>Your payment info is never stored on our servers</span>
            </div>
          </div>
        )}

        {/* ── AUTH ── */}
        {step === 'auth' && (
          <div className="modal-auth">
            <button className="modal__back-btn" onClick={()=>setStep('payment')}>← Back</button>
            <div className="modal-auth__header">
              <div className="modal-auth__check"><Check size={18}/></div>
              <h2 className="modal-auth__title">Almost there</h2>
              <p className="modal-auth__sub">Create your account to activate {cfg.label}.</p>
            </div>

            <div className="modal-auth__tier-confirm">
              <Star size={13}/>
              <span>{cfg.label} · €{cfg.price.toFixed(2)}/mo · {cfg.includedMinutes} min included</span>
            </div>

            <form className="modal-auth__form" onSubmit={handleSubscribe}>
              <div className="modal-pay__field modal-pay__field--full">
                <label className="modal-pay__label">Email</label>
                <input type="email" required className="modal-pay__input" placeholder="you@example.com"
                  value={email} onChange={e=>setEmail(e.target.value)}/>
              </div>
              <div className="modal-pay__field modal-pay__field--full">
                <label className="modal-pay__label">Password</label>
                <input type="password" required minLength={6} className="modal-pay__input" placeholder="Min. 6 characters"
                  value={password} onChange={e=>setPassword(e.target.value)}/>
              </div>
              {error && <p className="modal__error">{error}</p>}
              <button type="submit" className="modal__cta" disabled={loading}>
                {loading ? <span className="modal__spinner"/> : <><Check size={16}/> Activate {cfg.label}</>}
              </button>
            </form>
            <p className="modal-auth__legal">
              By subscribing you agree to the Terms of Service. Billed monthly at €{cfg.price.toFixed(2)}.
              <br/>Overage at €{cfg.overageRate.toFixed(2)}/min after {cfg.includedMinutes} included minutes.
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
