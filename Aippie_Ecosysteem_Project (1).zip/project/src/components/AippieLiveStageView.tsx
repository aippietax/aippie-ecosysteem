/**
 * AippieLiveStageView — V213 Decentralized Live Concert Dashboard
 * AIPPIETAX S.A. · Aippie Live Stage S.A. · Module 20
 *
 * Left: simulated WebRTC live stream viewport with lock-gate overlay.
 * Right sidebar: Secure Token Ticket Gate (input + validate button).
 * On mount: TTS at rate 0.85 with word-by-word typewriter subtitle.
 */
import { useEffect, useRef, useState, useCallback } from 'react';
import {
  Radio, ShieldCheck, Zap, Music, Users, Activity,
  Lock, Unlock, Building2, Wifi, Eye, ChevronRight,
} from 'lucide-react';
import { withVoicesReady, selectPremiumVoice, normalizeForTTS } from '../lib/ttsVoice';
import { supabase } from '../lib/supabase';

// ── Constants ─────────────────────────────────────────────────────────────────
const TTS_TEXT = normalizeForTTS(
  'Aippie Live Stage initialized. Decentralized artist-to-fan entertainment architecture is live.'
);
const SUBTITLE_TEXT =
  'Aippie Live Stage initialized. Decentralized artist-to-fan entertainment architecture is live.';

const LIVE_STATUS_TEXT =
  '🔴 LIVE BROADCAST STABLE // 4K Audio-Visual Stream Engaged via Aippie Media Core.';

// Demo ticket codes that pass validation (fallback if DB unreachable)
const FALLBACK_CODES = new Set(['AIPPIE-VIP', 'STAGE-001', 'LIVE-2025', 'AIPPIE213', 'TESTCODE']);

// ── Telemetry stream rows ─────────────────────────────────────────────────────
const TELEMETRY = [
  { id: 'webrtc',   label: 'WebRTC P2P Node',       value: 'STABLE',    color: '#4ade80' },
  { id: 'latency',  label: 'Stream Latency',          value: '12 ms',     color: '#38bdf8' },
  { id: 'bitrate',  label: 'Video Bitrate',            value: '4K / 60fps', color: '#38bdf8' },
  { id: 'audio',    label: 'Audio Codec',              value: 'Opus 320k', color: '#4ade80' },
  { id: 'viewers',  label: 'Active Viewers',           value: '14,822',    color: '#fb923c' },
  { id: 'encrypt',  label: 'E2E Encryption',           value: 'AES-256',   color: '#4ade80' },
  { id: 'cdn',      label: 'Aippie Media Core CDN',   value: 'ONLINE',    color: '#4ade80' },
] as const;

// ── Typewriter hook ───────────────────────────────────────────────────────────
function useTypewriter(text: string, active: boolean, intervalMs = 62) {
  const [displayed, setDisplayed] = useState('');
  const idxRef = useRef(0);
  const tmrRef = useRef<ReturnType<typeof setInterval> | null>(null);

  useEffect(() => {
    if (tmrRef.current) { clearInterval(tmrRef.current); tmrRef.current = null; }
    setDisplayed('');
    idxRef.current = 0;
    if (!active || !text) return;
    tmrRef.current = setInterval(() => {
      idxRef.current++;
      setDisplayed(text.slice(0, idxRef.current));
      if (idxRef.current >= text.length && tmrRef.current) {
        clearInterval(tmrRef.current);
        tmrRef.current = null;
      }
    }, intervalMs);
    return () => { if (tmrRef.current) { clearInterval(tmrRef.current); tmrRef.current = null; } };
  }, [text, active, intervalMs]);

  return displayed;
}

// ── Animated neon VU bars ─────────────────────────────────────────────────────
function NeonVUBars({ active }: { active: boolean }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const frameRef  = useRef<number>(0);
  const tickRef   = useRef(0);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const draw = () => {
      tickRef.current++;
      const tk = tickRef.current;
      const W = canvas.width, H = canvas.height;
      ctx.clearRect(0, 0, W, H);
      const bars = 32;
      const gap = W / bars;
      const barW = Math.max(2, gap - 2);

      for (let i = 0; i < bars; i++) {
        const phase = (i / bars) * Math.PI * 2;
        const rawH = active
          ? (0.1 + 0.9 * Math.abs(Math.sin(tk * 0.07 + phase + Math.sin(tk * 0.023 + i * 0.5) * 1.1))) * H
          : (0.04 + 0.08 * Math.abs(Math.sin(tk * 0.01 + phase))) * H;
        const x = i * gap + (gap - barW) / 2;
        const y = (H - rawH) / 2;
        const grad = ctx.createLinearGradient(0, y, 0, y + rawH);
        grad.addColorStop(0,   active ? 'rgba(74,222,128,0.9)' : 'rgba(74,222,128,0.12)');
        grad.addColorStop(0.5, active ? 'rgba(34,197,94,1)'    : 'rgba(34,197,94,0.18)');
        grad.addColorStop(1,   active ? 'rgba(74,222,128,0.9)' : 'rgba(74,222,128,0.12)');
        ctx.fillStyle = grad;
        ctx.shadowColor = active ? '#4ade80' : 'transparent';
        ctx.shadowBlur  = active ? 6 : 0;
        ctx.beginPath();
        ctx.roundRect(x, y, barW, rawH, Math.min(barW / 2, 3));
        ctx.fill();
      }
      ctx.shadowBlur = 0;
      frameRef.current = requestAnimationFrame(draw);
    };

    frameRef.current = requestAnimationFrame(draw);
    return () => cancelAnimationFrame(frameRef.current);
  }, [active]);

  return (
    <canvas
      ref={canvasRef}
      width={340}
      height={40}
      aria-hidden="true"
      className="als-vu"
    />
  );
}

// ── Simulated concert stream visual ─────────────────────────────────────────
function StreamViewport({ unlocked, tick }: { unlocked: boolean; tick: number }) {
  const wave = Math.sin(tick * 0.05) * 0.5 + 0.5;

  return (
    <div className="als-stream-outer">
      {/* Simulated stage visuals */}
      <div className="als-stage-bg" aria-hidden="true">
        {/* Stage lighting beams */}
        {[0,1,2,3,4].map(i => (
          <div
            key={i}
            className="als-beam"
            style={{
              left: `${10 + i * 18}%`,
              opacity: 0.12 + 0.08 * Math.sin(tick * 0.04 + i * 1.2),
              transform: `rotate(${-20 + i * 12 + Math.sin(tick * 0.025 + i) * 6}deg)`,
            }}
          />
        ))}
        {/* Artist silhouette */}
        <svg viewBox="0 0 200 180" className="als-silhouette" aria-hidden="true">
          {/* Body */}
          <ellipse cx="100" cy="60"  rx="18" ry="22" fill="rgba(56,189,248,0.08)" />
          <rect    x="82"  y="82"  width="36" height="50" rx="8" fill="rgba(56,189,248,0.06)" />
          {/* Arms raised */}
          <line x1="82" y1="95"  x2="50"  y2="68"  stroke="rgba(56,189,248,0.10)" strokeWidth="8" strokeLinecap="round" />
          <line x1="118" y1="95" x2="150" y2="68"  stroke="rgba(56,189,248,0.10)" strokeWidth="8" strokeLinecap="round" />
          {/* Legs */}
          <line x1="90"  y1="132" x2="80"  y2="175" stroke="rgba(56,189,248,0.08)" strokeWidth="7" strokeLinecap="round" />
          <line x1="110" y1="132" x2="120" y2="175" stroke="rgba(56,189,248,0.08)" strokeWidth="7" strokeLinecap="round" />
          {/* Mic */}
          <circle cx="64"  cy="60"  r="4"  fill="rgba(56,189,248,0.18)" />
          <line   x1="64" y1="64"  x2="64" y2="82"  stroke="rgba(56,189,248,0.15)" strokeWidth="2" />
          {/* Crowd dots */}
          {[20,35,50,65,80,115,130,145,160,175].map((cx, i) => (
            <circle
              key={cx}
              cx={cx} cy={165 + (i % 3) * 5}
              r="3"
              fill={`rgba(56,189,248,${0.06 + 0.04 * Math.sin(tick * 0.08 + i)})`}
            />
          ))}
          {/* Stage floor glow */}
          <ellipse cx="100" cy="178" rx="80" ry="6" fill="rgba(14,165,233,0.06)" />
        </svg>

        {/* Scan-line overlay */}
        <div className="als-scanlines" />

        {/* Live badge */}
        {unlocked && (
          <div className="als-live-badge">
            <span className="als-live-badge__dot" style={{ opacity: 0.6 + 0.4 * wave }} />
            LIVE
          </div>
        )}

        {/* Audio VU bars overlay */}
        {unlocked && (
          <div className="als-vu-overlay">
            <NeonVUBars active={true} />
          </div>
        )}
      </div>

      {/* Lock gate overlay */}
      {!unlocked && (
        <div className="als-lock-overlay">
          <Lock size={28} className="als-lock-overlay__icon" />
          <p className="als-lock-overlay__label">Secure Stream</p>
          <p className="als-lock-overlay__sub">Enter your digital ticket code to unlock</p>
        </div>
      )}

      {/* Live status bar — shown when unlocked */}
      {unlocked && (
        <div className="als-live-status-bar">
          <Radio size={10} />
          <span>{LIVE_STATUS_TEXT}</span>
        </div>
      )}
    </div>
  );
}

// ── Main component ────────────────────────────────────────────────────────────
export default function AippieLiveStageView() {
  const [speaking,   setSpeaking]   = useState(false);
  const [unlocked,   setUnlocked]   = useState(false);
  const [ticketCode, setTicketCode] = useState('');
  const [validating, setValidating] = useState(false);
  const [ticketError,setTicketError]= useState('');
  const [tick,       setTick]       = useState(0);
  const cancelRef = useRef(false);
  const subtitle  = useTypewriter(SUBTITLE_TEXT, speaking, 62);

  // Tick for animations
  useEffect(() => {
    const id = setInterval(() => setTick(t => t + 1), 80);
    return () => clearInterval(id);
  }, []);

  // TTS on mount
  useEffect(() => {
    cancelRef.current = false;
    if (!('speechSynthesis' in window)) return;
    window.speechSynthesis.cancel();
    let delayTimer: ReturnType<typeof setTimeout> | null = null;

    withVoicesReady(() => {
      if (cancelRef.current) return;
      delayTimer = setTimeout(() => {
        if (cancelRef.current) return;
        const voices = window.speechSynthesis.getVoices();
        const { voice, isFallback } = selectPremiumVoice(voices);
        const u = new SpeechSynthesisUtterance(TTS_TEXT);
        u.rate  = 0.85;
        u.pitch = 1.02;
        u.lang  = 'en-US';
        if (voice) u.voice = voice;
        if (isFallback) { u.lang = 'en-US'; u.pitch = 1.05; }
        u.onstart = () => setSpeaking(true);
        u.onend   = () => setSpeaking(false);
        u.onerror = () => setSpeaking(false);
        window.speechSynthesis.speak(u);
      }, 700);
    });

    return () => {
      cancelRef.current = true;
      if (delayTimer) clearTimeout(delayTimer);
      window.speechSynthesis?.cancel();
    };
  }, []);

  const handleValidate = useCallback(async () => {
    const code = ticketCode.trim().toUpperCase();
    if (!code) { setTicketError('Please enter a ticket code.'); return; }
    setValidating(true);
    setTicketError('');

    // Check against DB first, fall back to hardcoded set
    const { data } = await supabase
      .from('live_stage_tickets')
      .select('id, redeemed')
      .eq('ticket_code', code)
      .maybeSingle();

    setValidating(false);
    if (data) {
      if (data.redeemed) {
        setTicketError('This ticket has already been used.');
        return;
      }
      // Mark as redeemed
      const deviceKey = localStorage.getItem('aippie_device_key') ?? 'anon';
      await supabase.from('live_stage_tickets').update({
        redeemed: true, redeemed_at: new Date().toISOString(), device_key: deviceKey,
      }).eq('id', data.id);
      setUnlocked(true);
    } else if (FALLBACK_CODES.has(code)) {
      setUnlocked(true);
    } else {
      setTicketError('Invalid ticket code. Try: AIPPIE-VIP');
    }
  }, [ticketCode]);

  return (
    <div className="als-root">
      {/* Ambient bg */}
      <div className="als-bg" aria-hidden="true">
        <div className="als-bg__grid" />
        <div className="als-bg__glow als-bg__glow--l" />
        <div className="als-bg__glow als-bg__glow--r" />
      </div>

      {/* ── Header ── */}
      <div className="als-header w-full max-w-[1600px] mx-auto px-6">
        <div className="als-header__badge">
          <span className="als-header__dot" />
          MODULE 20 · AIPPIE LIVE STAGE S.A.
        </div>
        <h1 className="als-header__title">
          Digital Ticket &amp; WebRTC Streaming Matrix
        </h1>
        <p className="als-header__sub">
          Decentralized Artist-to-Fan Concert Architecture · AIPPIETAX S.A. · v213
        </p>
      </div>

      {/* ── Body: stream left, ticket gate right ── */}
      <div className="als-body w-full max-w-[1600px] mx-auto px-6">

        {/* Stream viewport */}
        <div className="als-stream-panel">
          <div className="als-panel-label">
            <Radio size={11} />
            Live WebRTC Concert Stream
            {unlocked && <span className="als-panel-label__live">● LIVE</span>}
          </div>
          <StreamViewport unlocked={unlocked} tick={tick} />

          {/* Telemetry strip */}
          <div className="als-telemetry">
            {TELEMETRY.map(t => (
              <div key={t.id} className="als-tel-row">
                <span className="als-tel-row__label">{t.label}</span>
                <span className="als-tel-row__value" style={{ color: t.color }}>{t.value}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Ticket gate sidebar */}
        <div className="als-gate-panel">
          <div className="als-panel-label">
            <ShieldCheck size={11} />
            Secure Token Ticket Gate
          </div>

          {/* Status indicator */}
          <div className={`als-gate-status${unlocked ? ' als-gate-status--open' : ''}`}>
            {unlocked
              ? <><Unlock size={14} /><span>Stream Unlocked</span></>
              : <><Lock size={14} /><span>Stream Locked</span></>
            }
          </div>

          {/* Input area */}
          {!unlocked && (
            <div className="als-gate-form">
              <label className="als-gate-form__label" htmlFor="als-ticket-input">
                Digital Ticket Code
              </label>
              <input
                id="als-ticket-input"
                className="als-gate-form__input"
                type="text"
                placeholder="Enter Ticket Code (e.g. AIPPIE-VIP)"
                value={ticketCode}
                onChange={e => { setTicketCode(e.target.value); setTicketError(''); }}
                onKeyDown={e => { if (e.key === 'Enter') handleValidate(); }}
                disabled={validating}
                autoComplete="off"
                spellCheck={false}
              />
              {ticketError && (
                <p className="als-gate-form__error">{ticketError}</p>
              )}
              <button
                className={`als-gate-btn${validating ? ' als-gate-btn--loading' : ''}`}
                onClick={handleValidate}
                disabled={validating}
              >
                {validating
                  ? <><span className="als-gate-btn__spinner" />Validating…</>
                  : <><ShieldCheck size={13} />Validate &amp; Unlock Live Stream</>
                }
              </button>
              <p className="als-gate-form__hint">
                Demo codes: AIPPIE-VIP · STAGE-001 · LIVE-2025
              </p>
            </div>
          )}

          {/* Post-unlock info */}
          {unlocked && (
            <div className="als-gate-unlocked">
              <div className="als-gate-unlocked__row">
                <Zap size={13} />
                <span>4K Ultra-HD stream active</span>
              </div>
              <div className="als-gate-unlocked__row">
                <Wifi size={13} />
                <span>WebRTC node connected</span>
              </div>
              <div className="als-gate-unlocked__row">
                <Eye size={13} />
                <span>14,822 viewers online</span>
              </div>
              <div className="als-gate-unlocked__row">
                <Users size={13} />
                <span>Artist: Aippie Live — Private Session</span>
              </div>
            </div>
          )}

          {/* Feature list */}
          <div className="als-gate-features">
            {[
              ['Decentralized P2P nodes', '#4ade80'],
              ['Artist-owned stream key', '#38bdf8'],
              ['NFT ticket verification', '#fb923c'],
              ['Revenue split on-chain', '#4ade80'],
              ['Zero platform fees', '#38bdf8'],
            ].map(([label, color]) => (
              <div key={label} className="als-gate-feature">
                <ChevronRight size={10} style={{ color }} />
                <span>{label}</span>
              </div>
            ))}
          </div>

          {/* Tech stack badges */}
          <div className="als-gate-badges">
            {['WebRTC', 'IPFS', 'AES-256', 'Blockchain', 'v213'].map(b => (
              <span key={b} className="als-gate-badge">{b}</span>
            ))}
          </div>
        </div>
      </div>

      {/* ── Typewriter subtitle bar ── */}
      <div className="als-subtitle-bar w-full max-w-[1600px] mx-auto px-6">
        <div className="als-subtitle-bar__inner">
          {speaking && <span className="als-subtitle-bar__pulse" aria-hidden="true" />}
          <Music size={11} className="als-subtitle-bar__icon" />
          <span className="als-subtitle-bar__text">
            {subtitle || <span className="als-subtitle-bar__idle">Initializing Aippie Live Stage…</span>}
          </span>
          {speaking && <span className="als-subtitle-bar__cursor" aria-hidden="true" />}
        </div>
      </div>

      {/* ── Footer ── */}
      <div className="als-footer w-full max-w-[1600px] mx-auto px-6">
        <Building2 size={9} />
        <span>AIPPIETAX S.A.</span>
        <span className="als-footer__sep">·</span>
        <span>Aippie Live Stage S.A. · Module 20</span>
        <span className="als-footer__sep">·</span>
        <span>Decentralized Concert Architecture</span>
        <span className="als-footer__sep">·</span>
        <span>v213</span>
      </div>
    </div>
  );
}
