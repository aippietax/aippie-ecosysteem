import { ReactNode } from 'react';
import { Lock, Zap } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';

type Plan = 'starter' | 'business' | 'enterprise';

const PLAN_RANK: Record<Plan, number> = { starter: 1, business: 2, enterprise: 3 };
const DEV_EMAILS = ['elvin@aippietax.com', 'aippieai@gmail.com'];

interface PlanGateProps {
  requiredPlan: Plan;
  feature: string;
  currentPlan?: Plan;
  onUpgrade?: () => void;
  children: ReactNode;
}

export default function PlanGate({ requiredPlan, feature, currentPlan, onUpgrade, children }: PlanGateProps) {
  const { user } = useAuth();
  const isSubscribed =
    DEV_EMAILS.includes(user?.email ?? '') ||
    user?.user_metadata?.is_subscribed === true ||
    user?.user_metadata?.subscription_type === 'lifetime' ||
    user?.user_metadata?.subscription_type === 'annual';

  if (isSubscribed) return <>{children}</>;

  const rank = PLAN_RANK[currentPlan ?? 'starter'];
  const required = PLAN_RANK[requiredPlan];

  if (rank >= required) return <>{children}</>;

  return (
    <div className="plan-gate">
      <div className="plan-gate__icon">
        <Lock size={22} />
      </div>
      <div className="plan-gate__title">Función bloqueada</div>
      <div className="plan-gate__desc">
        <strong>{feature}</strong> requiere el plan <strong>{requiredPlan.charAt(0).toUpperCase() + requiredPlan.slice(1)}</strong> o superior.
      </div>
      <button className="plan-gate__btn" onClick={onUpgrade}>
        <Zap size={14} />
        Actualizar plan
      </button>
    </div>
  );
}
