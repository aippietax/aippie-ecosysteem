import { useEffect, useRef, useState } from 'react';
import AippieVoiceOverlay from './AippieVoiceOverlay';
import {
  Wifi, WifiOff, TrendingUp, Euro, Users, Signal, Database, Zap, DollarSign,
  CheckCircle2, ShieldCheck, X, Lock, CreditCard, Building2, KeyRound, Router, Tag,
} from 'lucide-react';
import { supabase, type WiFiNode, type CostaLocation, COSTA_LOCATIONS, WIFI_OWNER_RATE, WIFI_PLATFORM_RATE } from '../lib/supabase';
import SofiaTabShell from './SofiaTabShell';

const RATE_PER_GB = WIFI_OWNER_RATE + WIFI_PLATFORM_RATE;
const GREETING = 'Aippie is now automatically scanning for secure background routers. You do not need to search; I will handle authentication instantly.';

function signalBars(strength: number) {
  if (strength >= 80) return 'Excellent';
  if (strength >= 60) return 'Good';
  if (strength >= 40) return 'Fair';
  return 'Weak';
}

function fmt(n: number, d = 2) { return n.toFixed(d); }

type AutoPilotMode = 'none' | 'client' | 'owner';

// ── Owner Registration Modal ──────────────────────────────────────────────────
type OwnerModalProps = { onClose: () => void; onConfirm: (ssid: string, iban: string, pricePerGb: number) => Promise<void> };

function OwnerModal({ onClose, onConfirm }: OwnerModalProps) {
  const [ssid,       setSsid]       = useState('');
  const [pass,       setPass]       = useState('');
  const [iban,       setIban]       = useState('');
  const [pricePerGb, setPricePerGb] = useState('0.09');
  const [submitting, setSubmitting] = useState(false);
  const [error, setError]           = useState('');

  const handleSubmit = async () => {
    if (!ssid.trim()) { setError('Network name (SSID) is required.'); return; }
    if (!pass.trim()) { setError('Wi-Fi password is required.'); return; }
    if (!iban.trim() || iban.trim().length < 8) { setError('Please enter a valid IBAN.'); return; }
    const price = parseFloat(pricePerGb);
    if (isNaN(price) || price < 0.01 || price > 9.99) { setError('Price per GB must be between €0.01 and €9.99.'); return; }
    setError('');
    setSubmitting(true);
    await onConfirm(ssid.trim(), iban.trim().toUpperCase(), price);
    setSubmitting(false);
  };

  return (
    <div className="wf-modal-backdrop" onClick={e => e.target === e.currentTarget && onClose()}>
      <div className="wf-modal">
        <div className="wf-modal__header">
          <div className="wf-modal__icon wf-modal__icon--green"><Router size={18} /></div>
          <div>
            <div className="wf-modal__title">Register Your AippieWiFi Node</div>
            <div className="wf-modal__sub">Turn your router into a passive income stream</div>
          </div>
          <button className="wf-modal__close" onClick={onClose}><X size={16} /></button>
        </div>
        <div className="wf-modal__body">
          <div className="wf-modal__field">
            <label className="wf-modal__label"><Wifi size={12} /> Network Name (SSID)</label>
            <input className="wf-modal__input" type="text" placeholder="e.g. AippieNode_Marbella"
              value={ssid} onChange={e => setSsid(e.target.value)} maxLength={64} />
          </div>
          <div className="wf-modal__field">
            <label className="wf-modal__label"><KeyRound size={12} /> Wi-Fi Password</label>
            <input className="wf-modal__input" type="password" placeholder="Router admin password"
              value={pass} onChange={e => setPass(e.target.value)} maxLength={64} />
            <div className="wf-modal__hint">Stored end-to-end encrypted. Never shared.</div>
          </div>
          <div className="wf-modal__field">
            <label className="wf-modal__label"><Building2 size={12} /> Payout Bank Details (IBAN)</label>
            <input className="wf-modal__input wf-modal__input--mono" type="text"
              placeholder="e.g. ES76 0049 0001 5210 2041 5100"
              value={iban} onChange={e => setIban(e.target.value)} maxLength={34} />
          </div>
          <div className="wf-modal__field">
            <label className="wf-modal__label"><Tag size={12} /> Your Price per GB (€)</label>
            <input className="wf-modal__input wf-modal__input--mono" type="number" min="0.01" max="9.99" step="0.01"
              placeholder="e.g. 0.09"
              value={pricePerGb} onChange={e => setPricePerGb(e.target.value)} />
            <div className="wf-modal__hint">Your earnings per GB served · AIPPIETAX S.A. platform fee applies.</div>
          </div>
          {error && <div className="wf-modal__error">{error}</div>}
          <div className="wf-modal__terms">
            <ShieldCheck size={11} />
            By confirming you agree to the AippieWiFi Node Terms. Revenue credited weekly at your configured rate per GB.
          </div>
        </div>
        <div className="wf-modal__footer">
          <button className="wf-modal__cancel" onClick={onClose} disabled={submitting}>Cancel</button>
          <button className="wf-modal__confirm wf-modal__confirm--green" onClick={handleSubmit} disabled={submitting}>
            {submitting ? <span className="wf-modal__spinner" /> : <><DollarSign size={14} /> Confirm &amp; Start Earning</>}
          </button>
        </div>
      </div>
    </div>
  );
}

// ── Client Checkout Modal ─────────────────────────────────────────────────────
type ClientModalProps = { onClose: () => void; onAuthorize: () => void };

function ClientModal({ onClose, onAuthorize }: ClientModalProps) {
  const [cardNum, setCardNum] = useState('');
  const [expiry, setExpiry]   = useState('');
  const [cvc, setCvc]         = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [error, setError]     = useState('');

  const handleCardNum = (raw: string) => {
    const digits = raw.replace(/\D/g, '').slice(0, 16);
    setCardNum(digits.replace(/(.{4})/g, '$1 ').trim());
  };
  const handleExpiry = (raw: string) => {
    const digits = raw.replace(/\D/g, '').slice(0, 4);
    setExpiry(digits.length > 2 ? `${digits.slice(0, 2)}/${digits.slice(2)}` : digits);
  };
  const handleAuthorize = () => {
    const stripped = cardNum.replace(/\s/g, '');
    if (stripped.length < 16) { setError('Please enter a valid 16-digit card number.'); return; }
    if (expiry.length < 5)  { setError('Please enter card expiry (MM/YY).'); return; }
    if (cvc.length < 3)     { setError('Please enter a 3-digit CVC.'); return; }
    setError('');
    setSubmitting(true);
    setTimeout(() => { setSubmitting(false); onAuthorize(); }, 1600);
  };

  return (
    <div className="wf-modal-backdrop" onClick={e => e.target === e.currentTarget && onClose()}>
      <div className="wf-modal">
        <div className="wf-modal__header">
          <div className="wf-modal__icon wf-modal__icon--blue"><Zap size={18} /></div>
          <div>
            <div className="wf-modal__title">Activate AippieWiFi Auto-Pilot</div>
            <div className="wf-modal__sub">One-time deposit · Instant background authentication</div>
          </div>
          <button className="wf-modal__close" onClick={onClose}><X size={16} /></button>
        </div>
        <div className="wf-modal__body">
          <div className="wf-modal__terms-box">
            <Lock size={12} />
            <span><strong>Flat-rate deposit required</strong> to initiate network scanning. One-time €4.99 activation fee.</span>
          </div>
          <div className="wf-modal__field">
            <label className="wf-modal__label"><CreditCard size={12} /> Credit Card Number</label>
            <input className="wf-modal__input wf-modal__input--mono" type="text" inputMode="numeric"
              placeholder="4242 4242 4242 4242" value={cardNum} onChange={e => handleCardNum(e.target.value)} />
            <div className="wf-modal__hint">Test card: 4242 4242 4242 4242</div>
          </div>
          <div className="wf-modal__row">
            <div className="wf-modal__field">
              <label className="wf-modal__label">Expiry</label>
              <input className="wf-modal__input wf-modal__input--mono" type="text" inputMode="numeric"
                placeholder="MM/YY" value={expiry} onChange={e => handleExpiry(e.target.value)} maxLength={5} />
            </div>
            <div className="wf-modal__field">
              <label className="wf-modal__label">CVC</label>
              <input className="wf-modal__input wf-modal__input--mono" type="text" inputMode="numeric"
                placeholder="123" value={cvc} onChange={e => setCvc(e.target.value.replace(/\D/g, '').slice(0, 4))} maxLength={4} />
            </div>
          </div>
          {error && <div className="wf-modal__error">{error}</div>}
          <div className="wf-modal__terms">
            <ShieldCheck size={11} />
            Payments processed by AIPPIETAX S.A. · PCI-DSS Level 1 · 256-bit TLS encryption
          </div>
        </div>
        <div className="wf-modal__footer">
          <button className="wf-modal__cancel" onClick={onClose} disabled={submitting}>Cancel</button>
          <button className="wf-modal__confirm wf-modal__confirm--blue" onClick={handleAuthorize} disabled={submitting}>
            {submitting ? <span className="wf-modal__spinner" /> : <><Lock size={14} /> Authorize &amp; Connect</>}
          </button>
        </div>
      </div>
    </div>
  );
}

// ── Main WiFi View ────────────────────────────────────────────────────────────
export default function WiFiView() {
  const [nodes, setNodes]         = useState<WiFiNode[]>([]);
  const [location, setLocation]   = useState<CostaLocation>('Fuengirola');
  const [loading, setLoading]     = useState(true);
  const [simTick, setSimTick]     = useState(0);
  const [autoPilot, setAutoPilot] = useState<AutoPilotMode>('none');
  const [showOwnerModal, setShowOwnerModal]   = useState(false);
  const [showClientModal, setShowClientModal] = useState(false);
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const fetchNodes = async () => {
    const { data } = await supabase
      .from('aippiewifi_data_ledger').select('*')
      .eq('location', location).order('status', { ascending: false });
    if (data) setNodes(data as WiFiNode[]);
    setLoading(false);
  };

  useEffect(() => {
    setLoading(true);
    fetchNodes();
    const ch = supabase.channel(`wifi-${location}`)
      .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'aippiewifi_data_ledger' },
        (payload) => setNodes(prev => prev.map(n => n.id === (payload.new as WiFiNode).id ? payload.new as WiFiNode : n)))
      .subscribe();
    return () => { supabase.removeChannel(ch); };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [location]);

  useEffect(() => {
    intervalRef.current = setInterval(() => setSimTick(t => t + 1), 3000);
    return () => { if (intervalRef.current) clearInterval(intervalRef.current); };
  }, []);

  const handleOwnerConfirm = async (ssid: string, iban: string, pricePerGb: number) => {
    await supabase.from('aippiewifi_data_ledger').insert({
      node_id: `NODE-${Date.now()}`, node_name: ssid, owner_iban: iban, location,
      status: 'online', total_gb_served: 0, session_gb: 0, owner_earnings: 0,
      platform_margin: 0, connected_users: 0, signal_strength: 85,
      price_per_gb: pricePerGb,
    });
    setShowOwnerModal(false);
    setAutoPilot('owner');
    fetchNodes();
  };

  const onlineNodes   = nodes.filter(n => n.status === 'online');
  const offlineNodes  = nodes.filter(n => n.status === 'offline');
  const totalGB       = nodes.reduce((s, n) => s + Number(n.total_gb_served), 0);
  const totalEarnings = nodes.reduce((s, n) => s + Number(n.owner_earnings), 0);
  const totalUsers    = onlineNodes.reduce((s, n) => s + n.connected_users, 0);
  const clientActive  = autoPilot === 'client';
  const ownerActive   = autoPilot === 'owner';

  return (
    <>
      {showOwnerModal && (
        <OwnerModal onClose={() => setShowOwnerModal(false)} onConfirm={handleOwnerConfirm} />
      )}
      {showClientModal && (
        <ClientModal onClose={() => setShowClientModal(false)} onAuthorize={() => { setShowClientModal(false); setAutoPilot('client'); }} />
      )}

      <SofiaTabShell
        greeting={GREETING}
        serviceLabel="AippieWiFi · Auto-Pilot"
        trustLine="AIPPIETAX S.A. · PCI-DSS Level 1"
      >
        {/* Module overlay on portrait */}
        <div className="sts-wifi-overlay">

          {/* Auto-pilot status */}
          {autoPilot !== 'none' && (
            <div className="wifi-autopilot-banner">
              <span className="wifi-autopilot-banner__dot" />
              <span className="wifi-autopilot-banner__text">
                Auto-Pilot Active · {autoPilot === 'client' ? 'Auto-Connect Client' : 'Earning Mode'}
              </span>
              <ShieldCheck size={12} className="wifi-autopilot-banner__shield" />
            </div>
          )}

          {/* One-tap action cards */}
          <div className="sts-wifi-cards">
            <div className={`wifi-pilot-card${clientActive ? ' wifi-pilot-card--active' : ''}`}>
              <div className="wifi-pilot-card__top">
                <div className="wifi-pilot-card__icon-wrap wifi-pilot-card__icon-wrap--blue"><Zap size={18} /></div>
                <div className="wifi-pilot-card__text">
                  <div className="wifi-pilot-card__title">Auto-Connect Client</div>
                </div>
              </div>
              {clientActive
                ? <div className="wifi-pilot-card__done"><CheckCircle2 size={14} /> Auto-Pilot Active</div>
                : <button className="wifi-pilot-btn wifi-pilot-btn--blue" onClick={() => setShowClientModal(true)}>
                    <Zap size={13} /> ACTIVATE AUTO-CONNECT
                  </button>
              }
            </div>

            <div className={`wifi-pilot-card${ownerActive ? ' wifi-pilot-card--active wifi-pilot-card--active-owner' : ''}`}>
              <div className="wifi-pilot-card__top">
                <div className="wifi-pilot-card__icon-wrap wifi-pilot-card__icon-wrap--green"><DollarSign size={18} /></div>
                <div className="wifi-pilot-card__text">
                  <div className="wifi-pilot-card__title">Share My Wi-Fi &amp; Earn</div>
                </div>
              </div>
              {ownerActive
                ? <div className="wifi-pilot-card__done wifi-pilot-card__done--green"><CheckCircle2 size={14} /> Earning Mode Active</div>
                : <button className="wifi-pilot-btn wifi-pilot-btn--green" onClick={() => setShowOwnerModal(true)}>
                    <DollarSign size={13} /> SHARE &amp; START EARNING
                  </button>
              }
            </div>
          </div>

          {/* Summary stats */}
          <div className="wifi-summary">
            <div className="wifi-stat-card">
              <div className="wifi-stat-card__icon wifi-stat-card__icon--blue"><Wifi size={13} /></div>
              <div className="wifi-stat-card__body">
                <span className="wifi-stat-card__label">Nodes Online</span>
                <span className="wifi-stat-card__value">{onlineNodes.length}<span className="wifi-stat-card__unit">/{nodes.length}</span></span>
              </div>
            </div>
            <div className="wifi-stat-card">
              <div className="wifi-stat-card__icon wifi-stat-card__icon--green"><Users size={13} /></div>
              <div className="wifi-stat-card__body">
                <span className="wifi-stat-card__label">Active Users</span>
                <span className="wifi-stat-card__value">{totalUsers}</span>
              </div>
            </div>
            <div className="wifi-stat-card">
              <div className="wifi-stat-card__icon wifi-stat-card__icon--teal"><Database size={13} /></div>
              <div className="wifi-stat-card__body">
                <span className="wifi-stat-card__label">GB Served</span>
                <span className="wifi-stat-card__value">{fmt(totalGB, 1)}</span>
              </div>
            </div>
            <div className="wifi-stat-card wifi-stat-card--highlight">
              <div className="wifi-stat-card__icon wifi-stat-card__icon--amber"><Euro size={13} /></div>
              <div className="wifi-stat-card__body">
                <span className="wifi-stat-card__label">Node Earnings</span>
                <span className="wifi-stat-card__value">€{fmt(totalEarnings)}</span>
              </div>
            </div>
          </div>

          {/* Location tabs */}
          <div className="parking-location-tabs">
            {COSTA_LOCATIONS.map(loc => (
              <button key={loc}
                className={`parking-location-tab${location === loc ? ' parking-location-tab--active' : ''}`}
                onClick={() => setLocation(loc)}>{loc}</button>
            ))}
          </div>

          {/* Node list */}
          <div className="wifi-node-list">
            {loading ? (
              <div style={{ display:'flex', justifyContent:'center', padding:'16px' }}><span className="modal__spinner" /></div>
            ) : (
              <>
                {onlineNodes.map(node => {
                  const simExtra     = simTick * 0.0003 * node.connected_users;
                  const liveGB       = Number(node.session_gb) + simExtra;
                  const liveOwner    = Number(node.owner_earnings) + simExtra * WIFI_OWNER_RATE;
                  const livePlatform = Number(node.platform_margin) + simExtra * WIFI_PLATFORM_RATE;
                  return (
                    <div key={node.id} className="wifi-node-card wifi-node-card--online">
                      <div className="wifi-node-card__header">
                        <div className="wifi-node-card__name-row">
                          <span className="wifi-node-card__status-dot wifi-node-card__status-dot--online" />
                          <span className="wifi-node-card__name">{node.node_name}</span>
                        </div>
                        <span className="wifi-node-card__badge wifi-node-card__badge--online">ONLINE</span>
                      </div>
                      <div className="wifi-node-card__grid">
                        <div className="wifi-node-stat"><Signal size={10} /><span>{signalBars(node.signal_strength)} ({node.signal_strength}%)</span></div>
                        <div className="wifi-node-stat"><Users size={10} /><span>{node.connected_users} connected</span></div>
                        <div className="wifi-node-stat"><Database size={10} /><span>{fmt(liveGB, 2)} GB</span></div>
                        <div className="wifi-node-stat wifi-node-stat--live"><TrendingUp size={10} /><span className="wifi-node-stat__live-dot" />Live</div>
                      </div>
                      <div className="wifi-node-card__ledger">
                        <div className="wifi-ledger-row">
                          <span className="wifi-ledger-row__label">Owner (IBAN •••{node.owner_iban.slice(-4)})</span>
                          <span className="wifi-ledger-row__value wifi-ledger-row__value--owner">+€{fmt(liveOwner)}</span>
                        </div>
                        <div className="wifi-ledger-row">
                          <span className="wifi-ledger-row__label">AIPPIETAX S.A.</span>
                          <span className="wifi-ledger-row__value wifi-ledger-row__value--platform">+€{fmt(livePlatform)}</span>
                        </div>
                      </div>
                    </div>
                  );
                })}
                {offlineNodes.map(node => (
                  <div key={node.id} className="wifi-node-card wifi-node-card--offline">
                    <div className="wifi-node-card__header">
                      <div className="wifi-node-card__name-row">
                        <span className="wifi-node-card__status-dot" />
                        <span className="wifi-node-card__name">{node.node_name}</span>
                      </div>
                      <span className="wifi-node-card__badge wifi-node-card__badge--offline"><WifiOff size={10} /> OFFLINE</span>
                    </div>
                  </div>
                ))}
                {nodes.length === 0 && <div className="parking-empty">No nodes registered in {location}.</div>}
              </>
            )}
          </div>
        </div>
        <AippieVoiceOverlay context="wifi" />
      </SofiaTabShell>
    </>
  );
}
