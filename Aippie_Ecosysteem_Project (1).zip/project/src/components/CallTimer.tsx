type Props = {
  seconds: number;
};

export default function CallTimer({ seconds }: Props) {
  const mm = String(Math.floor(seconds / 60)).padStart(2, '0');
  const ss = String(seconds % 60).padStart(2, '0');

  return (
    <div className="call-timer">
      <span className="call-timer__label">Connected</span>
      <span className="call-timer__time">{mm}:{ss}</span>
    </div>
  );
}
