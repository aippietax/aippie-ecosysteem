import React, { useState } from 'react';
import type { User } from '@supabase/supabase-js';
import {
  PieChart,
  TrendingUp,
  TrendingDown,
  Shield,
  Scale,
  FileText,
  Building2,
  Zap,
  Download,
  Share2,
  Lock,
  CheckCircle,
  AlertTriangle,
  RefreshCw,
  Globe,
} from 'lucide-react';

interface AippieUnifiedDashboardProps {
  user: User | null;
}

// Sparkline component
const MiniSparkline: React.FC<{ data: number[]; color: string }> = ({ data, color }) => {
  const width = 60;
  const height = 20;
  const padding = 2;
  const chartWidth = width - 2 * padding;
  const chartHeight = height - 2 * padding;

  if (data.length < 2) return null;

  const min = Math.min(...data);
  const max = Math.max(...data);
  const range = max - min || 1;

  const points = data
    .map((value, index) => {
      const x = padding + (index / (data.length - 1)) * chartWidth;
      const y = padding + chartHeight - ((value - min) / range) * chartHeight;
      return `${x},${y}`;
    })
    .join(' ');

  return (
    <svg width={width} height={height} className="ufd-sparkline">
      <polyline points={points} fill="none" stroke={color} strokeWidth="1.5" vectorEffect="non-scaling-stroke" />
    </svg>
  );
};

// Risk Radar Gauge component
const RiskRadar: React.FC<{ riskPercentage: number }> = ({ riskPercentage }) => {
  const size = 120;
  const radius = 50;
  const angle = (riskPercentage / 100) * 360;
  const angleRad = (angle * Math.PI) / 180;
  const x = size / 2 + radius * Math.cos(angleRad - Math.PI / 2);
  const y = size / 2 + radius * Math.sin(angleRad - Math.PI / 2);

  const isGreen = riskPercentage < 25;
  const isAmber = riskPercentage >= 25 && riskPercentage < 60;
  const isRed = riskPercentage >= 60;

  let arcColor = '#22c55e'; // green
  if (isAmber) arcColor = '#f59e0b'; // amber
  if (isRed) arcColor = '#ef4444'; // red

  const largeArcFlag = angle > 180 ? 1 : 0;
  const pathData = `
    M ${size / 2} ${size / 2}
    L ${size / 2} ${size / 2 - radius}
    A ${radius} ${radius} 0 ${largeArcFlag} 1 ${x} ${y}
    Z
  `;

  return (
    <svg width={size} height={size} className="ufd-risk-radar">
      <circle cx={size / 2} cy={size / 2} r={radius} fill="none" stroke="#1e3a5f" strokeWidth="2" />
      <circle cx={size / 2} cy={size / 2} r={radius * 0.5} fill="none" stroke="#1e3a5f" strokeWidth="1" opacity="0.5" />
      <path d={pathData} fill={arcColor} opacity="0.7" />
      <circle cx={size / 2} cy={size / 2} r="6" fill="#fff" />
      <text x={size / 2} y={size / 2 + 30} textAnchor="middle" className="ufd-radar-label">
        {riskPercentage}%
      </text>
    </svg>
  );
};

// Tax Year Progress Bar
const TaxYearProgress: React.FC = () => {
  const months = ['J', 'F', 'M', 'A', 'M', 'J', 'J', 'A', 'S', 'O', 'N', 'D'];
  const currentMonth = 5; // June (0-indexed)
  const progress = ((currentMonth + 1) / 12) * 100;

  return (
    <div className="ufd-tax-year-progress">
      <div className="ufd-tax-year-bar">
        <div className="ufd-tax-year-fill" style={{ width: `${progress}%` }}></div>
        <div className="ufd-tax-year-months">
          {months.map((month, idx) => (
            <div
              key={idx}
              className={`ufd-month-marker ${idx === currentMonth ? 'current' : ''} ${idx < currentMonth ? 'past' : 'future'}`}
            >
              {month}
            </div>
          ))}
        </div>
      </div>
      <p className="ufd-tax-year-label">{progress.toFixed(0)}% through tax year</p>
    </div>
  );
};

export const AippieUnifiedDashboard: React.FC<AippieUnifiedDashboardProps> = ({ user }) => {
  const [selectedCountry, setSelectedCountry] = useState<'NL' | 'BE' | 'ES'>('NL');
  const [lastSyncTime] = useState(new Date(Date.now() - 2 * 60000)); // 2 minutes ago

  // Simulated portfolio data
  const portfolioAssets = [
    { symbol: 'BTC', name: 'Bitcoin', amount: 0.45, value: 18500, pnl: 2.3, icon: '₿', color: '#f7931a' },
    { symbol: 'ETH', name: 'Ethereum', amount: 5.2, value: 16200, pnl: 1.8, icon: 'Ξ', color: '#627eea' },
    { symbol: 'AAPL', name: 'Apple Inc', amount: 25, value: 4125, pnl: -0.5, icon: '🍎', color: '#555555' },
    { symbol: 'NVDA', name: 'NVIDIA', amount: 12, value: 5400, pnl: 3.1, icon: '⚡', color: '#76b900' },
    { symbol: 'GOLD', name: 'Physical Gold', amount: 15.5, value: 3095.8, pnl: 0.9, icon: '◆', color: '#ffd700' },
  ];

  const totalPortfolioValue = 47320.8;
  const dailyPnL = 2.3;

  // Tax data by country
  const taxData = {
    NL: {
      incomeTax: 8240,
      capitalGains: 2180,
      vat: 0,
      cryptoGains: 1340,
      country: 'Netherlands',
      flag: '🇳🇱',
    },
    BE: {
      incomeTax: 7950,
      capitalGains: 1920,
      vat: 450,
      cryptoGains: 1100,
      country: 'Belgium',
      flag: '🇧🇪',
    },
    ES: {
      incomeTax: 9100,
      capitalGains: 2450,
      vat: 800,
      cryptoGains: 1580,
      country: 'Spain',
      flag: '🇪🇸',
    },
  };

  const currentTaxData = taxData[selectedCountry];

  // Generate sparkline data (20 points)
  const generateSparklineData = (seed: number): number[] => {
    const data: number[] = [];
    let value = 50 + seed * 10;
    for (let i = 0; i < 20; i++) {
      value += (Math.random() - 0.5) * 20;
      data.push(Math.max(20, Math.min(80, value)));
    }
    return data;
  };

  const formatCurrency = (value: number, currency: string = '€'): string => {
    return `${currency}${value.toLocaleString('de-DE', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
  };

  const formatSyncTime = (date: Date): string => {
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffMins = Math.floor(diffMs / 60000);
    if (diffMins < 1) return 'Just now';
    if (diffMins === 1) return '1 minute ago';
    return `${diffMins} minutes ago`;
  };

  return (
    <div className="ufd-container">
      <style>{`
        .ufd-container {
          background: #060f1e;
          color: #e0e7ff;
          min-height: 100vh;
          font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
          padding: 24px;
        }

        .ufd-top-bar {
          display: flex;
          justify-content: space-between;
          align-items: center;
          margin-bottom: 32px;
          flex-wrap: wrap;
          gap: 16px;
        }

        .ufd-title {
          font-size: 28px;
          font-weight: 700;
          letter-spacing: -0.5px;
          background: linear-gradient(135deg, #00d4ff, #0099ff);
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
          background-clip: text;
        }

        .ufd-sync-info {
          display: flex;
          align-items: center;
          gap: 8px;
          font-size: 12px;
          color: #94a3b8;
        }

        .ufd-quick-stats {
          display: flex;
          gap: 24px;
          flex-wrap: wrap;
        }

        .ufd-quick-stat {
          display: flex;
          flex-direction: column;
          gap: 4px;
        }

        .ufd-quick-stat-label {
          font-size: 11px;
          color: #64748b;
          text-transform: uppercase;
          letter-spacing: 0.5px;
        }

        .ufd-quick-stat-value {
          font-size: 18px;
          font-weight: 700;
          color: #00d4ff;
        }

        .ufd-main-grid {
          display: grid;
          grid-template-columns: repeat(3, 1fr);
          gap: 24px;
          margin-bottom: 24px;
        }

        @media (max-width: 1400px) {
          .ufd-main-grid {
            grid-template-columns: 1fr;
          }
        }

        .ufd-column {
          display: flex;
          flex-direction: column;
          gap: 16px;
        }

        .ufd-card {
          background: #0c1a2e;
          border: 1px solid #1e3a5f;
          border-radius: 12px;
          padding: 20px;
          flex: 1;
        }

        .ufd-card-header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          margin-bottom: 16px;
          gap: 12px;
        }

        .ufd-card-title {
          font-size: 16px;
          font-weight: 700;
          letter-spacing: -0.3px;
        }

        .ufd-badge {
          display: inline-flex;
          align-items: center;
          gap: 6px;
          padding: 4px 12px;
          border-radius: 6px;
          font-size: 11px;
          font-weight: 600;
          white-space: nowrap;
        }

        .ufd-badge.success {
          background: rgba(34, 197, 94, 0.1);
          color: #22c55e;
        }

        .ufd-badge.warning {
          background: rgba(245, 158, 11, 0.1);
          color: #f59e0b;
        }

        .ufd-badge.danger {
          background: rgba(239, 68, 68, 0.1);
          color: #ef4444;
        }

        .ufd-badge.info {
          background: rgba(0, 212, 255, 0.1);
          color: #00d4ff;
        }

        .ufd-portfolio-value {
          display: flex;
          align-items: baseline;
          gap: 12px;
          margin-bottom: 8px;
        }

        .ufd-portfolio-value-main {
          font-size: 28px;
          font-weight: 700;
          color: #00d4ff;
        }

        .ufd-asset-row {
          display: flex;
          align-items: center;
          gap: 12px;
          padding: 12px;
          background: rgba(30, 58, 95, 0.3);
          border-radius: 8px;
          margin-bottom: 8px;
        }

        .ufd-asset-icon {
          width: 40px;
          height: 40px;
          border-radius: 50%;
          display: flex;
          align-items: center;
          justify-content: center;
          font-weight: 700;
          font-size: 18px;
          color: #fff;
          flex-shrink: 0;
        }

        .ufd-asset-info {
          flex: 1;
          min-width: 0;
        }

        .ufd-asset-symbol {
          font-size: 13px;
          font-weight: 700;
          color: #e0e7ff;
        }

        .ufd-asset-amount {
          font-size: 11px;
          color: #94a3b8;
        }

        .ufd-asset-values {
          display: flex;
          align-items: center;
          gap: 16px;
        }

        .ufd-asset-value {
          text-align: right;
          min-width: 70px;
        }

        .ufd-asset-value-main {
          font-size: 13px;
          font-weight: 700;
          color: #e0e7ff;
        }

        .ufd-asset-value-pnl {
          font-size: 11px;
          margin-top: 2px;
        }

        .ufd-asset-value-pnl.positive {
          color: #22c55e;
        }

        .ufd-asset-value-pnl.negative {
          color: #ef4444;
        }

        .ufd-sparkline {
          display: block;
        }

        .ufd-action-buttons {
          display: flex;
          gap: 12px;
          margin-top: 16px;
        }

        .ufd-btn {
          flex: 1;
          padding: 10px 16px;
          border: none;
          border-radius: 8px;
          font-size: 13px;
          font-weight: 600;
          cursor: pointer;
          transition: all 0.2s;
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 8px;
          white-space: nowrap;
        }

        .ufd-btn-primary {
          background: rgba(0, 212, 255, 0.1);
          color: #00d4ff;
          border: 1px solid #00d4ff;
        }

        .ufd-btn-primary:hover {
          background: rgba(0, 212, 255, 0.2);
        }

        .ufd-btn-secondary {
          background: rgba(34, 197, 94, 0.1);
          color: #22c55e;
          border: 1px solid #22c55e;
        }

        .ufd-btn-secondary:hover {
          background: rgba(34, 197, 94, 0.2);
        }

        .ufd-btn-tertiary {
          background: rgba(245, 158, 11, 0.1);
          color: #f59e0b;
          border: 1px solid #f59e0b;
        }

        .ufd-btn-tertiary:hover {
          background: rgba(245, 158, 11, 0.2);
        }

        .ufd-ai-box {
          background: rgba(0, 212, 255, 0.05);
          border: 1px solid rgba(0, 212, 255, 0.2);
          border-radius: 8px;
          padding: 12px;
          margin-top: 12px;
          font-size: 12px;
          line-height: 1.5;
        }

        .ufd-ai-box-title {
          font-weight: 600;
          color: #00d4ff;
          margin-bottom: 4px;
          display: flex;
          align-items: center;
          gap: 6px;
        }

        .ufd-country-selector {
          display: flex;
          gap: 8px;
        }

        .ufd-country-btn {
          padding: 6px 12px;
          border: 1px solid #1e3a5f;
          border-radius: 6px;
          background: transparent;
          color: #94a3b8;
          font-size: 12px;
          font-weight: 600;
          cursor: pointer;
          transition: all 0.2s;
        }

        .ufd-country-btn.active {
          background: rgba(0, 212, 255, 0.15);
          border-color: #00d4ff;
          color: #00d4ff;
        }

        .ufd-country-btn:hover {
          border-color: #00d4ff;
        }

        .ufd-tax-year-progress {
          margin-bottom: 16px;
        }

        .ufd-tax-year-bar {
          position: relative;
          height: 40px;
          background: #1e3a5f;
          border-radius: 8px;
          overflow: hidden;
          margin-bottom: 8px;
        }

        .ufd-tax-year-fill {
          position: absolute;
          left: 0;
          top: 0;
          height: 100%;
          background: linear-gradient(90deg, rgba(34, 197, 94, 0.3), rgba(0, 212, 255, 0.3));
          border-right: 2px solid #00d4ff;
        }

        .ufd-tax-year-months {
          display: flex;
          height: 100%;
          position: relative;
          z-index: 2;
        }

        .ufd-month-marker {
          flex: 1;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 10px;
          font-weight: 600;
          color: #64748b;
          border-right: 1px solid rgba(30, 58, 95, 0.5);
        }

        .ufd-month-marker.current {
          color: #00d4ff;
          background: rgba(0, 212, 255, 0.1);
        }

        .ufd-month-marker.past {
          color: #22c55e;
        }

        .ufd-tax-year-label {
          font-size: 11px;
          color: #64748b;
          margin: 0;
        }

        .ufd-tax-card {
          background: rgba(30, 58, 95, 0.3);
          border-radius: 8px;
          padding: 12px;
          margin-bottom: 8px;
          display: flex;
          justify-content: space-between;
          align-items: center;
        }

        .ufd-tax-card-label {
          font-size: 12px;
          color: #94a3b8;
        }

        .ufd-tax-card-value {
          font-size: 16px;
          font-weight: 700;
        }

        .ufd-tax-card.income .ufd-tax-card-value {
          color: #f59e0b;
        }

        .ufd-tax-card.gains .ufd-tax-card-value {
          color: #ef4444;
        }

        .ufd-tax-card.vat .ufd-tax-card-value {
          color: #22c55e;
        }

        .ufd-tax-card.crypto .ufd-tax-card-value {
          color: #f7931a;
        }

        .ufd-compliance-score {
          background: rgba(34, 197, 94, 0.1);
          border: 1px solid rgba(34, 197, 94, 0.3);
          border-radius: 8px;
          padding: 12px;
          text-align: center;
          margin-top: 12px;
        }

        .ufd-compliance-score-value {
          font-size: 24px;
          font-weight: 700;
          color: #22c55e;
        }

        .ufd-compliance-score-label {
          font-size: 11px;
          color: #64748b;
          margin-top: 4px;
        }

        .ufd-legal-layer {
          background: rgba(30, 58, 95, 0.3);
          border-radius: 8px;
          padding: 12px;
          margin-bottom: 8px;
          display: flex;
          justify-content: space-between;
          align-items: center;
        }

        .ufd-legal-layer-info {
          flex: 1;
        }

        .ufd-legal-layer-name {
          font-size: 13px;
          font-weight: 700;
          color: #e0e7ff;
        }

        .ufd-legal-layer-detail {
          font-size: 11px;
          color: #94a3b8;
          margin-top: 2px;
        }

        .ufd-legal-layer-status {
          font-size: 12px;
          font-weight: 600;
          color: #22c55e;
          display: flex;
          align-items: center;
          gap: 4px;
        }

        .ufd-risk-radar {
          display: block;
          margin: 0 auto;
        }

        .ufd-radar-label {
          font-size: 12px;
          font-weight: 700;
          fill: #00d4ff;
        }

        .ufd-legal-alert {
          background: rgba(245, 158, 11, 0.1);
          border: 1px solid rgba(245, 158, 11, 0.3);
          border-radius: 8px;
          padding: 12px;
          margin-bottom: 12px;
          display: flex;
          gap: 8px;
        }

        .ufd-legal-alert-icon {
          color: #f59e0b;
          flex-shrink: 0;
          margin-top: 2px;
        }

        .ufd-legal-alert-text {
          font-size: 12px;
          color: #e0e7ff;
        }

        .ufd-legal-alert-label {
          color: #f59e0b;
          font-weight: 600;
        }

        .ufd-bottom-bar {
          display: flex;
          gap: 12px;
          margin-top: 24px;
          flex-wrap: wrap;
        }

        .ufd-btn-export {
          flex: 1;
          min-width: 200px;
        }

        .ufd-btn-share {
          flex: 1;
          min-width: 200px;
        }

        .ufd-btn-upgrade {
          min-width: 200px;
          background: linear-gradient(135deg, rgba(250, 204, 21, 0.2), rgba(245, 158, 11, 0.2));
          border: 1px solid #fbbf24;
          color: #fbbf24;
        }

        .ufd-btn-upgrade:hover {
          background: linear-gradient(135deg, rgba(250, 204, 21, 0.3), rgba(245, 158, 11, 0.3));
        }

        @media (max-width: 768px) {
          .ufd-container {
            padding: 12px;
          }

          .ufd-top-bar {
            margin-bottom: 24px;
          }

          .ufd-title {
            font-size: 20px;
          }

          .ufd-quick-stats {
            width: 100%;
            gap: 12px;
          }

          .ufd-main-grid {
            gap: 16px;
          }

          .ufd-card {
            padding: 16px;
          }

          .ufd-bottom-bar {
            flex-direction: column;
          }

          .ufd-btn-export,
          .ufd-btn-share,
          .ufd-btn-upgrade {
            min-width: 100%;
          }
        }
      `}</style>

      {/* TOP BAR */}
      <div className="ufd-top-bar">
        <div className="ufd-title">AIPPIE UNIFIED FINANCE</div>
        <div className="ufd-sync-info">
          <RefreshCw size={12} />
          <span>Last sync: {formatSyncTime(lastSyncTime)}</span>
        </div>
        <div className="ufd-quick-stats">
          <div className="ufd-quick-stat">
            <div className="ufd-quick-stat-label">Net Worth</div>
            <div className="ufd-quick-stat-value">{formatCurrency(totalPortfolioValue)}</div>
          </div>
          <div className="ufd-quick-stat">
            <div className="ufd-quick-stat-label">Tax Saved (YTD)</div>
            <div className="ufd-quick-stat-value">{formatCurrency(4280)}</div>
          </div>
          <div className="ufd-quick-stat">
            <div className="ufd-quick-stat-label">Legal Score</div>
            <div className="ufd-quick-stat-value">94/100</div>
          </div>
        </div>
      </div>

      {/* MAIN 3-COLUMN GRID */}
      <div className="ufd-main-grid">
        {/* COLUMN 1: PORTFOLIO OVERVIEW */}
        <div className="ufd-column">
          <div className="ufd-card">
            <div className="ufd-card-header">
              <div className="ufd-card-title">PORTFOLIO</div>
              <div
                className={`ufd-badge ${dailyPnL >= 0 ? 'success' : 'danger'}`}
              >
                {dailyPnL >= 0 ? <TrendingUp size={12} /> : <TrendingDown size={12} />}
                {dailyPnL >= 0 ? '+' : ''}{dailyPnL.toFixed(1)}%
              </div>
            </div>

            <div className="ufd-portfolio-value">
              <div className="ufd-portfolio-value-main">{formatCurrency(totalPortfolioValue)}</div>
            </div>

            {portfolioAssets.map((asset, idx) => (
              <div key={idx} className="ufd-asset-row">
                <div className="ufd-asset-icon" style={{ backgroundColor: asset.color }}>
                  {asset.icon}
                </div>
                <div className="ufd-asset-info">
                  <div className="ufd-asset-symbol">{asset.symbol}</div>
                  <div className="ufd-asset-amount">
                    {asset.amount.toFixed(2)} {asset.symbol}
                  </div>
                </div>
                <div className="ufd-asset-values">
                  <div className="ufd-asset-value">
                    <div className="ufd-asset-value-main">{formatCurrency(asset.value)}</div>
                    <div className={`ufd-asset-value-pnl ${asset.pnl >= 0 ? 'positive' : 'negative'}`}>
                      {asset.pnl >= 0 ? '+' : ''}{asset.pnl.toFixed(1)}%
                    </div>
                  </div>
                  <MiniSparkline
                    data={generateSparklineData(idx)}
                    color={asset.pnl >= 0 ? '#22c55e' : '#ef4444'}
                  />
                </div>
              </div>
            ))}

            <div className="ufd-action-buttons">
              <button className="ufd-btn ufd-btn-primary">+ ADD ASSET</button>
              <button className="ufd-btn ufd-btn-secondary">⚡ REBALANCE AI</button>
            </div>

            <div className="ufd-ai-box">
              <div className="ufd-ai-box-title">
                <Zap size={12} />
                AI Recommendation
              </div>
              <div>Overweight in BTC — consider rebalancing to 40/30/30 split for optimal diversification.</div>
            </div>
          </div>
        </div>

        {/* COLUMN 2: TAX STATUS */}
        <div className="ufd-column">
          <div className="ufd-card">
            <div className="ufd-card-header">
              <div className="ufd-card-title">TAX ENGINE</div>
              <div className="ufd-country-selector">
                {(['NL', 'BE', 'ES'] as const).map((country) => (
                  <button
                    key={country}
                    className={`ufd-country-btn ${selectedCountry === country ? 'active' : ''}`}
                    onClick={() => setSelectedCountry(country)}
                  >
                    {country} {taxData[country].flag}
                  </button>
                ))}
              </div>
            </div>

            <TaxYearProgress />

            <div className="ufd-tax-card income">
              <div className="ufd-tax-card-label">Income Tax</div>
              <div className="ufd-tax-card-value">{formatCurrency(currentTaxData.incomeTax)}</div>
            </div>

            <div className="ufd-tax-card gains">
              <div className="ufd-tax-card-label">Capital Gains</div>
              <div className="ufd-tax-card-value">{formatCurrency(currentTaxData.capitalGains)}</div>
            </div>

            <div className="ufd-tax-card vat">
              <div className="ufd-tax-card-label">VAT/BTW</div>
              <div className="ufd-tax-card-value">{formatCurrency(currentTaxData.vat)}</div>
            </div>

            <div className="ufd-tax-card crypto">
              <div className="ufd-tax-card-label">Crypto Gains</div>
              <div className="ufd-tax-card-value">{formatCurrency(currentTaxData.cryptoGains)}</div>
            </div>

            <button className="ufd-btn ufd-btn-primary" style={{ marginTop: '12px' }}>
              <FileText size={14} />
              GENERATE REPORT
            </button>

            <div className="ufd-ai-box">
              <div className="ufd-ai-box-title">
                <Zap size={12} />
                Tax Tip
              </div>
              <div>Contributing to your pension reduces taxable income by up to €14,000 per year.</div>
            </div>

            <div className="ufd-compliance-score">
              <div className="ufd-compliance-score-value">94/100</div>
              <div className="ufd-compliance-score-label">Compliance Score</div>
            </div>
          </div>
        </div>

        {/* COLUMN 3: LEGAL SHIELD */}
        <div className="ufd-column">
          <div className="ufd-card">
            <div className="ufd-card-header">
              <div className="ufd-card-title">LEGAL SHIELD</div>
              <div className="ufd-badge success">
                <CheckCircle size={12} />
                ACTIVE
              </div>
            </div>

            <div className="ufd-legal-layer">
              <div className="ufd-legal-layer-info">
                <div className="ufd-legal-layer-name">LLC Structure</div>
                <div className="ufd-legal-layer-detail">Aippie Holdings BV</div>
              </div>
              <div className="ufd-legal-layer-status">
                <CheckCircle size={14} />
                Active
              </div>
            </div>

            <div className="ufd-legal-layer">
              <div className="ufd-legal-layer-info">
                <div className="ufd-legal-layer-name">IP Protection</div>
                <div className="ufd-legal-layer-detail">3 assets registered</div>
              </div>
              <div style={{ color: '#22c55e', fontWeight: '600' }}>✓</div>
            </div>

            <div className="ufd-legal-layer">
              <div className="ufd-legal-layer-info">
                <div className="ufd-legal-layer-name">Contract Vault</div>
                <div className="ufd-legal-layer-detail">7 agreements stored</div>
              </div>
              <div style={{ color: '#22c55e', fontWeight: '600' }}>✓</div>
            </div>

            <div style={{ marginTop: '16px', textAlign: 'center' }}>
              <RiskRadar riskPercentage={12} />
              <div style={{ fontSize: '11px', color: '#94a3b8', marginTop: '8px' }}>Legal Exposure Score</div>
            </div>

            <div className="ufd-legal-alert">
              <div className="ufd-legal-alert-icon">
                <AlertTriangle size={16} />
              </div>
              <div>
                <div className="ufd-legal-alert-label">1 Contract Expiring</div>
                <div className="ufd-legal-alert-text">Service agreement expires in 30 days</div>
              </div>
            </div>

            <div className="ufd-action-buttons">
              <button className="ufd-btn ufd-btn-secondary">
                <Scale size={14} />
                AI LEGAL REVIEW
              </button>
              <button className="ufd-btn ufd-btn-primary">
                <FileText size={14} />
                DRAFT CONTRACT
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* BOTTOM BAR */}
      <div className="ufd-bottom-bar">
        <button className="ufd-btn ufd-btn-primary ufd-btn-export">
          <Download size={14} />
          EXPORT FULL REPORT
        </button>
        <button className="ufd-btn ufd-btn-primary ufd-btn-share">
          <Share2 size={14} />
          SHARE WITH ADVISOR
        </button>
        <button className="ufd-btn ufd-btn-upgrade">
          <Zap size={14} />
          UPGRADE TO PRO
        </button>
      </div>
    </div>
  );
};

export default AippieUnifiedDashboard;
