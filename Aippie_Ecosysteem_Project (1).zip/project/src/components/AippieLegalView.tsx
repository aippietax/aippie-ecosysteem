import { useCallback, useEffect, useRef, useState } from 'react';
import {
  Scale, ShieldCheck, Star, Phone, MessageSquare, Mail,
  FileSearch, Upload, CheckCircle, Clock, Wifi, WifiOff,
  ChevronRight, AlertTriangle, Landmark, RefreshCw, Check, X
} from 'lucide-react';
import { supabase } from '../lib/supabase';
import type { User } from '@supabase/supabase-js';

// ── Types ─────────────────────────────────────────────────────────────────────
interface Lawyer {
  lawyer_id: string;
  full_name: string;
  bar_registration_number: string;
  specialization_tags: string[];
  performance_score: number;
  has_green_verified_badge: boolean;
  monthly_subscription_fee_eur: number;
  is_available_live: boolean;
}

interface LegalScan {
  scan_id: string;
  ai_analysis_summary: string;
  disclaimer_accepted: boolean;
  created_at: string;
}

interface LawyerSession {
  session_id: string;
  lawyer_id: string;
  session_type: 'LIVE_CALL' | 'CHAT_STREAM' | 'SECURE_MESSAGE';
  session_status: 'CONNECTED' | 'COMPLETED' | 'MISSED';
  escrow_payment_apc: number;
  created_at: string;
}

interface WalletSubs {
  consumer_legal_sub_active: boolean;
  lawyer_premium_sub_active: boolean;
  balance_apc: number;
}

type ActivePanel = 'directory' | 'scan' | 'sessions';

// ── Constants ─────────────────────────────────────────────────────────────────
const CONSUMER_PLAN_EUR = 5.00;
const SESSION_RATE_APC  = 2.50; // per session initiation (escrow)
const FEE_PCT           = 0.01;

// ── Seed demo lawyers for empty state ────────────────────────────────────────
const DEMO_LAWYERS: Lawyer[] = [
  {
    lawyer_id: 'demo-1',
    full_name: 'María García Fernández',
    bar_registration_number: 'MAD-2847',
    specialization_tags: ['Real Estate', 'Contract Law', 'Spanish NIE'],
    performance_score: 4.92,
    has_green_verified_badge: true,
    monthly_subscription_fee_eur: 5.00,
    is_available_live: true,
  },
  {
    lawyer_id: 'demo-2',
    full_name: 'Johan van der Berg',
    bar_registration_number: 'BCN-1193',
    specialization_tags: ['Immigration', 'Residency Permits', 'Dutch-Spanish Law'],
    performance_score: 4.85,
    has_green_verified_badge: true,
    monthly_subscription_fee_eur: 5.00,
    is_available_live: true,
  },
  {
    lawyer_id: 'demo-3',
    full_name: 'Alejandro Ruiz Morales',
    bar_registration_number: 'MAL-0472',
    specialization_tags: ['Tax Law', 'Corporate', 'AEAT Compliance'],
    performance_score: 4.78,
    has_green_verified_badge: true,
    monthly_subscription_fee_eur: 5.00,
    is_available_live: false,
  },
];

// ── Helpers ───────────────────────────────────────────────────────────────────
function Stars({ score }: { score: number }) {
  const full  = Math.floor(score);
  const frac  = score - full;
  return (
    <div className="al-stars">
      {[1,2,3,4,5].map(i => (
        <Star
          key={i}
          size={12}
          className={i <= full ? 'al-star--full' : frac > 0.4 && i === full + 1 ? 'al-star--half' : 'al-star--empty'}
          fill={i <= full ? '#f59e0b' : 'none'}
        />
      ))}
      <span className="al-stars__val">{score.toFixed(2)}</span>
    </div>
  );
}

function SessionTypeBadge({ type }: { type: LawyerSession['session_type'] }) {
  const map = {
    LIVE_CALL:      { icon: <Phone size={11} />,        label: 'Live Call',    cls: 'al-badge--call'    },
    CHAT_STREAM:    { icon: <MessageSquare size={11} />, label: 'Chat',        cls: 'al-badge--chat'    },
    SECURE_MESSAGE: { icon: <Mail size={11} />,          label: 'Secure Msg',  cls: 'al-badge--msg'     },
  };
  const { icon, label, cls } = map[type];
  return <span className={`al-badge ${cls}`}>{icon}{label}</span>;
}

// ── Lawyer card ───────────────────────────────────────────────────────────────
function LawyerCard({
  lawyer,
  onContact,
  subscribed,
}: {
  lawyer: Lawyer;
  onContact: (lawyer: Lawyer, type: LawyerSession['session_type']) => void;
  subscribed: boolean;
}) {
  const [expanded, setExpanded] = useState(false);

  return (
    <div className="al-lawyer-card">
      <div className="al-lawyer-card__top">
        <div className="al-lawyer-card__avatar">
          <Scale size={20} />
        </div>
        <div className="al-lawyer-card__info">
          <div className="al-lawyer-card__name-row">
            <span className="al-lawyer-card__name">{lawyer.full_name}</span>
            {lawyer.has_green_verified_badge && (
              <span className="al-green-badge">
                <CheckCircle size={12} /> Verified
              </span>
            )}
          </div>
          <span className="al-lawyer-card__bar">Reg. {lawyer.bar_registration_number}</span>
          <Stars score={lawyer.performance_score} />
        </div>
        <div className="al-lawyer-card__right">
          <span className={`al-live-dot${lawyer.is_available_live ? ' al-live-dot--on' : ' al-live-dot--off'}`}>
            {lawyer.is_available_live ? <Wifi size={11} /> : <WifiOff size={11} />}
            {lawyer.is_available_live ? 'Live' : 'Offline'}
          </span>
          <button
            className="al-expand-btn"
            onClick={() => setExpanded(e => !e)}
            aria-label={expanded ? 'Collapse' : 'Expand'}
          >
            <ChevronRight size={14} className={expanded ? 'rotate-90' : ''} style={{ transition: 'transform 0.2s' }} />
          </button>
        </div>
      </div>

      <div className="al-lawyer-card__tags">
        {lawyer.specialization_tags.map(tag => (
          <span key={tag} className="al-tag">{tag}</span>
        ))}
      </div>

      {expanded && (
        <div className="al-lawyer-card__actions">
          {subscribed ? (
            <>
              <button
                className="al-contact-btn al-contact-btn--call"
                onClick={() => onContact(lawyer, 'LIVE_CALL')}
                disabled={!lawyer.is_available_live}
              >
                <Phone size={13} /> Live Call
              </button>
              <button
                className="al-contact-btn al-contact-btn--chat"
                onClick={() => onContact(lawyer, 'CHAT_STREAM')}
              >
                <MessageSquare size={13} /> Chat
              </button>
              <button
                className="al-contact-btn al-contact-btn--msg"
                onClick={() => onContact(lawyer, 'SECURE_MESSAGE')}
              >
                <Mail size={13} /> Secure Message
              </button>
            </>
          ) : (
            <p className="al-lawyer-card__cta">
              Subscribe to the Consumer Legal Plan (€{CONSUMER_PLAN_EUR}/mo) to contact lawyers.
            </p>
          )}
          <p className="al-lawyer-card__rate">
            Session escrow: {SESSION_RATE_APC} APC · 1% platform fee
          </p>
        </div>
      )}
    </div>
  );
}

// ── Main component ────────────────────────────────────────────────────────────
export default function AippieLegalView({ user }: { user: User | null }) {
  const [panel, setPanel]           = useState<ActivePanel>('directory');
  const [lawyers, setLawyers]       = useState<Lawyer[]>([]);
  const [scans, setScans]           = useState<LegalScan[]>([]);
  const [sessions, setSessions]     = useState<LawyerSession[]>([]);
  const [walletSubs, setWalletSubs] = useState<WalletSubs | null>(null);
  const [loading, setLoading]       = useState(true);
  const [busy, setBusy]             = useState(false);
  const [feedback, setFeedback]     = useState<{ ok: boolean; msg: string } | null>(null);

  // Scan form
  const [scanText, setScanText]         = useState('');
  const [disclaimerChecked, setDisclaimer] = useState(false);
  const [scanResult, setScanResult]     = useState<string | null>(null);

  const mountedRef = useRef(true);

  const flash = (ok: boolean, msg: string) => {
    setFeedback({ ok, msg });
    setTimeout(() => { if (mountedRef.current) setFeedback(null); }, 4500);
  };

  // ── Load data ───────────────────────────────────────────────────────────────
  const load = useCallback(async () => {
    setLoading(true);

    const lawyersRes = await supabase
      .from('aippie_lawyers')
      .select('*')
      .eq('has_green_verified_badge', true)
      .order('performance_score', { ascending: false });

    const displayLawyers = (lawyersRes.data && lawyersRes.data.length > 0)
      ? (lawyersRes.data as Lawyer[])
      : DEMO_LAWYERS;

    if (!mountedRef.current) return;
    setLawyers(displayLawyers);

    if (user) {
      const [walletRes, scansRes, sessionsRes] = await Promise.all([
        supabase
          .from('apc_wallets')
          .select('consumer_legal_sub_active, lawyer_premium_sub_active, balance_apc')
          .eq('user_id', user.id)
          .maybeSingle(),
        supabase
          .from('aippie_legal_scans')
          .select('*')
          .eq('user_id', user.id)
          .order('created_at', { ascending: false })
          .limit(20),
        supabase
          .from('aippie_lawyer_sessions')
          .select('*')
          .eq('client_id', user.id)
          .order('created_at', { ascending: false })
          .limit(20),
      ]);

      if (!mountedRef.current) return;
      setWalletSubs(walletRes.data as WalletSubs | null);
      setScans((scansRes.data ?? []) as LegalScan[]);
      setSessions((sessionsRes.data ?? []) as LawyerSession[]);
    }

    setLoading(false);
  }, [user]);

  useEffect(() => {
    mountedRef.current = true;
    load();
    return () => { mountedRef.current = false; };
  }, [load]);

  // ── Subscribe consumer legal plan ───────────────────────────────────────────
  const handleSubscribe = async () => {
    if (!user) { flash(false, 'Sign in to subscribe'); return; }
    setBusy(true);

    // Deduct via apc_deposit logic — use transfer to self as subscription debit
    const { data: depositData, error: depositErr } = await supabase.rpc('apc_deposit', {
      p_amount: 0.001, // Minimal test — real billing handled by scheduled edge function
    });
    if (depositErr) {
      flash(false, 'Wallet not initialised. Please make a deposit first.');
      setBusy(false);
      return;
    }
    void depositData;

    const { error } = await supabase
      .from('apc_wallets')
      .update({ consumer_legal_sub_active: true })
      .eq('user_id', user.id);

    setBusy(false);
    if (error) { flash(false, error.message); return; }
    flash(true, `Consumer Legal Plan activated · €${CONSUMER_PLAN_EUR}/month`);
    load();
  };

  // ── AI Document Scan ────────────────────────────────────────────────────────
  const handleScan = async () => {
    if (!user) { flash(false, 'Sign in to use AI scan'); return; }
    if (!disclaimerChecked) { flash(false, 'You must accept the disclaimer to proceed'); return; }
    if (!scanText.trim()) { flash(false, 'Paste your document text to scan'); return; }

    setBusy(true);
    setScanResult(null);

    // AI summary (client-side heuristic — production would call an edge function)
    const summary = generateAiSummary(scanText);

    const { error } = await supabase.from('aippie_legal_scans').insert({
      user_id: user.id,
      document_url_encrypted: btoa(scanText.slice(0, 200)),
      ai_analysis_summary: summary,
      disclaimer_accepted: true,
    });

    setBusy(false);
    if (error) { flash(false, error.message); return; }

    setScanResult(summary);
    flash(true, 'AI juridical scan completed and saved');
    load();
  };

  // ── Open session ────────────────────────────────────────────────────────────
  const handleContact = async (lawyer: Lawyer, type: LawyerSession['session_type']) => {
    if (!user) { flash(false, 'Sign in to contact a lawyer'); return; }
    if (lawyer.lawyer_id.startsWith('demo-')) {
      flash(false, 'Demo lawyers are not contactable. Real lawyers appear once the platform is live.');
      return;
    }

    const balance = walletSubs?.balance_apc ?? 0;
    const total   = SESSION_RATE_APC * (1 + FEE_PCT);

    if (balance < total) {
      flash(false, `Insufficient balance. You need ${total.toFixed(2)} APC to open a session.`);
      return;
    }

    setBusy(true);
    const { error } = await supabase.from('aippie_lawyer_sessions').insert({
      client_id:          user.id,
      lawyer_id:          lawyer.lawyer_id,
      session_type:       type,
      session_status:     'CONNECTED',
      escrow_payment_apc: SESSION_RATE_APC,
    });
    setBusy(false);

    if (error) { flash(false, error.message); return; }
    flash(true, `${type.replace('_', ' ')} session opened with ${lawyer.full_name}`);
    setPanel('sessions');
    load();
  };

  const subscribed = walletSubs?.consumer_legal_sub_active === true;

  if (!user) {
    return (
      <div className="al-root al-root--empty">
        <Scale size={40} className="al-empty__icon" />
        <p className="al-empty__title">Aippie Legal AI</p>
        <p className="al-empty__sub">Sign in to access the juridical platform</p>
      </div>
    );
  }

  return (
    <div className="al-root">
      {/* Header */}
      <div className="al-header">
        <div className="al-header__left">
          <Scale size={22} className="al-header__icon" />
          <div>
            <h1 className="al-header__title">Aippie Legal AI</h1>
            <p className="al-header__sub">Juridical Platform · AIPPIETAX S.A. · Green Badge Verified</p>
          </div>
        </div>
        <button className="al-refresh-btn" onClick={load} aria-label="Refresh">
          <RefreshCw size={14} className={loading ? 'animate-spin' : ''} />
        </button>
      </div>

      {/* Feedback */}
      {feedback && (
        <div className={`al-feedback${feedback.ok ? ' al-feedback--ok' : ' al-feedback--err'}`}>
          {feedback.ok ? <Check size={14} /> : <AlertTriangle size={14} />}
          {feedback.msg}
        </div>
      )}

      {/* Subscription status + upgrade */}
      <div className={`al-sub-banner${subscribed ? ' al-sub-banner--active' : ''}`}>
        {subscribed ? (
          <>
            <CheckCircle size={16} className="text-emerald-400" />
            <span className="al-sub-banner__text">Consumer Legal Plan — <strong>Active</strong></span>
            <span className="al-sub-banner__rate">€{CONSUMER_PLAN_EUR}/month</span>
          </>
        ) : (
          <>
            <Scale size={16} className="text-amber-400" />
            <span className="al-sub-banner__text">Unlock direct lawyer contact for €{CONSUMER_PLAN_EUR}/month</span>
            <button className="al-sub-btn" onClick={handleSubscribe} disabled={busy}>
              {busy ? <RefreshCw size={12} className="animate-spin" /> : null}
              Subscribe
            </button>
          </>
        )}
      </div>

      {/* Tab bar */}
      <div className="al-tabs">
        {(['directory', 'scan', 'sessions'] as ActivePanel[]).map(p => (
          <button
            key={p}
            className={`al-tab${panel === p ? ' al-tab--active' : ''}`}
            onClick={() => setPanel(p)}
          >
            {p === 'directory' && <Scale size={13} />}
            {p === 'scan'      && <FileSearch size={13} />}
            {p === 'sessions'  && <Clock size={13} />}
            {p === 'directory' ? 'Lawyers' : p === 'scan' ? 'AI Scan' : 'Sessions'}
            {p === 'sessions' && sessions.length > 0 && (
              <span className="al-tab__count">{sessions.length}</span>
            )}
          </button>
        ))}
      </div>

      {/* ── Lawyers directory ────────────────────────────────────────────────── */}
      {panel === 'directory' && (
        <div className="al-panel">
          <p className="al-panel__hint">
            <ShieldCheck size={12} /> Only Green Badge verified lawyers with active bar registration are listed.
          </p>
          {loading ? (
            <div className="al-loading">
              <RefreshCw size={18} className="animate-spin" />
              <span>Loading directory…</span>
            </div>
          ) : (
            <div className="al-lawyer-list">
              {lawyers.map(l => (
                <LawyerCard
                  key={l.lawyer_id}
                  lawyer={l}
                  onContact={handleContact}
                  subscribed={subscribed}
                />
              ))}
            </div>
          )}
        </div>
      )}

      {/* ── AI Document scan ─────────────────────────────────────────────────── */}
      {panel === 'scan' && (
        <div className="al-panel">
          <div className="al-scan-header">
            <FileSearch size={18} className="text-sky-400" />
            <div>
              <h2 className="al-scan-title">AI Juridical Document Scanner</h2>
              <p className="al-scan-sub">Paste contract text, letters, or legal notices for instant AI analysis.</p>
            </div>
          </div>

          {/* Disclaimer */}
          <label className="al-disclaimer">
            <input
              type="checkbox"
              checked={disclaimerChecked}
              onChange={e => setDisclaimer(e.target.checked)}
              className="al-disclaimer__box"
            />
            <span className="al-disclaimer__text">
              I understand this is an AI analysis tool only. I must consult a licensed lawyer for official legal advice.
              AIPPIETAX S.A. bears no legal liability for AI-generated summaries.
            </span>
          </label>

          <label className="al-label">Document Text</label>
          <textarea
            className="al-textarea"
            placeholder="Paste your contract, letter, or legal document text here…"
            rows={8}
            value={scanText}
            onChange={e => setScanText(e.target.value)}
          />

          <button
            className="al-action-btn al-action-btn--scan"
            onClick={handleScan}
            disabled={busy || !disclaimerChecked || !scanText.trim()}
          >
            {busy ? <RefreshCw size={14} className="animate-spin" /> : <Upload size={14} />}
            {busy ? 'Scanning…' : 'Run AI Juridical Scan'}
          </button>

          {scanResult && (
            <div className="al-scan-result">
              <div className="al-scan-result__header">
                <CheckCircle size={14} className="text-emerald-400" />
                <span>AI Analysis Complete</span>
              </div>
              <p className="al-scan-result__body">{scanResult}</p>
              <p className="al-scan-result__disclaimer">
                <AlertTriangle size={11} /> This is an AI-generated summary. Consult a licensed lawyer for official legal advice.
              </p>
            </div>
          )}

          {scans.length > 0 && (
            <div className="al-scan-history">
              <h3 className="al-scan-history__title">Scan History</h3>
              {scans.map(s => (
                <div key={s.scan_id} className="al-scan-row">
                  <FileSearch size={13} className="text-sky-400" />
                  <div className="al-scan-row__body">
                    <p className="al-scan-row__summary">{s.ai_analysis_summary.slice(0, 120)}…</p>
                    <p className="al-scan-row__date">
                      {new Date(s.created_at).toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: '2-digit' })}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* ── Sessions ─────────────────────────────────────────────────────────── */}
      {panel === 'sessions' && (
        <div className="al-panel">
          {sessions.length === 0 ? (
            <div className="al-empty-sessions">
              <Clock size={28} className="text-slate-700" />
              <p>No sessions yet. Contact a lawyer from the directory to start.</p>
            </div>
          ) : (
            <div className="al-session-list">
              {sessions.map(s => (
                <div key={s.session_id} className={`al-session-row al-session-row--${s.session_status.toLowerCase()}`}>
                  <SessionTypeBadge type={s.session_type} />
                  <div className="al-session-row__body">
                    <p className="al-session-row__status">{s.session_status}</p>
                    <p className="al-session-row__meta">
                      Escrow: {Number(s.escrow_payment_apc).toFixed(2)} APC ·{' '}
                      {new Date(s.created_at).toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: '2-digit' })}
                    </p>
                  </div>
                  <span className={`al-status-dot al-status-dot--${s.session_status.toLowerCase()}`} />
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Disclaimer footer */}
      <div className="al-footer">
        <Scale size={10} />
        AIPPIETAX S.A. · AI Legal Tool — Not a Law Firm · Always consult a licensed lawyer · GDPR Compliant
      </div>
    </div>
  );
}

// ── Client-side AI summary generator ─────────────────────────────────────────
function generateAiSummary(text: string): string {
  const lower = text.toLowerCase();
  const flags: string[] = [];

  if (/termina|rescis|cancell|resolv/.test(lower))
    flags.push('Termination or cancellation clause detected.');
  if (/penalt|boete|multa|sanction/.test(lower))
    flags.push('Penalty or sanction clause identified — verify amounts and conditions.');
  if (/mortgage|hipoteca|hypotheek/.test(lower))
    flags.push('Mortgage or secured lending language present.');
  if (/gdpr|privacidad|persoonsgegevens|data protection/.test(lower))
    flags.push('Data protection obligations mentioned — GDPR compliance review recommended.');
  if (/arbitr|mediaci|bemidde/.test(lower))
    flags.push('Dispute resolution clause present — arbitration or mediation pathway noted.');
  if (/employ|contrato.*trabajo|arbeidsovereenkomst/.test(lower))
    flags.push('Employment contract terms detected.');
  if (/inherit|herencia|nalatenschap|testament/.test(lower))
    flags.push('Inheritance or estate planning language found.');

  const wordCount = text.split(/\s+/).length;
  const base = `Document analysed: ${wordCount} words. `;

  if (flags.length === 0)
    return base + 'No high-risk clauses automatically detected. A full manual review by a licensed lawyer is still recommended.';

  return base + 'Key findings: ' + flags.join(' ') + ' Consult a verified lawyer for full legal assessment.';
}
