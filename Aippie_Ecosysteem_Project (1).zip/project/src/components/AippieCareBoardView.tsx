// @ts-nocheck
import React, { useState, useRef, useEffect, useCallback } from 'react';
import { Volume2, Bell, Mic, Phone, PhoneCall, AlertTriangle, X, Settings, Check, CircleUser as UserCircle } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { applyPremiumVoice, normalizeForTTS, withVoicesReady } from '../lib/ttsVoice';
import { getStoredLang } from '../lib/i18n';

// ── Proactive AI scripts ─────────────────────────────────────────────────────

const WELCOME = {
  nl: 'Hallo lieverd! Ik ben Aippie, jouw beste AI vriend. Ik ben er altijd voor jou! Wat heb je nodig? Tik gewoon op een knop, dan zorg ik dat mama of papa het weet!',
  en: 'Hello sweetheart! I am Aippie, your best AI friend. I am always here for you! What do you need? Just tap a button and I will make sure mom or dad knows!',
};

const IDLE_PROMPTS = {
  nl: [
    'Hé lieverd! Alles oké? Ik ben hier voor jou. Wil je iets? Tik gewoon op een knop!',
    'Hoe gaat het met jou? Ben je misschien een beetje hongerig of dorstig? Druk op de rode knop!',
    'Ik denk aan jou! Wil je misschien buiten spelen? Tik op de groene knop!',
    'Weet je dat ik mama of papa voor jou kan bellen? Druk gewoon op de blauwe knop!',
    'Ben je moe of voel je je niet zo goed? Geen zorgen. Tik op een knop en ik roep hulp voor jou!',
    'Ik wacht op jou. Wat heb je nodig vandaag? Ik luister altijd, dag en nacht.',
  ],
  en: [
    'Hey sweetheart! Everything okay? I am here for you. Need something? Just tap a button!',
    'How are you? Maybe a little hungry or thirsty? Press the red button!',
    'I am thinking of you! Do you want to play outside? Tap the green button!',
    'Did you know I can call mom or dad for you? Just press the blue button!',
    'Are you tired or not feeling well? No worries. Tap a button and I will get help!',
    'I am waiting for you. What do you need today? I am always listening.',
  ],
};

// Warm Aippie responses AFTER the child phrase — encouraging, loving
const AIPPIE_PRAISE: { nl: string[]; en: string[] } = {
  nl: [
    'Wat goed dat je dat zegt! Je bent zo dapper! Ik ga nu direct mama of papa voor jou bellen!',
    'Super gedaan! Je communiceert zo goed! Ik zorg ervoor dat de juiste persoon het meteen weet!',
    'Heel goed! Je hebt het precies goed gezegd! Ik stuur nu een berichtje naar mama of papa!',
    'Wauw, wat knap van jou! Ik ben trots op jou! We laten mama of papa meteen weten wat je nodig hebt!',
    'Geweldig! Jij kunt zo goed communiceren! Mama of papa krijgt nu een berichtje van mij!',
  ],
  en: [
    'Well done for telling me! You are so brave! I am going to call mom or dad for you right now!',
    'Super job! You communicate so well! I will make sure the right person knows immediately!',
    'Very good! You said it perfectly! I am now sending a message to mom or dad!',
    'Wow, how clever of you! I am proud of you! We are letting mom or dad know right away!',
    'Amazing! You communicate so well! Mom or dad is getting a message from me now!',
  ],
};

// Emergency-specific items that trigger 112 prompt
const EMERGENCY_ITEM_IDS = new Set(['help', 'pain', 'overwhelmed']);

// Choking emergency
const CHOKE_SCRIPT = {
  nl: 'NOODGEVAL! Er is iets in de keel! Bel nu 112! Ik bel mama en papa! Paniek niet — ik help je! BEL NU 112!',
  en: 'EMERGENCY! Something is stuck in the throat! Call 112 now! I am calling mom and dad! Do not panic — I am helping you! CALL 112 NOW!',
};

// ── Care board data ──────────────────────────────────────────────────────────

interface CareItem {
  id: string;
  emoji: string;
  label_nl: string;
  label_en: string;
  phrase_nl: string;
  phrase_en: string;
  avatar_nl: string;
  avatar_en: string;
  parent_nl: string;
  parent_en: string;
  isUrgent?: boolean;
}

interface Category {
  id: string;
  label_nl: string;
  label_en: string;
  color: string;
  bg: string;
  items: CareItem[];
}

const CATEGORIES: Category[] = [
  {
    id: 'body', label_nl: 'Mijn Lichaam', label_en: 'My Body',
    color: '#ef4444', bg: 'rgba(239,68,68,0.12)',
    items: [
      {
        id: 'hunger', emoji: '🍴', label_nl: 'Honger', label_en: 'Hungry',
        phrase_nl: 'Ik wil iets eten.', phrase_en: 'I want something to eat.',
        avatar_nl: 'Ik hoor je! Je hebt honger. Dat is heel normaal! We gaan nu iets lekkers voor jou halen. Mama of papa weet het nu ook!',
        avatar_en: 'I hear you! You are hungry. That is very normal! We are getting you something yummy now. Mom or dad knows too!',
        parent_nl: 'Mama, papa — uw kind heeft honger en wil iets eten. Kunt u snel iets brengen?',
        parent_en: 'Mom, dad — your child is hungry and wants something to eat. Can you please bring something soon?',
      },
      {
        id: 'thirst', emoji: '🚰', label_nl: 'Dorst', label_en: 'Thirsty',
        phrase_nl: 'Ik wil iets drinken.', phrase_en: 'I want something to drink.',
        avatar_nl: 'Je hebt dorst! Goed dat je het zegt! We zorgen nu voor een lekker drankje voor jou. Mama of papa komt eraan!',
        avatar_en: 'You are thirsty! Good that you told me! We are getting you a nice drink now. Mom or dad is coming!',
        parent_nl: 'Mama, papa — uw kind heeft dorst en wil iets drinken. Kunt u water of sap brengen?',
        parent_en: 'Mom, dad — your child is thirsty and wants something to drink. Can you bring water or juice?',
      },
      {
        id: 'toilet', emoji: '🚽', label_nl: 'WC nodig', label_en: 'Bathroom',
        phrase_nl: 'Ik moet naar het toilet.', phrase_en: 'I need to use the bathroom.',
        avatar_nl: 'Oké! Je moet naar het toilet. We gaan meteen! Ik roep mama of papa om je te helpen. Kom maar mee!',
        avatar_en: 'Okay! You need the bathroom. Let\'s go right now! I am calling mom or dad to help you. Come with me!',
        parent_nl: 'Mama, papa — uw kind moet naar het toilet. Breng het kind alstublieft direct.',
        parent_en: 'Mom, dad — your child needs to use the bathroom. Please take them immediately.',
        isUrgent: true,
      },
      {
        id: 'tired', emoji: '💤', label_nl: 'Moe', label_en: 'Tired',
        phrase_nl: 'Ik ben moe. Ik wil rusten.', phrase_en: 'I am tired. I want to rest.',
        avatar_nl: 'Je bent moe, liefje. Dat is helemaal oké. Kom, we gaan lekker uitrusten. Mama of papa weet het nu.',
        avatar_en: 'You are tired, sweetheart. That is completely okay. Come, let\'s rest. Mom or dad knows now.',
        parent_nl: 'Mama, papa — uw kind is moe en wil rusten of slapen. Kunt u een rustige plek regelen?',
        parent_en: 'Mom, dad — your child is tired and wants to rest or sleep. Can you arrange a quiet place?',
      },
    ],
  },
  {
    id: 'feelings', label_nl: 'Mijn Gevoel', label_en: 'My Feelings',
    color: '#eab308', bg: 'rgba(234,179,8,0.12)',
    items: [
      {
        id: 'pain', emoji: '🤕', label_nl: 'Pijn', label_en: 'Pain',
        phrase_nl: 'Ik heb ergens pijn.', phrase_en: 'I am in pain.',
        avatar_nl: 'Je hebt pijn! Dat is niet fijn, lieverd. Ik roep nu meteen mama of papa voor jou. Je bent niet alleen. Ik ben bij jou.',
        avatar_en: 'You are in pain! That is not nice, sweetheart. I am calling mom or dad for you right now. You are not alone. I am with you.',
        parent_nl: 'URGENT! Uw kind heeft pijn. Controleer uw kind alstublieft direct en kijk waar de pijn zit.',
        parent_en: 'URGENT! Your child is in pain. Please check on your child immediately and see where the pain is.',
        isUrgent: true,
      },
      {
        id: 'overwhelmed', emoji: '⚡', label_nl: 'Te Druk', label_en: 'Too Much',
        phrase_nl: 'Het is te veel voor mij. Ik ben overprikkeld.', phrase_en: 'It is too much. I am overwhelmed.',
        avatar_nl: 'Ik snap je helemaal. Het is te veel. Adem rustig met mij mee. In... en uit... We zoeken een stille plek. Mama of papa weet het.',
        avatar_en: 'I understand you completely. It is too much. Breathe slowly with me. In... and out... We find a quiet place. Mom or dad knows.',
        parent_nl: 'Mama, papa — uw kind is overprikkeld en heeft dringend rust nodig. Breng het naar een stille rustige ruimte.',
        parent_en: 'Mom, dad — your child is overwhelmed and urgently needs rest. Please move them to a quiet, calm space.',
        isUrgent: true,
      },
      {
        id: 'sad', emoji: '😢', label_nl: 'Verdrietig', label_en: 'Sad',
        phrase_nl: 'Ik voel me niet fijn.', phrase_en: 'I do not feel good.',
        avatar_nl: 'Het is oké om je niet fijn te voelen. Ik ben er voor jou, altijd. Je bent zo geliefd. Mama of papa komt snel bij jou.',
        avatar_en: 'It is okay to not feel good. I am here for you, always. You are so loved. Mom or dad is coming to you soon.',
        parent_nl: 'Mama, papa — uw kind voelt zich verdrietig of angstig. Uw kind heeft emotionele steun nodig. Geef uw kind nabijheid.',
        parent_en: 'Mom, dad — your child feels sad or anxious. Your child needs emotional support. Please be close to them.',
      },
      {
        id: 'hug', emoji: '❤️', label_nl: 'Knuffel', label_en: 'Hug',
        phrase_nl: 'Ik wil een knuffel.', phrase_en: 'I want a hug.',
        avatar_nl: 'Ahhh wat lief! Een grote warme knuffel voor jou! Je bent zo ontzettend geliefd! Mama of papa geeft jou een echte knuffel!',
        avatar_en: 'Aww how sweet! A big warm hug for you! You are so incredibly loved! Mom or dad will give you a real hug!',
        parent_nl: 'Mama, papa — uw kind wil graag een knuffel. Geef uw kind een warme knuffel en veel liefde.',
        parent_en: 'Mom, dad — your child wants a hug. Please give your child a warm hug and lots of love.',
      },
    ],
  },
  {
    id: 'desires', label_nl: 'Ik Wil', label_en: 'I Want',
    color: '#22c55e', bg: 'rgba(34,197,94,0.12)',
    items: [
      {
        id: 'play', emoji: '🧸', label_nl: 'Spelen', label_en: 'Play',
        phrase_nl: 'Ik wil spelen met mijn speelgoed.', phrase_en: 'I want to play with my toys.',
        avatar_nl: 'Super! Je wil spelen! Wat geweldig! Laten we je favoriete speelgoed pakken! Mama of papa helpt je zo!',
        avatar_en: 'Super! You want to play! How wonderful! Let\'s get your favourite toys! Mom or dad will help you soon!',
        parent_nl: 'Mama, papa — uw kind wil graag spelen. Kan iemand helpen met het speelgoed of spelletjes?',
        parent_en: 'Mom, dad — your child wants to play. Can someone help with toys or games?',
      },
      {
        id: 'outside', emoji: '🌳', label_nl: 'Buiten', label_en: 'Outside',
        phrase_nl: 'Ik wil naar buiten.', phrase_en: 'I want to go outside.',
        avatar_nl: 'Buiten! Wat heerlijk! Frisse lucht is zo goed voor jou! We vragen mama of papa of het kan!',
        avatar_en: 'Outside! How lovely! Fresh air is so good for you! We ask mom or dad if it is possible!',
        parent_nl: 'Mama, papa — uw kind wil graag naar buiten of de tuin in. Kan het kind buiten spelen?',
        parent_en: 'Mom, dad — your child wants to go outside or into the garden. Can the child play outside?',
      },
      {
        id: 'screen', emoji: '📺', label_nl: 'Filmpje', label_en: 'Video',
        phrase_nl: 'Ik wil een filmpje kijken.', phrase_en: 'I want to watch a video.',
        avatar_nl: 'Oké! Je wil een filmpje kijken! Laten we samen iets leuks uitkiezen! Mama of papa zet het aan voor jou!',
        avatar_en: 'Okay! You want to watch something! Let\'s choose something fun together! Mom or dad will put it on for you!',
        parent_nl: 'Mama, papa — uw kind wil graag een filmpje kijken. Kunt u iets voor hem of haar opzetten?',
        parent_en: 'Mom, dad — your child wants to watch a video. Can you put something on for them?',
      },
      {
        id: 'draw', emoji: '🎨', label_nl: 'Knutselen', label_en: 'Draw',
        phrase_nl: 'Ik wil knutselen of kleuren.', phrase_en: 'I want to draw or color.',
        avatar_nl: 'Fantastisch! Je wil knutselen! Zo creatief! Mama of papa pakt de verf en het papier voor jou!',
        avatar_en: 'Fantastic! You want to draw! So creative! Mom or dad will get the paint and paper for you!',
        parent_nl: 'Mama, papa — uw kind wil graag knutselen of tekenen. Kunt u knutselspullen geven?',
        parent_en: 'Mom, dad — your child wants to draw or do crafts. Can you provide art supplies?',
      },
    ],
  },
  {
    id: 'people', label_nl: 'Wie Nodig', label_en: 'I Need',
    color: '#3b82f6', bg: 'rgba(59,130,246,0.12)',
    items: [
      {
        id: 'mama', emoji: '👩‍👦', label_nl: 'Mama', label_en: 'Mom',
        phrase_nl: 'Ik wil mama.', phrase_en: 'I want mom.',
        avatar_nl: 'Mama! Mama! Uw kind heeft u nodig! Ik bel mama nu meteen voor jou! Mama komt eraan, liefje!',
        avatar_en: 'Mom! Mom! Your child needs you! I am calling mom right now for you! Mom is coming, sweetheart!',
        parent_nl: 'Mama — uw kind vraagt specifiek naar jou. Uw kind heeft jou heel erg nodig op dit moment.',
        parent_en: 'Mom — your child is asking specifically for you. Your child needs you very much right now.',
      },
      {
        id: 'papa', emoji: '👨‍👦', label_nl: 'Papa', label_en: 'Dad',
        phrase_nl: 'Ik wil papa.', phrase_en: 'I want dad.',
        avatar_nl: 'Papa! Papa! Uw kind heeft u nodig! Ik bel papa nu meteen voor jou! Papa komt eraan, liefje!',
        avatar_en: 'Dad! Dad! Your child needs you! I am calling dad right now for you! Dad is coming, sweetheart!',
        parent_nl: 'Papa — uw kind vraagt specifiek naar jou. Uw kind heeft jou heel erg nodig op dit moment.',
        parent_en: 'Dad — your child is asking specifically for you. Your child needs you very much right now.',
      },
      {
        id: 'help', emoji: '🆘', label_nl: 'Help!', label_en: 'Help!',
        phrase_nl: 'Ik heb hulp nodig.', phrase_en: 'I need help.',
        avatar_nl: 'Ik help je! Geen paniek! We zoeken samen hulp! Ik roep mama en papa meteen! Je bent veilig bij mij!',
        avatar_en: 'I am helping you! No panic! We find help together! I am calling mom and dad right now! You are safe with me!',
        parent_nl: 'URGENT! Uw kind heeft direct hulp nodig. Kom alstublieft onmiddellijk naar uw kind toe.',
        parent_en: 'URGENT! Your child needs immediate help. Please come to your child immediately.',
        isUrgent: true,
      },
      {
        id: 'alone', emoji: '🤫', label_nl: 'Even Rust', label_en: 'Quiet',
        phrase_nl: 'Ik wil even alleen zijn.', phrase_en: 'I want to be alone for a while.',
        avatar_nl: 'Dat is helemaal oké, lieverd. Je mag even rust pakken. Ik ben vlakbij als je me nodig hebt. We houden van jou.',
        avatar_en: 'That is completely okay, sweetheart. You can have some quiet time. I am nearby if you need me. We love you.',
        parent_nl: 'Mama, papa — uw kind heeft rust nodig en wil even alleen zijn. Geef het kind wat ruimte maar blijf in de buurt.',
        parent_en: 'Mom, dad — your child needs quiet time and wants to be alone. Give them space but stay nearby.',
      },
    ],
  },
  {
    id: 'emergency', label_nl: '🆘 Nood', label_en: '🆘 Emergency',
    color: '#ef4444', bg: 'rgba(239,68,68,0.15)',
    items: [
      {
        id: 'choke', emoji: '🫁', label_nl: 'Stik!', label_en: 'Choking!',
        phrase_nl: 'Ik stik! Er zit iets in mijn keel!', phrase_en: 'I am choking! Something is in my throat!',
        avatar_nl: CHOKE_SCRIPT.nl,
        avatar_en: CHOKE_SCRIPT.en,
        parent_nl: '🚨 NOODGEVAL! Uw kind stikt! Bel onmiddellijk 112! Geef eerste hulp bij verslikken!',
        parent_en: '🚨 EMERGENCY! Your child is choking! Call 112 immediately! Give first aid for choking!',
        isUrgent: true,
      },
      {
        id: 'heartpain', emoji: '💔', label_nl: 'Borst pijn', label_en: 'Chest pain',
        phrase_nl: 'Mijn borst doet pijn. Ik voel me heel ziek.', phrase_en: 'My chest hurts. I feel very sick.',
        avatar_nl: 'Borst pijn is heel ernstig! Ik bel nu 112 en mama en papa! Ga rustig liggen! Beweeg niet te veel! Help komt eraan!',
        avatar_en: 'Chest pain is very serious! I am calling 112 and mom and dad now! Lie down calmly! Do not move too much! Help is coming!',
        parent_nl: '🚨 NOODGEVAL! Uw kind heeft borstpijn en voelt zich heel ziek. BEL 112! Dit kan ernstig zijn!',
        parent_en: '🚨 EMERGENCY! Your child has chest pain and feels very sick. CALL 112! This can be serious!',
        isUrgent: true,
      },
      {
        id: 'fall', emoji: '🩹', label_nl: 'Gevallen', label_en: 'I fell',
        phrase_nl: 'Ik ben gevallen en ik heb pijn.', phrase_en: 'I fell and I am hurt.',
        avatar_nl: 'Je bent gevallen! Ik roep mama en papa nu meteen! Beweeg nog niet! Wacht op hulp! Ik ben bij jou!',
        avatar_en: 'You fell! I am calling mom and dad right now! Do not move yet! Wait for help! I am with you!',
        parent_nl: '⚠️ Uw kind is gevallen en heeft pijn. Controleer op verwondingen en bied hulp. Eventueel 112 bellen.',
        parent_en: '⚠️ Your child has fallen and is hurt. Check for injuries and provide help. Consider calling 112.',
        isUrgent: true,
      },
      {
        id: 'scared', emoji: '😱', label_nl: 'Bang!', label_en: 'Scared!',
        phrase_nl: 'Ik ben heel erg bang. Ik ben niet veilig.', phrase_en: 'I am very scared. I am not safe.',
        avatar_nl: 'Ik hoor je! Je bent bang en dat is serieus! Ik bel mama en papa meteen! Je bent niet alleen! Ik bescherm jou!',
        avatar_en: 'I hear you! You are scared and that is serious! I am calling mom and dad right now! You are not alone! I am protecting you!',
        parent_nl: '🚨 Uw kind voelt zich onveilig of is heel erg bang. Kom onmiddellijk naar uw kind toe!',
        parent_en: '🚨 Your child feels unsafe or is very scared. Come to your child immediately!',
        isUrgent: true,
      },
    ],
  },
];

interface LogEntry {
  time: string;
  emoji: string;
  label: string;
  parent_msg: string;
  color: string;
  isUrgent?: boolean;
}

interface ParentContact {
  id: string;
  label: string;
  phone: string;
  is_primary: boolean;
}

interface Props {
  deviceKey?: string;
  sessionId?: string;
}

const AippieCareBoardView: React.FC<Props> = ({
  deviceKey = 'anon',
  sessionId = 'anon',
}) => {
  const [activeCatIdx, setActiveCatIdx]   = useState(0);
  const [selected,    setSelected]        = useState<CareItem | null>(null);
  const [speaking,    setSpeaking]        = useState(false);
  const [bouncing,    setBouncing]        = useState<string | null>(null);
  const [log,         setLog]             = useState<LogEntry[]>([]);
  const [showLog,     setShowLog]         = useState(false);
  const [caption,     setCaption]         = useState('');
  const [aiMode,      setAiMode]          = useState<'idle'|'greeting'|'proactive'|'responding'>('idle');

  // Parent contact state
  const [contacts,       setContacts]       = useState<ParentContact[]>([]);
  const [showContactSetup, setShowContactSetup] = useState(false);
  const [contactLabel,   setContactLabel]   = useState('Mama');
  const [contactPhone,   setContactPhone]   = useState('');
  const [contactSaving,  setContactSaving]  = useState(false);
  const [contactSaved,   setContactSaved]   = useState(false);

  // After-tap parent action panel
  const [showParentActions, setShowParentActions] = useState(false);
  const [pendingItem,       setPendingItem]       = useState<CareItem | null>(null);

  // Emergency modal
  const [showEmergency, setShowEmergency] = useState(false);
  const [emergencyItem, setEmergencyItem] = useState<CareItem | null>(null);

  const resultRef     = useRef<HTMLDivElement | null>(null);
  const speakingRef   = useRef(false);
  const hasWelcomed   = useRef(false);
  const idleCount     = useRef(0);
  const idleTimerRef  = useRef<ReturnType<typeof setInterval> | null>(null);
  const praiseIdx     = useRef(0);
  const lang = getStoredLang();
  const activeCat = CATEGORIES[activeCatIdx];

  // ── Load parent contacts ───────────────────────────────────────────────────
  useEffect(() => {
    if (deviceKey === 'anon') return;
    supabase.from('parent_contacts')
      .select('id, label, phone, is_primary')
      .eq('device_key', deviceKey)
      .then(({ data }) => { if (data) setContacts(data); });
  }, [deviceKey]);

  // ── Core speak function ────────────────────────────────────────────────────
  const speak = useCallback((text: string, mode: typeof aiMode = 'responding') => {
    if (!('speechSynthesis' in window)) return;
    window.speechSynthesis.cancel();
    setSpeaking(true);
    speakingRef.current = true;
    setCaption(text);
    setAiMode(mode);
    withVoicesReady(() => {
      const u = new SpeechSynthesisUtterance(normalizeForTTS(text));
      u.lang = lang === 'nl' ? 'nl-NL' : 'en-US';
      u.rate = 0.78;
      u.pitch = 1.1;
      applyPremiumVoice(u, u.lang);
      u.onend = u.onerror = () => {
        setSpeaking(false);
        speakingRef.current = false;
        setCaption('');
        setAiMode('idle');
      };
      window.speechSynthesis.speak(u);
    });
    setTimeout(() => {
      setSpeaking(false);
      speakingRef.current = false;
      setCaption('');
      setAiMode('idle');
    }, Math.max(text.length * 82, 5000));
  }, [lang]);

  // ── Welcome message on mount ───────────────────────────────────────────────
  useEffect(() => {
    if (hasWelcomed.current) return;
    const t = setTimeout(() => {
      if (!hasWelcomed.current) {
        hasWelcomed.current = true;
        speak(lang === 'nl' ? WELCOME.nl : WELCOME.en, 'greeting');
      }
    }, 1800);
    return () => clearTimeout(t);
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  // ── Proactive idle prompts every 45 seconds ────────────────────────────────
  useEffect(() => {
    idleTimerRef.current = setInterval(() => {
      if (speakingRef.current) return;
      if (idleCount.current >= IDLE_PROMPTS.nl.length) return;
      const idx = idleCount.current % IDLE_PROMPTS.nl.length;
      idleCount.current++;
      const prompts = lang === 'nl' ? IDLE_PROMPTS.nl : IDLE_PROMPTS.en;
      speak(prompts[idx], 'proactive');
    }, 45_000);
    return () => { if (idleTimerRef.current) clearInterval(idleTimerRef.current); };
  }, [lang, speak]);

  // ── Save parent contact ────────────────────────────────────────────────────
  const saveContact = async () => {
    if (!contactPhone.trim()) return;
    setContactSaving(true);
    const { data, error } = await supabase.from('parent_contacts').insert({
      device_key: deviceKey,
      label: contactLabel,
      phone: contactPhone.trim(),
      is_primary: contacts.length === 0,
    }).select('id, label, phone, is_primary').single();
    setContactSaving(false);
    if (!error && data) {
      setContacts(prev => [...prev, data]);
      setContactPhone('');
      setContactSaved(true);
      setTimeout(() => setContactSaved(false), 2000);
      speak(
        lang === 'nl'
          ? `${contactLabel} is toegevoegd! Nu kan ik altijd bericht sturen als uw kind iets nodig heeft!`
          : `${contactLabel} has been added! Now I can always send a message when your child needs something!`,
        'responding'
      );
    }
  };

  const deleteContact = async (id: string) => {
    await supabase.from('parent_contacts').delete().eq('id', id);
    setContacts(prev => prev.filter(c => c.id !== id));
  };

  // ── Button selection handler ───────────────────────────────────────────────
  const handleSelect = (item: CareItem) => {
    idleCount.current = 0;
    setSelected(item);
    setBouncing(item.id);
    setTimeout(() => setBouncing(null), 500);

    // 1. Aippie speaks to child
    const phrase = lang === 'nl' ? item.avatar_nl : item.avatar_en;
    speak(phrase, 'responding');

    // 2. After child speech: warm praise + "Moet ik mama/papa bellen?"
    const praiseList = lang === 'nl' ? AIPPIE_PRAISE.nl : AIPPIE_PRAISE.en;
    const praise = praiseList[praiseIdx.current % praiseList.length];
    praiseIdx.current++;
    const askParent = lang === 'nl'
      ? 'Moet ik mama of papa nu bellen of een berichtje sturen? Kies hieronder!'
      : 'Should I call or message mom or dad now? Choose below!';
    const phraseDelay = Math.max(phrase.length * 82, 5000) + 800;

    setTimeout(() => {
      if (!speakingRef.current) {
        speak(praise + ' ' + askParent, 'responding');
        setShowParentActions(true);
        setPendingItem(item);
      }
    }, phraseDelay);

    // Log entry
    setLog(prev => [{
      time: new Date().toLocaleTimeString('nl-NL', { hour: '2-digit', minute: '2-digit' }),
      emoji: item.emoji,
      label: lang === 'nl' ? item.label_nl : item.label_en,
      parent_msg: lang === 'nl' ? item.parent_nl : item.parent_en,
      color: activeCat.color,
      isUrgent: item.isUrgent,
    }, ...prev].slice(0, 20));

    setTimeout(() => resultRef.current?.scrollIntoView({ behavior: 'smooth', block: 'nearest' }), 80);

    // Emergency flow
    if (item.isUrgent && activeCat.id === 'emergency') {
      setEmergencyItem(item);
      setShowEmergency(true);
    }

    supabase.from('care_board_events').insert({
      device_key: deviceKey, session_id: sessionId,
      category: activeCat.id, item_id: item.id,
      label: item.label_nl,
      phrase_nl: item.phrase_nl, phrase_en: item.phrase_en,
      lang_code: lang,
      is_emergency: item.isUrgent ?? false,
    }).catch(() => {});
  };

  // ── Notify parent via phone call ──────────────────────────────────────────
  const notifyParent = (contact: ParentContact, item: CareItem) => {
    callParent(contact);

    supabase.from('care_board_events')
      .update({ parent_notified_at: new Date().toISOString() })
      .eq('device_key', deviceKey)
      .eq('item_id', item.id)
      .order('created_at', { ascending: false })
      .limit(1)
      .catch(() => {});

    speak(
      lang === 'nl'
        ? `Bellen naar ${contact.label}! ${contact.label} weet nu wat je nodig hebt! Goed gedaan!`
        : `Calling ${contact.label}! ${contact.label} knows what you need now! Well done!`,
      'responding'
    );
    setShowParentActions(false);
  };

  const callParent = (contact: ParentContact) => {
    window.location.href = `tel:${contact.phone}`;
    speak(
      lang === 'nl'
        ? `Ik bel ${contact.label} voor jou! ${contact.label} neemt zo op!`
        : `I am calling ${contact.label} for you! ${contact.label} will answer soon!`,
      'responding'
    );
    setShowParentActions(false);
  };

  const dismissParentActions = () => {
    setShowParentActions(false);
    speak(
      lang === 'nl'
        ? 'Oké, geen berichtje gestuurd. Maar als je het later wil, tik dan gewoon opnieuw!'
        : 'Okay, no message sent. But if you want to later, just tap again!',
      'responding'
    );
  };

  // ── Companion bubble colour ────────────────────────────────────────────────
  const companionColor =
    aiMode === 'greeting'   ? '#38bdf8' :
    aiMode === 'proactive'  ? '#a78bfa' :
    aiMode === 'responding' ? '#4ade80' : '#334155';

  const primaryContact = contacts.find(c => c.is_primary) ?? contacts[0];

  return (
    <div className="cb-root">

      {/* ── Emergency Modal ── */}
      {showEmergency && emergencyItem && (
        <div className="cb-emergency-overlay">
          <div className="cb-emergency-modal">
            <div className="cb-emergency-icon">
              {emergencyItem.emoji}
            </div>
            <h2 className="cb-emergency-title">
              {lang === 'nl' ? 'NOODGEVAL GEDETECTEERD' : 'EMERGENCY DETECTED'}
            </h2>
            <p className="cb-emergency-desc">
              {lang === 'nl' ? emergencyItem.parent_nl : emergencyItem.parent_en}
            </p>
            <div className="cb-emergency-actions">
              <a href="tel:112" className="cb-emergency-112" onClick={() => setShowEmergency(false)}>
                <Phone size={20} />
                BEL 112
              </a>
              {primaryContact && (
                <button className="cb-emergency-parent"
                  onClick={() => { callParent(primaryContact); setShowEmergency(false); }}>
                  <PhoneCall size={18} />
                  {lang === 'nl' ? `Bel ${primaryContact.label}` : `Call ${primaryContact.label}`}
                </button>
              )}
            </div>
            <button className="cb-emergency-close" onClick={() => setShowEmergency(false)}>
              <X size={14} />
              {lang === 'nl' ? 'Close' : 'Close'}
            </button>
          </div>
        </div>
      )}

      {/* ── Contact Setup Modal ── */}
      {showContactSetup && (
        <div className="cb-contact-overlay">
          <div className="cb-contact-modal">
            <div className="cb-contact-modal__header">
              <UserCircle size={18} style={{ color: '#38bdf8' }} />
              <span>{lang === 'nl' ? 'Parent contacts' : 'Parent contacts'}</span>
              <button className="cb-contact-close" onClick={() => setShowContactSetup(false)}>
                <X size={14} />
              </button>
            </div>

            {contacts.length > 0 && (
              <div className="cb-contact-list">
                {contacts.map(c => (
                  <div key={c.id} className="cb-contact-row">
                    <span className="cb-contact-row__label">{c.label}</span>
                    <span className="cb-contact-row__phone">{c.phone}</span>
                    <button className="cb-contact-row__del" onClick={() => deleteContact(c.id)}>
                      <X size={11} />
                    </button>
                  </div>
                ))}
              </div>
            )}

            <div className="cb-contact-form">
              <p className="cb-contact-form__title">
                {lang === 'nl' ? 'Add new contact' : 'Add new contact'}
              </p>
              <div className="cb-contact-form__row">
                <select
                  className="cb-contact-select"
                  value={contactLabel}
                  onChange={e => setContactLabel(e.target.value)}
                >
                  <option value="Mama">Mama</option>
                  <option value="Papa">Papa</option>
                  <option value="Opa">Opa</option>
                  <option value="Oma">Oma</option>
                  <option value="Verzorger">Verzorger</option>
                </select>
                <input
                  className="cb-contact-input"
                  type="tel"
                  placeholder="+31 6 12345678"
                  value={contactPhone}
                  onChange={e => setContactPhone(e.target.value)}
                />
              </div>
              <button
                className="cb-contact-save"
                onClick={saveContact}
                disabled={contactSaving || !contactPhone.trim()}
              >
                {contactSaved ? <><Check size={13} /> Saved!</> : contactSaving ? 'Saving…' : lang === 'nl' ? 'Save' : 'Save'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ── Aippie Companion Banner ── */}
      <div className={`cb-companion${speaking ? ' cb-companion--speaking' : ''}`}
        style={{ borderColor: companionColor + '50', background: companionColor + '0d' }}>
        <div className="cb-companion__orb" style={{ background: speaking ? companionColor : '#334155' }}>
          {speaking
            ? <Mic size={13} style={{ color: '#fff' }} />
            : <span style={{ fontSize: 16 }}>🤖</span>}
        </div>
        <div className="cb-companion__text">
          {speaking && caption
            ? <span className="cb-companion__caption" style={{ color: companionColor }}>{caption}</span>
            : <span className="cb-companion__ready">
                {lang === 'nl' ? 'Aippie is klaar · Tik op een knop' : 'Aippie is ready · Tap a button'}
              </span>}
        </div>
        {speaking && (
          <div className="cb-companion__waves">
            {[0,1,2,3,4].map(i => (
              <div key={i} className="cb-companion__bar"
                style={{ animationDelay: `${i * 0.1}s`, background: companionColor }} />
            ))}
          </div>
        )}
        <button
          className="cb-settings-btn"
          onClick={() => setShowContactSetup(true)}
          title={lang === 'nl' ? 'Set up parent contacts' : 'Set up parent contacts'}
        >
          <Settings size={12} />
          {contacts.length === 0 && <span className="cb-settings-dot" />}
        </button>
      </div>

      {/* No contacts warning */}
      {contacts.length === 0 && (
        <button className="cb-no-contact-banner" onClick={() => setShowContactSetup(true)}>
          <AlertTriangle size={12} style={{ color: '#fbbf24' }} />
          <span>
            {lang === 'nl'
              ? 'Add mom or dad so Aippie can send messages →'
              : 'Add mom or dad so Aippie can send messages →'}
          </span>
        </button>
      )}

      {/* Category tabs */}
      <div className="cb-cat-tabs">
        {CATEGORIES.map((cat, i) => (
          <button
            key={cat.id}
            className={`cb-cat-tab${activeCatIdx === i ? ' cb-cat-tab--active' : ''}`}
            style={activeCatIdx === i
              ? { borderColor: cat.color, color: cat.color, background: cat.bg }
              : undefined}
            onClick={() => {
              setActiveCatIdx(i);
              setSelected(null);
              setShowParentActions(false);
              idleCount.current = 0;
            }}
          >
            <span className="cb-cat-tab__dot" style={{ background: cat.color }} />
            <span className="cb-cat-tab__label">{lang === 'nl' ? cat.label_nl : cat.label_en}</span>
          </button>
        ))}
      </div>

      {/* Icon grid */}
      <div className="cb-grid">
        {activeCat.items.map(item => {
          const isActive   = selected?.id === item.id;
          const isBouncing = bouncing === item.id;
          return (
            <button
              key={item.id}
              className={`cb-btn${isActive ? ' cb-btn--active' : ''}${isBouncing ? ' cb-btn--bounce' : ''}${item.isUrgent && activeCat.id === 'emergency' ? ' cb-btn--emergency' : ''}`}
              style={isActive
                ? { borderColor: activeCat.color, background: activeCat.bg, boxShadow: `0 0 24px ${activeCat.color}40` }
                : undefined}
              onClick={() => handleSelect(item)}
            >
              <span className="cb-btn__emoji">{item.emoji}</span>
              <span className="cb-btn__label" style={isActive ? { color: activeCat.color } : undefined}>
                {lang === 'nl' ? item.label_nl : item.label_en}
              </span>
              {item.isUrgent && <span className="cb-btn__urgent-dot" />}
              {isActive && speaking && (
                <span className="cb-btn__pulse" style={{ background: activeCat.color }} />
              )}
            </button>
          );
        })}
      </div>

      {/* Result card */}
      {selected && (
        <div
          ref={resultRef}
          className="cb-result"
          style={{ borderColor: activeCat.color + '50', background: activeCat.bg }}
        >
          <div className="cb-result__top">
            <span className="cb-result__big-emoji">{selected.emoji}</span>
            <div className="cb-result__content">
              <div className="cb-result__phrase">
                &ldquo;{lang === 'nl' ? selected.phrase_nl : selected.phrase_en}&rdquo;
              </div>
              <div className="cb-result__status" style={{ color: speaking ? activeCat.color : '#4ade80' }}>
                {speaking
                  ? <><Volume2 size={13}/> {lang === 'nl' ? 'Aippie spreekt nu…' : 'Aippie is speaking…'}</>
                  : <span>{lang === 'nl' ? 'Stem afgespeeld' : 'Played'}</span>}
              </div>
            </div>
          </div>

          <div className="cb-result__parent">
            <Bell size={11} style={{ color: activeCat.color, flexShrink: 0, marginTop: 1 }} />
            <span>{lang === 'nl' ? selected.parent_nl : selected.parent_en}</span>
          </div>

          <div className="cb-result__actions">
            <button
              className="cb-result__repeat"
              style={{ background: activeCat.color }}
              onClick={() => speak(lang === 'nl' ? selected.avatar_nl : selected.avatar_en, 'responding')}
            >
              <Volume2 size={14} /> {lang === 'nl' ? 'Repeat' : 'Repeat'}
            </button>
            <button
              className="cb-result__close"
              onClick={() => {
                setSelected(null);
                setShowParentActions(false);
                window.speechSynthesis?.cancel();
                setSpeaking(false);
                speakingRef.current = false;
                setCaption('');
                setAiMode('idle');
              }}
            >
              Close ✕
            </button>
          </div>
        </div>
      )}

      {/* ── Parent Actions Panel ── */}
      {showParentActions && pendingItem && (
        <div className="cb-parent-actions">
          <div className="cb-parent-actions__title">
            <Bell size={13} style={{ color: '#fbbf24' }} />
            {lang === 'nl' ? 'Should I notify mom or dad now?' : 'Should I notify mom or dad now?'}
          </div>

          {contacts.length > 0 ? (
            <div className="cb-parent-actions__contacts">
              {contacts.map(contact => (
                <div key={contact.id} className="cb-parent-actions__contact-row">
                  <span className="cb-parent-actions__contact-name">{contact.label}</span>
                  <button
                    className="cb-parent-actions__btn cb-parent-actions__btn--call"
                    onClick={() => notifyParent(contact, pendingItem)}
                  >
                    <Phone size={14} />
                    {lang === 'nl' ? 'Call' : 'Call'}
                  </button>
                </div>
              ))}
            </div>
          ) : (
            <button className="cb-parent-actions__add-contact" onClick={() => { setShowContactSetup(true); setShowParentActions(false); }}>
              <UserCircle size={14} />
              {lang === 'nl' ? 'Add mom/dad →' : 'Add mom/dad →'}
            </button>
          )}

          <button className="cb-parent-actions__skip" onClick={dismissParentActions}>
            {lang === 'nl' ? 'No, later' : 'No, later'}
          </button>
        </div>
      )}

      {/* Parent activity log */}
      {log.length > 0 && (
        <div className="cb-log">
          <button className="cb-log__toggle" onClick={() => setShowLog(o => !o)}>
            <Bell size={11} /> {lang === 'nl' ? 'Parent notifications' : 'Parent notifications'} · {log.length}
            <span className="cb-log__arrow">{showLog ? '▲' : '▼'}</span>
          </button>
          {showLog && (
            <div className="cb-log__list">
              {log.map((entry, i) => (
                <div key={i} className={`cb-log__row${entry.isUrgent ? ' cb-log__row--urgent' : ''}`}>
                  <span className="cb-log__emoji">{entry.emoji}</span>
                  <div className="cb-log__body">
                    <span className="cb-log__label" style={{ color: entry.color }}>{entry.label}</span>
                    <span className="cb-log__msg">{entry.parent_msg}</span>
                  </div>
                  <span className="cb-log__time">{entry.time}</span>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default AippieCareBoardView;
