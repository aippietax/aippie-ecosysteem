import { useState, useEffect, useRef, useCallback } from 'react';
import {
  Video, VideoOff, Mic, MicOff, PhoneOff, Shield,
  AlertTriangle, Copy, Check, Eye, EyeOff,
  Lock, Wifi, RefreshCw, Users, Zap, Radio,
} from 'lucide-react';
import { supabase } from '../lib/supabase';
import type { RealtimeChannel } from '@supabase/supabase-js';
import type { User } from '@supabase/supabase-js';

// Lazy-loaded to keep the initial bundle small
// eslint-disable-next-line @typescript-eslint/no-explicit-any
let faceapi: any = null;
async function loadFaceApi() {
  if (!faceapi) faceapi = await import('face-api.js');
  return faceapi;
}

const ICE_SERVERS = [
  { urls: 'stun:stun.l.google.com:19302' },
  { urls: 'stun:stun1.l.google.com:19302' },
  { urls: 'stun:stun2.l.google.com:19302' },
];

const FACE_MODEL_CDN = 'https://cdn.jsdelivr.net/gh/justadudewhohacks/face-api.js@0.22.2/weights';
const MAX_PEERS = 6;

type Screen = 'lobby' | 'room' | 'ended';

function genCode(): string {
  const c = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  return Array.from({ length: 6 }, () => c[Math.floor(Math.random() * c.length)]).join('');
}

function fmtTime(s: number): string {
  return `${String(Math.floor(s / 60)).padStart(2, '0')}:${String(s % 60).padStart(2, '0')}`;
}

function PeerVideoTile({ stream, index }: { stream: MediaStream; index: number }) {
  const ref = useRef<HTMLVideoElement>(null);
  useEffect(() => {
    if (ref.current) ref.current.srcObject = stream;
  }, [stream]);
  return (
    <div className="vv-tile">
      <video ref={ref} autoPlay playsInline className="vv-tile-video" />
      <span className="vv-tile-label">Participant {index + 1}</span>
    </div>
  );
}

export default function AippieVideoVaultView({ user, onNavigateToChat }: {
  user: User | null;
  onNavigateToChat?: () => void;
}) {
  const [screen, setScreen]           = useState<Screen>('lobby');
  const [myPeerId]                    = useState(() => crypto.randomUUID());
  const [roomCode, setRoomCode]       = useState('');
  const [joinInput, setJoinInput]     = useState('');
  const [joinMode, setJoinMode]       = useState(false);
  const [videoOn, setVideoOn]         = useState(true);
  const [audioOn, setAudioOn]         = useState(true);
  const [blurOn, setBlurOn]           = useState(false);
  const [voiceMask, setVoiceMask]     = useState(false);
  const [sneakOn, setSneakOn]         = useState(false);
  const [sneakAlert, setSneakAlert]   = useState(false);
  const [recWarning, setRecWarning]   = useState(false);
  const [copied, setCopied]           = useState(false);
  const [secs, setSecs]               = useState(0);
  const [faceReady, setFaceReady]     = useState(false);
  const [faceLoading, setFaceLoading] = useState(false);
  const [err, setErr]                 = useState('');
  const [sneakCount, setSneakCount]   = useState(0);
  const [peerStreams, setPeerStreams]  = useState<Map<string, MediaStream>>(new Map());

  const localRef        = useRef<HTMLVideoElement>(null);
  const streamRef       = useRef<MediaStream | null>(null);
  const chanRef         = useRef<RealtimeChannel | null>(null);
  const peersRef        = useRef<Map<string, RTCPeerConnection>>(new Map());
  const iceQueuesRef    = useRef<Map<string, RTCIceCandidateInit[]>>(new Map());
  const canvasElRef     = useRef<HTMLCanvasElement | null>(null);
  const canvasStreamRef = useRef<MediaStream | null>(null);
  const rafRef          = useRef<number | null>(null);
  const timerRef        = useRef<ReturnType<typeof setInterval> | null>(null);
  const sneakTimerRef   = useRef<ReturnType<typeof setInterval> | null>(null);
  const screenRef       = useRef<Screen>('lobby');
  const audioCtxRef     = useRef<AudioContext | null>(null);
  const pitchNodeRef    = useRef<ScriptProcessorNode | null>(null);
  const maskedTrackRef  = useRef<MediaStreamTrack | null>(null);

  useEffect(() => { screenRef.current = screen; }, [screen]);

  // Call timer
  useEffect(() => {
    if (screen === 'room') {
      timerRef.current = setInterval(() => setSecs(s => s + 1), 1000);
    } else {
      if (timerRef.current) { clearInterval(timerRef.current); timerRef.current = null; }
    }
    return () => { if (timerRef.current) clearInterval(timerRef.current); };
  }, [screen]);

  // Screen-record / tab-switch detection
  useEffect(() => {
    const onVis = () => {
      if (document.hidden && screenRef.current === 'room') {
        setRecWarning(true);
        setTimeout(() => setRecWarning(false), 5000);
      }
    };
    document.addEventListener('visibilitychange', onVis);
    return () => document.removeEventListener('visibilitychange', onVis);
  }, []);

  // Sneak detection loop
  useEffect(() => {
    if (!sneakOn || !faceReady) return;
    sneakTimerRef.current = setInterval(async () => {
      const v = localRef.current;
      if (!v || v.readyState < 2) return;
      try {
        const fa = await loadFaceApi();
        const d = await fa.detectAllFaces(
          v, new fa.TinyFaceDetectorOptions({ scoreThreshold: 0.38 })
        );
        if (d.length > 1) {
          setSneakAlert(true);
          setSneakCount(n => n + 1);
          setTimeout(() => setSneakAlert(false), 4000);
        }
      } catch { /* model warming up */ }
    }, 2000);
    return () => { if (sneakTimerRef.current) clearInterval(sneakTimerRef.current); };
  }, [sneakOn, faceReady]);

  // eslint-disable-next-line react-hooks/exhaustive-deps
  useEffect(() => () => { cleanup(false); }, []);

  // ── Media ──────────────────────────────────────────────────────────────────
  const getMedia = async (): Promise<MediaStream | null> => {
    try {
      const s = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
      streamRef.current = s;
      if (localRef.current) localRef.current.srcObject = s;
      return s;
    } catch {
      setErr('Camera or microphone access denied. Please allow permissions and try again.');
      return null;
    }
  };

  // ── RTCPeerConnection factory ──────────────────────────────────────────────
  const makePc = useCallback((remotePeerId: string): RTCPeerConnection => {
    if (peersRef.current.has(remotePeerId)) return peersRef.current.get(remotePeerId)!;

    const pc = new RTCPeerConnection({ iceServers: ICE_SERVERS });

    if (streamRef.current) {
      streamRef.current.getTracks().forEach(t => {
        // If voice mask is active substitute the masked audio track
        if (t.kind === 'audio' && maskedTrackRef.current) {
          pc.addTrack(maskedTrackRef.current, streamRef.current!);
        } else {
          pc.addTrack(t, streamRef.current!);
        }
      });
    }

    // If canvas blur already active, replace video sender immediately
    const canvasVid = canvasStreamRef.current?.getVideoTracks()[0];
    if (canvasVid) {
      const sender = pc.getSenders().find(s => s.track?.kind === 'video');
      sender?.replaceTrack(canvasVid);
    }

    pc.onicecandidate = ({ candidate }) => {
      if (candidate) {
        chanRef.current?.send({
          type: 'broadcast', event: 'sig',
          payload: { t: 'ice', from: myPeerId, to: remotePeerId, c: candidate.toJSON() },
        });
      }
    };

    pc.ontrack = ({ streams }) => {
      if (streams[0]) {
        setPeerStreams(prev => new Map(prev).set(remotePeerId, streams[0]));
      }
    };

    pc.onconnectionstatechange = () => {
      if (['failed', 'disconnected', 'closed'].includes(pc.connectionState)) {
        peersRef.current.delete(remotePeerId);
        iceQueuesRef.current.delete(remotePeerId);
        setPeerStreams(prev => { const m = new Map(prev); m.delete(remotePeerId); return m; });
      }
    };

    peersRef.current.set(remotePeerId, pc);
    return pc;
  }, [myPeerId]);

  // ── Signaling ──────────────────────────────────────────────────────────────
  const onSig = useCallback(async (payload: Record<string, unknown>) => {
    const { t, from, to, sdp, c } = payload as {
      t: string; from: string; to?: string;
      sdp?: RTCSessionDescriptionInit; c?: RTCIceCandidateInit;
    };

    if (!from || from === myPeerId) return;
    if (to && to !== myPeerId) return;

    if (t === 'hello') {
      if (peersRef.current.size >= MAX_PEERS) return;
      if (!streamRef.current) return;
      const pc = makePc(from);
      const offer = await pc.createOffer();
      await pc.setLocalDescription(offer);
      chanRef.current?.send({
        type: 'broadcast', event: 'sig',
        payload: { t: 'offer', from: myPeerId, to: from, sdp: offer },
      });

    } else if (t === 'offer') {
      if (peersRef.current.size >= MAX_PEERS && !peersRef.current.has(from)) return;
      const pc = makePc(from);
      await pc.setRemoteDescription(new RTCSessionDescription(sdp!));
      for (const ic of iceQueuesRef.current.get(from) ?? []) {
        await pc.addIceCandidate(new RTCIceCandidate(ic));
      }
      iceQueuesRef.current.delete(from);
      const ans = await pc.createAnswer();
      await pc.setLocalDescription(ans);
      chanRef.current?.send({
        type: 'broadcast', event: 'sig',
        payload: { t: 'answer', from: myPeerId, to: from, sdp: ans },
      });

    } else if (t === 'answer') {
      const pc = peersRef.current.get(from);
      if (pc?.signalingState === 'have-local-offer') {
        await pc.setRemoteDescription(new RTCSessionDescription(sdp!));
      }

    } else if (t === 'ice') {
      const pc = peersRef.current.get(from);
      if (pc?.remoteDescription) {
        await pc.addIceCandidate(new RTCIceCandidate(c!));
      } else {
        const q = iceQueuesRef.current.get(from) ?? [];
        q.push(c!);
        iceQueuesRef.current.set(from, q);
      }

    } else if (t === 'bye') {
      peersRef.current.get(from)?.close();
      peersRef.current.delete(from);
      iceQueuesRef.current.delete(from);
      setPeerStreams(prev => { const m = new Map(prev); m.delete(from); return m; });
    }
  }, [myPeerId, makePc]);

  // ── Enter room ─────────────────────────────────────────────────────────────
  const enterRoom = async (code: string) => {
    setErr('');
    const stream = await getMedia();
    if (!stream) return;

    setRoomCode(code);
    setScreen('room');
    setSecs(0);

    const ch = supabase
      .channel(`vv2_${code}`, { config: { broadcast: { self: false } } })
      .on('broadcast', { event: 'sig' }, ({ payload }) => onSig(payload as Record<string, unknown>))
      .subscribe(status => {
        if (status !== 'SUBSCRIBED') return;
        ch.send({ type: 'broadcast', event: 'sig', payload: { t: 'hello', from: myPeerId } });
      });

    chanRef.current = ch;
  };

  const startCall = () => enterRoom(genCode());
  const joinCall = () => {
    const code = joinInput.trim().toUpperCase();
    if (code.length !== 6) { setErr('Enter a valid 6-character room code.'); return; }
    enterRoom(code);
  };

  // ── Cleanup ────────────────────────────────────────────────────────────────
  const cleanup = (sendBye = true) => {
    if (sendBye) {
      chanRef.current?.send({ type: 'broadcast', event: 'sig', payload: { t: 'bye', from: myPeerId } });
    }
    if (rafRef.current) { cancelAnimationFrame(rafRef.current); rafRef.current = null; }
    canvasElRef.current = null;
    canvasStreamRef.current = null;
    pitchNodeRef.current?.disconnect(); pitchNodeRef.current = null;
    audioCtxRef.current?.close().catch(() => {}); audioCtxRef.current = null;
    peersRef.current.forEach(pc => pc.close());
    peersRef.current.clear();
    iceQueuesRef.current.clear();
    streamRef.current?.getTracks().forEach(t => t.stop()); streamRef.current = null;
    chanRef.current?.unsubscribe(); chanRef.current = null;
    setPeerStreams(new Map());
  };

  const hangup = () => { cleanup(true); setScreen('ended'); };

  // ── Canvas background blur (replaces outgoing video stream) ───────────────
  const startCanvasBlur = useCallback(() => {
    const video = localRef.current;
    if (!video || !streamRef.current) return;

    const canvas = document.createElement('canvas');
    canvas.width = 640;
    canvas.height = 480;
    canvasElRef.current = canvas;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const draw = () => {
      if (!canvasElRef.current) return;
      ctx.filter = 'blur(18px)';
      // Overdraw slightly to prevent black blur border
      ctx.drawImage(video, -20, -20, 680, 520);
      rafRef.current = requestAnimationFrame(draw);
    };
    draw();

    const cs = canvas.captureStream(30);
    canvasStreamRef.current = cs;

    const canvasVid = cs.getVideoTracks()[0];
    if (canvasVid) {
      peersRef.current.forEach(pc => {
        const sender = pc.getSenders().find(s => s.track?.kind === 'video');
        sender?.replaceTrack(canvasVid);
      });
    }
  }, []);

  const stopCanvasBlur = useCallback(() => {
    if (rafRef.current) { cancelAnimationFrame(rafRef.current); rafRef.current = null; }
    canvasElRef.current = null;
    canvasStreamRef.current = null;

    const origVid = streamRef.current?.getVideoTracks()[0];
    if (origVid) {
      peersRef.current.forEach(pc => {
        const sender = pc.getSenders().find(s => s.track?.kind === 'video');
        sender?.replaceTrack(origVid);
      });
    }
  }, []);

  const toggleBlur = useCallback(() => {
    const next = !blurOn;
    setBlurOn(next);
    if (next) startCanvasBlur(); else stopCanvasBlur();
  }, [blurOn, startCanvasBlur, stopCanvasBlur]);

  // ── Voice masking (+15% pitch shift → anti voice-clone) ───────────────────
  const applyVoiceMask = useCallback(() => {
    if (!streamRef.current) return;
    try {
      const ctx = new AudioContext();
      audioCtxRef.current = ctx;
      const source = ctx.createMediaStreamSource(streamRef.current);
      const dest = ctx.createMediaStreamDestination();
      const proc = ctx.createScriptProcessor(4096, 1, 1);
      let phase = 0;
      proc.onaudioprocess = (e) => {
        const input = e.inputBuffer.getChannelData(0);
        const output = e.outputBuffer.getChannelData(0);
        for (let i = 0; i < 4096; i++) {
          phase += 1.15;
          output[i] = input[Math.floor(phase) % 4096] * 0.85;
        }
        if (Math.floor(phase) > 4096 * 4) phase = phase % 4096;
      };
      source.connect(proc);
      proc.connect(dest);
      pitchNodeRef.current = proc;
      const maskedAudio = dest.stream.getAudioTracks()[0];
      if (maskedAudio) {
        maskedTrackRef.current = maskedAudio;
        peersRef.current.forEach(pc => {
          const sender = pc.getSenders().find(s => s.track?.kind === 'audio');
          sender?.replaceTrack(maskedAudio);
        });
      }
    } catch { /* no-op */ }
  }, []);

  const removeVoiceMask = useCallback(() => {
    pitchNodeRef.current?.disconnect(); pitchNodeRef.current = null;
    audioCtxRef.current?.close().catch(() => {}); audioCtxRef.current = null;
    maskedTrackRef.current = null;
    const origAudio = streamRef.current?.getAudioTracks()[0];
    if (origAudio) {
      peersRef.current.forEach(pc => {
        const sender = pc.getSenders().find(s => s.track?.kind === 'audio');
        sender?.replaceTrack(origAudio);
      });
    }
  }, []);

  const toggleVoiceMask = useCallback(() => {
    const next = !voiceMask;
    setVoiceMask(next);
    if (next) applyVoiceMask(); else removeVoiceMask();
  }, [voiceMask, applyVoiceMask, removeVoiceMask]);

  // ── Toggles ────────────────────────────────────────────────────────────────
  const toggleVideo = () => {
    const t = streamRef.current?.getVideoTracks()[0];
    if (t) { t.enabled = !videoOn; setVideoOn(v => !v); }
  };

  const toggleAudio = () => {
    const t = streamRef.current?.getAudioTracks()[0];
    if (t) { t.enabled = !audioOn; setAudioOn(a => !a); }
  };

  const loadFaceModel = useCallback(async () => {
    if (faceReady || faceLoading) return;
    setFaceLoading(true);
    try {
      const fa = await loadFaceApi();
      await fa.nets.tinyFaceDetector.loadFromUri(FACE_MODEL_CDN);
      setFaceReady(true);
    } catch { /* CDN unavailable */ }
    finally { setFaceLoading(false); }
  }, [faceReady, faceLoading]);

  const handleSneakToggle = () => { if (!sneakOn) loadFaceModel(); setSneakOn(s => !s); };

  const copyCode = () => {
    navigator.clipboard.writeText(roomCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  // ── Render ─────────────────────────────────────────────────────────────────
  if (!user) {
    return (
      <div className="vv-root vv-center">
        <Lock size={40} className="vv-empty-icon" />
        <p className="vv-empty-text">Sign in to use Video Vault</p>
      </div>
    );
  }

  if (screen === 'ended') {
    return (
      <div className="vv-root vv-center">
        <div className="vv-ended-icon-wrap"><PhoneOff size={36} /></div>
        <h3 className="vv-ended-title">Call Ended</h3>
        <p className="vv-ended-sub">Duration: {fmtTime(secs)}</p>
        {sneakCount > 0 && (
          <div className="vv-ended-sneak-warn">
            <AlertTriangle size={14} />
            {sneakCount} unauthorized viewer alert{sneakCount > 1 ? 's' : ''} during this call
          </div>
        )}
        <button className="vv-btn-primary" onClick={() => { setScreen('lobby'); setSecs(0); setSneakCount(0); setJoinMode(false); }}>
          <RefreshCw size={15} /> New Room
        </button>
        {onNavigateToChat && (
          <button className="vv-btn-ghost" onClick={onNavigateToChat}>Back to SecureChat</button>
        )}
      </div>
    );
  }

  // ── Room ───────────────────────────────────────────────────────────────────
  if (screen === 'room') {
    const peerList = Array.from(peerStreams.entries());
    const totalTiles = Math.min(peerList.length + 1, MAX_PEERS);
    const hasConnected = peerList.length > 0;

    return (
      <div className="vv-root vv-call-root">
        {sneakAlert && (
          <div className="vv-sneak-alert">
            <AlertTriangle size={18} />
            <span>UNAUTHORIZED VIEWER DETECTED — Content shielded</span>
          </div>
        )}
        {recWarning && (
          <div className="vv-rec-warning">
            <Shield size={13} /> Screen recording or tab-switch detected — Session logged
          </div>
        )}

        {/* Header */}
        <div className="vv-call-header">
          <div className="vv-call-header__left">
            <span className="vv-live-dot" />
            <span className="vv-room-label">{roomCode}</span>
            <span className="vv-call-timer">{fmtTime(secs)}</span>
          </div>
          <div className="vv-call-header__right">
            <span className="vv-peer-count"><Users size={10} /> {peerList.length + 1}</span>
            <span className="vv-e2e-badge"><Lock size={10} /> P2P · E2EE</span>
            <button className="vv-share-code-inline" onClick={copyCode}>
              {copied ? <Check size={11} /> : <Copy size={11} />}
              {roomCode}
            </button>
          </div>
        </div>

        {/* Video grid + waiting overlay */}
        <div className="vv-grid-container">
          <div className={`vv-grid vv-grid--${totalTiles}${sneakAlert ? ' vv-grid--shielded' : ''}`}>
            {/* My tile */}
            <div className="vv-tile vv-tile--self">
              <video
                ref={localRef}
                autoPlay playsInline muted
                className={`vv-tile-video${blurOn ? ' vv-tile-video--blur' : ''}`}
              />
              {!videoOn && <div className="vv-tile-off"><VideoOff size={22} /></div>}
              <span className="vv-tile-label">
                You{blurOn ? ' · Blur' : ''}{voiceMask ? ' · Voice' : ''}
              </span>
              {sneakOn && <span className="vv-pip-sneak-badge"><Eye size={10} /> SNEAK GUARD</span>}
            </div>

            {/* Remote peer tiles */}
            {peerList.map(([peerId, stream], i) => (
              <PeerVideoTile key={peerId} stream={stream} index={i} />
            ))}
          </div>

          {!hasConnected && (
            <div className="vv-waiting-fullscreen">
              <div className="vv-waiting-ring" />
              <p className="vv-waiting-text">Waiting for participants…</p>
              <div className="vv-share-code-row">
                <span>Room code:</span>
                <strong className="vv-share-code-val">{roomCode}</strong>
                <button className="vv-copy-code-btn" onClick={copyCode}>
                  {copied ? <Check size={13} /> : <Copy size={13} />}
                </button>
              </div>
              <p className="vv-waiting-hint">Up to {MAX_PEERS - 1} others can join this room</p>
            </div>
          )}
        </div>

        {/* Controls */}
        <div className="vv-controls">
          <button className={`vv-ctrl${audioOn ? '' : ' vv-ctrl--muted'}`} onClick={toggleAudio}>
            {audioOn ? <Mic size={20} /> : <MicOff size={20} />}
            <span className="vv-ctrl__label">{audioOn ? 'Mute' : 'Unmuted'}</span>
          </button>
          <button className={`vv-ctrl${videoOn ? '' : ' vv-ctrl--muted'}`} onClick={toggleVideo}>
            {videoOn ? <Video size={20} /> : <VideoOff size={20} />}
            <span className="vv-ctrl__label">{videoOn ? 'Video' : 'Off'}</span>
          </button>
          <button className={`vv-ctrl${blurOn ? ' vv-ctrl--active' : ''}`} onClick={toggleBlur} title="Background blur — replaces outgoing stream">
            <EyeOff size={20} />
            <span className="vv-ctrl__label">Blur BG</span>
          </button>
          <button
            className={`vv-ctrl${sneakOn ? ' vv-ctrl--active' : ''}${faceLoading ? ' vv-ctrl--loading' : ''}`}
            onClick={handleSneakToggle}
          >
            {faceLoading ? <RefreshCw size={20} className="vv-spin" /> : <Eye size={20} />}
            <span className="vv-ctrl__label">{faceLoading ? 'Loading…' : sneakOn ? 'Sneak ON' : 'Sneak'}</span>
          </button>
          <button className={`vv-ctrl${voiceMask ? ' vv-ctrl--active' : ''}`} onClick={toggleVoiceMask} title="AI Voice Masking">
            <Radio size={20} />
            <span className="vv-ctrl__label">{voiceMask ? 'Voice ON' : 'Voice'}</span>
          </button>
          <button className="vv-ctrl vv-ctrl--end" onClick={hangup}>
            <PhoneOff size={20} />
            <span className="vv-ctrl__label">End</span>
          </button>
        </div>
      </div>
    );
  }

  // ── Lobby ──────────────────────────────────────────────────────────────────
  return (
    <div className="vv-root">
      <div className="vv-lobby">
        <div className="vv-lobby-hero">
          <div className="vv-lobby-icon-wrap"><Video size={32} /></div>
          <h2 className="vv-lobby-title">Aippie Video Vault</h2>
          <p className="vv-lobby-sub">
            Encrypted boardroom — up to {MAX_PEERS} participants. Video never touches our servers.
          </p>
        </div>

        <div className="vv-sec-badges">
          {[
            { icon: <Lock size={11} />,    label: 'P2P — No server video' },
            { icon: <Shield size={11} />,   label: 'E2E Encrypted' },
            { icon: <Users size={11} />,    label: `Up to ${MAX_PEERS} participants` },
            { icon: <Eye size={11} />,      label: 'Sneak Detection' },
            { icon: <Zap size={11} />,      label: 'Canvas Background Blur' },
            { icon: <Radio size={11} />,    label: 'AI Voice Masking' },
          ].map(b => <span key={b.label} className="vv-sec-badge">{b.icon} {b.label}</span>)}
        </div>

        <div className="vv-lobby-tabs">
          <button className={`vv-lobby-tab${!joinMode ? ' vv-lobby-tab--active' : ''}`} onClick={() => { setJoinMode(false); setErr(''); }}>
            New Room
          </button>
          <button className={`vv-lobby-tab${joinMode ? ' vv-lobby-tab--active' : ''}`} onClick={() => { setJoinMode(true); setErr(''); }}>
            Join Room
          </button>
        </div>

        <div className="vv-lobby-panel">
          {!joinMode ? (
            <>
              <p className="vv-lobby-panel__desc">Create a secure boardroom. Share the 6-character code to invite up to {MAX_PEERS - 1} others.</p>
              <button className="vv-btn-primary vv-btn-call" onClick={startCall}>
                <Video size={17} /> Start Secure Boardroom
              </button>
            </>
          ) : (
            <>
              <p className="vv-lobby-panel__desc">Enter the 6-character room code shared with you.</p>
              <input
                className="vv-code-input"
                placeholder="A3X9K2"
                value={joinInput}
                onChange={e => setJoinInput(e.target.value.toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 6))}
                maxLength={6}
                autoFocus
                onKeyDown={e => { if (e.key === 'Enter') joinCall(); }}
              />
              <button className="vv-btn-primary vv-btn-call" onClick={joinCall} disabled={joinInput.length !== 6}>
                <Wifi size={17} /> Join Boardroom
              </button>
            </>
          )}
          {err && <p className="vv-err">{err}</p>}
        </div>

        <div className="vv-how">
          <p className="vv-how__title">How it works</p>
          <div className="vv-how__steps">
            {[
              { n: '1', text: 'Create a room — receive a 6-character board code' },
              { n: '2', text: 'Share code via Aippie SecureChat or any secure channel' },
              { n: '3', text: 'All participants connect P2P — zero server involvement' },
            ].map(s => (
              <div key={s.n} className="vv-how__step">
                <span className="vv-how__step-num">{s.n}</span>
                <span className="vv-how__step-text">{s.text}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="vv-native-note">
          <Shield size={11} />
          <span>Full HDMI blackout and device kill switch available in the native iOS/Android app</span>
        </div>
      </div>
    </div>
  );
}
