/**
 * AippieDoctorView — V186 Premium Care Router + Smart Band Hardware Module
 * AIPPIETAX S.A.
 *
 * Seven integrated modules:
 *   1. PPG biometrics scanner (fingertip → HR / HRV / SpO2)
 *   2. Skin / lesion camera analyser (CV simulation → color & texture report)
 *   3. Medical geolocation radar (GPS → nearest clinics, pharmacies, doctors)
 *   4. Doctor consultation (€30 gate, any 16-digit card, dual-camera + 5-signal telemetry overlay)
 *   5. Earnings Terminal — split-payment ledger, payout simulation, invoice export
 *   6. AI Heart-Attack Early Warning & 112 Emergency Dispatcher (V184)
 *   7. Aippie Smart Band — Bluetooth hardware interface + order dispatch (V186)
 *
 * Split logic: 80% net to practitioner / 20% platform fee to AIPPIETAX S.A.
 */
import { useCallback, useEffect, useRef, useState } from 'react';
import AippieVoiceOverlay from './AippieVoiceOverlay';
import FatigueCompanion from './FatigueCompanion';
import { useAuth } from '../contexts/AuthContext';
import {
  Activity, AlertCircle, Camera, CheckCircle2,
  CreditCard, Eye, FlipHorizontal, Hand, Heart, Lock, MapPin,
  Mic, Navigation, Phone, Stethoscope, Wind,
  Zap, ScanLine, RefreshCw, Video, TrendingUp,
  DollarSign, Building2, ArrowDownToLine, FileText,
  Copy, ChevronRight, ShieldAlert, Siren, Wifi, Radio,
  Thermometer, Droplets, Timer, Bluetooth, Watch, ShoppingCart,
  Package, Signal, Cpu, Scan, Brain, RotateCcw,
} from 'lucide-react';
import { supabase } from '../lib/supabase';
import { applyPremiumVoice, withVoicesReady } from '../lib/ttsVoice';

// ── Constants ──────────────────────────────────────────────────────────────────
const SPEECH_RATE  = 0.82;
const SPEECH_PITCH = 1.02;
const PLATFORM_FEE_RATE = 0.20; // 20 % retained by AIPPIETAX S.A.
const CONSULT_PRICE_EUR = 30.00;

const DISCLAIMER_V101 =
  'I am happy to help you with wellness information and finding care nearby, but I am an AI guide and not a physician. ' +
  'For official medical diagnoses, treatments, and exact insurance coverage, ALWAYS contact your local doctor or ' +
  'your own health insurance provider directly.';

const SKIN_INSTRUCTION =
  'Gently hold the camera over the area of the rash or swelling, and I will analyze it with you right away.';

// ── Types ──────────────────────────────────────────────────────────────────────
type ScanPhase  = 'idle' | 'place' | 'analyzing' | 'success' | 'error';
type DocTab     = 'vitals' | 'skin' | 'nearby' | 'consult' | 'earnings' | 'heartAlert' | 'smartBand' | 'elysium' | 'autism';

// ── Elysium Diagnostic Simulation Panel — V194 ────────────────────────────────
type ElysiumScanPhase  = 'idle' | 'scanning' | 'active' | 'anomaly';
type ElysiumTrackState = 'initializing' | 'active' | 'anomaly';

interface BodyCoord { x: number; y: number; z: number; label: string; risk: 'ok' | 'warn' | 'critical'; }
interface PpgSample { t: number; value: number; }

const BODY_LANDMARKS: Omit<BodyCoord, 'risk'>[] = [
  { x: 0,    y: 10,  z: 2,   label: 'Cranial Vault'      },
  { x: -12,  y: 18,  z: 1,   label: 'L-Temporal Lobe'    },
  { x: 12,   y: 18,  z: 1,   label: 'R-Temporal Lobe'    },
  { x: 0,    y: 30,  z: 3,   label: 'Cervical Spine C3'  },
  { x: -18,  y: 42,  z: 2,   label: 'L-Shoulder Joint'   },
  { x: 18,   y: 42,  z: 2,   label: 'R-Shoulder Joint'   },
  { x: -6,   y: 55,  z: 4,   label: 'Cardiac Region'     },
  { x: 0,    y: 62,  z: 4,   label: 'Diaphragm'          },
  { x: -10,  y: 70,  z: 3,   label: 'L-Kidney'           },
  { x: 10,   y: 70,  z: 3,   label: 'R-Kidney'           },
  { x: -20,  y: 75,  z: 2,   label: 'L-Elbow'            },
  { x: 20,   y: 75,  z: 2,   label: 'R-Elbow'            },
  { x: -8,   y: 85,  z: 3,   label: 'L-Hip Joint'        },
  { x: 8,    y: 85,  z: 3,   label: 'R-Hip Joint'        },
  { x: -10,  y: 95,  z: 2,   label: 'L-Knee'             },
  { x: 10,   y: 95,  z: 2,   label: 'R-Knee'             },
  { x: -24,  y: 90,  z: 1,   label: 'L-Wrist'            },
  { x: 24,   y: 90,  z: 1,   label: 'R-Wrist'            },
];

const SYMPTOM_RESPONSES: Record<string, string> = {
  pijn:       'Pain symptoms registered. Based on your input, I am activating the clinical risk matrix. Always consult your doctor for an official diagnosis.',
  borst:      'Thoracic symptoms detected. This may indicate musculoskeletal or cardiac causes. As a precaution, I am escalating to the cardiac monitoring system.',
  hoofdpijn:  'Cephalalgia registered. Differential diagnosis includes migraine, tension headache, or hypertension. Monitor blood pressure and consult your physician.',
  kortademig: 'Dyspnea detected. Possible causes include pulmonary or cardiac origin. I am monitoring your SpO2 in real time.',
  duizelig:   'Vertigo or presyncope registered. Check hydration status and blood pressure. Avoid standing up suddenly.',
  koorts:     'Pyrexia registered. If fever persists above 38.5 degrees Celsius, consult your doctor. Increase fluid intake.',
  vermoeid:   'Fatigue complaint logged. This may indicate anemia, sleep disorders, or infection. Comprehensive screening is recommended.',
};

const ELYSIUM_CRITICAL_TRIGGER_WORDS = ['hartaanval', 'borst', 'bewusteloos', 'stroke', 'beroerte', 'geen adem'];

const PPG_WAVEFORM_POINTS = 64;

// ── Smart Band — hardware constants ───────────────────────────────────────────
const BAND_PRICE_HW   = 49.00;   // one-time hardware activation fee
const BAND_PRICE_SAAS = 9.99;    // monthly Lifeline SaaS monitoring

type BandInputMode  = 'camera' | 'bluetooth';
type BandColor      = 'black' | 'white' | 'navy' | 'pink';
type BandConnPhase  = 'idle' | 'scanning' | 'pairing' | 'connected' | 'streaming';
type BandOrderPhase = 'idle' | 'processing' | 'confirmed';

interface BandColorOption {
  id:    BandColor;
  label: string;
  emoji: string;
  hex:   string;
  ring:  string;
}

const BAND_COLORS: BandColorOption[] = [
  { id: 'black', label: 'Black',  emoji: '⚫', hex: '#0f172a', ring: '#475569' },
  { id: 'white', label: 'White',  emoji: '⚪', hex: '#f1f5f9', ring: '#94a3b8' },
  { id: 'navy',  label: 'Navy',   emoji: '🔵', hex: '#1e3a8a', ring: '#3b82f6' },
  { id: 'pink',  label: 'Pink',   emoji: '🔴', hex: '#be185d', ring: '#f472b6' },
];

const BT_STEPS: string[] = [
  'Bluetooth LE scanner started · frequency 2.4 GHz',
  'Aippie Smart Band found · MAC: AB:CD:EF:12:34:56',
  'Pairing request sent · waiting for confirmation…',
  'Band paired · firmware v2.6.1 · GATT profile active',
  'Green LED array activated · PPG sensor 525nm',
  'Heart rate 74bpm · HRV 61ms · SpO2 98% · live stream',
];

const BT_STREAM_METRICS = [
  { label: 'Heart rate',      unit: 'bpm',   base: 74,  delta: 4,   color: '#f87171' },
  { label: 'HRV',           unit: 'ms',    base: 58,  delta: 8,   color: '#38bdf8' },
  { label: 'SpO2',          unit: '%',     base: 98,  delta: 1.5, color: '#4ade80' },
  { label: 'Temperature',   unit: '°C',    base: 36.7, delta: 0.3, color: '#fbbf24' },
  { label: 'Step count', unit: 'steps', base: 4820, delta: 30,  color: '#a78bfa' },
];
type AlertPhase = 'monitoring' | 'warning' | 'critical' | 'dispatching' | 'dispatched';

// ── Heart-Attack Early Warning — biometric signal config ──────────────────────
interface BiometricSignal {
  id:     'hrv' | 'spo2' | 'gps';
  label:  string;
  emoji:  string;
  color:  string;
  unit:   string;
  normal: [number, number];
  critical: number;
  desc:   string;
}

const BIO_SIGNALS: BiometricSignal[] = [
  {
    id:       'hrv',
    label:    'HRV Anomaly Detection',
    emoji:    '🫀',
    color:    '#f87171',
    unit:     'ms',
    normal:   [45, 80],
    critical: 22,
    desc:     'Heart Rate Variability drop below 22ms triggers Tier-1 cardiac alert.',
  },
  {
    id:       'spo2',
    label:    'SpO2 Drop Interception',
    emoji:    '🩸',
    color:    '#38bdf8',
    unit:     '%',
    normal:   [95, 100],
    critical: 90,
    desc:     'Blood oxygen saturation below 90% activates emergency oxygen-deprivation protocol.',
  },
  {
    id:       'gps',
    label:    'GPS Emergency Dispatcher',
    emoji:    '📍',
    color:    '#4ade80',
    unit:     'fix',
    normal:   [1, 1],
    critical: 0,
    desc:     'Live GPS coordinates armed for instant 112 dispatch with patient location vector.',
  },
];

const DISPATCH_STEPS = [
  'Critical biometrics detected · thresholds exceeded',
  '112 emergency alert compiled · GPS coordinates attached',
  'Alert sent to regional dispatch centre',
  'Ambulance unit #A-247 dispatched · ETA 6 minutes',
  'Heart monitoring active · real-time telemetry transmitted',
  'Family contact informed via emergency protocol',
  'Ambulance arrived · patient transferred ✓',
];

interface Vitals {
  bpm: number; hrv: number; spo2: number; ts: string;
}

interface SkinReport {
  dominantTone: string;
  redness: number;
  uniformity: number;
  hydrationEst: string;
  finding: string;
  advice: string;
}

interface CarePlace {
  name: string;
  type: 'clinic' | 'pharmacy' | 'doctor';
  distanceM: number;
  phone: string;
  address: string;
}

interface PaymentRow {
  id: string;
  gross_eur: number;
  platform_fee_eur: number;
  net_eur: number;
  status: string;
  created_at: string;
}

interface PayoutRow {
  id: string;
  iban: string;
  amount_eur: number;
  invoice_ref: string;
  status: string;
  created_at: string;
}

// ── Helpers ────────────────────────────────────────────────────────────────────
function computeVitals(luminanceSamples: number[]): Vitals {
  const mean     = luminanceSamples.reduce((a, b) => a + b, 0) / luminanceSamples.length;
  const variance = luminanceSamples.reduce((a, b) => a + (b - mean) ** 2, 0) / luminanceSamples.length;
  const stdDev   = Math.sqrt(variance);
  const bpm      = Math.min(92, Math.max(58, 58 + Math.round((stdDev / 30) * 34)));
  const hrv      = Math.round(28 + (stdDev / 30) * 42);
  const spo2     = Math.round(94 + (mean / 255) * 5);
  return { bpm, hrv, spo2, ts: new Date().toISOString() };
}

function analyzeSkin(imageData: ImageData): SkinReport {
  const d = imageData.data;
  let rSum = 0, gSum = 0, bSum = 0;
  const px = d.length / 4;
  for (let i = 0; i < d.length; i += 4) { rSum += d[i]; gSum += d[i+1]; bSum += d[i+2]; }
  const rMean = rSum / px, gMean = gSum / px, bMean = bSum / px;
  let rVar = 0;
  for (let i = 0; i < d.length; i += 4) rVar += (d[i] - rMean) ** 2;
  rVar /= px;
  const uniformity = Math.max(0, Math.min(100, Math.round(100 - (Math.sqrt(rVar) / 60) * 100)));
  const redness = Math.min(100, Math.round(((rMean - gMean) / (rMean + gMean + 1)) * 300 + 10));
  let dominantTone = 'Neutral / light complexion';
  if (rMean > 180 && gMean < 140) dominantTone = 'Elevated redness visible';
  else if (rMean < 100 && gMean < 100 && bMean < 100) dominantTone = 'Dark complexion';
  else if (rMean > 200 && gMean > 170) dominantTone = 'Light / pale complexion';
  const brightness = (rMean + gMean + bMean) / 3;
  const hydrationEst = brightness > 180
    ? 'Good hydration likely'
    : brightness > 120
    ? 'Moderate hydration'
    : 'Possible dry or thickened skin';
  const finding = redness > 55
    ? 'Elevated redness or irritation detected in the analyzed area.'
    : uniformity < 45
    ? 'Irregular skin texture or pigmentation variation visible in this area.'
    : 'No apparent visual anomalies detected in the analyzed area.';
  const advice = redness > 55
    ? 'Consider consulting a dermatologist for persistent redness or rash.'
    : 'Monitor the area. Consult a physician if symptoms persist or worsen.';
  return { dominantTone, redness, uniformity, hydrationEst, finding, advice };
}

async function fetchNearbyPlaces(lat: number, lon: number): Promise<CarePlace[]> {
  const R = 3000;
  const query = `
    [out:json][timeout:10];
    (
      node["amenity"="pharmacy"](around:${R},${lat},${lon});
      node["amenity"="doctors"](around:${R},${lat},${lon});
      node["amenity"="clinic"](around:${R},${lat},${lon});
      node["amenity"="hospital"](around:${R},${lat},${lon});
    );
    out body 20;
  `;
  const url = `https://overpass-api.de/api/interpreter?data=${encodeURIComponent(query)}`;
  const res = await fetch(url, { signal: AbortSignal.timeout(10000) });
  if (!res.ok) throw new Error('Overpass error');
  const json = await res.json();
  const places: CarePlace[] = (json.elements ?? [])
    .filter((el: Record<string, unknown>) => el.tags && (el.tags as Record<string, string>).name)
    .map((el: Record<string, unknown>) => {
      const tags = el.tags as Record<string, string>;
      const amenity = tags.amenity ?? '';
      const type: CarePlace['type'] =
        amenity === 'pharmacy' ? 'pharmacy' :
        amenity === 'doctors'  ? 'doctor'   : 'clinic';
      const dLat = ((el.lat as number) - lat) * Math.PI / 180;
      const dLon = ((el.lon as number) - lon) * Math.PI / 180;
      const a    = Math.sin(dLat/2)**2 + Math.cos(lat*Math.PI/180) * Math.cos((el.lat as number)*Math.PI/180) * Math.sin(dLon/2)**2;
      const distanceM = Math.round(6371000 * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a)));
      return {
        name:      tags.name,
        type,
        distanceM,
        phone:     tags['contact:phone'] ?? tags.phone ?? '',
        address:   [tags['addr:street'], tags['addr:housenumber']].filter(Boolean).join(' ') || '',
      };
    })
    .sort((a: CarePlace, b: CarePlace) => a.distanceM - b.distanceM)
    .slice(0, 12);
  return places;
}

function generateInvoiceRef(): string {
  const seg = () => Math.random().toString(36).slice(2, 6).toUpperCase();
  return `INV-AIPP-${seg()}-${seg()}`;
}

// ── Sub-components ─────────────────────────────────────────────────────────────
function VitalCard({ icon, label, value, unit, color, sub }: {
  icon: React.ReactNode; label: string; value: number;
  unit: string; color: string; sub: string;
}) {
  return (
    <div className="doc-vital-card" style={{ borderColor: color + '44', background: color + '0d' }}>
      <div className="doc-vital-card__top">
        <span className="doc-vital-card__icon" style={{ color }}>{icon}</span>
        <span className="doc-vital-card__label">{label}</span>
      </div>
      <div className="doc-vital-card__value" style={{ color }}>
        {value}<span className="doc-vital-card__unit">{unit}</span>
      </div>
      <div className="doc-vital-card__sub">{sub}</div>
    </div>
  );
}

function SkinMetricBar({ label, value, color }: { label: string; value: number; color: string }) {
  return (
    <div className="doc-skin-metric">
      <div className="doc-skin-metric__head">
        <span className="doc-skin-metric__label">{label}</span>
        <span className="doc-skin-metric__val" style={{ color }}>{value}%</span>
      </div>
      <div className="doc-skin-metric__track">
        <div className="doc-skin-metric__fill" style={{ width: `${value}%`, background: color }} />
      </div>
    </div>
  );
}

const TYPE_ICON: Record<CarePlace['type'], React.ReactNode> = {
  clinic:   <Stethoscope size={14} />,
  pharmacy: <Wind size={14} />,
  doctor:   <Heart size={14} />,
};
const TYPE_COLOR: Record<CarePlace['type'], string> = {
  clinic:   '#38bdf8',
  pharmacy: '#4ade80',
  doctor:   '#fb7185',
};
const TYPE_LABEL: Record<CarePlace['type'], string> = {
  clinic:   'Clinic',
  pharmacy: 'Pharmacy',
  doctor:   'GP',
};

function CareCard({ place }: { place: CarePlace }) {
  const color = TYPE_COLOR[place.type];
  return (
    <div className="doc-care-card" style={{ borderColor: color + '33' }}>
      <div className="doc-care-card__type" style={{ color, background: color + '18' }}>
        {TYPE_ICON[place.type]}
        <span>{TYPE_LABEL[place.type]}</span>
      </div>
      <div className="doc-care-card__name">{place.name}</div>
      <div className="doc-care-card__meta">
        <span className="doc-care-card__dist">
          <Navigation size={10} />
          {place.distanceM < 1000
            ? `${place.distanceM} m`
            : `${(place.distanceM / 1000).toFixed(1)} km`}
        </span>
        {place.address && (
          <span className="doc-care-card__addr">
            <MapPin size={10} /> {place.address}
          </span>
        )}
      </div>
      {place.phone && (
        <a href={`tel:${place.phone}`} className="doc-care-card__phone">
          <Phone size={11} /> {place.phone}
        </a>
      )}
    </div>
  );
}

// ── Earnings stat widget ───────────────────────────────────────────────────────
function EarningsStat({ label, value, sub, color, icon }: {
  label: string; value: string; sub: string; color: string; icon: React.ReactNode;
}) {
  return (
    <div className="doc-earn-stat" style={{ borderColor: color + '33', background: color + '08' }}>
      <div className="doc-earn-stat__icon" style={{ color, background: color + '14' }}>{icon}</div>
      <div className="doc-earn-stat__body">
        <span className="doc-earn-stat__label">{label}</span>
        <span className="doc-earn-stat__value" style={{ color }}>{value}</span>
        <span className="doc-earn-stat__sub">{sub}</span>
      </div>
    </div>
  );
}

// ── Subtitle typewriter ────────────────────────────────────────────────────────
function useSubtitle(text: string, active: boolean) {
  const [sub, setSub] = useState('');
  const tmr = useRef<ReturnType<typeof setInterval> | null>(null);
  const idx = useRef(0);
  useEffect(() => {
    if (tmr.current) { clearInterval(tmr.current); tmr.current = null; }
    setSub('');
    if (!active || !text.trim()) return;
    const words = text.split(/\s+/);
    idx.current = 0;
    tmr.current = setInterval(() => {
      idx.current++;
      setSub(words.slice(Math.max(0, idx.current - 10), idx.current).join(' '));
      if (idx.current >= words.length && tmr.current) { clearInterval(tmr.current); tmr.current = null; }
    }, 420);
    return () => { if (tmr.current) { clearInterval(tmr.current); tmr.current = null; } };
  }, [text, active]);
  return sub;
}

// ── Autism & Behavioral Analysis Panel ────────────────────────────────────────
type AutismScanPhase = 'idle' | 'scanning' | 'analysis' | 'result';

interface MicroExpression {
  emotion: string;
  confidence: number;
  timestamp: number;
  color: string;
}

function AutismBehavioralPanel({ speak }: { speak: (text: string) => void }) {
  const videoRef   = useRef<HTMLVideoElement>(null);
  const canvasRef  = useRef<HTMLCanvasElement>(null);
  const streamRef  = useRef<MediaStream | null>(null);
  const scanTimerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const [phase, setPhase]                   = useState<AutismScanPhase>('idle');
  const [expressions, setExpressions]       = useState<MicroExpression[]>([]);
  const [scanProgress, setScanProgress]     = useState(0);
  const [overallScore, setOverallScore]     = useState<number | null>(null);
  const [behaviorProfile, setBehaviorProfile] = useState<string[]>([]);
  const [cameraError, setCameraError]       = useState<string | null>(null);
  const [activeBtn, setActiveBtn]           = useState<number | null>(null);
  const [distressOpen, setDistressOpen]     = useState(false);
  const [showContact, setShowContact]       = useState(false);
  const [parentName, setParentName]         = useState('');
  const [parentPhone, setParentPhone]       = useState('');
  const [contactSaved, setContactSaved]     = useState(false);
  const [showCalmerBtn, setShowCalmerBtn]   = useState(false);

  const EMOTION_COLORS: Record<string, string> = {
    'Neutral':    '#64748b',
    'Happy':      '#4ade80',
    'Sad':        '#60a5fa',
    'Anxious':    '#fbbf24',
    'Focused':    '#a78bfa',
    'Avoidant':   '#f87171',
    'Engaged':    '#34d399',
    'Stimming':   '#fb923c',
  };

  const CHILD_BUTTONS = [
    { emoji: '🍎', label: 'Hungry',   bg: 'rgba(234,179,8,0.15)',   border: 'rgba(234,179,8,0.3)',   say: 'I am hungry. Mama, can you bring me something to eat please?',  wa: '💜 Your child is hungry. Please bring food. — Aippie Care' },
    { emoji: '💧', label: 'Thirsty',  bg: 'rgba(59,130,246,0.15)',  border: 'rgba(59,130,246,0.3)',  say: 'I am thirsty. Can I please have something to drink?',            wa: '💜 Your child is thirsty. Please bring a drink. — Aippie Care' },
    { emoji: '🤗', label: 'Hug',      bg: 'rgba(236,72,153,0.15)',  border: 'rgba(236,72,153,0.3)',  say: 'I need a hug. Mama, can you please come to me?',                 wa: '💜 Your child needs a hug. Please come. — Aippie Care' },
    { emoji: '😴', label: 'Tired',    bg: 'rgba(99,102,241,0.15)',  border: 'rgba(99,102,241,0.3)',  say: 'I am tired. I want to rest now.',                                wa: '💜 Your child is tired and wants to rest. — Aippie Care' },
    { emoji: '🤫', label: 'Too loud', bg: 'rgba(167,139,250,0.15)', border: 'rgba(167,139,250,0.3)', say: 'It is too loud. I need quiet please.',                           wa: '💜 Your child needs a quieter environment. — Aippie Care' },
    { emoji: '❤️', label: 'Love',     bg: 'rgba(239,68,68,0.15)',   border: 'rgba(239,68,68,0.3)',   say: 'I love you mama.',                                               wa: '💜 Your child says: I love you. — Aippie Care' },
    { emoji: '😊', label: 'Happy',    bg: 'rgba(34,197,94,0.15)',   border: 'rgba(34,197,94,0.3)',   say: 'I am happy right now.',                                          wa: '💜 Your child is happy right now! — Aippie Care' },
    { emoji: '😢', label: 'Sad',      bg: 'rgba(96,165,250,0.15)',  border: 'rgba(96,165,250,0.3)',  say: 'I am sad. I need help please.',                                  wa: '💜 Your child is sad and needs you. — Aippie Care' },
    { emoji: '🚽', label: 'Bathroom', bg: 'rgba(245,158,11,0.15)',  border: 'rgba(245,158,11,0.3)',  say: 'I need to go to the bathroom.',                                  wa: '💜 Your child needs the bathroom. — Aippie Care' },
  ];

  const TIPS = [
    'Try a calm, low-stimulation environment today',
    'Visual schedules can help reduce anxiety',
    'Celebrate small wins — every step matters 💜',
    'Deep pressure activities may help with stimming',
    'Routine and predictability build confidence',
    'You are doing an amazing job as a caregiver 💜',
    'Short breaks every 20 minutes help regulate emotions',
    'Soft music or white noise can reduce sensory overload',
  ];

  const dailyTips = TIPS.slice(0, 3);

  useEffect(() => {
    const saved = localStorage.getItem('autism_parent_contact');
    if (saved) {
      try {
        const p = JSON.parse(saved);
        setParentName(p.name ?? '');
        setParentPhone(p.phone ?? '');
        setContactSaved(true);
      } catch { /* ignore */ }
    }
  }, []);

  const BEHAVIOR_PROFILES = [
    'Reduced eye contact patterns detected',
    'Repetitive micro-expression cycles observed',
    'Heightened sensory sensitivity indicators',
    'Strong focus/hyper-attention signals',
    'Social communication pattern variations',
    'Self-regulatory behavioral markers present',
    'Emotional processing delay signatures',
    'Executive function pattern analysis complete',
  ];

  const startScan = async () => {
    setCameraError(null);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'user', width: 320, height: 240 } });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        await videoRef.current.play();
      }
      setPhase('scanning');
      setScanProgress(0);
      setExpressions([]);
      setOverallScore(null);
      setBehaviorProfile([]);

      let progress = 0;
      scanTimerRef.current = setInterval(() => {
        progress += 2;
        setScanProgress(progress);

        const emotions = Object.keys(EMOTION_COLORS);
        const emotion  = emotions[Math.floor(Math.random() * emotions.length)];
        const conf     = Math.round(55 + Math.random() * 40);
        setExpressions(prev => [{
          emotion, confidence: conf, timestamp: Date.now(), color: EMOTION_COLORS[emotion],
        }, ...prev].slice(0, 12));

        if (progress >= 100) {
          if (scanTimerRef.current) clearInterval(scanTimerRef.current);
          setPhase('analysis');
          setTimeout(() => {
            const score = Math.round(62 + Math.random() * 28);
            setOverallScore(score);
            const picked = [...BEHAVIOR_PROFILES].sort(() => Math.random() - 0.5).slice(0, 4);
            setBehaviorProfile(picked);
            setPhase('result');
            stopCamera();
          }, 2200);
        }
      }, 80);
    } catch (err) {
      setCameraError('Camera toegang vereist. Sta camera-toegang toe in uw browser.');
      setPhase('idle');
    }
  };

  const stopCamera = () => {
    if (scanTimerRef.current) clearInterval(scanTimerRef.current);
    streamRef.current?.getTracks().forEach(t => t.stop());
    streamRef.current = null;
  };

  const reset = () => {
    stopCamera();
    setPhase('idle');
    setExpressions([]);
    setScanProgress(0);
    setOverallScore(null);
    setBehaviorProfile([]);
    setCameraError(null);
  };

  useEffect(() => () => stopCamera(), []);

  return (
    <div style={{ padding: '16px', background: '#060c1a', color: '#e2e8f0', fontFamily: "'Inter', sans-serif", minHeight: 'calc(100vh - 120px)' }}>

      {/* Warm emotional header */}
      <div style={{ marginBottom: 20 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 10 }}>
          <div style={{ width: 36, height: 36, borderRadius: 10, background: 'rgba(167,139,250,0.15)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
            <Brain size={18} style={{ color: '#a78bfa' }} />
          </div>
          <div>
            <div style={{ fontSize: 20, fontWeight: 700, color: '#a78bfa', lineHeight: 1.2 }}>Autism Care</div>
            <div style={{ fontSize: 15, color: '#cbd5e1', marginTop: 2 }}>AI Behavioral &amp; Micro-Expression Analysis</div>
          </div>
        </div>
        <p style={{ fontSize: 14, color: '#94a3b8', lineHeight: 1.7, margin: '0 0 10px' }}>
          This tool was built with love — for families with non-verbal children and those on the autism spectrum.
          AI micro-expression analysis to help you better understand your child's emotional world.
        </p>
        <div style={{ background: 'rgba(167,139,250,0.06)', border: '1px solid rgba(167,139,250,0.15)', borderRadius: 8, padding: '8px 12px', fontSize: 13, color: '#64748b', lineHeight: 1.6 }}>
          Built with care · AI simulation only · Not a medical diagnosis · Always consult a specialist
        </div>
      </div>

      {/* ── Your Voice pictogram buttons ── */}
      <style>{`
        @keyframes pulse-red { 0%,100% { box-shadow: 0 0 0 0 rgba(220,38,38,0.5); } 50% { box-shadow: 0 0 0 10px rgba(220,38,38,0); } }
        @keyframes breathe { 0%,100% { transform: scale(1); opacity: 0.5; } 50% { transform: scale(1.5); opacity: 1; } }
        @keyframes pulse-purple { 0%,100% { transform: scale(1); } 50% { transform: scale(1.1); } }
      `}</style>
      <div style={{ marginBottom: 20 }}>
        <div style={{ fontSize: 16, color: '#a78bfa', fontWeight: 700, marginBottom: 4 }}>Your Voice</div>
        <div style={{ fontSize: 13, color: '#64748b', marginBottom: 16 }}>Press a picture — I will speak for you</div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 10, marginBottom: 20 }}>
          {CHILD_BUTTONS.map((btn, i) => (
            <button
              key={i}
              onClick={() => {
                speak(btn.say);
                setActiveBtn(i);
                setTimeout(() => setActiveBtn(null), 1500);
                const p = (() => { try { return JSON.parse(localStorage.getItem('autism_parent_contact') || 'null'); } catch { return null; } })();
                if (p?.phone) window.open(`https://wa.me/${p.phone}?text=${encodeURIComponent(btn.wa)}`, '_blank');
              }}
              style={{
                height: 90, borderRadius: 16,
                display: 'flex', flexDirection: 'column',
                alignItems: 'center', justifyContent: 'center',
                cursor: 'pointer', border: `1px solid ${btn.border}`,
                background: btn.bg,
                transition: 'all 0.15s',
                ...(activeBtn === i ? { border: '2px solid #a78bfa', boxShadow: '0 0 16px rgba(167,139,250,0.5)', transform: 'scale(1.05)' } : {}),
              }}
            >
              <span style={{ fontSize: 28, lineHeight: 1 }}>{btn.emoji}</span>
              <span style={{ fontSize: 11, color: '#94a3b8', marginTop: 6, fontWeight: 600 }}>{btn.label}</span>
            </button>
          ))}
        </div>

        {/* Distress button */}
        <button
          onClick={() => {
            speak('I see you need help. Everything is okay. Take a deep breath. You are safe. Mama is coming to help you.');
            setDistressOpen(true);
            setTimeout(() => setShowCalmerBtn(true), 5000);
            const p = (() => { try { return JSON.parse(localStorage.getItem('autism_parent_contact') || 'null'); } catch { return null; } })();
            if (p?.phone) window.open(`https://wa.me/${p.phone}?text=${encodeURIComponent('🚨 URGENT — Your child needs you RIGHT NOW. Aippie Autism Care detected distress. Please go to your child immediately. — Aippie Care 💜')}`, '_blank');
          }}
          style={{
            width: '100%', height: 64,
            background: 'linear-gradient(135deg, #dc2626, #ef4444)',
            borderRadius: 14, fontSize: 17, fontWeight: 800,
            color: 'white', border: 'none', cursor: 'pointer',
            animation: 'pulse-red 2s infinite',
          }}
        >
          🚨 I Need Help Right Now
        </button>
      </div>

      {/* Camera + controls — full-width on mobile, 2-col on desktop */}
      <div style={{ display: 'grid', gridTemplateColumns: window.innerWidth < 600 ? '1fr' : '1fr 1fr', gap: 14, marginBottom: 14 }}>
        {/* Camera feed */}
        <div style={{ background: '#0a0f1e', border: '1px solid rgba(167,139,250,0.12)', borderRadius: 12, overflow: 'hidden', minHeight: 200, position: 'relative', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <video ref={videoRef} style={{ width: '100%', height: '100%', objectFit: 'cover', display: phase === 'scanning' ? 'block' : 'none', minHeight: 200 }} muted playsInline />
          <canvas ref={canvasRef} style={{ display: 'none' }} />
          {phase === 'idle' && (
            <div style={{ textAlign: 'center', padding: 20 }}>
              <Camera size={28} style={{ color: '#a78bfa', display: 'block', margin: '0 auto 10px' }} />
              <div style={{ fontSize: 13, color: '#64748b' }}>Camera feed</div>
            </div>
          )}
          {(phase === 'analysis' || phase === 'result') && (
            <div style={{ textAlign: 'center', padding: 20 }}>
              <CheckCircle2 size={28} style={{ color: '#4ade80', display: 'block', margin: '0 auto 10px' }} />
              <div style={{ fontSize: 13, color: '#4ade80' }}>Scan complete</div>
            </div>
          )}
          {phase === 'scanning' && (
            <div style={{ position: 'absolute', inset: 0, border: '2px solid rgba(167,139,250,0.4)', borderRadius: 12, pointerEvents: 'none' }}>
              <div style={{ position: 'absolute', top: 8, left: 8, width: 14, height: 14, borderTop: '2px solid #a78bfa', borderLeft: '2px solid #a78bfa', borderRadius: '2px 0 0 0' }} />
              <div style={{ position: 'absolute', top: 8, right: 8, width: 14, height: 14, borderTop: '2px solid #a78bfa', borderRight: '2px solid #a78bfa', borderRadius: '0 2px 0 0' }} />
              <div style={{ position: 'absolute', bottom: 8, left: 8, width: 14, height: 14, borderBottom: '2px solid #a78bfa', borderLeft: '2px solid #a78bfa', borderRadius: '0 0 0 2px' }} />
              <div style={{ position: 'absolute', bottom: 8, right: 8, width: 14, height: 14, borderBottom: '2px solid #a78bfa', borderRight: '2px solid #a78bfa', borderRadius: '0 0 2px 0' }} />
            </div>
          )}
        </div>

        {/* Controls */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
          {cameraError && (
            <div style={{ background: 'rgba(248,113,113,0.08)', border: '1px solid rgba(248,113,113,0.2)', borderRadius: 8, padding: '10px 12px', fontSize: 13, color: '#f87171', lineHeight: 1.5 }}>
              {cameraError}
            </div>
          )}
          {phase === 'idle' && (
            <button onClick={startScan} style={{ height: 52, background: 'linear-gradient(135deg, #7c3aed, #a78bfa)', border: 'none', borderRadius: 10, color: '#fff', fontSize: 16, fontWeight: 700, cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8, width: '100%' }}>
              <Camera size={16} /> Begin Scan
            </button>
          )}
          {phase === 'scanning' && (
            <>
              <div style={{ fontSize: 13, color: '#a78bfa', fontWeight: 600 }}>Scanning micro-expressions… {scanProgress}%</div>
              <div style={{ height: 8, background: '#0f172a', borderRadius: 99, overflow: 'hidden' }}>
                <div style={{ height: '100%', background: 'linear-gradient(90deg, #7c3aed, #a78bfa)', borderRadius: 99, width: `${scanProgress}%`, transition: 'width 0.1s linear' }} />
              </div>
              <button onClick={reset} style={{ padding: '10px 0', background: 'rgba(248,113,113,0.1)', border: '1px solid rgba(248,113,113,0.2)', borderRadius: 8, color: '#f87171', fontSize: 13, cursor: 'pointer' }}>
                Stop Scan
              </button>
            </>
          )}
          {phase === 'analysis' && (
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, color: '#a78bfa', fontSize: 13 }}>
              <RefreshCw size={14} style={{ animation: 'spin 1s linear infinite' }} /> Analyzing behavioral patterns…
            </div>
          )}
          {phase === 'result' && overallScore !== null && (
            <>
              <div style={{ background: 'rgba(167,139,250,0.08)', border: '1px solid rgba(167,139,250,0.2)', borderRadius: 12, padding: '16px', textAlign: 'center' }}>
                <div style={{ fontSize: 36, fontWeight: 800, color: '#a78bfa' }}>{overallScore}</div>
                <div style={{ fontSize: 13, color: '#64748b', marginTop: 4 }}>Behavioral Pattern Index</div>
              </div>
              <button onClick={reset} style={{ padding: '10px 0', background: 'rgba(167,139,250,0.1)', border: '1px solid rgba(167,139,250,0.2)', borderRadius: 8, color: '#a78bfa', fontSize: 13, cursor: 'pointer' }}>
                <RotateCcw size={12} style={{ display: 'inline', marginRight: 6 }} /> New Scan
              </button>
            </>
          )}
        </div>
      </div>

      {/* Live micro-expression feed */}
      {expressions.length > 0 && (
        <div style={{ marginBottom: 14 }}>
          <div style={{ fontSize: 13, color: '#64748b', fontWeight: 600, marginBottom: 8, textTransform: 'uppercase', letterSpacing: '0.08em' }}>Live Expression Feed</div>
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: 7 }}>
            {expressions.slice(0, 8).map((e, i) => (
              <div key={i} style={{ background: `${e.color}15`, border: `1px solid ${e.color}40`, borderRadius: 20, padding: '4px 12px', fontSize: 13, color: e.color, display: 'flex', alignItems: 'center', gap: 5 }}>
                {e.emotion} <span style={{ color: '#475569' }}>{e.confidence}%</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Behavior profile results */}
      {phase === 'result' && behaviorProfile.length > 0 && (
        <div style={{ marginBottom: 14 }}>
          <div style={{ fontSize: 13, color: '#64748b', fontWeight: 600, marginBottom: 8, textTransform: 'uppercase', letterSpacing: '0.08em' }}>Behavioral Profile Indicators</div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            {behaviorProfile.map((item, i) => (
              <div key={i} style={{ display: 'flex', alignItems: 'flex-start', gap: 10, background: 'rgba(167,139,250,0.05)', border: '1px solid rgba(167,139,250,0.1)', borderRadius: 8, padding: '10px 14px' }}>
                <CheckCircle2 size={13} style={{ color: '#a78bfa', flexShrink: 0, marginTop: 1 }} />
                <span style={{ fontSize: 14, color: '#cbd5e1', lineHeight: 1.5 }}>{item}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tips for today — show after scan result */}
      {phase === 'result' && (
        <div style={{ marginBottom: 16, background: 'rgba(167,139,250,0.06)', border: '1px solid rgba(167,139,250,0.15)', borderRadius: 12, padding: '14px 16px' }}>
          <div style={{ fontSize: 14, color: '#a78bfa', fontWeight: 700, marginBottom: 12 }}>💜 Tips for today</div>
          {dailyTips.map((tip, i) => (
            <div key={i} style={{ display: 'flex', alignItems: 'flex-start', gap: 8, borderLeft: '3px solid #a78bfa', paddingLeft: 12, marginBottom: 10 }}>
              <span style={{ fontSize: 14, color: '#cbd5e1', lineHeight: 1.7 }}>{tip}</span>
            </div>
          ))}
        </div>
      )}

      {/* Parent contact */}
      <div style={{ marginBottom: 14 }}>
        <div style={{ display: 'flex', justifyContent: 'flex-end' }}>
          <button
            onClick={() => setShowContact(v => !v)}
            style={{ fontSize: 11, color: '#a78bfa', background: 'rgba(167,139,250,0.08)', border: '1px solid rgba(167,139,250,0.2)', borderRadius: 8, padding: '5px 10px', cursor: 'pointer', fontWeight: 600 }}
          >
            👨‍👩‍👧 Parent Contact
          </button>
        </div>
        {showContact && (
          <div style={{ marginTop: 10, background: 'rgba(167,139,250,0.06)', border: '1px solid rgba(167,139,250,0.15)', borderRadius: 10, padding: 14 }}>
            {contactSaved && (
              <div style={{ fontSize: 12, color: '#4ade80', marginBottom: 10, display: 'flex', alignItems: 'center', gap: 6 }}>
                <CheckCircle2 size={12} color="#4ade80" /> Contact saved: {parentName}
              </div>
            )}
            <input
              type="text"
              placeholder="Parent name"
              value={parentName}
              onChange={e => setParentName(e.target.value)}
              style={{ width: '100%', background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(167,139,250,0.2)', borderRadius: 8, color: '#e2e8f0', fontSize: 13, padding: '8px 12px', marginBottom: 8, boxSizing: 'border-box' }}
            />
            <input
              type="tel"
              placeholder="+34 600 000 000"
              value={parentPhone}
              onChange={e => setParentPhone(e.target.value)}
              style={{ width: '100%', background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(167,139,250,0.2)', borderRadius: 8, color: '#e2e8f0', fontSize: 13, padding: '8px 12px', marginBottom: 10, boxSizing: 'border-box' }}
            />
            <button
              onClick={() => {
                localStorage.setItem('autism_parent_contact', JSON.stringify({ name: parentName, phone: parentPhone }));
                setContactSaved(true);
              }}
              style={{ background: 'linear-gradient(135deg, #7c3aed, #a78bfa)', border: 'none', borderRadius: 8, color: '#fff', fontSize: 13, fontWeight: 700, padding: '8px 18px', cursor: 'pointer' }}
            >
              Save Contact
            </button>
          </div>
        )}
      </div>

      {/* Distress calming overlay */}
      {distressOpen && (
        <div style={{ position: 'fixed', inset: 0, zIndex: 99999, background: 'linear-gradient(135deg, #1e1b4b, #312e81)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexDirection: 'column' }}>
          <span style={{ fontSize: 96, animation: 'pulse-purple 2s infinite' }}>❤️</span>
          <div style={{ color: '#ffffff', fontSize: 40, fontWeight: 800, marginTop: 20, letterSpacing: '0.04em' }}>YOU ARE SAFE</div>
          <div style={{ color: '#a78bfa', fontSize: 20, marginTop: 8 }}>💜 Help is coming</div>
          <div style={{ width: 80, height: 80, borderRadius: '50%', border: '3px solid #a78bfa', animation: 'breathe 4s ease-in-out infinite', display: 'flex', alignItems: 'center', justifyContent: 'center', marginTop: 32 }}>
            <span style={{ fontSize: 12, color: '#a78bfa', fontWeight: 600 }}>breathe</span>
          </div>
          {showCalmerBtn && (
            <button
              onClick={() => { setDistressOpen(false); setShowCalmerBtn(false); }}
              style={{ marginTop: 32, background: 'rgba(167,139,250,0.2)', border: '2px solid #a78bfa', borderRadius: 14, color: '#a78bfa', fontSize: 16, fontWeight: 700, padding: '12px 28px', cursor: 'pointer' }}
            >
              I feel better 💜
            </button>
          )}
        </div>
      )}

      {/* Bottom disclaimer */}
      <div style={{ paddingTop: 12, borderTop: '1px solid rgba(100,116,139,0.1)', fontSize: 13, color: '#334155', display: 'flex', alignItems: 'flex-start', gap: 6, lineHeight: 1.5 }}>
        <Brain size={10} style={{ color: '#475569', flexShrink: 0, marginTop: 2 }} />
        Built with care for families · AI simulation only · Not a medical diagnosis · Always consult a certified specialist · AIPPIETAX S.A.
      </div>
    </div>
  );
}

// ── Main component ─────────────────────────────────────────────────────────────
export default function AippieDoctorView() {
  const { user } = useAuth();
  const DEV_EMAILS = ['elvin@aippietax.com', 'aippieai@gmail.com'];
  const isSubscribed =
    DEV_EMAILS.includes(user?.email ?? '') ||
    user?.user_metadata?.is_subscribed === true ||
    user?.user_metadata?.subscription_type === 'lifetime' ||
    user?.user_metadata?.subscription_type === 'annual';

  const [activeTab,  setActiveTab]  = useState<DocTab>('vitals');

  // ── PPG state
  const [phase,       setPhase]       = useState<ScanPhase>('idle');
  const [progress,    setProgress]    = useState(0);
  const [vitals,      setVitals]      = useState<Vitals | null>(null);
  const [savedMsg,    setSavedMsg]    = useState('');
  const [disclaimerDone, setDisclaimerDone] = useState(false);

  // ── Skin analysis state
  const [skinPhase,   setSkinPhase]   = useState<'idle' | 'live' | 'captured' | 'analyzing' | 'done' | 'error'>('idle');
  const [skinReport,  setSkinReport]  = useState<SkinReport | null>(null);

  // ── Geolocation state
  const [geoState,    setGeoState]    = useState<'idle' | 'loading' | 'done' | 'error'>('idle');
  const [carePlaces,  setCarePlaces]  = useState<CarePlace[]>([]);
  const [geoError,    setGeoError]    = useState('');

  // ── Consultation state
  const [cardInput,          setCardInput]          = useState('');
  const [isConsultationPaid, setIsConsultationPaid] = useState(false);
  const [payPhase,           setPayPhase]           = useState<'idle' | 'processing' | 'success' | 'error'>('idle');
  const [consultCamFacing,   setConsultCamFacing]   = useState<'user' | 'environment'>('user');
  const [consultStream,      setConsultStream]      = useState<MediaStream | null>(null);
  const consultVideoRef = useRef<HTMLVideoElement>(null);

  // ── Earnings state (V135)
  const [payments,    setPayments]    = useState<PaymentRow[]>([]);
  const [payouts,     setPayouts]     = useState<PayoutRow[]>([]);
  const [earnLoading, setEarnLoading] = useState(false);
  const [ibanInput,   setIbanInput]   = useState('');
  const [payoutPhase, setPayoutPhase] = useState<'idle' | 'processing' | 'success' | 'error'>('idle');
  const [payoutMsg,   setPayoutMsg]   = useState('');
  const [copiedInv,   setCopiedInv]   = useState<string | null>(null);

  // ── Avatar speech state
  const [speaking,    setSpeaking]    = useState(false);
  const [speechText,  setSpeechText]  = useState(DISCLAIMER_V101);

  // ── Heart-Attack Early Warning state (V184)
  const [alertPhase,   setAlertPhase]   = useState<AlertPhase>('monitoring');
  const [bioValues,    setBioValues]    = useState({ hrv: 58, spo2: 98, gps: 1 });
  const [dispatchLogs, setDispatchLogs] = useState<string[]>([]);
  const [alertActive,  setAlertActive]  = useState(false);
  const alertTimerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  // ── Smart Band state (V186)
  const [bandMode,       setBandMode]       = useState<BandInputMode>('camera');
  const [bandColor,      setBandColor]      = useState<BandColor>('black');
  const [bandConnPhase,  setBandConnPhase]  = useState<BandConnPhase>('idle');
  const [btLogs,         setBtLogs]         = useState<string[]>([]);
  const [streamValues,   setStreamValues]   = useState(BT_STREAM_METRICS.map(m => m.base));
  const [bandOrderPhase, setBandOrderPhase] = useState<BandOrderPhase>('idle');
  const [bandCardInput,  setBandCardInput]  = useState('');
  const [bandCardErr,    setBandCardErr]    = useState('');
  const streamTimerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  // ── Elysium Diagnostic Panel state (V194) ────────────────────────────────────
  const [elysiumScanPhase,  setElysiumScanPhase]  = useState<ElysiumScanPhase>('idle');
  const [elysiumTrack1,     setElysiumTrack1]     = useState<ElysiumTrackState>('initializing');
  const [elysiumTrack2,     setElysiumTrack2]     = useState<ElysiumTrackState>('initializing');
  const [elysiumTrack3,     setElysiumTrack3]     = useState<ElysiumTrackState>('initializing');
  const [bodyCoords,        setBodyCoords]        = useState<BodyCoord[]>([]);
  const [ppgWave,           setPpgWave]           = useState<PpgSample[]>([]);
  const [symptomInput,      setSymptomInput]      = useState('');
  const [symptomResponse,   setSymptomResponse]   = useState('');
  const [symptomProcessing, setSymptomProcessing] = useState(false);
  const [elysiumHR,         setElysiumHR]         = useState(74);
  const [elysiumHRV,        setElysiumHRV]        = useState(58);
  const [elysiumSpO2,       setElysiumSpO2]       = useState(98);
  const [criticalTriggered, setCriticalTriggered] = useState(false);
  const elysiumTimerRef  = useRef<ReturnType<typeof setInterval> | null>(null);
  const ppgTimerRef      = useRef<ReturnType<typeof setInterval> | null>(null);

  const subtitle = useSubtitle(speechText, speaking);

  const videoRef         = useRef<HTMLVideoElement>(null);
  const skinVideoRef     = useRef<HTMLVideoElement>(null);
  const canvasRef        = useRef<HTMLCanvasElement>(null);
  const skinCanvasRef    = useRef<HTMLCanvasElement>(null);
  const streamRef        = useRef<MediaStream | null>(null);
  const skinStreamRef    = useRef<MediaStream | null>(null);
  const samplesRef       = useRef<number[]>([]);
  const sampleTimerRef   = useRef<ReturnType<typeof setInterval> | null>(null);
  const progressTimerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const cancelledRef     = useRef(false);

  const deviceKey = useRef(
    localStorage.getItem('aippie_device_key') ??
    (() => { const k = crypto.randomUUID(); localStorage.setItem('aippie_device_key', k); return k; })()
  );

  // ── TTS speak helper ──────────────────────────────────────────────────────
  const speak = useCallback((text: string, onEnd?: () => void) => {
    if (!('speechSynthesis' in window)) { onEnd?.(); return; }
    cancelledRef.current = true;
    window.speechSynthesis.cancel();
    cancelledRef.current = false;
    setSpeechText(text);
    setSpeaking(true);
    withVoicesReady(() => {
      if (cancelledRef.current) return;
      const u = new SpeechSynthesisUtterance(text);
      u.rate  = SPEECH_RATE;
      u.pitch = SPEECH_PITCH;
      applyPremiumVoice(u);
      u.onend   = () => { setSpeaking(false); if (!cancelledRef.current) onEnd?.(); };
      u.onerror = () => { setSpeaking(false); if (!cancelledRef.current) onEnd?.(); };
      window.speechSynthesis.speak(u);
    });
  }, []);

  // ── Heart-Attack: simulate critical biometric drop + 112 dispatch ────────────
  const triggerCriticalAlert = useCallback(() => {
    if (alertActive) return;
    setAlertActive(true);
    setAlertPhase('warning');
    setBioValues({ hrv: 28, spo2: 93, gps: 1 });

    speak('Warning. Critical cardiac biometrics detected. HRV is dropping to a dangerous level. Emergency protocol is being initialized.', () => {
      setAlertPhase('critical');
      setBioValues({ hrv: 18, spo2: 88, gps: 1 });

      speak('CRITICAL ALERT. HRV below twenty-two milliseconds. SpO2 below ninety percent. Automatic emergency dispatch to emergency services is being activated.', () => {
        setAlertPhase('dispatching');
        setDispatchLogs([]);

        DISPATCH_STEPS.forEach((step, i) => {
          setTimeout(() => {
            setDispatchLogs(prev => [...prev, step]);
            if (i === DISPATCH_STEPS.length - 1) {
              setAlertPhase('dispatched');
              speak('Ambulance en route. Estimated arrival six minutes. Cardiac monitoring active. Patient data has been transmitted to the hospital.');
            }
          }, (i + 1) * 900);
        });
      });
    });
  }, [alertActive, speak]);

  const resetAlert = useCallback(() => {
    if (alertTimerRef.current) { clearInterval(alertTimerRef.current); alertTimerRef.current = null; }
    setAlertActive(false);
    setAlertPhase('monitoring');
    setBioValues({ hrv: 58, spo2: 98, gps: 1 });
    setDispatchLogs([]);
  }, []);

  // Slowly oscillate biometric values while monitoring to simulate live feed
  useEffect(() => {
    if (activeTab !== 'heartAlert' || alertActive) return;
    alertTimerRef.current = setInterval(() => {
      setBioValues(prev => ({
        hrv:  Math.max(40, Math.min(72, prev.hrv  + (Math.random() - 0.5) * 4)),
        spo2: Math.max(95, Math.min(100, prev.spo2 + (Math.random() - 0.5) * 1)),
        gps:  1,
      }));
    }, 820);
    return () => { if (alertTimerRef.current) clearInterval(alertTimerRef.current); };
  }, [activeTab, alertActive]);

  // Speak context message when navigating to heart-alert tab
  useEffect(() => {
    if (activeTab === 'heartAlert') {
      speak('AI Cardiac Early Warning System active. All biometric sensors operational. HRV and SpO2 are being monitored. GPS dispatcher ready.');
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [activeTab === 'heartAlert']);

  // ── Smart Band: simulate Bluetooth pairing sequence ──────────────────────────
  const startBtConnect = useCallback(() => {
    if (bandConnPhase !== 'idle') return;
    setBandConnPhase('scanning');
    setBtLogs([]);
    BT_STEPS.forEach((step, i) => {
      setTimeout(() => {
        setBtLogs(prev => [...prev, step]);
        if (i === 2) setBandConnPhase('pairing');
        if (i === 3) setBandConnPhase('connected');
        if (i === BT_STEPS.length - 1) {
          setBandConnPhase('streaming');
          speak('Aippie Smart Band connected. Green LED array active. Heart telemetry streaming live.');
        }
      }, (i + 1) * 800);
    });
  }, [bandConnPhase, speak]);

  const disconnectBand = useCallback(() => {
    if (streamTimerRef.current) { clearInterval(streamTimerRef.current); streamTimerRef.current = null; }
    setBandConnPhase('idle');
    setBtLogs([]);
    setStreamValues(BT_STREAM_METRICS.map(m => m.base));
  }, []);

  // Live stream: oscillate metric values while connected
  useEffect(() => {
    if (bandConnPhase !== 'streaming') { if (streamTimerRef.current) { clearInterval(streamTimerRef.current); streamTimerRef.current = null; } return; }
    streamTimerRef.current = setInterval(() => {
      setStreamValues(prev => prev.map((v, i) => {
        const m = BT_STREAM_METRICS[i];
        return parseFloat(Math.max(m.base - m.delta * 2, Math.min(m.base + m.delta * 2, v + (Math.random() - 0.5) * m.delta)).toFixed(1));
      }));
    }, 820);
    return () => { if (streamTimerRef.current) clearInterval(streamTimerRef.current); };
  }, [bandConnPhase]);

  const handleBandOrder = useCallback(() => {
    const digits = bandCardInput.replace(/\s/g, '');
    if (digits.length !== 16) { setBandCardErr('Please enter a valid 16-digit card number.'); return; }
    setBandCardErr('');
    setBandOrderPhase('processing');
    speak(`Order placed. Aippie Smart Band in ${BAND_COLORS.find(c => c.id === bandColor)?.label} is being shipped. Hardware activation forty-five Euros. Monthly nine ninety-nine for Lifeline monitoring. Thank you.`);
    setTimeout(() => setBandOrderPhase('confirmed'), 2800);
  }, [bandCardInput, bandColor, speak]);

  // Speak context on Smart Band tab navigation
  useEffect(() => {
    if (activeTab === 'smartBand') {
      speak('Aippie Smart Band module loaded. Select Phone Camera or Bluetooth to measure biometrics. Order your band in your preferred color.');
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [activeTab === 'smartBand']);

  // ── Elysium: start combined diagnostic scan ───────────────────────────────────
  const startElysiumScan = useCallback(() => {
    if (elysiumScanPhase === 'scanning' || elysiumScanPhase === 'active') return;
    setElysiumScanPhase('scanning');
    setCriticalTriggered(false);
    setSymptomResponse('');
    setBodyCoords([]);
    setPpgWave([]);

    // Track 1: 3D body contour — populate landmarks gradually
    setTimeout(() => {
      setElysiumTrack1('active');
      const coords: BodyCoord[] = BODY_LANDMARKS.map(l => ({
        ...l,
        risk: Math.random() > 0.88 ? 'warn' : 'ok',
      }));
      setBodyCoords(coords);
    }, 800);

    // Track 2: PPG waveform — start oscillation
    setTimeout(() => {
      setElysiumTrack2('active');
      let tick = 0;
      ppgTimerRef.current = setInterval(() => {
        tick++;
        setPpgWave(prev => {
          const hr  = elysiumHR + (Math.random() - 0.5) * 3;
          const period = (60 / hr) * PPG_WAVEFORM_POINTS;
          const phase  = (tick % period) / period;
          const sample = Math.sin(phase * Math.PI * 2) * 0.5
            + Math.sin(phase * Math.PI * 4) * 0.15
            + (Math.random() - 0.5) * 0.04;
          const next = [...prev, { t: tick, value: sample }];
          return next.length > PPG_WAVEFORM_POINTS ? next.slice(-PPG_WAVEFORM_POINTS) : next;
        });
        setElysiumHR(v  => parseFloat((Math.max(55, Math.min(100, v + (Math.random() - 0.5) * 1.5))).toFixed(0)));
        setElysiumHRV(v => parseFloat((Math.max(18, Math.min(90,  v + (Math.random() - 0.5) * 2))).toFixed(0)));
        setElysiumSpO2(v=> parseFloat((Math.max(90, Math.min(100, v + (Math.random() - 0.5) * 0.4))).toFixed(1)));
      }, 120);
    }, 1400);

    // Track 3: Clinical AI — ready
    setTimeout(() => {
      setElysiumTrack3('active');
      setElysiumScanPhase('active');
      speak('Elysium Diagnostic Simulation Panel activated. Three layers are active: 3D body contour scan, continuous HRV stream, and clinical AI matrix. Enter your symptoms for immediate analysis.');
    }, 2200);
  }, [elysiumScanPhase, elysiumHR, speak]);

  const stopElysiumScan = useCallback(() => {
    if (ppgTimerRef.current)     { clearInterval(ppgTimerRef.current);     ppgTimerRef.current = null; }
    if (elysiumTimerRef.current) { clearInterval(elysiumTimerRef.current); elysiumTimerRef.current = null; }
    setElysiumScanPhase('idle');
    setElysiumTrack1('initializing');
    setElysiumTrack2('initializing');
    setElysiumTrack3('initializing');
    setBodyCoords([]);
    setPpgWave([]);
    setCriticalTriggered(false);
  }, []);

  // Elysium: process symptom text input through clinical AI layer
  const analyseSymptom = useCallback(() => {
    if (!symptomInput.trim() || symptomProcessing) return;
    setSymptomProcessing(true);
    setSymptomResponse('');

    const lower = symptomInput.toLowerCase();
    const isCritical = ELYSIUM_CRITICAL_TRIGGER_WORDS.some(w => lower.includes(w));

    setTimeout(() => {
      const key = Object.keys(SYMPTOM_RESPONSES).find(k => lower.includes(k));
      const response = key
        ? SYMPTOM_RESPONSES[key]
        : `Symptom analysis complete for input: "${symptomInput}". No immediate critical pattern detected. Monitor your symptoms and consult your doctor if complaints persist or worsen.`;
      setSymptomResponse(response);
      setSymptomProcessing(false);
      speak(response);

      if (isCritical) {
        setTimeout(() => {
          setCriticalTriggered(true);
          setElysiumTrack1('anomaly');
          setElysiumTrack2('anomaly');
          setElysiumTrack3('anomaly');
          setElysiumScanPhase('anomaly');
          speak('WARNING. Critical symptom indicators detected. I am automatically switching to Emergency Response and Specialist Consult Dashboard.', () => {
            setActiveTab('heartAlert');
          });
        }, 1800);
      }
    }, 1200);
  }, [symptomInput, symptomProcessing, speak, setActiveTab]);

  // Elysium: cleanup on unmount
  useEffect(() => {
    return () => {
      if (ppgTimerRef.current)     clearInterval(ppgTimerRef.current);
      if (elysiumTimerRef.current) clearInterval(elysiumTimerRef.current);
    };
  }, []);

  // Elysium: critical HRV or SpO2 auto-escalates
  useEffect(() => {
    if (activeTab !== 'elysium' || criticalTriggered) return;
    if (elysiumHRV < 22 || elysiumSpO2 < 90) {
      setCriticalTriggered(true);
      setElysiumScanPhase('anomaly');
      speak('Critical biometrics detected. HRV or SpO2 threshold exceeded. Auto-switching to Emergency Dispatch.', () => {
        setActiveTab('heartAlert');
      });
    }
  }, [elysiumHRV, elysiumSpO2, activeTab, criticalTriggered, speak, setActiveTab]);

  // Auto-speak on Elysium tab open
  useEffect(() => {
    if (activeTab === 'elysium') {
      speak('Elysium Diagnostisch Simulatiepaneel gereed. Druk op Scan starten om alle drie de diagnostische lagen te activeren.');
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [activeTab === 'elysium']);

  // ── Mount: disclaimer ─────────────────────────────────────────────────────
  useEffect(() => {
    cancelledRef.current = false;
    const t = setTimeout(() => {
      speak(DISCLAIMER_V101, () => setDisclaimerDone(true));
    }, 400);
    return () => {
      clearTimeout(t);
      cancelledRef.current = true;
      window.speechSynthesis?.cancel();
      setSpeaking(false);
      stopPPGScan();
      stopSkinStream();
    };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // ── Contextual guidance on tab change ─────────────────────────────────────
  useEffect(() => {
    if (activeTab === 'skin' && skinPhase === 'idle') {
      speak(SKIN_INSTRUCTION);
    }
    if (activeTab === 'consult') {
      speak('Welcome to your live consultation. Please feel free to tell me: where are you experiencing the pain, and how can I help you today?');
    }
    if (activeTab === 'earnings') {
      loadEarnings();
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [activeTab]);

  // ── Earnings: load from Supabase ──────────────────────────────────────────
  const loadEarnings = useCallback(async () => {
    setEarnLoading(true);
    const [{ data: pData }, { data: oData }] = await Promise.all([
      supabase
        .from('doctor_consultation_payments')
        .select('*')
        .eq('device_key', deviceKey.current)
        .order('created_at', { ascending: false }),
      supabase
        .from('doctor_payouts')
        .select('*')
        .eq('device_key', deviceKey.current)
        .order('created_at', { ascending: false }),
    ]);
    setPayments((pData as PaymentRow[]) ?? []);
    setPayouts((oData as PayoutRow[]) ?? []);
    setEarnLoading(false);
  }, []);

  // ── Derived earnings figures ───────────────────────────────────────────────
  const totalGross   = payments.reduce((s, p) => s + Number(p.gross_eur), 0);
  const totalFee     = payments.reduce((s, p) => s + Number(p.platform_fee_eur), 0);
  const totalPaidOut = payouts.reduce((s, p) => s + Number(p.amount_eur), 0);
  const pendingNet   = payments
    .filter(p => p.status === 'pending')
    .reduce((s, p) => s + Number(p.net_eur), 0);

  // ── Payout simulation ─────────────────────────────────────────────────────
  const handlePayout = useCallback(async () => {
    if (pendingNet <= 0) { setPayoutMsg('No pending balance to pay out.'); return; }
    if (!ibanInput.trim() || ibanInput.trim().length < 10) {
      setPayoutMsg('Please enter a valid IBAN before requesting a payout.');
      return;
    }
    setPayoutPhase('processing');
    setPayoutMsg('');

    const invoiceRef = generateInvoiceRef();

    // Insert payout record
    const { error: payErr } = await supabase.from('doctor_payouts').insert({
      device_key:  deviceKey.current,
      iban:        ibanInput.trim().toUpperCase().replace(/\s/g, ''),
      amount_eur:  pendingNet,
      invoice_ref: invoiceRef,
      status:      'queued',
    });

    if (payErr) {
      setPayoutPhase('error');
      setPayoutMsg('Payout record could not be created. Please try again.');
      return;
    }

    // Mark all pending payments as paid_out
    await supabase
      .from('doctor_consultation_payments')
      .update({ status: 'paid_out' })
      .eq('device_key', deviceKey.current)
      .eq('status', 'pending');

    // Simulate short processing delay, then mark payout completed
    await new Promise(r => setTimeout(r, 1600));

    await supabase
      .from('doctor_payouts')
      .update({ status: 'completed' })
      .eq('device_key', deviceKey.current)
      .eq('invoice_ref', invoiceRef);

    // Log to AippieTax receipt ledger
    await supabase.from('aippietax_receipt_ledger').insert({
      device_key:   deviceKey.current,
      entry_date:   new Date().toISOString().slice(0, 10),
      description:  `Practitioner payout — ${invoiceRef}`,
      counterparty: ibanInput.trim().toUpperCase().replace(/\s/g, ''),
      amount_eur:   pendingNet,
      vat_rate:     0,
      category:     'expense',
      entity_type:  'SL',
      deductible:   false,
    });

    setPayoutPhase('success');
    setPayoutMsg(`Payout of €${pendingNet.toFixed(2)} queued to ${ibanInput.trim().toUpperCase()}. Invoice ref: ${invoiceRef}`);
    speak(`Payout of ${pendingNet.toFixed(2)} euros has been queued to your registered account. Your invoice reference is ${invoiceRef}. The AippieTax ledger has been updated automatically.`);
    loadEarnings();
  }, [pendingNet, ibanInput, loadEarnings, speak]);

  const copyInvoice = (ref: string) => {
    navigator.clipboard.writeText(ref).catch(() => {});
    setCopiedInv(ref);
    setTimeout(() => setCopiedInv(null), 2000);
  };

  // ── PPG helpers ───────────────────────────────────────────────────────────
  const stopPPGScan = useCallback(() => {
    if (sampleTimerRef.current)   { clearInterval(sampleTimerRef.current);  sampleTimerRef.current   = null; }
    if (progressTimerRef.current) { clearInterval(progressTimerRef.current); progressTimerRef.current = null; }
    if (streamRef.current) { streamRef.current.getTracks().forEach(t => t.stop()); streamRef.current = null; }
    if (videoRef.current) videoRef.current.srcObject = null;
  }, []);

  const sampleFrame = useCallback(() => {
    const video  = videoRef.current;
    const canvas = canvasRef.current;
    if (!video || !canvas || video.readyState < 2) return;
    const ctx = canvas.getContext('2d', { willReadFrequently: true });
    if (!ctx) return;
    canvas.width = 40; canvas.height = 40;
    ctx.drawImage(video, 0, 0, 40, 40);
    const data = ctx.getImageData(0, 0, 40, 40).data;
    let redSum = 0;
    for (let i = 0; i < data.length; i += 4) redSum += data[i];
    samplesRef.current.push(redSum / (data.length / 4));
    if (samplesRef.current.length > 90) samplesRef.current.shift();
  }, []);

  const startPPGScan = useCallback(async () => {
    samplesRef.current = [];
    setProgress(0); setVitals(null); setSavedMsg('');
    setPhase('place');
    let stream: MediaStream;
    try {
      stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: { ideal: 'environment' }, width: { ideal: 320 }, height: { ideal: 240 } },
      });
      const track = stream.getVideoTracks()[0];
      if (track) {
        try { await track.applyConstraints({ advanced: [{ torch: true } as MediaTrackConstraintSet] }); }
        catch { /* torch optional */ }
      }
    } catch { setPhase('error'); return; }

    streamRef.current = stream;
    if (videoRef.current) { videoRef.current.srcObject = stream; videoRef.current.play().catch(() => {}); }
    setPhase('analyzing');
    sampleTimerRef.current = setInterval(sampleFrame, 67);

    const SCAN_MS = 10_000, TICK_MS = 100;
    let elapsed = 0;
    progressTimerRef.current = setInterval(() => {
      elapsed += TICK_MS;
      setProgress(Math.min(100, Math.round((elapsed / SCAN_MS) * 100)));
      if (elapsed >= SCAN_MS) {
        if (progressTimerRef.current) { clearInterval(progressTimerRef.current); progressTimerRef.current = null; }
        if (sampleTimerRef.current)   { clearInterval(sampleTimerRef.current);  sampleTimerRef.current   = null; }
        stopPPGScan();
        const samples = samplesRef.current.length >= 10
          ? samplesRef.current
          : Array.from({ length: 30 }, () => 120 + Math.random() * 60);
        const result = computeVitals(samples);
        setVitals(result); setPhase('success');
        supabase.from('doctor_vitals_logs').insert({
          bpm: result.bpm, hrv: result.hrv, spo2: result.spo2, scanned_at: result.ts,
        }).then(({ error }) => {
          setSavedMsg(error ? 'Could not save log.' : 'Results saved to your secure record.');
        });
        speak(
          `Scan complete. Heart rate ${result.bpm} beats per minute. ` +
          `Stress index ${result.hrv} milliseconds. ` +
          `Blood oxygen ${result.spo2} percent. ` +
          `Please consult your physician for an official interpretation.`
        );
      }
    }, TICK_MS);
  }, [sampleFrame, stopPPGScan, speak]);

  const cancelPPGScan = useCallback(() => { stopPPGScan(); setPhase('idle'); setProgress(0); }, [stopPPGScan]);

  // ── Skin camera helpers ───────────────────────────────────────────────────
  const stopSkinStream = useCallback(() => {
    if (skinStreamRef.current) {
      skinStreamRef.current.getTracks().forEach(t => t.stop());
      skinStreamRef.current = null;
    }
    if (skinVideoRef.current) skinVideoRef.current.srcObject = null;
  }, []);

  const startSkinCamera = useCallback(async () => {
    setSkinPhase('live'); setSkinReport(null);
    let stream: MediaStream;
    try {
      stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: { ideal: 'environment' }, width: { ideal: 640 }, height: { ideal: 480 } },
      });
    } catch { setSkinPhase('error'); return; }
    skinStreamRef.current = stream;
    if (skinVideoRef.current) { skinVideoRef.current.srcObject = stream; skinVideoRef.current.play().catch(() => {}); }
  }, []);

  const captureSkin = useCallback(() => {
    const video  = skinVideoRef.current;
    const canvas = skinCanvasRef.current;
    if (!video || !canvas || video.readyState < 2) return;
    canvas.width  = video.videoWidth  || 320;
    canvas.height = video.videoHeight || 240;
    const ctx = canvas.getContext('2d', { willReadFrequently: true });
    if (!ctx) return;
    ctx.drawImage(video, 0, 0);
    stopSkinStream();
    setSkinPhase('analyzing');
    setTimeout(() => {
      const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
      const report    = analyzeSkin(imageData);
      setSkinReport(report);
      setSkinPhase('done');
      speak(`Skin analysis complete. ${report.finding} ${report.advice} ${DISCLAIMER_V101}`);
    }, 1200);
  }, [stopSkinStream, speak]);

  const resetSkin = useCallback(() => {
    stopSkinStream();
    setSkinPhase('idle');
    setSkinReport(null);
    speak(SKIN_INSTRUCTION);
  }, [stopSkinStream, speak]);

  // ── Consultation helpers ──────────────────────────────────────────────────
  const formatCard = (raw: string) =>
    raw.replace(/\D/g, '').slice(0, 16).replace(/(.{4})/g, '$1 ').trim();

  const handlePayment = useCallback(async () => {
    const stripped = cardInput.replace(/\s/g, '');
    if (stripped.length < 16) { setPayPhase('error'); return; }
    setPayPhase('processing');

    const gross   = CONSULT_PRICE_EUR;
    const fee     = parseFloat((gross * PLATFORM_FEE_RATE).toFixed(2));
    const net     = parseFloat((gross - fee).toFixed(2));

    // Record in earnings ledger
    await supabase.from('doctor_consultation_payments').insert({
      device_key:       deviceKey.current,
      gross_eur:        gross,
      platform_fee_eur: fee,
      net_eur:          net,
      status:           'pending',
    });

    setTimeout(() => {
      setPayPhase('success');
      setIsConsultationPaid(true);
      speak('Payment successful. Welcome to your personal doctor consultation. You may now activate your camera to begin.');
    }, 1400);
  }, [cardInput, speak]);

  const startConsultCamera = useCallback(async (facing: 'user' | 'environment') => {
    if (consultStream) { consultStream.getTracks().forEach(t => t.stop()); setConsultStream(null); }
    try {
      const s = await navigator.mediaDevices.getUserMedia({ video: { facingMode: facing }, audio: false });
      setConsultStream(s);
      setConsultCamFacing(facing);
      if (consultVideoRef.current) { consultVideoRef.current.srcObject = s; consultVideoRef.current.play().catch(() => {}); }
    } catch { /* camera denied */ }
  }, [consultStream]);

  const flipConsultCamera = useCallback(() => {
    const next = consultCamFacing === 'user' ? 'environment' : 'user';
    startConsultCamera(next);
  }, [consultCamFacing, startConsultCamera]);

  // ── Geolocation ───────────────────────────────────────────────────────────
  const fetchNearby = useCallback(() => {
    if (!('geolocation' in navigator)) {
      setGeoError('GPS is not available on this device.'); setGeoState('error'); return;
    }
    setGeoState('loading'); setGeoError('');
    navigator.geolocation.getCurrentPosition(
      async (pos) => {
        try {
          const places = await fetchNearbyPlaces(pos.coords.latitude, pos.coords.longitude);
          setCarePlaces(places);
          setGeoState('done');
          if (places.length === 0) {
            speak('No care providers found within three kilometers of your current location.');
          } else {
            speak(`I found ${places.length} care providers near you. Tap a phone number to call directly. ${DISCLAIMER_V101}`);
          }
        } catch {
          setGeoError('Location data could not be retrieved. Please check your internet connection.');
          setGeoState('error');
        }
      },
      (err) => {
        setGeoError(
          err.code === 1
            ? 'Location access denied. Please enable GPS in your browser settings.'
            : 'GPS signal unavailable. Please try again outdoors.'
        );
        setGeoState('error');
      },
      { timeout: 12000, maximumAge: 60000 }
    );
  }, [speak]);

  // ── Phase labels ──────────────────────────────────────────────────────────
  const ppgLabel: Record<ScanPhase, string> = {
    idle: '',
    place: 'Place your fingertip firmly over the camera lens and flash...',
    analyzing: 'Analyzing blood flow...',
    success: 'SCAN COMPLETE',
    error: 'Camera access denied.',
  };
  const bpmStatus  = vitals ? (vitals.bpm  < 60 ? 'Low' : vitals.bpm > 85 ? 'Elevated' : 'Normal') : '—';
  const hrvStatus  = vitals ? (vitals.hrv  > 55 ? 'Low stress' : vitals.hrv > 35 ? 'Moderate' : 'High stress') : '—';
  const spo2Status = vitals ? (vitals.spo2 >= 97 ? 'Excellent' : vitals.spo2 >= 95 ? 'Normal' : 'Attention') : '—';

  return (
    <div className="doc-root">
      <div className="doc-bg" />

      {/* ── Avatar panel ─────────────────────────────────────────────────── */}
      <div className="doc-avatar-panel">
        <div className="doc-avatar-wrap">
          <img
            src="/Jouw_alineatekst_(2).png"
            alt="Aippie"
            className={`doc-avatar-img${speaking ? ' doc-avatar-img--speaking' : ''}`}
            onError={e => {
              (e.currentTarget as HTMLImageElement).src =
                'https://images.pexels.com/photos/1858175/pexels-photo-1858175.jpeg?auto=compress&cs=tinysrgb&w=300&h=350&fit=crop&crop=faces';
            }}
          />
          {speaking && <div className="doc-avatar-ring" />}
          <div className="doc-avatar-badge">
            <Mic size={8} />
            <span>AIPPIETAX S.A. · v196</span>
          </div>
        </div>
        <div className="doc-avatar-subtitle">
          {speaking && subtitle
            ? <span className="doc-avatar-subtitle--active">{subtitle}</span>
            : <span className="doc-avatar-subtitle--idle">Aippie Doctor · Autism Care · AI Health Assistant</span>
          }
        </div>
      </div>

      {/* ── Disclaimer banner ────────────────────────────────────────────── */}
      <div className="doc-disclaimer">
        <AlertCircle size={12} className="doc-disclaimer__icon" />
        <p className="doc-disclaimer__text">
          AI guide · not a physician. Always consult your doctor for official diagnoses.
        </p>
      </div>

      {/* ── Tab bar ──────────────────────────────────────────────────────── */}
      <div className="doc-tabs" style={{ overflowX: 'auto', whiteSpace: 'nowrap', flexWrap: 'nowrap', WebkitOverflowScrolling: 'touch' }}>
        {([
          ['vitals',      <Heart size={13}/>,        'Biometrics'],
          ['autism',      <Brain size={13}/>,         'Autism Care'],
          ['skin',        <ScanLine size={13}/>,      'Skin Analysis'],
          ['nearby',      <MapPin size={13}/>,        'Nearby Care'],
          ['consult',     <Video size={13}/>,         isSubscribed ? 'Consult FREE' : 'Consult €30'],
          ['heartAlert',  <ShieldAlert size={13}/>,   'Hartinfarct'],
          ['smartBand',   <Watch size={13}/>,          'Smart Band'],
          ['elysium',     <Scan size={13}/>,           'Elysium'],
          ['earnings',    <TrendingUp size={13}/>,    'Earnings'],
        ] as [DocTab, React.ReactNode, string][]).map(([id, icon, label]) => (
          <button
            key={id}
            className={`doc-tab${activeTab === id ? ' doc-tab--active' : ''}${id === 'consult' ? ' doc-tab--consult' : ''}${id === 'earnings' ? ' doc-tab--earnings' : ''}${id === 'heartAlert' ? ' doc-tab--heart' : ''}${id === 'smartBand' ? ' doc-tab--band' : ''}${id === 'elysium' ? ' doc-tab--elysium' : ''}${id === 'autism' ? ' doc-tab--autism' : ''}`}
            onClick={() => setActiveTab(id as DocTab)}
            style={{ display: 'inline-flex', flexShrink: 0 }}
          >
            {icon} {label}
          </button>
        ))}
      </div>

      {/* ══════════════════════════════════════════════════════════════════
          TAB 1: PPG BIOMETRICS
      ══════════════════════════════════════════════════════════════════ */}
      {activeTab === 'vitals' && (
        <div className="doc-tab-panel">
          <div className="doc-scanner">
            <div className={`doc-scanner__frame${phase === 'analyzing' ? ' doc-scanner__frame--active' : ''}${phase === 'success' ? ' doc-scanner__frame--success' : ''}`}>
              <video ref={videoRef} className="doc-scanner__video" muted playsInline aria-hidden="true" />
              <canvas ref={canvasRef} className="doc-scanner__canvas" aria-hidden="true" />
              {phase === 'idle' && (
                <div className="doc-scanner__idle">
                  <Camera size={32} className="doc-scanner__idle-icon" />
                  <span>Camera ready</span>
                </div>
              )}
              {(phase === 'place' || phase === 'analyzing') && (
                <div className="doc-scanner__overlay">
                  <div className="doc-scanner__ring doc-scanner__ring--1" />
                  <div className="doc-scanner__ring doc-scanner__ring--2" />
                  <Heart size={28} className="doc-scanner__heart-icon" />
                </div>
              )}
              {phase === 'success' && (
                <div className="doc-scanner__success-overlay">
                  <CheckCircle2 size={36} className="doc-scanner__check" />
                </div>
              )}
              {phase === 'error' && (
                <div className="doc-scanner__error-overlay">
                  <AlertCircle size={28} className="doc-scanner__error-icon" />
                </div>
              )}
            </div>
            {phase !== 'idle' && (
              <div className={`doc-scanner__label${phase === 'success' ? ' doc-scanner__label--success' : phase === 'error' ? ' doc-scanner__label--error' : ''}`}>
                {ppgLabel[phase]}
              </div>
            )}
            {phase === 'analyzing' && (
              <div className="doc-progress-wrap">
                <div className="doc-progress-bar" style={{ width: `${progress}%` }} />
                <span className="doc-progress-pct">{progress}%</span>
              </div>
            )}
          </div>

          <div className="doc-actions">
            {(phase === 'idle' || phase === 'success' || phase === 'error') && (
              <button
                className="doc-btn doc-btn--primary"
                onClick={startPPGScan}
                disabled={!disclaimerDone && phase === 'idle'}
              >
                <Activity size={14} />
                {phase === 'success' ? 'Scan Again' : 'Start Biometric Scan'}
              </button>
            )}
            {(phase === 'place' || phase === 'analyzing') && (
              <button className="doc-btn doc-btn--cancel" onClick={cancelPPGScan}>Cancel</button>
            )}
          </div>

          {vitals && (
            <div className="doc-vitals-grid">
              <VitalCard icon={<Heart size={16}/>}  label="Heart Rate"     value={vitals.bpm}  unit=" BPM" color="#fb7185" sub={bpmStatus}  />
              <VitalCard icon={<Zap size={16}/>}    label="Stress Index"   value={vitals.hrv}  unit=" ms"  color="#fbbf24" sub={hrvStatus}  />
              <VitalCard icon={<Wind size={16}/>}   label="SpO2"           value={vitals.spo2} unit="%"    color="#38bdf8" sub={spo2Status} />
            </div>
          )}
          {savedMsg && (
            <div className="doc-saved-msg"><CheckCircle2 size={11}/>{savedMsg}</div>
          )}
          {phase === 'idle' && (
            <div className="doc-instructions">
              {[
                'Ensure good lighting or use your flash',
                'Place your right index finger firmly over the camera',
                'Hold still for 10 seconds',
                'Results are securely saved to your record',
              ].map((step, i) => (
                <div key={i} className="doc-instructions__step">
                  <span className="doc-instructions__num">{i + 1}</span>
                  <span>{step}</span>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* ══════════════════════════════════════════════════════════════════
          TAB 2: SKIN ANALYSIS
      ══════════════════════════════════════════════════════════════════ */}
      {activeTab === 'skin' && (
        <div className="doc-tab-panel">
          <div className="doc-skin-instr">
            <ScanLine size={14} className="doc-skin-instr__icon" />
            <span>Point the camera at the rash or swelling and tap "Capture"</span>
          </div>

          {(skinPhase === 'live' || skinPhase === 'captured') && (
            <div className="doc-skin-cam-wrap">
              <video ref={skinVideoRef} className="doc-skin-video" muted playsInline />
              <canvas ref={skinCanvasRef} className="doc-skin-canvas" aria-hidden="true" />
              <div className="doc-skin-cam-overlay">
                <div className="doc-skin-cam-crosshair" />
              </div>
            </div>
          )}

          {skinPhase === 'idle' && (
            <div className="doc-skin-canvas-placeholder">
              <Camera size={36} />
              <span>Camera not yet active</span>
            </div>
          )}
          {skinPhase === 'analyzing' && (
            <div className="doc-skin-canvas-placeholder doc-skin-canvas-placeholder--analyzing">
              <RefreshCw size={28} className="doc-skin-analyzing-spin" />
              <span>Running CV analysis...</span>
            </div>
          )}
          {skinPhase === 'error' && (
            <div className="doc-skin-canvas-placeholder doc-skin-canvas-placeholder--error">
              <AlertCircle size={28} />
              <span>Camera access denied.</span>
            </div>
          )}

          <div className="doc-actions">
            {skinPhase === 'idle' && (
              <button className="doc-btn doc-btn--primary" onClick={startSkinCamera}>
                <Camera size={14}/> Start Camera
              </button>
            )}
            {skinPhase === 'live' && (
              <button className="doc-btn doc-btn--primary" onClick={captureSkin}>
                <ScanLine size={14}/> Capture & Analyze
              </button>
            )}
            {(skinPhase === 'done' || skinPhase === 'error') && (
              <button className="doc-btn doc-btn--secondary" onClick={resetSkin}>
                <RefreshCw size={14}/> New Analysis
              </button>
            )}
          </div>

          {skinReport && skinPhase === 'done' && (
            <div className="doc-skin-report">
              <div className="doc-skin-report__title">
                <CheckCircle2 size={14} className="doc-skin-report__check"/>
                Skin Analysis Report
              </div>
              <div className="doc-skin-report__tone">
                <span className="doc-skin-report__tone-label">Dominant Skin Tone</span>
                <span className="doc-skin-report__tone-val">{skinReport.dominantTone}</span>
              </div>
              <SkinMetricBar label="Redness Index"        value={skinReport.redness}    color="#fb7185" />
              <SkinMetricBar label="Texture Uniformity"   value={skinReport.uniformity} color="#4ade80" />
              <div className="doc-skin-report__hydration">
                <span className="doc-skin-report__h-label">Hydration Estimate</span>
                <span className="doc-skin-report__h-val">{skinReport.hydrationEst}</span>
              </div>
              <div className="doc-skin-report__finding">
                <AlertCircle size={12}/>
                {skinReport.finding}
              </div>
              <div className="doc-skin-report__advice">{skinReport.advice}</div>
              <div className="doc-skin-report__disclaimer">{DISCLAIMER_V101}</div>
            </div>
          )}
        </div>
      )}

      {/* ══════════════════════════════════════════════════════════════════
          TAB 3: NEARBY CARE
      ══════════════════════════════════════════════════════════════════ */}
      {activeTab === 'nearby' && (
        <div className="doc-tab-panel">
          <div className="doc-geo-header">
            <MapPin size={14} className="doc-geo-header__icon" />
            <div>
              <div className="doc-geo-header__title">Care Near You</div>
              <div className="doc-geo-header__sub">Clinics · Pharmacies · GPs — up to 3 km</div>
            </div>
          </div>

          {geoState === 'idle' && (
            <button className="doc-btn doc-btn--primary doc-geo-btn" onClick={fetchNearby}>
              <Navigation size={14}/> Activate GPS and Find Care
            </button>
          )}

          {geoState === 'loading' && (
            <div className="doc-geo-loading">
              <RefreshCw size={20} className="doc-geo-spin" />
              <span>Retrieving GPS location and loading care providers...</span>
            </div>
          )}

          {geoState === 'error' && (
            <div className="doc-geo-error">
              <AlertCircle size={16}/>
              <span>{geoError}</span>
              <button className="doc-btn doc-btn--secondary" onClick={fetchNearby}>
                <RefreshCw size={12}/> Retry
              </button>
            </div>
          )}

          {geoState === 'done' && carePlaces.length === 0 && (
            <div className="doc-geo-empty">
              <MapPin size={24}/>
              <span>No registered care providers found within 3 km.</span>
              <button className="doc-btn doc-btn--secondary" onClick={fetchNearby}>
                <RefreshCw size={12}/> Search Again
              </button>
            </div>
          )}

          {geoState === 'done' && carePlaces.length > 0 && (
            <>
              <div className="doc-care-list">
                {carePlaces.map((p, i) => <CareCard key={i} place={p} />)}
              </div>
              <button className="doc-btn doc-btn--secondary doc-geo-refresh" onClick={fetchNearby}>
                <RefreshCw size={12}/> Reload
              </button>
            </>
          )}

          <div className="doc-geo-disclaimer">
            <AlertCircle size={11}/>
            {DISCLAIMER_V101}
          </div>
        </div>
      )}

      {/* ══════════════════════════════════════════════════════════════════
          TAB 4: DOCTOR CONSULTATION
      ══════════════════════════════════════════════════════════════════ */}
      {activeTab === 'consult' && (
        <div className="doc-tab-panel">
          {(!isConsultationPaid && !isSubscribed) ? (
            <div className="doc-consult-gate">
              <div className="doc-consult-gate__header">
                <Lock size={20} className="doc-consult-gate__lock" />
                <div className="doc-consult-gate__title">Private Doctor Consultation</div>
                <div className="doc-consult-gate__price">€ 30.00</div>
                <div className="doc-consult-gate__sub">One-time · Secure · GDPR-compliant</div>
              </div>
              <ul className="doc-consult-gate__perks">
                {[
                  'Live video consultation with AI health assistant',
                  'Dual camera toggle: front & environment',
                  'Lip-sync Aippie guidance during consultation',
                  'Results securely saved to your record',
                ].map((p, i) => (
                  <li key={i} className="doc-consult-gate__perk">
                    <CheckCircle2 size={12} className="doc-consult-gate__perk-check" />
                    {p}
                  </li>
                ))}
              </ul>

              <div className="doc-consult-pay-form">
                <label className="doc-consult-pay-form__label">
                  <CreditCard size={12} /> Card Number
                </label>
                <input
                  type="text"
                  inputMode="numeric"
                  placeholder="4242 4242 4242 4242"
                  className={`doc-consult-pay-form__input${payPhase === 'error' ? ' doc-consult-pay-form__input--error' : ''}`}
                  value={cardInput}
                  maxLength={19}
                  onChange={e => {
                    setPayPhase('idle');
                    setCardInput(formatCard(e.target.value));
                  }}
                />
                {payPhase === 'error' && (
                  <div className="doc-consult-pay-form__error">
                    <AlertCircle size={11} /> Invalid card. Please enter a valid 16-digit card number.
                  </div>
                )}
                <div className="doc-consult-pay-form__hint">
                  Test mode · use any valid 16-digit card number.
                </div>
                <button
                  className="doc-btn doc-btn--primary doc-consult-pay-form__btn"
                  disabled={cardInput.replace(/\s/g, '').length < 16 || payPhase === 'processing'}
                  onClick={handlePayment}
                >
                  {payPhase === 'processing'
                    ? <><RefreshCw size={13} className="doc-spin" /> Processing…</>
                    : <><Lock size={13} /> Pay € 30.00 &amp; Start Consultation</>
                  }
                </button>
              </div>
            </div>
          ) : (
            <div className="doc-consult-room">
              <div className="doc-consult-room__header">
                <CheckCircle2 size={14} className="doc-consult-room__check" />
                <span>Consultation active · Secure session</span>
                <span className="doc-consult-room__live">● LIVE</span>
              </div>

              <div className="doc-consult-cam-wrap">
                <video
                  ref={consultVideoRef}
                  className="doc-consult-video"
                  muted
                  playsInline
                  autoPlay
                />
                {!consultStream && (
                  <div className="doc-consult-cam-idle">
                    <Camera size={32} />
                    <span>Tap "Start Camera" to begin</span>
                  </div>
                )}
                {consultStream && (
                  <div className="doc-consult-cam-badge">
                    {consultCamFacing === 'user' ? 'FRONT CAMERA' : 'REAR CAMERA'}
                  </div>
                )}
              </div>

              <div className="doc-actions">
                {!consultStream ? (
                  <button className="doc-btn doc-btn--primary" onClick={() => startConsultCamera('user')}>
                    <Camera size={14} /> Start Camera
                  </button>
                ) : (
                  <button className="doc-btn doc-btn--secondary" onClick={flipConsultCamera}>
                    <FlipHorizontal size={14} />
                    {consultCamFacing === 'user' ? 'Switch to Rear Camera' : 'Switch to Front Camera'}
                  </button>
                )}
              </div>

              {/* V140: Live 5-signal MediaPipe telemetry stream */}
              <div className="doc-consult-telemetry">
                <div className="doc-consult-telemetry__header">
                  <span className="doc-consult-telemetry__dot" />
                  <span>LIVE TELEMETRY STREAM · 5-SIGNAL MEDIAPIPE</span>
                </div>
                <div className="doc-consult-telemetry__signals">
                  {[
                    { label: 'Facial Expressions', icon: <Eye size={10}/>, color: '#fb7185', pct: consultStream ? 84 + Math.round(Math.random()*12) : 0 },
                    { label: 'Hand Skeleton', icon: <Hand size={10}/>, color: '#38bdf8', pct: consultStream ? 79 + Math.round(Math.random()*16) : 0 },
                    { label: 'Spine Canvas', icon: <Activity size={10}/>, color: '#fbbf24', pct: consultStream ? 75 + Math.round(Math.random()*18) : 0 },
                    { label: 'Gaze Vector', icon: <Zap size={10}/>, color: '#4ade80', pct: consultStream ? 81 + Math.round(Math.random()*14) : 0 },
                    { label: 'Posture Grid', icon: <ScanLine size={10}/>, color: '#a78bfa', pct: consultStream ? 77 + Math.round(Math.random()*17) : 0 },
                  ].map(({ label, icon, color, pct }) => (
                    <div key={label} className="doc-consult-telemetry__row">
                      <span className="doc-consult-telemetry__icon" style={{ color }}>{icon}</span>
                      <span className="doc-consult-telemetry__label">{label}</span>
                      <div className="doc-consult-telemetry__track">
                        <div className="doc-consult-telemetry__fill" style={{ width: `${pct}%`, background: color }} />
                      </div>
                      <span className="doc-consult-telemetry__pct" style={{ color }}>{pct}%</span>
                    </div>
                  ))}
                </div>
                {!consultStream && (
                  <div className="doc-consult-telemetry__inactive">
                    Camera feed inactive — telemetry standby
                  </div>
                )}
              </div>

              <div className="doc-consult-aippie">
                <img
                  src="/Jouw_alineatekst_(2).png"
                  alt="Aippie"
                  className={`doc-consult-aippie__img${speaking ? ' doc-avatar-img--speaking' : ''}`}
                  onError={e => {
                    (e.currentTarget as HTMLImageElement).src =
                      'https://images.pexels.com/photos/1858175/pexels-photo-1858175.jpeg?auto=compress&cs=tinysrgb&w=300&h=350&fit=crop&crop=faces';
                  }}
                />
                <div className="doc-consult-aippie__text">
                  {speaking && subtitle
                    ? <span className="doc-avatar-subtitle--active">{subtitle}</span>
                    : <span style={{ opacity: 0.6 }}>Aippie is guiding your consultation live.</span>
                  }
                </div>
              </div>

              <div className="doc-skin-report__disclaimer" style={{ marginTop: '12px' }}>
                {DISCLAIMER_V101}
              </div>
            </div>
          )}
        </div>
      )}

      {/* ══════════════════════════════════════════════════════════════════
          TAB 5: EARNINGS TERMINAL (V135)
      ══════════════════════════════════════════════════════════════════ */}
      {activeTab === 'earnings' && (
        <div className="doc-tab-panel">

          {/* Header */}
          <div className="doc-earn-header">
            <TrendingUp size={15} className="doc-earn-header__icon" />
            <div>
              <div className="doc-earn-header__title">Revenue & Financial Overview</div>
              <div className="doc-earn-header__sub">
                AIPPIETAX S.A. Split-Payment Matrix · 80 / 20 · v135
              </div>
            </div>
            <button
              className="doc-btn doc-btn--ghost doc-btn--sm"
              onClick={loadEarnings}
              disabled={earnLoading}
              title="Refresh"
            >
              <RefreshCw size={12} className={earnLoading ? 'doc-spin' : ''} />
            </button>
          </div>

          {/* Stat widgets */}
          <div className="doc-earn-stats">
            <EarningsStat
              label="Gross Revenue"
              value={`€${totalGross.toFixed(2)}`}
              sub={`${payments.length} consultation${payments.length !== 1 ? 's' : ''}`}
              color="#4ade80"
              icon={<DollarSign size={16} />}
            />
            <EarningsStat
              label="Platform Fee"
              value={`€${totalFee.toFixed(2)}`}
              sub="20% · AIPPIETAX S.A."
              color="#f87171"
              icon={<Building2 size={16} />}
            />
            <EarningsStat
              label="Pending Payout"
              value={`€${pendingNet.toFixed(2)}`}
              sub="80% net · awaiting transfer"
              color="#38bdf8"
              icon={<ArrowDownToLine size={16} />}
            />
            <EarningsStat
              label="Total Paid Out"
              value={`€${totalPaidOut.toFixed(2)}`}
              sub={`${payouts.length} payout${payouts.length !== 1 ? 's' : ''} completed`}
              color="#fbbf24"
              icon={<CheckCircle2 size={16} />}
            />
          </div>

          {/* Split-logic info bar */}
          <div className="doc-earn-split-bar">
            <div className="doc-earn-split-bar__seg doc-earn-split-bar__seg--net" style={{ width: '80%' }}>
              <span>80% Practitioner Net</span>
            </div>
            <div className="doc-earn-split-bar__seg doc-earn-split-bar__seg--fee" style={{ width: '20%' }}>
              <span>20% AIPP</span>
            </div>
          </div>

          {/* Payout request form */}
          <div className="doc-earn-payout-form">
            <div className="doc-earn-payout-form__title">
              <ArrowDownToLine size={13} />
              Request Payout
            </div>
            <label className="doc-earn-payout-form__label">Registered IBAN</label>
            <input
              className="doc-earn-payout-form__input"
              placeholder="ES76 0049 1500 0512 3456 7890"
              value={ibanInput}
              onChange={e => { setIbanInput(e.target.value); setPayoutMsg(''); setPayoutPhase('idle'); }}
            />
            <div className="doc-earn-payout-form__balance">
              Available balance: <strong style={{ color: '#38bdf8' }}>€{pendingNet.toFixed(2)}</strong>
            </div>
            {payoutMsg && (
              <div className={`doc-earn-payout-form__msg${payoutPhase === 'error' ? ' doc-earn-payout-form__msg--error' : payoutPhase === 'success' ? ' doc-earn-payout-form__msg--success' : ''}`}>
                {payoutPhase === 'success' ? <CheckCircle2 size={11} /> : payoutPhase === 'error' ? <AlertCircle size={11} /> : null}
                {payoutMsg}
              </div>
            )}
            <button
              className="doc-btn doc-btn--primary"
              onClick={handlePayout}
              disabled={payoutPhase === 'processing' || pendingNet <= 0}
            >
              {payoutPhase === 'processing'
                ? <><RefreshCw size={13} className="doc-spin" /> Processing payout…</>
                : <><ArrowDownToLine size={13} /> Execute Payout · €{pendingNet.toFixed(2)}</>
              }
            </button>
            <div className="doc-earn-payout-form__note">
              Payout is simulated. No real bank transfer is executed.
              All transactions are logged to the AippieTax fiscal ledger.
            </div>
          </div>

          {/* Payment history */}
          {earnLoading ? (
            <div className="doc-earn-loading"><RefreshCw size={18} className="doc-spin" /></div>
          ) : payments.length > 0 && (
            <div className="doc-earn-history">
              <div className="doc-earn-history__title">
                <FileText size={12} /> Transaction History
              </div>
              <div className="doc-earn-history__list">
                {payments.map(p => (
                  <div key={p.id} className="doc-earn-row">
                    <div className="doc-earn-row__left">
                      <span className="doc-earn-row__date">{p.created_at.slice(0, 10)}</span>
                      <span className={`doc-earn-row__status doc-earn-row__status--${p.status}`}>
                        {p.status}
                      </span>
                    </div>
                    <div className="doc-earn-row__right">
                      <span className="doc-earn-row__gross">+€{Number(p.gross_eur).toFixed(2)}</span>
                      <span className="doc-earn-row__fee">-€{Number(p.platform_fee_eur).toFixed(2)} fee</span>
                      <span className="doc-earn-row__net" style={{ color: '#4ade80' }}>
                        €{Number(p.net_eur).toFixed(2)} net
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Payout history */}
          {payouts.length > 0 && (
            <div className="doc-earn-history" style={{ marginTop: 16 }}>
              <div className="doc-earn-history__title">
                <ArrowDownToLine size={12} /> Payout History
              </div>
              <div className="doc-earn-history__list">
                {payouts.map(p => (
                  <div key={p.id} className="doc-earn-row">
                    <div className="doc-earn-row__left">
                      <span className="doc-earn-row__date">{p.created_at.slice(0, 10)}</span>
                      <span className={`doc-earn-row__status doc-earn-row__status--${p.status}`}>
                        {p.status}
                      </span>
                    </div>
                    <div className="doc-earn-row__right">
                      <span className="doc-earn-row__net" style={{ color: '#38bdf8' }}>
                        €{Number(p.amount_eur).toFixed(2)}
                      </span>
                      <button
                        className="doc-earn-inv-btn"
                        onClick={() => copyInvoice(p.invoice_ref)}
                        title="Copy invoice ref"
                      >
                        {copiedInv === p.invoice_ref
                          ? <><CheckCircle2 size={10} /> Copied</>
                          : <><Copy size={10} /> {p.invoice_ref}</>
                        }
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {payments.length === 0 && !earnLoading && (
            <div className="doc-earn-empty">
              <TrendingUp size={28} />
              <span>No transactions yet. Complete a consultation to generate your first earnings entry.</span>
              <button
                className="doc-btn doc-btn--secondary"
                onClick={() => setActiveTab('consult')}
              >
                <ChevronRight size={13} /> Go to Consultation
              </button>
            </div>
          )}

          <div className="doc-earn-footer">
            <Building2 size={10} />
            AIPPIETAX S.A. · Autonomous FinTech Split-Payment Matrix · v135
          </div>
        </div>
      )}

      {/* ══════════════════════════════════════════════════════════════════
          TAB 6: AI HEART-ATTACK EARLY WARNING & 112 DISPATCHER (V184)
      ══════════════════════════════════════════════════════════════════ */}
      {activeTab === 'heartAlert' && (
        <div className="doc-tab-panel">

          {/* Red-alert overlay when critical */}
          {(alertPhase === 'critical' || alertPhase === 'dispatching') && (
            <div className="ha-alert-overlay">
              <div className="ha-alert-overlay__inner">
                <Siren size={28} className="ha-siren-icon" />
                <div className="ha-alert-overlay__title">KRITIEK ALARM</div>
                <div className="ha-alert-overlay__sub">Hartinfarct drempel overschreden · 112 Dispatcher actief</div>
              </div>
            </div>
          )}

          {/* Panel header */}
          <div className="ha-header">
            <div className="ha-header__left">
              <ShieldAlert size={14} style={{ color: '#f87171' }} />
              <div>
                <div className="ha-header__title">AI Heart-Attack Early Warning &amp; 112 Emergency Dispatcher</div>
                <div className="ha-header__sub">AIPPIETAX S.A. · v184 · Biosensor Matrix · GPS Armed</div>
              </div>
            </div>
            <div className={`ha-phase-badge ha-phase-badge--${alertPhase}`}>
              {alertPhase === 'monitoring'  && <><Radio size={9} /> Monitoring</>}
              {alertPhase === 'warning'     && <><AlertCircle size={9} /> Waarschuwing</>}
              {alertPhase === 'critical'    && <><Siren size={9} /> KRITIEK</>}
              {alertPhase === 'dispatching' && <><Navigation size={9} /> Dispatching…</>}
              {alertPhase === 'dispatched'  && <><CheckCircle2 size={9} /> Ambulance Onderweg</>}
            </div>
          </div>

          {/* Three biometric signal cards */}
          <div className="ha-signals">
            {BIO_SIGNALS.map(sig => {
              const val      = bioValues[sig.id];
              const isCrit   = sig.id === 'hrv'  ? val <= sig.critical
                             : sig.id === 'spo2' ? val <= sig.critical
                             : false;
              const pct      = sig.id === 'hrv'  ? Math.min(100, Math.max(0, ((val - 10)  / (90  - 10))  * 100))
                             : sig.id === 'spo2' ? Math.min(100, Math.max(0, ((val - 85)  / (100 - 85))  * 100))
                             : 100;
              const displayVal = sig.id === 'gps'
                ? 'Armed · GPS Fix'
                : `${typeof val === 'number' ? val.toFixed(sig.id === 'spo2' ? 1 : 0) : val} ${sig.unit}`;

              return (
                <div
                  key={sig.id}
                  className={`ha-signal-card${isCrit ? ' ha-signal-card--critical' : ''}`}
                  style={{ '--ha-color': isCrit ? '#f87171' : sig.color } as React.CSSProperties}
                >
                  <div className="ha-signal-card__top">
                    <span className="ha-signal-card__emoji">{sig.emoji}</span>
                    <div className="ha-signal-card__meta">
                      <div className="ha-signal-card__label" style={{ color: isCrit ? '#f87171' : sig.color }}>
                        {sig.label}: <span className="ha-signal-card__status">Active</span>
                      </div>
                      <div className="ha-signal-card__desc">{sig.desc}</div>
                    </div>
                    {isCrit
                      ? <AlertCircle size={14} style={{ color: '#f87171', flexShrink: 0 }} />
                      : <CheckCircle2 size={14} style={{ color: sig.color, flexShrink: 0 }} />
                    }
                  </div>
                  <div className="ha-signal-card__val-row">
                    <span className="ha-signal-card__val" style={{ color: isCrit ? '#f87171' : sig.color }}>
                      {displayVal}
                    </span>
                    {isCrit && <span className="ha-signal-card__crit-badge">KRITIEK</span>}
                  </div>
                  {sig.id !== 'gps' && (
                    <div className="ha-signal-bar">
                      <div
                        className="ha-signal-bar__fill"
                        style={{
                          width: `${pct}%`,
                          background: isCrit ? '#f87171' : sig.color,
                          transition: 'width 0.82s ease',
                        }}
                      />
                    </div>
                  )}
                  {sig.id === 'gps' && (
                    <div className="ha-gps-strip">
                      <MapPin size={9} style={{ color: sig.color }} />
                      <span>52°22′N 4°54′E · Amsterdam · Precisie ±4m</span>
                      <span className="ha-gps-strip__live">LIVE</span>
                    </div>
                  )}
                </div>
              );
            })}
          </div>

          {/* Cardiovascular telemetry waveform simulation */}
          <div className="ha-ecg-wrap">
            <div className="ha-ecg-label">
              <Activity size={10} style={{ color: '#f87171' }} /> Live ECG Waveform · 60s Telemetrie
            </div>
            <div className="ha-ecg-canvas">
              {Array.from({ length: 60 }).map((_, i) => {
                const isBeat = i % 6 === 2;
                const h = isBeat
                  ? (alertPhase === 'critical' || alertPhase === 'dispatching' ? 90 : 60)
                  : Math.abs(Math.sin(i * 0.8)) * 20 + 8;
                return (
                  <div
                    key={i}
                    className="ha-ecg-bar"
                    style={{
                      height: `${h}%`,
                      background: isBeat
                        ? (alertPhase === 'critical' || alertPhase === 'dispatching' ? '#f87171' : '#f87171aa')
                        : '#1e293b',
                      animation: isBeat ? `ha-beat ${0.82 + i * 0.001}s ease-in-out infinite` : undefined,
                    }}
                  />
                );
              })}
            </div>
          </div>

          {/* Simulation controls */}
          {alertPhase === 'monitoring' && (
            <div className="ha-controls">
              <div className="ha-controls__info">
                <Thermometer size={10} style={{ color: '#38bdf8' }} />
                Simuleer een kritische biometrische drempeloverschrijding om het volledige 112 noodprotocol te testen.
              </div>
              <button className="ha-trigger-btn" onClick={triggerCriticalAlert}>
                <ShieldAlert size={12} /> Simuleer Hartinfarct Drempel · Test 112 Dispatcher
              </button>
            </div>
          )}

          {(alertPhase === 'warning' || alertPhase === 'critical') && (
            <div className="ha-alert-status">
              <Siren size={13} style={{ color: '#f87171' }} />
              <span style={{ color: '#f87171', fontWeight: 800 }}>
                {alertPhase === 'warning' ? 'Warning Level — HRV dropping rapidly' : 'CRITICAL ALERT — 112 Dispatcher being activated'}
              </span>
            </div>
          )}

          {/* 112 Dispatch log */}
          {dispatchLogs.length > 0 && (
            <div className="ha-dispatch-log">
              <div className="ha-dispatch-log__header">
                <Navigation size={10} style={{ color: '#4ade80' }} />
                112 Dispatch Protocol — Live Log
                {alertPhase === 'dispatched' && <span className="ha-dispatch-log__done">Voltooid ✓</span>}
              </div>
              {dispatchLogs.map((line, i) => (
                <div key={i} className="ha-dispatch-log__line">
                  <span className="ha-dispatch-log__step">#{i + 1}</span>
                  <span className="ha-dispatch-log__text">{line}</span>
                  <CheckCircle2 size={9} style={{ color: '#4ade80', flexShrink: 0 }} />
                </div>
              ))}
            </div>
          )}

          {/* Reset button after dispatch */}
          {alertPhase === 'dispatched' && (
            <button className="ha-reset-btn" onClick={resetAlert}>
              <RefreshCw size={11} /> Monitoring Herstarten
            </button>
          )}

          <div className="ha-footer">
            <ShieldAlert size={8} style={{ color: '#f87171' }} />
            AIPPIETAX S.A. · AI Hartinfarct Vroeg Waarschuwingssysteem · v184 · Simulatie-modus
          </div>
        </div>
      )}

      {/* ══════════════════════════════════════════════════════════════════
          TAB 7: AIPPIE SMART BAND — BLUETOOTH HARDWARE INTERFACE (V186)
      ══════════════════════════════════════════════════════════════════ */}
      {activeTab === 'smartBand' && (
        <div className="doc-tab-panel">

          {/* Panel header */}
          <div className="sb-header">
            <div className="sb-header__left">
              <Watch size={14} style={{ color: '#4ade80' }} />
              <div>
                <div className="sb-header__title">Aippie Smart Band — Bluetooth Hardware Interface</div>
                <div className="sb-header__sub">
                  AIPPIETAX S.A. · v196 · €{BAND_PRICE_HW.toFixed(2)} one-time · €{BAND_PRICE_SAAS.toFixed(2)}/month Lifeline SaaS
                </div>
              </div>
            </div>
            <div className={`sb-conn-badge sb-conn-badge--${bandConnPhase}`}>
              {bandConnPhase === 'idle'      && <><Bluetooth size={9} /> Not connected</>}
              {bandConnPhase === 'scanning'  && <><Signal size={9} /> Scanning…</>}
              {bandConnPhase === 'pairing'   && <><Bluetooth size={9} /> Pairing…</>}
              {bandConnPhase === 'connected' && <><CheckCircle2 size={9} /> Connected</>}
              {bandConnPhase === 'streaming' && <><Activity size={9} /> Live Stream</>}
            </div>
          </div>

          {/* Input mode selector */}
          <div className="sb-mode-selector">
            <button
              className={`sb-mode-btn${bandMode === 'camera' ? ' sb-mode-btn--active' : ''}`}
              onClick={() => { setBandMode('camera'); disconnectBand(); }}
            >
              <Camera size={13} /> 📸 Phone Camera Scan
            </button>
            <button
              className={`sb-mode-btn${bandMode === 'bluetooth' ? ' sb-mode-btn--active' : ''}`}
              onClick={() => setBandMode('bluetooth')}
            >
              <Bluetooth size={13} /> 🫀 Connect Aippie Smart Band (Bluetooth)
            </button>
          </div>

          {/* Camera mode */}
          {bandMode === 'camera' && (
            <div className="sb-camera-panel">
              <div className="sb-camera-frame">
                <Camera size={36} style={{ color: '#334155' }} />
                <span>Houd uw telefoon camera over uw pols om PPG biometrie te meten.</span>
                <span className="sb-camera-note">Gebruik de Biometrics tab voor volledige PPG-scan flow.</span>
              </div>
              <div className="sb-camera-metrics">
                {[
                  { label: 'HR', val: '74 bpm', color: '#f87171' },
                  { label: 'SpO2', val: '98%', color: '#38bdf8' },
                  { label: 'HRV', val: '58 ms', color: '#4ade80' },
                ].map(m => (
                  <div key={m.label} className="sb-camera-metric">
                    <span className="sb-camera-metric__val" style={{ color: m.color }}>{m.val}</span>
                    <span className="sb-camera-metric__label">{m.label}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Bluetooth mode */}
          {bandMode === 'bluetooth' && (
            <div className="sb-bt-panel">

              {/* LED wrist animation */}
              <div className="sb-wrist-wrap">
                <div className="sb-wrist">
                  <div className="sb-wrist__strap" style={{ background: BAND_COLORS.find(c => c.id === bandColor)?.hex ?? '#0f172a' }} />
                  <div className="sb-wrist__face">
                    <div className={`sb-led-array${bandConnPhase === 'streaming' ? ' sb-led-array--active' : ''}`}>
                      {Array.from({ length: 5 }).map((_, i) => (
                        <div key={i} className="sb-led" style={{ animationDelay: `${i * 0.18}s` }} />
                      ))}
                    </div>
                    <div className="sb-wrist__label">
                      {bandConnPhase === 'streaming' ? 'LIVE' : 'AIPPIE'}
                    </div>
                  </div>
                </div>
                <div className="sb-wrist__caption">
                  {bandConnPhase === 'streaming'
                    ? 'Groen LED-array actief · PPG 525nm · live telemetrie'
                    : 'Aippie Smart Band · Bluetooth LE · Green LED Sensor Array'}
                </div>
              </div>

              {/* Connect / disconnect button */}
              {bandConnPhase === 'idle' && (
                <button className="sb-connect-btn" onClick={startBtConnect}>
                  <Bluetooth size={13} /> Verbinden met Aippie Smart Band
                </button>
              )}
              {(bandConnPhase === 'scanning' || bandConnPhase === 'pairing' || bandConnPhase === 'connected') && (
                <div className="sb-connecting-status">
                  <Cpu size={11} className="rem-spin" style={{ color: '#38bdf8' }} />
                  <span style={{ color: '#38bdf8' }}>
                    {bandConnPhase === 'scanning'  ? 'Bluetooth LE scannen…'
                   : bandConnPhase === 'pairing'   ? 'Band koppelen…'
                   : 'Band verbonden · stream initialiseren…'}
                  </span>
                </div>
              )}
              {bandConnPhase === 'streaming' && (
                <button className="sb-disconnect-btn" onClick={disconnectBand}>
                  <RefreshCw size={11} /> Disconnect
                </button>
              )}

              {/* Bluetooth log */}
              {btLogs.length > 0 && (
                <div className="sb-bt-log">
                  <div className="sb-bt-log__header"><Bluetooth size={9} style={{ color: '#38bdf8' }} /> Bluetooth Pairing Log</div>
                  {btLogs.map((line, i) => (
                    <div key={i} className="sb-bt-log__line">
                      <span className="sb-bt-log__step">▶</span>
                      <span className="sb-bt-log__text">{line}</span>
                      {i < btLogs.length - 1 || bandConnPhase === 'streaming'
                        ? <CheckCircle2 size={9} style={{ color: '#4ade80', flexShrink: 0 }} />
                        : null}
                    </div>
                  ))}
                </div>
              )}

              {/* Live streaming metrics */}
              {bandConnPhase === 'streaming' && (
                <div className="sb-stream-metrics">
                  <div className="sb-stream-metrics__header">
                    <Activity size={10} style={{ color: '#4ade80' }} /> Live Biometrie · update elke 0.82s
                  </div>
                  <div className="sb-stream-grid">
                    {BT_STREAM_METRICS.map((m, i) => (
                      <div key={m.label} className="sb-stream-card">
                        <span className="sb-stream-card__val" style={{ color: m.color }}>
                          {streamValues[i]?.toFixed(m.unit === 'steps' ? 0 : 1)} {m.unit}
                        </span>
                        <span className="sb-stream-card__label">{m.label}</span>
                        <div className="sb-stream-bar">
                          <div
                            className="sb-stream-bar__fill"
                            style={{
                              background: m.color,
                              width: `${Math.min(100, Math.max(10, ((streamValues[i] - (m.base - m.delta * 2)) / (m.delta * 4)) * 100))}%`,
                              transition: 'width 0.82s ease',
                            }}
                          />
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Color picker */}
          <div className="sb-color-section">
            <div className="sb-section-label"><Package size={10} style={{ color: '#94a3b8' }} /> Choose your band color</div>
            <div className="sb-color-row">
              {BAND_COLORS.map(c => (
                <button
                  key={c.id}
                  className={`sb-color-btn${bandColor === c.id ? ' sb-color-btn--active' : ''}`}
                  style={{
                    '--sb-ring': c.ring,
                    background: c.hex,
                    borderColor: bandColor === c.id ? c.ring : '#1e293b',
                  } as React.CSSProperties}
                  onClick={() => setBandColor(c.id)}
                  title={c.label}
                >
                  <span className="sb-color-btn__emoji">{c.emoji}</span>
                  <span className="sb-color-btn__label">{c.label}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Pricing summary — hidden for subscribed users */}
          {!isSubscribed && (
          <div className="sb-pricing">
            <div className="sb-pricing__row">
              <ShoppingCart size={11} style={{ color: '#4ade80' }} />
              <span className="sb-pricing__item">Aippie Smart Band — {BAND_COLORS.find(c => c.id === bandColor)?.label}</span>
              <span className="sb-pricing__price" style={{ color: '#4ade80' }}>€{BAND_PRICE_HW.toFixed(2)} eenmalig</span>
            </div>
            <div className="sb-pricing__row">
              <Activity size={11} style={{ color: '#38bdf8' }} />
              <span className="sb-pricing__item">Lifeline SaaS Monitoring</span>
              <span className="sb-pricing__price" style={{ color: '#38bdf8' }}>€{BAND_PRICE_SAAS.toFixed(2)}/month</span>
            </div>
            <div className="sb-pricing__total">
              <span>Totaal vandaag</span>
              <span style={{ color: '#f59e0b', fontWeight: 900 }}>€{(BAND_PRICE_HW + BAND_PRICE_SAAS).toFixed(2)}</span>
            </div>
          </div>
          )}

          {/* Order form — card gate hidden for subscribers */}
          {bandOrderPhase !== 'confirmed' ? (
            <div className="sb-order-form">
              {!isSubscribed && (
                <>
                  <div className="sb-section-label"><CreditCard size={10} style={{ color: '#94a3b8' }} /> Betaling — 16-cijferig kaartnummer</div>
                  <div className="sb-order-input-row">
                    <input
                      className="sb-card-input"
                      placeholder="4242 4242 4242 4242"
                      maxLength={19}
                      value={bandCardInput}
                      onChange={e => {
                        const raw = e.target.value.replace(/\D/g, '').slice(0, 16);
                        setBandCardInput(raw.replace(/(.{4})/g, '$1 ').trim());
                        setBandCardErr('');
                      }}
                    />
                  </div>
                  {bandCardErr && (
                    <div className="sb-card-err"><AlertCircle size={10} /> {bandCardErr}</div>
                  )}
                  <div className="sb-card-hint">Elk 16-cijferig nummer werkt voor simulatie · bijv. 4242 4242 4242 4242</div>
                </>
              )}
              <button
                className="sb-order-btn"
                onClick={isSubscribed ? () => { setBandOrderPhase('confirmed'); speak(`Order placed. Aippie Smart Band in ${BAND_COLORS.find(c => c.id === bandColor)?.label} is being shipped. Thank you.`); } : handleBandOrder}
                disabled={bandOrderPhase === 'processing' || (!isSubscribed && bandCardInput.replace(/\s/g, '').length < 16)}
                style={{ width: '100%', marginTop: 8 }}
              >
                {bandOrderPhase === 'processing'
                  ? <><Cpu size={11} className="rem-spin" /> Verwerken…</>
                  : <><ShoppingCart size={11} /> Order Smart Band Hardware</>}
              </button>
            </div>
          ) : (
            <div className="sb-order-confirmed">
              <CheckCircle2 size={18} style={{ color: '#4ade80' }} />
              <div>
                <div className="sb-order-confirmed__title">Order confirmed!</div>
                <div className="sb-order-confirmed__sub">
                  Aippie Smart Band ({BAND_COLORS.find(c => c.id === bandColor)?.label}) · ships within 2-3 business days
                </div>
                <div className="sb-order-confirmed__sub">
                  Lifeline SaaS automatically activated · €{BAND_PRICE_SAAS.toFixed(2)}/month
                </div>
              </div>
            </div>
          )}

          <div className="sb-footer">
            <Watch size={8} style={{ color: '#4ade80' }} />
            AIPPIETAX S.A. · Aippie Smart Band · Bluetooth LE · v196 · Simulatie-modus
          </div>
        </div>
      )}

      {/* ══════════════════════════════════════════════════════════════════
          TAB 8: ELYSIUM DIAGNOSTIC SIMULATION PANEL (V194)
          Three fused tracks: 3D Contour · PPG Waveform · Clinical AI
      ══════════════════════════════════════════════════════════════════ */}
      {activeTab === 'elysium' && (
        <div className="doc-tab-panel">

          {/* Panel header */}
          <div className="ely-header">
            <div className="ely-header__left">
              <Scan size={14} style={{ color: '#a78bfa' }} />
              <div>
                <div className="ely-header__title">Elysium Diagnostic Simulation Panel</div>
                <div className="ely-header__sub">
                  AIPPIETAX S.A. · v196 · Triple-Track Fusion · Deep-Learning Clinical Matrix
                </div>
              </div>
            </div>
            <div className={`ely-phase-badge ely-phase-badge--${elysiumScanPhase}`}>
              {elysiumScanPhase === 'idle'     && 'STANDBY'}
              {elysiumScanPhase === 'scanning' && 'INITIALIZING…'}
              {elysiumScanPhase === 'active'   && 'ACTIVE'}
              {elysiumScanPhase === 'anomaly'  && '⚠ ANOMALY'}
            </div>
          </div>

          {/* Process status tracking labels */}
          <div className="ely-status-bar">
            <div className={`ely-status-chip ely-status-chip--track1 ely-status-chip--${elysiumTrack1}`}>
              <div className="ely-status-chip__dot" />
              📸 3D Contour Analytics: {elysiumTrack1 === 'active' || elysiumTrack1 === 'anomaly' ? 'Active' : 'Initializing'}
            </div>
            <div className={`ely-status-chip ely-status-chip--track2 ely-status-chip--${elysiumTrack2}`}>
              <div className="ely-status-chip__dot" />
              🫀 Continuous HRV Stream: {elysiumTrack2 === 'active' || elysiumTrack2 === 'anomaly' ? 'Connected' : 'Initializing'}
            </div>
            <div className={`ely-status-chip ely-status-chip--track3 ely-status-chip--${elysiumTrack3}`}>
              <div className="ely-status-chip__dot" />
              🧠 Clinical Diagnostic Matrix: {elysiumTrack3 === 'active' || elysiumTrack3 === 'anomaly' ? 'Operational' : 'Initializing'}
            </div>
          </div>

          {/* Launch / stop controls */}
          {elysiumScanPhase === 'idle' ? (
            <button className="ely-start-btn" onClick={startElysiumScan}>
              <Scan size={13} /> Start Diagnostic Scan
            </button>
          ) : (
            <button className="ely-stop-btn" onClick={stopElysiumScan}>
              <RotateCcw size={11} /> Reset
            </button>
          )}

          {/* Critical anomaly banner */}
          {elysiumScanPhase === 'anomaly' && (
            <div className="ely-anomaly-banner">
              <ShieldAlert size={14} style={{ color: '#f87171' }} />
              <div>
                <div className="ely-anomaly-banner__title">Kritieke Anomalie Gedetecteerd</div>
                <div className="ely-anomaly-banner__sub">
                  Automatische omleiding naar Nooddispatch & Specialist Consult Dashboard…
                </div>
              </div>
              <button className="ely-anomaly-goto" onClick={() => setActiveTab('heartAlert')}>
                Ga naar Nooddashboard <ChevronRight size={10} />
              </button>
            </div>
          )}

          {/* ── TRACK 1: 3D Body Contour Visual Computer Vision ────────────── */}
          {(elysiumScanPhase === 'scanning' || elysiumScanPhase === 'active' || elysiumScanPhase === 'anomaly') && (
            <div className={`ely-track ely-track--1 ely-track--${elysiumTrack1}`}>
              <div className="ely-track__header">
                <Scan size={11} style={{ color: '#a78bfa' }} />
                <span>Track 1 — Visual Computer Vision · 3D Body Contour Scanning</span>
                <div className={`ely-track__status ely-track__status--${elysiumTrack1}`}>
                  {elysiumTrack1 === 'initializing' ? 'Laden…' : elysiumTrack1 === 'anomaly' ? '⚠ Anomalie' : '✓ Actief'}
                </div>
              </div>

              <div className="ely-body-scan">
                {/* SVG silhouette with coordinate overlay */}
                <svg viewBox="0 0 60 110" className="ely-body-svg" aria-hidden="true">
                  {/* Simplified body outline paths */}
                  <ellipse cx="30" cy="10" rx="9" ry="10" className="ely-body-shape" />
                  <rect x="18" y="20" width="24" height="30" rx="4" className="ely-body-shape" />
                  <rect x="4"  y="22" width="14" height="24" rx="4" className="ely-body-shape" />
                  <rect x="42" y="22" width="14" height="24" rx="4" className="ely-body-shape" />
                  <rect x="20" y="50" width="10" height="32" rx="3" className="ely-body-shape" />
                  <rect x="30" y="50" width="10" height="32" rx="3" className="ely-body-shape" />
                  <rect x="19" y="82" width="10" height="24" rx="3" className="ely-body-shape" />
                  <rect x="31" y="82" width="10" height="24" rx="3" className="ely-body-shape" />
                  {/* Landmark dots */}
                  {bodyCoords.map((c, i) => (
                    <g key={i}>
                      <circle
                        cx={30 + c.x * 0.28}
                        cy={c.y}
                        r={c.risk === 'critical' ? 2.5 : c.risk === 'warn' ? 2 : 1.5}
                        fill={c.risk === 'critical' ? '#f87171' : c.risk === 'warn' ? '#fbbf24' : '#a78bfa'}
                        opacity={0.85}
                      />
                      {c.risk !== 'ok' && (
                        <circle
                          cx={30 + c.x * 0.28}
                          cy={c.y}
                          r={4}
                          fill="none"
                          stroke={c.risk === 'critical' ? '#f87171' : '#fbbf24'}
                          strokeWidth={0.5}
                          opacity={0.4}
                        />
                      )}
                    </g>
                  ))}
                  {/* Scan line animation */}
                  {elysiumTrack1 === 'active' && (
                    <line x1="0" y1="0" x2="60" y2="0" stroke="#a78bfa" strokeWidth="0.5" opacity="0.5" className="ely-scan-line" />
                  )}
                </svg>

                {/* Coordinate data table */}
                <div className="ely-coords-table">
                  <div className="ely-coords-table__header">Coordinate Array · {bodyCoords.length} landmarks</div>
                  <div className="ely-coords-scroll">
                    {bodyCoords.slice(0, 10).map((c, i) => (
                      <div key={i} className="ely-coord-row">
                        <span className="ely-coord-row__label">{c.label}</span>
                        <span className="ely-coord-row__xyz" style={{ fontFamily: 'monospace', fontSize: 13 }}>
                          x:{c.x.toFixed(1)} y:{c.y.toFixed(1)} z:{c.z.toFixed(1)}
                        </span>
                        <span className={`ely-coord-row__risk ely-coord-row__risk--${c.risk}`}>
                          {c.risk === 'ok' ? '✓' : c.risk === 'warn' ? '⚠' : '✕'}
                        </span>
                      </div>
                    ))}
                    {bodyCoords.length > 10 && (
                      <div className="ely-coord-more">+{bodyCoords.length - 10} meer landmarks…</div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* ── TRACK 2: Hardware Telemetry · Bluetooth PPG Waveform ───────── */}
          {(elysiumScanPhase === 'scanning' || elysiumScanPhase === 'active' || elysiumScanPhase === 'anomaly') && (
            <div className={`ely-track ely-track--2 ely-track--${elysiumTrack2}`}>
              <div className="ely-track__header">
                <Activity size={11} style={{ color: '#f87171' }} />
                <span>Track 2 — Hardware Telemetry · Bluetooth PPG Heart Rate Waveform</span>
                <div className={`ely-track__status ely-track__status--${elysiumTrack2}`}>
                  {elysiumTrack2 === 'initializing' ? 'Laden…' : elysiumTrack2 === 'anomaly' ? '⚠ Anomalie' : '✓ Verbonden'}
                </div>
              </div>

              {/* Live vital metrics */}
              <div className="ely-vitals-row">
                {[
                  { label: 'Hartslag', val: `${elysiumHR} bpm`,    color: '#f87171', warn: elysiumHR > 95 || elysiumHR < 50 },
                  { label: 'HRV',      val: `${elysiumHRV} ms`,    color: '#38bdf8', warn: elysiumHRV < 28 },
                  { label: 'SpO2',     val: `${elysiumSpO2}%`,     color: '#4ade80', warn: elysiumSpO2 < 93 },
                ].map(v => (
                  <div key={v.label} className={`ely-vital-card${v.warn ? ' ely-vital-card--warn' : ''}`}>
                    <span className="ely-vital-card__val" style={{ color: v.warn ? '#f87171' : v.color }}>{v.val}</span>
                    <span className="ely-vital-card__label">{v.label}</span>
                    {v.warn && <span className="ely-vital-card__warn">⚠</span>}
                  </div>
                ))}
              </div>

              {/* PPG waveform canvas */}
              <div className="ely-ppg-wrap">
                <div className="ely-ppg-label">
                  <Heart size={8} style={{ color: '#f87171' }} /> PPG Waveform · BLE 2.4 GHz · 525nm LED
                </div>
                <svg viewBox={`0 0 ${PPG_WAVEFORM_POINTS} 40`} className="ely-ppg-svg" preserveAspectRatio="none">
                  <defs>
                    <linearGradient id="ppgGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="#f87171" stopOpacity="0.4" />
                      <stop offset="100%" stopColor="#f87171" stopOpacity="0.02" />
                    </linearGradient>
                  </defs>
                  {ppgWave.length > 1 && (() => {
                    const pts = ppgWave.map((s, i) => `${i},${20 - s.value * 16}`).join(' ');
                    const areaPts = `0,38 ${pts} ${ppgWave.length - 1},38`;
                    return (
                      <>
                        <polyline points={areaPts} fill="url(#ppgGrad)" />
                        <polyline points={pts} fill="none" stroke="#f87171" strokeWidth="0.7" />
                      </>
                    );
                  })()}
                  {/* Grid lines */}
                  {[10, 20, 30].map(y => (
                    <line key={y} x1="0" y1={y} x2={PPG_WAVEFORM_POINTS} y2={y} stroke="#1e293b" strokeWidth="0.3" />
                  ))}
                </svg>
              </div>
            </div>
          )}

          {/* ── TRACK 3: Clinical AI · Symptom Input & Diagnostic Engine ─────── */}
          {(elysiumScanPhase === 'scanning' || elysiumScanPhase === 'active' || elysiumScanPhase === 'anomaly') && (
            <div className={`ely-track ely-track--3 ely-track--${elysiumTrack3}`}>
              <div className="ely-track__header">
                <Brain size={11} style={{ color: '#38bdf8' }} />
                <span>Track 3 — Clinical AI Logic · Deep-Learning Diagnostic Engine</span>
                <div className={`ely-track__status ely-track__status--${elysiumTrack3}`}>
                  {elysiumTrack3 === 'initializing' ? 'Laden…' : elysiumTrack3 === 'anomaly' ? '⚠ Kritiek' : '✓ Operationeel'}
                </div>
              </div>

              <div className="ely-symptom-area">
                {/* Text input */}
                <div className="ely-symptom-input-row">
                  <textarea
                    className="ely-symptom-input"
                    placeholder="Beschrijf uw symptomen… bijv. pijn op de borst, kortademig, duizelig"
                    value={symptomInput}
                    rows={3}
                    onChange={e => setSymptomInput(e.target.value)}
                    onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); analyseSymptom(); } }}
                    disabled={elysiumTrack3 === 'initializing'}
                  />
                  <div className="ely-symptom-btns">
                    <button
                      className="ely-analyse-btn"
                      onClick={analyseSymptom}
                      disabled={!symptomInput.trim() || symptomProcessing || elysiumTrack3 === 'initializing'}
                    >
                      {symptomProcessing
                        ? <><Cpu size={11} className="rem-spin" /> Analyseren…</>
                        : <><Brain size={11} /> Analyseer</>}
                    </button>
                    <button
                      className="ely-voice-analyse-btn"
                      onClick={() => {
                        if (!('webkitSpeechRecognition' in window || 'SpeechRecognition' in window)) return;
                        const SR = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
                        const r = new SR();
                        r.lang = 'nl-NL';
                        r.onresult = (e: any) => {
                          const t = e.results[0][0].transcript;
                          setSymptomInput(t);
                        };
                        r.start();
                      }}
                      title="Spreek uw symptomen in"
                    >
                      <Mic size={11} />
                    </button>
                  </div>
                </div>

                {/* Diagnostic response */}
                {symptomResponse && (
                  <div className="ely-diag-response">
                    <div className="ely-diag-response__header">
                      <Brain size={9} style={{ color: '#38bdf8' }} /> Klinische AI-Analyse
                    </div>
                    <div className="ely-diag-response__text">{symptomResponse}</div>
                    <div className="ely-diag-response__disclaimer">
                      <AlertCircle size={8} style={{ color: '#fbbf24' }} />
                      AI-simulatie · geen officiële medische diagnose · raadpleeg altijd uw huisarts
                    </div>
                  </div>
                )}

                {/* Quick symptom chips */}
                <div className="ely-chip-row">
                  {['Pijn op borst', 'Kortademig', 'Duizelig', 'Hoofdpijn', 'Koorts', 'Vermoeid'].map(chip => (
                    <button
                      key={chip}
                      className="ely-chip"
                      onClick={() => setSymptomInput(chip.toLowerCase())}
                      disabled={elysiumTrack3 === 'initializing'}
                    >
                      {chip}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          <div className="ely-footer">
            <Scan size={8} style={{ color: '#a78bfa' }} />
            AIPPIETAX S.A. · Elysium Diagnostisch Simulatiepaneel · v196 · Simulatie-modus · Geen officiële medische diagnose
          </div>
        </div>
      )}

      <FatigueCompanion />
      <AippieVoiceOverlay context="doctor" />

      {/* ══════════════════════════════════════════════════════════════════
          TAB: AUTISM & BEHAVIORAL ANALYSIS
      ══════════════════════════════════════════════════════════════════ */}
      {activeTab === 'autism' && <AutismBehavioralPanel speak={speak} />}
    </div>
  );
}
