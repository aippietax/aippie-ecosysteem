// @ts-nocheck
/**
 * PulseCameraView — rPPG heart rate + SpO2 estimation via device camera.
 * Aippie speaks the full health summary out loud after each measurement.
 */
import { useCallback, useEffect, useRef, useState } from 'react';
import { Heart, Droplets, Activity, AlertTriangle, Zap, Volume2, Mic, Phone } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { applyPremiumVoice, normalizeForTTS, withVoicesReady } from '../lib/ttsVoice';
import { getStoredLang } from '../lib/i18n';

interface ParentContact { id: string; label: string; phone: string; }

// ── Signal processing ─────────────────────────────────────────────────────────

function detrend(signal: number[]): number[] {
  const n = signal.length;
  const mean = signal.reduce((a, b) => a + b, 0) / n;
  // Linear detrend: remove both mean and slope
  const xs = signal.map((_, i) => i);
  const xMean = (n - 1) / 2;
  const slope =
    xs.reduce((sum, x, i) => sum + (x - xMean) * (signal[i] - mean), 0) /
    xs.reduce((sum, x) => sum + (x - xMean) ** 2, 0);
  return signal.map((v, i) => v - mean - slope * (i - xMean));
}

// DFT magnitude over a frequency range — returns { freq, power } for dominant bin
function dominantFreq(signal: number[], sampleRate: number): number {
  const N = signal.length;
  const det = detrend(signal);

  const minK = Math.max(1, Math.floor((0.65 * N) / sampleRate)); // ~39 BPM
  const maxK = Math.ceil((4.2 * N) / sampleRate);                 // ~252 BPM

  let best = 0;
  let bestPow = -1;

  for (let k = minK; k <= maxK; k++) {
    let re = 0, im = 0;
    const step = (2 * Math.PI * k) / N;
    for (let n = 0; n < N; n++) {
      re += det[n] * Math.cos(step * n);
      im -= det[n] * Math.sin(step * n);
    }
    const pow = re * re + im * im;
    if (pow > bestPow) { bestPow = pow; best = k; }
  }

  return (best * sampleRate) / N; // Hz
}

function acDcAmplitude(buf: number[]): { ac: number; dc: number } {
  const dc = buf.reduce((a, b) => a + b, 0) / buf.length;
  const ac = Math.max(...buf) - Math.min(...buf);
  return { ac, dc };
}

// SpO2 from R/G ratio using empirical formula (Beer-Lambert approximation)
function estimateSpO2(reds: number[], greens: number[]): number {
  const r = acDcAmplitude(reds);
  const g = acDcAmplitude(greens);
  if (r.dc < 10 || g.dc < 10 || g.ac < 0.01) return 0;
  const R = (r.ac / r.dc) / (g.ac / g.dc);
  // Empirical calibration curve (Mendelson & Ochs 1988 adaptation for green proxy)
  const spo2 = Math.round(110 - 25 * R);
  return Math.min(100, Math.max(85, spo2));
}

// ── Health summary voice generator ───────────────────────────────────────────

function buildHealthSummary(r: { bpm: number; spo2: number; hrv: number }, lang: string): string {
  const nl = lang === 'nl';

  // Heart rate
  let bpmMsg: string;
  if (r.bpm < 55) {
    bpmMsg = `Your heart rate is ${r.bpm} beats per minute. That is a little low. Your body is very relaxed, but try to move around more to make your heart stronger!`;
  } else if (r.bpm <= 100) {
    bpmMsg = `Your heart rate is ${r.bpm} beats per minute. That is perfectly normal! Your heart is beating wonderfully and is very strong.`;
  } else if (r.bpm <= 120) {
    bpmMsg = `Your heart rate is ${r.bpm} beats per minute. That is slightly elevated. Try to breathe calmly. Breathe deeply in... and slowly out. You can do it!`;
  } else {
    bpmMsg = `Your heart rate is ${r.bpm} beats per minute. That is quite high. Please sit down and breathe slowly. If this continues, please tell mom or dad.`;
  }

  // SpO2
  let spo2Msg: string;
  if (r.spo2 >= 97) {
    spo2Msg = `Your blood oxygen is ${r.spo2} percent. Excellent! You are breathing very well. Your lungs are strong and healthy!`;
  } else if (r.spo2 >= 95) {
    spo2Msg = `Your oxygen is ${r.spo2} percent. That is a little low. Sit up straight and take a few deep breaths through your nose. That will bring your oxygen up!`;
  } else {
    spo2Msg = `Your oxygen is ${r.spo2} percent. That is low. Sit up straight and breathe deeply through your nose. Please tell mom or dad so they can help you!`;
  }

  // Stress / HRV
  let stressMsg: string;
  if (r.hrv >= 40) {
    stressMsg = `Your stress level is low. You are very relaxed and calm inside. Wonderful! That is great.`;
  } else if (r.hrv >= 20) {
    stressMsg = `You have some tension in your body. That is completely normal. Try to do something fun that relaxes you. Maybe drawing, listening to music, or playing outside.`;
  } else {
    stressMsg = `I can see you are stressed. That is okay, I am right here with you. Breathe slowly in and out. We will work through this together. You are not alone.`;
  }

  // Personalised advice
  let advice: string;
  if (r.bpm > 100 && r.hrv < 25) {
    advice = `My advice for you today: please get some good rest. Your body needs it right now. Find a quiet and comfortable place to sit or lie down.`;
  } else if (r.bpm < 60) {
    advice = `My advice: try to move around more today! A short walk outside or dancing to music does wonders for your body and your mood.`;
  } else if (r.spo2 < 96) {
    advice = `My advice: drink some water and sit up straight. Eating and drinking well keeps your body strong. Make sure you eat enough vegetables!`;
  } else if (r.bpm > 105) {
    advice = `My advice: you might not be feeling completely well today. Please tell mom or dad. They really want to help you!`;
  } else {
    advice = `My advice: keep eating well, drinking enough water, and getting enough sleep. You are doing great! Your body is strong and healthy.`;
  }

  // Closing
  const closing = `I am so incredibly proud of you! You did so wonderfully well. I am always here for you, every single day, always.`;

  return [bpmMsg, spo2Msg, stressMsg, advice, closing].join(' ');
}

// ── Component ─────────────────────────────────────────────────────────────────

const MEASURE_SECS = 20;
const DFT_WINDOW   = 256; // samples used for DFT

type Phase = 'idle' | 'detecting' | 'recording' | 'result' | 'error';

interface Reading {
  bpm: number;
  spo2: number;
  hrv: number;
  quality: 'good' | 'fair';
}

interface Props {
  deviceKey?: string;
  sessionId?: string;
}

export default function PulseCameraView({ deviceKey = 'anon', sessionId = 'anon' }: Props) {
  const videoRef   = useRef<HTMLVideoElement>(null);
  const canvasRef  = useRef<HTMLCanvasElement>(null);
  const streamRef  = useRef<MediaStream | null>(null);
  const rafRef     = useRef(0);
  const phaseRef   = useRef<Phase>('idle');
  const redBuf     = useRef<number[]>([]);
  const greenBuf   = useRef<number[]>([]);
  const startTime  = useRef(0);
  const lastSample = useRef(0);

  const [phase,         setPhase]         = useState<Phase>('idle');
  const [secondsLeft,   setSecondsLeft]   = useState(MEASURE_SECS);
  const [fingerOn,      setFingerOn]      = useState(false);
  const [beatAnim,      setBeatAnim]      = useState(false);
  const [signalLevel,   setSignalLevel]   = useState(0);
  const [result,        setResult]        = useState<Reading | null>(null);
  const [errorMsg,      setErrorMsg]      = useState('');
  const [history,       setHistory]       = useState<Reading[]>([]);
  const [speaking,      setSpeaking]      = useState(false);
  const [caption,       setCaption]       = useState('');
  const [parentContacts, setParentContacts] = useState<ParentContact[]>([]);
  const [showParentAlert, setShowParentAlert] = useState(false);
  const [parentAlertMsg,  setParentAlertMsg]  = useState('');

  const changePhase = (p: Phase) => { phaseRef.current = p; setPhase(p); };
  const lang = getStoredLang();

  // Load parent contacts
  useEffect(() => {
    if (deviceKey === 'anon') return;
    supabase.from('parent_contacts')
      .select('id, label, phone')
      .eq('device_key', deviceKey)
      .then(({ data }) => { if (data) setParentContacts(data); });
  }, [deviceKey]);

  const speak = useCallback((text: string) => {
    if (!('speechSynthesis' in window)) return;
    window.speechSynthesis.cancel();
    setSpeaking(true);
    setCaption(text);
    withVoicesReady(() => {
      const u = new SpeechSynthesisUtterance(normalizeForTTS(text));
      u.lang = lang === 'nl' ? 'nl-NL' : 'en-US';
      u.rate = 0.75;
      u.pitch = 1.1;
      applyPremiumVoice(u, u.lang);
      u.onend = u.onerror = () => { setSpeaking(false); setCaption(''); };
      window.speechSynthesis.speak(u);
    });
    setTimeout(() => { setSpeaking(false); setCaption(''); }, Math.max(text.length * 85, 6000));
  }, [lang]);


  // ── Frame processing ──────────────────────────────────────────────────────
  const processResult = useCallback(() => {
    const reds   = [...redBuf.current];
    const greens = [...greenBuf.current];

    if (reds.length < 60) {
      setErrorMsg('Not enough data. Make sure your finger covers the lens.');
      changePhase('error');
      return;
    }

    const usedReds   = reds.slice(-DFT_WINDOW);
    const usedGreens = greens.slice(-DFT_WINDOW);
    const sr         = reds.length / MEASURE_SECS;

    const freqHz = dominantFreq(usedReds, sr);
    const bpm    = Math.round(freqHz * 60);

    const spo2 = estimateSpO2(usedReds.slice(-60), usedGreens.slice(-60));

    // HRV: std-dev of local amplitude windows (rough proxy)
    const chunks: number[] = [];
    const w = Math.floor(sr);
    for (let i = 0; i + w < usedReds.length; i += w) {
      chunks.push(acDcAmplitude(usedReds.slice(i, i + w)).ac);
    }
    const chunkMean = chunks.reduce((a, b) => a + b, 0) / (chunks.length || 1);
    const hrv = Math.round(
      Math.sqrt(chunks.reduce((s, c) => s + (c - chunkMean) ** 2, 0) / (chunks.length || 1)) * 10
    );

    const clampedBpm  = Math.min(200, Math.max(35, bpm));
    const clampedSpo2 = spo2 || 97;
    const clampedHrv  = Math.min(80, Math.max(10, hrv));
    const quality: Reading['quality'] = clampedBpm >= 45 && clampedBpm <= 160 ? 'good' : 'fair';

    const reading: Reading = { bpm: clampedBpm, spo2: clampedSpo2, hrv: clampedHrv, quality };
    setResult(reading);
    setHistory(h => [reading, ...h].slice(0, 5));
    changePhase('result');

    // Aippie speaks the full health summary automatically after 800ms
    setTimeout(() => {
      speak(buildHealthSummary(reading, lang));
    }, 800);

    // If stress is high (low HRV or elevated BPM), offer to notify parent
    const isStressed = clampedHrv < 20 || clampedBpm > 110;
    const isEmergency = clampedBpm > 130 || clampedSpo2 < 93;
    if (isStressed || isEmergency) {
      const alertMsg = lang === 'nl'
        ? `${isEmergency ? '🚨 EMERGENCY! ' : '⚠️ '}Your child measurement: heart rate ${clampedBpm} bpm, SpO2 ${clampedSpo2}%, HRV ${clampedHrv}ms. ${isEmergency ? 'POSSIBLE MEDICAL EMERGENCY — check your child immediately!' : 'Your child seems stressed. Please check how they are.'}`
        : `${isEmergency ? '🚨 EMERGENCY! ' : '⚠️ '}Your child measurement: heart rate ${clampedBpm} bpm, SpO2 ${clampedSpo2}%, HRV ${clampedHrv}ms. ${isEmergency ? 'POSSIBLE MEDICAL EMERGENCY — check your child immediately!' : 'Your child seems stressed. Please check how they are.'}`;
      setParentAlertMsg(alertMsg);
      setShowParentAlert(true);
    }

    supabase.from('pulse_readings').insert({
      device_key: deviceKey, session_id: sessionId,
      bpm: clampedBpm, spo2: clampedSpo2, hrv_ms: clampedHrv, quality,
    }).catch(() => {});
  }, [deviceKey, sessionId, speak, lang]);

  const loop = useCallback(() => {
    const video  = videoRef.current;
    const canvas = canvasRef.current;
    if (!video || !canvas || video.readyState < 2) {
      rafRef.current = requestAnimationFrame(loop);
      return;
    }

    const now = performance.now();
    // ~30 fps throttle
    if (now - lastSample.current < 33) {
      rafRef.current = requestAnimationFrame(loop);
      return;
    }
    lastSample.current = now;

    const ctx = canvas.getContext('2d')!;
    canvas.width = 8; canvas.height = 8;
    ctx.drawImage(video, 0, 0, 8, 8);
    const px = ctx.getImageData(0, 0, 8, 8).data;

    let r = 0, g = 0, b = 0;
    for (let i = 0; i < px.length; i += 4) { r += px[i]; g += px[i + 1]; b += px[i + 2]; }
    const n = px.length / 4;
    r /= n; g /= n; b /= n;

    // Finger detection: high red, low blue, warm hue
    const isFinger = r > 100 && b < 90 && r > g * 1.2 && r > 60;
    setFingerOn(isFinger);
    setSignalLevel(Math.round((r / 255) * 100));

    const p = phaseRef.current;

    if (p === 'detecting') {
      if (isFinger) {
        redBuf.current.push(r);
        greenBuf.current.push(g);
        if (redBuf.current.length >= 8) {
          redBuf.current = [];
          greenBuf.current = [];
          startTime.current = now;
          changePhase('recording');
        }
      }
    } else if (p === 'recording') {
      if (isFinger) {
        redBuf.current.push(r);
        greenBuf.current.push(g);

        // Beat animation every ~second
        if (redBuf.current.length % 28 === 0) {
          setBeatAnim(true);
          setTimeout(() => setBeatAnim(false), 180);
        }
      }

      const elapsed = (now - startTime.current) / 1000;
      setSecondsLeft(Math.max(0, Math.ceil(MEASURE_SECS - elapsed)));

      if (elapsed >= MEASURE_SECS) {
        cancelAnimationFrame(rafRef.current);
        processResult();
        return;
      }
    }

    rafRef.current = requestAnimationFrame(loop);
  }, [processResult]);

  useEffect(() => {
    if (phase === 'detecting' || phase === 'recording') {
      rafRef.current = requestAnimationFrame(loop);
    }
    return () => cancelAnimationFrame(rafRef.current);
  }, [phase, loop]);

  useEffect(() => () => {
    cancelAnimationFrame(rafRef.current);
    streamRef.current?.getTracks().forEach(t => t.stop());
  }, []);

  // ── Start / Stop ──────────────────────────────────────────────────────────
  const start = async () => {
    setErrorMsg('');
    setResult(null);
    redBuf.current = [];
    greenBuf.current = [];
    setSecondsLeft(MEASURE_SECS);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment', width: { ideal: 320 }, height: { ideal: 240 } },
        audio: false,
      });
      streamRef.current = stream;

      // Try to enable torch (Android Chrome)
      const track = stream.getVideoTracks()[0];
      try {
        const caps = track.getCapabilities() as MediaTrackCapabilities & { torch?: boolean };
        if (caps.torch) await track.applyConstraints({ advanced: [{ torch: true } as MediaTrackConstraintSet] });
      } catch { /* torch not supported */ }

      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        await videoRef.current.play();
      }
      changePhase('detecting');
    } catch {
      setErrorMsg('Camera toegang geweigerd. Klik op het slotje in de adresbalk.');
      changePhase('error');
    }
  };

  const stop = () => {
    cancelAnimationFrame(rafRef.current);
    streamRef.current?.getTracks().forEach(t => t.stop());
    streamRef.current = null;
    redBuf.current = [];
    greenBuf.current = [];
    changePhase('idle');
  };

  // ── Colours ───────────────────────────────────────────────────────────────
  const bpmCol  = !result ? '#4ade80' : result.bpm < 55 || result.bpm > 110 ? '#f87171' : result.bpm > 95 ? '#fbbf24' : '#4ade80';
  const spo2Col = !result ? '#38bdf8' : result.spo2 < 94 ? '#f87171' : result.spo2 < 97 ? '#fbbf24' : '#38bdf8';
  const hrvCol  = !result ? '#a78bfa' : result.hrv < 20 ? '#fbbf24' : '#a78bfa';

  const progress = ((MEASURE_SECS - secondsLeft) / MEASURE_SECS) * 100;

  return (
    <div className="px-root">
      {/* Hidden media */}
      <video ref={videoRef} style={{ display: 'none' }} playsInline muted />
      <canvas ref={canvasRef} style={{ display: 'none' }} />

      {/* Parent alert banner */}
      {showParentAlert && (
        <div className="px-parent-alert">
          <div className="px-parent-alert__msg">
            <AlertTriangle size={13} style={{ color: '#fbbf24', flexShrink: 0 }} />
            <span>{parentAlertMsg}</span>
          </div>
          {parentContacts.length > 0 && (
            <div className="px-parent-alert__contacts">
              {parentContacts.map(c => (
                <div key={c.id} className="px-parent-alert__row">
                  <span className="px-parent-alert__name">{c.label}</span>
                  <a href={`tel:${c.phone}`} className="px-parent-alert__btn px-parent-alert__btn--call">
                    <Phone size={12} /> {lang === 'nl' ? 'Call' : 'Call'}
                  </a>
                </div>
              ))}
            </div>
          )}
          <button className="px-parent-alert__close" onClick={() => setShowParentAlert(false)}>
            {lang === 'nl' ? 'Close' : 'Close'}
          </button>
        </div>
      )}

      <div className="px-header">
        <Heart size={13} style={{ color: '#f87171' }} />
        <span>Heart Rate &amp; Oxygen · rPPG Measurement</span>
        <span className="px-badge">CAMERA</span>
      </div>
      <div className="px-disclaimer">
        <AlertTriangle size={9} />
        <span>Indicative — not a medical device</span>
      </div>

      {/* ── IDLE ── */}
      {(phase === 'idle' || phase === 'error') && (
        <div className="px-idle">
          <div className="px-idle__visual">
            <div className="px-idle__ring">
              <span className="px-idle__finger">👆</span>
            </div>
          </div>
          <p className="px-idle__title">Place your finger on the camera</p>
          <p className="px-idle__sub">
            Completely cover the rear camera with your fingertip.
            Aippie measures your heart rate and oxygen levels via light reflection.
          </p>
          {errorMsg && (
            <div className="px-error-msg">
              <AlertTriangle size={12} /> {errorMsg}
            </div>
          )}
          <button className="px-btn-start" onClick={start}>
            <Heart size={15} /> Start measurement
          </button>

          {history.length > 0 && (
            <div className="px-history">
              <div className="px-history__title">Recent measurements</div>
              {history.map((h, i) => (
                <div key={i} className="px-history__row">
                  <span style={{ color: '#f87171' }}>♥ {h.bpm} BPM</span>
                  <span style={{ color: '#38bdf8' }}>O₂ {h.spo2}%</span>
                  <span style={{ color: '#a78bfa' }}>HRV {h.hrv}ms</span>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* ── DETECTING ── */}
      {phase === 'detecting' && (
        <div className="px-detecting">
          <div className={`px-detect-ring${fingerOn ? ' px-detect-ring--on' : ''}`}>
            <span className="px-detect-ring__emoji">👆</span>
            <span className="px-detect-ring__label">
              {fingerOn ? 'Finger recognized!' : 'Place finger on camera…'}
            </span>
          </div>
          <div className="px-signal-bar">
            <div className="px-signal-bar__label">Signal</div>
            <div className="px-signal-bar__track">
              <div
                className="px-signal-bar__fill"
                style={{
                  width: `${signalLevel}%`,
                  background: fingerOn ? '#f87171' : '#475569',
                }}
              />
            </div>
            <div className="px-signal-bar__val">{signalLevel}%</div>
          </div>
          <p className="px-hint">Fully cover the lens — the screen will turn reddish</p>
          <button className="px-btn-stop" onClick={stop}>Cancel</button>
        </div>
      )}

      {/* ── RECORDING ── */}
      {phase === 'recording' && (
        <div className="px-recording">
          <div className={`px-heart-anim${beatAnim ? ' px-heart-anim--beat' : ''}`}>
            <Heart size={44} style={{ color: '#f87171' }} />
          </div>
          <div className="px-countdown">{secondsLeft}s</div>
          <p className="px-recording__txt">Measurement in progress… keep finger still on camera</p>

          <div className="px-progress-wrap">
            <div className="px-progress-track">
              <div className="px-progress-fill" style={{ width: `${progress}%` }} />
            </div>
            <span className="px-progress-pct">{Math.round(progress)}%</span>
          </div>

          <div className="px-signal-bar">
            <div className="px-signal-bar__label">Red signal</div>
            <div className="px-signal-bar__track">
              <div className="px-signal-bar__fill" style={{ width: `${signalLevel}%`, background: '#f87171' }} />
            </div>
            <div className="px-signal-bar__val">{signalLevel}%</div>
          </div>

          <div className="px-samples">
            <Zap size={10} style={{ color: '#fbbf24' }} />
            {redBuf.current.length} samples · {Math.round(redBuf.current.length / MEASURE_SECS * 10) / 10} fps
          </div>

          <button className="px-btn-stop" onClick={stop}>Stop</button>
        </div>
      )}

      {/* ── RESULT ── */}
      {phase === 'result' && result && (
        <div className="px-result">

          {/* Aippie speaking companion banner */}
          <div className={`px-aippie-banner${speaking ? ' px-aippie-banner--active' : ''}`}>
            <div className="px-aippie-banner__orb">
              {speaking ? <Mic size={13} style={{ color: '#fff' }} /> : <span style={{ fontSize: 16 }}>🤖</span>}
            </div>
            <div className="px-aippie-banner__content">
              {speaking && caption
                ? <span className="px-aippie-banner__caption">{caption}</span>
                : <span className="px-aippie-banner__idle">
                    {lang === 'nl' ? 'Tap "Repeat explanation" to hear Aippie again' : 'Tap "Repeat explanation" to hear Aippie again'}
                  </span>}
            </div>
            {speaking && (
              <div className="px-aippie-banner__waves">
                {[0,1,2,3,4].map(i => (
                  <div key={i} className="px-aippie-banner__bar" style={{ animationDelay: `${i * 0.1}s` }} />
                ))}
              </div>
            )}
          </div>

          <div className="px-result__quality">
            <span style={{ color: result.quality === 'good' ? '#4ade80' : '#fbbf24' }}>
              ● {result.quality === 'good' ? 'Good reading' : 'Fair reading'}
            </span>
          </div>

          <div className="px-metrics">
            {/* Heart rate */}
            <div className="px-metric">
              <div className="px-metric__icon" style={{ color: bpmCol }}>
                <Heart size={22} />
              </div>
              <div className="px-metric__value" style={{ color: bpmCol }}>{result.bpm}</div>
              <div className="px-metric__unit">BPM</div>
              <div className="px-metric__label">Heart Rate</div>
              <div className="px-metric__status" style={{ color: bpmCol }}>
                {result.bpm < 55 ? 'Low' : result.bpm > 110 ? 'Elevated' : 'Normal'}
              </div>
              <div className="px-metric__norm">Normal: 60–100</div>
            </div>

            {/* SpO2 */}
            <div className="px-metric">
              <div className="px-metric__icon" style={{ color: spo2Col }}>
                <Droplets size={22} />
              </div>
              <div className="px-metric__value" style={{ color: spo2Col }}>{result.spo2}%</div>
              <div className="px-metric__unit">SpO₂</div>
              <div className="px-metric__label">Oxygen</div>
              <div className="px-metric__status" style={{ color: spo2Col }}>
                {result.spo2 >= 97 ? 'Normal' : result.spo2 >= 95 ? 'Slightly Low' : 'Low'}
              </div>
              <div className="px-metric__norm">Normal: 97–100%</div>
            </div>

            {/* HRV */}
            <div className="px-metric">
              <div className="px-metric__icon" style={{ color: hrvCol }}>
                <Activity size={22} />
              </div>
              <div className="px-metric__value" style={{ color: hrvCol }}>{result.hrv}</div>
              <div className="px-metric__unit">ms</div>
              <div className="px-metric__label">HRV</div>
              <div className="px-metric__status" style={{ color: hrvCol }}>
                {result.hrv >= 35 ? 'Relaxed' : result.hrv >= 20 ? 'Moderate' : 'Stressed'}
              </div>
              <div className="px-metric__norm">Heart variability</div>
            </div>
          </div>

          {/* Interpretation for parent */}
          <div className="px-interpretation">
            <div className="px-interpretation__title">
              <Heart size={11} style={{ color: '#f87171' }} /> Interpretation for parent
            </div>

            {/* Fever indicator based on elevated resting HR */}
            {result.bpm > 105 && (
              <div className="px-fever-alert">
                🌡️ <strong>Possible fever indicator:</strong> Elevated resting heart rate ({result.bpm} BPM) may indicate fever or physical stress. Check body temperature with a thermometer.
                <div className="px-fever-disclaimer">HR-based indication — not a substitute for thermometer measurement.</div>
              </div>
            )}

            <p className="px-interpretation__txt">
              {result.bpm > 110
                ? `Elevated heart rate (${result.bpm} BPM) — child may be excited, stressed or unwell.`
                : result.bpm < 55
                ? `Low heart rate (${result.bpm} BPM) — child is very relaxed or tired.`
                : `Heart rate normal (${result.bpm} BPM).`}
              {result.spo2 < 95
                ? ` Oxygen low (${result.spo2}%) — watch breathing.`
                : ` Oxygen good (${result.spo2}%).`}
              {result.hrv < 20
                ? ' HRV low — possible stress or physical strain.'
                : result.hrv >= 40 ? ' HRV high — child is relaxed.' : ' HRV normal.'}
            </p>

            {/* What camera CAN and CANNOT measure */}
            <div className="px-capabilities">
              <div className="px-cap-row px-cap-yes"><span>✓</span> Heart rate (BPM) — reliable via rPPG</div>
              <div className="px-cap-row px-cap-yes"><span>✓</span> SpO2 oxygen — estimation (±3-4%)</div>
              <div className="px-cap-row px-cap-yes"><span>✓</span> Stress (HRV) — via heart rate variability</div>
              <div className="px-cap-row px-cap-yes"><span>~</span> Fever indicator — via elevated HR at rest</div>
              <div className="px-cap-row px-cap-no"><span>✗</span> Exact temperature — requires thermometer</div>
              <div className="px-cap-row px-cap-no"><span>✗</span> Blood sugar — requires CGM sensor</div>
              <div className="px-cap-row px-cap-no"><span>✗</span> Blood pressure — requires blood pressure meter</div>
            </div>
          </div>

          <div className="px-result__voice-actions">
            <button
              className="px-btn-repeat"
              onClick={() => speak(buildHealthSummary(result, lang))}
              disabled={speaking}
            >
              <Volume2 size={14} />
              {lang === 'nl' ? 'Repeat explanation' : 'Repeat explanation'}
            </button>
            <button className="px-btn-start" style={{ flex: 1 }} onClick={start}>
              <Heart size={14} /> {lang === 'nl' ? 'New reading' : 'New reading'}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
