/**
 * PrivacyPolicyView — GDPR-compliant Privacy Policy for Aippie / AIPPIETAX S.A.
 */
import { useState } from 'react';
import {
  Shield, Database, Eye, Lock, Globe, Mail, ChevronDown,
  ChevronRight, AlertTriangle, Users, Clock, Trash2, FileText
} from 'lucide-react';

interface Section {
  id: string;
  icon: React.ReactNode;
  title: string;
  content: React.ReactNode;
}

export default function PrivacyPolicyView() {
  const [open, setOpen] = useState<string | null>('intro');

  const toggle = (id: string) => setOpen(p => (p === id ? null : id));

  const sections: Section[] = [
    {
      id: 'intro',
      icon: <FileText size={15} />,
      title: '1. About Aippie & AIPPIETAX S.A.',
      content: (
        <div className="pp-text">
          <p>
            Aippie (operated by <strong>AIPPIETAX S.A.</strong>) provides an automated, non-custodial
            multi-asset AI software system, data analysis tools, and a proactive AI-driven concierge
            interface. All software performance logs, dark pool metrics, and automated indicators are
            for software automation purposes only and do not constitute investment advice, financial
            services, or portfolio management within the meaning of MiFID II.
          </p>
          <p>
            AIPPIETAX S.A. is the data controller for all personal data processed through the Aippie
            platform, including the web application, progressive web app (PWA), and any associated
            API services.
          </p>
          <p>
            This Privacy Policy applies to all users of the Aippie platform, including users of the
            following modules: AippieTax, AippieDoctor, AippieLegal, AippieTrading, AippieAcademy,
            AippieRealEstate, AippieTranslator, AippieAssistant, AippieSafeCheckIn, AippieParking,
            AippieWiFi, AippieWallet, AippieB2B, AippieCompanion, and any future modules.
          </p>
          <p className="pp-updated">Last updated: 7 June 2026 · Version 1.0</p>
        </div>
      ),
    },
    {
      id: 'collect',
      icon: <Database size={15} />,
      title: '2. Data We Collect',
      content: (
        <div className="pp-text">
          <p>We collect personal data in the following categories:</p>

          <div className="pp-category">
            <h4>2.1 Account &amp; Identity Data</h4>
            <ul>
              <li>Email address (used for authentication and service communications)</li>
              <li>Full name (optional, provided during onboarding)</li>
              <li>Company name, VAT number, and registered address (for AippieTax and B2B modules)</li>
              <li>Date of birth (for age verification in trading and legal modules)</li>
              <li>KYC / identity document data (when required by module functionality)</li>
            </ul>
          </div>

          <div className="pp-category">
            <h4>2.2 Usage &amp; Technical Data</h4>
            <ul>
              <li>IP address (first two octets only, for fraud prevention and consent logging)</li>
              <li>Browser type, operating system, and device identifiers</li>
              <li>Session tokens and authentication cookies</li>
              <li>Device key (a pseudonymous identifier for non-authenticated sessions)</li>
              <li>Feature usage logs, module navigation patterns, and session duration</li>
              <li>Error logs and crash reports (no personal content included)</li>
            </ul>
          </div>

          <div className="pp-category">
            <h4>2.3 Financial &amp; Trading Data</h4>
            <ul>
              <li>Broker API keys and API secrets (stored encrypted at rest using AES-256 in Supabase Vault)</li>
              <li>Paper and live trading positions, strategy configurations, and performance logs</li>
              <li>Portfolio data, asset watchlists, and risk preferences</li>
              <li>Tax documents, payroll records, VAT returns, and fiscal data (AippieTax module)</li>
              <li>Dark pool liquidity metrics and algorithmic signal logs (anonymised, software-only)</li>
            </ul>
          </div>

          <div className="pp-category">
            <h4>2.4 Health &amp; Wellbeing Data (Special Category — Art. 9 GDPR)</h4>
            <ul>
              <li>Vitals entered in the AippieDoctor module (heart rate, blood pressure, symptoms)</li>
              <li>Fatigue scores and biometric indicators from wearable integrations</li>
              <li>This data is processed exclusively on your behalf, is never shared with third parties without explicit consent, and requires a separate opt-in.</li>
            </ul>
          </div>

          <div className="pp-category">
            <h4>2.5 Communication Data</h4>
            <ul>
              <li>Messages exchanged with the Aippie AI assistant (processed in real-time, not stored permanently unless you enable history)</li>
              <li>Voice input transcripts (processed locally via Web Speech API; not transmitted to our servers unless explicitly saved)</li>
              <li>Safe Check-In location signals (processed ephemerally; stored only for active dispatch workflows)</li>
            </ul>
          </div>
        </div>
      ),
    },
    {
      id: 'use',
      icon: <Eye size={15} />,
      title: '3. How We Use Your Data',
      content: (
        <div className="pp-text">
          <div className="pp-category">
            <h4>3.1 Service Delivery</h4>
            <p>We process your data to deliver the Aippie platform services, including: executing automated trading strategies on your broker account, generating tax reports, providing legal document analysis, facilitating real estate lead management, and operating the AI concierge interface.</p>
          </div>

          <div className="pp-category">
            <h4>3.2 Software Automation &amp; AI Processing</h4>
            <p>
              Algorithmic signals, dark pool metrics, AI trading indicators, and strategy engine outputs are processed solely for software automation purposes. <strong>They do not constitute personalised investment advice</strong> under MiFID II or any applicable financial regulation.
              The AI models powering the assistant, tax analysis, and legal tools process your inputs to generate responses. These are not legal, medical, or financial professionals.
            </p>
          </div>

          <div className="pp-category">
            <h4>3.3 Security &amp; Fraud Prevention</h4>
            <p>We use technical data (IP hints, device keys, session tokens) to detect unauthorised access, prevent fraud, and maintain the security of your account and API key vault.</p>
          </div>

          <div className="pp-category">
            <h4>3.4 Legal Compliance &amp; Consent Logging</h4>
            <p>When you accept our trading risk disclaimer, the timestamp, user identifier, and version of the disclaimer are stored permanently as evidence of informed consent (GDPR Art. 7). This log is not used for marketing purposes.</p>
          </div>

          <div className="pp-category">
            <h4>3.5 Service Improvement</h4>
            <p>Aggregated, anonymised usage data (no personal identifiers) is used to improve the platform. We do not build individual behavioural profiles for advertising purposes.</p>
          </div>
        </div>
      ),
    },
    {
      id: 'basis',
      icon: <Scale size={15} />,
      title: '4. Legal Basis for Processing (GDPR Art. 6)',
      content: (
        <div className="pp-text">
          <div className="pp-table">
            <div className="pp-table-row pp-table-head">
              <span>Processing Activity</span>
              <span>Legal Basis</span>
            </div>
            <div className="pp-table-row">
              <span>Account creation and authentication</span>
              <span>Contract (Art. 6(1)(b))</span>
            </div>
            <div className="pp-table-row">
              <span>Service delivery (tax, trading, legal, doctor)</span>
              <span>Contract (Art. 6(1)(b))</span>
            </div>
            <div className="pp-table-row">
              <span>Trading risk disclaimer logging</span>
              <span>Legal obligation + Consent (Art. 6(1)(a)(c))</span>
            </div>
            <div className="pp-table-row">
              <span>Health vitals (AippieDoctor)</span>
              <span>Explicit consent (Art. 9(2)(a))</span>
            </div>
            <div className="pp-table-row">
              <span>Security and fraud prevention</span>
              <span>Legitimate interest (Art. 6(1)(f))</span>
            </div>
            <div className="pp-table-row">
              <span>Aggregated analytics</span>
              <span>Legitimate interest (Art. 6(1)(f))</span>
            </div>
            <div className="pp-table-row">
              <span>Marketing communications</span>
              <span>Consent (Art. 6(1)(a)) — opt-in only</span>
            </div>
          </div>
        </div>
      ),
    },
    {
      id: 'sharing',
      icon: <Users size={15} />,
      title: '5. Data Sharing & Third Parties',
      content: (
        <div className="pp-text">
          <p>We do not sell your personal data. We share data only with the following categories of processors under binding Data Processing Agreements (DPAs):</p>

          <div className="pp-category">
            <h4>5.1 Infrastructure &amp; Cloud</h4>
            <ul>
              <li><strong>Supabase Inc.</strong> — Database, authentication, and edge function hosting. Data hosted in EU (Frankfurt). DPA in place.</li>
              <li><strong>Cloudflare / CDN provider</strong> — Static asset delivery and DDoS protection.</li>
            </ul>
          </div>

          <div className="pp-category">
            <h4>5.2 Broker Integrations (User-Initiated)</h4>
            <ul>
              <li><strong>Binance</strong> and <strong>Alpaca Markets</strong> — Only when you explicitly connect your broker API keys. We transmit only the minimum data required to execute your trading instructions. We never transmit withdrawal permissions.</li>
              <li>Your API keys are stored encrypted. Only the edge function executing trades has temporary, scoped access.</li>
            </ul>
          </div>

          <div className="pp-category">
            <h4>5.3 AI &amp; Language Processing</h4>
            <ul>
              <li>AI assistant queries may be processed by third-party LLM providers. We apply data minimisation and do not include account credentials or financial secrets in prompts.</li>
            </ul>
          </div>

          <div className="pp-category">
            <h4>5.4 Legal &amp; Regulatory</h4>
            <ul>
              <li>We may disclose data when required by applicable law, court order, or regulatory authority, limited to the minimum necessary.</li>
            </ul>
          </div>
        </div>
      ),
    },
    {
      id: 'retention',
      icon: <Clock size={15} />,
      title: '6. Data Retention',
      content: (
        <div className="pp-text">
          <div className="pp-table">
            <div className="pp-table-row pp-table-head">
              <span>Data Type</span>
              <span>Retention Period</span>
            </div>
            <div className="pp-table-row">
              <span>Account data</span>
              <span>Duration of account + 2 years after closure</span>
            </div>
            <div className="pp-table-row">
              <span>Trading positions &amp; performance logs</span>
              <span>7 years (EU financial record-keeping requirement)</span>
            </div>
            <div className="pp-table-row">
              <span>Tax documents &amp; payroll records</span>
              <span>7 years (EU fiscal compliance)</span>
            </div>
            <div className="pp-table-row">
              <span>Trading risk consent logs</span>
              <span>10 years (legal defence evidence)</span>
            </div>
            <div className="pp-table-row">
              <span>Health vitals (AippieDoctor)</span>
              <span>Until deletion request; max 2 years</span>
            </div>
            <div className="pp-table-row">
              <span>AI chat history</span>
              <span>30 days unless you enable persistent history</span>
            </div>
            <div className="pp-table-row">
              <span>Voice transcripts</span>
              <span>Not stored — processed in-browser only</span>
            </div>
            <div className="pp-table-row">
              <span>Session &amp; security logs</span>
              <span>90 days</span>
            </div>
          </div>
        </div>
      ),
    },
    {
      id: 'rights',
      icon: <Shield size={15} />,
      title: '7. Your Rights Under GDPR',
      content: (
        <div className="pp-text">
          <p>As a data subject under the GDPR, you have the following rights, exercisable by contacting us at <strong>privacy@aippie.com</strong>:</p>
          <div className="pp-rights-grid">
            {[
              { right: 'Right of Access (Art. 15)', desc: 'Request a copy of all personal data we hold about you.' },
              { right: 'Right to Rectification (Art. 16)', desc: 'Correct inaccurate or incomplete data.' },
              { right: 'Right to Erasure (Art. 17)', desc: 'Request deletion of your data, subject to legal retention obligations.' },
              { right: 'Right to Restriction (Art. 18)', desc: 'Restrict processing while a dispute is resolved.' },
              { right: 'Right to Portability (Art. 20)', desc: 'Receive your data in a structured, machine-readable format (JSON/CSV).' },
              { right: 'Right to Object (Art. 21)', desc: 'Object to processing based on legitimate interest, including profiling.' },
              { right: 'Right to Withdraw Consent (Art. 7(3))', desc: 'Withdraw consent at any time for consent-based processing. This does not affect past lawfulness.' },
              { right: 'Right to Lodge a Complaint', desc: 'File a complaint with the Dutch Data Protection Authority (Autoriteit Persoonsgegevens) at autoriteitpersoonsgegevens.nl.' },
            ].map(r => (
              <div key={r.right} className="pp-right-card">
                <span className="pp-right-card__title">{r.right}</span>
                <span className="pp-right-card__desc">{r.desc}</span>
              </div>
            ))}
          </div>
          <p className="pp-note">We respond to verified requests within <strong>30 days</strong> (extendable by 60 days for complex requests, with notice).</p>
        </div>
      ),
    },
    {
      id: 'security',
      icon: <Lock size={15} />,
      title: '8. Security Measures',
      content: (
        <div className="pp-text">
          <p>We implement the following technical and organisational security measures:</p>
          <ul>
            <li><strong>Encryption at rest:</strong> All database content encrypted via AES-256. API keys stored in Supabase Vault (separate encrypted key store).</li>
            <li><strong>Encryption in transit:</strong> All connections enforced over TLS 1.3. HSTS headers active.</li>
            <li><strong>Row-Level Security (RLS):</strong> Every database table enforces per-user access policies. No user can access another user's data at the database level.</li>
            <li><strong>Broker API permissions:</strong> We instruct all users to enable Read + Trade permissions only. We explicitly prohibit and cannot use Withdraw permissions.</li>
            <li><strong>Edge function isolation:</strong> Broker execution runs in isolated serverless functions with scoped secret access — no plaintext keys in application code.</li>
            <li><strong>Pseudonymisation:</strong> Non-authenticated sessions use device keys rather than personal identifiers.</li>
            <li><strong>Access control:</strong> Internal access to production data is role-gated and audit-logged.</li>
            <li><strong>Breach notification:</strong> In the event of a data breach affecting your rights and freedoms, we will notify you and the relevant supervisory authority within 72 hours (GDPR Art. 33/34).</li>
          </ul>
        </div>
      ),
    },
    {
      id: 'cookies',
      icon: <Globe size={15} />,
      title: '9. Cookies & Local Storage',
      content: (
        <div className="pp-text">
          <p>Aippie uses minimal browser storage for functional purposes only:</p>
          <div className="pp-table">
            <div className="pp-table-row pp-table-head">
              <span>Name / Key</span>
              <span>Purpose</span>
              <span>Type</span>
            </div>
            <div className="pp-table-row">
              <span>supabase-auth-token</span>
              <span>Maintains your authenticated session</span>
              <span>Functional</span>
            </div>
            <div className="pp-table-row">
              <span>aippie_trading_consent_v1</span>
              <span>Records trading disclaimer acceptance to avoid repeated prompts</span>
              <span>Functional</span>
            </div>
            <div className="pp-table-row">
              <span>aippie_device_key</span>
              <span>Pseudonymous device identifier for guest sessions</span>
              <span>Functional</span>
            </div>
            <div className="pp-table-row">
              <span>aippie_lang</span>
              <span>Stores your language preference</span>
              <span>Functional</span>
            </div>
          </div>
          <p>We do not use advertising cookies, tracking pixels, or third-party analytics cookies. No cookie consent banner is required for strictly functional cookies under ePrivacy Directive Recital 66.</p>
        </div>
      ),
    },
    {
      id: 'transfers',
      icon: <Globe size={15} />,
      title: '10. International Data Transfers',
      content: (
        <div className="pp-text">
          <p>
            Your data is primarily stored and processed within the <strong>European Economic Area (EEA)</strong>, specifically in Supabase's EU (Frankfurt) data centre.
          </p>
          <p>
            Where data is processed outside the EEA (e.g., by AI model providers or CDN nodes), we ensure adequate safeguards are in place through:
          </p>
          <ul>
            <li>EU Standard Contractual Clauses (SCCs) as approved by the European Commission</li>
            <li>Adequacy decisions where applicable (e.g., transfers to countries with equivalent data protection)</li>
            <li>Data minimisation: we transmit only the minimum data required for the specific processing purpose</li>
          </ul>
        </div>
      ),
    },
    {
      id: 'minors',
      icon: <AlertTriangle size={15} />,
      title: '11. Minors',
      content: (
        <div className="pp-text">
          <p>
            The Aippie platform is intended for users <strong>18 years of age or older</strong>. We do not knowingly collect personal data from persons under 18. The trading module requires explicit age confirmation (18+) at first use.
          </p>
          <p>
            If you believe a minor has provided personal data to Aippie, please contact us immediately at <strong>privacy@aippie.com</strong> and we will delete the data without undue delay.
          </p>
        </div>
      ),
    },
    {
      id: 'changes',
      icon: <FileText size={15} />,
      title: '12. Changes to This Policy',
      content: (
        <div className="pp-text">
          <p>
            We may update this Privacy Policy as our services evolve or as legal requirements change. When we make material changes, we will:
          </p>
          <ul>
            <li>Update the "Last updated" date at the top of this document</li>
            <li>Increment the version number (e.g., v1.0 → v1.1)</li>
            <li>Notify registered users by email for significant changes affecting their rights</li>
            <li>Where required by law, request renewed consent</li>
          </ul>
          <p>
            Continued use of the platform after the effective date of a revised policy constitutes acceptance of the updated terms, to the extent permitted by applicable law.
          </p>
        </div>
      ),
    },
    {
      id: 'contact',
      icon: <Mail size={15} />,
      title: '13. Contact & Data Protection',
      content: (
        <div className="pp-text">
          <div className="pp-contact-grid">
            <div className="pp-contact-card">
              <h4>Data Controller</h4>
              <p><strong>AIPPIETAX S.A.</strong></p>
              <p>Privacy Officer: privacy@aippie.com</p>
              <p>General: info@aippie.com</p>
            </div>
            <div className="pp-contact-card">
              <h4>Supervisory Authority</h4>
              <p><strong>Autoriteit Persoonsgegevens</strong></p>
              <p>Postbus 93374</p>
              <p>2509 AJ Den Haag, Netherlands</p>
              <p>autoriteitpersoonsgegevens.nl</p>
            </div>
            <div className="pp-contact-card">
              <h4>Response Times</h4>
              <p>Data subject requests: <strong>30 days</strong></p>
              <p>Breach notification: <strong>72 hours</strong></p>
              <p>General enquiries: <strong>5 business days</strong></p>
            </div>
          </div>
          <p className="pp-note" style={{ marginTop: 16 }}>
            For trading-related disclaimer evidence requests or consent log exports, email <strong>privacy@aippie.com</strong> with your account email and the subject line "Consent Log Request".
          </p>
        </div>
      ),
    },
  ];

  return (
    <div className="pp-root">
      {/* Hero */}
      <div className="pp-hero">
        <div className="pp-hero__icon">
          <Shield size={28} />
        </div>
        <div>
          <h1 className="pp-hero__title">Privacy Policy</h1>
          <p className="pp-hero__sub">AIPPIETAX S.A. · GDPR Compliant · Version 1.0 · June 2026</p>
        </div>
        <div className="pp-hero__badge">
          <Lock size={11} /> GDPR
        </div>
      </div>

      {/* Intro summary strip */}
      <div className="pp-summary">
        <div className="pp-summary-item">
          <Database size={13} />
          <span>Minimal data collection</span>
        </div>
        <div className="pp-summary-item">
          <Lock size={13} />
          <span>AES-256 encrypted storage</span>
        </div>
        <div className="pp-summary-item">
          <Globe size={13} />
          <span>EU data centres (Frankfurt)</span>
        </div>
        <div className="pp-summary-item">
          <Trash2 size={13} />
          <span>Right to erasure</span>
        </div>
        <div className="pp-summary-item">
          <Users size={13} />
          <span>Never sold to third parties</span>
        </div>
      </div>

      {/* Accordion sections */}
      <div className="pp-sections">
        {sections.map(s => (
          <div key={s.id} className={`pp-section${open === s.id ? ' pp-section--open' : ''}`}>
            <button className="pp-section__header" onClick={() => toggle(s.id)}>
              <span className="pp-section__icon">{s.icon}</span>
              <span className="pp-section__title">{s.title}</span>
              <span className="pp-section__chevron">
                {open === s.id ? <ChevronDown size={14} /> : <ChevronRight size={14} />}
              </span>
            </button>
            {open === s.id && (
              <div className="pp-section__body">{s.content}</div>
            )}
          </div>
        ))}
      </div>

      <p className="pp-footer-note">
        This Privacy Policy was last reviewed on 7 June 2026. For questions, contact privacy@aippie.com.
      </p>
    </div>
  );
}

// Dummy icon for scale — resolved from lucide-react
function Scale({ size }: { size: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M12 3v18"/><path d="M8 6H4l-2 6h6l-2-6z"/><path d="M18 6h-4l-2 6h6l-2-6z"/><path d="M5 21h14"/>
    </svg>
  );
}
