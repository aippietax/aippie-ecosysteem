import { useState, useEffect, useCallback } from 'react';
import { Megaphone, ExternalLink, ChevronLeft, ChevronRight, X } from 'lucide-react';
import { supabase } from '../lib/supabase';

interface PlatformAd {
  id: string;
  company_name: string;
  ad_text: string;
  image_url: string | null;
  link_url: string | null;
}

interface Props {
  /** Compact single-line bar (default) or tall card mode */
  variant?: 'bar' | 'card';
  /** Accent color passed from the active product module */
  accentColor?: string;
  /** Called when user clicks "Plaats advertentie" */
  onPlaceAd?: () => void;
}

const ROTATE_MS = 3000;
const FALLBACK_ADS: PlatformAd[] = [
  { id: 'f1', company_name: 'Aippie', ad_text: 'Adverteer hier voor slechts €5/week — bereik duizenden gebruikers', image_url: null, link_url: null },
  { id: 'f2', company_name: 'AippieTax', ad_text: 'Laat AI jouw belastingaangifte doen — AippieTax vanaf €100', image_url: null, link_url: null },
];

export default function PlatformAdBanner({ variant = 'bar', accentColor = '#38bdf8', onPlaceAd }: Props) {
  const [ads, setAds] = useState<PlatformAd[]>(FALLBACK_ADS);
  const [idx, setIdx] = useState(0);
  const [visible, setVisible] = useState(true);
  const [animating, setAnimating] = useState(false);

  useEffect(() => {
    supabase
      .from('platform_ads')
      .select('id, company_name, ad_text, image_url, link_url')
      .then(({ data }) => { if (data && data.length > 0) setAds(data); });
  }, []);

  const goTo = useCallback((next: number) => {
    setAnimating(true);
    setTimeout(() => {
      setIdx(next);
      setAnimating(false);
    }, 220);
  }, []);

  useEffect(() => {
    if (!visible || ads.length <= 1) return;
    const id = setInterval(() => {
      setAnimating(true);
      setTimeout(() => {
        setIdx(i => (i + 1) % ads.length);
        setAnimating(false);
      }, 220);
    }, ROTATE_MS);
    return () => clearInterval(id);
  }, [visible, ads.length]);

  if (!visible) return null;

  const ad = ads[idx] ?? ads[0];

  if (variant === 'card') {
    return (
      <div className="pad-card" style={{ '--pad-accent': accentColor } as React.CSSProperties}>
        <div className={`pad-card__inner${animating ? ' pad-card__inner--out' : ''}`}>
          <div className="pad-card__label">
            <Megaphone size={10} />
            <span>ADVERTENTIE</span>
          </div>
          {ad.image_url && (
            <img src={ad.image_url} alt={ad.company_name} className="pad-card__img" />
          )}
          <div className="pad-card__company">{ad.company_name}</div>
          <div className="pad-card__text">{ad.ad_text}</div>
          {ad.link_url && (
            <a href={ad.link_url} target="_blank" rel="noopener noreferrer" className="pad-card__link">
              <ExternalLink size={10} /> Bekijk meer
            </a>
          )}
        </div>
        <div className="pad-card__nav">
          <button className="pad-card__nav-btn" onClick={() => goTo((idx - 1 + ads.length) % ads.length)}>
            <ChevronLeft size={12} />
          </button>
          <div className="pad-card__dots">
            {ads.map((_, i) => (
              <button
                key={i}
                className={`pad-card__dot${i === idx ? ' pad-card__dot--active' : ''}`}
                style={i === idx ? { background: accentColor } : {}}
                onClick={() => goTo(i)}
              />
            ))}
          </div>
          <button className="pad-card__nav-btn" onClick={() => goTo((idx + 1) % ads.length)}>
            <ChevronRight size={12} />
          </button>
        </div>
        {onPlaceAd && (
          <button className="pad-card__cta" style={{ borderColor: accentColor, color: accentColor }} onClick={onPlaceAd}>
            + Plaats jouw advertentie · €5/week
          </button>
        )}
      </div>
    );
  }

  // variant = 'bar' (default — thin horizontal strip)
  return (
    <div className="pad-bar" style={{ '--pad-accent': accentColor } as React.CSSProperties}>
      <div className="pad-bar__left">
        <Megaphone size={11} style={{ color: accentColor, flexShrink: 0 }} />
        <span className="pad-bar__label">AD</span>
      </div>
      <div className={`pad-bar__content${animating ? ' pad-bar__content--out' : ''}`}>
        {ad.image_url && <img src={ad.image_url} alt="" className="pad-bar__img" />}
        <span className="pad-bar__company" style={{ color: accentColor }}>{ad.company_name}</span>
        <span className="pad-bar__text">{ad.ad_text}</span>
        {ad.link_url && (
          <a href={ad.link_url} target="_blank" rel="noopener noreferrer" className="pad-bar__link">
            <ExternalLink size={10} />
          </a>
        )}
      </div>
      <div className="pad-bar__right">
        <div className="pad-bar__dots">
          {ads.slice(0, 5).map((_, i) => (
            <span key={i} className={`pad-bar__dot${i === idx ? ' pad-bar__dot--active' : ''}`}
              style={i === idx ? { background: accentColor } : {}} />
          ))}
        </div>
        {onPlaceAd && (
          <button className="pad-bar__place-btn" onClick={onPlaceAd} title="Adverteer hier">+AD</button>
        )}
        <button className="pad-bar__close" onClick={() => setVisible(false)} aria-label="Sluit">
          <X size={9} />
        </button>
      </div>
    </div>
  );
}
