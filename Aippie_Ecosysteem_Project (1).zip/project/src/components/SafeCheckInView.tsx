/**
 * SafeCheckInView — V78 Safe Check-in Timer Emergency Core
 * AIPPIETAX S.A.
 *
 * Autonomous personal safety system:
 *   1. User sets a timer window (5 / 10 / 15 / custom minutes)
 *   2. On expiry → vibration alarm + PIN/biometric challenge modal
 *   3. 60-second grace window: any failed or missing auth → DISTRESS
 *   4. Distress: locks GPS coords, calls edge function to dispatch
 *      emergency SMS + push payload to pre-configured contacts
 *
 * Browser APIs used:
 *   - navigator.geolocation (GPS)
 *   - navigator.vibrate (tactile alarm)
 *   - navigator.credentials / PublicKeyCredential (WebAuthn biometric)
 *   - Supabase real-time + edge function (dispatch)
 */
import { useCallback, useEffect, useRef, useState } from 'react';
import AippieVoiceOverlay from './AippieVoiceOverlay';
import {
  ShieldCheck, ShieldAlert, ShieldOff, Clock, MapPin,
  Phone, UserPlus, Trash2, AlertTriangle, CheckCircle2,
  Lock, Fingerprint, Send, Building2, Zap, X,
  ChevronRight, RefreshCw, Radio
} from 'lucide-react';
import { supabase } from '../lib/supabase';
import { notifySafeCheckInExpired, notifySafeCheckInConfirmed } from '../lib/notificationService';
import type { User } from '@supabase/supabase-js';

// ─── Types ────────────────────────────────────────────────────────────────────
type SessionStatus = 'idle' | 'active' | 'challenge' | 'grace' | 'safe' | 'distress' | 'cancelled';
type AuthStep      = 'pin' | 'biometric' | 'done';

interface EmergencyContact {
  id: string;
  name: string;
  phone: string;
  email: string;
  is_primary: boolean;
}

interface CheckinSession {
  id: string;
  duration_minutes: number;
  started_at: string;
  expires_at: string;
  grace_ends_at: string;
  status: string;
  lat: number | null;
  lng: number | null;
  maps_link: string | null;
  pin_attempts: number;
}

// ─── Constants ────────────────────────────────────────────────────────────────
const GRACE_SECONDS   = 60;
const PRESET_DURATIONS = [5, 10, 15, 30] as const;
const HARDCODED_PIN   = '1234'; // user-set PIN — in production stored hashed; demo uses static

// ─── Helpers ─────────────────────────────────────────────────────────────────
function fmt(secs: number): string {
  const m = Math.floor(secs / 60);
  const s = secs % 60;
  return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
}

function vibrate(pattern: number | number[]) {
  try { navigator.vibrate?.(pattern); } catch { /* not supported */ }
}

async function getGps(): Promise<{ lat: number; lng: number } | null> {
  return new Promise(resolve => {
    if (!navigator.geolocation) { resolve(null); return; }
    navigator.geolocation.getCurrentPosition(
      pos => resolve({ lat: pos.coords.latitude, lng: pos.coords.longitude }),
      ()  => resolve(null),
      { timeout: 8000, enableHighAccuracy: true }
    );
  });
}

// ─── PIN Pad ──────────────────────────────────────────────────────────────────
function PinPad({ onSubmit, attempts }: { onSubmit: (pin: string) => void; attempts: number }) {
  const [digits, setDigits] = useState('');
  const append = (d: string) => {
    if (digits.length >= 4) return;
    const next = digits + d;
    setDigits(next);
    if (next.length === 4) { setTimeout(() => { onSubmit(next); setDigits(''); }, 120); }
  };
  const clear = () => setDigits('');
  return (
    <div className="sci-pin-pad">
      <div className="sci-pin-dots">
        {[0,1,2,3].map(i => (
          <span key={i} className={`sci-pin-dot${i < digits.length ? ' sci-pin-dot--filled' : ''}`} />
        ))}
      </div>
      {attempts > 0 && (
        <div className="sci-pin-attempts">
          <AlertTriangle size={10} /> {attempts} failed attempt{attempts > 1 ? 's' : ''}
        </div>
      )}
      <div className="sci-pin-grid">
        {['1','2','3','4','5','6','7','8','9','','0','⌫'].map((k, i) => (
          <button
            key={i}
            className={`sci-pin-key${k === '' ? ' sci-pin-key--empty' : ''}`}
            onClick={() => k === '⌫' ? clear() : k !== '' ? append(k) : undefined}
            disabled={k === ''}
            aria-label={k === '⌫' ? 'Clear' : k || undefined}
          >
            {k}
          </button>
        ))}
      </div>
    </div>
  );
}

// ─── Circular countdown ring ──────────────────────────────────────────────────
function CountdownRing({
  remaining, total, danger, label, sublabel,
}: {
  remaining: number; total: number; danger: boolean; label: string; sublabel: string;
}) {
  const R = 52, C = 2 * Math.PI * R;
  const pct = Math.max(0, Math.min(1, remaining / total));
  const dash = pct * C;
  const color = danger ? '#f87171' : remaining < total * 0.25 ? '#fbbf24' : '#4ade80';
  return (
    <div className="sci-ring-wrap">
      <svg viewBox="0 0 120 120" className="sci-ring-svg">
        <circle cx="60" cy="60" r={R} className="sci-ring-track" />
        <circle
          cx="60" cy="60" r={R}
          className="sci-ring-fill"
          style={{
            stroke: color,
            strokeDasharray: `${dash} ${C}`,
            filter: danger ? `drop-shadow(0 0 6px ${color})` : undefined,
          }}
        />
      </svg>
      <div className="sci-ring-center">
        <span className="sci-ring-label"  style={{ color }}>{label}</span>
        <span className="sci-ring-sublabel">{sublabel}</span>
      </div>
    </div>
  );
}

// ─── Main component ───────────────────────────────────────────────────────────
type Props = { user: User | null };

export default function SafeCheckInView({ user }: Props) {
  // ── State ─────────────────────────────────────────────────────────────────
  const [status,       setStatus]       = useState<SessionStatus>('idle');
  const [duration,     setDuration]     = useState(10);
  const [customMin,    setCustomMin]    = useState('');
  const [remaining,    setRemaining]    = useState(0);     // seconds left in main timer
  const [graceLeft,    setGraceLeft]    = useState(GRACE_SECONDS);
  const [authStep,     setAuthStep]     = useState<AuthStep>('pin');
  const [pinAttempts,  setPinAttempts]  = useState(0);
  const [biometricErr, setBiometricErr] = useState<string | null>(null);
  const [gps,          setGps]          = useState<{ lat: number; lng: number } | null>(null);
  const [gpsLoading,   setGpsLoading]   = useState(false);
  const [dispatching,  setDispatching]  = useState(false);
  const [dispatchResult, setDispatchResult] = useState<string | null>(null);
  const [contacts,     setContacts]     = useState<EmergencyContact[]>([]);
  const [contactsLoading, setContactsLoading] = useState(false);
  const [session,      setSession]      = useState<CheckinSession | null>(null);
  const [history,      setHistory]      = useState<CheckinSession[]>([]);
  // contact form
  const [addName,  setAddName]  = useState('');
  const [addPhone, setAddPhone] = useState('');
  const [addEmail, setAddEmail] = useState('');
  const [addPrimary, setAddPrimary] = useState(false);
  const [saving,   setSaving]   = useState(false);

  const mainTimerRef  = useRef<ReturnType<typeof setInterval> | null>(null);
  const graceTimerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const sessionIdRef  = useRef<string | null>(null);

  // ── Load contacts + history ───────────────────────────────────────────────
  const loadContacts = useCallback(async () => {
    if (!user) return;
    setContactsLoading(true);
    const { data } = await supabase
      .from('emergency_contacts')
      .select('*')
      .eq('user_id', user.id)
      .order('is_primary', { ascending: false });
    setContacts((data ?? []) as EmergencyContact[]);
    setContactsLoading(false);
  }, [user]);

  const loadHistory = useCallback(async () => {
    if (!user) return;
    const { data } = await supabase
      .from('safe_checkin_sessions')
      .select('*')
      .eq('user_id', user.id)
      .order('created_at', { ascending: false })
      .limit(5);
    setHistory((data ?? []) as CheckinSession[]);
  }, [user]);

  useEffect(() => {
    loadContacts();
    loadHistory();
  }, [loadContacts, loadHistory]);

  // ── GPS capture ───────────────────────────────────────────────────────────
  const captureGps = useCallback(async () => {
    setGpsLoading(true);
    const pos = await getGps();
    setGps(pos);
    setGpsLoading(false);
    return pos;
  }, []);

  // ── Start timer ───────────────────────────────────────────────────────────
  const startTimer = useCallback(async () => {
    if (!user) return;
    const mins = customMin ? parseInt(customMin, 10) || duration : duration;
    if (mins < 1 || mins > 240) return;

    // Create session in DB
    const now      = new Date();
    const expires  = new Date(now.getTime() + mins * 60_000);
    const graceEnd = new Date(expires.getTime() + GRACE_SECONDS * 1000);

    const { data, error } = await supabase
      .from('safe_checkin_sessions')
      .insert({
        user_id:          user.id,
        duration_minutes: mins,
        started_at:       now.toISOString(),
        expires_at:       expires.toISOString(),
        grace_ends_at:    graceEnd.toISOString(),
        status:           'active',
      })
      .select()
      .maybeSingle();

    if (error || !data) return;
    sessionIdRef.current = data.id;
    setSession(data as CheckinSession);
    setStatus('active');
    setRemaining(mins * 60);
    setPinAttempts(0);
    setDispatchResult(null);
    vibrate([100, 50, 100]);

    // Pre-capture GPS in background
    captureGps();

    // Main countdown
    mainTimerRef.current = setInterval(() => {
      setRemaining(r => {
        if (r <= 1) {
          clearInterval(mainTimerRef.current!);
          triggerChallenge();
          return 0;
        }
        return r - 1;
      });
    }, 1000);
  }, [user, duration, customMin, captureGps]); // eslint-disable-line react-hooks/exhaustive-deps

  // ── Challenge (authentication demand) ────────────────────────────────────
  const triggerChallenge = useCallback(() => {
    setStatus('challenge');
    setAuthStep('pin');
    setGraceLeft(GRACE_SECONDS);
    vibrate([300, 100, 300, 100, 300]);
    notifySafeCheckInExpired({});

    graceTimerRef.current = setInterval(() => {
      setGraceLeft(g => {
        if (g <= 1) {
          clearInterval(graceTimerRef.current!);
          triggerDistress();
          return 0;
        }
        return g - 1;
      });
    }, 1000);
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  // ── Distress trigger ──────────────────────────────────────────────────────
  const triggerDistress = useCallback(async () => {
    clearInterval(graceTimerRef.current!);
    setStatus('distress');
    vibrate([500, 200, 500, 200, 500, 200, 500]);

    if (!sessionIdRef.current) return;
    setDispatching(true);

    // Final GPS capture
    const pos = gps ?? await getGps();

    try {
      const { data: { session: authSession } } = await supabase.auth.getSession();
      const token = authSession?.access_token;

      const res = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/safe-checkin-dispatch`,
        {
          method: 'POST',
          headers: {
            'Content-Type':  'application/json',
            'Authorization': `Bearer ${token ?? import.meta.env.VITE_SUPABASE_ANON_KEY}`,
            'Apikey':        import.meta.env.VITE_SUPABASE_ANON_KEY,
          },
          body: JSON.stringify({
            session_id: sessionIdRef.current,
            lat: pos?.lat ?? null,
            lng: pos?.lng ?? null,
          }),
        }
      );
      const json = await res.json();
      setDispatchResult(
        json.sms_dispatched > 0
          ? `Emergency SMS sent to ${json.sms_dispatched} contact(s).`
          : json.twilio_ready === false
            ? 'Distress logged. SMS gateway not yet configured — contact your administrator.'
            : `Distress logged. ${json.contacts_count === 0 ? 'No emergency contacts on file.' : 'Dispatch attempted.'}`
      );
      setGps(pos);
    } catch {
      setDispatchResult('Distress logged locally. Network error during dispatch.');
    } finally {
      setDispatching(false);
      loadHistory();
    }
  }, [gps, loadHistory]);

  // ── Mark safe ─────────────────────────────────────────────────────────────
  const markSafe = useCallback(async () => {
    clearInterval(mainTimerRef.current!);
    clearInterval(graceTimerRef.current!);
    setStatus('safe');
    vibrate([80, 40, 80]);
    notifySafeCheckInConfirmed({});
    if (!sessionIdRef.current) return;
    await supabase
      .from('safe_checkin_sessions')
      .update({ status: 'safe' })
      .eq('id', sessionIdRef.current);
    loadHistory();
  }, [loadHistory]);

  // ── Cancel ────────────────────────────────────────────────────────────────
  const cancelTimer = useCallback(async () => {
    clearInterval(mainTimerRef.current!);
    clearInterval(graceTimerRef.current!);
    setStatus('cancelled');
    if (!sessionIdRef.current) return;
    await supabase
      .from('safe_checkin_sessions')
      .update({ status: 'cancelled' })
      .eq('id', sessionIdRef.current);
    loadHistory();
  }, [loadHistory]);

  // ── PIN submission ────────────────────────────────────────────────────────
  const handlePin = useCallback(async (pin: string) => {
    if (pin === HARDCODED_PIN) {
      clearInterval(graceTimerRef.current!);
      await markSafe();
    } else {
      const next = pinAttempts + 1;
      setPinAttempts(next);
      vibrate([200]);
      // Increment pin_attempts in DB
      if (sessionIdRef.current) {
        await supabase
          .from('safe_checkin_sessions')
          .update({ pin_attempts: next })
          .eq('id', sessionIdRef.current);
      }
      if (next >= 3) {
        // Too many failures — trigger distress immediately
        triggerDistress();
      }
    }
  }, [pinAttempts, markSafe, triggerDistress]);

  // ── Biometric auth (WebAuthn / Face ID / Touch ID) ────────────────────────
  const handleBiometric = useCallback(async () => {
    setBiometricErr(null);
    try {
      if (!window.PublicKeyCredential) {
        setBiometricErr('WebAuthn not supported in this browser.');
        return;
      }
      const available = await PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable();
      if (!available) {
        setBiometricErr('No biometric authenticator found. Use PIN instead.');
        return;
      }
      // Create a simple get() assertion to trigger Face ID / Touch ID
      const challenge = new Uint8Array(32);
      crypto.getRandomValues(challenge);
      await navigator.credentials.get({
        publicKey: {
          challenge,
          timeout: 30000,
          userVerification: 'required',
          rpId: window.location.hostname,
        },
      } as CredentialRequestOptions);
      // If we reach here — biometric passed
      clearInterval(graceTimerRef.current!);
      await markSafe();
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err);
      if (msg.includes('not allowed') || msg.includes('cancelled') || msg.includes('NotAllowedError')) {
        setBiometricErr('Biometric cancelled. Use your PIN.');
      } else if (msg.includes('No credentials') || msg.includes('NotFoundError')) {
        setBiometricErr('No registered biometric. Use PIN to authenticate.');
      } else {
        setBiometricErr(msg);
      }
    }
  }, [markSafe]);

  // ── Add contact ───────────────────────────────────────────────────────────
  const addContact = useCallback(async () => {
    if (!user || !addName.trim() || !addPhone.trim()) return;
    setSaving(true);
    await supabase.from('emergency_contacts').insert({
      user_id:    user.id,
      name:       addName.trim(),
      phone:      addPhone.trim(),
      email:      addEmail.trim(),
      is_primary: addPrimary,
    });
    setAddName(''); setAddPhone(''); setAddEmail(''); setAddPrimary(false);
    setSaving(false);
    loadContacts();
  }, [user, addName, addPhone, addEmail, addPrimary, loadContacts]);

  const deleteContact = useCallback(async (id: string) => {
    await supabase.from('emergency_contacts').delete().eq('id', id);
    loadContacts();
  }, [loadContacts]);

  // ── Reset to idle ─────────────────────────────────────────────────────────
  const resetIdle = () => {
    setStatus('idle');
    setRemaining(0);
    setGraceLeft(GRACE_SECONDS);
    setPinAttempts(0);
    setBiometricErr(null);
    setSession(null);
    sessionIdRef.current = null;
    setDispatchResult(null);
  };

  // ── Cleanup ───────────────────────────────────────────────────────────────
  useEffect(() => {
    return () => {
      clearInterval(mainTimerRef.current!);
      clearInterval(graceTimerRef.current!);
    };
  }, []);

  // ─────────────────────────────────────────────────────────────────────────
  // Render
  // ─────────────────────────────────────────────────────────────────────────

  const statusColor: Record<SessionStatus, string> = {
    idle:      '#60a5fa',
    active:    '#4ade80',
    challenge: '#fbbf24',
    grace:     '#f87171',
    safe:      '#4ade80',
    distress:  '#f87171',
    cancelled: '#64748b',
  };
  const accent = statusColor[status];

  // ── Auth challenge modal (overlays everything) ──────────────────────────
  if (status === 'challenge' || (status === 'grace' && graceLeft > 0)) {
    const isGrace = status === 'grace';
    return (
      <div className="sci-root">
        <div className={`sci-challenge-overlay${graceLeft < 20 ? ' sci-challenge-overlay--critical' : ''}`}>
          <div className="sci-challenge-header">
            <ShieldAlert size={22} style={{ color: '#fbbf24' }} />
            <div>
              <div className="sci-challenge-title">Safe Check-in Required</div>
              <div className="sci-challenge-sub">Verify identity to confirm safety</div>
            </div>
          </div>

          <CountdownRing
            remaining={graceLeft}
            total={GRACE_SECONDS}
            danger={graceLeft < 20}
            label={fmt(graceLeft)}
            sublabel="Grace window"
          />

          {graceLeft < 20 && (
            <div className="sci-challenge-urgent">
              <AlertTriangle size={13} /> {graceLeft}s — Emergency dispatch in {graceLeft}s
            </div>
          )}

          {authStep === 'pin' && (
            <>
              <div className="sci-challenge-section-label">
                <Lock size={11} /> Enter your 4-digit PIN
              </div>
              <PinPad onSubmit={handlePin} attempts={pinAttempts} />
              <button className="sci-switch-auth-btn" onClick={() => { setAuthStep('biometric'); setBiometricErr(null); }}>
                <Fingerprint size={12} /> Use Biometric instead
              </button>
            </>
          )}

          {authStep === 'biometric' && (
            <div className="sci-biometric-panel">
              <button className="sci-biometric-btn" onClick={handleBiometric}>
                <Fingerprint size={28} />
                <span>Face ID / Touch ID</span>
              </button>
              {biometricErr && <div className="sci-bio-error"><AlertTriangle size={10} /> {biometricErr}</div>}
              <button className="sci-switch-auth-btn" onClick={() => { setAuthStep('pin'); setBiometricErr(null); }}>
                <Lock size={12} /> Use PIN instead
              </button>
            </div>
          )}

          <div className="sci-challenge-footer">
            <ShieldCheck size={10} style={{ color: '#334155' }} />
            <span>PIN demo: 1234 · biometric uses device authenticator</span>
          </div>
        </div>
      </div>
    );
  }

  // ── Distress state ─────────────────────────────────────────────────────
  if (status === 'distress') {
    const mapsUrl = gps ? `https://www.google.com/maps?q=${gps.lat},${gps.lng}` : null;
    return (
      <div className="sci-root">
        <div className="sci-distress-screen">
          <div className="sci-distress-icon">
            <ShieldOff size={36} style={{ color: '#f87171' }} />
          </div>
          <div className="sci-distress-title">DISTRESS SIGNAL SENT</div>
          <div className="sci-distress-sub">Emergency contacts have been notified</div>

          {dispatching && (
            <div className="sci-distress-dispatching">
              <span className="modal__spinner" />
              <span>Dispatching emergency payload...</span>
            </div>
          )}

          {dispatchResult && (
            <div className="sci-distress-result">
              <Send size={11} style={{ color: '#f87171' }} />
              <span>{dispatchResult}</span>
            </div>
          )}

          {gps && (
            <a
              href={mapsUrl!}
              target="_blank"
              rel="noopener noreferrer"
              className="sci-maps-link"
            >
              <MapPin size={13} />
              {gps.lat.toFixed(5)}°N, {gps.lng.toFixed(5)}°
              <ChevronRight size={11} />
            </a>
          )}
          {!gps && (
            <div className="sci-no-gps"><MapPin size={11} /> GPS unavailable at dispatch</div>
          )}

          <div className="sci-distress-contacts">
            <div className="sci-distress-contacts__label">
              <Phone size={11} /> Notified contacts
            </div>
            {contacts.length === 0
              ? <span className="sci-no-contacts-warn">No emergency contacts on file — add contacts to enable SMS dispatch.</span>
              : contacts.map(c => (
                  <div key={c.id} className="sci-distress-contact-row">
                    <span className={`sci-contact-dot${c.is_primary ? ' sci-contact-dot--primary' : ''}`} />
                    <span className="sci-contact-name">{c.name}</span>
                    <span className="sci-contact-phone">{c.phone}</span>
                  </div>
                ))
            }
          </div>

          <button className="sci-reset-btn" onClick={resetIdle}>
            <RefreshCw size={13} /> Start New Session
          </button>

          <div className="sci-distress-footer">
            <Building2 size={9} /> AIPPIETAX S.A. · Safe Check-in v78
          </div>
        </div>
      </div>
    );
  }

  // ── Safe / Cancelled / Idle / Active ─────────────────────────────────────
  return (
    <div className="sci-root">

      {/* ── Header ── */}
      <div className="sci-header">
        <div className="sci-header__brand">
          <ShieldCheck size={18} style={{ color: accent }} />
          <div>
            <div className="sci-header__title">Safe Check-in</div>
            <div className="sci-header__sub">Autonomous Emergency Timer Core · v78</div>
          </div>
        </div>
        <div className="sci-status-pill" style={{ borderColor: accent + '44', color: accent }}>
          <span className={`sci-status-dot${status === 'active' ? ' sci-status-dot--pulse' : ''}`}
            style={{ background: accent }} />
          {status.charAt(0).toUpperCase() + status.slice(1)}
        </div>
      </div>

      {/* ── Safe / Cancelled outcome banner ── */}
      {(status === 'safe' || status === 'cancelled') && (
        <div className={`sci-outcome-banner sci-outcome-banner--${status}`}>
          {status === 'safe'
            ? <><CheckCircle2 size={14} /> Check-in confirmed safe.</>
            : <><X size={14} /> Timer cancelled.</>
          }
          <button className="sci-outcome-reset" onClick={resetIdle}>New session</button>
        </div>
      )}

      {/* ── Active timer ring ── */}
      {status === 'active' && session && (
        <div className="sci-active-section">
          <CountdownRing
            remaining={remaining}
            total={session.duration_minutes * 60}
            danger={remaining < 60}
            label={fmt(remaining)}
            sublabel={`of ${session.duration_minutes} min`}
          />
          <div className="sci-active-gps">
            {gpsLoading
              ? <><span className="modal__spinner modal__spinner--sm" /> Acquiring GPS...</>
              : gps
                ? <><MapPin size={10} style={{ color: '#4ade80' }} /> {gps.lat.toFixed(4)}°N, {gps.lng.toFixed(4)}°</>
                : <><MapPin size={10} style={{ color: '#64748b' }} /> GPS unavailable</>
            }
          </div>
          <div className="sci-active-actions">
            <button className="sci-safe-btn" onClick={markSafe}>
              <CheckCircle2 size={14} /> I'm Safe
            </button>
            <button className="sci-cancel-btn" onClick={cancelTimer}>
              <X size={13} /> Cancel
            </button>
          </div>
          <div className="sci-active-info">
            <Zap size={10} style={{ color: '#fbbf24' }} />
            Authentication required in {fmt(remaining)} — {contacts.length} contact{contacts.length !== 1 ? 's' : ''} on standby
          </div>
        </div>
      )}

      {/* ── Timer setup (idle) ── */}
      {(status === 'idle' || status === 'safe' || status === 'cancelled') && (
        <div className="sci-setup-section">
          <div className="sci-section-label">
            <Clock size={11} /> Set Timer Window
          </div>
          <div className="sci-preset-grid">
            {PRESET_DURATIONS.map(d => (
              <button
                key={d}
                className={`sci-preset-btn${duration === d && !customMin ? ' sci-preset-btn--active' : ''}`}
                onClick={() => { setDuration(d); setCustomMin(''); }}
                style={duration === d && !customMin ? { borderColor: '#60a5fa', color: '#60a5fa', background: 'rgba(96,165,250,0.08)' } : undefined}
              >
                {d} min
              </button>
            ))}
          </div>
          <div className="sci-custom-row">
            <input
              className="sci-custom-input"
              type="number"
              min={1} max={240}
              placeholder="Custom minutes"
              value={customMin}
              onChange={e => setCustomMin(e.target.value)}
            />
            <span className="sci-custom-unit">min</span>
          </div>

          {!user ? (
            <div className="sci-sign-in-warn">
              <AlertTriangle size={12} style={{ color: '#fbbf24' }} />
              Sign in to activate Safe Check-in and store emergency sessions.
            </div>
          ) : (
            <button
              className="sci-start-btn"
              onClick={startTimer}
              style={{ background: 'linear-gradient(135deg, #1e3a5f 0%, #0f2233 100%)', borderColor: '#60a5fa' }}
            >
              <ShieldCheck size={15} />
              Activate Safe Check-in
              <ChevronRight size={13} />
            </button>
          )}

          <div className="sci-setup-info">
            <Radio size={10} style={{ color: '#334155' }} />
            On expiry: vibration alarm → PIN/biometric challenge → 60s grace → autonomous distress dispatch
          </div>
        </div>
      )}

      {/* ── Emergency contacts ── */}
      <div className="sci-contacts-section">
        <div className="sci-section-label">
          <Phone size={11} /> Emergency Contacts
          <button className="sci-contacts-refresh" onClick={loadContacts} aria-label="Refresh contacts">
            <RefreshCw size={10} />
          </button>
        </div>

        {contactsLoading ? (
          <div className="sci-loading-row"><span className="modal__spinner modal__spinner--sm" /> Loading...</div>
        ) : contacts.length === 0 ? (
          <div className="sci-no-contacts">No contacts configured. Add at least one to enable emergency dispatch.</div>
        ) : (
          <div className="sci-contact-list">
            {contacts.map(c => (
              <div key={c.id} className={`sci-contact-card${c.is_primary ? ' sci-contact-card--primary' : ''}`}>
                <div className="sci-contact-card__left">
                  <span className={`sci-contact-dot${c.is_primary ? ' sci-contact-dot--primary' : ''}`} />
                  <div className="sci-contact-card__info">
                    <span className="sci-contact-card__name">{c.name}</span>
                    <span className="sci-contact-card__phone">{c.phone}</span>
                    {c.email && <span className="sci-contact-card__email">{c.email}</span>}
                  </div>
                </div>
                <div className="sci-contact-card__right">
                  {c.is_primary && <span className="sci-primary-badge">Primary</span>}
                  <button className="sci-delete-contact-btn" onClick={() => deleteContact(c.id)} aria-label="Delete contact">
                    <Trash2 size={11} />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Add contact form */}
        {user && (
          <div className="sci-add-contact-form">
            <div className="sci-section-label" style={{ marginTop: 8 }}>
              <UserPlus size={11} /> Add Contact
            </div>
            <input className="sci-input" placeholder="Full name *" value={addName} onChange={e => setAddName(e.target.value)} />
            <input className="sci-input" placeholder="Phone (E.164: +34...) *" value={addPhone} onChange={e => setAddPhone(e.target.value)} />
            <input className="sci-input" placeholder="Email (optional)" value={addEmail} onChange={e => setAddEmail(e.target.value)} />
            <label className="sci-primary-checkbox">
              <input type="checkbox" checked={addPrimary} onChange={e => setAddPrimary(e.target.checked)} />
              Set as primary contact
            </label>
            <button
              className="sci-add-contact-btn"
              onClick={addContact}
              disabled={!addName.trim() || !addPhone.trim() || saving}
            >
              {saving
                ? <span className="modal__spinner modal__spinner--sm" />
                : <><UserPlus size={12} /> Add Contact</>
              }
            </button>
          </div>
        )}
      </div>

      {/* ── Session history ── */}
      {history.length > 0 && (
        <div className="sci-history-section">
          <div className="sci-section-label"><Clock size={11} /> Recent Sessions</div>
          <div className="sci-history-list">
            {history.map(h => {
              const hColor = h.status === 'safe' ? '#4ade80' : h.status === 'distress' ? '#f87171' : '#64748b';
              return (
                <div key={h.id} className="sci-history-row">
                  <span className="sci-history-dot" style={{ background: hColor }} />
                  <span className="sci-history-label" style={{ color: hColor }}>
                    {h.status.charAt(0).toUpperCase() + h.status.slice(1)}
                  </span>
                  <span className="sci-history-dur">{h.duration_minutes} min</span>
                  <span className="sci-history-date">
                    {new Date(h.started_at).toLocaleDateString()}
                  </span>
                  {h.maps_link && (
                    <a href={h.maps_link} target="_blank" rel="noopener noreferrer" className="sci-history-map">
                      <MapPin size={9} />
                    </a>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* ── Security footer ── */}
      <div className="sci-footer">
        <ShieldCheck size={9} style={{ color: '#4ade80' }} />
        <span>E2EE · GPS processed locally · RLS protected · GDPR compliant</span>
        <Building2 size={9} style={{ color: '#334155' }} />
      </div>

      <AippieVoiceOverlay context="guardian" />

    </div>
  );
}
