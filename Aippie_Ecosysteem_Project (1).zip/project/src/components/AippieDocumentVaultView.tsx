import { useState, useRef, useEffect, useCallback } from 'react';
import {
  FolderLock, Upload, FileText, Shield, Eye, AlertTriangle,
  Download, Trash2, MapPin, Globe, Lock, ShieldCheck, X,
  FileImage, RefreshCw,
} from 'lucide-react';
import { supabase } from '../lib/supabase';
import type { User } from '@supabase/supabase-js';

interface VaultDoc {
  id: string;
  user_id: string;
  name: string;
  size: number;
  mime_type: string;
  storage_path: string;
  created_at: string;
  access_count: number;
}

interface WatermarkData {
  ip: string;
  lat: number | null;
  lng: number | null;
  pin: string;
  ts: string;
}

async function getClientIp(): Promise<string> {
  try {
    const r = await fetch('https://api.ipify.org?format=json');
    const d = await r.json();
    return d.ip ?? 'unknown';
  } catch {
    return 'unknown';
  }
}

function getGeoPosition(): Promise<{ lat: number; lng: number } | null> {
  return new Promise(resolve => {
    if (!navigator.geolocation) { resolve(null); return; }
    navigator.geolocation.getCurrentPosition(
      p => resolve({ lat: parseFloat(p.coords.latitude.toFixed(4)), lng: parseFloat(p.coords.longitude.toFixed(4)) }),
      () => resolve(null),
      { timeout: 4000 }
    );
  });
}

function fmtBytes(b: number): string {
  if (b < 1024) return `${b} B`;
  if (b < 1048576) return `${(b / 1024).toFixed(1)} KB`;
  return `${(b / 1048576).toFixed(1)} MB`;
}

function fmtDate(ts: string): string {
  return new Date(ts).toLocaleDateString(undefined, { day: '2-digit', month: 'short', year: 'numeric' });
}

function getDocIcon(mime: string) {
  if (mime.startsWith('image/')) return <FileImage size={18} />;
  return <FileText size={18} />;
}

export default function AippieDocumentVaultView({ user, userPin }: { user: User | null; userPin?: string }) {
  const [docs, setDocs] = useState<VaultDoc[]>([]);
  const [loading, setLoading] = useState(true);
  const [uploading, setUploading] = useState(false);
  const [uploadErr, setUploadErr] = useState('');
  const [viewingDoc, setViewingDoc] = useState<VaultDoc | null>(null);
  const [viewUrl, setViewUrl] = useState<string | null>(null);
  const [watermark, setWatermark] = useState<WatermarkData | null>(null);
  const [watermarkReady, setWatermarkReady] = useState(false);
  const [deleteConfirm, setDeleteConfirm] = useState<string | null>(null);
  const [blurred, setBlurred] = useState(false);

  const canvasRef = useRef<HTMLCanvasElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Screenshot protection
  useEffect(() => {
    const onVisibility = () => { if (viewingDoc) setBlurred(document.hidden); };
    document.addEventListener('visibilitychange', onVisibility);
    return () => document.removeEventListener('visibilitychange', onVisibility);
  }, [viewingDoc]);

  const loadDocs = useCallback(async () => {
    if (!user) return;
    setLoading(true);
    const { data } = await supabase
      .from('vault_documents')
      .select('*')
      .eq('user_id', user.id)
      .order('created_at', { ascending: false });
    setDocs((data ?? []) as VaultDoc[]);
    setLoading(false);
  }, [user]);

  useEffect(() => { loadDocs(); }, [loadDocs]);

  const handleUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !user) return;
    if (file.size > 20 * 1024 * 1024) { setUploadErr('File too large. Maximum 20 MB.'); return; }

    const allowed = ['application/pdf', 'image/jpeg', 'image/png', 'image/webp', 'image/gif', 'text/plain'];
    if (!allowed.includes(file.type)) { setUploadErr('Unsupported file type. PDF, images, and text files only.'); return; }

    setUploadErr('');
    setUploading(true);

    const path = `${user.id}/${Date.now()}_${file.name.replace(/[^a-zA-Z0-9._-]/g, '_')}`;
    const { error: storageErr } = await supabase.storage.from('vault_documents').upload(path, file, {
      contentType: file.type,
      upsert: false,
    });

    if (storageErr) {
      setUploadErr(`Upload failed: ${storageErr.message}`);
      setUploading(false);
      return;
    }

    const { error: dbErr } = await supabase.from('vault_documents').insert({
      user_id: user.id,
      name: file.name,
      size: file.size,
      mime_type: file.type,
      storage_path: path,
      access_count: 0,
    });

    if (dbErr) {
      setUploadErr('Could not register document. Please try again.');
    } else {
      await loadDocs();
    }
    setUploading(false);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const openDoc = async (doc: VaultDoc) => {
    setBlurred(false);
    setWatermarkReady(false);
    setViewingDoc(doc);
    setViewUrl(null);

    // Increment access counter
    supabase.from('vault_documents').update({ access_count: doc.access_count + 1 }).eq('id', doc.id);

    // Get signed URL (60 second expiry — never cached)
    const { data } = await supabase.storage.from('vault_documents').createSignedUrl(doc.storage_path, 60);
    if (data?.signedUrl) setViewUrl(data.signedUrl);

    // Collect watermark data in parallel
    const [ip, geo] = await Promise.all([getClientIp(), getGeoPosition()]);
    setWatermark({
      ip,
      lat: geo?.lat ?? null,
      lng: geo?.lng ?? null,
      pin: userPin ?? '?????',
      ts: new Date().toLocaleString(),
    });
    setWatermarkReady(true);
  };

  // Draw watermark overlay onto canvas after doc loads
  const drawWatermark = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas || !watermark) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    canvas.width  = canvas.offsetWidth;
    canvas.height = canvas.offsetHeight;

    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // ── Repeating diagonal tiled watermark ───────────────────────────────
    ctx.save();
    ctx.font = 'bold 11px Inter, system-ui, sans-serif';
    ctx.fillStyle = 'rgba(59, 130, 246, 0.18)';
    ctx.strokeStyle = 'rgba(15, 23, 42, 0.12)';
    ctx.lineWidth = 0.5;

    const lines = [
      `IP: ${watermark.ip}`,
      watermark.lat !== null ? `GPS: ${watermark.lat}, ${watermark.lng}` : 'GPS: unavailable',
      `PIN: ${watermark.pin}`,
      watermark.ts,
    ].join('  |  ');

    const spacing = 80;
    const rows = Math.ceil(canvas.height / spacing) + 2;
    const cols = 3;

    for (let row = -1; row < rows; row++) {
      for (let col = 0; col < cols; col++) {
        const x = (canvas.width / cols) * col + 20;
        const y = row * spacing + (col % 2 === 0 ? 0 : spacing / 2);
        ctx.save();
        ctx.translate(x, y);
        ctx.rotate(-22 * Math.PI / 180);
        ctx.strokeText(lines, 0, 0);
        ctx.fillText(lines, 0, 0);
        ctx.restore();
      }
    }

    ctx.restore();

    // ── Prominent security notice bar at top ─────────────────────────────
    const barH = 28;
    ctx.fillStyle = 'rgba(5, 10, 28, 0.72)';
    ctx.fillRect(0, 0, canvas.width, barH);
    ctx.font = 'bold 10px Inter, system-ui, sans-serif';
    ctx.fillStyle = 'rgba(34, 211, 238, 0.9)';
    ctx.fillText(
      `\u26A0 AIPPIESHIELD VERTROUWELIJK — Viewer: PIN ${watermark.pin}  |  IP: ${watermark.ip}  |  ${watermark.ts}  |  Forensisch watermerk actief`,
      10, 18,
    );

    // ── Security notice bar at bottom ────────────────────────────────────
    ctx.fillStyle = 'rgba(5, 10, 28, 0.72)';
    ctx.fillRect(0, canvas.height - barH, canvas.width, barH);
    ctx.fillStyle = 'rgba(239, 68, 68, 0.85)';
    ctx.fillText(
      '\u26A0 Dit document is beveiligd. Ongeautoriseerde verspreiding, afdruk of schermopname is strafbaar.',
      10,
      canvas.height - 10,
    );
  }, [watermark]);

  useEffect(() => {
    if (watermarkReady) {
      requestAnimationFrame(drawWatermark);
    }
  }, [watermarkReady, drawWatermark]);

  const deleteDoc = async (id: string, path: string) => {
    await supabase.storage.from('vault_documents').remove([path]);
    await supabase.from('vault_documents').delete().eq('id', id);
    setDeleteConfirm(null);
    if (viewingDoc?.id === id) { setViewingDoc(null); setViewUrl(null); }
    loadDocs();
  };

  if (!user) {
    return (
      <div className="dv-root dv-center">
        <Lock size={40} className="dv-empty-icon" />
        <p className="dv-empty-text">Sign in to access Document Vault</p>
      </div>
    );
  }

  // Document viewer modal
  if (viewingDoc) {
    const isImage = viewingDoc.mime_type.startsWith('image/');
    const isPdf   = viewingDoc.mime_type === 'application/pdf';

    return (
      <div className="dv-root">
        {blurred && (
          <div className="dv-blur-overlay">
            <Lock size={44} />
            <p>Return to view document</p>
            <span>Screenshot protection active</span>
          </div>
        )}

        <div className={`dv-viewer${blurred ? ' dv-viewer--blurred' : ''}`}>
          {/* Viewer topbar */}
          <div className="dv-viewer-topbar">
            <div className="dv-viewer-topbar__info">
              {getDocIcon(viewingDoc.mime_type)}
              <span className="dv-viewer-topbar__name">{viewingDoc.name}</span>
            </div>
            <div className="dv-viewer-topbar__actions">
              <span className="dv-viewer-badge">
                <Eye size={11} /> View #{viewingDoc.access_count + 1}
              </span>
              <button className="dv-viewer-close" onClick={() => { setViewingDoc(null); setViewUrl(null); setBlurred(false); }}>
                <X size={18} />
              </button>
            </div>
          </div>

          {/* Watermark bar */}
          {watermarkReady && watermark && (
            <div className="dv-watermark-bar">
              <Shield size={11} />
              <span>
                Watermarked · IP {watermark.ip}
                {watermark.lat !== null && ` · GPS ${watermark.lat}, ${watermark.lng}`}
                {` · PIN ${watermark.pin}`}
              </span>
            </div>
          )}

          {/* Sandboxed viewer content */}
          <div className="dv-viewer-content" style={{ position: 'relative' }}>
            {!viewUrl && (
              <div className="dv-viewer-loading">
                <RefreshCw size={22} className="dv-spin" />
                <p>Loading secure document…</p>
              </div>
            )}

            {viewUrl && isImage && (
              <img
                src={viewUrl}
                alt={viewingDoc.name}
                className="dv-viewer-image"
                onLoad={() => setWatermarkReady(true)}
                style={{ userSelect: 'none', WebkitUserSelect: 'none', pointerEvents: 'none' }}
                draggable={false}
              />
            )}

            {viewUrl && isPdf && (
              <iframe
                src={`${viewUrl}#toolbar=0&navpanes=0&scrollbar=0`}
                className="dv-viewer-iframe"
                title={viewingDoc.name}
                sandbox="allow-same-origin allow-scripts"
              />
            )}

            {viewUrl && !isImage && !isPdf && (
              <div className="dv-viewer-unsupported">
                <FileText size={40} />
                <p>Preview unavailable for this file type.</p>
              </div>
            )}

            {/* Watermark canvas overlay */}
            {watermarkReady && (
              <canvas
                ref={canvasRef}
                className="dv-watermark-canvas"
                style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', pointerEvents: 'none' }}
              />
            )}
          </div>

          {/* Sandboxed footer notice */}
          <div className="dv-viewer-footer">
            <Lock size={10} />
            <span>Sandboxed viewer · File is never saved to your device · Dynamic watermark active</span>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="dv-root">
      <div className="dv-vault">
        {/* Header */}
        <div className="dv-header">
          <div className="dv-header__icon-wrap">
            <FolderLock size={26} />
          </div>
          <div>
            <h2 className="dv-header__title">Document Vault</h2>
            <p className="dv-header__sub">Sandboxed viewer · AI watermarking · Zero local cache</p>
          </div>
        </div>

        {/* Security badges */}
        <div className="dv-sec-badges">
          {[
            { icon: <Shield size={11} />,       label: 'Never downloaded' },
            { icon: <MapPin size={11} />,        label: 'GPS watermark' },
            { icon: <Globe size={11} />,         label: 'IP watermark' },
            { icon: <Lock size={11} />,          label: 'PIN watermark' },
            { icon: <Eye size={11} />,           label: 'Screenshot blocked' },
            { icon: <ShieldCheck size={11} />,   label: 'Access logged' },
          ].map(b => (
            <span key={b.label} className="dv-sec-badge">{b.icon} {b.label}</span>
          ))}
        </div>

        {/* Upload zone */}
        <div
          className={`dv-upload-zone${uploading ? ' dv-upload-zone--uploading' : ''}`}
          onClick={() => !uploading && fileInputRef.current?.click()}
          onDragOver={e => e.preventDefault()}
          onDrop={e => {
            e.preventDefault();
            const file = e.dataTransfer.files[0];
            if (file && fileInputRef.current) {
              const dt = new DataTransfer();
              dt.items.add(file);
              fileInputRef.current.files = dt.files;
              fileInputRef.current.dispatchEvent(new Event('change', { bubbles: true }));
            }
          }}
        >
          <input
            ref={fileInputRef}
            type="file"
            accept=".pdf,.jpg,.jpeg,.png,.webp,.gif,.txt"
            className="dv-upload-input"
            onChange={handleUpload}
          />
          {uploading ? (
            <>
              <RefreshCw size={26} className="dv-spin dv-upload-zone__icon" />
              <p className="dv-upload-zone__label">Encrypting and storing…</p>
            </>
          ) : (
            <>
              <Upload size={26} className="dv-upload-zone__icon" />
              <p className="dv-upload-zone__label">Drop file here or click to upload</p>
              <p className="dv-upload-zone__hint">PDF, images, text · Max 20 MB</p>
            </>
          )}
        </div>

        {uploadErr && (
          <div className="dv-upload-err">
            <AlertTriangle size={13} /> {uploadErr}
          </div>
        )}

        {/* Document list */}
        <div className="dv-doc-list">
          {loading ? (
            <div className="dv-center dv-doc-list__loading">
              <RefreshCw size={18} className="dv-spin" />
              <span>Loading vault…</span>
            </div>
          ) : docs.length === 0 ? (
            <div className="dv-empty-vault">
              <FolderLock size={40} className="dv-empty-vault__icon" />
              <p className="dv-empty-vault__title">Vault is empty</p>
              <p className="dv-empty-vault__sub">Upload sensitive documents to protect them with AI watermarking</p>
            </div>
          ) : (
            docs.map(doc => (
              <div key={doc.id} className="dv-doc-row">
                <button className="dv-doc-row__main" onClick={() => openDoc(doc)}>
                  <span className="dv-doc-row__icon">{getDocIcon(doc.mime_type)}</span>
                  <div className="dv-doc-row__info">
                    <span className="dv-doc-row__name">{doc.name}</span>
                    <span className="dv-doc-row__meta">
                      {fmtBytes(doc.size)} · {fmtDate(doc.created_at)} · {doc.access_count} view{doc.access_count !== 1 ? 's' : ''}
                    </span>
                  </div>
                  <span className="dv-doc-row__view"><Eye size={14} /> View</span>
                </button>
                <button
                  className="dv-doc-row__delete"
                  onClick={() => setDeleteConfirm(doc.id)}
                  title="Delete"
                >
                  <Trash2 size={14} />
                </button>
              </div>
            ))
          )}
        </div>

        {/* Watermark explanation */}
        <div className="dv-watermark-info">
          <ShieldCheck size={13} />
          <span>
            Every viewed document is overlaid with your live IP address, GPS coordinates, and Aippie PIN.
            Any photograph of the screen is permanently traceable to your identity.
          </span>
        </div>

        {/* Download note */}
        <div className="dv-download-note">
          <Download size={11} />
          <span>Files are never downloaded to your device. All access is logged and auditable.</span>
        </div>
      </div>

      {/* Delete confirmation modal */}
      {deleteConfirm && (
        <div className="dv-modal-overlay" onClick={() => setDeleteConfirm(null)}>
          <div className="dv-modal" onClick={e => e.stopPropagation()}>
            <AlertTriangle size={28} className="dv-modal__icon" />
            <h3 className="dv-modal__title">Delete document?</h3>
            <p className="dv-modal__sub">
              This permanently removes the file from your vault. This action cannot be undone.
            </p>
            <div className="dv-modal__actions">
              <button className="dv-modal__btn dv-modal__btn--cancel" onClick={() => setDeleteConfirm(null)}>
                Cancel
              </button>
              <button
                className="dv-modal__btn dv-modal__btn--delete"
                onClick={() => {
                  const doc = docs.find(d => d.id === deleteConfirm);
                  if (doc) deleteDoc(doc.id, doc.storage_path);
                }}
              >
                <Trash2 size={14} /> Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
