/**
 * QuantumTimeMachineView — V124 Smart Glass & Quantum Time Machine
 * AIPPIETAX S.A.
 *
 * Chrono-Cinema Story Engine: Aippie narrates a personalised historical or
 * futuristic story at rate 0.82 with typewriter subtitles. The user selects
 * an era, enters their name, and Aippie generates a cinematic prose script
 * which is read aloud sentence-by-sentence.
 *
 * LEGAL: All content is clearly labelled as AI-generated entertainment fiction
 * before any interaction begins. No biometric face-scan is performed.
 */
import { useCallback, useEffect, useRef, useState } from 'react';
import {
  AlertTriangle, Play, Square, RotateCcw, ChevronRight,
  Clock, Zap, Globe, User, Volume2, VolumeX, Sparkles,
  Film, Radio
} from 'lucide-react';
import { applyPremiumVoice, withVoicesReady, normalizeForTTS } from '../lib/ttsVoice';

const SPEECH_RATE  = 0.82;
const SPEECH_PITCH = 1.02;

// ── Era catalogue ─────────────────────────────────────────────────────────────
type EraId = 'ancient-egypt' | 'roman-empire' | 'dutch-golden-age' | 'medieval' | 'year-3000' | 'space-2500';

interface Era {
  id:         EraId;
  label:      string;
  period:     string;
  type:       'past' | 'future';
  color:      string;
  bgImage:    string;
  tagline:    string;
}

const ERAS: Era[] = [
  {
    id: 'ancient-egypt',
    label: 'Ancient Egypt',
    period: '2560 BC',
    type: 'past',
    color: '#f59e0b',
    bgImage: 'https://images.pexels.com/photos/71241/pexels-photo-71241.jpeg?auto=compress&cs=tinysrgb&w=1200&fit=crop',
    tagline: 'Trade along the Nile — build the Pyramids',
  },
  {
    id: 'roman-empire',
    label: 'The Roman Empire',
    period: '100 AD',
    type: 'past',
    color: '#dc2626',
    bgImage: 'https://images.pexels.com/photos/2064827/pexels-photo-2064827.jpeg?auto=compress&cs=tinysrgb&w=1200&fit=crop',
    tagline: 'Senate, legions, and a global trade empire',
  },
  {
    id: 'dutch-golden-age',
    label: 'The Golden Age',
    period: '1650 AD',
    type: 'past',
    color: '#0284c7',
    bgImage: 'https://images.pexels.com/photos/1796730/pexels-photo-1796730.jpeg?auto=compress&cs=tinysrgb&w=1200&fit=crop',
    tagline: 'VOC voyages, Amsterdam canals, and merchant guilds',
  },
  {
    id: 'medieval',
    label: 'Medieval Europe',
    period: '1250 AD',
    type: 'past',
    color: '#7c3aed',
    bgImage: 'https://images.pexels.com/photos/161740/castle-medieval-castle-fortress-161740.jpeg?auto=compress&cs=tinysrgb&w=1200&fit=crop',
    tagline: 'Knights, cathedrals, and Hanseatic trade routes',
  },
  {
    id: 'year-3000',
    label: 'The Year 3000',
    period: 'Year 3000',
    type: 'future',
    color: '#06b6d4',
    bgImage: 'https://images.pexels.com/photos/586063/pexels-photo-586063.jpeg?auto=compress&cs=tinysrgb&w=1200&fit=crop',
    tagline: 'Smart cities, neural interfaces, interstellar travel',
  },
  {
    id: 'space-2500',
    label: 'Space Colony 2500',
    period: 'Year 2500',
    type: 'future',
    color: '#10b981',
    bgImage: 'https://images.pexels.com/photos/41162/moon-landing-apollo-11-nasa-41162.jpeg?auto=compress&cs=tinysrgb&w=1200&fit=crop',
    tagline: 'Space stations, terraforming, galactic commerce',
  },
];

// ── Script generator ──────────────────────────────────────────────────────────
function buildCinemaScript(name: string, era: Era): string[] {
  const n = name.trim() || 'the lead character';
  const scripts: Record<EraId, string[]> = {
    'ancient-egypt': [
      `The year is 2560 BC. The blazing Egyptian sun beats down across the plains of the Nile, where thousands of workers labor on the greatest construction project humanity has ever known.`,
      `${n} stands on the bank of the Nile, dressed in fine linen robes. As a trusted advisor to Pharaoh Khufu, ${n} has been entrusted with the most honored task in the kingdom: overseeing the supply chain of the Great Pyramid of Giza.`,
      `A caravan of forty camels approaches. The merchant Amenhotep bows deeply and speaks: "Honored one, we bring one thousand granite blocks from Aswan, as agreed." ${n} inspects the cargo, nods in approval, and presses the royal seal ring into warm wax.`,
      `That evening, ${n} dines with the royal architect Imhotep by torchlight, the pyramid's blueprints spread across the table. "In twenty years," says Imhotep, "the entire world will speak of what we are building here."`,
      `${n} gazes up at the night sky and thinks of future generations — the families thousands of years from now who will look up at this monument in wonder. A legacy for eternity. Created by Aippie Chrono-Cinema for ${n}. Entirely fictional. For entertainment purposes only.`,
    ],
    'roman-empire': [
      `Rome, 100 AD. The eternal city hums with life. On the Forum Romanum, the voices of senators, merchants, and legionaries echo together across the marble stones.`,
      `${n} enters the Senate as a newly appointed trade envoy. Consul Marcus Trajanus himself rises to greet ${n}. "Welcome to the heart of the empire. Your trade route to Alexandria has increased the state treasury by ten percent."`,
      `In the port of Ostia, ${n} inspects the arriving ships — olive oil from Hispania, silk from the Far East, grain from Egypt. ${n} negotiates swiftly with the Greek captain Nikodemos and seals a five-year supply contract.`,
      `At sunset, on the Palatine Hill, ${n} presents the signed agreement to the Emperor. Trajanus smiles. "Rome builds its future on people like you."`,
      `${n} stares out over the city as the Tiber glitters in the evening light. An empire built on words, commerce, and trust. Created by Aippie Chrono-Cinema. Entirely fictional. For entertainment purposes only.`,
    ],
    'dutch-golden-age': [
      `Amsterdam, 1650. The canals shimmer in the morning light. The VOC flag flies above the East India House as a fleet of ships sails out of the harbor toward distant oceans.`,
      `${n} walks along the Herengracht, dressed in a black velvet coat with a white lace collar. As a VOC shareholder, ${n} has been invited to an extraordinary board meeting: the trade route to Japan is at stake.`,
      `In the boardroom, Director Jan de Bruijn speaks: "Ladies and gentlemen, our ship the Batavia carries spices worth one hundred thousand guilders on board. But the route is dangerous." ${n} takes the floor, proposes an alternative route around the Cape, and convinces the board.`,
      `Months later, the Batavia returns safely. The spices sell for three times the original investment. ${n} receives a portrait painted by Rembrandt van Rijn himself as a gesture of gratitude from the directors.`,
      `In the portrait, ${n} stands with a confident gaze, the Amsterdam harbor visible in the background. A moment preserved for eternity. Created by Aippie Chrono-Cinema. Entirely fictional. For entertainment purposes only.`,
    ],
    'medieval': [
      `Europe, 1250. The medieval continent lies in a web of kingdoms, crusader states, and merchant guilds. Cathedrals rise out of the mist across the horizon.`,
      `${n} rides a white horse into the town of Bruges. As an envoy of the Hanseatic League, ${n} carries a message of peace between the Count of Flanders and the Duke of Brabant.`,
      `At the market square, merchants trade cloth, spices, and gold. ${n} speaks Latin, French, and German fluently and brokers a historic trade agreement. Bishop Heinrich strikes the stone with his staff: "Witnesses! This treaty binds us for one hundred years."`,
      `That night, in the castle hall, the minstrel sings a ballad about ${n}: the diplomatic hero who brought peace without a sword. Knights and nobles raise their goblets in celebration.`,
      `${n} records the events in an illuminated codex, bound for the monastery library. Words that will outlive centuries. Created by Aippie Chrono-Cinema. Entirely fictional. For entertainment purposes only.`,
    ],
    'year-3000': [
      `The year is 3000. Earth has been transformed. Megacities rise into the stratosphere, divided by high-speed aerial transit networks. The climate has been stabilized. Humanity is united.`,
      `${n} steps out of a levitating capsule onto the rooftop of the Neo-Amsterdam tower, three hundred floors above sea level. As a neural architect for the Global City Council, ${n} has been tasked with designing the first fully self-sustaining smart city on the Moon.`,
      `The holographic interface flickers to life. An A.I. entity named Orion presents the blueprints. "${n}, the lunar colony Artemis can be fully operational within six months. Your energy solution is unique in the entire history of urban engineering."`,
      `${n} activates the neural connection and experiences the future city as a dream visualization: children playing in levitating gardens, five-generation families living together in bio-integrated residential towers.`,
      `Back in the meeting room, ${n} leans back in the chair. The future is not something you wait for. The future is something you build. Created by Aippie Chrono-Cinema for ${n}. Entirely fictional. For entertainment purposes only.`,
    ],
    'space-2500': [
      `The year is 2500. Space Station Olympus orbits the planet Mars slowly — a glittering ring of steel and light in the void. Fifty thousand colonists live and work within its walls.`,
      `${n} glides through the station's central corridor, magnetic boots on the floor. As chief engineer of the Terraforming Committee, ${n} leads the greatest project in human history: making Mars habitable for life.`,
      `On the bridge, ${n} addresses the technical team. The atmospheric processors are running at eighty percent. Scientist Dr. Yara Patel reports: "${n}, if we switch the ion reactor to secondary mode, we can reach one hundred and twenty percent capacity. Mars could be green within our generation."`,
      `${n} makes the decision. The reactor shifts over. Across the surface of Mars, the first polar ice caps begin to melt. Green. Slowly, but certainly, green.`,
      `${n} looks through the observation window at the red planet slowly changing its color. This is the moment humanity has been working toward for a thousand years. Created by Aippie Chrono-Cinema. Entirely fictional. For entertainment purposes only.`,
    ],
  };
  return scripts[era.id];
}

// ── Typewriter subtitle ───────────────────────────────────────────────────────
function useTypewriterLine(sentence: string, active: boolean) {
  const [display, setDisplay] = useState('');
  const tmr = useRef<ReturnType<typeof setInterval> | null>(null);
  useEffect(() => {
    if (tmr.current) { clearInterval(tmr.current); tmr.current = null; }
    setDisplay('');
    if (!active || !sentence) return;
    const words = sentence.split(/\s+/);
    let i = 0;
    tmr.current = setInterval(() => {
      i++;
      setDisplay(words.slice(Math.max(0, i - 12), i).join(' '));
      if (i >= words.length) { clearInterval(tmr.current!); tmr.current = null; }
    }, 420);
    return () => { if (tmr.current) { clearInterval(tmr.current); tmr.current = null; } };
  }, [sentence, active]);
  return display;
}

// ── Waveform ──────────────────────────────────────────────────────────────────
function Waveform({ active }: { active: boolean }) {
  const ref  = useRef<HTMLCanvasElement>(null);
  const fRef = useRef<number>(0);
  const tick = useRef(0);
  useEffect(() => {
    const c = ref.current; if (!c) return;
    const ctx = c.getContext('2d'); if (!ctx) return;
    const BARS = 24;
    const draw = () => {
      tick.current++;
      const tk = tick.current, W = c.width, H = c.height;
      ctx.clearRect(0, 0, W, H);
      const gap = W / BARS, bw = Math.max(2, gap - 2);
      for (let i = 0; i < BARS; i++) {
        const ph = (i / BARS) * Math.PI * 2;
        const h = active
          ? (0.1 + 0.9 * Math.abs(Math.sin(tk * 0.07 + ph))) * H
          : (0.04 + 0.03 * Math.abs(Math.sin(tk * 0.01 + ph))) * H;
        const x = i * gap + (gap - bw) / 2, y = (H - h) / 2;
        ctx.fillStyle = active ? '#38bdf8cc' : '#1e293b55';
        ctx.beginPath();
        ctx.roundRect(x, y, bw, h, Math.min(bw / 2, 3));
        ctx.fill();
      }
      fRef.current = requestAnimationFrame(draw);
    };
    fRef.current = requestAnimationFrame(draw);
    return () => cancelAnimationFrame(fRef.current);
  }, [active]);
  return <canvas ref={ref} width={200} height={32} style={{ display: 'block' }} />;
}

type Stage = 'disclaimer' | 'select-era' | 'enter-name' | 'narrating' | 'done';

export default function QuantumTimeMachineView() {
  const [stage,      setStage]      = useState<Stage>('disclaimer');
  const [selectedEra, setSelectedEra] = useState<Era | null>(null);
  const [userName,   setUserName]   = useState('');
  const [script,     setScript]     = useState<string[]>([]);
  const [lineIdx,    setLineIdx]    = useState(-1);
  const [speaking,   setSpeaking]   = useState(false);
  const [muted,      setMuted]      = useState(false);

  const cancelRef = useRef(false);
  const currentLine = lineIdx >= 0 && lineIdx < script.length ? script[lineIdx] : '';
  const subtitle   = useTypewriterLine(currentLine, speaking);

  useEffect(() => {
    return () => {
      cancelRef.current = true;
      window.speechSynthesis?.cancel();
    };
  }, []);

  const speak = useCallback((text: string, onEnd?: () => void) => {
    if (!('speechSynthesis' in window) || muted) { onEnd?.(); return; }
    cancelRef.current = true;
    window.speechSynthesis.cancel();
    cancelRef.current = false;
    setSpeaking(true);
    withVoicesReady(() => {
      const u = new SpeechSynthesisUtterance(normalizeForTTS(text));
      u.rate  = SPEECH_RATE;
      u.pitch = SPEECH_PITCH;
      applyPremiumVoice(u);
      u.onend   = () => { if (!cancelRef.current) { setSpeaking(false); onEnd?.(); } };
      u.onerror = () => { setSpeaking(false); onEnd?.(); };
      window.speechSynthesis.speak(u);
    });
  }, [muted]);

  const stopSpeech = useCallback(() => {
    cancelRef.current = true;
    window.speechSynthesis?.cancel();
    setSpeaking(false);
  }, []);

  const playFrom = useCallback((idx: number, lines: string[]) => {
    if (idx >= lines.length) { setStage('done'); return; }
    setLineIdx(idx);
    speak(lines[idx], () => playFrom(idx + 1, lines));
  }, [speak]);

  const handleStart = () => {
    if (!selectedEra) return;
    const lines = buildCinemaScript(userName, selectedEra);
    setScript(lines);
    setLineIdx(-1);
    setStage('narrating');
    setTimeout(() => playFrom(0, lines), 400);
  };

  const handleStop = () => {
    stopSpeech();
    setStage('done');
  };

  const handleReset = () => {
    stopSpeech();
    setStage('select-era');
    setSelectedEra(null);
    setUserName('');
    setScript([]);
    setLineIdx(-1);
  };

  const pastEras   = ERAS.filter(e => e.type === 'past');
  const futureEras = ERAS.filter(e => e.type === 'future');

  // ── STAGE: disclaimer ───────────────────────────────────────────────────────
  if (stage === 'disclaimer') {
    return (
      <div className="qtm-root">
        <div className="qtm-disclaimer-gate">

          {/* Mandatory disclaimer banner — always visible first */}
          <div className="qtm-disclaimer-banner" role="alert" aria-live="assertive">
            <AlertTriangle size={18} className="qtm-disclaimer-banner__icon" />
            <p className="qtm-disclaimer-banner__text">
              <strong>DISCLAIMER:</strong> This is an entirely fictional, AI-generated cinematic story in which you play the lead role.
              Strictly for entertainment purposes only.
            </p>
          </div>

          {/* Hero */}
          <div className="qtm-hero">
            <div className="qtm-hero__avatar-wrap">
              <img
                src="/Jouw_alineatekst_(2).png"
                alt="Aippie"
                className="qtm-hero__avatar"
                draggable={false}
                onError={e => {
                  (e.currentTarget as HTMLImageElement).src =
                    'https://images.pexels.com/photos/1858175/pexels-photo-1858175.jpeg?auto=compress&cs=tinysrgb&w=120&h=160&fit=crop&crop=faces';
                }}
              />
              <span className="qtm-hero__avatar-ring" />
            </div>
            <div className="qtm-hero__copy">
              <div className="qtm-hero__eyebrow">
                <Film size={13} /> Smart Glass · Quantum Time Machine
              </div>
              <h1 className="qtm-hero__title">Aippie Chrono-Cinema</h1>
              <p className="qtm-hero__sub">
                Aippie narrates a personalized cinematic story with you as the lead character.
                Choose an era — past or future — and Aippie performs your story live,
                sentence by sentence, at a calm rate of 0.82 with typewriter subtitles.
              </p>
              <ul className="qtm-hero__features">
                <li><Clock size={11} /> 3-minute cinematic narrative per era</li>
                <li><Volume2 size={11} /> Live narrated at rate 0.82</li>
                <li><Globe size={11} /> 4 historical + 2 futuristic eras</li>
                <li><Sparkles size={11} /> Fully personalized to your name</li>
              </ul>
              <button
                className="qtm-cta-btn"
                onClick={() => setStage('select-era')}
              >
                <ChevronRight size={14} /> I understand — start Chrono-Cinema
              </button>
              <p className="qtm-hero__legal">
                By continuing you confirm that you understand all story content
                is entirely fictional and created strictly for entertainment purposes.
                No biometric data is processed or stored.
                AIPPIETAX S.A. — all rights reserved.
              </p>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // ── STAGE: select-era ───────────────────────────────────────────────────────
  if (stage === 'select-era') {
    return (
      <div className="qtm-root">
        {/* Persistent disclaimer strip */}
        <div className="qtm-disclaimer-strip">
          <AlertTriangle size={11} />
          DISCLAIMER: Fictional AI story · Strictly for entertainment purposes only
        </div>

        <div className="qtm-section">
          <div className="qtm-section__header">
            <Clock size={14} style={{ color: '#f59e0b' }} />
            <span>Choose Your Era</span>
          </div>

          <div className="qtm-era-group-label qtm-era-group-label--past">
            <Clock size={11} /> Past (The Past Film)
          </div>
          <div className="qtm-era-grid">
            {pastEras.map(era => (
              <button
                key={era.id}
                className={`qtm-era-card${selectedEra?.id === era.id ? ' qtm-era-card--selected' : ''}`}
                style={{ '--era-color': era.color } as React.CSSProperties}
                onClick={() => setSelectedEra(era)}
              >
                <div
                  className="qtm-era-card__bg"
                  style={{ backgroundImage: `url(${era.bgImage})` }}
                />
                <div className="qtm-era-card__overlay" />
                <div className="qtm-era-card__body">
                  <div className="qtm-era-card__period">{era.period}</div>
                  <div className="qtm-era-card__label">{era.label}</div>
                  <div className="qtm-era-card__tagline">{era.tagline}</div>
                </div>
                {selectedEra?.id === era.id && (
                  <div className="qtm-era-card__check">✓</div>
                )}
              </button>
            ))}
          </div>

          <div className="qtm-era-group-label qtm-era-group-label--future" style={{ marginTop: 16 }}>
            <Zap size={11} /> Future (The Future Film)
          </div>
          <div className="qtm-era-grid">
            {futureEras.map(era => (
              <button
                key={era.id}
                className={`qtm-era-card${selectedEra?.id === era.id ? ' qtm-era-card--selected' : ''}`}
                style={{ '--era-color': era.color } as React.CSSProperties}
                onClick={() => setSelectedEra(era)}
              >
                <div
                  className="qtm-era-card__bg"
                  style={{ backgroundImage: `url(${era.bgImage})` }}
                />
                <div className="qtm-era-card__overlay" />
                <div className="qtm-era-card__body">
                  <div className="qtm-era-card__period">{era.period}</div>
                  <div className="qtm-era-card__label">{era.label}</div>
                  <div className="qtm-era-card__tagline">{era.tagline}</div>
                </div>
                {selectedEra?.id === era.id && (
                  <div className="qtm-era-card__check">✓</div>
                )}
              </button>
            ))}
          </div>

          {selectedEra && (
            <div className="qtm-action-row">
              <button
                className="qtm-cta-btn"
                onClick={() => setStage('enter-name')}
              >
                <ChevronRight size={13} /> Continue with {selectedEra.label}
              </button>
            </div>
          )}
        </div>
      </div>
    );
  }

  // ── STAGE: enter-name ───────────────────────────────────────────────────────
  if (stage === 'enter-name') {
    return (
      <div className="qtm-root">
        <div className="qtm-disclaimer-strip">
          <AlertTriangle size={11} />
          DISCLAIMER: Fictional AI story · Strictly for entertainment purposes only
        </div>

        <div className="qtm-section">
          <div className="qtm-section__header">
            <User size={14} style={{ color: '#38bdf8' }} />
            <span>Your Name for the Story</span>
          </div>

          {selectedEra && (
            <div className="qtm-selected-era-badge" style={{ borderColor: selectedEra.color + '55', color: selectedEra.color }}>
              <Clock size={10} /> {selectedEra.label} · {selectedEra.period}
            </div>
          )}

          <p className="qtm-field-hint">
            Aippie uses your name as the lead character throughout the story.
            You may also enter a fictional name or pseudonym.
          </p>

          <input
            className="qtm-name-input"
            type="text"
            placeholder="e.g. Sofia, Marcus, Amira…"
            value={userName}
            onChange={e => setUserName(e.target.value.slice(0, 40))}
            maxLength={40}
            autoFocus
          />

          <div className="qtm-action-row">
            <button className="qtm-ghost-btn" onClick={() => setStage('select-era')}>
              ← Back
            </button>
            <button
              className="qtm-cta-btn"
              onClick={handleStart}
            >
              <Play size={13} /> Start Chrono-Cinema
            </button>
          </div>

          <p className="qtm-hero__legal" style={{ marginTop: 12 }}>
            No biometric data is processed. Your name is not stored or transmitted.
          </p>
        </div>
      </div>
    );
  }

  // ── STAGE: narrating / done ─────────────────────────────────────────────────
  const progress = script.length > 0 ? ((lineIdx + 1) / script.length) * 100 : 0;

  return (
    <div className="qtm-root qtm-root--cinema">
      {/* Era background */}
      {selectedEra && (
        <div
          className="qtm-cinema-bg"
          style={{ backgroundImage: `url(${selectedEra.bgImage})` }}
        />
      )}
      <div className="qtm-cinema-scrim" />

      {/* Persistent disclaimer strip — always on top */}
      <div className="qtm-disclaimer-strip qtm-disclaimer-strip--cinema">
        <AlertTriangle size={11} />
        DISCLAIMER: Fictieve AI-film · Strictly for entertainment purposes only
      </div>

      {/* Narrator panel */}
      <div className="qtm-narrator-panel">
        <div className={`qtm-narrator-avatar-wrap${speaking ? ' qtm-narrator-avatar-wrap--speaking' : ''}`}>
          <img
            src="/Jouw_alineatekst_(2).png"
            alt="Aippie"
            className="qtm-narrator-avatar"
            draggable={false}
            onError={e => {
              (e.currentTarget as HTMLImageElement).src =
                'https://images.pexels.com/photos/1858175/pexels-photo-1858175.jpeg?auto=compress&cs=tinysrgb&w=100&h=130&fit=crop&crop=faces';
            }}
          />
          {speaking && (
            <>
              <span className="qtm-narrator-ring qtm-narrator-ring--1" />
              <span className="qtm-narrator-ring qtm-narrator-ring--2" />
            </>
          )}
        </div>

        <div className="qtm-narrator-info">
          <div className="qtm-narrator-label">
            {speaking ? (
              <><Radio size={10} className="qtm-pulse" /> Aippie narrating…</>
            ) : stage === 'done' ? (
              <><Sparkles size={10} /> Story complete</>
            ) : (
              <><Clock size={10} /> Ready</>
            )}
          </div>
          {selectedEra && (
            <div className="qtm-narrator-era" style={{ color: selectedEra.color }}>
              {selectedEra.label} · {selectedEra.period}
            </div>
          )}
          <Waveform active={speaking} />
        </div>

        <button
          className="qtm-mute-btn"
          onClick={() => { setMuted(m => !m); if (!muted) stopSpeech(); }}
          title={muted ? 'Unmute' : 'Mute'}
        >
          {muted ? <VolumeX size={13} /> : <Volume2 size={13} />}
        </button>
      </div>

      {/* Progress bar */}
      <div className="qtm-progress-bar">
        <div className="qtm-progress-bar__fill" style={{ width: `${progress}%` }} />
      </div>

      {/* Subtitle strip */}
      <div className={`qtm-subtitle-strip${speaking && subtitle ? ' qtm-subtitle-strip--active' : ''}`}>
        {speaking && subtitle ? subtitle : stage === 'done' ? 'End of story.' : '\u00A0'}
      </div>

      {/* Scene counter */}
      {script.length > 0 && (
        <div className="qtm-scene-counter">
          Scene {Math.max(1, lineIdx + 1)} / {script.length}
        </div>
      )}

      {/* Controls */}
      <div className="qtm-controls">
        {stage === 'narrating' && speaking && (
          <button className="qtm-ctrl-btn qtm-ctrl-btn--stop" onClick={handleStop}>
            <Square size={13} /> Stop
          </button>
        )}
        {stage === 'done' && (
          <>
            <button className="qtm-ctrl-btn" onClick={() => { handleReset(); }}>
              <RotateCcw size={13} /> New Era
            </button>
            <button
              className="qtm-ctrl-btn qtm-ctrl-btn--play"
              onClick={() => {
                if (!selectedEra) return;
                const lines = buildCinemaScript(userName, selectedEra);
                setScript(lines);
                setLineIdx(-1);
                setStage('narrating');
                setTimeout(() => playFrom(0, lines), 200);
              }}
            >
              <Play size={13} /> Play Again
            </button>
          </>
        )}
      </div>
    </div>
  );
}
