import { useState, useEffect, useCallback } from 'react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import {
  Zap, Activity, Leaf, TrendingUp, TrendingDown, BarChart3,
  ShieldCheck, Download, RefreshCw, AlertTriangle, CheckCircle,
  Play, Pause, FileText, ChevronRight, Wifi, WifiOff,
  ToggleLeft, ToggleRight, Globe, Award
} from 'lucide-react';

// ── Types ──────────────────────────────────────────────────────────────
interface LiveMeter {
  id: string;
  name: string;
  location: string;
  kw: number;
  kwh: number;
  renewable: number;
  status: 'normal' | 'peak' | 'critical';
  pf: number;
  voltage: number;
}

interface EmissionEntry {
  electricity_kwh: string;
  gas_m3: string;
  logistics_km: string;
}

interface EsgReport {
  id: string;
  report_name: string;
  standard: string;
  status: string;
  co2_total: number;
  renewable_pct: number;
  generated_at: string;
}

interface Certificate {
  id: string;
  cert_type: string;
  quantity: number;
  source_type: string;
  vintage_year: number;
  status: string;
  cost_basis: number;
}

interface Trade {
  id: string;
  trade_type: string;
  quantity: number;
  price_per_unit: number;
  total_eur: number;
  market: string;
  status: string;
  executed_at: string;
}

// ── Live market prices (simulated ticks) ──────────────────────────────
const BASE_PRICES: Record<string, number> = {
  'EU-ETS': 63.8,
  'GO': 4.2,
  'REGO': 5.7,
  'VCS': 12.4,
};

function useLivePrices() {
  const [prices, setPrices] = useState({ ...BASE_PRICES });
  useEffect(() => {
    const id = setInterval(() => {
      setPrices(prev => {
        const next = { ...prev };
        (Object.keys(next) as string[]).forEach(k => {
          next[k] = +(next[k] + (Math.random() - 0.5) * 0.3).toFixed(2);
        });
        return next;
      });
    }, 2200);
    return () => clearInterval(id);
  }, []);
  return prices;
}

// ── Meter simulation ──────────────────────────────────────────────────
const METER_BASES: Omit<LiveMeter, 'kw' | 'kwh' | 'status'>[] = [
  { id: 'M1', name: 'Productielijn A', location: 'Hal Noord',  renewable: 72, pf: 0.94, voltage: 400 },
  { id: 'M2', name: 'Koeltorens',      location: 'Buiten',     renewable: 45, pf: 0.88, voltage: 400 },
  { id: 'M3', name: 'Datacenter Core', location: 'Server-1',   renewable: 89, pf: 0.97, voltage: 230 },
  { id: 'M4', name: 'Ventilatiesyst.', location: 'Dak',        renewable: 61, pf: 0.91, voltage: 400 },
  { id: 'M5', name: 'EV-laders',       location: 'Parkeergarage', renewable: 100, pf: 0.99, voltage: 230 },
  { id: 'M6', name: 'Verlichting',     location: 'Kantoren',   renewable: 55, pf: 0.82, voltage: 230 },
];

const KW_BASES = [284, 142, 96, 58, 47, 23];

function useMeters() {
  const [meters, setMeters] = useState<LiveMeter[]>(
    METER_BASES.map((b, i) => ({
      ...b,
      kw: KW_BASES[i],
      kwh: +(KW_BASES[i] * 8.4).toFixed(0),
      status: 'normal' as const,
    }))
  );
  useEffect(() => {
    const id = setInterval(() => {
      setMeters(prev => prev.map((m, i) => {
        const kw = +(KW_BASES[i] + (Math.random() - 0.5) * KW_BASES[i] * 0.12).toFixed(1);
        const status: LiveMeter['status'] = kw > KW_BASES[i] * 1.08 ? 'critical' : kw > KW_BASES[i] * 1.04 ? 'peak' : 'normal';
        return { ...m, kw, kwh: +(m.kwh + kw / 3600 * 1.5).toFixed(1), status };
      }));
    }, 1800);
    return () => clearInterval(id);
  }, []);
  return meters;
}

// ── Colour helpers ─────────────────────────────────────────────────────
const STATUS_COLOR: Record<string, string> = {
  normal: '#22c55e',
  peak: '#f59e0b',
  critical: '#ef4444',
  available: '#22c55e',
  listed: '#38bdf8',
  sold: '#94a3b8',
  draft: '#f59e0b',
  submitted: '#38bdf8',
  certified: '#22c55e',
  pending: '#f59e0b',
  executed: '#22c55e',
  cancelled: '#ef4444',
};

const CERT_COLOR: Record<string, string> = {
  'EU-ETS': '#38bdf8',
  GO: '#22c55e',
  REGO: '#a78bfa',
  VCS: '#fb923c',
};

// ══════════════════════════════════════════════════════════════════════
export default function AippieEnergyView() {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState<'network' | 'esg' | 'trading'>('network');
  const meters = useMeters();
  const prices = useLivePrices();
  const [autoTrade, setAutoTrade] = useState(false);
  const [aiOpt, setAiOpt] = useState(true);

  // ESG
  const [emission, setEmission] = useState<EmissionEntry>({ electricity_kwh: '', gas_m3: '', logistics_km: '' });
  const [savingEmission, setSavingEmission] = useState(false);
  const [reports, setReports] = useState<EsgReport[]>([]);
  const [generatingReport, setGeneratingReport] = useState(false);
  const [reportStandard, setReportStandard] = useState('GRI');

  // Trading
  const [certs, setCerts] = useState<Certificate[]>([]);
  const [trades, setTrades] = useState<Trade[]>([]);
  const [loadingTrade, setLoadingTrade] = useState(false);

  // ── Fetch data ──────────────────────────────────────────────────────
  const fetchReports = useCallback(async () => {
    if (!user) return;
    const { data } = await supabase
      .from('esg_reports')
      .select('*')
      .eq('user_id', user.id)
      .order('generated_at', { ascending: false })
      .limit(8);
    if (data) setReports(data as EsgReport[]);
  }, [user]);

  const fetchCerts = useCallback(async () => {
    if (!user) return;
    const { data } = await supabase
      .from('green_certificates')
      .select('*')
      .eq('user_id', user.id)
      .order('created_at', { ascending: false })
      .limit(12);
    if (data) setCerts(data as Certificate[]);
  }, [user]);

  const fetchTrades = useCallback(async () => {
    if (!user) return;
    const { data } = await supabase
      .from('certificate_trades')
      .select('*')
      .eq('user_id', user.id)
      .order('executed_at', { ascending: false })
      .limit(15);
    if (data) setTrades(data as Trade[]);
  }, [user]);

  useEffect(() => {
    fetchReports();
    fetchCerts();
    fetchTrades();
  }, [fetchReports, fetchCerts, fetchTrades]);

  // ── ESG: log emissions ──────────────────────────────────────────────
  const handleLogEmission = async () => {
    if (!user) return;
    setSavingEmission(true);
    const elec = parseFloat(emission.electricity_kwh) || 0;
    const gas  = parseFloat(emission.gas_m3) || 0;
    const log  = parseFloat(emission.logistics_km) || 0;
    const scope1 = +(gas * 2.04).toFixed(4);
    const scope2 = +(elec * 0.233).toFixed(4);
    const scope3 = +(log * 0.21 / 1000).toFixed(4);
    const co2 = +(scope1 + scope2 + scope3).toFixed(4);
    const today = new Date().toISOString().slice(0, 10);
    await supabase.from('co2_emissions_log').insert({
      user_id: user.id,
      period_start: today,
      period_end: today,
      electricity_kwh: elec,
      gas_m3: gas,
      logistics_km: log,
      co2_tonnes: co2,
      scope1,
      scope2,
      scope3,
    });
    setEmission({ electricity_kwh: '', gas_m3: '', logistics_km: '' });
    setSavingEmission(false);
  };

  // ── ESG: generate report ────────────────────────────────────────────
  const handleGenerateReport = async () => {
    if (!user) return;
    setGeneratingReport(true);
    const name = `${reportStandard} Rapport ${new Date().toLocaleDateString('nl-NL', { month: 'long', year: 'numeric' })}`;
    const { data: logs } = await supabase
      .from('co2_emissions_log')
      .select('co2_tonnes, electricity_kwh')
      .eq('user_id', user.id);
    const co2Total = (logs ?? []).reduce((s: number, r: { co2_tonnes: number }) => s + (r.co2_tonnes || 0), 0);
    await supabase.from('esg_reports').insert({
      user_id: user.id,
      report_name: name,
      report_type: 'quarterly',
      standard: reportStandard,
      status: 'draft',
      co2_total: +co2Total.toFixed(4),
      renewable_pct: 67.4,
      report_data: { generated_by: 'AippieEnergy AI', logs_count: (logs ?? []).length },
    });
    await fetchReports();
    setGeneratingReport(false);
  };

  // ── Trading: sell certificate ───────────────────────────────────────
  const handleSell = async (cert: Certificate) => {
    if (!user || loadingTrade) return;
    setLoadingTrade(true);
    const market = cert.cert_type === 'GO' ? 'GO' : cert.cert_type === 'REGO' ? 'REGO' : cert.cert_type === 'VCS' ? 'VCS' : 'EU-ETS';
    const price = prices[market] ?? 10;
    const total = +(cert.quantity * price).toFixed(4);
    await supabase.from('certificate_trades').insert({
      user_id: user.id,
      cert_id: cert.id,
      trade_type: 'sell',
      quantity: cert.quantity,
      price_per_unit: price,
      total_eur: total,
      market,
      status: 'executed',
      executed_at: new Date().toISOString(),
    });
    await supabase.from('green_certificates').update({ status: 'sold' }).eq('id', cert.id);
    await Promise.all([fetchCerts(), fetchTrades()]);
    setLoadingTrade(false);
  };

  // ── Totals ──────────────────────────────────────────────────────────
  const totalKw   = meters.reduce((s, m) => s + m.kw, 0);
  const avgRenew  = meters.reduce((s, m) => s + m.renewable, 0) / meters.length;
  const certAvail = certs.filter(c => c.status === 'available');
  const certValue = certAvail.reduce((s, c) => {
    const market = c.cert_type === 'GO' ? 'GO' : c.cert_type === 'REGO' ? 'REGO' : c.cert_type === 'VCS' ? 'VCS' : 'EU-ETS';
    return s + c.quantity * (prices[market] ?? 10);
  }, 0);
  const totalRevenue = trades.filter(t => t.trade_type === 'sell' && t.status === 'executed')
    .reduce((s, t) => s + (t.total_eur || 0), 0);

  // ── Bar spark ───────────────────────────────────────────────────────
  const sparkBars = Array.from({ length: 18 }, (_, i) => ({
    h: 20 + Math.random() * 60,
    solar: Math.random() > 0.4,
  }));

  // ─────────────────────────────────────────────────────────────────────
  return (
    <div style={{ minHeight: '100vh', background: 'transparent', color: '#e2e8f0', fontFamily: 'Inter, system-ui, sans-serif', paddingBottom: 60 }}>

      {/* ── Header ── */}
      <div style={{ padding: '20px 20px 0' }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 4 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <div style={{ width: 36, height: 36, borderRadius: 10, background: 'linear-gradient(135deg,#16a34a,#22c55e)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <Zap size={18} color="#fff" strokeWidth={2.2} />
            </div>
            <div>
              <div style={{ fontWeight: 700, fontSize: 17, letterSpacing: '-0.3px' }}>Aippie Energy</div>
              <div style={{ fontSize: 11, color: '#64748b' }}>Industrieel energieplatform · Live</div>
            </div>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
            <div style={{ width: 7, height: 7, borderRadius: '50%', background: '#22c55e', boxShadow: '0 0 6px #22c55e' }} />
            <span style={{ fontSize: 11, color: '#22c55e', fontWeight: 600 }}>CONNECTED</span>
          </div>
        </div>

        {/* KPI strip */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: 8, marginTop: 16 }}>
          {[
            { label: 'Totaal verbruik', value: `${totalKw.toFixed(0)} kW`, icon: <Zap size={13} />, color: '#f59e0b' },
            { label: 'Hernieuwbaar', value: `${avgRenew.toFixed(0)}%`, icon: <Leaf size={13} />, color: '#22c55e' },
            { label: 'Cert. waarde', value: `€${certValue.toFixed(0)}`, icon: <Award size={13} />, color: '#38bdf8' },
            { label: 'Inkomsten', value: `€${totalRevenue.toFixed(0)}`, icon: <TrendingUp size={13} />, color: '#a78bfa' },
          ].map(k => (
            <div key={k.label} style={{ background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.07)', borderRadius: 10, padding: '10px 12px' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 5, color: k.color, marginBottom: 4 }}>{k.icon}<span style={{ fontSize: 10, fontWeight: 600 }}>{k.label}</span></div>
              <div style={{ fontSize: 15, fontWeight: 700, color: '#f1f5f9' }}>{k.value}</div>
            </div>
          ))}
        </div>
      </div>

      {/* ── Tabs ── */}
      <div style={{ display: 'flex', gap: 4, padding: '16px 20px 0', borderBottom: '1px solid rgba(255,255,255,0.06)', marginBottom: 0 }}>
        {([
          { id: 'network', label: 'Netwerkcontrole', icon: <Activity size={13} /> },
          { id: 'esg',     label: 'CO₂ & ESG',       icon: <Leaf size={13} /> },
          { id: 'trading', label: 'Certificatenhandel', icon: <BarChart3 size={13} /> },
        ] as { id: 'network' | 'esg' | 'trading'; label: string; icon: JSX.Element }[]).map(t => (
          <button key={t.id}
            onClick={() => setActiveTab(t.id)}
            style={{
              display: 'flex', alignItems: 'center', gap: 5,
              padding: '7px 12px', borderRadius: '8px 8px 0 0', border: 'none', cursor: 'pointer',
              fontSize: 12, fontWeight: 600, transition: 'all .15s',
              background: activeTab === t.id ? 'rgba(34,197,94,0.12)' : 'transparent',
              color: activeTab === t.id ? '#22c55e' : '#64748b',
              borderBottom: activeTab === t.id ? '2px solid #22c55e' : '2px solid transparent',
            }}
          >
            {t.icon}{t.label}
          </button>
        ))}
      </div>

      {/* ══ MODULE 1: Netwerkcontrole ══════════════════════════════════ */}
      {activeTab === 'network' && (
        <div style={{ padding: '16px 20px' }}>
          {/* AI optimalisatie toggle */}
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', background: 'rgba(34,197,94,0.06)', border: '1px solid rgba(34,197,94,0.15)', borderRadius: 10, padding: '12px 16px', marginBottom: 14 }}>
            <div>
              <div style={{ fontSize: 13, fontWeight: 700, color: '#22c55e' }}>AI Piekbelasting Optimizer</div>
              <div style={{ fontSize: 11, color: '#64748b', marginTop: 2 }}>Stem verbruik in milliseconden af op goedkoopste groene uren</div>
            </div>
            <button onClick={() => setAiOpt(v => !v)} style={{ background: 'none', border: 'none', cursor: 'pointer', padding: 0 }}>
              {aiOpt
                ? <ToggleRight size={30} color="#22c55e" />
                : <ToggleLeft size={30} color="#475569" />}
            </button>
          </div>

          {/* Sparkline */}
          <div style={{ background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.06)', borderRadius: 10, padding: '12px 14px', marginBottom: 14 }}>
            <div style={{ display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between', marginBottom: 6 }}>
              <span style={{ fontSize: 11, color: '#94a3b8', fontWeight: 600 }}>24h VERBRUIKSPROFIEL (kW)</span>
              <span style={{ fontSize: 10, color: '#22c55e' }}>● Hernieuwbaar &nbsp; <span style={{ color: '#f59e0b' }}>● Piek</span></span>
            </div>
            <div style={{ display: 'flex', alignItems: 'flex-end', gap: 2, height: 56 }}>
              {sparkBars.map((b, i) => (
                <div key={i} style={{ flex: 1, borderRadius: 3, background: b.solar ? 'rgba(34,197,94,0.55)' : 'rgba(245,158,11,0.55)', height: `${b.h}%`, transition: 'height .5s' }} />
              ))}
            </div>
          </div>

          {/* Meters grid */}
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
            {meters.map(m => (
              <div key={m.id} style={{ background: 'rgba(255,255,255,0.04)', border: `1px solid ${STATUS_COLOR[m.status]}33`, borderRadius: 10, padding: '11px 13px' }}>
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 6 }}>
                  <span style={{ fontSize: 12, fontWeight: 700, color: '#e2e8f0' }}>{m.name}</span>
                  <span style={{ fontSize: 9, fontWeight: 700, color: STATUS_COLOR[m.status], textTransform: 'uppercase', background: `${STATUS_COLOR[m.status]}20`, padding: '2px 5px', borderRadius: 4 }}>
                    {m.status}
                  </span>
                </div>
                <div style={{ fontSize: 10, color: '#64748b', marginBottom: 8 }}>{m.location}</div>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 4 }}>
                  {[
                    { l: 'Verbruik', v: `${m.kw} kW` },
                    { l: 'Vandaag', v: `${m.kwh} kWh` },
                    { l: 'Hernieuwb.', v: `${m.renewable}%` },
                    { l: 'Cosφ', v: m.pf.toFixed(2) },
                  ].map(item => (
                    <div key={item.l} style={{ background: 'rgba(255,255,255,0.04)', borderRadius: 6, padding: '5px 7px' }}>
                      <div style={{ fontSize: 9, color: '#475569' }}>{item.l}</div>
                      <div style={{ fontSize: 12, fontWeight: 700, color: '#f1f5f9' }}>{item.v}</div>
                    </div>
                  ))}
                </div>
                {/* Renewable bar */}
                <div style={{ marginTop: 7, height: 3, borderRadius: 2, background: 'rgba(255,255,255,0.08)' }}>
                  <div style={{ height: '100%', width: `${m.renewable}%`, borderRadius: 2, background: 'linear-gradient(90deg,#16a34a,#22c55e)', transition: 'width .6s' }} />
                </div>
              </div>
            ))}
          </div>

          {/* Alerts */}
          {meters.some(m => m.status !== 'normal') && (
            <div style={{ marginTop: 12, background: 'rgba(245,158,11,0.08)', border: '1px solid rgba(245,158,11,0.2)', borderRadius: 10, padding: '10px 14px' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 6 }}>
                <AlertTriangle size={13} color="#f59e0b" />
                <span style={{ fontSize: 12, fontWeight: 700, color: '#f59e0b' }}>AI Netwerkalerts</span>
              </div>
              {meters.filter(m => m.status !== 'normal').map(m => (
                <div key={m.id} style={{ fontSize: 11, color: '#94a3b8', marginBottom: 3 }}>
                  ↳ <b style={{ color: STATUS_COLOR[m.status] }}>{m.name}</b> — {m.status === 'critical' ? 'Kritisch verbruik, AI stuurt bij' : 'Piekbelasting gedetecteerd'}
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* ══ MODULE 2: CO₂ & ESG ══════════════════════════════════════ */}
      {activeTab === 'esg' && (
        <div style={{ padding: '16px 20px' }}>
          {/* Scope breakdown */}
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 8, marginBottom: 14 }}>
            {[
              { label: 'Scope 1', sub: 'Directe emissies', color: '#ef4444', pct: 18 },
              { label: 'Scope 2', sub: 'Elektriciteit', color: '#f59e0b', pct: 47 },
              { label: 'Scope 3', sub: 'Logistiek', color: '#38bdf8', pct: 35 },
            ].map(s => (
              <div key={s.label} style={{ background: 'rgba(255,255,255,0.04)', border: `1px solid ${s.color}22`, borderRadius: 10, padding: '11px 12px' }}>
                <div style={{ fontSize: 11, fontWeight: 700, color: s.color }}>{s.label}</div>
                <div style={{ fontSize: 9, color: '#475569', marginBottom: 6 }}>{s.sub}</div>
                <div style={{ fontSize: 18, fontWeight: 800, color: '#f1f5f9' }}>{s.pct}%</div>
                <div style={{ marginTop: 6, height: 3, borderRadius: 2, background: 'rgba(255,255,255,0.06)' }}>
                  <div style={{ height: '100%', width: `${s.pct}%`, borderRadius: 2, background: s.color }} />
                </div>
              </div>
            ))}
          </div>

          {/* Log emissions form */}
          <div style={{ background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.07)', borderRadius: 12, padding: '14px 16px', marginBottom: 14 }}>
            <div style={{ fontSize: 13, fontWeight: 700, color: '#e2e8f0', marginBottom: 10 }}>
              <Activity size={13} style={{ marginRight: 5, verticalAlign: 'middle' }} />
              Verbruiksdata Invoeren
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr', gap: 8, marginBottom: 10 }}>
              {[
                { key: 'electricity_kwh' as const, label: 'Elektriciteit (kWh)', ph: 'bijv. 12500' },
                { key: 'gas_m3' as const, label: 'Gas (m³)', ph: 'bijv. 840' },
                { key: 'logistics_km' as const, label: 'Logistiek (km)', ph: 'bijv. 15000' },
              ].map(f => (
                <div key={f.key}>
                  <label style={{ fontSize: 10, color: '#64748b', fontWeight: 600, display: 'block', marginBottom: 3 }}>{f.label}</label>
                  <input
                    type="number"
                    placeholder={f.ph}
                    value={emission[f.key]}
                    onChange={e => setEmission(prev => ({ ...prev, [f.key]: e.target.value }))}
                    style={{ width: '100%', background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 7, padding: '9px 12px', color: '#e2e8f0', fontSize: 13, outline: 'none', boxSizing: 'border-box' }}
                  />
                </div>
              ))}
            </div>
            <button
              onClick={handleLogEmission}
              disabled={savingEmission}
              style={{ width: '100%', background: savingEmission ? '#1e293b' : '#16a34a', border: 'none', borderRadius: 8, padding: '10px', color: '#fff', fontSize: 13, fontWeight: 700, cursor: savingEmission ? 'not-allowed' : 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6 }}
            >
              {savingEmission ? <><RefreshCw size={13} />&nbsp;Berekenen…</> : <><CheckCircle size={13} />&nbsp;CO₂-voetafdruk berekenen &amp; opslaan</>}
            </button>
          </div>

          {/* Report generator */}
          <div style={{ background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.07)', borderRadius: 12, padding: '14px 16px', marginBottom: 14 }}>
            <div style={{ fontSize: 13, fontWeight: 700, color: '#e2e8f0', marginBottom: 10 }}>
              <FileText size={13} style={{ marginRight: 5, verticalAlign: 'middle' }} />
              Officieel ESG-Rapport Genereren
            </div>
            <div style={{ display: 'flex', gap: 6, marginBottom: 10 }}>
              {['GRI', 'CSRD', 'EU-ETS', 'TCFD'].map(s => (
                <button key={s}
                  onClick={() => setReportStandard(s)}
                  style={{ padding: '5px 10px', borderRadius: 6, border: `1px solid ${reportStandard === s ? '#22c55e' : 'rgba(255,255,255,0.1)'}`, background: reportStandard === s ? 'rgba(34,197,94,0.12)' : 'transparent', color: reportStandard === s ? '#22c55e' : '#64748b', fontSize: 11, fontWeight: 700, cursor: 'pointer' }}
                >
                  {s}
                </button>
              ))}
            </div>
            <button
              onClick={handleGenerateReport}
              disabled={generatingReport}
              style={{ width: '100%', background: generatingReport ? '#1e293b' : 'linear-gradient(90deg,#0f766e,#0d9488)', border: 'none', borderRadius: 8, padding: '10px', color: '#fff', fontSize: 13, fontWeight: 700, cursor: generatingReport ? 'not-allowed' : 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6 }}
            >
              {generatingReport ? <><RefreshCw size={13} />&nbsp;AI genereert rapport…</> : <><Download size={13} />&nbsp;Genereer {reportStandard}-compliant Rapport</>}
            </button>
          </div>

          {/* Reports list */}
          {reports.length > 0 && (
            <div>
              <div style={{ fontSize: 11, fontWeight: 700, color: '#64748b', marginBottom: 8, textTransform: 'uppercase', letterSpacing: '0.06em' }}>Gegenereerde Rapporten</div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
                {reports.map(r => (
                  <div key={r.id} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.06)', borderRadius: 9, padding: '10px 13px' }}>
                    <div>
                      <div style={{ fontSize: 12, fontWeight: 700, color: '#e2e8f0' }}>{r.report_name}</div>
                      <div style={{ fontSize: 10, color: '#475569', marginTop: 2 }}>CO₂: {(r.co2_total || 0).toFixed(2)} ton · {r.renewable_pct}% hernieuwbaar</div>
                    </div>
                    <div style={{ textAlign: 'right' }}>
                      <span style={{ fontSize: 9, fontWeight: 700, color: STATUS_COLOR[r.status] || '#94a3b8', background: `${STATUS_COLOR[r.status] || '#94a3b8'}18`, padding: '2px 6px', borderRadius: 4, textTransform: 'uppercase' }}>{r.status}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
          {reports.length === 0 && (
            <div style={{ textAlign: 'center', color: '#334155', fontSize: 12, padding: '20px 0' }}>Nog geen rapporten. Log verbruiksdata en genereer je eerste rapport.</div>
          )}
        </div>
      )}

      {/* ══ MODULE 3: Certificatenhandel ══════════════════════════════ */}
      {activeTab === 'trading' && (
        <div style={{ padding: '16px 20px' }}>
          {/* Live market prices */}
          <div style={{ marginBottom: 14 }}>
            <div style={{ fontSize: 11, fontWeight: 700, color: '#64748b', marginBottom: 8, textTransform: 'uppercase', letterSpacing: '0.06em' }}>Live Marktprijzen</div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
              {Object.entries(prices).map(([market, price]) => {
                const prev = BASE_PRICES[market];
                const up = price >= prev;
                return (
                  <div key={market} style={{ background: 'rgba(255,255,255,0.04)', border: `1px solid ${CERT_COLOR[market] || '#334155'}33`, borderRadius: 10, padding: '10px 13px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                    <div>
                      <div style={{ fontSize: 10, fontWeight: 700, color: CERT_COLOR[market] || '#94a3b8' }}>{market}</div>
                      <div style={{ fontSize: 16, fontWeight: 800, color: '#f1f5f9' }}>€{price.toFixed(2)}</div>
                    </div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 3, color: up ? '#22c55e' : '#ef4444', fontSize: 11, fontWeight: 700 }}>
                      {up ? <TrendingUp size={12} /> : <TrendingDown size={12} />}
                      {up ? '+' : ''}{(price - prev).toFixed(2)}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Auto-trade toggle */}
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', background: 'rgba(56,189,248,0.06)', border: '1px solid rgba(56,189,248,0.15)', borderRadius: 10, padding: '12px 16px', marginBottom: 14 }}>
            <div>
              <div style={{ fontSize: 13, fontWeight: 700, color: '#38bdf8' }}>Autonoom Handelsalgoritme</div>
              <div style={{ fontSize: 11, color: '#64748b', marginTop: 2 }}>Verkoopt certificaten automatisch op de hoogste live-koers</div>
            </div>
            <button onClick={() => setAutoTrade(v => !v)} style={{ background: 'none', border: 'none', cursor: 'pointer', padding: 0 }}>
              {autoTrade
                ? <ToggleRight size={30} color="#38bdf8" />
                : <ToggleLeft size={30} color="#475569" />}
            </button>
          </div>

          {/* Certificates portfolio */}
          {certs.length > 0 ? (
            <div style={{ marginBottom: 14 }}>
              <div style={{ fontSize: 11, fontWeight: 700, color: '#64748b', marginBottom: 8, textTransform: 'uppercase', letterSpacing: '0.06em' }}>Certificatenportefeuille</div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
                {certs.map(c => {
                  const market = c.cert_type === 'GO' ? 'GO' : c.cert_type === 'REGO' ? 'REGO' : c.cert_type === 'VCS' ? 'VCS' : 'EU-ETS';
                  const liveVal = +(c.quantity * (prices[market] ?? 10)).toFixed(2);
                  return (
                    <div key={c.id} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.07)', borderRadius: 10, padding: '10px 13px' }}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                        <div style={{ width: 28, height: 28, borderRadius: 7, background: `${CERT_COLOR[c.cert_type] || '#94a3b8'}22`, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                          <Globe size={13} color={CERT_COLOR[c.cert_type] || '#94a3b8'} />
                        </div>
                        <div>
                          <div style={{ fontSize: 12, fontWeight: 700, color: '#e2e8f0' }}>{c.cert_type} · {c.source_type}</div>
                          <div style={{ fontSize: 10, color: '#475569' }}>{c.quantity} eenheden · {c.vintage_year}</div>
                        </div>
                      </div>
                      <div style={{ textAlign: 'right', display: 'flex', alignItems: 'center', gap: 8 }}>
                        <div>
                          <div style={{ fontSize: 13, fontWeight: 700, color: '#22c55e' }}>€{liveVal}</div>
                          <span style={{ fontSize: 9, color: STATUS_COLOR[c.status] || '#94a3b8', fontWeight: 700, textTransform: 'uppercase' }}>{c.status}</span>
                        </div>
                        {c.status === 'available' && (
                          <button
                            onClick={() => handleSell(c)}
                            disabled={loadingTrade}
                            style={{ background: 'linear-gradient(135deg,#16a34a,#22c55e)', border: 'none', borderRadius: 7, padding: '6px 10px', color: '#fff', fontSize: 11, fontWeight: 700, cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 4 }}
                          >
                            <ChevronRight size={11} />Verkoop
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          ) : (
            <div style={{ textAlign: 'center', color: '#334155', fontSize: 12, padding: '12px 0 6px' }}>
              Geen certificaten in portefeuille.
            </div>
          )}

          {/* Trade history */}
          {trades.length > 0 && (
            <div>
              <div style={{ fontSize: 11, fontWeight: 700, color: '#64748b', marginBottom: 8, textTransform: 'uppercase', letterSpacing: '0.06em' }}>Handelshistorie</div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 5 }}>
                {trades.slice(0, 8).map(t => (
                  <div key={t.id} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.05)', borderRadius: 8, padding: '9px 12px' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                      <div style={{ width: 7, height: 7, borderRadius: '50%', background: t.trade_type === 'sell' ? '#22c55e' : '#38bdf8' }} />
                      <div>
                        <div style={{ fontSize: 11, fontWeight: 700, color: '#e2e8f0' }}>{t.trade_type === 'sell' ? 'Verkoop' : 'Aankoop'} · {t.market}</div>
                        <div style={{ fontSize: 10, color: '#475569' }}>{t.quantity} eenheden @ €{t.price_per_unit}</div>
                      </div>
                    </div>
                    <div style={{ textAlign: 'right' }}>
                      <div style={{ fontSize: 12, fontWeight: 700, color: t.trade_type === 'sell' ? '#22c55e' : '#f1f5f9' }}>€{(t.total_eur || 0).toFixed(2)}</div>
                      <div style={{ fontSize: 9, color: STATUS_COLOR[t.status] || '#94a3b8', fontWeight: 700, textTransform: 'uppercase' }}>{t.status}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {trades.length === 0 && certs.length === 0 && (
            <div style={{ textAlign: 'center', padding: '16px 0' }}>
              <ShieldCheck size={28} color="#1e3a2f" style={{ marginBottom: 8, display: 'block', margin: '0 auto 8px' }} />
              <div style={{ fontSize: 12, color: '#334155' }}>Koppel je energiemeters om automatisch groene certificaten te registreren en te verhandelen.</div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
