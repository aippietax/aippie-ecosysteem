import { AlertTriangle, X, Zap } from 'lucide-react';

interface SubscriptionBannerProps {
  status: 'trial' | 'cancelled' | 'expired';
  trialDaysLeft?: number;
  expiryDate?: string;
  onUpgrade: () => void;
  onDismiss?: () => void;
}

export default function SubscriptionBanner({ status, trialDaysLeft, expiryDate, onUpgrade, onDismiss }: SubscriptionBannerProps) {
  if (status === 'expired') {
    return (
      <div className="sub-banner sub-banner--expired">
        <div className="sub-banner__fullscreen">
          <AlertTriangle size={40} />
          <div className="sub-banner__fs-title">Suscripción expirada</div>
          <div className="sub-banner__fs-sub">Elige un plan para continuar usando AippieAccounts.</div>
          <button className="sub-banner__cta" onClick={onUpgrade}>
            <Zap size={14} />
            Elegir un plan
          </button>
        </div>
      </div>
    );
  }

  if (status === 'trial') {
    return (
      <div className="sub-banner sub-banner--trial">
        <span className="sub-banner__text">
          <strong>{trialDaysLeft ?? 14} días</strong> restantes en tu prueba gratuita.{' '}
          <button className="sub-banner__link" onClick={onUpgrade}>Actualizar ahora →</button>
        </span>
        {onDismiss && <button className="sub-banner__dismiss" onClick={onDismiss}><X size={14} /></button>}
      </div>
    );
  }

  if (status === 'cancelled') {
    return (
      <div className="sub-banner sub-banner--cancelled">
        <span className="sub-banner__text">
          Tu suscripción finaliza el <strong>{expiryDate}</strong>.{' '}
          <button className="sub-banner__link" onClick={onUpgrade}>Renovar →</button>
        </span>
        {onDismiss && <button className="sub-banner__dismiss" onClick={onDismiss}><X size={14} /></button>}
      </div>
    );
  }

  return null;
}
