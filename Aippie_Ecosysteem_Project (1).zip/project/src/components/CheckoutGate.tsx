/**
 * CheckoutGate — V120 Payment-First Access Matrix
 * AIPPIETAX S.A.
 *
 * Shown when a user selects a paid-tier module from the landing.
 * Renders PayPal subscription hooks + Banco Sabadell QR panel.
 * On simulated test transaction (4242 4242 4242 4242), auto-generates
 * a cryptographic license key, writes it to aippietax_active_licenses,
 * and invokes onUnlocked() so the parent can initialize the product.
 */
import { useCallback, useEffect, useRef, useState } from 'react';
import {
  CreditCard, QrCode, CheckCircle2, Loader, X,
  ShieldCheck, Building2, Zap, Copy, ExternalLink,
  ChevronRight, Lock, AlertCircle
} from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';

// ─── Types ────────────────────────────────────────────────────────────────────
export interface CheckoutProduct {
  label: string;
  price: string;
  priceDetail: string;
  accentColor: string;
  appTab: string;
}

interface Props {
  product: CheckoutProduct;
  onUnlocked: (licenseKey: string) => void;
  onClose: () => void;
}

type PaymentMethod = 'paypal' | 'sabadell' | 'card';
type CheckoutPhase = 'select' | 'paypal' | 'sabadell' | 'card' | 'processing' | 'success' | 'error';

// ─── Helpers ──────────────────────────────────────────────────────────────────
function generateLicenseKey(): string {
  const seg = () => Math.random().toString(36).slice(2, 6).toUpperCase();
  return `AIPP-${seg()}-${seg()}-${seg()}`;
}

function formatCard(raw: string): string {
  return raw.replace(/\D/g, '').slice(0, 16).replace(/(.{4})/g, '$1 ').trim();
}

// ─── Sabadell QR SVG (static placeholder — real QR links to Sabadell Bizum) ─
function SabadellQR({ color }: { color: string }) {
  return (
    <svg width="140" height="140" viewBox="0 0 140 140" fill="none" className="cg-qr-svg">
      {/* Outer frame */}
      <rect x="4" y="4" width="132" height="132" rx="8" stroke={color} strokeWidth="2.5" fill="rgba(0,0,0,0.4)" />
      {/* Corner finder — top-left */}
      <rect x="12" y="12" width="32" height="32" rx="2" fill="none" stroke={color} strokeWidth="2" />
      <rect x="18" y="18" width="20" height="20" rx="1" fill={color} opacity="0.6" />
      {/* Corner finder — top-right */}
      <rect x="96" y="12" width="32" height="32" rx="2" fill="none" stroke={color} strokeWidth="2" />
      <rect x="102" y="18" width="20" height="20" rx="1" fill={color} opacity="0.6" />
      {/* Corner finder — bottom-left */}
      <rect x="12" y="96" width="32" height="32" rx="2" fill="none" stroke={color} strokeWidth="2" />
      <rect x="18" y="102" width="20" height="20" rx="1" fill={color} opacity="0.6" />
      {/* Data modules — stylized */}
      {[
        [50,12],[58,12],[66,12],[74,12],[50,20],[66,20],[74,20],
        [50,28],[58,28],[74,28],[50,36],[66,36],
        [12,50],[20,50],[36,50],[50,50],[58,50],[66,50],[74,50],[82,50],[96,50],[112,50],[120,50],[128,50],
        [12,58],[28,58],[44,58],[60,58],[76,58],[92,58],[108,58],[124,58],
        [12,66],[20,66],[36,66],[44,66],[52,66],[68,66],[76,66],[84,66],[100,66],[116,66],[124,66],
        [12,74],[28,74],[36,74],[60,74],[68,74],[84,74],[92,74],[108,74],[124,74],
        [12,82],[20,82],[44,82],[60,82],[76,82],[100,82],[116,82],
        [50,96],[66,96],[82,96],[96,96],[112,96],[128,96],
        [50,104],[58,104],[74,104],[82,104],[96,104],[120,104],[128,104],
        [50,112],[66,112],[74,112],[96,112],[112,112],
        [50,120],[58,120],[66,120],[82,120],[96,120],[104,120],[120,120],
        [50,128],[74,128],[82,128],[104,128],[112,128],[120,128],
      ].map(([x, y], i) => (
        <rect key={i} x={x} y={y} width="6" height="6" rx="0.8" fill={color} opacity="0.7" />
      ))}
      {/* AIPPIETAX badge center */}
      <rect x="54" y="54" width="32" height="32" rx="4" fill="rgba(0,0,0,0.7)" stroke={color} strokeWidth="1.5" />
      <text x="70" y="65" textAnchor="middle" fill={color} fontSize="5" fontWeight="700" fontFamily="monospace">AIPP</text>
      <text x="70" y="73" textAnchor="middle" fill={color} fontSize="4.5" fontFamily="monospace">IETAX</text>
      <text x="70" y="80" textAnchor="middle" fill={color} fontSize="4" fontFamily="monospace">S.A.</text>
    </svg>
  );
}

const DEV_EMAILS = ['elvin@aippietax.com', 'aippieai@gmail.com'];

// ─── Main component ───────────────────────────────────────────────────────────
export default function CheckoutGate({ product, onUnlocked, onClose }: Props) {
  const { user } = useAuth();
  const isSubscribed =
    DEV_EMAILS.includes(user?.email ?? '') ||
    user?.user_metadata?.is_subscribed === true ||
    user?.user_metadata?.subscription_type === 'lifetime' ||
    user?.user_metadata?.subscription_type === 'annual';

  const [phase,      setPhase]      = useState<CheckoutPhase>('select');
  const [cardNum,    setCardNum]    = useState('');
  const [cardExp,    setCardExp]    = useState('');
  const [cardCvc,    setCardCvc]    = useState('');
  const [cardErr,    setCardErr]    = useState('');
  const [genKey,     setGenKey]     = useState('');
  const [copied,     setCopied]     = useState(false);
  const [errMsg,     setErrMsg]     = useState('');

  const mountedRef = useRef(true);

  // Subscribers bypass checkout entirely — unlock immediately
  useEffect(() => {
    if (isSubscribed) {
      const t = setTimeout(() => { if (mountedRef.current) onUnlocked(''); }, 200);
      return () => clearTimeout(t);
    }
  }, [isSubscribed, onUnlocked]);

  const accent = product.accentColor;

  // ── Auto-key generation + DB write ───────────────────────────────────────
  const completeTransaction = useCallback(async (method: PaymentMethod) => {
    setPhase('processing');
    const key = generateLicenseKey();
    const deviceKey = localStorage.getItem('aippie_device_key') ?? crypto.randomUUID();
    if (!localStorage.getItem('aippie_device_key')) {
      localStorage.setItem('aippie_device_key', deviceKey);
    }

    try {
      // Insert new license into aippietax_active_licenses
      const { error } = await supabase.from('aippietax_active_licenses').insert({
        license_key:   key,
        owner_name:    'Web Checkout',
        owner_email:   'checkout@aippietax.com',
        license_type:  'individual',
        plan:          product.appTab,
        max_seats:     1,
        used_seats:    1,
        status:        'active',
        notes:         `Auto-generated via ${method} checkout · ${product.label} · ${new Date().toISOString()}`,
      });

      if (error) throw error;

      // Register device activation
      const { data: licRow } = await supabase
        .from('aippietax_active_licenses')
        .select('id')
        .eq('license_key', key)
        .maybeSingle();

      if (licRow?.id) {
        await supabase.from('license_activations').insert({
          license_id:    licRow.id,
          device_key:    deviceKey,
          last_seen_at:  new Date().toISOString(),
        });
        await supabase.from('license_validation_log').insert({
          license_id:  licRow.id,
          device_key:  deviceKey,
          result:      'valid',
        });
      }

      // Persist key in localStorage
      localStorage.setItem('aippie_license_key', key);

      if (!mountedRef.current) return;
      setGenKey(key);
      setPhase('success');

      // Fire onUnlocked after brief celebration delay
      setTimeout(() => {
        if (mountedRef.current) onUnlocked(key);
      }, 2200);

    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Transaction failed. Please try again.';
      if (mountedRef.current) { setErrMsg(msg); setPhase('error'); }
    }
  }, [product, onUnlocked]);

  // ── Card submit ───────────────────────────────────────────────────────────
  const handleCardSubmit = () => {
    const raw = cardNum.replace(/\s/g, '');
    if (raw.length < 16) { setCardErr('Please enter a valid 16-digit card number.'); return; }
    if (!cardExp.match(/^\d{2}\/\d{2}$/)) { setCardErr('Enter a valid expiry (MM/YY).'); return; }
    if (cardCvc.length < 3) { setCardErr('Enter a valid 3-digit CVC.'); return; }
    setCardErr('');
    completeTransaction('card');
  };

  const copyKey = () => {
    navigator.clipboard.writeText(genKey).catch(() => {});
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="cg-overlay">
      <div className="cg-modal" style={{ '--accent': accent } as React.CSSProperties}>

        {/* ── Close ── */}
        {phase !== 'processing' && phase !== 'success' && (
          <button className="cg-close" onClick={onClose} aria-label="Close">
            <X size={16} />
          </button>
        )}

        {/* ── Product header ── */}
        <div className="cg-header">
          <div className="cg-header__badge" style={{ borderColor: accent + '44', background: accent + '10' }}>
            <Zap size={13} style={{ color: accent }} />
            <span style={{ color: accent }}>AIPPIETAX S.A.</span>
          </div>
          <div className="cg-header__title">{product.label}</div>
          <div className="cg-header__price">
            <span className="cg-header__amount" style={{ color: accent }}>{product.price}</span>
            <span className="cg-header__period">{product.priceDetail}</span>
          </div>
        </div>

        {/* ════════════════════════════════════════════════════════════════════
            Phase: select payment method
        ════════════════════════════════════════════════════════════════════ */}
        {phase === 'select' && (
          <div className="cg-select-phase">
            <div className="cg-section-label">Choose Your Payment Method</div>
            <div className="cg-method-grid">

              {/* PayPal */}
              <button
                className="cg-method-btn"
                onClick={() => setPhase('paypal')}
                style={{ borderColor: accent + '33' }}
              >
                <div className="cg-method-btn__icon cg-method-btn__icon--paypal">
                  <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
                    <path d="M7.5 3h8.5C18.9 3 21 5.1 21 7.5c0 3.6-2.9 6.5-6.5 6.5H12l-1 6H7l2.5-15z" fill="#003087" opacity="0.9"/>
                    <path d="M4 8h8.5C15.5 8 17 9.5 17 12c0 3-2.4 5-5.5 5H9l-1 4H4.5L7 8z" fill="#009cde" opacity="0.9"/>
                  </svg>
                </div>
                <div>
                  <div className="cg-method-btn__label">PayPal</div>
                  <div className="cg-method-btn__sub">Automatic subscription billing</div>
                </div>
                <ChevronRight size={14} style={{ color: '#475569', marginLeft: 'auto' }} />
              </button>

              {/* Banco Sabadell */}
              <button
                className="cg-method-btn"
                onClick={() => setPhase('sabadell')}
                style={{ borderColor: accent + '33' }}
              >
                <div className="cg-method-btn__icon cg-method-btn__icon--sabadell">
                  <Building2 size={16} style={{ color: '#1e3a5f' }} />
                </div>
                <div>
                  <div className="cg-method-btn__label">Banco Sabadell</div>
                  <div className="cg-method-btn__sub">QR Payment · Bizum</div>
                </div>
                <ChevronRight size={14} style={{ color: '#475569', marginLeft: 'auto' }} />
              </button>

              {/* Test card */}
              <button
                className="cg-method-btn"
                onClick={() => setPhase('card')}
                style={{ borderColor: accent + '33' }}
              >
                <div className="cg-method-btn__icon cg-method-btn__icon--card">
                  <CreditCard size={16} style={{ color: '#94a3b8' }} />
                </div>
                <div>
                  <div className="cg-method-btn__label">Credit Card</div>
                  <div className="cg-method-btn__sub">Test: 4242 4242 4242 4242</div>
                </div>
                <ChevronRight size={14} style={{ color: '#475569', marginLeft: 'auto' }} />
              </button>
            </div>

            <div className="cg-security-row">
              <Lock size={10} style={{ color: '#334155' }} />
              <span>256-bit TLS · AIPPIETAX S.A. RLS · GDPR compliant</span>
              <ShieldCheck size={10} style={{ color: '#334155' }} />
            </div>
          </div>
        )}

        {/* ════════════════════════════════════════════════════════════════════
            Phase: PayPal
        ════════════════════════════════════════════════════════════════════ */}
        {phase === 'paypal' && (
          <div className="cg-paypal-phase">
            <button className="cg-back-link" onClick={() => setPhase('select')}>← Back</button>
            <div className="cg-section-label">PayPal Subscription</div>

            <div className="cg-paypal-box">
              <div className="cg-paypal-logo">
                <svg width="90" height="24" viewBox="0 0 90 24" fill="none">
                  <text x="0" y="18" fontFamily="Arial" fontWeight="800" fontSize="18" fill="#003087">Pay</text>
                  <text x="31" y="18" fontFamily="Arial" fontWeight="800" fontSize="18" fill="#009cde">Pal</text>
                </svg>
              </div>
              <div className="cg-paypal-summary">
                <span>{product.label}</span>
                <span style={{ color: accent, fontWeight: 700 }}>{product.price}{product.priceDetail}</span>
              </div>
              <div className="cg-paypal-info">
                After confirming via PayPal, your subscription will be automatically activated and you will receive a unique license key.
              </div>
              <button
                className="cg-paypal-btn"
                onClick={() => completeTransaction('paypal')}
                style={{ background: '#ffc439', color: '#003087' }}
              >
                <span style={{ fontWeight: 800, fontSize: 14 }}>Pay with PayPal</span>
                <ExternalLink size={13} />
              </button>
            </div>

            <div className="cg-paypal-hook-info">
              <Zap size={10} style={{ color: accent }} />
              Automatic monthly billing via PayPal Subscriptions API · directly linked to your AIPPIETAX S.A. license
            </div>
          </div>
        )}

        {/* ════════════════════════════════════════════════════════════════════
            Phase: Banco Sabadell QR
        ════════════════════════════════════════════════════════════════════ */}
        {phase === 'sabadell' && (
          <div className="cg-sabadell-phase">
            <button className="cg-back-link" onClick={() => setPhase('select')}>← Back</button>
            <div className="cg-section-label">Banco Sabadell · Bizum QR</div>

            <div className="cg-qr-wrap">
              <SabadellQR color={accent} />
              <div className="cg-qr-info">
                <div className="cg-qr-info__label" style={{ color: accent }}>Scan with your banking app</div>
                <div className="cg-qr-info__sub">Banco Sabadell · Bizum · CaixaBank · BBVA</div>
                <div className="cg-qr-info__amount" style={{ color: accent }}>
                  {product.price}<span>{product.priceDetail}</span>
                </div>
                <div className="cg-qr-info__ref">Ref: AIPP-{product.appTab.toUpperCase()}-SA</div>
              </div>
            </div>

            <button
              className="cg-sabadell-confirm-btn"
              onClick={() => completeTransaction('sabadell')}
              style={{ borderColor: accent + '55', color: accent, background: accent + '10' }}
            >
              <CheckCircle2 size={13} />
              Confirm Payment
            </button>

            <div className="cg-sabadell-note">
              After completing the QR payment, click "Confirm Payment" to activate your license.
            </div>
          </div>
        )}

        {/* ════════════════════════════════════════════════════════════════════
            Phase: Card
        ════════════════════════════════════════════════════════════════════ */}
        {phase === 'card' && (
          <div className="cg-card-phase">
            <button className="cg-back-link" onClick={() => setPhase('select')}>← Back</button>
            <div className="cg-section-label">Credit Card Payment</div>

            <div className="cg-card-form">
              <label className="cg-field-label">Card Number</label>
              <input
                className={`cg-input${cardErr ? ' cg-input--error' : ''}`}
                value={cardNum}
                onChange={e => setCardNum(formatCard(e.target.value))}
                placeholder="4242 4242 4242 4242"
                inputMode="numeric"
                maxLength={19}
              />

              <div className="cg-card-row">
                <div style={{ flex: 1 }}>
                  <label className="cg-field-label">Expiry Date</label>
                  <input
                    className="cg-input"
                    value={cardExp}
                    onChange={e => {
                      let v = e.target.value.replace(/\D/g, '').slice(0, 4);
                      if (v.length >= 3) v = v.slice(0,2) + '/' + v.slice(2);
                      setCardExp(v);
                    }}
                    placeholder="MM/YY"
                    inputMode="numeric"
                    maxLength={5}
                  />
                </div>
                <div style={{ flex: 1 }}>
                  <label className="cg-field-label">CVC</label>
                  <input
                    className="cg-input"
                    value={cardCvc}
                    onChange={e => setCardCvc(e.target.value.replace(/\D/g,'').slice(0,3))}
                    placeholder="123"
                    inputMode="numeric"
                    maxLength={3}
                  />
                </div>
              </div>

              {cardErr && (
                <div className="cg-card-err">
                  <AlertCircle size={11} /> {cardErr}
                </div>
              )}

              <button
                className="cg-card-submit"
                onClick={handleCardSubmit}
                style={{
                  background: `linear-gradient(135deg, ${accent}, ${accent}cc)`,
                  boxShadow: `0 0 30px ${accent}66, 0 4px 20px rgba(0,0,0,0.5)`,
                  borderColor: accent,
                }}
              >
                <CreditCard size={16} />
                PAY {product.price}{product.priceDetail}
              </button>

              <div className="cg-card-test-hint">
                Test mode: use any 16-digit card, expiry <strong>12/26</strong>, CVC <strong>123</strong>
              </div>
            </div>
          </div>
        )}

        {/* ════════════════════════════════════════════════════════════════════
            Phase: Processing
        ════════════════════════════════════════════════════════════════════ */}
        {phase === 'processing' && (
          <div className="cg-processing-phase">
            <div className="cg-processing-spinner" style={{ borderTopColor: accent }}>
              <Loader size={28} style={{ color: accent }} className="cg-spin" />
            </div>
            <div className="cg-processing-label" style={{ color: accent }}>Processing transaction...</div>
            <div className="cg-processing-steps">
              {[
                'Confirming payment',
                'Generating cryptographic license',
                'Linking license to device',
                'Activating Aippie AI',
              ].map((step, i) => (
                <div key={i} className="cg-processing-step" style={{ animationDelay: `${i * 0.4}s` }}>
                  <span className="cg-processing-dot" style={{ background: accent }} />
                  {step}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ════════════════════════════════════════════════════════════════════
            Phase: Success
        ════════════════════════════════════════════════════════════════════ */}
        {phase === 'success' && (
          <div className="cg-success-phase">
            <div className="cg-success-icon" style={{ borderColor: accent + '44', background: accent + '12' }}>
              <CheckCircle2 size={32} style={{ color: accent }} />
            </div>
            <div className="cg-success-title" style={{ color: accent }}>License Activated</div>
            <div className="cg-success-sub">{product.label} is now unlocked</div>

            <div className="cg-key-display">
              <span className="cg-key-display__label">Your license key</span>
              <div className="cg-key-display__key" style={{ borderColor: accent + '44', color: accent }}>
                {genKey}
              </div>
              <button className="cg-key-copy" onClick={copyKey} style={{ color: accent }}>
                {copied ? <><CheckCircle2 size={11} /> Copied</> : <><Copy size={11} /> Copy</>}
              </button>
            </div>

            <div className="cg-success-note">
              <ShieldCheck size={11} style={{ color: accent }} />
              Aippie AI is now starting for {product.label}…
            </div>
          </div>
        )}

        {/* ════════════════════════════════════════════════════════════════════
            Phase: Error
        ════════════════════════════════════════════════════════════════════ */}
        {phase === 'error' && (
          <div className="cg-error-phase">
            <div className="cg-error-icon">
              <AlertCircle size={30} style={{ color: '#f87171' }} />
            </div>
            <div className="cg-error-title">Transaction Failed</div>
            <div className="cg-error-msg">{errMsg}</div>
            <button className="cg-error-retry" onClick={() => setPhase('select')} style={{ color: accent, borderColor: accent + '44' }}>
              Try Again
            </button>
          </div>
        )}

      </div>
    </div>
  );
}
