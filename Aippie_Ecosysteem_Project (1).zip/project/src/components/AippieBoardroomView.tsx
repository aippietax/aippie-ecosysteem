import { useCallback, useEffect, useState } from 'react';
import {
  Crown, ShieldCheck, TrendingUp, Heart, Briefcase, Zap,
  RefreshCw, Lock, ChevronRight, Calendar, CheckCircle2,
  AlertCircle, Clock, Sparkles, Building2, Play,
} from 'lucide-react';
import { supabase } from '../lib/supabase';
import {
  executeAutonomousCabinetMeeting,
  generateMonthlyEmperorBriefing,
  type BoardroomMeeting,
  type EmperorBriefing,
  type BoardroomDepartment,
} from '../services/aiService';

const DEPT_META: Record<BoardroomDepartment, {
  label: string;
  color: string;
  bg: string;
  border: string;
  icon: React.ReactNode;
  agenda: string[];
}> = {
  tax: {
    label: 'Secretary of Tax & Fiscal Policy',
    color: '#38bdf8',
    bg: 'rgba(56,189,248,0.08)',
    border: 'rgba(56,189,248,0.2)',
    icon: <Briefcase size={14} />,
    agenda: [
      'Q3 2026 VAT (IVA/BTW) reconciliation and optimization review',
      'Verifactu hash chain integrity audit',
      'Cross-border tax treaty opportunities (ES/NL/US)',
    ],
  },
  commerce: {
    label: 'Secretary of Commerce & Enterprise',
    color: '#4ade80',
    bg: 'rgba(74,222,128,0.08)',
    border: 'rgba(74,222,128,0.2)',
    icon: <TrendingUp size={14} />,
    agenda: [
      'B2B pipeline expansion targets for Q4 2026',
      'Partner affiliate revenue share review',
      'Enterprise licensing tier restructuring proposal',
    ],
  },
  defense: {
    label: 'Secretary of Cybersecurity & Defense',
    color: '#fb923c',
    bg: 'rgba(251,146,60,0.08)',
    border: 'rgba(251,146,60,0.2)',
    icon: <ShieldCheck size={14} />,
    agenda: [
      'Zero-trust architecture compliance audit',
      'E2EE SecureChat threat matrix review',
      'GDPR / AVG data residency enforcement update',
    ],
  },
  health: {
    label: 'Secretary of Health & Wellness',
    color: '#f472b6',
    bg: 'rgba(244,114,182,0.08)',
    border: 'rgba(244,114,182,0.2)',
    icon: <Heart size={14} />,
    agenda: [
      'AI Doctor module clinical accuracy review',
      'Fatigue companion biometric stream analysis',
      'Autism CareBoard parent network expansion',
    ],
  },
};

const DEFAULT_FINANCIALS = { bruto: 12154.00, net: 9154.00 };

export default function AippieBoardroomView() {
  const [meetings, setMeetings]     = useState<BoardroomMeeting[]>([]);
  const [briefing, setBriefing]     = useState<EmperorBriefing | null>(null);
  const [loading, setLoading]       = useState(true);
  const [convening, setConvening]   = useState<BoardroomDepartment | null>(null);
  const [briefLoading, setBriefLoading] = useState(false);
  const [expanded, setExpanded]     = useState<string | null>(null);

  const loadData = useCallback(async () => {
    setLoading(true);
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) { setLoading(false); return; }

    const [{ data: mtgs }, { data: brief }] = await Promise.all([
      supabase
        .from('aippie_boardroom_meetings')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false })
        .limit(20),
      supabase
        .from('aippie_emperor_briefings')
        .select('*')
        .eq('user_id', user.id)
        .order('briefing_month', { ascending: false })
        .limit(1)
        .maybeSingle(),
    ]);

    setMeetings((mtgs ?? []) as BoardroomMeeting[]);
    setBriefing(brief as EmperorBriefing | null);
    setLoading(false);
  }, []);

  useEffect(() => { loadData(); }, [loadData]);

  const handleConvene = async (dept: BoardroomDepartment) => {
    setConvening(dept);
    try {
      const meeting = await executeAutonomousCabinetMeeting(dept, DEPT_META[dept].agenda);
      if (meeting) setMeetings(prev => [meeting, ...prev]);
    } catch (e) {
      console.error('[Boardroom] Convene error:', e);
    }
    setConvening(null);
  };

  const handleEmperorBriefing = async () => {
    setBriefLoading(true);
    try {
      const result = await generateMonthlyEmperorBriefing(DEFAULT_FINANCIALS);
      if (result) setBriefing(result);
    } catch (e) {
      console.error('[Emperor] Briefing error:', e);
    }
    setBriefLoading(false);
  };

  const depts: BoardroomDepartment[] = ['tax', 'commerce', 'defense', 'health'];

  return (
    <div style={{
      minHeight: '100vh',
      background: '#080d1a',
      color: '#e2e8f0',
      padding: '20px 16px 80px',
      fontFamily: "'Inter', sans-serif",
    }}>

      {/* ── Header ─────────────────────────────────────────────── */}
      <div style={{ maxWidth: 900, margin: '0 auto' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 4 }}>
          <Crown size={18} color="#fbbf24" />
          <span style={{ fontSize: 18, fontWeight: 800, letterSpacing: '0.04em', color: '#fff' }}>
            AIPPIE Boardroom
          </span>
          <span style={{
            marginLeft: 'auto', fontSize: 9, fontWeight: 700, letterSpacing: '0.12em',
            color: '#4ade80', background: 'rgba(74,222,128,0.1)',
            border: '1px solid rgba(74,222,128,0.25)', padding: '2px 8px', borderRadius: 20,
          }}>
            AIOS v2.0 · LIVE
          </span>
        </div>
        <p style={{ fontSize: 11, color: 'rgba(148,163,184,0.7)', marginBottom: 24 }}>
          Autonomous Cabinet — all departments running under your master vision
        </p>

        {/* ── Emperor Briefing Cockpit ────────────────────────── */}
        <div style={{
          background: 'linear-gradient(135deg, rgba(251,191,36,0.06) 0%, rgba(251,146,60,0.04) 100%)',
          border: '1px solid rgba(251,191,36,0.2)',
          borderRadius: 16, padding: 20, marginBottom: 24,
        }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 14 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
              <Crown size={16} color="#fbbf24" />
              <span style={{ fontSize: 13, fontWeight: 700, color: '#fbbf24' }}>Emperor Briefing Cockpit</span>
              <span style={{ fontSize: 9, color: 'rgba(251,191,36,0.6)', background: 'rgba(251,191,36,0.08)', border: '1px solid rgba(251,191,36,0.15)', padding: '1px 6px', borderRadius: 10 }}>
                {briefing?.briefing_month ?? new Date().toISOString().slice(0, 7)}
              </span>
            </div>
            <button
              onClick={handleEmperorBriefing}
              disabled={briefLoading}
              style={{
                display: 'flex', alignItems: 'center', gap: 6, fontSize: 10, fontWeight: 700,
                background: 'rgba(251,191,36,0.12)', border: '1px solid rgba(251,191,36,0.3)',
                color: '#fbbf24', padding: '5px 12px', borderRadius: 20, cursor: 'pointer',
              }}
            >
              {briefLoading
                ? <><RefreshCw size={10} style={{ animation: 'spin 0.8s linear infinite' }} /> Generating…</>
                : <><Zap size={10} /> Generate Briefing</>
              }
            </button>
          </div>

          {/* Financials row */}
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginBottom: 14 }}>
            <div style={{ background: 'rgba(251,191,36,0.06)', borderRadius: 10, padding: '12px 16px' }}>
              <div style={{ fontSize: 9, color: 'rgba(251,191,36,0.6)', letterSpacing: '0.1em', marginBottom: 4 }}>BRUTO BALANCE</div>
              <div style={{ fontSize: 22, fontWeight: 800, color: '#fbbf24' }}>
                €{(briefing?.bruto_balance_eur ?? DEFAULT_FINANCIALS.bruto).toLocaleString('en-US', { minimumFractionDigits: 2 })}
              </div>
            </div>
            <div style={{ background: 'rgba(74,222,128,0.06)', borderRadius: 10, padding: '12px 16px' }}>
              <div style={{ fontSize: 9, color: 'rgba(74,222,128,0.6)', letterSpacing: '0.1em', marginBottom: 4 }}>NET SURPLUS</div>
              <div style={{ fontSize: 22, fontWeight: 800, color: '#4ade80' }}>
                €{(briefing?.net_surplus_eur ?? DEFAULT_FINANCIALS.net).toLocaleString('en-US', { minimumFractionDigits: 2 })}
              </div>
            </div>
          </div>

          {/* Department summaries */}
          {briefing ? (
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginBottom: 14 }}>
              {(['tax', 'commerce', 'defense', 'health'] as BoardroomDepartment[]).map(d => {
                const m = DEPT_META[d];
                const summary = briefing[`${d}_summary` as keyof EmperorBriefing] as string | null;
                return summary ? (
                  <div key={d} style={{ background: m.bg, border: `1px solid ${m.border}`, borderRadius: 10, padding: '10px 12px' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 6 }}>
                      <span style={{ color: m.color }}>{m.icon}</span>
                      <span style={{ fontSize: 9, fontWeight: 700, color: m.color, letterSpacing: '0.08em', textTransform: 'uppercase' }}>{d}</span>
                    </div>
                    <p style={{ fontSize: 10, color: 'rgba(226,232,240,0.8)', lineHeight: 1.5, margin: 0 }}>{summary}</p>
                  </div>
                ) : null;
              })}
            </div>
          ) : null}

          {/* Master directive */}
          <div style={{
            background: 'rgba(251,191,36,0.04)', border: '1px solid rgba(251,191,36,0.12)',
            borderRadius: 10, padding: '10px 14px', display: 'flex', alignItems: 'flex-start', gap: 8,
          }}>
            <Lock size={11} color="#fbbf24" style={{ marginTop: 1, flexShrink: 0 }} />
            <p style={{ fontSize: 10, color: 'rgba(251,191,36,0.85)', lineHeight: 1.55, margin: 0, fontStyle: 'italic' }}>
              {briefing?.master_directive ?? 'Next Supreme Intel Briefing Scheduled. All departments running autonomously under your master vision.'}
            </p>
          </div>
        </div>

        {/* ── Cabinet Council Tiles ──────────────────────────── */}
        <div style={{ marginBottom: 28 }}>
          <div style={{ fontSize: 11, fontWeight: 700, color: 'rgba(148,163,184,0.6)', letterSpacing: '0.1em', textTransform: 'uppercase', marginBottom: 12 }}>
            Convene Cabinet Session
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 12 }}>
            {depts.map(dept => {
              const m = DEPT_META[dept];
              const isConvening = convening === dept;
              return (
                <div key={dept} style={{
                  background: m.bg, border: `1px solid ${m.border}`,
                  borderRadius: 14, padding: 16, cursor: 'pointer',
                  transition: 'opacity 0.15s',
                  opacity: convening && !isConvening ? 0.5 : 1,
                }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8 }}>
                    <span style={{ color: m.color }}>{m.icon}</span>
                    <span style={{ fontSize: 11, fontWeight: 700, color: m.color }}>{m.label}</span>
                  </div>
                  <ul style={{ margin: '0 0 12px 0', paddingLeft: 14 }}>
                    {m.agenda.map((item, i) => (
                      <li key={i} style={{ fontSize: 9.5, color: 'rgba(148,163,184,0.75)', marginBottom: 3, lineHeight: 1.5 }}>{item}</li>
                    ))}
                  </ul>
                  <button
                    onClick={() => handleConvene(dept)}
                    disabled={!!convening}
                    style={{
                      display: 'flex', alignItems: 'center', gap: 5, fontSize: 9.5, fontWeight: 700,
                      background: `${m.color}18`, border: `1px solid ${m.color}44`,
                      color: m.color, padding: '5px 11px', borderRadius: 18,
                      cursor: convening ? 'not-allowed' : 'pointer', width: '100%', justifyContent: 'center',
                    }}
                  >
                    {isConvening
                      ? <><RefreshCw size={10} style={{ animation: 'spin 0.8s linear infinite' }} /> Convening…</>
                      : <><Play size={9} /> Convene Session</>
                    }
                  </button>
                </div>
              );
            })}
          </div>
        </div>

        {/* ── Meeting Timeline ───────────────────────────────── */}
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 14 }}>
            <Calendar size={13} color="rgba(148,163,184,0.6)" />
            <span style={{ fontSize: 11, fontWeight: 700, color: 'rgba(148,163,184,0.6)', letterSpacing: '0.1em', textTransform: 'uppercase' }}>
              Cabinet Meeting Timeline
            </span>
            <button
              onClick={loadData}
              style={{ marginLeft: 'auto', background: 'none', border: 'none', cursor: 'pointer', color: 'rgba(148,163,184,0.5)' }}
            >
              <RefreshCw size={11} />
            </button>
          </div>

          {loading ? (
            <div style={{ textAlign: 'center', padding: 40, color: 'rgba(148,163,184,0.4)', fontSize: 12 }}>
              <RefreshCw size={18} style={{ animation: 'spin 0.8s linear infinite', margin: '0 auto 8px', display: 'block' }} />
              Loading cabinet records…
            </div>
          ) : meetings.length === 0 ? (
            <div style={{
              textAlign: 'center', padding: '32px 20px',
              background: 'rgba(255,255,255,0.02)', border: '1px solid rgba(255,255,255,0.06)',
              borderRadius: 14, color: 'rgba(148,163,184,0.4)', fontSize: 11,
            }}>
              <Sparkles size={20} style={{ margin: '0 auto 10px', display: 'block', opacity: 0.3 }} />
              No cabinet meetings yet. Convene your first session above.
            </div>
          ) : (
            <div style={{ position: 'relative' }}>
              {/* Timeline line */}
              <div style={{
                position: 'absolute', left: 15, top: 8, bottom: 8, width: 1,
                background: 'linear-gradient(180deg, rgba(251,191,36,0.3), rgba(56,189,248,0.2) 50%, transparent)',
              }} />
              <div style={{ display: 'flex', flexDirection: 'column', gap: 12, paddingLeft: 36 }}>
                {meetings.map(m => {
                  const meta = DEPT_META[m.department as BoardroomDepartment] ?? DEPT_META.tax;
                  const isExp = expanded === m.id;
                  return (
                    <div key={m.id} style={{ position: 'relative' }}>
                      {/* Dot */}
                      <div style={{
                        position: 'absolute', left: -28, top: 12, width: 10, height: 10,
                        borderRadius: '50%', background: meta.color,
                        boxShadow: `0 0 8px ${meta.color}66`,
                      }} />
                      <div
                        onClick={() => setExpanded(isExp ? null : m.id)}
                        style={{
                          background: meta.bg, border: `1px solid ${meta.border}`,
                          borderRadius: 12, padding: '12px 14px', cursor: 'pointer',
                          transition: 'border-color 0.15s',
                        }}
                      >
                        <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4 }}>
                          <span style={{ color: meta.color }}>{meta.icon}</span>
                          <span style={{ fontSize: 11, fontWeight: 700, color: '#e2e8f0', flex: 1 }}>{m.title}</span>
                          {m.status === 'completed'
                            ? <CheckCircle2 size={11} color="#4ade80" />
                            : m.status === 'active'
                              ? <AlertCircle size={11} color="#fbbf24" />
                              : <Clock size={11} color="rgba(148,163,184,0.5)" />
                          }
                          <ChevronRight
                            size={11}
                            color={meta.color}
                            style={{ transform: isExp ? 'rotate(90deg)' : 'none', transition: 'transform 0.2s' }}
                          />
                        </div>
                        <div style={{ fontSize: 9.5, color: 'rgba(148,163,184,0.5)' }}>
                          {new Date(m.created_at).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' })}
                        </div>
                        {isExp && m.discussion_transcript && (
                          <div style={{
                            marginTop: 12, padding: '10px 12px',
                            background: 'rgba(0,0,0,0.25)', borderRadius: 8,
                            fontSize: 10, color: 'rgba(226,232,240,0.75)', lineHeight: 1.65,
                            whiteSpace: 'pre-wrap', maxHeight: 240, overflowY: 'auto',
                          }}>
                            {m.discussion_transcript}
                          </div>
                        )}
                        {isExp && Array.isArray(m.approved_actions) && m.approved_actions.length > 0 && (
                          <div style={{ marginTop: 10 }}>
                            <div style={{ fontSize: 9, fontWeight: 700, color: meta.color, letterSpacing: '0.08em', marginBottom: 6 }}>APPROVED ACTIONS</div>
                            {m.approved_actions.map((a, i) => (
                              <div key={i} style={{ display: 'flex', gap: 6, alignItems: 'flex-start', marginBottom: 4 }}>
                                <CheckCircle2 size={9} color="#4ade80" style={{ marginTop: 1.5, flexShrink: 0 }} />
                                <span style={{ fontSize: 9.5, color: 'rgba(226,232,240,0.65)' }}>{a.action}</span>
                              </div>
                            ))}
                          </div>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>

        {/* ── Footer note ────────────────────────────────────── */}
        <div style={{
          marginTop: 32, padding: '12px 16px',
          background: 'rgba(251,191,36,0.04)', border: '1px solid rgba(251,191,36,0.1)',
          borderRadius: 10, display: 'flex', alignItems: 'center', gap: 8,
        }}>
          <Building2 size={11} color="rgba(251,191,36,0.5)" />
          <span style={{ fontSize: 9.5, color: 'rgba(148,163,184,0.45)', lineHeight: 1.5 }}>
            AIPPIE Boardroom · Autonomous Cabinet Engine v2.0 · AIPPIETAX S.A. · NIF A22944987
            All cabinet proceedings are AI-generated strategic guidance. Not legal or financial advice.
          </span>
        </div>
      </div>

      <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
    </div>
  );
}
