import { useCallback, useEffect, useRef, useState } from 'react';
import { ShieldCheck } from 'lucide-react';
import PlatformAdBanner from './PlatformAdBanner';

// ── 28-bar waveform canvas ────────────────────────────────────────────────────
function Waveform({ active }: { active: boolean }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const frameRef  = useRef<number>(0);
  const tickRef   = useRef(0);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    const BARS = 28;

    const draw = () => {
      tickRef.current += 1;
      const tk = tickRef.current;
      const W = canvas.width, H = canvas.height;
      ctx.clearRect(0, 0, W, H);
      const gap  = W / BARS;
      const barW = Math.max(2, gap - 2);
      for (let i = 0; i < BARS; i++) {
        const phase = (i / BARS) * Math.PI * 2;
        const rawH  = active
          ? (0.18 + 0.82 * Math.abs(Math.sin(tk * 0.05 + phase))) * H
          : 4;
        const x = i * gap + (gap - barW) / 2;
        const y = (H - rawH) / 2;
        const grad = ctx.createLinearGradient(0, y, 0, y + rawH);
        grad.addColorStop(0,   'rgba(74,222,128,0.95)');
        grad.addColorStop(0.5, 'rgba(34,197,94,0.75)');
        grad.addColorStop(1,   'rgba(22,163,74,0.4)');
        ctx.fillStyle = grad;
        ctx.beginPath();
        ctx.roundRect(x, y, barW, rawH, Math.min(barW / 2, 4));
        ctx.fill();
      }
      frameRef.current = requestAnimationFrame(draw);
    };

    frameRef.current = requestAnimationFrame(draw);
    return () => cancelAnimationFrame(frameRef.current);
  }, [active]);

  return (
    <canvas
      ref={canvasRef}
      width={300}
      height={56}
      className="sts-waveform"
      aria-hidden="true"
    />
  );
}

// ── Word-sync subtitle hook (120–130 wpm) ─────────────────────────────────────
// Renders a rolling 10-word window at ~460 ms/word (≈130 wpm)
export function useWordSubtitle(text: string, active: boolean): string {
  const [subtitle, setSubtitle] = useState('');
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const idxRef   = useRef(0);

  useEffect(() => {
    if (timerRef.current) { clearInterval(timerRef.current); timerRef.current = null; }
    setSubtitle('');
    if (!active || !text.trim()) return;

    const words = text.split(/\s+/);
    idxRef.current = 0;

    timerRef.current = setInterval(() => {
      idxRef.current++;
      const start = Math.max(0, idxRef.current - 10);
      setSubtitle(words.slice(start, idxRef.current).join(' '));
      if (idxRef.current >= words.length && timerRef.current) {
        clearInterval(timerRef.current);
        timerRef.current = null;
      }
    }, 460);

    return () => {
      if (timerRef.current) { clearInterval(timerRef.current); timerRef.current = null; }
    };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [text, active]);

  return subtitle;
}

// ── Typewriter hook ───────────────────────────────────────────────────────────
function useTypewriter(script: string, delayMs = 700) {
  const [typed, setTyped] = useState('');
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const idxRef      = useRef(0);

  useEffect(() => {
    const timeout = setTimeout(() => {
      idxRef.current = 0;
      setTyped('');
      intervalRef.current = setInterval(() => {
        idxRef.current += 1;
        setTyped(script.slice(0, idxRef.current));
        if (idxRef.current >= script.length) {
          if (intervalRef.current) clearInterval(intervalRef.current);
        }
      }, 28);
    }, delayMs);

    return () => {
      clearTimeout(timeout);
      if (intervalRef.current) clearInterval(intervalRef.current);
    };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [script]);

  return { typed, done: typed.length >= script.length };
}

// ── Shell props ───────────────────────────────────────────────────────────────
export type SofiaTabShellProps = {
  greeting: string;
  serviceLabel: string;
  trustLine?: string;
  onHoldStart?: () => void;
  onHoldEnd?: () => void;
  btnLabel?: string;
  /** Active speech text — drives word-sync subtitle directly under the portrait */
  speakingText?: string;
  /** True while speechSynthesis is running — locks portrait in full-screen */
  isSpeaking?: boolean;
  /** True while listening — locks portrait in full-screen */
  isListening?: boolean;
  /** Concierge info drawer rendered beneath the portrait, never routes away */
  conciergeDrawer?: React.ReactNode;
  /** Whether the concierge drawer is open */
  conciergeOpen?: boolean;
  children?: React.ReactNode;
};

// ── Shell component ───────────────────────────────────────────────────────────
export default function SofiaTabShell({
  greeting,
  serviceLabel,
  trustLine = 'AIPPIETAX S.A. · Secure Platform',
  onHoldStart,
  onHoldEnd,
  btnLabel = '🎙️ HOLD TO TALK TO AIPPIE',
  speakingText = '',
  isSpeaking = false,
  isListening = false,
  conciergeDrawer,
  conciergeOpen = false,
  children,
}: SofiaTabShellProps) {
  const [listening, setListening] = useState(false);
  const holdTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const { typed, done } = useTypewriter(greeting);

  // Any speech or listen activity locks the portrait view
  const locked = isSpeaking || isListening || listening;

  // Word-sync subtitle: driven by speakingText when isSpeaking is true
  const subtitle = useWordSubtitle(speakingText, isSpeaking);

  const startListening = useCallback(() => {
    setListening(true);
    onHoldStart?.();
    holdTimerRef.current = setTimeout(() => {
      setListening(false);
      onHoldEnd?.();
    }, 10_000);
  }, [onHoldStart, onHoldEnd]);

  const stopListening = useCallback(() => {
    if (!listening) return;
    setListening(false);
    if (holdTimerRef.current) clearTimeout(holdTimerRef.current);
    onHoldEnd?.();
  }, [listening, onHoldEnd]);

  useEffect(() => () => { if (holdTimerRef.current) clearTimeout(holdTimerRef.current); }, []);

  return (
    <div className={`sts-root${locked ? ' sts-root--locked' : ''}`}>

      {/* Status bar */}
      <div className="sts-status-bar">
        <span className="sts-status-bar__dot" />
        <span className="sts-status-bar__text">
          {isSpeaking   ? 'Aippie is speaking…'
           : isListening || listening ? 'Listening…'
           : `Aippie is Live · ${serviceLabel}`}
        </span>
      </div>

      {/* Portrait — expands to locked full-view during speech/listen */}
      <div className={`sts-portrait-wrap${locked ? ' sts-portrait-wrap--locked' : ''}`}>
        <img
          src="/Jouw_alineatekst_(2).png"
          alt="Aippie"
          className={`sts-portrait${isSpeaking ? ' sts-portrait--speaking' : ''}`}
          draggable={false}
        />
        <div className="sts-portrait__fade" />

        {/* Waveform anchored inside portrait during any activity */}
        {locked && (
          <div className="sts-portrait__wave-overlay">
            <Waveform active={locked} />
            <div className="sts-wave-label">
              {isSpeaking ? 'Aippie is speaking…' : 'Processing your request…'}
            </div>
          </div>
        )}

        {children}
      </div>

      {/* Word-sync subtitle panel — mounted strictly below the portrait */}
      <div className={`sts-subtitle-panel${isSpeaking && subtitle ? ' sts-subtitle-panel--active' : ''}`}>
        <span className={`sts-subtitle-text${(!isSpeaking || !subtitle) ? ' sts-subtitle-text--idle' : ''}`}>
          {isSpeaking && subtitle ? subtitle : '\u00A0'}
        </span>
      </div>

      {/* Speech bubble (greeting typewriter) */}
      <div className="sts-speech">
        <div className="sts-speech__avatar-row">
          <img
            src="/Jouw_alineatekst_(2).png"
            alt="Aippie"
            className="sts-speech__thumb"
          />
          <div className="sts-speech__name-col">
            <span className="sts-speech__name">Aippie</span>
            <span className="sts-speech__role">{serviceLabel}</span>
          </div>
        </div>
        <div className="sts-speech__bubble">
          <span>{typed}</span>
          {!done && <span className="sts-speech__cursor" />}
        </div>
      </div>

      {/* Concierge drawer — slides smoothly beneath the face, no routing */}
      {conciergeDrawer && (
        <div className={`sts-concierge-drawer${conciergeOpen ? ' sts-concierge-drawer--open' : ''}`}>
          {conciergeDrawer}
        </div>
      )}

      {/* Hold-to-talk CTA */}
      <div className="sts-cta-wrap">
        <button
          className={`sts-hold-btn${listening || isListening ? ' sts-hold-btn--active' : ''}`}
          onPointerDown={startListening}
          onPointerUp={stopListening}
          onPointerLeave={stopListening}
          onPointerCancel={stopListening}
          aria-label="Hold to talk to Aippie"
        >
          <span className="sts-hold-btn__ring sts-hold-btn__ring--1" />
          <span className="sts-hold-btn__ring sts-hold-btn__ring--2" />
          <span className="sts-hold-btn__core">{btnLabel}</span>
        </button>
      </div>

      {/* Platform Ad Banner — visible in every module */}
      <div className="sts-ad-strip">
        <PlatformAdBanner />
      </div>

      {/* Footer */}
      <div className="sts-footer">
        <ShieldCheck size={11} />
        {trustLine}
      </div>
    </div>
  );
}
