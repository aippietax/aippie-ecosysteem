import { useCallback, useEffect, useRef, useState } from 'react';
import {
  ShieldCheck, MapPin, Building2, GraduationCap, Briefcase,
  ChevronRight, Star, ExternalLink, Mic, CheckCircle,
  FileText, Heart, Banknote, Home, Globe, Zap
} from 'lucide-react';
import { applyPremiumVoice, normalizeForTTS } from '../lib/ttsVoice';
import { supabase } from '../lib/supabase';
import { getStoredLang } from '../lib/i18n';

// ── Domain catalogue ──────────────────────────────────────────────────────────
type DomainId = 'housing_nie' | 'education_health' | 'business_wealth';

type DomainStep = { title: string; detail: string };

type Domain = {
  id: DomainId;
  icon: React.ReactNode;
  label: string;
  color: string;
  accent: string;
  steps: DomainStep[];
  scripts: Record<string, string>;
};

const DOMAINS: Domain[] = [
  {
    id: 'housing_nie',
    icon: <Home size={14}/>,
    label: 'Housing & NIE',
    color: '#38bdf8',
    accent: 'rgba(56,189,248,0.12)',
    steps: [
      { title: 'NIE Application', detail: 'Book your appointment at the nearest Comisaría or via Spanish consulate abroad. Bring EX-15 form, valid passport, and proof of purpose.' },
      { title: 'Property Purchase', detail: 'Engage a licensed gestor, obtain mortgage pre-approval from Santander or CaixaBank, sign arras contract (10% deposit), then escritura at notary.' },
      { title: 'Residency Certificate', detail: 'Register at your local Ayuntamiento (empadronamiento) within 30 days. Required for utilities, school enrolment, and TIE card.' },
      { title: 'Utility Setup', detail: 'Transfer Endesa/Iberdrola electricity, Aguas del Sur water, and Movistar/Orange broadband. Average setup: 5–8 business days.' },
    ],
    scripts: {
      en: "Housing and NIE in Spain. Step one: book your NIE appointment at the Comisaría or consulate. Bring your passport, form EX-15, and purpose of stay. Step two: for property purchase, hire a gestor, get mortgage pre-approval, sign the arras deposit contract for 10%, then the escritura at a notary. Step three: register at the Ayuntamiento for empadronamiento within 30 days. This unlocks school access and utilities. Step four: transfer electricity with Endesa or Iberdrola, water with Aguas del Sur, and broadband with Movistar. Five to eight business days for activation.",
      nl: "Housing and NIE in Spain. Step one: book your NIE appointment at the Comisaría or consulate. Bring your passport, form EX-15, and purpose of stay. Step two: for property purchase, hire a gestor, get mortgage pre-approval, sign the arras deposit contract for 10%, then the escritura at a notary. Step three: register at the Ayuntamiento for empadronamiento within 30 days. This unlocks school access and utilities. Step four: transfer electricity with Endesa or Iberdrola, water with Aguas del Sur, and broadband with Movistar. Five to eight business days for activation.",
      de: "Housing and NIE in Spain. Step one: book your NIE appointment at the Comisaría or consulate. Bring your passport, form EX-15, and purpose of stay. Step two: for property purchase, hire a gestor, get mortgage pre-approval, sign the arras deposit contract for 10%, then the escritura at a notary. Step three: register at the Ayuntamiento for empadronamiento within 30 days. This unlocks school access and utilities. Step four: transfer electricity with Endesa or Iberdrola, water with Aguas del Sur, and broadband with Movistar. Five to eight business days for activation.",
      fr: "Housing and NIE in Spain. Step one: book your NIE appointment at the Comisaría or consulate. Bring your passport, form EX-15, and purpose of stay. Step two: for property purchase, hire a gestor, get mortgage pre-approval, sign the arras deposit contract for 10%, then the escritura at a notary. Step three: register at the Ayuntamiento for empadronamiento within 30 days. This unlocks school access and utilities. Step four: transfer electricity with Endesa or Iberdrola, water with Aguas del Sur, and broadband with Movistar. Five to eight business days for activation.",
      sv: "Housing and NIE in Spain. Step one: book your NIE appointment at the Comisaría or consulate. Bring your passport, form EX-15, and purpose of stay. Step two: for property purchase, hire a gestor, get mortgage pre-approval, sign the arras deposit contract for 10%, then the escritura at a notary. Step three: register at the Ayuntamiento for empadronamiento within 30 days. This unlocks school access and utilities. Step four: transfer electricity with Endesa or Iberdrola, water with Aguas del Sur, and broadband with Movistar. Five to eight business days for activation.",
    },
  },
  {
    id: 'education_health',
    icon: <GraduationCap size={14}/>,
    label: 'Education & Health',
    color: '#4ade80',
    accent: 'rgba(74,222,128,0.10)',
    steps: [
      { title: 'Public vs Private Healthcare', detail: 'Register with Centro de Salud using empadronamiento for free public care. Private: Sanitas, Adeslas, or AXA from €45/month. Expats: MUFACE or agreement-based.' },
      { title: 'International Schools', detail: 'Brave Generation Academy (BGA) in Fuengirola: IB curriculum, ages 3–18. Laude San Pedro International College: British A-levels, Cambridge IGCSE, Marbella.' },
      { title: 'School Enrolment', detail: 'Submit empadronamiento, NIE, vaccination records, and previous school transcripts. Applications open February–May for September start.' },
      { title: 'Family Permits', detail: 'EU family members: free registration. Non-EU dependents: apply for family reunification visa (reagrupación familiar) at consulate before arriving.' },
    ],
    scripts: {
      en: "Education and health in Spain. For healthcare: register at your local Centro de Salud with your empadronamiento certificate for free public access. Private options include Sanitas, Adeslas, and AXA from 45 euros per month. For schools: Brave Generation Academy BGA in Fuengirola offers the International Baccalaureate from age 3 to 18. Laude San Pedro International College in Marbella delivers British A-levels and Cambridge IGCSE. Submit empadronamiento, NIE, vaccination records, and transcripts. Applications open February to May for September start. Non-EU family members need a reagrupación familiar visa.",
      nl: "Education and health in Spain. For healthcare: register at your local Centro de Salud with your empadronamiento certificate for free public access. Private options include Sanitas, Adeslas, and AXA from 45 euros per month. For schools: Brave Generation Academy BGA in Fuengirola offers the International Baccalaureate from age 3 to 18. Laude San Pedro International College in Marbella delivers British A-levels and Cambridge IGCSE. Submit empadronamiento, NIE, vaccination records, and transcripts. Applications open February to May for September start. Non-EU family members need a reagrupación familiar visa.",
      de: "Education and health in Spain. For healthcare: register at your local Centro de Salud with your empadronamiento certificate for free public access. Private options include Sanitas, Adeslas, and AXA from 45 euros per month. For schools: Brave Generation Academy BGA in Fuengirola offers the International Baccalaureate from age 3 to 18. Laude San Pedro International College in Marbella delivers British A-levels and Cambridge IGCSE. Submit empadronamiento, NIE, vaccination records, and transcripts. Applications open February to May for September start. Non-EU family members need a reagrupación familiar visa.",
      fr: "Education and health in Spain. For healthcare: register at your local Centro de Salud with your empadronamiento certificate for free public access. Private options include Sanitas, Adeslas, and AXA from 45 euros per month. For schools: Brave Generation Academy BGA in Fuengirola offers the International Baccalaureate from age 3 to 18. Laude San Pedro International College in Marbella delivers British A-levels and Cambridge IGCSE. Submit empadronamiento, NIE, vaccination records, and transcripts. Applications open February to May for September start. Non-EU family members need a reagrupación familiar visa.",
      sv: "Education and health in Spain. For healthcare: register at your local Centro de Salud with your empadronamiento certificate for free public access. Private options include Sanitas, Adeslas, and AXA from 45 euros per month. For schools: Brave Generation Academy BGA in Fuengirola offers the International Baccalaureate from age 3 to 18. Laude San Pedro International College in Marbella delivers British A-levels and Cambridge IGCSE. Submit empadronamiento, NIE, vaccination records, and transcripts. Applications open February to May for September start. Non-EU family members need a reagrupación familiar visa.",
    },
  },
  {
    id: 'business_wealth',
    icon: <Briefcase size={14}/>,
    label: 'Business & Wealth',
    color: '#fbbf24',
    accent: 'rgba(251,191,36,0.10)',
    steps: [
      { title: 'Tax Residency', detail: 'Spend >183 days in Spain to become tax resident. File Modelo 030 with AEAT. Benefits: reduced corporate rates, EU market access, territorial tax system possible.' },
      { title: 'Business Entity', detail: 'SL (Sociedad Limitada): €3,000 minimum capital, 25% corporate tax (15% first 2 years). Autónomo: freelance, progressive IRPF. Register with Registro Mercantil.' },
      { title: 'Beckham Law', detail: 'Special expat regime: flat 24% IRPF on Spanish income for 6 years for qualifying workers and executives. Apply within 6 months of arriving. File Modelo 149.' },
      { title: 'Banking Setup', detail: 'Recommended: Sabadell or BBVA (NIE + passport required). Expat-friendly: N26, Revolut, Wise for international transfers. Crypto-friendly: Evo Banco.' },
    ],
    scripts: {
      en: "Business and wealth optimization in Spain. Tax residency: spend more than 183 days per year to become tax resident. File Modelo 030 with AEAT. For your business entity: an SL Sociedad Limitada requires 3,000 euros minimum capital with 25% corporate tax, reduced to 15% for the first two years. Beckham Law is a special expat tax regime giving you a flat rate of 24% income tax for six years. Apply within six months of arrival using Modelo 149. For banking: Sabadell or BBVA for local accounts, Revolut or Wise for international transfers.",
      nl: "Business and wealth optimization in Spain. Tax residency: spend more than 183 days per year to become tax resident. File Modelo 030 with AEAT. For your business entity: an SL Sociedad Limitada requires 3,000 euros minimum capital with 25% corporate tax, reduced to 15% for the first two years. Beckham Law is a special expat tax regime giving you a flat rate of 24% income tax for six years. Apply within six months of arrival using Modelo 149. For banking: Sabadell or BBVA for local accounts, Revolut or Wise for international transfers.",
      de: "Business and wealth optimization in Spain. Tax residency: spend more than 183 days per year to become tax resident. File Modelo 030 with AEAT. For your business entity: an SL Sociedad Limitada requires 3,000 euros minimum capital with 25% corporate tax, reduced to 15% for the first two years. Beckham Law is a special expat tax regime giving you a flat rate of 24% income tax for six years. Apply within six months of arrival using Modelo 149. For banking: Sabadell or BBVA for local accounts, Revolut or Wise for international transfers.",
      fr: "Business and wealth optimization in Spain. Tax residency: spend more than 183 days per year to become tax resident. File Modelo 030 with AEAT. For your business entity: an SL Sociedad Limitada requires 3,000 euros minimum capital with 25% corporate tax, reduced to 15% for the first two years. Beckham Law is a special expat tax regime giving you a flat rate of 24% income tax for six years. Apply within six months of arrival using Modelo 149. For banking: Sabadell or BBVA for local accounts, Revolut or Wise for international transfers.",
      sv: "Business and wealth optimization in Spain. Tax residency: spend more than 183 days per year to become tax resident. File Modelo 030 with AEAT. For your business entity: an SL Sociedad Limitada requires 3,000 euros minimum capital with 25% corporate tax, reduced to 15% for the first two years. Beckham Law is a special expat tax regime giving you a flat rate of 24% income tax for six years. Apply within six months of arrival using Modelo 149. For banking: Sabadell or BBVA for local accounts, Revolut or Wise for international transfers.",
    },
  },
];

// ── 28-bar waveform ───────────────────────────────────────────────────────────
function Waveform({ active }: { active: boolean }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const frameRef  = useRef<number>(0);
  const tickRef   = useRef(0);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    const BARS = 28;

    const draw = () => {
      tickRef.current++;
      const tk = tickRef.current;
      const W = canvas.width, H = canvas.height;
      ctx.clearRect(0, 0, W, H);
      const gap = W / BARS, barW = Math.max(2, gap - 2);
      for (let i = 0; i < BARS; i++) {
        const phase = (i / BARS) * Math.PI * 2;
        const rawH = active ? (0.2 + 0.8 * Math.abs(Math.sin(tk * 0.052 + phase))) * H : 4;
        const x = i * gap + (gap - barW) / 2, y = (H - rawH) / 2;
        const grad = ctx.createLinearGradient(0, y, 0, y + rawH);
        grad.addColorStop(0,   'rgba(251,191,36,0.95)');
        grad.addColorStop(0.5, 'rgba(245,158,11,0.75)');
        grad.addColorStop(1,   'rgba(217,119,6,0.4)');
        ctx.fillStyle = grad;
        ctx.beginPath(); ctx.roundRect(x, y, barW, rawH, Math.min(barW/2,4)); ctx.fill();
      }
      frameRef.current = requestAnimationFrame(draw);
    };
    frameRef.current = requestAnimationFrame(draw);
    return () => cancelAnimationFrame(frameRef.current);
  }, [active]);

  return <canvas ref={canvasRef} width={300} height={48} className="rl-waveform" aria-hidden="true"/>;
}

// ── Subtitle engine — word-by-word sync with speechSynthesis ─────────────────
function useSubtitles(text: string, speaking: boolean) {
  const [subtitle, setSubtitle] = useState('');
  const wordTimer = useRef<ReturnType<typeof setInterval> | null>(null);
  const wordIdx   = useRef(0);
  const words     = useRef<string[]>([]);

  useEffect(() => {
    if (wordTimer.current) clearInterval(wordTimer.current);
    if (!speaking || !text) { setSubtitle(''); return; }

    words.current = text.split(' ');
    wordIdx.current = 0;
    setSubtitle('');

    // Estimate ~120 words/minute = 500ms/word
    wordTimer.current = setInterval(() => {
      wordIdx.current++;
      const chunk = words.current.slice(0, wordIdx.current).join(' ');
      setSubtitle(chunk);
      if (wordIdx.current >= words.current.length) {
        if (wordTimer.current) clearInterval(wordTimer.current);
      }
    }, 480);

    return () => { if (wordTimer.current) clearInterval(wordTimer.current); };
  }, [text, speaking]);

  return subtitle;
}

// ── Checkout modal ────────────────────────────────────────────────────────────
function CheckoutModal({ domain, lang, onClose }: { domain: DomainId | 'full_package'; lang: string; onClose: () => void }) {
  const [step, setStep] = useState<'confirm' | 'processing' | 'done'>('confirm');
  const deviceKey = localStorage.getItem('aippie_device_key') ?? 'anon';

  const handlePay = async () => {
    setStep('processing');
    await supabase.from('aippie_relocation_leads').insert({
      device_key: deviceKey,
      lang_code: lang,
      domain,
      amount_eur: 499,
      status: 'pending',
    });
    // Stripe redirect would fire here in production
    setTimeout(() => setStep('done'), 1800);
  };

  return (
    <div className="rl-checkout-backdrop" onClick={onClose}>
      <div className="rl-checkout-modal" onClick={e => e.stopPropagation()}>

        {step === 'confirm' && <>
          <div className="rl-checkout-modal__header">
            <div className="rl-checkout-modal__icon"><Star size={18}/></div>
            <div>
              <div className="rl-checkout-modal__title">Gold Bridge Roadmap</div>
              <div className="rl-checkout-modal__sub">Complete Costa del Sol Relocation Package</div>
            </div>
          </div>
          <div className="rl-checkout-modal__price">€499 <span>one-time</span></div>
          <ul className="rl-checkout-modal__list">
            {['NIE + housing step-by-step guide','International school placement','Healthcare registration','Tax residency & Beckham Law filing','Banking setup','Personal Aippie AI concierge access'].map(f => (
              <li key={f}><CheckCircle size={12}/> {f}</li>
            ))}
          </ul>
          <div className="rl-checkout-modal__stripe-note">
            <ShieldCheck size={11}/> Secured by Stripe · Test card 4242 4242 4242 4242
          </div>
          <button className="rl-checkout-modal__pay-btn" onClick={handlePay}>
            <Zap size={13}/> PAY €499 — GET INSTANT ACCESS
          </button>
          <button className="rl-checkout-modal__cancel" onClick={onClose}>Cancel</button>
        </>}

        {step === 'processing' && (
          <div className="rl-checkout-modal__processing">
            <span className="ob-cta__spinner"/>
            <div>Processing your payment…</div>
          </div>
        )}

        {step === 'done' && (
          <div className="rl-checkout-modal__done">
            <CheckCircle size={36} color="#4ade80"/>
            <div className="rl-checkout-modal__done-title">Gold Bridge Roadmap Unlocked!</div>
            <div className="rl-checkout-modal__done-sub">Your personal Aippie relocation concierge is activated. Check your email for your full roadmap PDF.</div>
            <button className="rl-checkout-modal__pay-btn" onClick={onClose}>Close</button>
          </div>
        )}
      </div>
    </div>
  );
}

// ── Main RelocationView ───────────────────────────────────────────────────────
export default function RelocationView() {
  const lang = getStoredLang();
  const [activeDomain, setActiveDomain] = useState<Domain>(DOMAINS[0]);
  const [speaking, setSpeaking]         = useState(false);
  const [showCheckout, setShowCheckout] = useState(false);
  const [expandedStep, setExpandedStep] = useState<number | null>(null);

  const subtitle = useSubtitles(activeDomain.scripts[lang] ?? activeDomain.scripts['en'], speaking);

  const speakDomain = useCallback((d: Domain) => {
    if (!('speechSynthesis' in window)) return;
    window.speechSynthesis.cancel();
    const text = d.scripts[lang] ?? d.scripts['en'];
    const u = new SpeechSynthesisUtterance(normalizeForTTS(text));
    const langTag = lang === 'nl' ? 'nl-NL' : lang === 'de' ? 'de-DE' : lang === 'fr' ? 'fr-FR' : lang === 'sv' ? 'sv-SE' : 'en-US';
    u.lang = langTag; u.rate = 0.92; u.pitch = 1.0;
    applyPremiumVoice(u, langTag);
    u.onstart = () => setSpeaking(true);
    u.onend   = () => setSpeaking(false);
    u.onerror  = () => setSpeaking(false);
    window.speechSynthesis.speak(u);
    setSpeaking(true);
  }, [lang]);

  const selectDomain = (d: Domain) => {
    setActiveDomain(d);
    setExpandedStep(null);
    speakDomain(d);
  };

  useEffect(() => {
    return () => window.speechSynthesis?.cancel();
  }, []);

  return (
    <div className="rl-root">

      {/* Status bar */}
      <div className="rl-status-bar">
        <span className="rl-status-bar__dot"/>
        <span className="rl-status-bar__text">AippieConnect · Costa del Sol Relocation Hub</span>
        <span className="rl-status-bar__badge"><MapPin size={9}/> ES</span>
      </div>

      {/* Avatar viewport */}
      <div className="rl-avatar-wrap">
        <img
          src="/Jouw_alineatekst_(2).png"
          alt="Aippie" className="rl-avatar" draggable={false}
        />
        <div className="rl-avatar__fade"/>

        {/* Speaking indicator */}
        {speaking && (
          <div className="rl-avatar__speaking-badge">
            <Mic size={10}/>
            <span>Aippie is guiding you…</span>
          </div>
        )}

        <div className="rl-avatar__plate">
          <div className="rl-avatar__plate-name">Aippie Relocation Concierge</div>
          <div className="rl-avatar__plate-role">AIPPIETAX S.A. · aippieconnect.com</div>
        </div>
      </div>

      {/* Waveform + live subtitles */}
      <div className="rl-subtitle-block">
        <Waveform active={speaking}/>
        <div className={`rl-subtitle${speaking ? ' rl-subtitle--active' : ''}`}>
          {speaking
            ? subtitle || 'Aippie is speaking…'
            : `Tap a domain below, then tap Aippie's face to hear her guide you through each step.`
          }
        </div>
      </div>

      {/* Tap face to speak CTA */}
      <div className="rl-speak-cta">
        <button
          className={`rl-speak-btn${speaking ? ' rl-speak-btn--active' : ''}`}
          onClick={() => { if (speaking) { window.speechSynthesis?.cancel(); setSpeaking(false); } else { speakDomain(activeDomain); } }}
        >
          <Mic size={14}/>
          {speaking ? 'TAP TO STOP AIPPIE' : '🎙️ TAP TO HEAR AIPPIE GUIDE YOU'}
        </button>
      </div>

      {/* Domain selector tabs */}
      <div className="rl-domain-tabs">
        {DOMAINS.map(d => (
          <button
            key={d.id}
            className={`rl-domain-tab${activeDomain.id === d.id ? ' rl-domain-tab--active' : ''}`}
            style={activeDomain.id === d.id ? { borderColor: d.color, color: d.color, background: d.accent } : {}}
            onClick={() => selectDomain(d)}
          >
            {d.icon}
            <span>{d.label}</span>
          </button>
        ))}
      </div>

      {/* Active domain steps */}
      <div className="rl-domain-content">
        <div className="rl-domain-content__header" style={{ color: activeDomain.color }}>
          {activeDomain.icon}
          <span>{activeDomain.label}</span>
        </div>
        <div className="rl-steps">
          {activeDomain.steps.map((step, i) => (
            <div
              key={i}
              className={`rl-step${expandedStep === i ? ' rl-step--open' : ''}`}
              onClick={() => setExpandedStep(expandedStep === i ? null : i)}
            >
              <div className="rl-step__header">
                <div className="rl-step__num" style={{ background: activeDomain.accent, color: activeDomain.color }}>
                  {i + 1}
                </div>
                <div className="rl-step__title">{step.title}</div>
                <ChevronRight
                  size={14}
                  className="rl-step__chevron"
                  style={{ transform: expandedStep === i ? 'rotate(90deg)' : 'none' }}
                />
              </div>
              {expandedStep === i && (
                <div className="rl-step__detail">{step.detail}</div>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Domain quick-reference cards */}
      <div className="rl-domain-links">
        {activeDomain.id === 'housing_nie' && (
          <>
            <a className="rl-link-chip" href="https://sede.administracionespublicas.gob.es" target="_blank" rel="noopener noreferrer">
              <FileText size={11}/> NIE Appointment Portal <ExternalLink size={9}/>
            </a>
            <a className="rl-link-chip" href="https://www.catastro.hacienda.gob.es" target="_blank" rel="noopener noreferrer">
              <Building2 size={11}/> Property Registry <ExternalLink size={9}/>
            </a>
          </>
        )}
        {activeDomain.id === 'education_health' && (
          <>
            <a className="rl-link-chip" href="https://www.bgacademy.es" target="_blank" rel="noopener noreferrer">
              <GraduationCap size={11}/> BGA Fuengirola <ExternalLink size={9}/>
            </a>
            <a className="rl-link-chip" href="https://www.laudecolleges.com/san-pedro" target="_blank" rel="noopener noreferrer">
              <GraduationCap size={11}/> Laude San Pedro <ExternalLink size={9}/>
            </a>
            <a className="rl-link-chip" href="https://www.sanitas.es" target="_blank" rel="noopener noreferrer">
              <Heart size={11}/> Sanitas Health <ExternalLink size={9}/>
            </a>
          </>
        )}
        {activeDomain.id === 'business_wealth' && (
          <>
            <a className="rl-link-chip" href="https://sede.agenciatributaria.gob.es" target="_blank" rel="noopener noreferrer">
              <Banknote size={11}/> AEAT Tax Agency <ExternalLink size={9}/>
            </a>
            <a className="rl-link-chip" href="https://www.sabadell.com" target="_blank" rel="noopener noreferrer">
              <Banknote size={11}/> Sabadell Bank <ExternalLink size={9}/>
            </a>
            <a className="rl-link-chip" href="https://www.revolut.com" target="_blank" rel="noopener noreferrer">
              <Globe size={11}/> Revolut <ExternalLink size={9}/>
            </a>
          </>
        )}
      </div>

      {/* ── Gold Bridge Roadmap checkout card ──────────────── */}
      <div className="rl-roadmap-card">
        <div className="rl-roadmap-card__header">
          <div className="rl-roadmap-card__icon"><Star size={16}/></div>
          <div>
            <div className="rl-roadmap-card__title">Gold Bridge Roadmap</div>
            <div className="rl-roadmap-card__sub">Complete A–Z Costa del Sol Relocation Blueprint</div>
          </div>
          <div className="rl-roadmap-card__price">€499</div>
        </div>
        <div className="rl-roadmap-card__features">
          {['NIE + housing guidance','International school placement','Healthcare registration','Tax residency & Beckham Law','Banking setup','Personal AI concierge'].map(f => (
            <div key={f} className="rl-roadmap-card__feature">
              <CheckCircle size={10} color="#4ade80"/>
              <span>{f}</span>
            </div>
          ))}
        </div>
        <button className="rl-roadmap-card__cta" onClick={() => setShowCheckout(true)}>
          <Star size={13}/> Get the Gold Bridge Roadmap — €499
        </button>
        <div className="rl-roadmap-card__trust">
          <ShieldCheck size={10}/> Secured by Stripe · Instant delivery · GDPR compliant
        </div>
      </div>

      <div className="rl-footer">
        <ShieldCheck size={10}/>
        AIPPIETAX S.A. · aippieconnect.com · Costa del Sol Relocation Hub
      </div>

      {showCheckout && (
        <CheckoutModal
          domain="full_package"
          lang={lang}
          onClose={() => setShowCheckout(false)}
        />
      )}
    </div>
  );
}
