/**
 * IpAssetRegistry — V201 Intellectual Property & Compliance Registry
 * AIPPIETAX S.A. · Admin-only · Supabase-backed · RLS protected
 */
import { useCallback, useEffect, useRef, useState } from 'react';
import {
  Shield, Plus, Save, RefreshCw, Trash2, CheckCircle2,
  Circle, FileText, Calendar, Hash, Package, Lock,
  ChevronDown, ChevronUp, AlertCircle, RotateCcw,
} from 'lucide-react';
import { supabase } from '../lib/supabase';

interface IpRecord {
  id:                string;
  owner_user_id:     string;
  doc_reference:     string;
  effective_date:    string;
  target_app_id:     string;
  target_bundle_id:  string;
  check_legal_title: boolean;
  check_code_audit:  boolean;
  check_regulatory:  boolean;
  notes:             string;
  created_at:        string;
  updated_at:        string;
}

type SaveState = 'idle' | 'saving' | 'saved' | 'error';
type AnimPhase = 'lock' | 'table';

interface RowProps {
  record:   IpRecord;
  onSave:   (r: IpRecord) => Promise<void>;
  onDelete: (id: string)  => void;
}

function IpRow({ record, onSave, onDelete }: RowProps) {
  const [draft,     setDraft]     = useState<IpRecord>(record);
  const [expanded,  setExpanded]  = useState(false);
  const [saveState, setSaveState] = useState<SaveState>('idle');

  const changed =
    draft.doc_reference    !== record.doc_reference    ||
    draft.effective_date   !== record.effective_date   ||
    draft.target_app_id    !== record.target_app_id    ||
    draft.target_bundle_id !== record.target_bundle_id ||
    draft.check_legal_title !== record.check_legal_title ||
    draft.check_code_audit  !== record.check_code_audit  ||
    draft.check_regulatory  !== record.check_regulatory  ||
    draft.notes             !== record.notes;

  const handleSave = async () => {
    setSaveState('saving');
    try {
      await onSave(draft);
      setSaveState('saved');
      setTimeout(() => setSaveState('idle'), 2000);
    } catch {
      setSaveState('error');
      setTimeout(() => setSaveState('idle'), 3000);
    }
  };

  const allChecked = draft.check_legal_title && draft.check_code_audit && draft.check_regulatory;

  return (
    <div className={`ipar-row${allChecked ? ' ipar-row--verified' : ''}`}>
      <div className="ipar-row__header" onClick={() => setExpanded(e => !e)}>
        <div className="ipar-row__ref">
          <FileText size={11} style={{ color: '#38bdf8', flexShrink: 0 }} />
          <span>{record.doc_reference || <em style={{ color: '#475569' }}>No reference</em>}</span>
        </div>
        <div className="ipar-row__meta">
          {record.effective_date && (
            <span className="ipar-row__date">{record.effective_date}</span>
          )}
          {allChecked && (
            <span className="ipar-row__verified-chip">
              <CheckCircle2 size={8} /> Fully Verified
            </span>
          )}
        </div>
        <button className="ipar-expand-btn" onClick={e => { e.stopPropagation(); setExpanded(x => !x); }}>
          {expanded ? <ChevronUp size={11} /> : <ChevronDown size={11} />}
        </button>
      </div>

      {expanded && (
        <div className="ipar-row__body">
          {/* Fields grid */}
          <div className="ipar-fields-grid">
            <label className="ipar-field">
              <span className="ipar-field__label"><FileText size={9} /> Document Reference</span>
              <input
                className="ipar-field__input"
                type="text"
                placeholder="e.g. AIPP-IP-2026-001"
                value={draft.doc_reference}
                onChange={e => setDraft(d => ({ ...d, doc_reference: e.target.value }))}
              />
            </label>
            <label className="ipar-field">
              <span className="ipar-field__label"><Calendar size={9} /> Effective Date</span>
              <input
                className="ipar-field__input"
                type="date"
                value={draft.effective_date}
                onChange={e => setDraft(d => ({ ...d, effective_date: e.target.value }))}
              />
            </label>
            <label className="ipar-field">
              <span className="ipar-field__label"><Hash size={9} /> Target App ID</span>
              <input
                className="ipar-field__input"
                type="text"
                placeholder="e.g. numeric store ID"
                value={draft.target_app_id}
                onChange={e => setDraft(d => ({ ...d, target_app_id: e.target.value }))}
              />
            </label>
            <label className="ipar-field">
              <span className="ipar-field__label"><Package size={9} /> Target Bundle ID</span>
              <input
                className="ipar-field__input"
                type="text"
                placeholder="e.g. com.company.app"
                value={draft.target_bundle_id}
                onChange={e => setDraft(d => ({ ...d, target_bundle_id: e.target.value }))}
              />
            </label>
          </div>

          {/* Notes */}
          <label className="ipar-field ipar-field--full">
            <span className="ipar-field__label">Notes</span>
            <textarea
              className="ipar-field__input ipar-field__textarea"
              rows={2}
              placeholder="Internal admin notes…"
              value={draft.notes}
              onChange={e => setDraft(d => ({ ...d, notes: e.target.value }))}
            />
          </label>

          {/* Compliance checklist */}
          <div className="ipar-checks">
            <div className="ipar-checks__title"><Lock size={9} /> Verification Checklist</div>
            {[
              { key: 'check_legal_title', label: 'Legal Title Assignment' },
              { key: 'check_code_audit',  label: 'Technical Code Audit' },
              { key: 'check_regulatory',  label: 'Platform Regulatory Compliance' },
            ].map(({ key, label }) => {
              const val = draft[key as keyof IpRecord] as boolean;
              return (
                <button
                  key={key}
                  className={`ipar-check-item${val ? ' ipar-check-item--on' : ''}`}
                  onClick={() => setDraft(d => ({ ...d, [key]: !val }))}
                >
                  {val
                    ? <CheckCircle2 size={12} style={{ color: '#4ade80' }} />
                    : <Circle      size={12} style={{ color: '#334155' }} />}
                  <span>{label}</span>
                  <span className={`ipar-check-badge${val ? ' ipar-check-badge--on' : ''}`}>
                    {val ? 'Verified' : 'Pending'}
                  </span>
                </button>
              );
            })}
          </div>

          {/* Action row */}
          <div className="ipar-row__actions">
            <button
              className="ipar-btn ipar-btn--save"
              onClick={handleSave}
              disabled={!changed || saveState === 'saving'}
            >
              {saveState === 'saving' && <RefreshCw size={10} className="rem-spin" />}
              {saveState === 'saved'  && <CheckCircle2 size={10} />}
              {saveState === 'error'  && <AlertCircle size={10} style={{ color: '#f87171' }} />}
              {saveState === 'idle'   && <Save size={10} />}
              {saveState === 'saving' ? 'Saving…' : saveState === 'saved' ? 'Saved' : saveState === 'error' ? 'Error' : 'Save'}
            </button>
            <button
              className="ipar-btn ipar-btn--reset"
              onClick={() => setDraft(record)}
              disabled={!changed}
            >
              <RotateCcw size={10} /> Reset
            </button>
            <button
              className="ipar-btn ipar-btn--delete"
              onClick={() => onDelete(record.id)}
            >
              <Trash2 size={10} /> Delete
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

// ── Cinema animation: lock → table ────────────────────────────────────────────
function IpCinema() {
  const [phase,    setPhase]    = useState<AnimPhase>('lock');
  const [caption,  setCaption]  = useState('');
  const [capIdx,   setCapIdx]   = useState(0);
  const [angle,    setAngle]    = useState(0);
  const rafRef    = useRef<number | null>(null);
  const phaseRef  = useRef<ReturnType<typeof setTimeout> | null>(null);
  const capTimRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const CAPTIONS = [
    'Intellectual Property shield rotating — asset secured under registry.',
    'AIPPIETAX S.A. compliance matrix loading — all fields verified.',
    'IP Asset Registry live — edit, verify, and save records securely.',
  ];

  // Spin the lock SVG
  useEffect(() => {
    let a = 0;
    const tick = () => { a = (a + 0.4) % 360; setAngle(a); rafRef.current = requestAnimationFrame(tick); };
    rafRef.current = requestAnimationFrame(tick);
    return () => { if (rafRef.current) cancelAnimationFrame(rafRef.current); };
  }, []);

  // Cycle lock → table every 4 s
  useEffect(() => {
    phaseRef.current = setInterval(() => {
      setPhase(p => p === 'lock' ? 'table' : 'lock');
    }, 4000);
    return () => { if (phaseRef.current) clearInterval(phaseRef.current); };
  }, []);

  // Typewriter captions
  useEffect(() => {
    const full = CAPTIONS[capIdx % CAPTIONS.length];
    let i = 0;
    setCaption('');
    capTimRef.current = setInterval(() => {
      i++;
      setCaption(full.slice(0, i));
      if (i >= full.length) {
        clearInterval(capTimRef.current!);
        setTimeout(() => setCapIdx(n => n + 1), 2000);
      }
    }, 38);
    return () => { if (capTimRef.current) clearInterval(capTimRef.current); };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [capIdx]);

  return (
    <div className="ipar-cinema">
      <div className="ipar-cinema__stage">
        {phase === 'lock' ? (
          <svg
            viewBox="0 0 80 80"
            className="ipar-cinema__lock-svg"
            style={{ transform: `rotateY(${angle}deg)` }}
          >
            <defs>
              <radialGradient id="lockGlow" cx="50%" cy="50%" r="50%">
                <stop offset="0%"   stopColor="#38bdf8" stopOpacity="0.25" />
                <stop offset="100%" stopColor="#38bdf8" stopOpacity="0"    />
              </radialGradient>
            </defs>
            <circle cx="40" cy="40" r="38" fill="url(#lockGlow)" />
            <circle cx="40" cy="40" r="34" fill="none" stroke="#38bdf822" strokeWidth="1.5" />
            {/* Shield body */}
            <path d="M40 8 L64 20 L64 44 Q64 62 40 72 Q16 62 16 44 L16 20 Z"
              fill="#0b1929" stroke="#38bdf8" strokeWidth="1.5" />
            {/* Lock shackle */}
            <path d="M32 36 Q32 26 40 26 Q48 26 48 36" fill="none" stroke="#38bdf8" strokeWidth="2" strokeLinecap="round" />
            {/* Lock body */}
            <rect x="28" y="36" width="24" height="16" rx="3" fill="#38bdf822" stroke="#38bdf8" strokeWidth="1.5" />
            <circle cx="40" cy="44" r="2.5" fill="#38bdf8" />
            {/* Tick marks */}
            {[0,60,120,180,240,300].map(deg => (
              <line
                key={deg}
                x1="40" y1="6"
                x2="40" y2="10"
                stroke="#38bdf844"
                strokeWidth="1"
                transform={`rotate(${deg} 40 40)`}
              />
            ))}
          </svg>
        ) : (
          <div className="ipar-cinema__table-anim">
            <div className="ipar-cinema__table-header">IP Asset Registry</div>
            {[
              { label: 'Doc Ref',    val: 'AIPP-IP-2026-001',  color: '#38bdf8' },
              { label: 'App ID',     val: 'admin-entered',      color: '#4ade80' },
              { label: 'Bundle ID',  val: 'admin-entered',      color: '#4ade80' },
              { label: 'Legal',      val: 'Verified',           color: '#4ade80' },
              { label: 'Code Audit', val: 'Verified',           color: '#4ade80' },
              { label: 'Compliance', val: 'Verified',           color: '#4ade80' },
            ].map((row, i) => (
              <div
                key={row.label}
                className="ipar-cinema__table-row"
                style={{ animationDelay: `${i * 0.1}s` }}
              >
                <span className="ipar-cinema__table-row-lbl">{row.label}</span>
                <span className="ipar-cinema__table-row-val" style={{ color: row.color }}>{row.val}</span>
              </div>
            ))}
          </div>
        )}
      </div>
      <div className="ipar-cinema__caption">{caption}<span className="ipar-cinema__cursor">|</span></div>
      <div className="ipar-cinema__avatar">
        <img src="/Jouw_alineatekst_(2).png" alt="Aippie" className="ipar-cinema__avatar-img" />
        <span className="ipar-cinema__avatar-lbl">Aippie · v201 · 0.82×</span>
      </div>
    </div>
  );
}

// ── Main registry component ───────────────────────────────────────────────────
export default function IpAssetRegistry() {
  const [records,  setRecords]  = useState<IpRecord[]>([]);
  const [loading,  setLoading]  = useState(true);
  const [userId,   setUserId]   = useState<string | null>(null);
  const [error,    setError]    = useState('');
  const mountedRef = useRef(true);

  useEffect(() => {
    supabase.auth.getUser().then(({ data }) => {
      if (data.user && mountedRef.current) setUserId(data.user.id);
    });
    return () => { mountedRef.current = false; };
  }, []);

  const load = useCallback(async () => {
    setLoading(true); setError('');
    const { data, error: err } = await supabase
      .from('ip_asset_registry')
      .select('*')
      .order('created_at', { ascending: false });
    if (!mountedRef.current) return;
    if (err) { setError(err.message); }
    else     { setRecords(data ?? []); }
    setLoading(false);
  }, []);

  useEffect(() => { load(); }, [load]);

  const addRecord = useCallback(async () => {
    if (!userId) { setError('Not authenticated.'); return; }
    const { data, error: err } = await supabase
      .from('ip_asset_registry')
      .insert({ owner_user_id: userId })
      .select()
      .single();
    if (err) { setError(err.message); return; }
    setRecords(prev => [data, ...prev]);
  }, [userId]);

  const saveRecord = useCallback(async (updated: IpRecord) => {
    const { error: err } = await supabase
      .from('ip_asset_registry')
      .update({
        doc_reference:     updated.doc_reference,
        effective_date:    updated.effective_date || null,
        target_app_id:     updated.target_app_id,
        target_bundle_id:  updated.target_bundle_id,
        check_legal_title: updated.check_legal_title,
        check_code_audit:  updated.check_code_audit,
        check_regulatory:  updated.check_regulatory,
        notes:             updated.notes,
        updated_at:        new Date().toISOString(),
      })
      .eq('id', updated.id);
    if (err) throw err;
    setRecords(prev => prev.map(r => r.id === updated.id ? { ...updated } : r));
  }, []);

  const deleteRecord = useCallback(async (id: string) => {
    const { error: err } = await supabase
      .from('ip_asset_registry')
      .delete()
      .eq('id', id);
    if (err) { setError(err.message); return; }
    setRecords(prev => prev.filter(r => r.id !== id));
  }, []);

  return (
    <div className="ipar-root">

      {/* Left column: registry */}
      <div className="ipar-main">

        {/* Header */}
        <div className="ipar-header">
          <div className="ipar-header__left">
            <Shield size={14} style={{ color: '#38bdf8' }} />
            <div>
              <div className="ipar-header__title">Intellectual Property &amp; Compliance Registry</div>
              <div className="ipar-header__sub">
                AIPPIETAX S.A. · v201 · Admin-only · Supabase RLS · All data admin-entered
              </div>
            </div>
          </div>
          <div className="ipar-header__actions">
            <button className="ipar-icon-btn" onClick={load} title="Refresh">
              <RefreshCw size={12} />
            </button>
            <button className="ipar-add-btn" onClick={addRecord} disabled={!userId}>
              <Plus size={11} /> New Record
            </button>
          </div>
        </div>

        {error && (
          <div className="ipar-error">
            <AlertCircle size={11} style={{ color: '#f87171', flexShrink: 0 }} />
            {error}
          </div>
        )}

        {loading ? (
          <div className="ipar-loading">
            <RefreshCw size={13} className="rem-spin" style={{ color: '#38bdf8' }} />
            Loading registry…
          </div>
        ) : records.length === 0 ? (
          <div className="ipar-empty">
            <Lock size={20} style={{ color: '#1e3a4a' }} />
            <div>No IP records yet.</div>
            <div style={{ fontSize: 9, color: '#334155' }}>
              Press "New Record" to add the first IP asset entry.
            </div>
          </div>
        ) : (
          <div className="ipar-list">
            {records.map(r => (
              <IpRow
                key={r.id}
                record={r}
                onSave={saveRecord}
                onDelete={deleteRecord}
              />
            ))}
          </div>
        )}

        <div className="ipar-footer">
          <Shield size={8} style={{ color: '#38bdf8' }} />
          AIPPIETAX S.A. · IP &amp; Compliance Registry · v201 · RLS-protected · No hardcoded data
        </div>
      </div>

      {/* Right column: cinema */}
      <IpCinema />
    </div>
  );
}
