import { useEffect, useRef, useState } from 'react';
import {
  Zap, Key, Copy, Check, TrendingUp, Lock,
  Activity, ShieldCheck, Globe, Building2, ArrowRight
} from 'lucide-react';
import type { User } from '@supabase/supabase-js';
import { applyPremiumVoice, withVoicesReady } from '../lib/ttsVoice';

// ── Constants ─────────────────────────────────────────────────────────────────
const DEMO_TOKEN      = 'AIPPIE-MRELECTRIC-2026-X';
const SPEECH_RATE     = 0.82;
const SPEECH_PITCH    = 1.02;
const LOCKOUT_SECS    = 47 * 3600 + 58 * 60 + 43;
const GREETING_TTS    = 'Welcome to eye-pee TAX S.A. Infrastructure. I am eye-pee. Your deployment is active. Watch the telemetry modules on your right to observe how 80 hours of manual pipeline labor is condensed to 80 minutes on autopilot.';
const GREETING_DISPLAY= 'Welcome to AIPPIETAX S.A. Infrastructure. I am Aippie. Your deployment is active. Watch the telemetry modules on your right to observe how 80 hours of manual pipeline labor is condensed to 80 minutes on autopilot.';

type Lang = 'ES' | 'EN' | 'DE' | 'NL';
const LANGS: Lang[] = ['ES', 'EN', 'DE', 'NL'];

// ── Hooks ─────────────────────────────────────────────────────────────────────
function useLockoutCountdown() {
  const [secs, setSecs] = useState(LOCKOUT_SECS);
  useEffect(() => {
    const id = setInterval(() => setSecs(s => Math.max(0, s - 1)), 1000);
    return () => clearInterval(id);
  }, []);
  const h = Math.floor(secs / 3600);
  const m = Math.floor((secs % 3600) / 60);
  const s = secs % 60;
  return [h, m, s].map(n => String(n).padStart(2, '0')).join(':');
}

function useCyclingLang() {
  const [idx, setIdx] = useState(0);
  useEffect(() => {
    const id = setInterval(() => setIdx(i => (i + 1) % LANGS.length), 1200);
    return () => clearInterval(id);
  }, []);
  return LANGS[idx];
}

function useTypewriter(text: string, active: boolean) {
  const [out, setOut] = useState('');
  const tmr = useRef<ReturnType<typeof setInterval> | null>(null);
  const idx = useRef(0);
  useEffect(() => {
    if (tmr.current) { clearInterval(tmr.current); tmr.current = null; }
    setOut('');
    if (!active || !text) return;
    const words = text.split(/\s+/);
    idx.current = 0;
    tmr.current = setInterval(() => {
      idx.current++;
      setOut(words.slice(0, idx.current).join(' '));
      if (idx.current >= words.length && tmr.current) {
        clearInterval(tmr.current); tmr.current = null;
      }
    }, 460);
    return () => { if (tmr.current) { clearInterval(tmr.current); tmr.current = null; } };
  }, [text, active]);
  return out;
}

// ── Premium 3D Female Cybernetic AI Avatar ────────────────────────────────────
function CyberFace({ speaking }: { speaking: boolean }) {
  const [blink, setBlink]     = useState(false);
  const [scanY, setScanY]     = useState(0);
  const [breathe, setBreathe] = useState(0);
  const frameRef = useRef<number>(0);
  const t0       = useRef(Date.now());

  useEffect(() => {
    const tick = () => {
      const t = (Date.now() - t0.current) / 1000;
      setScanY((t % 2.8) / 2.8);
      setBreathe(Math.sin(t * 0.9) * 0.5 + 0.5);
      frameRef.current = requestAnimationFrame(tick);
    };
    frameRef.current = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(frameRef.current);
  }, []);

  useEffect(() => {
    const schedule = (): ReturnType<typeof setTimeout> =>
      setTimeout(() => {
        setBlink(true);
        setTimeout(() => { setBlink(false); schedule(); }, 130);
      }, 2800 + Math.random() * 2400);
    const t = schedule();
    return () => clearTimeout(t);
  }, []);

  const eyeRy   = blink ? 0.4 : 6.5;
  const fScale  = 1 + breathe * 0.012;
  const glowOp  = speaking ? 0.85 : 0.35 + breathe * 0.25;
  const scanOp  = speaking ? 0.6  : 0.18 + breathe * 0.12;

  return (
    <div className={`b2b-face-wrap${speaking ? ' b2b-face-wrap--live' : ''}`}>
      <div className="b2b-halo b2b-halo--3" />
      <div className="b2b-halo b2b-halo--2" />
      <div className="b2b-halo b2b-halo--1" />

      <svg viewBox="0 0 200 220" className="b2b-avatar-svg" aria-label="Aippie AI">
        <defs>
          <radialGradient id="bskin" cx="50%" cy="42%" r="52%">
            <stop offset="0%"   stopColor="#1a3045" />
            <stop offset="55%"  stopColor="#0f1f30" />
            <stop offset="100%" stopColor="#070d14" />
          </radialGradient>
          <radialGradient id="bsheen" cx="48%" cy="28%" r="38%">
            <stop offset="0%"   stopColor="#38bdf8" stopOpacity="0.18" />
            <stop offset="100%" stopColor="#38bdf8" stopOpacity="0"    />
          </radialGradient>
          <radialGradient id="biris" cx="38%" cy="38%" r="62%">
            <stop offset="0%"   stopColor="#7dd3fc" />
            <stop offset="40%"  stopColor="#38bdf8" />
            <stop offset="100%" stopColor="#0369a1" />
          </radialGradient>
          <radialGradient id="bmglow" cx="50%" cy="50%" r="50%">
            <stop offset="0%"   stopColor="#38bdf8" stopOpacity={speaking ? '0.5' : '0'} />
            <stop offset="100%" stopColor="#38bdf8" stopOpacity="0" />
          </radialGradient>
          <radialGradient id="boglow" cx="50%" cy="50%" r="50%">
            <stop offset="0%"   stopColor="#38bdf8" stopOpacity="0" />
            <stop offset="70%"  stopColor="#38bdf8" stopOpacity={String(glowOp * 0.08)} />
            <stop offset="100%" stopColor="#38bdf8" stopOpacity={String(glowOp * 0.22)} />
          </radialGradient>
          <linearGradient id="bhair" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%"   stopColor="#061220" />
            <stop offset="100%" stopColor="#0c1e30" />
          </linearGradient>
          <linearGradient id="bneck" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%"   stopColor="#0f1f30" />
            <stop offset="100%" stopColor="#070d14" />
          </linearGradient>
          <linearGradient id="bscan" x1="0" y1="0" x2="1" y2="0">
            <stop offset="0%"   stopColor="#38bdf8" stopOpacity="0"              />
            <stop offset="20%"  stopColor="#38bdf8" stopOpacity={String(scanOp)} />
            <stop offset="80%"  stopColor="#38bdf8" stopOpacity={String(scanOp)} />
            <stop offset="100%" stopColor="#38bdf8" stopOpacity="0"              />
          </linearGradient>
          <filter id="bglow" x="-20%" y="-20%" width="140%" height="140%">
            <feGaussianBlur stdDeviation="2.5" result="blur" />
            <feComposite in="SourceGraphic" in2="blur" operator="over" />
          </filter>
        </defs>

        {/* Ambient disc */}
        <ellipse cx="100" cy="108" rx="88" ry="95" fill="url(#boglow)" />

        {/* Neck / shoulders */}
        <path d="M72 170 Q68 200 55 218 L145 218 Q132 200 128 170 Z" fill="url(#bneck)" opacity="0.9" />
        <path d="M55 218 Q100 208 145 218" fill="none" stroke="#38bdf8" strokeWidth="0.8" opacity="0.4" />
        <circle cx="75"  cy="210" r="1.8" fill="#38bdf8" opacity="0.5" filter="url(#bglow)" />
        <circle cx="125" cy="210" r="1.8" fill="#38bdf8" opacity="0.5" filter="url(#bglow)" />

        {/* Face */}
        <ellipse cx="100" cy="105" rx={String(46 * fScale)} ry={String(58 * fScale)} fill="url(#bskin)" />
        <ellipse cx="62"  cy="118" rx="14" ry="18" fill="#050c16" opacity="0.35" />
        <ellipse cx="138" cy="118" rx="14" ry="18" fill="#050c16" opacity="0.35" />
        <ellipse cx="100" cy="82"  rx="32" ry="22" fill="url(#bsheen)" />

        {/* Hair */}
        <path d="M56 90 Q54 52 100 47 Q146 52 144 90 Q130 58 100 60 Q70 58 56 90 Z" fill="url(#bhair)" opacity="0.95" />
        <path d="M84 58 Q96 50 110 54" fill="none" stroke="#1e4060" strokeWidth="2.5" opacity="0.6" />

        {/* Contours */}
        <path d="M68 148 Q100 166 132 148" fill="none" stroke="#050c16" strokeWidth="3" opacity="0.5" />
        <path d="M65 110 Q70 102 78 106"   fill="none" stroke="#1e4060" strokeWidth="1.2" opacity="0.5" />
        <path d="M135 110 Q130 102 122 106" fill="none" stroke="#1e4060" strokeWidth="1.2" opacity="0.5" />

        {/* Eyebrows */}
        <path d="M74 86 Q84 81 95 84"   fill="none" stroke="#0e2236" strokeWidth="2.8" strokeLinecap="round" opacity="0.9" />
        <path d="M105 84 Q116 81 126 86" fill="none" stroke="#0e2236" strokeWidth="2.8" strokeLinecap="round" opacity="0.9" />
        <path d="M75 85 Q84 81 94 84"   fill="none" stroke="#38bdf8" strokeWidth="0.6" opacity="0.3" />
        <path d="M106 84 Q116 81 125 86" fill="none" stroke="#38bdf8" strokeWidth="0.6" opacity="0.3" />

        {/* Eye sockets */}
        <ellipse cx="84"  cy="100" rx="11" ry="5" fill="#040b12" opacity="0.7" />
        <ellipse cx="116" cy="100" rx="11" ry="5" fill="#040b12" opacity="0.7" />

        {/* Eye whites */}
        <ellipse cx="84"  cy="99" rx="9.5" ry={eyeRy} fill="#0a1e2e" stroke="#38bdf8" strokeWidth="0.8" opacity="0.9" />
        <ellipse cx="116" cy="99" rx="9.5" ry={eyeRy} fill="#0a1e2e" stroke="#38bdf8" strokeWidth="0.8" opacity="0.9" />

        {/* Iris / pupil / highlights */}
        {!blink && <ellipse cx="84"  cy="99" rx="6" ry="5.8" fill="url(#biris)" filter="url(#bglow)" />}
        {!blink && <ellipse cx="116" cy="99" rx="6" ry="5.8" fill="url(#biris)" filter="url(#bglow)" />}
        {!blink && <circle  cx="84"  cy="99.5" r="2.8" fill="#010810" />}
        {!blink && <circle  cx="116" cy="99.5" r="2.8" fill="#010810" />}
        {!blink && <circle  cx="82"  cy="97.5" r="1.2" fill="#ffffff" opacity="0.85" />}
        {!blink && <circle  cx="114" cy="97.5" r="1.2" fill="#ffffff" opacity="0.85" />}
        {!blink && <circle  cx="86.2"  cy="101.5" r="0.6" fill="#7dd3fc" opacity="0.5" />}
        {!blink && <circle  cx="118.2" cy="101.5" r="0.6" fill="#7dd3fc" opacity="0.5" />}

        {/* Nose */}
        <path d="M97 106 Q94 116 96 122 Q100 126 104 122 Q106 116 103 106" fill="none" stroke="#071523" strokeWidth="1.4" opacity="0.65" />
        <ellipse cx="96.5"  cy="122" rx="3.5" ry="2" fill="#040b12" opacity="0.55" />
        <ellipse cx="103.5" cy="122" rx="3.5" ry="2" fill="#040b12" opacity="0.55" />

        {/* Lips */}
        <ellipse cx="100" cy="140" rx="16" ry="8" fill="url(#bmglow)" />
        <path
          d={speaking ? 'M82 134 Q90 130 100 133 Q110 130 118 134 Q110 138 100 136 Q90 138 82 134 Z'
                      : 'M82 136 Q90 132 100 134 Q110 132 118 136 Q110 138 100 137 Q90 138 82 136 Z'}
          fill="#0e1e2e" stroke="#38bdf8" strokeWidth="0.6" opacity="0.9"
        />
        <path
          d={speaking ? 'M82 134 Q90 148 100 150 Q110 148 118 134'
                      : 'M82 136 Q90 146 100 148 Q110 146 118 136'}
          fill="#0d1b2b" stroke="#38bdf8" strokeWidth="0.7" opacity="0.8"
        />
        <path d="M91 136 Q96 134 103 136" fill="none" stroke="#1e5070" strokeWidth="1" opacity="0.5" />

        {/* Temple implants */}
        <circle cx="56"  cy="98" r="4" fill="#061220" stroke="#38bdf8" strokeWidth="0.8" opacity="0.7" filter="url(#bglow)" />
        <circle cx="56"  cy="98" r="1.8" fill="#38bdf8" opacity={String(0.5 + breathe * 0.4)} />
        <line x1="52" y1="98" x2="44" y2="95" stroke="#38bdf8" strokeWidth="0.7" opacity="0.4" />
        <line x1="44" y1="95" x2="36" y2="98" stroke="#38bdf8" strokeWidth="0.7" opacity="0.3" />
        <circle cx="36" cy="98" r="1.2" fill="#38bdf8" opacity="0.35" />

        <circle cx="144" cy="98" r="4" fill="#061220" stroke="#38bdf8" strokeWidth="0.8" opacity="0.7" filter="url(#bglow)" />
        <circle cx="144" cy="98" r="1.8" fill="#38bdf8" opacity={String(0.5 + breathe * 0.4)} />
        <line x1="148" y1="98" x2="156" y2="95" stroke="#38bdf8" strokeWidth="0.7" opacity="0.4" />
        <line x1="156" y1="95" x2="164" y2="98" stroke="#38bdf8" strokeWidth="0.7" opacity="0.3" />
        <circle cx="164" cy="98" r="1.2" fill="#38bdf8" opacity="0.35" />

        {/* Scan line */}
        <line
          x1={20 + scanY * 4} y1={50 + scanY * 130}
          x2={180 - scanY * 4} y2={50 + scanY * 130}
          stroke="url(#bscan)" strokeWidth="1.2"
        />

        {/* Corner brackets */}
        <path d="M18 16 L18 8 L26 8"   fill="none" stroke="#38bdf8" strokeWidth="1" opacity="0.4" />
        <path d="M182 8 L174 8 L174 16" fill="none" stroke="#38bdf8" strokeWidth="1" opacity="0.4" />
        <path d="M18 204 L18 212 L26 212"   fill="none" stroke="#38bdf8" strokeWidth="1" opacity="0.4" />
        <path d="M182 212 L174 212 L174 204" fill="none" stroke="#38bdf8" strokeWidth="1" opacity="0.4" />
        <circle cx="18"  cy="8"   r="2.5" fill="#38bdf8" opacity={String(0.4 + breathe * 0.5)} filter="url(#bglow)" />
        <circle cx="182" cy="8"   r="2.5" fill="#38bdf8" opacity={String(0.4 + breathe * 0.5)} filter="url(#bglow)" />
        <circle cx="18"  cy="212" r="2"   fill="#38bdf8" opacity="0.3" />
        <circle cx="182" cy="212" r="2"   fill="#38bdf8" opacity="0.3" />

        {/* Waveform */}
        {[0,1,2,3,4,5,6,7,8].map(i => {
          const h = speaking ? 4 + Math.sin(Date.now() * 0.01 + i * 0.9) * 8 : 2;
          return <rect key={i} x={60 + i * 10} y={195 - h / 2} width="5" height={h} rx="1.5" fill="#38bdf8" opacity={speaking ? 0.55 : 0.18} />;
        })}
      </svg>

      <div className="b2b-avatar-badge">
        <span className={`b2b-cin-mode-dot${speaking ? ' b2b-cin-mode-dot--live' : ''}`} />
        <span className="b2b-avatar-badge__label">{speaking ? 'CINEMATIC MODE — LIVE' : 'AIPPIE A.I. · READY'}</span>
      </div>
    </div>
  );
}

// ── Main B2B Dashboard ────────────────────────────────────────────────────────
export default function AippieB2BView(_: { user: User | null }) {
  const countdown  = useLockoutCountdown();
  const activeLang = useCyclingLang();

  const [speaking,   setSpeaking]   = useState(false);
  const [langCounts, setLangCounts] = useState<Record<Lang, number>>({ ES: 39, EN: 27, DE: 19, NL: 18 });
  const [copied,     setCopied]     = useState(false);
  const [deploying,  setDeploying]  = useState(false);
  const cancelRef = useRef(false);
  const caption   = useTypewriter(GREETING_DISPLAY, speaking);
  const totalLeads = Object.values(langCounts).reduce((a, b) => a + b, 0);

  // Auto TTS on mount
  useEffect(() => {
    cancelRef.current = false;
    setSpeaking(true);
    const fire = () => {
      if (cancelRef.current) { setSpeaking(false); return; }
      const u = new SpeechSynthesisUtterance(GREETING_TTS);
      u.rate  = SPEECH_RATE;
      u.pitch = SPEECH_PITCH;
      applyPremiumVoice(u);
      u.onend   = () => { if (!cancelRef.current) setSpeaking(false); };
      u.onerror = () => { if (!cancelRef.current) setSpeaking(false); };
      window.speechSynthesis.speak(u);
    };
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      withVoicesReady(fire);
    }
    return () => { cancelRef.current = true; window.speechSynthesis?.cancel(); };
  }, []);

  // Live lead pulse
  useEffect(() => {
    const id = setInterval(() => {
      const pick = LANGS[Math.floor(Math.random() * LANGS.length)];
      setLangCounts(prev => ({ ...prev, [pick]: prev[pick] + 1 }));
    }, 1100);
    return () => clearInterval(id);
  }, []);

  const copyToken = () => {
    navigator.clipboard.writeText(DEMO_TOKEN).catch(() => {});
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  const handleDeploy = () => {
    setDeploying(true);
    setTimeout(() => setDeploying(false), 2200);
  };

  return (
    <div className="b2b-v214-root">

      {/* ══ HEADER BANNER ══════════════════════════════════════════════════════ */}
      <div className="b2b-v214-banner">
        <div className="b2b-v214-banner__left">
          <div className="b2b-v214-banner__icon"><Zap size={14} /></div>
          <div>
            <div className="b2b-v214-banner__title">AIPPIE B2B ENTERPRISE CONTROL PANEL (v214)</div>
            <div className="b2b-v214-banner__sub">
              Active License: <span className="b2b-v214-hl">Maria Electric B.V.</span>
              <span className="b2b-v214-sep">·</span>
              Gateway: <span className="b2b-v214-secure">OPERATIONAL &amp; SECURE</span>
            </div>
          </div>
        </div>
        <div className="b2b-v214-tags">
          <span className="b2b-v214-tag">[ENGINE: 100% CLEAN]</span>
          <span className="b2b-v214-tag">[COMPLIANCE: AML_VALID]</span>
        </div>
      </div>

      {/* ══ MAIN AREA: AVATAR LEFT · TELEMETRY RIGHT ══════════════════════════ */}
      <div className="b2b-v214-main">

        {/* ── LEFT: Avatar + caption ── */}
        <div className="b2b-v214-left">
          <CyberFace speaking={speaking} />
          <div className={`b2b-v214-caption${speaking ? ' b2b-v214-caption--live' : ''}`}>
            <div className="b2b-v214-caption__bar">
              <span className={`b2b-v214-caption__dot${speaking ? ' b2b-v214-caption__dot--on' : ''}`} />
              <span className="b2b-v214-caption__status">{speaking ? 'LIVE TRANSCRIPT' : 'STANDBY'}</span>
            </div>
            <p className="b2b-v214-caption__text">
              {caption || <span className="b2b-v214-caption__idle">Initializing voice synthesis…</span>}
            </p>
          </div>
        </div>

        {/* ── RIGHT: Three telemetry panels ── */}
        <div className="b2b-v214-right">

          {/* Panel 1 — Leads Grid */}
          <div className="b2b-v214-panel b2b-v214-panel--leads">
            <div className="b2b-v214-panel__head">
              <Activity size={11} />
              <span>Active Inbound Leads</span>
              <span className="b2b-v214-live-dot" />
              <span className="b2b-v214-panel__kpi">{totalLeads}</span>
            </div>
            <div className="b2b-v214-bars">
              {(Object.entries(langCounts) as [Lang, number][]).map(([lang, count]) => {
                const pct = Math.round((count / totalLeads) * 100);
                const on  = activeLang === lang;
                return (
                  <div key={lang} className={`b2b-v214-bar-row${on ? ' b2b-v214-bar-row--on' : ''}`}>
                    <span className="b2b-v214-bar-row__lang">{lang}</span>
                    <div className="b2b-v214-track">
                      <div className={`b2b-v214-fill${on ? ' b2b-v214-fill--on' : ''}`} style={{ width: `${pct}%` }} />
                    </div>
                    <span className="b2b-v214-bar-row__n">{count}</span>
                  </div>
                );
              })}
            </div>
            <div className="b2b-v214-panel__foot">50ms language recognition · ES / EN / DE / NL</div>
          </div>

          {/* Panel 2 — Cryptographic License Keys */}
          <div className="b2b-v214-panel b2b-v214-panel--token">
            <div className="b2b-v214-panel__head">
              <Key size={11} />
              <span>Cryptographic License Keys</span>
              <span className="b2b-v214-secure-tag">SECURE</span>
            </div>
            <div className="b2b-v214-token-row">
              <code className="b2b-v214-token">{DEMO_TOKEN}</code>
              <button className="b2b-v214-copy-btn" onClick={copyToken}>
                {copied ? <><Check size={11} /> Copied!</> : <><Copy size={11} /> Copy Token</>}
              </button>
            </div>
            <div className="b2b-v214-dots-row">
              {[...Array(5)].map((_, i) => (
                <span key={i} className={`b2b-v214-dot${i < 4 ? ' b2b-v214-dot--on' : ''}`} />
              ))}
              <span className="b2b-v214-dots-label">4 / 5 active · Maria Electric B.V.</span>
            </div>
          </div>

          {/* Panel 3 — 48-Hour Lockout */}
          <div className="b2b-v214-panel b2b-v214-panel--lockout">
            <div className="b2b-v214-panel__head b2b-v214-panel__head--red">
              <div className="b2b-v214-lockout-pulse" />
              <span>48-Hour Server Lockout Warning</span>
              <span className="b2b-v214-clause-tag">CLAUSE 4.1</span>
            </div>
            <div className="b2b-v214-lockout-clock">{countdown}</div>
            <div className="b2b-v214-lockout-steps">
              <div><span className="b2b-v214-step-n">1</span>Automated timestamp tracking active</div>
              <div><span className="b2b-v214-step-n">2</span>48h grace · bi-weekly €1,550 disbursement required</div>
              <div><span className="b2b-v214-step-n">3</span>Instant server freeze on non-compliance</div>
            </div>
            <div className="b2b-v214-lockout-bar"><div className="b2b-v214-lockout-fill" /></div>
          </div>

        </div>
      </div>

      {/* ══ SECTION 1 & 2 — FUNCTIONAL SPECIFICATION PANEL ════════════════════ */}
      <div className="b2b-v214-spec">
        <div className="b2b-v214-spec__head">
          <ShieldCheck size={13} />
          <span>Functional Specification Manual — v214 · Section 1 &amp; 2</span>
          <span className="b2b-v214-spec__badge">AIPPIETAX S.A.</span>
        </div>
        <div className="b2b-v214-spec__grid">
          <div className="b2b-v214-spec__block">
            <div className="b2b-v214-spec__block-title">
              <Globe size={11} /> Section 1 — Operating Model (AIaaS)
            </div>
            <p>AIPPIETAX S.A. operates as an <strong>AI-as-a-Service (AIaaS)</strong> provider under autonomous infrastructure governance. The platform deploys multi-tenant enterprise modules — each licensed independently — eliminating the need for in-house AI development, DevOps teams, or custom integrations. Clients receive a fully managed, sovereign AI backbone operating 24/7 with zero maintenance overhead.</p>
            <ul>
              <li>Autonomous Infrastructure — zero DevOps requirement for client tenants</li>
              <li>Multi-Tenant Architecture — isolated namespaces per enterprise license</li>
              <li>Sovereign Data Handling — GDPR-compliant, EU-hosted vector databases</li>
              <li>Revenue Model — bi-weekly €1,550 disbursement per active enterprise seat</li>
            </ul>
          </div>
          <div className="b2b-v214-spec__block">
            <div className="b2b-v214-spec__block-title">
              <Building2 size={11} /> Section 2 — Automated Data Pipelines
            </div>
            <p>The v214 pipeline condenses <strong>80 hours of manual labor</strong> to <strong>80 minutes on autopilot</strong> across five automated stages operating concurrently upon license activation:</p>
            <ul>
              <li><strong>Step 1:</strong> Inbound Lead Tracker — ES/EN/DE/NL multi-language intake with 50ms routing classification</li>
              <li><strong>Step 2:</strong> Token Handshake — generate_smart_home_license_key() issues AIPPIE-XXXX cryptographic tokens bound to tenant domain</li>
              <li><strong>Step 3:</strong> Real-Time Orchestration — aippie_memory.chat_embeddings vector store syncs client context across all 20 modules</li>
              <li><strong>Step 4:</strong> Banco Sabadell Ledger — automated disbursement scheduling with AML_VALID compliance gate</li>
              <li><strong>Step 5:</strong> Clause 4.1 Lockout Engine — 48-hour countdown arms automatically on billing cycle open; freezes access tokens on non-payment</li>
            </ul>
          </div>
        </div>
      </div>

      {/* ══ DEPLOY CTA ═════════════════════════════════════════════════════════ */}
      <button
        className={`b2b-v214-deploy-btn${deploying ? ' b2b-v214-deploy-btn--active' : ''}`}
        onClick={handleDeploy}
      >
        {deploying ? (
          <><span className="b2b-v214-deploy-spinner" /> Deploying Core Shell…</>
        ) : (
          <><Zap size={15} /> Deploy Multi-Tenant AI Core Shell <ArrowRight size={15} /></>
        )}
      </button>

    </div>
  );
}
