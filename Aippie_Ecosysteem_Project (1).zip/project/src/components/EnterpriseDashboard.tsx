// @ts-nocheck
/**
 * EnterpriseDashboard — AIPPIE AI Manager Command Center
 * Standalone premium module: routed via tab='aimanager'
 * Requires active subscription (trading_alpha / corporate_b2b / premium_jurado)
 */
import { useEffect, useRef, useState, useCallback } from 'react';
import {
  Terminal, Cpu, Activity, Shield, ChevronRight,
  Zap, Globe, BarChart3, Lock, FileText, Users,
  AlertTriangle, CheckCircle2,
} from 'lucide-react';
import { supabase } from '../lib/supabase';

// ── Colour tokens ─────────────────────────────────────────────────────────────
const C = {
  bg:       '#0B0F19',
  surface:  '#0F1520',
  border:   'rgba(16,185,129,0.18)',
  borderHi: 'rgba(16,185,129,0.5)',
  green:    '#10B981',
  greenDim: 'rgba(16,185,129,0.12)',
  greenGlow:'rgba(16,185,129,0.25)',
  text:     '#E2E8F0',
  muted:    '#64748B',
  dim:      '#334155',
} as const;

// ── Telemetry pool ────────────────────────────────────────────────────────────
const TELEMETRY_POOL = [
  '[CORE] AIPPIE Core: multi-country wage structures mapped via ES / NL / US local tax APIs.',
  '[PAY]  Payroll matrix v4.2 compiled — 3 jurisdictions · 0 discrepancies.',
  '[TAX]  Verifactu hash-chain verification passed — block #004418 committed.',
  '[SYNC] Real-time data-loop heartbeat OK — latency 4ms.',
  '[AGENT] Sub-manager "ContractScan-v3" deployed to node EU-WEST-1.',
  '[LEDGER] Autonomous invoicing engine processed batch #2291.',
  '[HEALTH] Memory utilisation 38.2% — all systems nominal.',
  '[PAY]  calcAlgemeneHeffingskorting executed for NL employee set.',
  '[PAY]  calcArbeidskorting routine passed — net delta €0.00.',
  '[TAX]  ES tax bracket enforcement confirmed — T-IRPF 24% segment locked.',
  '[AGENT] Logistics-scanner sub-manager requested — spawning worker.',
  '[CORE] 83-module skill treasury snapshot verified at epoch 1751298042.',
  '[DEPLOY] Creator social-media engine compiled — status READY.',
  '[SYNC] Supabase realtime channel reconnect — latency 7ms.',
  '[SEC]  AES-256 vault seal verified — document store integrity OK.',
  '[AGENT] Contract-safety compliance engine initialised.',
  '[PAY]  US federal withholding table applied — bracket 22%.',
  '[CORE] KPI strip refreshed — 142,890 tasks executed this cycle.',
  '[LEDGER] SEPA batch payout queued — 14 beneficiaries.',
  '[HEALTH] Autonomous-hours-saved counter updated: 642h.',
];

const BOOT_MSG =
  'System initialisation complete. The AIPPIE AI Manager is online. ' +
  'Real-time background data monitoring loops are fully synchronised with your core utilities. ' +
  'Payroll matrices and Verifactu compliance engines are verified in server cache. ' +
  'Standing by to autonomously generate, compile, and execute dedicated sub-managers ' +
  'from our 83-module skill treasury to handle your operational scaling. ' +
  'Instruct your AI Manager below.';

const SKILL_TREASURY = [
  'ContractScannerPro','LogisticsOptimiser','SocialCreatorEngine','PayrollES-v4',
  'PayrollNL-v4','PayrollUS-v4','VerifactuGateway','InvoiceArchiver',
  'TaxBracketEnforcer','SEPABatchRouter','RecruitmentScreener','HRComplianceAudit',
  'DocumentVaultSeal','FinancialForecast','CashFlowPredictor','TradingAlphaBot',
  'RealEstateAnalyser','InsuranceParser','MedicalTriageBot','PharmaLedger',
  'EnergyOptimiser','CarbonTracker','GDPR-AuditPro','CyberThreatMonitor',
  'IdentityVerifier','KYC-AutoRouter','AntiMoneyLaundering','FraudDetect-v2',
  'IPAssetRegistry','TrademarksScanner','PatentDraftAssist','LegalClause-AI',
  'CourtDateTracker','LitigationPredictor','B2B-OutreachBot','LeadQualifier',
  'CRM-SyncEngine','EmailCampaignBot','SlackIntegrator','TeamsConnector',
  'ZoomScheduler','CalendarOptimiser','ReceiptOCR','ExpenseCategorisor',
  'BudgetAlertEngine','SupplierNegotiator','PurchaseOrderBot','InventoryTracker',
  'WarehouseRouter','ShippingLabel-AI','CustomsDutyCal','FX-HedgeAdvisor',
  'CryptoTaxReport','DeFiAuditBot','NFT-ValuationAI','BlockchainLedger',
  'ESG-Reporter','SustainabilityKPI','WorkforceAnalytics','TalentMapAI',
  'OnboardingOrchestrator','PerformanceCoach','WellnessMonitor','SafeCheckIn',
  'EmergencyDispatch','LanguageTranslator','SentimentAnalyser','NewsDigest-AI',
  'PressRelease-Bot','VideoScript-AI','PodcastProducer','SEO-ContentBot',
  'AdCopyGen','MarketResearch-AI','CompetitorMonitor','PricingOptimiser',
  'CustomerServiceBot','EscalationRouter','NPS-AnalysisAI','ReviewResponder',
  'DataCleansingBot','DataPipelineAI','BI-DashboardGen','APIIntegratorBot',
];

// ── Subscription check ────────────────────────────────────────────────────────
function useSubscriptionCheck() {
  const [status, setStatus] = useState<'loading' | 'active' | 'none'>('loading');
  useEffect(() => {
    supabase.auth.getSession().then(async ({ data: { session } }) => {
      if (!session) { setStatus('none'); return; }
      const { data } = await supabase
        .from('subscriptions')
        .select('id')
        .eq('user_id', session.user.id)
        .eq('status', 'active')
        .in('plan_tier', ['trading_alpha', 'corporate_b2b', 'premium_jurado'])
        .maybeSingle();
      setStatus(data ? 'active' : 'none');
    }).catch(() => setStatus('none'));
  }, []);
  return status;
}

// ── Typewriter hook ───────────────────────────────────────────────────────────
function useTypewriter(text: string, speed = 20) {
  const [idx, setIdx] = useState(0);
  useEffect(() => {
    setIdx(0);
    const t = setInterval(() => setIdx(i => (i < text.length ? i + 1 : i)), speed);
    return () => clearInterval(t);
  }, [text, speed]);
  return text.slice(0, idx);
}

// ── Count-up hook ─────────────────────────────────────────────────────────────
function useCountUp(target: number, duration = 1600) {
  const [val, setVal] = useState(0);
  useEffect(() => {
    let start: number;
    const step = (ts: number) => {
      if (!start) start = ts;
      const p = Math.min((ts - start) / duration, 1);
      setVal(Math.round((1 - Math.pow(1 - p, 3)) * target));
      if (p < 1) requestAnimationFrame(step);
    };
    requestAnimationFrame(step);
  }, [target, duration]);
  return val;
}

// ── Telemetry Canvas ──────────────────────────────────────────────────────────
function TelemetryCanvas() {
  const ref = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const canvas = ref.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d')!;
    let raf: number;
    let t = 0;
    const waves = [
      { amp: 0.18, freq: 0.018, phase: 0,   alpha: 0.55 },
      { amp: 0.11, freq: 0.028, phase: 1.1, alpha: 0.3  },
      { amp: 0.08, freq: 0.038, phase: 2.4, alpha: 0.18 },
    ];
    const draw = () => {
      const W = canvas.offsetWidth, H = canvas.offsetHeight;
      ctx.clearRect(0, 0, W, H);
      waves.forEach(({ amp, freq, phase, alpha }) => {
        ctx.beginPath();
        for (let x = 0; x <= W; x += 2) {
          const y = H / 2 + H * amp * Math.sin(x * freq + t + phase);
          x === 0 ? ctx.moveTo(x, y) : ctx.lineTo(x, y);
        }
        const g = ctx.createLinearGradient(0, 0, W, 0);
        g.addColorStop(0, `rgba(16,185,129,0)`);
        g.addColorStop(0.3, `rgba(16,185,129,${alpha})`);
        g.addColorStop(0.7, `rgba(16,185,129,${alpha})`);
        g.addColorStop(1, `rgba(16,185,129,0)`);
        ctx.strokeStyle = g; ctx.lineWidth = 1.5; ctx.stroke();
      });
      ctx.beginPath(); ctx.setLineDash([4, 8]);
      ctx.moveTo(0, H / 2); ctx.lineTo(W, H / 2);
      ctx.strokeStyle = 'rgba(16,185,129,0.07)'; ctx.lineWidth = 1; ctx.stroke();
      ctx.setLineDash([]);
      t += 0.025;
      raf = requestAnimationFrame(draw);
    };
    const resize = () => {
      canvas.width  = canvas.offsetWidth  * devicePixelRatio;
      canvas.height = canvas.offsetHeight * devicePixelRatio;
      ctx.scale(devicePixelRatio, devicePixelRatio);
    };
    resize(); draw();
    window.addEventListener('resize', resize);
    return () => { cancelAnimationFrame(raf); window.removeEventListener('resize', resize); };
  }, []);
  return <canvas ref={ref} style={{ width: '100%', height: 64, display: 'block', borderRadius: 8 }} />;
}

// ── Telemetry log ─────────────────────────────────────────────────────────────
function TelemetryLog() {
  const [lines, setLines] = useState<string[]>([]);
  useEffect(() => {
    let i = 0;
    const tick = () => {
      const ts = new Date().toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
      setLines(prev => [`[${ts}] ${TELEMETRY_POOL[i % TELEMETRY_POOL.length]}`, ...prev].slice(0, 30));
      i++;
    };
    tick();
    const id = setInterval(tick, 2800);
    return () => clearInterval(id);
  }, []);
  return (
    <div style={{
      background: 'rgba(0,0,0,0.55)', border: `1px solid ${C.border}`,
      borderRadius: 8, padding: '10px 12px',
      fontFamily: "'JetBrains Mono', 'Fira Code', monospace",
      fontSize: 9.5, lineHeight: 1.7, color: 'rgba(16,185,129,0.75)',
      height: 148, overflowY: 'hidden', position: 'relative',
    }}>
      <div style={{
        position: 'absolute', bottom: 0, left: 0, right: 0, height: 48,
        background: 'linear-gradient(transparent, rgba(0,0,0,0.55))',
        pointerEvents: 'none', borderRadius: '0 0 8px 8px',
      }} />
      {lines.map((l, i) => (
        <div key={i} style={{ opacity: Math.max(0.15, 1 - i * 0.07) }}>{l}</div>
      ))}
    </div>
  );
}

// ── Core action card ──────────────────────────────────────────────────────────
function CoreCard({ icon: Icon, title, subtitle, onClick }: {
  icon: React.ComponentType<{ size?: number; color?: string; strokeWidth?: number }>;
  title: string; subtitle: string; onClick: () => void;
}) {
  const [hov, setHov] = useState(false);
  return (
    <button
      onClick={onClick}
      onMouseEnter={() => setHov(true)}
      onMouseLeave={() => setHov(false)}
      style={{
        width: '100%', textAlign: 'left', cursor: 'pointer', outline: 'none',
        background: hov ? `linear-gradient(135deg, ${C.greenDim}, rgba(16,185,129,0.06))` : `linear-gradient(135deg, rgba(16,185,129,0.05), rgba(0,0,0,0))`,
        border: `1px solid ${hov ? C.borderHi : C.border}`,
        borderRadius: 12, padding: '14px 16px',
        display: 'flex', alignItems: 'flex-start', gap: 12,
        transition: 'all 0.2s ease',
        boxShadow: hov ? `0 0 20px ${C.greenGlow}` : 'none',
      }}
    >
      <div style={{
        width: 36, height: 36, borderRadius: 9, flexShrink: 0,
        background: C.greenDim, border: `1px solid ${C.borderHi}`,
        display: 'flex', alignItems: 'center', justifyContent: 'center',
      }}>
        <Icon size={16} color={C.green} strokeWidth={1.8} />
      </div>
      <div style={{ flex: 1 }}>
        <div style={{ color: C.text, fontSize: 11.5, fontWeight: 700, marginBottom: 3, lineHeight: 1.3 }}>{title}</div>
        <div style={{ color: C.muted, fontSize: 9.5, lineHeight: 1.5 }}>{subtitle}</div>
      </div>
      <ChevronRight size={12} color={C.muted} style={{ flexShrink: 0, marginTop: 12 }} />
    </button>
  );
}

// ── KPI strip ─────────────────────────────────────────────────────────────────
function KPIStrip({ agents }: { agents: number }) {
  const tasks = useCountUp(142890, 2200);
  const hours = useCountUp(642, 1800);
  const kpis = [
    { label: 'MICRO-AGENT DEPLOYMENTS', value: agents.toLocaleString(),      color: C.green   },
    { label: 'TASKS EXECUTED',          value: tasks.toLocaleString(),       color: '#38BDF8' },
    { label: 'AUTONOMOUS HRS SAVED',    value: `${hours.toLocaleString()}h`, color: '#A78BFA' },
    { label: 'NETWORK HEALTH',          value: '99.87%',                     color: '#F59E0B' },
  ];
  return (
    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 8, marginBottom: 18 }}>
      {kpis.map(k => (
        <div key={k.label} style={{
          background: 'rgba(0,0,0,0.4)', border: `1px solid ${C.border}`,
          borderRadius: 10, padding: '10px 14px', position: 'relative', overflow: 'hidden',
        }}>
          <div style={{ fontSize: 16, fontWeight: 900, color: k.color, fontVariantNumeric: 'tabular-nums', lineHeight: 1, textShadow: `0 0 16px ${k.color}88` }}>
            {k.value}
          </div>
          <div style={{ fontSize: 8, fontWeight: 700, color: C.muted, letterSpacing: '0.1em', marginTop: 5 }}>{k.label}</div>
          <div style={{ position: 'absolute', bottom: 0, left: 0, right: 0, height: 2, background: `linear-gradient(90deg, transparent, ${k.color}66, transparent)` }} />
        </div>
      ))}
    </div>
  );
}

// ── Code-stream effect ────────────────────────────────────────────────────────
function CodeStream({ onDone }: { onDone: () => void }) {
  const chars = '01ABCDEF⬡◈▲⬢█░▒▓⌬∆◇';
  const [frame, setFrame] = useState(0);
  const [rows, setRows] = useState(() =>
    Array.from({ length: 4 }, () =>
      Array.from({ length: 36 }, () => chars[Math.floor(Math.random() * chars.length)]).join('')
    )
  );
  useEffect(() => {
    const id = setInterval(() => {
      setFrame(f => f + 1);
      setRows(Array.from({ length: 4 }, () =>
        Array.from({ length: 36 }, () => chars[Math.floor(Math.random() * chars.length)]).join('')
      ));
    }, 60);
    const done = setTimeout(() => { clearInterval(id); onDone(); }, 1100);
    return () => { clearInterval(id); clearTimeout(done); };
  }, []);
  return (
    <div style={{
      background: 'rgba(0,0,0,0.7)', border: `1px solid ${C.borderHi}`,
      borderRadius: 10, padding: '14px 16px', marginBottom: 12,
      fontFamily: "'JetBrains Mono', monospace", fontSize: 10, color: C.green,
      opacity: frame > 14 ? Math.max(0, 1 - (frame - 14) * 0.1) : 1,
    }}>
      <div style={{ color: C.muted, fontSize: 8, marginBottom: 6, letterSpacing: '0.12em' }}>
        ▶ GENERATING SUB-MANAGER PIPELINE...
      </div>
      {rows.map((r, i) => <div key={i} style={{ opacity: 0.6 + i * 0.1 }}>{r}</div>)}
    </div>
  );
}

// ── Chat message type ─────────────────────────────────────────────────────────
interface ChatMsg { role: 'user' | 'agent'; text: string; skill?: string; streaming?: boolean; }

// ── Paywall overlay ───────────────────────────────────────────────────────────
function PaywallOverlay({ onUpgrade }: { onUpgrade: () => void }) {
  return (
    <div style={{
      position: 'absolute', inset: 0, zIndex: 50,
      backdropFilter: 'blur(14px)', background: 'rgba(11,15,25,0.88)',
      display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
      borderRadius: 16, padding: 32,
    }}>
      <div style={{
        width: 64, height: 64, borderRadius: '50%',
        background: C.greenDim, border: `1.5px solid ${C.borderHi}`,
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        boxShadow: `0 0 36px ${C.greenGlow}`, marginBottom: 20,
        animation: 'ed-pulse 2s ease-in-out infinite',
      }}>
        <Lock size={26} color={C.green} strokeWidth={1.6} />
      </div>
      <div style={{ color: C.text, fontSize: 18, fontWeight: 900, marginBottom: 8, textAlign: 'center' }}>
        Enterprise Access Required
      </div>
      <div style={{ color: C.muted, fontSize: 12, lineHeight: 1.7, textAlign: 'center', maxWidth: 340, marginBottom: 28 }}>
        The AIPPIE AI Manager is restricted to active Enterprise subscribers.
        Upgrade to unlock autonomous sub-manager deployment and the complete 83-module skill treasury.
      </div>
      <button
        onClick={onUpgrade}
        style={{
          background: `linear-gradient(135deg, ${C.green}, #059669)`,
          border: 'none', borderRadius: 10, padding: '13px 36px',
          color: '#000', fontSize: 14, fontWeight: 900, cursor: 'pointer',
          letterSpacing: '0.06em', boxShadow: `0 8px 32px ${C.greenGlow}`,
        }}
      >
        UPGRADE — VIEW PLANS
      </button>
      <div style={{ color: C.dim, fontSize: 10, marginTop: 14 }}>PayPal · SEPA · AIPPIETAX S.A. · NIF A22944987</div>
    </div>
  );
}

// ── Upgrade modal ─────────────────────────────────────────────────────────────
function UpgradeModal({ onClose }: { onClose: () => void }) {
  return (
    <div style={{
      position: 'fixed', inset: 0, zIndex: 999, background: 'rgba(0,0,0,0.96)',
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      padding: 24, animation: 'ed-fadein 0.3s ease',
    }}>
      <div style={{
        background: C.surface, border: `1px solid ${C.border}`, borderRadius: 18,
        padding: '36px 32px', maxWidth: 480, width: '100%', position: 'relative',
        boxShadow: `0 0 80px ${C.greenGlow}`,
      }}>
        <button onClick={onClose} style={{
          position: 'absolute', top: 14, right: 14,
          background: 'rgba(255,255,255,0.05)', border: `1px solid ${C.border}`,
          borderRadius: '50%', width: 34, height: 34,
          color: C.muted, cursor: 'pointer', fontSize: 16,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
        }}>✕</button>
        <div style={{ color: C.green, fontSize: 10, fontWeight: 700, letterSpacing: '0.14em', marginBottom: 10 }}>
          ENTERPRISE UPGRADE
        </div>
        <h2 style={{ color: C.text, fontSize: 22, fontWeight: 900, margin: '0 0 6px' }}>AIPPIE AI Manager</h2>
        <p style={{ color: C.muted, fontSize: 12, lineHeight: 1.7, margin: '0 0 24px' }}>
          Unlock autonomous sub-manager deployment, real-time payroll engines, and the complete 83-module skill treasury.
        </p>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 12, marginBottom: 24 }}>
          {[
            { name: 'Trading Alpha', price: '€299', period: '/mo', color: '#F59E0B', url: 'https://www.paypal.com/paypalme/aippietax/299', desc: 'Full AI Manager · 83 modules · Priority deploy' },
            { name: 'Corporate B2B', price: '€199', period: '/mo', color: C.green,   url: 'https://www.paypal.com/paypalme/aippietax/199', desc: '50 modules · Multi-jurisdiction payroll · Verifactu', popular: true },
          ].map(p => (
            <div key={p.name} style={{
              background: p.popular ? C.greenDim : 'rgba(0,0,0,0.3)',
              border: `1px solid ${p.popular ? C.borderHi : C.border}`,
              borderRadius: 14, padding: '16px 18px', position: 'relative',
            }}>
              {p.popular && (
                <div style={{
                  position: 'absolute', top: -10, left: '50%', transform: 'translateX(-50%)',
                  background: C.green, color: '#000', fontSize: 8, fontWeight: 800,
                  padding: '3px 12px', borderRadius: 20, letterSpacing: '0.12em',
                }}>MOST POPULAR</div>
              )}
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 }}>
                <div>
                  <div style={{ color: C.text, fontWeight: 800, fontSize: 14 }}>{p.name}</div>
                  <div style={{ color: C.muted, fontSize: 10, marginTop: 2 }}>{p.desc}</div>
                </div>
                <div>
                  <span style={{ color: p.color, fontSize: 22, fontWeight: 900 }}>{p.price}</span>
                  <span style={{ color: C.muted, fontSize: 10 }}>{p.period}</span>
                </div>
              </div>
              <a
                href={p.url} target="_blank" rel="noopener noreferrer"
                style={{
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  background: '#003087', borderRadius: 8, padding: '10px 0',
                  color: '#fff', fontSize: 13, fontWeight: 800, textDecoration: 'none', width: '100%',
                }}
              >
                Pay via PayPal — {p.price}{p.period}
              </a>
            </div>
          ))}
        </div>
        <p style={{ color: C.dim, fontSize: 9.5, textAlign: 'center' }}>
          AIPPIETAX S.A. · NIF A22944987 · Mijas, Málaga
        </p>
      </div>
    </div>
  );
}

// ── Props ─────────────────────────────────────────────────────────────────────
interface Props {
  userId?: string;
  onNavigate?: (tab: string) => void;
}

// ── Main component ────────────────────────────────────────────────────────────
export default function EnterpriseDashboard({ onNavigate }: Props) {
  const subStatus   = useSubscriptionCheck();
  const bootText    = useTypewriter(BOOT_MSG, 18);
  const [agents, setAgents]     = useState(47);
  const [msgs,   setMsgs]       = useState<ChatMsg[]>([]);
  const [input,  setInput]      = useState('');
  const [busy,   setBusy]       = useState(false);
  const [stream, setStream]     = useState(false);
  const [upgrade, setUpgrade]   = useState(false);
  const chatRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const id = setInterval(() => setAgents(v => v + (Math.random() > 0.72 ? 1 : 0)), 4200);
    return () => clearInterval(id);
  }, []);

  useEffect(() => {
    if (chatRef.current) chatRef.current.scrollTop = chatRef.current.scrollHeight;
  }, [msgs, stream]);

  const pickSkill = useCallback(() =>
    SKILL_TREASURY[Math.floor(Math.random() * SKILL_TREASURY.length)], []);

  const handleSend = useCallback(() => {
    const q = input.trim();
    if (!q || busy) return;
    setInput(''); setBusy(true);
    setMsgs(prev => [...prev, { role: 'user', text: q }]);
    setStream(true);
  }, [input, busy]);

  const handleStreamDone = useCallback(() => {
    setStream(false);
    const skill = pickSkill();
    setAgents(v => v + 1);
    const reply =
      `Sub-manager pipeline compiled. Deploying **${skill}** from the AIPPIE skill treasury to node EU-WEST-1.\n\n` +
      `This autonomous agent will now execute your request continuously in the background. ` +
      `All outputs are logged to the secure ledger and synchronised with your payroll matrices. ` +
      `You may instruct additional sub-managers or monitor this deployment in the telemetry feed.`;
    setMsgs(prev => [...prev, { role: 'agent', text: '', skill, streaming: true }]);
    let i = 0;
    const id = setInterval(() => {
      i += 3;
      setMsgs(prev => {
        const c = [...prev];
        const last = { ...c[c.length - 1] };
        last.text = reply.slice(0, i);
        last.streaming = i < reply.length;
        c[c.length - 1] = last;
        return c;
      });
      if (i >= reply.length) { clearInterval(id); setBusy(false); }
    }, 18);
  }, [pickSkill]);

  const onKey = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handleSend(); }
  };

  const isLocked  = subStatus === 'none';
  const isLoading = subStatus === 'loading';

  return (
    <div style={{
      position: 'absolute', inset: 0, background: C.bg, overflow: 'hidden',
      fontFamily: "'Inter', -apple-system, BlinkMacSystemFont, sans-serif",
      display: 'flex', flexDirection: 'column',
    }}>
      <style>{`
        @keyframes ed-pulse  { 0%,100%{box-shadow:0 0 36px rgba(16,185,129,0.25)} 50%{box-shadow:0 0 56px rgba(16,185,129,0.5)} }
        @keyframes ed-fadein { from{opacity:0;transform:translateY(8px)} to{opacity:1;transform:translateY(0)} }
        @keyframes ed-blink  { 0%,49%{opacity:1} 50%,100%{opacity:0} }
        @keyframes ed-ping   { 0%{box-shadow:0 0 0 0 rgba(16,185,129,0.6)} 70%{box-shadow:0 0 0 7px rgba(16,185,129,0)} 100%{box-shadow:0 0 0 0 rgba(16,185,129,0)} }
        @keyframes ed-spin   { to{transform:rotate(360deg)} }
        @keyframes ed-scan   { 0%{top:-2px;opacity:0} 5%{opacity:0.06} 95%{opacity:0.06} 100%{top:100%;opacity:0} }
        * { box-sizing: border-box; }
        ::-webkit-scrollbar { width: 4px; }
        ::-webkit-scrollbar-thumb { background: rgba(16,185,129,0.2); border-radius: 2px; }
        textarea:focus { outline: none; }
      `}</style>

      {/* Scan line */}
      <div style={{ position: 'absolute', inset: 0, pointerEvents: 'none', zIndex: 0, overflow: 'hidden' }}>
        <div style={{
          position: 'absolute', left: 0, right: 0, height: 1,
          background: 'linear-gradient(90deg, transparent, rgba(16,185,129,0.12), transparent)',
          animation: 'ed-scan 4s linear infinite',
        }} />
      </div>

      {/* Top bar */}
      <div style={{
        height: 48, flexShrink: 0, background: C.surface,
        borderBottom: `1px solid ${C.border}`,
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        padding: '0 20px', zIndex: 10,
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 7 }}>
            <div style={{ width: 7, height: 7, borderRadius: '50%', background: C.green, animation: 'ed-ping 2s ease-in-out infinite' }} />
            <span style={{ color: C.green, fontSize: 10, fontWeight: 800, letterSpacing: '0.16em' }}>AIPPIE AI MANAGER</span>
          </div>
          <span style={{ color: C.dim, fontSize: 9 }}>|</span>
          <span style={{ color: C.muted, fontSize: 9, letterSpacing: '0.08em' }}>COMPREHENSIVE WORKFLOW INFRASTRUCTURAL COMMAND</span>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
            <Cpu size={11} color={C.muted} />
            <span style={{ color: C.muted, fontSize: 9 }}>{agents} agents live</span>
          </div>
          {isLoading && <div style={{ width: 14, height: 14, border: `2px solid ${C.border}`, borderTopColor: C.green, borderRadius: '50%', animation: 'ed-spin 0.8s linear infinite' }} />}
        </div>
      </div>

      {/* Body */}
      <div style={{ flex: 1, overflow: 'hidden', display: 'grid', gridTemplateColumns: '35% 65%' }}>

        {/* ── Left sidebar ── */}
        <div style={{
          borderRight: `1px solid ${C.border}`,
          display: 'flex', flexDirection: 'column',
          overflowY: 'auto', padding: '18px 16px', gap: 16,
        }}>
          {/* Header badge */}
          <div style={{
            background: `linear-gradient(135deg, ${C.greenDim}, rgba(0,0,0,0))`,
            border: `1px solid ${C.borderHi}`, borderRadius: 14, padding: '14px 16px',
          }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 4 }}>
              <span style={{ color: C.muted, fontSize: 8, fontWeight: 700, letterSpacing: '0.14em' }}>PRODUCTION CORE UTILITIES</span>
              <div style={{ display: 'flex', alignItems: 'center', gap: 5 }}>
                <div style={{ width: 6, height: 6, borderRadius: '50%', background: C.green, animation: 'ed-ping 1.8s ease-in-out infinite' }} />
                <span style={{ color: C.green, fontSize: 8, fontWeight: 700, letterSpacing: '0.1em' }}>ONLINE</span>
              </div>
            </div>
            <div style={{ color: C.text, fontSize: 11, fontWeight: 700, letterSpacing: '0.04em' }}>MANAGED SYSTEM</div>
          </div>

          {/* Core cards */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            <CoreCard
              icon={Users}
              title="Multi-Jurisdiction Payroll Processing Engine"
              subtitle="ES / NL / US Unified Compliance Ledger · calcAlgemeneHeffingskorting · calcArbeidskorting"
              onClick={() => onNavigate?.('payroll')}
            />
            <CoreCard
              icon={FileText}
              title="Fiscale Invoice Certification Gateway"
              subtitle="Verifactu ES Certified Cryptographic Schema · Automated tax-compliance router"
              onClick={() => onNavigate?.('accounting')}
            />
          </div>

          <div style={{ borderTop: `1px solid ${C.border}` }} />

          {/* Telemetry canvas */}
          <div>
            <div style={{ color: C.muted, fontSize: 8, fontWeight: 700, letterSpacing: '0.14em', marginBottom: 8, display: 'flex', alignItems: 'center', gap: 6 }}>
              <Activity size={9} color={C.green} />
              SYSTEM TELEMETRY PULSE WAVE
            </div>
            <TelemetryCanvas />
          </div>

          {/* Live log */}
          <div>
            <div style={{ color: C.muted, fontSize: 8, fontWeight: 700, letterSpacing: '0.14em', marginBottom: 8, display: 'flex', alignItems: 'center', gap: 6 }}>
              <Terminal size={9} color={C.green} />
              LIVE EVENT STREAM
            </div>
            <TelemetryLog />
          </div>

          {/* Stats grid */}
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
            {[
              { label: 'MODULES', value: '83',     icon: Cpu           },
              { label: 'UPTIME',  value: '99.87%', icon: CheckCircle2  },
              { label: 'REGION',  value: 'EU-W1',  icon: Globe         },
              { label: 'LATENCY', value: '4ms',    icon: Zap           },
            ].map(s => (
              <div key={s.label} style={{
                background: 'rgba(0,0,0,0.4)', border: `1px solid ${C.border}`,
                borderRadius: 9, padding: '9px 11px', display: 'flex', gap: 8, alignItems: 'center',
              }}>
                <s.icon size={12} color={C.green} />
                <div>
                  <div style={{ color: C.text, fontSize: 12, fontWeight: 800 }}>{s.value}</div>
                  <div style={{ color: C.muted, fontSize: 8, letterSpacing: '0.1em' }}>{s.label}</div>
                </div>
              </div>
            ))}
          </div>

          {/* Security badges */}
          <div style={{
            background: 'rgba(0,0,0,0.3)', border: `1px solid ${C.border}`,
            borderRadius: 10, padding: '10px 14px',
            display: 'flex', flexWrap: 'wrap', gap: '6px 14px',
          }}>
            {['AES-256','GDPR','HIPAA','ISO 27001'].map(b => (
              <div key={b} style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
                <Shield size={8} color={C.green} />
                <span style={{ color: C.green, fontSize: 8, fontWeight: 700, letterSpacing: '0.1em' }}>{b}</span>
              </div>
            ))}
          </div>
        </div>

        {/* ── Main panel ── */}
        <div style={{ display: 'flex', flexDirection: 'column', overflow: 'hidden', position: 'relative' }}>

          {/* KPI strip */}
          <div style={{ padding: '16px 20px 0', flexShrink: 0 }}>
            <KPIStrip agents={agents} />
          </div>

          {/* Boot message */}
          <div style={{
            margin: '0 20px 14px', flexShrink: 0,
            background: `linear-gradient(135deg, rgba(16,185,129,0.05), rgba(0,0,0,0))`,
            border: `1px solid ${C.border}`, borderRadius: 12, padding: '14px 18px',
          }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8 }}>
              <BarChart3 size={13} color={C.green} />
              <span style={{ color: C.green, fontSize: 9, fontWeight: 700, letterSpacing: '0.14em' }}>
                AUTONOMOUS SYSTEM BOOT LOG
              </span>
            </div>
            <p style={{
              color: C.text, fontSize: 11.5, lineHeight: 1.8, margin: 0,
              fontFamily: "'JetBrains Mono', monospace",
            }}>
              {bootText}
              <span style={{
                display: 'inline-block', width: 2, height: '1em',
                background: C.green, marginLeft: 2, verticalAlign: 'text-bottom',
                animation: 'ed-blink 1s ease-in-out infinite',
              }} />
            </p>
          </div>

          {/* Chat feed */}
          <div ref={chatRef} style={{ flex: 1, overflowY: 'auto', padding: '0 20px', display: 'flex', flexDirection: 'column', gap: 12 }}>
            {stream && <CodeStream onDone={handleStreamDone} />}

            {msgs.map((m, i) => (
              <div key={i} style={{ display: 'flex', justifyContent: m.role === 'user' ? 'flex-end' : 'flex-start', animation: 'ed-fadein 0.3s ease' }}>
                {m.role === 'agent' && (
                  <div style={{
                    width: 26, height: 26, borderRadius: '50%', flexShrink: 0,
                    marginRight: 10, marginTop: 2,
                    background: C.greenDim, border: `1px solid ${C.borderHi}`,
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                  }}>
                    <Cpu size={12} color={C.green} />
                  </div>
                )}
                <div style={{
                  maxWidth: '80%',
                  background: m.role === 'user' ? 'rgba(59,130,246,0.12)' : C.greenDim,
                  border: `1px solid ${m.role === 'user' ? 'rgba(59,130,246,0.25)' : C.border}`,
                  borderRadius: m.role === 'user' ? '14px 14px 4px 14px' : '14px 14px 14px 4px',
                  padding: '11px 15px',
                }}>
                  {m.skill && (
                    <div style={{
                      display: 'inline-flex', alignItems: 'center', gap: 5,
                      background: 'rgba(16,185,129,0.15)', border: `1px solid ${C.borderHi}`,
                      borderRadius: 6, padding: '3px 8px', marginBottom: 7,
                    }}>
                      <Zap size={9} color={C.green} />
                      <span style={{ color: C.green, fontSize: 9, fontWeight: 700, letterSpacing: '0.08em' }}>
                        {m.skill} DEPLOYED
                      </span>
                    </div>
                  )}
                  <p style={{
                    color: C.text, lineHeight: 1.75, margin: 0, whiteSpace: 'pre-wrap',
                    fontFamily: m.role === 'agent' ? "'JetBrains Mono', monospace" : 'inherit',
                    fontSize: m.role === 'agent' ? 11 : 12,
                  }}>
                    {m.text}
                    {m.streaming && (
                      <span style={{
                        display: 'inline-block', width: 2, height: '1em',
                        background: C.green, marginLeft: 2, verticalAlign: 'text-bottom',
                        animation: 'ed-blink 0.6s ease-in-out infinite',
                      }} />
                    )}
                  </p>
                </div>
              </div>
            ))}

            {msgs.length === 0 && !stream && (
              <div style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '24px 0' }}>
                <div style={{ textAlign: 'center' }}>
                  <div style={{
                    width: 52, height: 52, borderRadius: '50%',
                    background: C.greenDim, border: `1px solid ${C.borderHi}`,
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                    margin: '0 auto 14px', animation: 'ed-pulse 2.5s ease-in-out infinite',
                  }}>
                    <Terminal size={22} color={C.green} strokeWidth={1.5} />
                  </div>
                  <div style={{ color: C.muted, fontSize: 11, lineHeight: 1.6, maxWidth: 320 }}>
                    Instruct the AI Manager to deploy a sub-manager,<br />
                    run a compliance audit, or build a custom pipeline.
                  </div>
                  <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8, marginTop: 16, justifyContent: 'center' }}>
                    {['Deploy logistics scanner', 'Run payroll audit ES', 'Generate Verifactu batch', 'Spawn contract compliance engine'].map(s => (
                      <button
                        key={s}
                        onClick={() => setInput(s)}
                        style={{
                          background: 'rgba(0,0,0,0.4)', border: `1px solid ${C.border}`,
                          borderRadius: 20, padding: '5px 12px',
                          color: C.muted, fontSize: 10, cursor: 'pointer',
                          transition: 'border-color 0.2s, color 0.2s',
                        }}
                        onMouseEnter={e => { e.currentTarget.style.borderColor = C.green; e.currentTarget.style.color = C.green; }}
                        onMouseLeave={e => { e.currentTarget.style.borderColor = C.border; e.currentTarget.style.color = C.muted; }}
                      >
                        {s}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Command input */}
          <div style={{
            flexShrink: 0, padding: '14px 20px 16px',
            borderTop: `1px solid ${C.border}`, background: C.surface,
          }}>
            <div style={{
              display: 'flex', gap: 10, alignItems: 'flex-end',
              background: 'rgba(0,0,0,0.5)', border: `1px solid ${busy ? C.borderHi : C.border}`,
              borderRadius: 12, padding: '10px 14px', transition: 'border-color 0.2s',
            }}>
              <Terminal size={14} color={C.muted} style={{ flexShrink: 0, marginBottom: 3 }} />
              <textarea
                value={input}
                onChange={e => setInput(e.target.value)}
                onKeyDown={onKey}
                disabled={busy}
                placeholder="Execute Meta-Infrastructure Command / Deploy Automated Sub-Manager Pipeline..."
                rows={1}
                style={{
                  flex: 1, background: 'transparent', border: 'none', resize: 'none',
                  color: C.text, fontSize: 12, fontFamily: 'inherit', lineHeight: 1.5,
                }}
              />
              <button
                onClick={handleSend}
                disabled={!input.trim() || busy}
                style={{
                  flexShrink: 0,
                  background: input.trim() && !busy ? `linear-gradient(135deg, ${C.green}, #059669)` : C.greenDim,
                  border: `1px solid ${input.trim() && !busy ? C.green : C.border}`,
                  borderRadius: 8, padding: '7px 16px',
                  color: input.trim() && !busy ? '#000' : C.muted,
                  fontSize: 11, fontWeight: 800,
                  cursor: input.trim() && !busy ? 'pointer' : 'default',
                  letterSpacing: '0.08em', transition: 'all 0.2s',
                  display: 'flex', alignItems: 'center', gap: 6,
                }}
              >
                {busy
                  ? <div style={{ width: 12, height: 12, border: `2px solid ${C.muted}`, borderTopColor: C.green, borderRadius: '50%', animation: 'ed-spin 0.7s linear infinite' }} />
                  : <>EXECUTE <ChevronRight size={11} /></>
                }
              </button>
            </div>
            <div style={{ color: C.dim, fontSize: 9, marginTop: 7, display: 'flex', alignItems: 'center', gap: 5 }}>
              <AlertTriangle size={8} color={C.dim} />
              AIPPIE AI Manager · 83-Module Skill Treasury · EU-WEST-1 · Enter to execute
            </div>
          </div>

          {/* Paywall */}
          {isLocked && (
            <div style={{ position: 'absolute', inset: 0 }}>
              <PaywallOverlay onUpgrade={() => setUpgrade(true)} />
            </div>
          )}
        </div>
      </div>

      {upgrade && <UpgradeModal onClose={() => setUpgrade(false)} />}
    </div>
  );
}
