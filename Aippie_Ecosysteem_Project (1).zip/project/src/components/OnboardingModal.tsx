import { useCallback, useEffect, useRef, useState } from 'react';
import { ShieldCheck, Mic, TrendingUp, Hand, CheckCircle } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { LANGUAGES, t, storeLang, type LangCode } from '../lib/i18n';
import { applyPremiumVoice, normalizeForTTS } from '../lib/ttsVoice';

// ── Types ─────────────────────────────────────────────────────────────────────
export type OnboardingTokens = {
  voiceToken: boolean;
  tradingToken: boolean;
  freeSilentVoice: boolean;
};

type Props = {
  onComplete: (lang: LangCode, tokens: OnboardingTokens) => void;
};

// ── Exact hardcoded speech scripts ────────────────────────────────────────────
const SPEECH_SCRIPTS: Partial<Record<LangCode, string>> = {
  en: "I am your personal assistant, Aippie. I have unlocked the ecosystem for you. Tap below to instantly activate your choice: Tab 1 for AippieVoice, my 24/7 live translation gateway for only 14.99 a month. Tab 5 for Trading Alpha, my elite AI stock market matrix with live charts and 85% plus accuracy for 99.99 a month. And an important notice: For children who cannot speak, my Silent Voice hand-gesture assistant is 100% free for eternal family use. Tap to start talking to me now!",
  nl: "Ik ben jouw persoonlijke assistent, Aippie. Ik heb het ecosysteem voor je ontgrendeld. Tik hieronder om direct jouw keuze te activeren: Tabblad 1 voor AippieVoice, mijn 24/7 live vertaal-gateway voor slechts veertien euro negenennegentig per maand. Tabblad 5 voor Trading Alpha, mijn elite AI-aandelenmatrix met live grafieken en 85% plus nauwkeurigheid voor negenennegentig euro negenennegentig per maand. En een belangrijke mededeling: Voor kinderen die niet kunnen spreken, is mijn Silent Voice handgebaren-assistent 100% gratis voor eeuwig gezinsgebruik. Tik om te starten!",
  de: "Ich bin dein persönlicher Assistent, Aippie. Ich habe das Ökosystem für dich freigeschaltet. Tippe unten, um deine Wahl sofort zu aktivieren: Tab 1 für AippieVoice, mein 24/7 Live-Übersetzungsgateway für nur 14,99 pro Monat. Tab 5 für Trading Alpha, meine Elite-KI-Aktienmatrix mit Live-Charts und über 85 Prozent Genauigkeit für 99,99 pro Monat. Und ein wichtiger Hinweis: Für Kinder, die nicht sprechen können, ist mein Silent Voice Handgestenassistent 100 Prozent kostenlos für den ewigen Familiengebrauch. Tippe jetzt, um mit mir zu sprechen!",
  fr: "Je suis votre assistant personnel, Aippie. J'ai déverrouillé l'écosystème pour vous. Appuyez ci-dessous pour activer instantanément votre choix: Onglet 1 pour AippieVoice, ma passerelle de traduction en direct 24h sur 24 pour seulement 14,99 par mois. Onglet 5 pour Trading Alpha, ma matrice boursière IA d'élite avec des graphiques en direct et une précision de plus de 85 pourcent pour 99,99 par mois. Et une notice importante: Pour les enfants qui ne peuvent pas parler, mon assistant de gestes Silent Voice est 100 pourcent gratuit pour un usage familial éternel. Appuyez pour commencer à me parler maintenant!",
  sv: "Jag är din personliga assistent, Aippie. Jag har låst upp ekosystemet för dig. Tryck nedan för att omedelbart aktivera ditt val: Flik 1 för AippieVoice, min dygnet-runt direktöversättningsgateway för bara 14,99 per månad. Flik 5 för Trading Alpha, min elit AI-aktieportfölj med live-diagram och 85 procents noggrannhet för 99,99 per månad. Och ett viktigt meddelande: För barn som inte kan tala är min Silent Voice handgestsassistent 100 procent gratis för evig familjebruk. Tryck för att börja prata med mig nu!",
};

// ── Device key ────────────────────────────────────────────────────────────────
function getOrCreateDeviceKey(): string {
  let key = localStorage.getItem('aippie_device_key');
  if (!key) { key = crypto.randomUUID(); localStorage.setItem('aippie_device_key', key); }
  return key;
}

// ── 28-bar waveform ───────────────────────────────────────────────────────────
function Waveform({ active }: { active: boolean }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const frameRef  = useRef<number>(0);
  const tickRef   = useRef(0);
  const BARS = 28;

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const draw = () => {
      tickRef.current++;
      const tk = tickRef.current;
      const W = canvas.width, H = canvas.height;
      ctx.clearRect(0, 0, W, H);
      const gap = W / BARS, barW = Math.max(2, gap - 2);
      for (let i = 0; i < BARS; i++) {
        const phase = (i / BARS) * Math.PI * 2;
        const rawH = active
          ? (0.22 + 0.78 * Math.abs(Math.sin(tk * 0.048 + phase))) * H
          : 4;
        const x = i * gap + (gap - barW) / 2, y = (H - rawH) / 2;
        const grad = ctx.createLinearGradient(0, y, 0, y + rawH);
        grad.addColorStop(0,   'rgba(56,189,248,0.95)');
        grad.addColorStop(0.5, 'rgba(14,165,233,0.75)');
        grad.addColorStop(1,   'rgba(2,132,199,0.45)');
        ctx.fillStyle = grad;
        ctx.beginPath(); ctx.roundRect(x, y, barW, rawH, Math.min(barW/2,3)); ctx.fill();
      }
      frameRef.current = requestAnimationFrame(draw);
    };
    frameRef.current = requestAnimationFrame(draw);
    return () => cancelAnimationFrame(frameRef.current);
  }, [active]);

  return <canvas ref={canvasRef} width={290} height={50} className="ob-waveform" aria-hidden="true"/>;
}

// ── Word-sync subtitle hook ───────────────────────────────────────────────────
function useWordSubtitle(text: string, active: boolean): string {
  const [subtitle, setSubtitle] = useState('');
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const idxRef   = useRef(0);

  useEffect(() => {
    if (timerRef.current) clearInterval(timerRef.current);
    if (!active || !text) { setSubtitle(''); return; }

    const words = text.split(' ');
    idxRef.current = 0;
    setSubtitle('');

    timerRef.current = setInterval(() => {
      idxRef.current++;
      // Show a rolling window of the last 10 words as subtitle
      const start = Math.max(0, idxRef.current - 10);
      setSubtitle(words.slice(start, idxRef.current).join(' '));
      if (idxRef.current >= words.length) {
        if (timerRef.current) clearInterval(timerRef.current);
      }
    }, 460);

    return () => { if (timerRef.current) clearInterval(timerRef.current); };
  }, [text, active]);

  return subtitle;
}

// ── Main Modal ────────────────────────────────────────────────────────────────
export default function OnboardingModal({ onComplete }: Props) {
  const [lang, setLang]           = useState<LangCode>('en');
  const [typed, setTyped]         = useState('');
  const [scriptDone, setScriptDone] = useState(false);
  const [voiceActivated,   setVoiceActivated]   = useState(false);
  const [tradingActivated, setTradingActivated] = useState(false);
  const [silentActivated,  setSilentActivated]  = useState(false);
  const [submitting, setSubmitting] = useState<'voice'|'trading'|'silent'|'start'|null>(null);
  const [speaking, setSpeaking]   = useState(false);

  const typingRef  = useRef<ReturnType<typeof setInterval> | null>(null);
  const idxRef     = useRef(0);

  const currentScript = SPEECH_SCRIPTS[lang] ?? SPEECH_SCRIPTS['en'] ?? '';
  const subtitle = useWordSubtitle(currentScript, speaking);

  const startTypewriter = useCallback((script: string) => {
    if (typingRef.current) clearInterval(typingRef.current);
    setTyped(''); setScriptDone(false); idxRef.current = 0;
    typingRef.current = setInterval(() => {
      idxRef.current++;
      setTyped(script.slice(0, idxRef.current));
      if (idxRef.current >= script.length) {
        if (typingRef.current) clearInterval(typingRef.current);
        setScriptDone(true);
      }
    }, 14);
  }, []);

  const speakScript = useCallback((l: LangCode) => {
    if (!('speechSynthesis' in window)) return;
    window.speechSynthesis.cancel();
    const text = SPEECH_SCRIPTS[l] ?? SPEECH_SCRIPTS['en'] ?? '';
    const u = new SpeechSynthesisUtterance(normalizeForTTS(text));
    const langTag = l === 'nl' ? 'nl-NL' : l === 'de' ? 'de-DE' : l === 'fr' ? 'fr-FR' : l === 'sv' ? 'sv-SE' : 'en-US';
    u.lang = langTag;
    u.rate = 0.91; u.pitch = 1.0;
    applyPremiumVoice(u, langTag);
    u.onstart = () => setSpeaking(true);
    u.onend   = () => setSpeaking(false);
    u.onerror  = () => setSpeaking(false);
    window.speechSynthesis.speak(u);
    setSpeaking(true);
  }, []);

  useEffect(() => {
    const script = SPEECH_SCRIPTS['en'] ?? '';
    const delay = setTimeout(() => {
      startTypewriter(script);
      speakScript('en');
    }, 700);
    return () => {
      clearTimeout(delay);
      if (typingRef.current) clearInterval(typingRef.current);
      window.speechSynthesis?.cancel();
    };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleLangSelect = useCallback((code: LangCode) => {
    setLang(code);
    const script = SPEECH_SCRIPTS[code] ?? SPEECH_SCRIPTS['en'] ?? '';
    startTypewriter(script);
    speakScript(code);
  }, [startTypewriter, speakScript]);

  const isActive = speaking || !scriptDone;
  const deviceKey = getOrCreateDeviceKey();

  const persistToken = async (patch: Record<string, boolean>) => {
    await supabase
      .from('client_profiles')
      .upsert(
        { device_key: deviceKey, language: lang, onboarded_at: new Date().toISOString(), ...patch },
        { onConflict: 'device_key' }
      );
  };

  const activateVoice = async () => {
    if (voiceActivated || submitting) return;
    setSubmitting('voice');
    await persistToken({ voice_token: true });
    setVoiceActivated(true);
    setSubmitting(null);
  };

  const activateTrading = async () => {
    if (tradingActivated || submitting) return;
    setSubmitting('trading');
    await persistToken({ trading_token: true });
    setTradingActivated(true);
    setSubmitting(null);
  };

  const activateSilent = async () => {
    if (silentActivated || submitting) return;
    setSubmitting('silent');
    await persistToken({ free_silent_voice: true });
    setSilentActivated(true);
    setSubmitting(null);
  };

  const handleStart = async () => {
    if (submitting) return;
    setSubmitting('start');
    window.speechSynthesis?.cancel();
    // Mark onboarded immediately so a page reload never re-shows this modal
    storeLang(lang);
    localStorage.setItem('aippie_onboarded', '1');
    await supabase
      .from('client_profiles')
      .upsert(
        { device_key: deviceKey, language: lang, onboarded_at: new Date().toISOString() },
        { onConflict: 'device_key' }
      );
    setSubmitting(null);
    onComplete(lang, {
      voiceToken: voiceActivated,
      tradingToken: tradingActivated,
      freeSilentVoice: silentActivated,
    });
  };

  const handleSkip = () => {
    window.speechSynthesis?.cancel();
    storeLang(lang);
    localStorage.setItem('aippie_onboarded', '1');
    supabase
      .from('client_profiles')
      .upsert(
        { device_key: deviceKey, language: lang, onboarded_at: new Date().toISOString() },
        { onConflict: 'device_key' }
      );
    onComplete(lang, { voiceToken: false, tradingToken: false, freeSilentVoice: false });
  };

  const strings = t(lang);

  return (
    <div className="ob-backdrop">
      <div className="ob-modal ob-modal--v34">

        {/* Global Onboarding status bar */}
        <div className="ob-v34-statusbar ob-v34-statusbar--global">
          <span className="ob-v34-statusbar__dot"/>
          <span className="ob-v34-statusbar__text">Global Onboarding Active · Aippie Ecosystem v43</span>
        </div>

        {/* Avatar */}
        <div className="ob-avatar-wrap ob-avatar-wrap--v34">
          <img
            src="/Jouw_alineatekst_(2).png"
            alt="Aippie"
            className="ob-avatar"
          />
          <div className="ob-avatar__overlay"/>
          <div className={`ob-avatar__ring ob-avatar__ring--1${isActive?' ob-avatar__ring--pulse':''}`}/>
          <div className={`ob-avatar__ring ob-avatar__ring--2${isActive?' ob-avatar__ring--pulse':''}`}/>
          <div className="ob-avatar__badge">AI Concierge · AIPPIETAX S.A.</div>
        </div>

        {/* Language selector */}
        <div className="ob-lang-bar">
          {LANGUAGES.map(l => (
            <button
              key={l.code}
              className={`ob-lang-btn${lang === l.code ? ' ob-lang-btn--active' : ''}`}
              onClick={() => handleLangSelect(l.code)}
              title={l.label}
              aria-label={l.label}
            >
              <span className="ob-lang-btn__flag">{l.flag}</span>
              <span className="ob-lang-btn__label">{l.label}</span>
            </button>
          ))}
        </div>

        {/* Waveform */}
        <div className="ob-waveform-wrap">
          <Waveform active={isActive}/>
          <div className={`ob-waveform-label${!isActive?' ob-waveform-label--done':''}`}>
            {isActive ? 'Aippie is speaking…' : 'Pitch complete · Choose your plan below'}
          </div>
        </div>

        {/* Live word-sync subtitles — shown while speaking */}
        {speaking && subtitle && (
          <div className="ob-subtitle">
            <span className="ob-subtitle__text">{subtitle}</span>
          </div>
        )}

        {/* Scrolling typewriter text (compact) */}
        <div className="ob-speech ob-speech--v34">
          <span className="ob-speech__text">{typed}</span>
          {!scriptDone && <span className="ob-speech__cursor"/>}
        </div>

        {/* 3-tier activation buttons */}
        <div className="ob-v34-tiers">

          <button
            className={`ob-v34-tier ob-v34-tier--voice${voiceActivated?' ob-v34-tier--done':''}`}
            onClick={activateVoice}
            disabled={!!submitting}
          >
            {submitting === 'voice'
              ? <span className="ob-cta__spinner"/>
              : voiceActivated
                ? <><CheckCircle size={14}/> AippieVoice Activated</>
                : <><Mic size={14}/> ACTIVATE AIPPIEVOICE (€14.99/mo)</>
            }
          </button>

          <button
            className={`ob-v34-tier ob-v34-tier--trading${tradingActivated?' ob-v34-tier--done':''}`}
            onClick={activateTrading}
            disabled={!!submitting}
          >
            {submitting === 'trading'
              ? <span className="ob-cta__spinner"/>
              : tradingActivated
                ? <><CheckCircle size={14}/> Trading Alpha Activated</>
                : <><TrendingUp size={14}/> ACTIVATE TRADING ALPHA (€99.99/mo)</>
            }
          </button>

          <button
            className={`ob-v34-tier ob-v34-tier--silent${silentActivated?' ob-v34-tier--done':' ob-v34-tier--pulse'}`}
            onClick={activateSilent}
            disabled={!!submitting}
          >
            {submitting === 'silent'
              ? <span className="ob-cta__spinner"/>
              : silentActivated
                ? <><CheckCircle size={14}/> Silent Voice Unlocked — Free Forever</>
                : <><Hand size={14}/> ACTIVATE FREE SILENT VOICE FOR CHILDREN (GRATIS)</>
            }
          </button>

        </div>

        {/* Primary CTA */}
        <button
          className="ob-cta ob-cta--v34"
          onClick={handleStart}
          disabled={!!submitting}
        >
          {submitting === 'start'
            ? <span className="ob-cta__spinner"/>
            : '🎙️ TAP TO START TALKING TO AIPPIE'
          }
        </button>

        {/* Skip button */}
        <button
          className="ob-skip-btn"
          onClick={handleSkip}
          disabled={!!submitting}
        >
          Skip intro — enter app directly
        </button>

        <div className="ob-trust">
          <ShieldCheck size={11}/>
          {strings.trustLine}
        </div>
      </div>
    </div>
  );
}
