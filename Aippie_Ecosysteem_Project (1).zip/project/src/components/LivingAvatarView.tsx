import { useEffect, useRef, useState, useCallback } from 'react';
import {
  ShieldCheck, CircleUser as UserCircle2, Mic, Sparkles,
  Mic2, Wifi, Car, Hand, TrendingUp, MessageSquare,
  ChevronDown, ChevronUp, X
} from 'lucide-react';
import { applyPremiumVoice, normalizeForTTS } from '../lib/ttsVoice';
import type { Subscription } from '../lib/supabase';
import { getStoredLang } from '../lib/i18n';
import { useWordSubtitle } from './SofiaTabShell';

// ── (lipsync removed — static avatar image) ──────────────────────────────────

type Props = { subscription: Subscription | null };

// ── Voice response catalogue ──────────────────────────────────────────────────
type AvatarResponse = { trigger: RegExp; reply: Record<string, string>; module?: string };

const RESPONSES: AvatarResponse[] = [
  {
    trigger: /translat|interpret|speak|language|habla|sprech|parle/i,
    module: 'interpreter',
    reply: {
      en: 'Switching you to the Interpreter now. I support English, Dutch, German, French and Swedish corridors.',
      nl: 'Switching you to the Interpreter now. I support English, Dutch, German, French and Swedish corridors.',
      de: 'Ich verbinde dich jetzt mit dem Dolmetscher.',
      fr: "Je vous connecte maintenant à l'interprète.",
      sv: 'Jag kopplar dig till tolken nu.',
    },
  },
  {
    trigger: /wifi|internet|network|connect|hotspot|wi-fi/i,
    module: 'wifi',
    reply: {
      en: 'Opening WiFi Share. You can activate auto-connect or share your own network to start earning five euro cents per gigabyte.',
      nl: 'Opening WiFi Share. You can activate auto-connect or share your own network to start earning five euro cents per gigabyte.',
      de: 'Öffne WiFi Share. Fünf Cent pro Gigabyte verdienen.',
      fr: 'Ouverture de WiFi Share. Cinq centimes par gigaoctet.',
      sv: 'Öppnar WiFi-delning. Fem eurocent per gigabyte.',
    },
  },
  {
    trigger: /park|car|vehicle|spot|stall|place/i,
    module: 'parking',
    reply: {
      en: 'Loading the live parking map for Mijas, Fuengirola and Marbella. Green anchors show available spots right now.',
      nl: 'Loading the live parking map for Mijas, Fuengirola and Marbella. Green anchors show available spots right now.',
      de: 'Lade die Live-Parkkarte für Mijas, Fuengirola und Marbella.',
      fr: 'Chargement de la carte de stationnement en direct.',
      sv: 'Laddar live-parkeringskartan.',
    },
  },
  {
    trigger: /gesture|silent|hand|sign|deaf|mute|medtech/i,
    module: 'silentvoice',
    reply: {
      en: 'Opening Silent Voice. Hold a gesture in front of the camera and I will translate it to speech instantly.',
      nl: 'Opening Silent Voice. Hold a gesture in front of the camera and I will translate it to speech instantly.',
      de: 'Silent Voice öffnen. Geste vor die Kamera halten.',
      fr: 'Ouverture de Silent Voice. Tenez un geste devant la caméra.',
      sv: 'Öppnar Silent Voice. Håll en gest framför kameran.',
    },
  },
  {
    trigger: /trade|stock|invest|market|alpha|crypto|finance|profit|bitcoin|btc|whale|dump/i,
    module: 'trading',
    reply: {
      en: 'Opening Trading Alpha. Live institutional dark pool signals and billionaire copy-trading feeds are active.',
      nl: 'Opening Trading Alpha. Live institutional dark pool signals and billionaire copy-trading feeds are active.',
      de: 'Trading Alpha öffnen. Institutionelle Dark Pool Signale aktiv.',
      fr: 'Ouverture de Trading Alpha. Signaux dark pool actifs.',
      sv: 'Öppnar Trading Alpha. Dark pool-signaler aktiva.',
    },
  },
  {
    trigger: /school|academy|bga|brave|laude|san pedro|educati/i,
    module: 'relocation',
    reply: {
      en: 'Brave Generation Academy in Fuengirola offers the IB curriculum from age 3 to 18. Laude San Pedro International College in Marbella delivers British A-levels and Cambridge IGCSE. Both accept rolling admissions from February.',
      nl: 'Brave Generation Academy in Fuengirola offers the IB curriculum from age 3 to 18. Laude San Pedro International College in Marbella delivers British A-levels and Cambridge IGCSE. Both accept rolling admissions from February.',
    },
  },
  {
    trigger: /gas|fuel|petrol|benzin|station/i,
    module: 'parking',
    reply: {
      en: 'The nearest fuel station on the Costa del Sol is displayed on the parking map. Green anchors near the N-340 show available spots and fuel prices in real time.',
      nl: 'The nearest fuel station on the Costa del Sol is displayed on the parking map. Green anchors near the N-340 show available spots and fuel prices in real time.',
    },
  },
  {
    trigger: /help|wat|what|hoe|wie|comment|vad|hur/i,
    reply: {
      en: 'I am Aippie, your AI concierge. I can interpret languages, find parking, share WiFi, translate gestures, and guide your trading. Just talk to me.',
      nl: 'I am Aippie, your AI concierge. I can interpret languages, find parking, share WiFi, translate gestures, and guide your trading. Just talk to me.',
      de: 'Ich bin Aippie, Ihr KI-Concierge.',
      fr: 'Je suis Aippie, votre concierge IA.',
      sv: 'Jag är Aippie, din AI-concierge.',
    },
  },
];

// ── Concierge drawer data ─────────────────────────────────────────────────────
type ConciergeItem = { label: string; detail: string; url?: string };
const CONCIERGE_DRAWERS: Record<string, { title: string; items: ConciergeItem[] }> = {
  relocation: {
    title: 'Education — Costa del Sol',
    items: [
      { label: 'Brave Generation Academy (BGA)', detail: 'IB curriculum · Ages 3–18 · Fuengirola', url: 'https://www.bravegenerationacademy.com' },
      { label: 'Laude San Pedro International', detail: 'British A-levels · Cambridge IGCSE · Marbella' },
      { label: 'NIE Application', detail: 'EX-15 form · Comisaría or consulate · Passport required' },
      { label: 'Arras Contract', detail: '10% deposit · Notary signature · Gestoria recommended' },
    ],
  },
  parking: {
    title: 'Live Parking — Costa del Sol',
    items: [
      { label: 'Mijas Centro', detail: 'Green anchors · 14 spots available · Updated 2 min ago' },
      { label: 'Fuengirola Paseo', detail: 'Yellow anchor · 3 spots · Rush hour active' },
      { label: 'Marbella Puerto Banús', detail: 'Red anchor · Full · Redirect to Calle Ramón y Cajal' },
      { label: 'N-340 Fuel Station', detail: 'BP · Diesel €1.62 · Unleaded €1.58 · Open 24h' },
    ],
  },
  trading: {
    title: 'Trading Alpha — Live Alerts',
    items: [
      { label: 'BTC Whale Alert', detail: '18,400 BTC moved · Dark pool · Possible accumulation' },
      { label: 'NVDA Signal', detail: 'BUY · 89% probability · Dark pool block $280M · Entry $487' },
      { label: 'Pelosi Portfolio', detail: 'Call options $NVDA · Strike $500 · Dec 2025' },
      { label: 'Buffett Alpha', detail: '12.4M shares AAPL added · Avg $181.20' },
    ],
  },
  interpreter: {
    title: 'Interpreter Gateway',
    items: [
      { label: 'English ⇄ Dutch', detail: '142 certified translators online · Avg connect: 8s' },
      { label: 'English ⇄ German', detail: '97 translators online · Medical / Legal available' },
      { label: 'English ⇄ Spanish', detail: 'Emergency AI fallback · 99.8% uptime' },
      { label: 'Emergency AI Mode', detail: '15-second failover · WebRTC bridge active' },
    ],
  },
  wifi: {
    title: 'WiFi Share Network',
    items: [
      { label: 'Auto-connect', detail: 'Join the nearest Aippie mesh node instantly' },
      { label: 'Earnings', detail: '€0.03/GB to you · €0.02/GB to AIPPIETAX S.A.' },
      { label: 'WireGuard VPN', detail: 'Isolated tunnel · Zero-log · AES-256 encrypted' },
      { label: 'Active nodes nearby', detail: '7 nodes · Best signal: 94% · Fuengirola Centro' },
    ],
  },
  silentvoice: {
    title: 'Silent Voice Gestures',
    items: [
      { label: 'I am thirsty', detail: 'Open palm + curl gesture · Fires TTS immediately' },
      { label: 'I need medication', detail: 'Index point up · Emergency priority · Logs to DB' },
      { label: 'OK Sign', detail: 'Thumb + index circle · Acknowledges last message' },
      { label: 'Emergency assistance', detail: 'Closed fist raised · Triggers alert + TTS' },
    ],
  },
};

const IDLE_PHRASES: Record<string, string[]> = {
  en: [
    'Hello! I am your Aippie Living Avatar. I can speak, react, and guide you in real time.',
    'Ask me anything — I am connected to all five Aippie modules.',
    'Need an interpreter? Just say the word. I will connect you instantly.',
    'I adapt to your language and context automatically. Just talk to me.',
  ],
  nl: [
    'Hello! I am your Aippie Living Avatar. I can speak, react, and guide you in real time.',
    'Ask me anything — I am connected to all five Aippie modules.',
    'Need an interpreter? Just say the word. I will connect you instantly.',
    'I adapt to your language and context automatically. Just talk to me.',
  ],
  de: [
    'Hallo! Ich bin Ihr Aippie Living Avatar. Ich kann sprechen, reagieren und Sie führen.',
    'Fragen Sie mich alles — ich bin mit allen fünf Aippie-Modulen verbunden.',
    'Brauchen Sie einen Dolmetscher? Ich verbinde Sie sofort.',
    'Ich passe mich automatisch Ihrer Sprache an.',
  ],
  fr: [
    'Bonjour ! Je suis votre avatar vivant Aippie. Je peux parler, réagir et vous guider.',
    "Posez-moi n'importe quelle question — je suis connecté aux cinq modules Aippie.",
    "Besoin d'un interprète ? Je vous connecterai instantanément.",
    'Je m\'adapte automatiquement à votre langue.',
  ],
  sv: [
    'Hej! Jag är din Aippie Living Avatar. Jag kan tala, reagera och guida dig i realtid.',
    'Fråga mig vad som helst — jag är kopplad till alla fem Aippie-moduler.',
    'Behöver du en tolk? Jag kopplar dig omedelbart.',
    'Jag anpassar mig automatiskt till ditt språk.',
  ],
};

const MODULE_ICONS: Record<string, React.ReactNode> = {
  interpreter: <Mic2 size={12}/>,
  wifi:        <Wifi size={12}/>,
  parking:     <Car size={12}/>,
  silentvoice: <Hand size={12}/>,
  trading:     <TrendingUp size={12}/>,
  relocation:  <Mic size={12}/>,
};

const MODULE_LABELS: Record<string, string> = {
  interpreter: 'Interpreter',
  wifi:        'WiFi Share',
  parking:     'Parking Map',
  silentvoice: 'Silent Voice',
  trading:     'Trading Alpha',
  relocation:  'Relocation',
};

// ── 28-bar waveform ───────────────────────────────────────────────────────────
function Waveform({ active, color = 'amber' }: { active: boolean; color?: 'amber' | 'sky' | 'emerald' }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const frameRef  = useRef<number>(0);
  const tickRef   = useRef(0);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    const BARS = 28;
    const draw = () => {
      tickRef.current++;
      const tk = tickRef.current;
      const W = canvas.width, H = canvas.height;
      ctx.clearRect(0, 0, W, H);
      const gap = W / BARS, barW = Math.max(2, gap - 2);
      for (let i = 0; i < BARS; i++) {
        const phase = (i / BARS) * Math.PI * 2;
        const rawH = active ? (0.18 + 0.82 * Math.abs(Math.sin(tk * 0.055 + phase))) * H : 4;
        const x = i * gap + (gap - barW) / 2, y = (H - rawH) / 2;
        const grad = ctx.createLinearGradient(0, y, 0, y + rawH);
        if (color === 'amber') {
          grad.addColorStop(0,   'rgba(251,191,36,0.95)');
          grad.addColorStop(0.5, 'rgba(245,158,11,0.75)');
          grad.addColorStop(1,   'rgba(217,119,6,0.4)');
        } else if (color === 'emerald') {
          grad.addColorStop(0,   'rgba(74,222,128,0.95)');
          grad.addColorStop(0.5, 'rgba(34,197,94,0.75)');
          grad.addColorStop(1,   'rgba(22,163,74,0.4)');
        } else {
          grad.addColorStop(0,   'rgba(56,189,248,0.95)');
          grad.addColorStop(0.5, 'rgba(14,165,233,0.75)');
          grad.addColorStop(1,   'rgba(2,132,199,0.4)');
        }
        ctx.fillStyle = grad;
        ctx.beginPath(); ctx.roundRect(x, y, barW, rawH, Math.min(barW/2,4)); ctx.fill();
      }
      frameRef.current = requestAnimationFrame(draw);
    };
    frameRef.current = requestAnimationFrame(draw);
    return () => cancelAnimationFrame(frameRef.current);
  }, [active, color]);

  return <canvas ref={canvasRef} width={300} height={52} className="la-waveform" aria-hidden="true"/>;
}

// ── Chat entry type ───────────────────────────────────────────────────────────
type ChatEntry = { role: 'user' | 'aippie'; text: string; module?: string; ts: number };

// ── Concierge drawer component — mounts below avatar without routing ──────────
function ConciergeDrawer({ moduleKey, onClose }: { moduleKey: string; onClose: () => void }) {
  const data = CONCIERGE_DRAWERS[moduleKey];
  if (!data) return null;
  return (
    <div className="la-concierge-drawer">
      <div className="la-concierge-drawer__header">
        <div className="la-concierge-drawer__title">
          {MODULE_ICONS[moduleKey]}
          <span>{data.title}</span>
        </div>
        <button className="la-concierge-drawer__close" onClick={onClose}><X size={13}/></button>
      </div>
      <div className="la-concierge-drawer__list">
        {data.items.map((item, i) => (
          <div key={i} className="la-concierge-item">
            <div className="la-concierge-item__label">{item.label}</div>
            <div className="la-concierge-item__detail">{item.detail}</div>
            {item.url && (
              <a className="la-concierge-item__link" href={item.url} target="_blank" rel="noopener noreferrer">
                Open website
              </a>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}

// ── Main LivingAvatarView ─────────────────────────────────────────────────────
export default function LivingAvatarView({ subscription: _subscription }: Props) {
  const lang = getStoredLang();
  const phrases = IDLE_PHRASES[lang] ?? IDLE_PHRASES['en'];

  const [listening, setListening]   = useState(false);
  const [speaking, setSpeaking]     = useState(false);
  const [phraseIdx, setPhraseIdx]   = useState(0);
  const [typed, setTyped]           = useState('');
  const [typing, setTyping]         = useState(false);
  const [chat, setChat]             = useState<ChatEntry[]>([]);
  const [activeModule, setActiveModule] = useState<string | null>(null);
  const [holdSecs, setHoldSecs]     = useState(0);
  const [currentSpeechText, setCurrentSpeechText] = useState('');
  const [drawerOpen, setDrawerOpen] = useState(false);

  const holdTimer   = useRef<ReturnType<typeof setTimeout>|null>(null);
  const holdCounter = useRef<ReturnType<typeof setInterval>|null>(null);
  const typingRef   = useRef<ReturnType<typeof setInterval>|null>(null);
  const idxRef      = useRef(0);
  const chatEndRef  = useRef<HTMLDivElement>(null);

  // Word-sync subtitle hook — imported from SofiaTabShell, 130 wpm
  const subtitle = useWordSubtitle(currentSpeechText, speaking);

  // Portrait lock: any speech or listen activity freezes navigation and takes full visual precedence
  const locked = speaking || listening;

  const startTypewriter = useCallback((phrase: string, onDone?: () => void) => {
    if (typingRef.current) clearInterval(typingRef.current);
    setTyped('');
    idxRef.current = 0;
    setTyping(true);
    typingRef.current = setInterval(() => {
      idxRef.current++;
      setTyped(phrase.slice(0, idxRef.current));
      if (idxRef.current >= phrase.length) {
        if (typingRef.current) clearInterval(typingRef.current);
        setTyping(false);
        onDone?.();
      }
    }, 22);
  }, []);

  useEffect(() => {
    startTypewriter(phrases[0]);
    return () => { if (typingRef.current) clearInterval(typingRef.current); };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [chat]);

  const processVoiceInput = useCallback(() => {
    const simulatedQueries: Record<string, string[]> = {
      en: ['Can you help me find parking?', 'I need a translator please', 'Tell me about WiFi sharing', 'What are your trading signals?', 'Silent voice gesture help', 'Tell me about Brave Generation Academy', 'Where is the nearest gas station?', 'Bitcoin whale alert?'],
      nl: ['Kun je me helpen parkeren te vinden?', 'Ik heb een tolk nodig', 'Vertel me over WiFi delen', 'Wat zijn uw handelssignalen?', 'Stille stem gebaar hulp', 'Vertel me over Brave Generation Academy'],
      de: ['Kannst du mir helfen einen Parkplatz zu finden?', 'Ich brauche einen Dolmetscher', 'WiFi teilen erklärt', 'Handelssignale bitte', 'Stille Stimme Geste Hilfe'],
      fr: ["Pouvez-vous m'aider à trouver un parking?", "J'ai besoin d'un interprète", 'Parlez-moi du partage WiFi', 'Signaux de trading?'],
      sv: ['Kan du hjälpa mig hitta parkering?', 'Jag behöver en tolk', 'Berätta om WiFi-delning', 'Handelssignaler?'],
    };

    const queries = simulatedQueries[lang] ?? simulatedQueries['en'];
    const query = queries[Math.floor(Math.random() * queries.length)];
    setChat(prev => [...prev, { role: 'user', text: query, ts: Date.now() }]);

    const matched = RESPONSES.find(r => r.trigger.test(query));
    const replyText = matched
      ? (matched.reply[lang] ?? matched.reply['en'])
      : (lang === 'nl' ? 'I understand. Tell me more so I can help you further.'
        : lang === 'de' ? 'Ich verstehe. Bitte erzähl mir mehr.'
        : lang === 'fr' ? "Je comprends. Dites-m'en plus."
        : lang === 'sv' ? 'Jag förstår. Berätta mer.'
        : 'I understand. Tell me more so I can help you further.');

    setTimeout(() => {
      // Set speech text first so subtitle hook fires in sync with synthesis
      setCurrentSpeechText(replyText);
      setSpeaking(true);
      startTypewriter(replyText, () => setSpeaking(false));

      setChat(prev => [...prev, { role: 'aippie', text: replyText, module: matched?.module, ts: Date.now() }]);

      if (matched?.module) {
        setActiveModule(matched.module);
        setDrawerOpen(true);
      }

      if ('speechSynthesis' in window) {
        window.speechSynthesis.cancel();
        const u = new SpeechSynthesisUtterance(normalizeForTTS(replyText));
        const langTag = lang === 'nl' ? 'nl-NL' : lang === 'de' ? 'de-DE' : lang === 'fr' ? 'fr-FR' : lang === 'sv' ? 'sv-SE' : 'en-US';
        u.lang  = langTag;
        u.rate  = 0.92;
        u.pitch = 1.05;
        applyPremiumVoice(u, langTag);
        u.onend   = () => setSpeaking(false);
        u.onerror = () => setSpeaking(false);
        window.speechSynthesis.speak(u);
      }
    }, 600);
  }, [lang, startTypewriter]);

  const startListening = useCallback(() => {
    setListening(true);
    setHoldSecs(0);
    holdCounter.current = setInterval(() => setHoldSecs(s => s + 1), 1000);
    holdTimer.current = setTimeout(() => {
      setListening(false);
      if (holdCounter.current) clearInterval(holdCounter.current);
      processVoiceInput();
    }, 3000);
  }, [processVoiceInput]);

  const stopListening = useCallback(() => {
    if (!listening) return;
    setListening(false);
    setHoldSecs(0);
    if (holdTimer.current) clearTimeout(holdTimer.current);
    if (holdCounter.current) clearInterval(holdCounter.current);
    if (holdSecs >= 1) processVoiceInput();
    else {
      const next = (phraseIdx + 1) % phrases.length;
      setPhraseIdx(next);
      startTypewriter(phrases[next]);
    }
  }, [listening, holdSecs, phraseIdx, phrases, startTypewriter, processVoiceInput]);

  useEffect(() => () => {
    if (holdTimer.current) clearTimeout(holdTimer.current);
    if (holdCounter.current) clearInterval(holdCounter.current);
    if (typingRef.current) clearInterval(typingRef.current);
    window.speechSynthesis?.cancel();
  }, []);

  // Particle canvas
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const pFrameRef = useRef<number>(0);
  const pTickRef  = useRef(0);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    const W = canvas.width, H = canvas.height, cx = W/2, cy = H/2, DOTS = 56;

    const draw = () => {
      pTickRef.current++;
      const tk = pTickRef.current;
      ctx.clearRect(0,0,W,H);
      for (let i=0;i<DOTS;i++) {
        const angle = (i/DOTS)*Math.PI*2 + tk*0.008;
        const r = 116 + Math.sin(tk*0.035 + i*0.28)*14;
        const x = cx + Math.cos(angle)*r, y = cy + Math.sin(angle)*r;
        const alpha = 0.25 + 0.55*Math.abs(Math.sin(tk*0.055+i));
        const size  = 1.2 + Math.abs(Math.sin(tk*0.045+i))*2.2;
        ctx.fillStyle = `rgba(251,191,36,${alpha})`;
        ctx.beginPath(); ctx.arc(x,y,size,0,Math.PI*2); ctx.fill();
      }
      if (speaking || listening) {
        const INNER = 28;
        for (let i=0;i<INNER;i++) {
          const angle = (i/INNER)*Math.PI*2 - tk*0.012;
          const r = 84 + Math.sin(tk*0.08 + i*0.45)*10;
          const x = cx + Math.cos(angle)*r, y = cy + Math.sin(angle)*r;
          const col = speaking
            ? `rgba(74,222,128,${0.4+0.4*Math.abs(Math.sin(tk*0.1+i))})`
            : `rgba(56,189,248,${0.3+0.4*Math.abs(Math.sin(tk*0.1+i))})`;
          ctx.fillStyle = col;
          ctx.beginPath(); ctx.arc(x,y,1.5+Math.abs(Math.sin(tk*0.06+i))*2,0,Math.PI*2); ctx.fill();
        }
      }
      pFrameRef.current = requestAnimationFrame(draw);
    };
    pFrameRef.current = requestAnimationFrame(draw);
    return () => cancelAnimationFrame(pFrameRef.current);
  }, [speaking, listening]);

  return (
    <div className={`la-root${locked ? ' la-root--locked' : ''}`}>

      {/* Status bar */}
      <div className="la-status-bar">
        <span className={`la-status-bar__dot${(listening||speaking) ? ' la-status-bar__dot--active' : ''}`}/>
        <span className="la-status-bar__text">
          {listening ? `LISTENING… ${holdSecs}s` : speaking ? 'AIPPIE IS SPEAKING…' : 'LIVING AVATAR · ONLINE'}
        </span>
        {activeModule && (
          <div className="la-active-module">
            {MODULE_ICONS[activeModule]}
            <span>{MODULE_LABELS[activeModule]}</span>
          </div>
        )}
        <span className="la-status-bar__badge"><Sparkles size={9}/> AI</span>
      </div>

      {/* Avatar + particle ring — expands to full-screen when locked */}
      <div className={`la-avatar-stage${locked ? ' la-avatar-stage--locked' : ''}`}>
        <canvas ref={canvasRef} width={280} height={280} className="la-particle-canvas" aria-hidden="true"/>
        <div className="la-avatar-frame">
          <img
            src="/Jouw_alineatekst_(2).png"
            alt="Aippie Living Avatar"
            className={`la-avatar${listening?' la-avatar--listening':speaking?' la-avatar--speaking':''}`}
            draggable={false}
          />
          <div className={`la-avatar__ring la-avatar__ring--1${listening?' la-avatar__ring--fast':''}`}/>
          <div className={`la-avatar__ring la-avatar__ring--2${listening?' la-avatar__ring--fast':''}`}/>
        </div>
      </div>

      {/* Name plate */}
      <div className="la-nameplate">
        <div className="la-nameplate__name">Aippie</div>
        <div className="la-nameplate__role">Living AI Avatar · AIPPIETAX S.A.</div>
      </div>

      {/* Word-sync subtitle panel — anchored directly below the portrait/nameplate, always present */}
      <div className={`la-subtitle-panel${speaking && subtitle ? ' la-subtitle-panel--active' : ''}`}>
        <span className={`la-subtitle-text${(!speaking || !subtitle) ? ' la-subtitle-text--idle' : ''}`}>
          {speaking && subtitle ? subtitle : '\u00A0'}
        </span>
      </div>

      {/* Typewriter speech bubble */}
      <div className="la-speech">
        <div className="la-speech__avatar-row">
          <img
            src="/Jouw_alineatekst_(2).png"
            alt="Aippie" className="la-speech__thumb"
          />
          <div>
            <div className="la-speech__name">Aippie</div>
            <div className="la-speech__role">Living Avatar</div>
          </div>
          {speaking && <span className="la-speech__speaking-dot"/>}
        </div>
        <div className="la-speech__text">
          {typed}
          {typing && <span className="la-speech__cursor"/>}
        </div>
      </div>

      {/* Waveform */}
      <div className="la-wave-wrap">
        <Waveform active={listening || speaking} color={speaking ? 'emerald' : 'amber'}/>
        <div className="la-wave-label">
          {listening ? 'Processing your voice…' : speaking ? 'Aippie is speaking…' : 'Ready to listen'}
        </div>
      </div>

      {/* Concierge drawer — slides in directly below the avatar, zero routing */}
      {activeModule && CONCIERGE_DRAWERS[activeModule] && (
        <div className={`la-concierge-wrap${drawerOpen ? ' la-concierge-wrap--open' : ''}`}>
          <button
            className="la-concierge-toggle"
            onClick={() => setDrawerOpen(o => !o)}
          >
            {MODULE_ICONS[activeModule]}
            <span>{MODULE_LABELS[activeModule]} — Details</span>
            {drawerOpen ? <ChevronUp size={11}/> : <ChevronDown size={11}/>}
          </button>
          {drawerOpen && (
            <ConciergeDrawer moduleKey={activeModule} onClose={() => setDrawerOpen(false)}/>
          )}
        </div>
      )}

      {/* Hold-to-talk */}
      <div className="la-cta-row">
        <button
          className="la-did-btn"
          onClick={() => window.open('https://studio.d-id.com/share?id=05a847891293dbaa81a30f3079afb0ae&utm_source=copy', '_blank', 'width=420,height=620,resizable=yes,scrollbars=yes')}
        >
          <span className="la-did-btn__dot" />
          TALK TO AIPPIE LIVE
        </button>
        <button
          className={`sts-hold-btn la-hold-btn${listening?' sts-hold-btn--active':''}`}
          onPointerDown={startListening}
          onPointerUp={stopListening}
          onPointerLeave={stopListening}
          onPointerCancel={stopListening}
          aria-label="Hold to talk to Aippie Living Avatar"
        >
          <span className="sts-hold-btn__ring sts-hold-btn__ring--1"/>
          <span className="sts-hold-btn__ring sts-hold-btn__ring--2"/>
          <span className="sts-hold-btn__core">
            <Mic size={14}/>
            {listening ? `LISTENING… ${holdSecs}s` : '🎙️ HOLD TO TALK TO AIPPIE'}
          </span>
        </button>
      </div>

      {/* Chat history */}
      {chat.length > 0 && (
        <div className="la-chat">
          <div className="la-chat__header">
            <MessageSquare size={11}/>
            <span>CONVERSATION LOG</span>
          </div>
          <div className="la-chat__list">
            {chat.map(entry => (
              <div key={entry.ts} className={`la-chat-entry la-chat-entry--${entry.role}`}>
                {entry.role === 'aippie' && entry.module && (
                  <div className="la-chat-entry__module">
                    {MODULE_ICONS[entry.module]}
                    <span>{MODULE_LABELS[entry.module]} activated</span>
                  </div>
                )}
                <div className="la-chat-entry__bubble">{entry.text}</div>
              </div>
            ))}
            <div ref={chatEndRef}/>
          </div>
        </div>
      )}

      {/* Module capability chips */}
      <div className="la-capability-row">
        {Object.keys(MODULE_LABELS).map(k => (
          <div
            key={k}
            className={`la-cap-chip${activeModule===k?' la-cap-chip--active':''}`}
            onClick={() => {
              const next = activeModule === k ? null : k;
              setActiveModule(next);
              setDrawerOpen(!!next);
            }}
          >
            {MODULE_ICONS[k]}
            <span>{MODULE_LABELS[k]}</span>
          </div>
        ))}
      </div>

      <div className="la-module-row">
        <UserCircle2 size={11} className="la-module-row__icon"/>
        <span>Connected to all 5 Aippie modules · Real-time voice routing</span>
      </div>

      <div className="la-footer">
        <ShieldCheck size={10}/>
        AIPPIETAX S.A. · Living Avatar Engine v45 · GDPR compliant
      </div>
    </div>
  );
}
