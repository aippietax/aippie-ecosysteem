/**
 * GlobalLangSelector — V114 Global Multi-Language Localization Engine
 * AIPPIETAX S.A.
 *
 * Translucent top-right language selector overlay.
 * On language switch: cancels TTS, stores preference, fires onLangChange.
 */
import { useEffect, useRef, useState } from 'react';
import { Globe } from 'lucide-react';
import { LANGUAGES, type LangCode } from '../lib/i18n';

interface Props {
  lang: LangCode;
  onLangChange: (l: LangCode) => void;
}

export default function GlobalLangSelector({ lang, onLangChange }: Props) {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  const handleSelect = (code: LangCode) => {
    setOpen(false);
    if (code === lang) return;
    window.speechSynthesis?.cancel();
    onLangChange(code);
  };

  const current = LANGUAGES.find(l => l.code === lang) ?? LANGUAGES[0];

  return (
    <div className="gls-root" ref={ref}>
      <button
        className="gls-trigger"
        onClick={() => setOpen(o => !o)}
        aria-label="Select language"
        aria-expanded={open}
      >
        <Globe size={13} className="gls-trigger__globe" />
        <span className="gls-trigger__flag">{current.flag}</span>
        <span className="gls-trigger__label">{current.nativeLabel}</span>
      </button>

      {open && (
        <div className="gls-dropdown" role="listbox" aria-label="Language options">
          {LANGUAGES.map(l => (
            <button
              key={l.code}
              className={`gls-option${l.code === lang ? ' gls-option--active' : ''}`}
              onClick={() => handleSelect(l.code)}
              role="option"
              aria-selected={l.code === lang}
            >
              <span className="gls-option__flag">{l.flag}</span>
              <span className="gls-option__native">{l.nativeLabel}</span>
              <span className="gls-option__label">{l.label}</span>
              {l.code === lang && <span className="gls-option__check">✓</span>}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
