import { Mic, MicOff } from 'lucide-react';

type Props = {
  isActive: boolean;
  onPress: () => void;
};

export default function CallButton({ isActive, onPress }: Props) {
  return (
    <button
      onClick={onPress}
      aria-label={isActive ? 'End call' : 'Start call'}
      className={`call-btn ${isActive ? 'call-btn--active' : 'call-btn--idle'}`}
    >
      <span className="call-btn__ring call-btn__ring--1" />
      <span className="call-btn__ring call-btn__ring--2" />
      <span className="call-btn__inner">
        {isActive ? (
          <MicOff size={44} strokeWidth={1.8} />
        ) : (
          <Mic size={44} strokeWidth={1.8} />
        )}
      </span>
    </button>
  );
}
