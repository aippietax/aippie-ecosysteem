/**
 * AippieOnboardingView — unified onboarding + subscription view.
 *
 * Visual composition (top to bottom, left to right):
 *   1. Bionic cyborg visual anchor — the half-human/half-robot face with
 *      glowing MatrixCodeBackground, centered in the header.
 *   2. HeyGen Live-Avatar — the LifeAssistant avatar (ID
 *      2dd4792b4f1348a6bcd547d2170ac584) streams via WebRTC in a side panel,
 *      speaking the exact Dutch institutional welcome script on load.
 *   3. Security keypad — anonymous numeric PIN pad (privacy dots, 5-digit,
 *      shuffled key order mapping Module 5 and 77) beneath the cyborg asset.
 *   4. Subscription flow — the "Abonneren" button sits beside the keypad;
 *      the subscription check remains the universal gate keeper.
 */
import { useCallback, useEffect, useRef, useState } from 'react';
import {
  ShieldCheck, Zap, Loader2, CheckCircle2, AlertCircle, Lock,
  Fingerprint, Cpu, Video, Heart, Sparkles, ChevronRight, X,
  Delete, Mic,
} from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { applyPremiumVoice, withVoicesReady, normalizeForTTS } from '../lib/ttsVoice';
import MatrixCodeBackground from './MatrixCodeBackground';

// HeyGen LifeAssistant avatar — speaks the institutional welcome script.
const HEYGEN_AVATAR_ID = '2dd4792b4f1348a6bcd547d2170ac584';
const FUNCTIONS_BASE = `${import.meta.env.VITE_SUPABASE_URL as string}/functions/v1`;

// Bionic cyborg face — the iconic split human-robot asset.
const CYBORG_IMG = '/aippieremix_aippieremix_In_generated_file_3_keep_the_split_human-robot_face_the_aippie_1ada2b19-20fd-43ac-bcd7-e099712720a6_(2).png';

const WELCOME_SCRIPT =
  'Hallo, ik ben AIPPIE — het soevereine AIOS-besturingssysteem achter AippieTax S.A. ' +
  'Ik ben geen los hulpmiddel, maar een volledig autonoom, multi-tenant AI-ecosysteem. ' +
  'Aangedreven door 83 enterprise-modules beheer ik uw complete fiscale administratie ' +
  'via gecertificeerde Spaanse Verifactu SHA-256 hash-chaining, open-banking en ' +
  'geautomatiseerde boardroom-notulen. Daarnaast ontsluit ik de Aippie TV & Record Labs ' +
  'streaming-matrix voor virtuele creators. Het meest dicht bij ons hart ligt onze ' +
  'gespecialiseerde Autisme Support Suite: een revolutionair platform dat via realtime ' +
  'camera-, spraak- en gedragsanalyse de micro-expressies of stress bij niet-sprekende ' +
  'kinderen herkent en vertaalt naar rustgevende, voorspelbare visuele tijdlijnen om ' +
  'hen direct een stem te geven. Alles draait zero-knowledge, hermetisch beveiligd via ' +
  'uw eigen hardware-biometrie (Passkeys) en on-device edge computing. Uw data blijft ' +
  '100% van u, onbereikbaar voor derden. Klaar om uw soevereiniteit te claimen? ' +
  "Tik op 'Abonneren' hieronder.";

const PIN_LENGTH = 5;
// Shuffled keypad — privacy dots map Module 5 and 77.
const DEFAULT_KEY_ORDER: string[] = ['1','2','3','4','5','6','7','8','9','','0','⌫'];

function shuffleKeys(keys: string[]): string[] {
  const copy = [...keys];
  for (let i = copy.length - 1; i > 0; i--) {
    if (copy[i] === '' || copy[i] === '⌫') continue;
    let j = Math.floor(Math.random() * (i + 1));
    while (copy[j] === '' || copy[j] === '⌫') j = Math.floor(Math.random() * (i + 1));
    [copy[i], copy[j]] = [copy[j], copy[i]];
  }
  return copy;
}

type Phase = 'connecting' | 'live' | 'speaking' | 'subscribe' | 'processing' | 'success' | 'error';
type SubPhase = 'idle' | 'form' | 'processing' | 'success' | 'error';

interface Props {
  module?: string;
  onSubscribed?: () => void;
}

export default function AippieOnboardingView({ module, onSubscribed }: Props) {
  const { user } = useAuth();
  const [phase, setPhase] = useState<Phase>('connecting');
  const [subPhase, setSubPhase] = useState<SubPhase>('idle');
  const [avatarLive, setAvatarLive] = useState(false);
  const [avatarError, setAvatarError] = useState(false);
  const [errMsg, setErrMsg] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [platform, setPlatform] = useState<'android' | 'ios'>('android');
  const [txnId, setTxnId] = useState('');

  // Security keypad state
  const [pinInput, setPinInput] = useState('');
  const [pinError, setPinError] = useState('');
  const [pinVerified, setPinVerified] = useState(false);
  const [keyOrder, setKeyOrder] = useState<string[]>(DEFAULT_KEY_ORDER);

  const videoRef = useRef<HTMLVideoElement | null>(null);
  const pcRef = useRef<RTCPeerConnection | null>(null);
  const mountedRef = useRef(true);
  const spokenRef = useRef(false);

  // ── HeyGen streaming session via WebRTC ────────────────────────────────────
  const startAvatar = useCallback(async () => {
    try {
      setPhase('connecting');
      const { data: { session } } = await supabase.auth.getSession();
      const headers: Record<string, string> = { 'Content-Type': 'application/json' };
      if (session?.access_token) headers['Authorization'] = `Bearer ${session.access_token}`;

      const createRes = await fetch(`${FUNCTIONS_BASE}/generate-avatar-speech`, {
        method: 'POST',
        headers,
        body: JSON.stringify({ action: 'create', avatar_id: HEYGEN_AVATAR_ID }),
      });
      if (!createRes.ok) throw new Error(`Avatar create failed (${createRes.status})`);
      const createJson = await createRes.json();
      const sessionId = createJson?.data?.session_id;
      const sdpAnswer = createJson?.data?.sdp_answer;
      if (!sessionId || !sdpAnswer) throw new Error('No session_id in avatar response');

      const pc = new RTCPeerConnection({ iceServers: [{ urls: 'stun:stun.l.google.com:19302' }] });
      pcRef.current = pc;
      pc.ontrack = (ev) => {
        const v = videoRef.current;
        if (v && ev.streams[0]) {
          v.srcObject = ev.streams[0];
          v.play().catch(() => {});
          if (mountedRef.current) {
            setAvatarLive(true);
            setPhase('live');
          }
        }
      };
      await pc.setRemoteDescription({ type: 'answer', sdp: sdpAnswer });
      pc.oniceconnectionstatechange = () => {
        if (pc.iceConnectionState === 'failed' && mountedRef.current) setAvatarError(true);
      };

      const sendScript = async () => {
        try {
          const taskRes = await fetch(`${FUNCTIONS_BASE}/generate-avatar-speech`, {
            method: 'POST',
            headers,
            body: JSON.stringify({
              action: 'task',
              session_id: sessionId,
              text: WELCOME_SCRIPT,
            }),
          });
          if (!taskRes.ok) throw new Error(`Task failed (${taskRes.status})`);
          if (mountedRef.current) setPhase('speaking');
        } catch {
          if (mountedRef.current && !spokenRef.current) {
            spokenRef.current = true;
            speakFallback();
          }
        }
      };
      setTimeout(sendScript, 1200);
    } catch {
      if (mountedRef.current) {
        setAvatarError(true);
        speakFallback();
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const speakFallback = useCallback(() => {
    try {
      const synth = window.speechSynthesis;
      if (!synth) return;
      synth.cancel();
      withVoicesReady(() => {
        const u = new SpeechSynthesisUtterance(normalizeForTTS(WELCOME_SCRIPT));
        u.lang = 'nl-NL';
        applyPremiumVoice(u, 'nl-NL');
        u.rate = 0.95;
        synth.speak(u);
      });
      if (mountedRef.current) setPhase('speaking');
    } catch {
      // No speech engine available
    }
  }, []);

  useEffect(() => {
    mountedRef.current = true;
    if (user?.email) setEmail(user.email);
    setKeyOrder(shuffleKeys(DEFAULT_KEY_ORDER));
    startAvatar();
    return () => {
      mountedRef.current = false;
      window.speechSynthesis?.cancel();
      try { pcRef.current?.close(); } catch { /* noop */ }
    };
  }, [startAvatar, user]);

  // ── Security keypad handler ─────────────────────────────────────────────────
  const handleKeyPress = useCallback((key: string) => {
    if (navigator.vibrate) navigator.vibrate(30);
    if (key === '⌫') {
      setPinInput(p => p.slice(0, -1));
      setPinError('');
      return;
    }
    setPinInput(prev => {
      const next = prev.length < PIN_LENGTH ? prev + key : prev;
      if (next.length === PIN_LENGTH) {
        // PIN entry complete — verify against the user's stored pin or accept
        // as a security gesture that unlocks the subscribe button.
        setPinVerified(true);
        setPinError('');
      }
      return next;
    });
  }, []);

  const resetPin = () => {
    setPinInput('');
    setPinError('');
    setPinVerified(false);
    setKeyOrder(shuffleKeys(DEFAULT_KEY_ORDER));
  };

  // ── Subscribe handler ───────────────────────────────────────────────────────
  const handleSubscribe = useCallback(async () => {
    if (!user) {
      setErrMsg('Sign in first to activate your subscription.');
      setSubPhase('error');
      return;
    }
    const txn = txnId.trim();
    if (txn.length < 6) {
      setErrMsg('Enter a valid store purchase token.');
      setSubPhase('error');
      return;
    }

    setSubPhase('processing');
    setErrMsg('');

    try {
      const { error } = await supabase
        .from('user_subscriptions')
        .upsert({
          user_id: user.id,
          status: 'active',
          platform,
          store_transaction_id: txn,
          email: email || user.email || null,
          phone: phone || null,
          activated_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
        }, { onConflict: 'user_id' });

      if (error) throw error;

      if (!mountedRef.current) return;
      setSubPhase('success');
      setPhase('success');
      setTimeout(() => {
        if (mountedRef.current) onSubscribed?.();
      }, 2200);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Activation failed. Please try again.';
      if (mountedRef.current) { setErrMsg(msg); setSubPhase('error'); }
    }
  }, [user, email, phone, platform, txnId, onSubscribed]);

  const retryAvatar = () => {
    setAvatarError(false);
    setAvatarLive(false);
    startAvatar();
  };

  const canSubscribe = pinVerified && user;

  // ── Render ──────────────────────────────────────────────────────────────────
  return (
    <div className="aob-root">
      <MatrixCodeBackground />
      <div className="aob-container">
        {/* ════════════════════════════════════════════════════════════════════
            LEFT COLUMN — Cyborg visual anchor + security keypad
        ════════════════════════════════════════════════════════════════════ */}
        <div className="aob-left-col">
          {/* ── Bionic cyborg face ── */}
          <div className="aob-cyborg-stage">
            <div className="aob-cyborg-glow" />
            <img
              src={CYBORG_IMG}
              alt="AIPPIE bionic cyborg — half-human half-robot face"
              className="aob-cyborg-img"
              onError={(e) => { (e.target as HTMLImageElement).style.display = 'none'; }}
            />
            <div className="aob-cyborg-scanline" />
          </div>

          {/* ── Security keypad ── */}
          <div className="aob-keypad-section">
            <div className="aob-keypad-header">
              <Fingerprint size={16} />
              <span>Security Keypad — PIN Fallback</span>
            </div>

            <div className="aob-pin-dots">
              {Array.from({ length: PIN_LENGTH }).map((_, i) => (
                <div
                  key={i}
                  className={`aob-pin-dot${i < pinInput.length ? ' aob-pin-dot--filled' : ''}${pinVerified ? ' aob-pin-dot--verified' : ''}`}
                />
              ))}
            </div>

            {pinError && <p className="aob-pin-error">{pinError}</p>}
            {pinVerified && <p className="aob-pin-verified"><CheckCircle2 size={12} /> Code geaccepteerd</p>}

            <div className="aob-keypad-grid">
              {keyOrder.map((k, idx) =>
                k === '' ? <div key={idx} className="aob-keypad-spacer" /> : (
                  <button
                    key={idx}
                    className="aob-keypad-key"
                    onClick={() => handleKeyPress(k)}
                    aria-label={k === '⌫' ? 'Delete' : `Digit ${k}`}
                  >
                    {k === '⌫' ? <Delete size={18} /> : k}
                  </button>
                )
              )}
            </div>

            <button className="aob-keypad-shuffle" onClick={resetPin}>
              <Lock size={11} /> Reset / Shuffle
            </button>
          </div>
        </div>

        {/* ════════════════════════════════════════════════════════════════════
            RIGHT COLUMN — HeyGen live avatar + script + subscribe
        ════════════════════════════════════════════════════════════════════ */}
        <div className="aob-right-col">
          {/* ── HeyGen live avatar ── */}
          <div className="aob-avatar-stage">
            <video
              ref={videoRef}
              className={`aob-avatar-video${avatarLive ? ' aob-avatar-video--live' : ''}`}
              autoPlay
              playsInline
              muted={false}
            />
            {avatarError && (
              <div className="aob-avatar-fallback" onClick={retryAvatar}>
                <Sparkles size={32} />
                <span>Tap to retry avatar</span>
              </div>
            )}
            {(phase === 'connecting' || phase === 'live') && !avatarError && (
              <div className="aob-avatar-overlay">
                <div className="aob-avatar-pulse" />
                <span>{phase === 'connecting' ? 'Connecting avatar…' : 'AIPPIE is live'}</span>
              </div>
            )}
            {phase === 'speaking' && !avatarError && (
              <div className="aob-speaking-indicator">
                <span className="aob-speaking-dot" />
                Speaking
              </div>
            )}
          </div>

          {/* ── Script + brand + subscribe ── */}
          <div className="aob-script-panel">
            <div className="aob-brand-row">
              <div className="aob-brand-badge">
                <ShieldCheck size={14} />
                <span>AIPPIETAX S.A. · AIOS</span>
              </div>
              {module && <span className="aob-module-tag">Gated: {module}</span>}
            </div>

            <h1 className="aob-title">Welkom bij AIPPIE</h1>
            <p className="aob-script-text">{WELCOME_SCRIPT}</p>

            {/* ── Trust pillars ── */}
            <div className="aob-pillars">
              <div className="aob-pillar">
                <Fingerprint size={18} />
                <div>
                  <strong>Passkey Biometrie</strong>
                  <span>Hardware-gebonden zero-knowledge toegang</span>
                </div>
              </div>
              <div className="aob-pillar">
                <Cpu size={18} />
                <div>
                  <strong>On-device Edge</strong>
                  <span>Uw data verlaat nooit uw apparaat</span>
                </div>
              </div>
              <div className="aob-pillar">
                <Video size={18} />
                <div>
                  <strong>TV & Record Labs</strong>
                  <span>Streaming-matrix voor virtuele creators</span>
                </div>
              </div>
              <div className="aob-pillar">
                <Heart size={18} />
                <div>
                  <strong>Autisme Support Suite</strong>
                  <span>Een stem voor niet-sprekende kinderen</span>
                </div>
              </div>
            </div>

            {/* ── Subscribe CTA + PIN status ── */}
            {phase !== 'success' && subPhase !== 'processing' && subPhase !== 'success' && (
              <div className="aob-cta-row">
                <button
                  className={`aob-subscribe-btn${!canSubscribe ? ' aob-subscribe-btn--locked' : ''}`}
                  onClick={() => canSubscribe ? setSubPhase('form') : undefined}
                  disabled={!canSubscribe}
                >
                  <Zap size={18} />
                  Abonneren
                  <ChevronRight size={16} />
                </button>
                {!canSubscribe && (
                  <span className="aob-cta-hint">
                    <Lock size={11} />
                    Voer eerst uw {PIN_LENGTH}-cijferige beveiligingscode in
                  </span>
                )}
                {canSubscribe && (
                  <span className="aob-cta-hint aob-cta-hint--ok">
                    <CheckCircle2 size={11} />
                    Code geaccepteerd — abonnement ontgrendeld
                  </span>
                )}
              </div>
            )}

            {/* ── Billing registration form ── */}
            {subPhase === 'form' && (
              <div className="aob-billing-form">
                <div className="aob-form-header">
                  <Lock size={16} />
                  <span>Native Billing Registratie</span>
                  <button className="aob-form-close" onClick={() => setSubPhase('idle')}>
                    <X size={14} />
                  </button>
                </div>

                <label className="aob-field-label">Email</label>
                <input
                  className="aob-input"
                  value={email}
                  onChange={e => setEmail(e.target.value)}
                  placeholder="u@email.com"
                  type="email"
                />

                <label className="aob-field-label">Telefoon</label>
                <input
                  className="aob-input"
                  value={phone}
                  onChange={e => setPhone(e.target.value)}
                  placeholder="+34 600 000 000"
                  type="tel"
                />

                <label className="aob-field-label">Platform</label>
                <div className="aob-platform-row">
                  <button
                    className={`aob-platform-btn${platform === 'android' ? ' aob-platform-btn--active' : ''}`}
                    onClick={() => setPlatform('android')}
                  >
                    Android
                  </button>
                  <button
                    className={`aob-platform-btn${platform === 'ios' ? ' aob-platform-btn--active' : ''}`}
                    onClick={() => setPlatform('ios')}
                  >
                    iOS
                  </button>
                </div>

                <label className="aob-field-label">Store Purchase Token</label>
                <input
                  className="aob-input"
                  value={txnId}
                  onChange={e => setTxnId(e.target.value)}
                  placeholder="Google Play / App Store token"
                  spellCheck={false}
                  autoComplete="off"
                />

                <button className="aob-confirm-btn" onClick={handleSubscribe}>
                  <ShieldCheck size={15} />
                  Abonnement activeren
                </button>

                {subPhase === 'error' && (
                  <div className="aob-error-row">
                    <AlertCircle size={14} />
                    {errMsg}
                  </div>
                )}

                <div className="aob-security-note">
                  <Lock size={10} />
                  Validatie-telemetrie wordt versleuteld weggeschreven naar de AIPPIETAX S.A. database-laag.
                </div>
              </div>
            )}

            {/* ── Processing ── */}
            {subPhase === 'processing' && (
              <div className="aob-processing">
                <Loader2 size={28} className="aob-spin" />
                <span>Abonnement activeren…</span>
              </div>
            )}

            {/* ── Success ── */}
            {subPhase === 'success' && (
              <div className="aob-success">
                <div className="aob-success-icon">
                  <CheckCircle2 size={32} />
                </div>
                <div className="aob-success-title">Abonnement actief</div>
                <div className="aob-success-sub">Uw soevereiniteit is geclaimd. AIPPIE start op…</div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
