import { useEffect, useState, useRef } from 'react';
import {
  Trophy, Crown, TrendingUp, TrendingDown, Zap, Bot,
  Target, Medal, Star, Timer, Users, RefreshCw,
} from 'lucide-react';
import { supabase } from '../lib/supabase';

interface Trader {
  id: string;
  rank: number;
  display_name: string;
  avatar_color: string;
  strategy: string;
  portfolio: number;
  pnl: number;
  win_rate: number;
  trades: number;
  is_user: boolean;
}
interface TradeEvent {
  id: string;
  trader_name: string;
  action: 'BUY' | 'SELL' | 'SHORT' | 'COVER';
  asset: string;
  price: number;
  qty: number;
  pnl: number | null;
  created_at: string;
}

const STRATEGY_COLOR: Record<string, string> = {
  MOMENTUM: '#f59e0b', 'MEAN-REV': '#4ade80', BREAKOUT: '#38bdf8',
  SCALP: '#a78bfa', SWING: '#fb7185', 'AI-HYBRID': '#34d399',
};

const RANK_ICON = (r: number) => {
  if (r === 1) return <Crown size={13} style={{ color: '#f59e0b' }} />;
  if (r === 2) return <Medal size={13} style={{ color: '#94a3b8' }} />;
  if (r === 3) return <Medal size={13} style={{ color: '#cd7f32' }} />;
  return <span style={{ fontSize: 11, color: '#475569', width: 13, display: 'inline-block', textAlign: 'center' }}>{r}</span>;
};

export default function AippieTournamentView() {
  const [traders, setTraders]   = useState<Trader[]>([]);
  const [events, setEvents]     = useState<TradeEvent[]>([]);
  const [loading, setLoading]   = useState(true);
  const [elapsed, setElapsed]   = useState(0);
  const tickRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const load = async () => {
    const [{ data: t }, { data: e }] = await Promise.all([
      supabase.from('tournament_traders').select('*').order('rank').limit(20),
      supabase.from('tournament_events').select('*').order('created_at', { ascending: false }).limit(20),
    ]);
    if (t) setTraders(t as Trader[]);
    if (e) setEvents(e as TradeEvent[]);
    setLoading(false);
  };

  useEffect(() => {
    load();
    tickRef.current = setInterval(() => setElapsed(s => s + 1), 1000);

    // Realtime for new events
    const ch = supabase.channel('tournament_live')
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'tournament_events' }, p => {
        setEvents(prev => [p.new as TradeEvent, ...prev.slice(0, 19)]);
      })
      .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'tournament_traders' }, p => {
        setTraders(prev => prev.map(t => t.id === (p.new as Trader).id ? p.new as Trader : t));
      })
      .subscribe();

    return () => {
      if (tickRef.current) clearInterval(tickRef.current);
      supabase.removeChannel(ch);
    };
  }, []);

  const fmt = (n: number) => {
    if (Math.abs(n) >= 1000) return (n / 1000).toFixed(1) + 'K';
    return n.toFixed(0);
  };
  const fmtTime = (s: number) => `${String(Math.floor(s / 3600)).padStart(2,'0')}:${String(Math.floor((s % 3600) / 60)).padStart(2,'0')}:${String(s % 60).padStart(2,'0')}`;

  return (
    <div className="tour-root">
      {/* Header */}
      <div className="tour-header">
        <div className="tour-header__left">
          <Trophy size={22} style={{ color: '#f59e0b' }} />
          <div>
            <div className="tour-header__title">AI Trading Championship</div>
            <div className="tour-header__sub">Live tournament · {traders.length} strategieën actief</div>
          </div>
        </div>
        <div className="tour-header__right">
          <div className="tour-timer">
            <Timer size={11} />
            {fmtTime(elapsed)}
          </div>
          <button className="sr-control-btn" onClick={() => { setLoading(true); load(); }}>
            <RefreshCw size={12} className={loading ? 'mb-spin' : ''} />
          </button>
        </div>
      </div>

      {/* Top 3 podium */}
      {traders.length >= 3 && (
        <div className="tour-podium">
          {[traders[1], traders[0], traders[2]].map((t, i) => {
            const positions = [2, 1, 3];
            const heights = ['80px', '100px', '64px'];
            return (
              <div key={t.id} className="tour-podium__slot" style={{ order: i }}>
                <div className="tour-podium__avatar" style={{ borderColor: t.avatar_color, background: t.avatar_color + '18' }}>
                  <Bot size={18} style={{ color: t.avatar_color }} />
                </div>
                <div className="tour-podium__name">{t.display_name}</div>
                <div className="tour-podium__strategy" style={{ color: STRATEGY_COLOR[t.strategy] ?? '#38bdf8' }}>
                  {t.strategy}
                </div>
                <div className="tour-podium__pnl" style={{ color: t.pnl >= 0 ? '#4ade80' : '#f87171' }}>
                  {t.pnl >= 0 ? '+' : ''}${fmt(t.pnl)}
                </div>
                <div className="tour-podium__base" style={{ height: heights[i], background: t.avatar_color + '22', borderColor: t.avatar_color + '44' }}>
                  <span className="tour-podium__rank">#{positions[i]}</span>
                </div>
              </div>
            );
          })}
        </div>
      )}

      <div className="tour-body">
        {/* Leaderboard */}
        <div className="tour-leaderboard">
          <div className="tour-section-label"><Target size={10} /> Klassement</div>
          {loading ? (
            <div style={{ display: 'flex', justifyContent: 'center', padding: 24 }}>
              <div className="cag-checking__spinner" />
            </div>
          ) : traders.map(t => (
            <div key={t.id} className={`tour-row${t.is_user ? ' tour-row--user' : ''}`}>
              <div className="tour-row__rank">{RANK_ICON(t.rank)}</div>
              <div className="tour-row__avatar" style={{ background: t.avatar_color + '22', borderColor: t.avatar_color + '55' }}>
                <Bot size={11} style={{ color: t.avatar_color }} />
              </div>
              <div className="tour-row__info">
                <div className="tour-row__name">{t.display_name} {t.is_user && <Star size={9} style={{ color: '#f59e0b' }} />}</div>
                <div className="tour-row__strategy" style={{ color: STRATEGY_COLOR[t.strategy] ?? '#38bdf8' }}>{t.strategy}</div>
              </div>
              <div className="tour-row__portfolio">${fmt(t.portfolio)}</div>
              <div className={`tour-row__pnl ${t.pnl >= 0 ? 'mb-pos' : 'mb-neg'}`}>
                {t.pnl >= 0 ? <TrendingUp size={9} /> : <TrendingDown size={9} />}
                {t.pnl >= 0 ? '+' : ''}${fmt(t.pnl)}
              </div>
              <div className="tour-row__winrate">{t.win_rate.toFixed(1)}%</div>
              <div className="tour-row__trades">{t.trades} <span style={{ color: '#475569', fontSize: 9 }}>trades</span></div>
            </div>
          ))}
        </div>

        {/* Live events feed */}
        <div className="tour-events">
          <div className="tour-section-label"><Zap size={10} /> Live Trades Feed</div>
          <div className="tour-events__list">
            {events.length === 0 && <div style={{ color: '#475569', fontSize: 12, padding: '12px 0' }}>Geen events</div>}
            {events.map(ev => (
              <div key={ev.id} className="tour-event">
                <div className="tour-event__action" style={{ color: ev.action === 'BUY' || ev.action === 'COVER' ? '#4ade80' : '#f87171' }}>
                  {ev.action}
                </div>
                <div className="tour-event__body">
                  <span className="tour-event__name">{ev.trader_name}</span>
                  <span className="tour-event__asset">{ev.asset}</span>
                  <span style={{ color: '#475569', fontSize: 10 }}>@ ${ev.price.toFixed(2)}</span>
                </div>
                {ev.pnl != null && (
                  <div className={`tour-event__pnl ${ev.pnl >= 0 ? 'mb-pos' : 'mb-neg'}`}>
                    {ev.pnl >= 0 ? '+' : ''}${ev.pnl.toFixed(0)}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="sr-footer">
        <Users size={10} /> AIPPIETAX S.A. · AI Trading Championship · Simulated paper trading · Geen echt geld
      </div>
    </div>
  );
}
