/**
 * AdminLicenseView — V116 B2B Enterprise License Management
 * AIPPIETAX S.A.
 *
 * Master admin panel for generating, tracking, expanding, and revoking
 * multi-user cryptographic license keys for B2B partners, affiliate groups,
 * and educational institutions.
 */
import { useCallback, useEffect, useRef, useState } from 'react';
import {
  ShieldCheck, Plus, RefreshCw, X, Copy, CheckCircle2,
  AlertTriangle, Users, Key, Building2, Zap, Lock,
  ChevronDown, ChevronUp, Search
} from 'lucide-react';
import { supabase } from '../lib/supabase';
import type { LicenseRecord } from './LicenseGate';
import IpAssetRegistry from './IpAssetRegistry';

interface AdminLicenseViewProps {
  onClose: () => void;
}

type LicenseType = 'individual' | 'b2b_team' | 'enterprise' | 'affiliate' | 'education';
type Plan = 'tax' | 'voice' | 'trading' | 'doctor' | 'all';

const TYPE_COLORS: Record<LicenseType, string> = {
  individual: '#60a5fa',
  b2b_team:   '#4ade80',
  enterprise: '#f59e0b',
  affiliate:  '#fb7185',
  education:  '#a78bfa',
};

const PLAN_COLORS: Record<Plan, string> = {
  tax:     '#4ade80',
  voice:   '#38bdf8',
  trading: '#f59e0b',
  doctor:  '#34d399',
  all:     '#f472b6',
};

const STATUS_COLORS: Record<string, string> = {
  active:    '#4ade80',
  suspended: '#fbbf24',
  revoked:   '#f87171',
  expired:   '#94a3b8',
};

function generateLicenseKey(): string {
  const seg = () => Math.random().toString(36).toUpperCase().substring(2, 6).padEnd(4, '0');
  return `AIPP-${seg()}-${seg()}-${seg()}`;
}

function formatDate(iso: string | null): string {
  if (!iso) return 'Perpetual';
  return new Date(iso).toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' });
}

interface CreateForm {
  owner_name: string;
  owner_email: string;
  license_type: LicenseType;
  plan: Plan;
  max_seats: number;
  expires_months: number; // 0 = perpetual
  notes: string;
}

const BLANK_FORM: CreateForm = {
  owner_name: '',
  owner_email: '',
  license_type: 'individual',
  plan: 'all',
  max_seats: 1,
  expires_months: 12,
  notes: '',
};

export default function AdminLicenseView({ onClose }: AdminLicenseViewProps) {
  const [licenses, setLicenses]     = useState<LicenseRecord[]>([]);
  const [loading,  setLoading]      = useState(true);
  const [search,   setSearch]       = useState('');
  const [creating, setCreating]     = useState(false);
  const [form,     setForm]         = useState<CreateForm>(BLANK_FORM);
  const [formErr,  setFormErr]      = useState('');
  const [saving,   setSaving]       = useState(false);
  const [copiedId, setCopiedId]     = useState<string | null>(null);
  const [expanded, setExpanded]     = useState<string | null>(null);
  const [actionLoading, setActionLoading] = useState<string | null>(null);
  const mountedRef = useRef(true);

  const loadLicenses = useCallback(async () => {
    setLoading(true);
    const { data } = await supabase
      .from('aippietax_active_licenses')
      .select('id,license_key,owner_name,owner_email,license_type,plan,max_seats,used_seats,status,expires_at,issued_at,notes')
      .order('issued_at', { ascending: false })
      .limit(200);
    if (mountedRef.current) {
      setLicenses((data ?? []) as LicenseRecord[]);
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    mountedRef.current = true;
    loadLicenses();
    return () => { mountedRef.current = false; };
  }, [loadLicenses]);

  const handleCreate = async () => {
    if (!form.owner_name.trim()) { setFormErr('Owner name is required.'); return; }
    if (!form.owner_email.trim() || !form.owner_email.includes('@')) {
      setFormErr('Valid owner email is required.'); return;
    }
    setFormErr('');
    setSaving(true);

    const key = generateLicenseKey();
    const expires_at = form.expires_months > 0
      ? new Date(Date.now() + form.expires_months * 30 * 24 * 3600 * 1000).toISOString()
      : null;

    const { error } = await supabase.from('aippietax_active_licenses').insert({
      license_key:   key,
      owner_name:    form.owner_name.trim(),
      owner_email:   form.owner_email.trim().toLowerCase(),
      license_type:  form.license_type,
      plan:          form.plan,
      max_seats:     form.max_seats,
      expires_at,
      issued_by:     'admin',
      notes:         form.notes.trim(),
    });

    setSaving(false);
    if (!mountedRef.current) return;
    if (error) { setFormErr('Failed to create license: ' + error.message); return; }
    setCreating(false);
    setForm(BLANK_FORM);
    await loadLicenses();
  };

  const handleStatusChange = async (id: string, newStatus: string) => {
    setActionLoading(id);
    await supabase
      .from('aippietax_active_licenses')
      .update({ status: newStatus })
      .eq('id', id);
    if (mountedRef.current) {
      setActionLoading(null);
      await loadLicenses();
    }
  };

  const handleExpandSeats = async (id: string, current: number) => {
    const input = window.prompt(`Current max seats: ${current}\nEnter new max seats:`);
    if (!input) return;
    const n = parseInt(input, 10);
    if (isNaN(n) || n < 1) return;
    setActionLoading(id);
    await supabase
      .from('aippietax_active_licenses')
      .update({ max_seats: n })
      .eq('id', id);
    if (mountedRef.current) {
      setActionLoading(null);
      await loadLicenses();
    }
  };

  const handleCopy = (key: string, id: string) => {
    navigator.clipboard.writeText(key).catch(() => {});
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const filtered = licenses.filter(l =>
    search.trim() === '' ||
    l.license_key.includes(search.toUpperCase()) ||
    l.owner_name.toLowerCase().includes(search.toLowerCase()) ||
    l.owner_email.toLowerCase().includes(search.toLowerCase())
  );

  const stats = {
    total:    licenses.length,
    active:   licenses.filter(l => l.status === 'active').length,
    revoked:  licenses.filter(l => l.status === 'revoked').length,
    seats:    licenses.reduce((s, l) => s + l.used_seats, 0),
  };

  return (
    <div className="alv-overlay">
      <div className="alv-root">

        {/* ── Header ── */}
        <div className="alv-header">
          <div className="alv-header__left">
            <div className="alv-header__icon">
              <Key size={18} style={{ color: '#60a5fa' }} />
            </div>
            <div>
              <div className="alv-header__title">License Management</div>
              <div className="alv-header__sub">AIPPIETAX S.A. · IP Shield v201 · B2B Enterprise</div>
            </div>
          </div>
          <div className="alv-header__right">
            <button className="alv-btn-refresh" onClick={loadLicenses} disabled={loading}>
              <RefreshCw size={13} className={loading ? 'lg-spin' : ''} />
            </button>
            <button className="alv-btn-close" onClick={onClose} aria-label="Close">
              <X size={16} />
            </button>
          </div>
        </div>

        {/* ── Stats strip ── */}
        <div className="alv-stats">
          <div className="alv-stat">
            <Key size={12} style={{ color: '#60a5fa' }} />
            <span className="alv-stat__n">{stats.total}</span>
            <span className="alv-stat__label">Total</span>
          </div>
          <div className="alv-stat">
            <ShieldCheck size={12} style={{ color: '#4ade80' }} />
            <span className="alv-stat__n" style={{ color: '#4ade80' }}>{stats.active}</span>
            <span className="alv-stat__label">Active</span>
          </div>
          <div className="alv-stat">
            <Lock size={12} style={{ color: '#f87171' }} />
            <span className="alv-stat__n" style={{ color: '#f87171' }}>{stats.revoked}</span>
            <span className="alv-stat__label">Revoked</span>
          </div>
          <div className="alv-stat">
            <Users size={12} style={{ color: '#fbbf24' }} />
            <span className="alv-stat__n" style={{ color: '#fbbf24' }}>{stats.seats}</span>
            <span className="alv-stat__label">Active Seats</span>
          </div>
        </div>

        {/* ── Toolbar ── */}
        <div className="alv-toolbar">
          <div className="alv-search-wrap">
            <Search size={12} className="alv-search__icon" />
            <input
              className="alv-search"
              placeholder="Search by key, name, or email…"
              value={search}
              onChange={e => setSearch(e.target.value)}
            />
          </div>
          <button
            className="alv-btn-create"
            onClick={() => { setCreating(c => !c); setFormErr(''); }}
          >
            <Plus size={13} />
            New License
          </button>
        </div>

        {/* ── Create form ── */}
        {creating && (
          <div className="alv-create-form">
            <div className="alv-create-form__title">
              <Zap size={13} style={{ color: '#4ade80' }} />
              Generate New License Key
            </div>
            <div className="alv-create-form__grid">
              <label className="alv-label">
                Owner Name *
                <input
                  className="alv-input"
                  value={form.owner_name}
                  onChange={e => setForm(f => ({ ...f, owner_name: e.target.value }))}
                  placeholder="Acme Corp / John Smith"
                />
              </label>
              <label className="alv-label">
                Owner Email *
                <input
                  className="alv-input"
                  type="email"
                  value={form.owner_email}
                  onChange={e => setForm(f => ({ ...f, owner_email: e.target.value }))}
                  placeholder="admin@company.com"
                />
              </label>
              <label className="alv-label">
                License Type
                <select
                  className="alv-select"
                  value={form.license_type}
                  onChange={e => setForm(f => ({ ...f, license_type: e.target.value as LicenseType }))}
                >
                  <option value="individual">Individual</option>
                  <option value="b2b_team">B2B Team</option>
                  <option value="enterprise">Enterprise</option>
                  <option value="affiliate">Affiliate</option>
                  <option value="education">Education</option>
                </select>
              </label>
              <label className="alv-label">
                Plan
                <select
                  className="alv-select"
                  value={form.plan}
                  onChange={e => setForm(f => ({ ...f, plan: e.target.value as Plan }))}
                >
                  <option value="all">All Modules</option>
                  <option value="tax">AippieTax</option>
                  <option value="voice">AippieVoice</option>
                  <option value="trading">Trading Alpha</option>
                  <option value="doctor">Aippie Doctor</option>
                </select>
              </label>
              <label className="alv-label">
                Max Seats
                <input
                  className="alv-input"
                  type="number"
                  min={1}
                  max={10000}
                  value={form.max_seats}
                  onChange={e => setForm(f => ({ ...f, max_seats: Math.max(1, parseInt(e.target.value) || 1) }))}
                />
              </label>
              <label className="alv-label">
                Validity (months, 0 = perpetual)
                <input
                  className="alv-input"
                  type="number"
                  min={0}
                  max={120}
                  value={form.expires_months}
                  onChange={e => setForm(f => ({ ...f, expires_months: Math.max(0, parseInt(e.target.value) || 0) }))}
                />
              </label>
            </div>
            <label className="alv-label alv-label--full">
              Notes (internal)
              <textarea
                className="alv-textarea"
                rows={2}
                value={form.notes}
                onChange={e => setForm(f => ({ ...f, notes: e.target.value }))}
                placeholder="Partner details, contract reference, etc."
              />
            </label>
            {formErr && <div className="alv-form-err"><AlertTriangle size={11} />{formErr}</div>}
            <div className="alv-create-form__actions">
              <button className="alv-btn-cancel" onClick={() => setCreating(false)}>Cancel</button>
              <button className="alv-btn-generate" onClick={handleCreate} disabled={saving}>
                {saving
                  ? <><RefreshCw size={12} className="lg-spin" /> Generating…</>
                  : <><Key size={12} /> Generate License Key</>
                }
              </button>
            </div>
          </div>
        )}

        {/* ── License list ── */}
        <div className="alv-list">
          {loading && (
            <div className="alv-loading">
              <RefreshCw size={18} className="lg-spin" style={{ color: '#60a5fa' }} />
              <span>Loading licenses…</span>
            </div>
          )}

          {!loading && filtered.length === 0 && (
            <div className="alv-empty">
              <Key size={28} style={{ color: '#334155' }} />
              <span>No licenses found.</span>
              <span className="alv-empty__sub">Generate the first key using the button above.</span>
            </div>
          )}

          {!loading && filtered.map(lic => {
            const isExpanded = expanded === lic.id;
            const tc = TYPE_COLORS[lic.license_type as LicenseType] ?? '#94a3b8';
            const pc = PLAN_COLORS[lic.plan as Plan] ?? '#94a3b8';
            const sc = STATUS_COLORS[lic.status] ?? '#94a3b8';
            const seatPct = lic.max_seats > 0 ? Math.round((lic.used_seats / lic.max_seats) * 100) : 0;
            const isActing = actionLoading === lic.id;

            return (
              <div
                key={lic.id}
                className={`alv-row${lic.status !== 'active' ? ' alv-row--inactive' : ''}`}
                style={{ borderLeftColor: sc }}
              >
                <div className="alv-row__main" onClick={() => setExpanded(isExpanded ? null : lic.id)}>
                  <div className="alv-row__key-wrap">
                    <span className="alv-row__key">{lic.license_key}</span>
                    <button
                      className="alv-row__copy"
                      onClick={e => { e.stopPropagation(); handleCopy(lic.license_key, lic.id); }}
                      title="Copy key"
                    >
                      {copiedId === lic.id
                        ? <CheckCircle2 size={11} style={{ color: '#4ade80' }} />
                        : <Copy size={11} />
                      }
                    </button>
                  </div>

                  <div className="alv-row__owner">
                    <span className="alv-row__name">{lic.owner_name || '—'}</span>
                    <span className="alv-row__email">{lic.owner_email}</span>
                  </div>

                  <div className="alv-row__badges">
                    <span className="alv-badge" style={{ background: tc + '22', color: tc }}>
                      {lic.license_type.replace('_', ' ')}
                    </span>
                    <span className="alv-badge" style={{ background: pc + '22', color: pc }}>
                      {lic.plan}
                    </span>
                    <span className="alv-badge" style={{ background: sc + '22', color: sc }}>
                      {lic.status}
                    </span>
                  </div>

                  <div className="alv-row__seats">
                    <Users size={10} />
                    <span>{lic.used_seats}/{lic.max_seats}</span>
                    <div className="alv-seat-track">
                      <div className="alv-seat-fill" style={{ width: `${seatPct}%`, background: seatPct > 80 ? '#f87171' : '#4ade80' }} />
                    </div>
                  </div>

                  <button className="alv-row__expand">
                    {isExpanded ? <ChevronUp size={13} /> : <ChevronDown size={13} />}
                  </button>
                </div>

                {isExpanded && (
                  <div className="alv-row__detail">
                    <div className="alv-detail-grid">
                      <div className="alv-detail-item">
                        <span className="alv-detail-item__label">License ID</span>
                        <span className="alv-detail-item__val">{lic.id.slice(0, 8)}…</span>
                      </div>
                      <div className="alv-detail-item">
                        <span className="alv-detail-item__label">Expires</span>
                        <span className="alv-detail-item__val">{formatDate((lic as unknown as { expires_at: string | null }).expires_at)}</span>
                      </div>
                      <div className="alv-detail-item">
                        <span className="alv-detail-item__label">Seat Usage</span>
                        <span className="alv-detail-item__val">{seatPct}%</span>
                      </div>
                    </div>

                    <div className="alv-row__actions">
                      {lic.status === 'active' && (
                        <>
                          <button
                            className="alv-action-btn alv-action-btn--warn"
                            onClick={() => handleStatusChange(lic.id, 'suspended')}
                            disabled={isActing}
                          >
                            {isActing ? <RefreshCw size={10} className="lg-spin" /> : <AlertTriangle size={10} />}
                            Suspend
                          </button>
                          <button
                            className="alv-action-btn alv-action-btn--danger"
                            onClick={() => { if (confirm(`Revoke license ${lic.license_key}? This cannot be undone.`)) handleStatusChange(lic.id, 'revoked'); }}
                            disabled={isActing}
                          >
                            {isActing ? <RefreshCw size={10} className="lg-spin" /> : <Lock size={10} />}
                            Revoke
                          </button>
                          <button
                            className="alv-action-btn alv-action-btn--neutral"
                            onClick={() => handleExpandSeats(lic.id, lic.max_seats)}
                            disabled={isActing}
                          >
                            <Users size={10} />
                            Expand Seats
                          </button>
                        </>
                      )}
                      {(lic.status === 'suspended' || lic.status === 'revoked') && (
                        <button
                          className="alv-action-btn alv-action-btn--ok"
                          onClick={() => handleStatusChange(lic.id, 'active')}
                          disabled={isActing}
                        >
                          {isActing ? <RefreshCw size={10} className="lg-spin" /> : <ShieldCheck size={10} />}
                          Reactivate
                        </button>
                      )}
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>

        <div className="alv-footer">
          <Building2 size={8} />
          AIPPIETAX S.A. · License Ledger · v201 · GDPR compliant
        </div>
      </div>

      {/* V201: IP & Compliance Registry */}
      <IpAssetRegistry />
    </div>
  );
}
