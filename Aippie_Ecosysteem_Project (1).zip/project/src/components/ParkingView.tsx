/**
 * ParkingView — V78 AR Computer Vision + Ambient Audio Layer
 * AIPPIETAX S.A.
 *
 * AR Layer (getUserMedia):
 *   - Live camera feed rendered to <video> element
 *   - Canvas overlay draws animated CV detection boxes over
 *     pedestrians and vehicles (simulated tracking vectors)
 *   - Aippie avatar pip overlays live voice guidance + subtitles
 *
 * Ambient Audio Analytics (getUserMedia audio):
 *   - Web Audio AnalyserNode reads real microphone amplitude
 *   - Simulated classification cards: Traffic / Speech / Alarm / Quiet
 *
 * Parking slot data from Supabase real-time channel (unchanged).
 */
import { useCallback, useEffect, useRef, useState } from 'react';
import AippieVoiceOverlay from './AippieVoiceOverlay';
import FatigueCompanion from './FatigueCompanion';
import {
  MapPin, Car, Clock, RefreshCw, RadioTower, Navigation,
  Camera, CameraOff, Mic, MicOff, AlertCircle, Eye,
  Activity, Volume2, ShieldCheck, Building2, Radio
} from 'lucide-react';
import { supabase, type ParkingSlot, type CostaLocation, COSTA_LOCATIONS } from '../lib/supabase';
import SofiaTabShell from './SofiaTabShell';
import type { User } from '@supabase/supabase-js';
import { applyPremiumVoice, withVoicesReady, normalizeForTTS } from '../lib/ttsVoice';

type Props = { user: User | null };

const STREET_FREE_DURATION_MS = 10 * 60 * 1000;
const GREETING = normalizeForTTS(
  'Aippie is scanning the open space environment. Watch for green markers as cars disconnect via Bluetooth. Tap AR View to enable live computer vision tracking.'
);

// ─── CV entity types ──────────────────────────────────────────────────────────
type CvLabel = 'Pedestrian' | 'Vehicle' | 'Cyclist' | 'E-Scooter';
type CvEntity = {
  id: number; label: CvLabel;
  x: number; y: number; vx: number; vy: number;
  w: number; h: number; confidence: number;
  color: string; age: number;
};
const ENTITY_COLORS: Record<CvLabel, string> = {
  Pedestrian: '#38bdf8',
  Vehicle:    '#fbbf24',
  Cyclist:    '#4ade80',
  'E-Scooter':'#fb7185',
};

// ─── Audio classification ─────────────────────────────────────────────────────
type AudioClass = 'quiet' | 'traffic' | 'speech' | 'alarm';
const AUDIO_COLORS: Record<AudioClass, string> = {
  quiet: '#4ade80', traffic: '#fbbf24', speech: '#38bdf8', alarm: '#f87171',
};
const AUDIO_LABELS: Record<AudioClass, string> = {
  quiet:   'Quiet — low ambient noise',
  traffic: 'Traffic detected nearby',
  speech:  'Spoken speech detected',
  alarm:   'Alert signal detected',
};

// ─── Parking helpers ──────────────────────────────────────────────────────────
function occupancyColor(slot: ParkingSlot): 'green' | 'amber' | 'red' {
  if (slot.status === 'reporting') return 'amber';
  if (slot.status === 'full') return 'red';
  if (slot.slot_type === 'garage' && slot.total_spots && slot.vacant_spots !== null) {
    if (slot.vacant_spots / slot.total_spots < 0.15) return 'amber';
  }
  return 'green';
}

function timeLeft(reportedAt: string | null): string {
  if (!reportedAt) return '';
  const remaining = Math.max(0, STREET_FREE_DURATION_MS - (Date.now() - new Date(reportedAt).getTime()));
  const mins = Math.floor(remaining / 60000);
  const secs = Math.floor((remaining % 60000) / 1000);
  return `${mins}:${String(secs).padStart(2, '0')}`;
}

// ─── AR canvas overlay ────────────────────────────────────────────────────────
function ArOverlayCanvas({ entities, subtitle, speaking, active }: {
  entities: CvEntity[]; subtitle: string; speaking: boolean; active: boolean;
}) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const frameRef  = useRef<number>(0);
  const tickRef   = useRef(0);

  useEffect(() => {
    const canvas = canvasRef.current; if (!canvas) return;
    const ctx = canvas.getContext('2d'); if (!ctx) return;

    const draw = () => {
      tickRef.current++;
      const W = canvas.width, H = canvas.height;
      ctx.clearRect(0, 0, W, H);

      if (active) {
        entities.forEach(e => {
          const x = e.x * W, y = e.y * H;
          const bw = e.w * W, bh = e.h * H;
          const alpha = 0.5 + 0.5 * (e.confidence / 100);

          // Dashed bounding box
          ctx.strokeStyle = e.color + Math.round(alpha * 255).toString(16).padStart(2, '0');
          ctx.lineWidth = 1.5;
          ctx.setLineDash([4, 3]);
          ctx.strokeRect(x - bw / 2, y - bh / 2, bw, bh);
          ctx.setLineDash([]);

          // Corner brackets
          const cs = Math.min(bw, bh) * 0.22;
          ctx.strokeStyle = e.color;
          ctx.lineWidth = 2;
          ([[x-bw/2,y-bh/2,1,1],[x+bw/2,y-bh/2,-1,1],[x-bw/2,y+bh/2,1,-1],[x+bw/2,y+bh/2,-1,-1]] as [number,number,number,number][])
            .forEach(([cx,cy,dx,dy]) => {
              ctx.beginPath();
              ctx.moveTo(cx+dx*cs,cy); ctx.lineTo(cx,cy); ctx.lineTo(cx,cy+dy*cs);
              ctx.stroke();
            });

          // Label chip
          ctx.font = 'bold 9px system-ui';
          const lbl = `${e.label} ${Math.round(e.confidence)}%`;
          const tw = ctx.measureText(lbl).width + 8;
          const chipY = y - bh / 2 - 14;
          ctx.fillStyle = e.color + 'cc';
          ctx.beginPath(); ctx.roundRect(x - bw/2, chipY, tw, 13, 3); ctx.fill();
          ctx.fillStyle = '#050a12';
          ctx.fillText(lbl, x - bw/2 + 4, chipY + 9.5);

          // Centre tracking dot
          ctx.beginPath(); ctx.arc(x, y, 3, 0, Math.PI*2);
          ctx.fillStyle = e.color; ctx.fill();
        });

        // HUD
        ctx.font = '8px monospace';
        ctx.fillStyle = 'rgba(52,211,153,0.75)';
        ctx.fillText('36.5271°N  4.9230°W  ·  AR LIVE', 6, 14);
        ctx.textAlign = 'right';
        ctx.font = '8px system-ui';
        ctx.fillStyle = 'rgba(100,116,139,0.8)';
        ctx.fillText(`${entities.length} entities`, W-6, 14);
        ctx.textAlign = 'left';

        // Subtitle strip at bottom
        if (subtitle && speaking) {
          ctx.fillStyle = 'rgba(5,10,18,0.78)';
          ctx.fillRect(0, H-22, W, 22);
          ctx.font = 'bold 11px system-ui';
          ctx.fillStyle = '#e2e8f0';
          ctx.textAlign = 'center';
          ctx.fillText(subtitle, W/2, H-8);
          ctx.textAlign = 'left';
        }
      }

      frameRef.current = requestAnimationFrame(draw);
    };

    frameRef.current = requestAnimationFrame(draw);
    return () => cancelAnimationFrame(frameRef.current);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [entities, subtitle, speaking, active]);

  return <canvas ref={canvasRef} width={320} height={240} className="ar-overlay-canvas" aria-hidden="true" />;
}

// ─── Word subtitle hook ───────────────────────────────────────────────────────
function useWordSubtitle(text: string, active: boolean) {
  const [sub, setSub] = useState('');
  const tmr = useRef<ReturnType<typeof setInterval> | null>(null);
  const idx  = useRef(0);
  useEffect(() => {
    if (tmr.current) { clearInterval(tmr.current); tmr.current = null; }
    setSub('');
    if (!active || !text.trim()) return;
    const words = text.split(/\s+/);
    idx.current = 0;
    tmr.current = setInterval(() => {
      idx.current++;
      setSub(words.slice(Math.max(0, idx.current - 8), idx.current).join(' '));
      if (idx.current >= words.length && tmr.current) { clearInterval(tmr.current); tmr.current = null; }
    }, 380);
    return () => { if (tmr.current) { clearInterval(tmr.current); tmr.current = null; } };
  }, [text, active]);
  return sub;
}

// ─── Main component ───────────────────────────────────────────────────────────
export default function ParkingView({ user }: Props) {
  // parking data
  const [slots,     setSlots]     = useState<ParkingSlot[]>([]);
  const [location,  setLocation]  = useState<CostaLocation>('Fuengirola');
  const [filter,    setFilter]    = useState<'all' | 'garage' | 'street'>('all');
  const [reporting, setReporting] = useState<string | null>(null);
  const [loading,   setLoading]   = useState(true);
  const [,          setTick]      = useState(0);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  // AR camera
  const [arActive,  setArActive]  = useState(false);
  const [arError,   setArError]   = useState<string | null>(null);
  const [entities,  setEntities]  = useState<CvEntity[]>([]);
  const videoRef    = useRef<HTMLVideoElement>(null);
  const streamRef   = useRef<MediaStream | null>(null);
  const cvTimerRef  = useRef<ReturnType<typeof setInterval> | null>(null);
  const entityIdRef = useRef(0);

  // audio analytics
  const [audioActive, setAudioActive] = useState(false);
  const [audioLevel,  setAudioLevel]  = useState(0);
  const [audioClass,  setAudioClass]  = useState<AudioClass>('quiet');
  const [audioError,  setAudioError]  = useState<string | null>(null);
  const audioCtxRef   = useRef<AudioContext | null>(null);
  const analyserRef   = useRef<AnalyserNode | null>(null);
  const audioStreamRef= useRef<MediaStream | null>(null);
  const audioFrameRef = useRef<number>(0);

  // Aippie guidance
  const [speaking,     setSpeaking]     = useState(false);
  const [guidanceText, setGuidanceText] = useState('');
  const subtitle = useWordSubtitle(guidanceText, speaking);

  // ── Parking data ──────────────────────────────────────────────────────────
  const fetchSlots = useCallback(async () => {
    const { data } = await supabase
      .from('aippie_parking_slots').select('*')
      .eq('location', location).order('slot_type', { ascending: false });
    if (data) setSlots(data as ParkingSlot[]);
    setLoading(false);
  }, [location]);

  useEffect(() => {
    setLoading(true);
    fetchSlots();
    const ch = supabase.channel(`parking-${location}`)
      .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'aippie_parking_slots' },
        (payload) => setSlots(prev => prev.map(s =>
          s.id === (payload.new as ParkingSlot).id ? payload.new as ParkingSlot : s)))
      .subscribe();
    return () => { supabase.removeChannel(ch); };
  }, [location, fetchSlots]);

  useEffect(() => {
    timerRef.current = setInterval(() => setTick(t => t + 1), 1000);
    return () => { if (timerRef.current) clearInterval(timerRef.current); };
  }, []);

  // ── AR camera ────────────────────────────────────────────────────────────
  const speakGuidance = useCallback((text: string) => {
    if (!('speechSynthesis' in window)) return;
    window.speechSynthesis.cancel();
    setGuidanceText(text);
    const fire = () => {
      const u = new SpeechSynthesisUtterance(normalizeForTTS(text));
      u.pitch = 1.1; u.rate = 0.93;
      applyPremiumVoice(u);
      u.onstart = () => setSpeaking(true);
      u.onend   = () => setSpeaking(false);
      u.onerror = () => setSpeaking(false);
      window.speechSynthesis.speak(u);
    };
    withVoicesReady(fire);
  }, []);

  const startCvSimulation = useCallback(() => {
    if (cvTimerRef.current) clearInterval(cvTimerRef.current);
    const LABELS: CvLabel[] = ['Pedestrian', 'Vehicle', 'Cyclist', 'E-Scooter'];
    cvTimerRef.current = setInterval(() => {
      setEntities(prev => {
        let next = prev.map(e => ({
          ...e,
          x: e.x + e.vx,
          y: e.y + e.vy,
          age: e.age + 1,
          confidence: Math.max(60, Math.min(99, e.confidence + (Math.random()-0.5)*3)),
        })).filter(e => e.x > -0.15 && e.x < 1.15 && e.y > -0.15 && e.y < 1.15 && e.age < 200);

        if (next.length < 6 && Math.random() < 0.14) {
          const label = LABELS[Math.floor(Math.random() * LABELS.length)];
          const fromLeft = Math.random() > 0.5;
          next = [...next, {
            id: entityIdRef.current++,
            label,
            x: fromLeft ? -0.05 : 1.05,
            y: 0.28 + Math.random() * 0.48,
            vx: (fromLeft ? 1 : -1) * (0.003 + Math.random() * 0.006),
            vy: (Math.random()-0.5) * 0.002,
            w: label === 'Vehicle' ? 0.22 : 0.09,
            h: label === 'Vehicle' ? 0.12 : 0.18,
            confidence: 75 + Math.random() * 20,
            color: ENTITY_COLORS[label],
            age: 0,
          }];
        }
        return next;
      });
    }, 40);
  }, []);

  const startAr = useCallback(async () => {
    setArError(null);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment', width: { ideal: 640 }, height: { ideal: 480 } },
      });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        await videoRef.current.play();
      }
      setArActive(true);
      startCvSimulation();
      speakGuidance('AR environment mapping active. I can see the street. Watch for blue boxes around pedestrians and yellow boxes around vehicles.');
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err);
      setArError(
        msg.includes('denied') || msg.includes('NotAllowed')
          ? 'Camera permission denied. Allow camera access and retry.'
          : `Camera error: ${msg}`
      );
    }
  }, [startCvSimulation, speakGuidance]);

  const stopAr = useCallback(() => {
    streamRef.current?.getTracks().forEach(t => t.stop());
    streamRef.current = null;
    if (videoRef.current) videoRef.current.srcObject = null;
    if (cvTimerRef.current) clearInterval(cvTimerRef.current);
    setArActive(false);
    setEntities([]);
    window.speechSynthesis?.cancel();
    setSpeaking(false);
  }, []);

  // ── Audio analytics ───────────────────────────────────────────────────────
  const startAudio = useCallback(async () => {
    setAudioError(null);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      audioStreamRef.current = stream;
      const ctx = new AudioContext();
      audioCtxRef.current = ctx;
      const analyser = ctx.createAnalyser();
      analyser.fftSize = 256;
      analyserRef.current = analyser;
      ctx.createMediaStreamSource(stream).connect(analyser);
      setAudioActive(true);
      const data = new Uint8Array(analyser.frequencyBinCount);
      const tick = () => {
        analyser.getByteFrequencyData(data);
        const avg = data.reduce((a, b) => a + b, 0) / data.length;
        const level = Math.min(100, Math.round((avg / 128) * 100));
        setAudioLevel(level);
        setAudioClass(level < 12 ? 'quiet' : level < 30 ? 'traffic' : level < 55 ? 'speech' : 'alarm');
        audioFrameRef.current = requestAnimationFrame(tick);
      };
      audioFrameRef.current = requestAnimationFrame(tick);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err);
      setAudioError(
        msg.includes('denied') || msg.includes('NotAllowed')
          ? 'Microphone permission denied.'
          : `Audio error: ${msg}`
      );
    }
  }, []);

  const stopAudio = useCallback(() => {
    cancelAnimationFrame(audioFrameRef.current);
    audioCtxRef.current?.close();
    audioStreamRef.current?.getTracks().forEach(t => t.stop());
    audioStreamRef.current = null;
    audioCtxRef.current = null;
    analyserRef.current = null;
    setAudioActive(false);
    setAudioLevel(0);
    setAudioClass('quiet');
  }, []);

  // Speak on notable audio class change
  const prevAudioClassRef = useRef<AudioClass>('quiet');
  useEffect(() => {
    if (!audioActive) return;
    if (audioClass !== prevAudioClassRef.current) {
      prevAudioClassRef.current = audioClass;
      if (audioClass === 'speech') speakGuidance('Speech detected in the environment. Filtering ambient vocal audio.');
      if (audioClass === 'alarm')  speakGuidance('Alert signal detected nearby. Please be aware of your surroundings.');
    }
  }, [audioClass, audioActive, speakGuidance]);

  useEffect(() => {
    return () => {
      stopAr();
      stopAudio();
      window.speechSynthesis?.cancel();
    };
  }, [stopAr, stopAudio]);

  // ── Parking actions ───────────────────────────────────────────────────────
  const reportLeaving = async (slot: ParkingSlot) => {
    if (!user || reporting) return;
    setReporting(slot.id);
    await supabase.from('aippie_parking_slots').update({
      status: 'reporting', reported_free_at: new Date().toISOString(),
      reported_by: user.id, updated_at: new Date().toISOString(),
    }).eq('id', slot.id);
    // Contextual voice: navigate user to the freeing spot
    speakGuidance(`Bluetooth disconnect detected at ${slot.name}. A parking spot is freeing up now. Navigate to ${slot.name} immediately. The slot will remain available for 10 minutes before the timer expires. I have highlighted the spot on the live map.`);
    setTimeout(async () => {
      await supabase.from('aippie_parking_slots').update({
        status: 'available', reported_free_at: null, reported_by: null,
        updated_at: new Date().toISOString(),
      }).eq('id', slot.id);
    }, STREET_FREE_DURATION_MS);
    setReporting(null);
  };

  const visible    = slots.filter(s => filter === 'all' || s.slot_type === filter);
  const garages    = visible.filter(s => s.slot_type === 'garage');
  const streets    = visible.filter(s => s.slot_type === 'street');
  const availCount = slots.filter(s => s.status === 'available' || s.status === 'reporting').length;
  const fullCount  = slots.filter(s => s.status === 'full').length;

  return (
    <SofiaTabShell
      greeting={GREETING}
      serviceLabel="AippieParking · AR Vision · v86"
      trustLine="AIPPIETAX S.A. · v86 · Costa del Sol · 100% Free"
      speakingText={guidanceText}
      isSpeaking={speaking}
    >
      <div className="sts-parking-overlay">

        {/* ── AR Computer Vision section ── */}
        <div className="ar-section">
          <div className="ar-section__head">
            <Eye size={13} style={{ color: '#38bdf8' }} />
            <span>AR Computer Vision — Open Space Mapping</span>
            <span className="ar-free-badge">FREE</span>
          </div>

          <div className="ar-viewport">
            <video
              ref={videoRef}
              className={`ar-video${arActive ? ' ar-video--active' : ''}`}
              playsInline
              muted
              aria-label="AR camera feed"
            />
            <ArOverlayCanvas
              entities={arActive ? entities : []}
              subtitle={subtitle}
              speaking={speaking}
              active={arActive}
            />
            {/* Aippie omnipresent avatar PiP */}
            {arActive && (
              <div className={`ar-avatar-pip${speaking ? ' ar-avatar-pip--speaking' : ''}`}>
                <img
                  src="/Jouw_alineatekst_(2).png"
                  alt="Aippie"
                  className="ar-avatar-pip__img"
                />
                {speaking && <div className="ar-avatar-pip__ring" />}
                <div className="ar-avatar-pip__e2ee">
                  <span className={`ar-pip-dot${speaking ? ' ar-pip-dot--live' : ''}`} />
                  AR
                </div>
              </div>
            )}
            {!arActive && (
              <div className="ar-placeholder">
                <Camera size={24} style={{ color: '#334155' }} />
                <span>Camera inactive</span>
                <span className="ar-placeholder__sub">Tap AR View to enable live CV mapping</span>
              </div>
            )}
          </div>

          {arError && (
            <div className="ar-error-row">
              <AlertCircle size={11} /><span>{arError}</span>
            </div>
          )}

          <div className="ar-controls">
            <button
              className={`ar-btn${arActive ? ' ar-btn--stop' : ' ar-btn--start'}`}
              onClick={arActive ? stopAr : startAr}
              style={arActive
                ? { borderColor: '#f87171', color: '#f87171' }
                : { borderColor: '#38bdf8', color: '#38bdf8' }
              }
            >
              {arActive ? <><CameraOff size={13} /> Stop AR</> : <><Camera size={13} /> AR View</>}
            </button>
            {arActive && (
              <div className="ar-entity-legend">
                {(Object.entries(ENTITY_COLORS) as [CvLabel, string][]).map(([label, color]) => (
                  <span key={label} className="ar-legend-item">
                    <span className="ar-legend-dot" style={{ background: color }} />{label}
                  </span>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* ── Ambient Audio Analytics ── */}
        <div className="ar-audio-section">
          <div className="ar-section__head">
            <Mic size={13} style={{ color: '#4ade80' }} />
            <span>Ambient Sound Analytics</span>
            {audioActive && (
              <span className="ar-live-badge"
                style={{ color: AUDIO_COLORS[audioClass], borderColor: AUDIO_COLORS[audioClass] + '44' }}>
                {audioClass.toUpperCase()}
              </span>
            )}
          </div>

          {audioActive ? (
            <div className="ar-audio-panel">
              <div className="ar-noise-meter">
                <Volume2 size={10} style={{ color: AUDIO_COLORS[audioClass] }} />
                <div className="ar-noise-track">
                  <div className="ar-noise-fill" style={{
                    width: `${audioLevel}%`,
                    background: AUDIO_COLORS[audioClass],
                    transition: 'width 0.08s ease, background 0.3s',
                  }} />
                </div>
                <span className="ar-noise-pct" style={{ color: AUDIO_COLORS[audioClass] }}>{audioLevel}%</span>
              </div>

              <div className="ar-audio-card"
                style={{ borderColor: AUDIO_COLORS[audioClass]+'44', background: AUDIO_COLORS[audioClass]+'0d' }}>
                <Activity size={12} style={{ color: AUDIO_COLORS[audioClass], flexShrink: 0 }} />
                <div>
                  <div className="ar-audio-card__class" style={{ color: AUDIO_COLORS[audioClass] }}>
                    {audioClass.charAt(0).toUpperCase()+audioClass.slice(1)} Detected
                  </div>
                  <div className="ar-audio-card__desc">{AUDIO_LABELS[audioClass]}</div>
                </div>
              </div>

              {speaking && subtitle && (
                <div className="ar-subtitle-strip">
                  <Radio size={9} style={{ color: '#38bdf8', flexShrink: 0 }} />
                  <span>{subtitle}</span>
                </div>
              )}

              <button className="ar-btn ar-btn--stop" onClick={stopAudio}
                style={{ borderColor: '#f87171', color: '#f87171', marginTop: 6 }}>
                <MicOff size={13} /> Stop Audio
              </button>
            </div>
          ) : (
            <div className="ar-audio-inactive">
              {audioError && (
                <div className="ar-error-row" style={{ marginBottom: 6 }}>
                  <AlertCircle size={11} /><span>{audioError}</span>
                </div>
              )}
              <button className="ar-btn ar-btn--start" onClick={startAudio}
                style={{ borderColor: '#4ade80', color: '#4ade80' }}>
                <Mic size={13} /> Start Audio Analytics
              </button>
              <span className="ar-audio-inactive__hint">
                Listens for traffic, speech, and alert signals in the open environment.
              </span>
            </div>
          )}
        </div>

        {/* ── Parking map & slot list (unchanged) ── */}
        <div className="parking-header" style={{ marginTop: 10 }}>
          <div className="parking-header__brand">
            <Car size={14} className="parking-header__icon" />
            <span className="parking-header__title">AippieParking · Live Slots</span>
          </div>
          <div className="parking-header__stats">
            <span className="parking-stat parking-stat--green">
              <span className="parking-stat__dot parking-stat__dot--green" />{availCount} Free
            </span>
            <span className="parking-stat parking-stat--red">
              <span className="parking-stat__dot parking-stat__dot--red" />{fullCount} Full
            </span>
          </div>
        </div>

        <div className="parking-location-tabs">
          {COSTA_LOCATIONS.map(loc => (
            <button key={loc}
              className={`parking-location-tab${location === loc ? ' parking-location-tab--active' : ''}`}
              onClick={() => setLocation(loc)}>
              <Navigation size={10} />{loc}
            </button>
          ))}
        </div>

        <div className="parking-filter-row">
          {(['all', 'garage', 'street'] as const).map(f => (
            <button key={f}
              className={`parking-filter-btn${filter === f ? ' parking-filter-btn--active' : ''}`}
              onClick={() => setFilter(f)}>
              {f === 'all' ? 'All' : f === 'garage' ? 'Garages' : 'Street'}
            </button>
          ))}
          <button className="parking-refresh-btn" onClick={fetchSlots}><RefreshCw size={12} /></button>
        </div>

        <div className="parking-map">
          <div className="parking-map__overlay-label">
            <MapPin size={10} /> Costa del Sol — {location}
          </div>
          {loading ? (
            <div className="parking-map__loading"><span className="modal__spinner" /></div>
          ) : (
            <div className="parking-map__pins">
              {visible.map(slot => {
                const col = occupancyColor(slot);
                return (
                  <div key={slot.id} className={`map-pin map-pin--${col}`}
                    style={{
                      left: `${((slot.lng + 4.97) / 0.38) * 100}%`,
                      top:  `${((36.61 - slot.lat) / 0.13) * 100}%`,
                    }}
                    title={slot.name}>
                    <span className="map-pin__dot" />
                    {slot.slot_type === 'garage' && slot.vacant_spots !== null && (
                      <span className="map-pin__label">{slot.vacant_spots}</span>
                    )}
                    {slot.status === 'reporting' && (
                      <span className="map-pin__label map-pin__label--timer">
                        {timeLeft(slot.reported_free_at)}
                      </span>
                    )}
                  </div>
                );
              })}
            </div>
          )}
          <div className="parking-map__legend">
            <span className="legend-item"><span className="legend-dot legend-dot--green" /> Available</span>
            <span className="legend-item"><span className="legend-dot legend-dot--amber" /> Leaving soon</span>
            <span className="legend-item"><span className="legend-dot legend-dot--red" /> Full</span>
          </div>
        </div>

        <div className="parking-list">
          {(filter === 'all' || filter === 'garage') && garages.length > 0 && (
            <>
              <div className="parking-list__section-label"><Car size={10} /> Public Garages</div>
              {garages.map(slot => {
                const col = occupancyColor(slot);
                const pct = slot.total_spots && slot.vacant_spots !== null
                  ? Math.round((1 - slot.vacant_spots / slot.total_spots) * 100) : null;
                return (
                  <div key={slot.id} className={`parking-card parking-card--${col}`}>
                    <div className="parking-card__left">
                      <div className={`parking-card__dot parking-card__dot--${col}`} />
                      <div className="parking-card__info">
                        <span className="parking-card__name">{slot.name}</span>
                        <span className="parking-card__meta">{slot.total_spots} total{pct !== null && ` · ${pct}% full`}</span>
                      </div>
                    </div>
                    <div className="parking-card__right">
                      {slot.status === 'full'
                        ? <span className="parking-badge parking-badge--red">FULL</span>
                        : <span className="parking-badge parking-badge--green">{slot.vacant_spots} free</span>
                      }
                    </div>
                  </div>
                );
              })}
            </>
          )}

          {(filter === 'all' || filter === 'street') && streets.length > 0 && (
            <>
              <div className="parking-list__section-label" style={{ marginTop: garages.length > 0 ? '10px' : 0 }}>
                <RadioTower size={10} /> Street Parking
              </div>
              {streets.map(slot => {
                const col     = occupancyColor(slot);
                const leaving = slot.status === 'reporting';
                const tl      = leaving ? timeLeft(slot.reported_free_at) : null;
                return (
                  <div key={slot.id} className={`parking-card parking-card--${col}`}>
                    <div className="parking-card__left">
                      <div className={`parking-card__dot parking-card__dot--${col}`} />
                      <div className="parking-card__info">
                        <span className="parking-card__name">{slot.name}</span>
                        <span className="parking-card__meta">
                          {leaving ? `Spot freeing up — ${tl} remaining` : 'Street spot'}
                        </span>
                      </div>
                    </div>
                    <div className="parking-card__right">
                      {leaving ? (
                        <span className="parking-badge parking-badge--amber"><Clock size={9} /> {tl}</span>
                      ) : slot.status === 'full' ? (
                        <span className="parking-badge parking-badge--red">TAKEN</span>
                      ) : user ? (
                        <button className="parking-leaving-btn" onClick={() => reportLeaving(slot)} disabled={!!reporting}>
                          {reporting === slot.id ? <span className="modal__spinner modal__spinner--sm" /> : "I'm leaving"}
                        </button>
                      ) : (
                        <span className="parking-badge parking-badge--green">FREE</span>
                      )}
                    </div>
                  </div>
                );
              })}
            </>
          )}

          {!loading && visible.length === 0 && (
            <div className="parking-empty">No parking data for this location.</div>
          )}
        </div>

        <div className="ar-security-footer">
          <ShieldCheck size={10} style={{ color: '#4ade80' }} />
          <span>Camera · Microphone · GPS — processed locally · never stored · GDPR compliant</span>
          <Building2 size={9} style={{ color: '#334155' }} />
        </div>

        <FatigueCompanion />
        <AippieVoiceOverlay context="parking" />

      </div>
    </SofiaTabShell>
  );
}
