// @ts-nocheck
import { useState } from 'react';
import { Lock, Check, Zap, Globe, Building2, Gavel, ShieldCheck, ChevronRight, Mic } from 'lucide-react';
import { PLAN_CONFIG, splitPrice, type PlanTier } from '../lib/supabase';

type Props = {
  onSubscribe: () => void;
};

const PLAN_TIERS: PlanTier[] = ['turista_basic', 'premium_jurado', 'corporate_b2b'];

const PLAN_ICONS: Record<string, React.FC<{ size: number; className?: string }>> = {
  turista_basic:  Globe,
  corporate_b2b:  Building2,
  premium_jurado: Gavel,
};

const PLAN_HIGHLIGHTS: Record<string, string[]> = {
  turista_basic:  ['40 min / month included', 'EN ⇄ ES · NL ⇄ ES corridors', '€0.50/min overage', '24/7 AI fallback'],
  premium_jurado: ['60 min / month included', 'Certified court interpreters', 'Jurado-stamped records', 'Encrypted call archive'],
  corporate_b2b:  ['200 min / month included', 'All language corridors', 'Priority dispatch queue', 'Dedicated support'],
};

export default function VoicePaywall({ onSubscribe }: Props) {
  const [selected, setSelected] = useState<PlanTier>('turista_basic');
  const cfg = PLAN_CONFIG[selected];
  const { whole, cents } = splitPrice(cfg.price);

  return (
    <div className="vpw-root">
      <div className="vpw-bg" />

      {/* Lock hero */}
      <div className="vpw-hero">
        <div className="vpw-hero__icon-ring">
          <Lock size={28} className="vpw-hero__lock" />
        </div>
        <div className="vpw-hero__label">
          <Mic size={11} />
          <span>AippieVoice</span>
        </div>
        <h1 className="vpw-hero__title">AippieVoice Flat-Rate</h1>
        <p className="vpw-hero__sub">
          Real-time certified interpretation across Spain.<br />
          Unlock live audio channels with a single subscription.
        </p>
      </div>

      {/* Price hero for selected plan */}
      <div className="vpw-price-hero">
        <span className="vpw-price-hero__cur">€</span>
        <span className="vpw-price-hero__whole">{whole}</span>
        <span className="vpw-price-hero__cents">.{cents}</span>
        <span className="vpw-price-hero__period">/month</span>
      </div>

      {/* Plan selector */}
      <div className="vpw-plans">
        {PLAN_TIERS.map(tier => {
          const c    = PLAN_CONFIG[tier];
          const Icon = PLAN_ICONS[tier];
          const sel  = tier === selected;
          const { whole: w, cents: d } = splitPrice(c.price);
          return (
            <button
              key={tier}
              className={`vpw-plan${sel ? ' vpw-plan--selected' : ''}`}
              onClick={() => setSelected(tier)}
            >
              {sel && <span className="vpw-plan__check"><Check size={10} /></span>}
              <div className={`vpw-plan__icon vpw-plan__icon--${tier}`}>
                <Icon size={14} />
              </div>
              <div className="vpw-plan__name">{c.label}</div>
              <div className="vpw-plan__price">
                <span className="vpw-plan__cur">€</span>
                <span className="vpw-plan__amount">{w}</span>
                <span className="vpw-plan__dec">.{d}</span>
              </div>
              <div className="vpw-plan__mins">{c.includedMinutes} min</div>
            </button>
          );
        })}
      </div>

      {/* Feature highlights for selected plan */}
      <div className="vpw-features">
        {PLAN_HIGHLIGHTS[selected].map(f => (
          <div key={f} className="vpw-feature">
            <span className="vpw-feature__dot"><Check size={10} /></span>
            <span>{f}</span>
          </div>
        ))}
      </div>

      {/* CTA */}
      <button className="vpw-cta" onClick={onSubscribe}>
        <Zap size={15} />
        Unlock AippieVoice — €{cfg.price.toFixed(2)}/mo
        <ChevronRight size={15} />
      </button>

      <p className="vpw-cancel">Cancel anytime · No hidden fees</p>

      <div className="vpw-trust">
        <ShieldCheck size={11} />
        <span>256-bit SSL · GDPR · AIPPIETAX S.A.</span>
      </div>
    </div>
  );
}
