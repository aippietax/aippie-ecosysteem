import { useCallback, useEffect, useRef, useState } from 'react';
import { X, Coins, Users, Zap, Lock, MessageCircle } from 'lucide-react';
import { supabase } from '../lib/supabase';

// ══════════════════════════════════════════════════════════════════════════════
//  AIPPIE ISOMETRIC OPEN WORLD
//  True 2.5D isometric engine — better than Second Life / Roblox / Decentraland
//  Features they don't have:
//  ✦ Every building = a live, working professional tool
//  ✦ SOFIA AI companion gives real-time zone tips
//  ✦ Zone-based passive APC income (Trading = 4×)
//  ✦ E2EE shield auto-activates in Secure Vault district
//  ✦ One-tap business card for any player
//  ✦ Neon cyberpunk aesthetic unique to Aippie brand
//  ✦ Day/night cycle with dynamic ambient light
//  ✦ Particle effects per zone (gold sparks, neon pulses, holo rain)
//  ✦ Flying drone traffic
// ══════════════════════════════════════════════════════════════════════════════

// ── Iso rendering constants ───────────────────────────────────────────────────
const TILE_W = 64, TILE_H = 32;     // iso tile size
const HW = TILE_W / 2, HH = TILE_H / 2; // 32, 16
const TILE_Z = 28;                  // px per height unit
const MAP_S = 24;                   // 24×24 tile grid
const P_SPEED = 0.09;               // tiles/frame
const CAM_LERP = 0.08;

// Tile type IDs
const T_VOID=0,T_GRASS=1,T_ROAD=2,T_WATER=3;
const T_BIZ=4,T_TRADE=5,T_VAULT=6,T_PLAZA=7,T_ACAD=8;

// ── World-to-screen ────────────────────────────────────────────────────────────
const ws = (wx:number, wy:number, wz:number, ox:number, oy:number) => ({
  x: ox + (wx - wy) * HW,
  y: oy + (wx + wy) * HH - wz * TILE_Z,
});

// ── Map generation ─────────────────────────────────────────────────────────────
function makeMap(): Uint8Array {
  const m = new Uint8Array(MAP_S * MAP_S).fill(T_GRASS);
  const fill = (x1:number,y1:number,x2:number,y2:number,t:number) => {
    for(let y=y1;y<=y2;y++) for(let x=x1;x<=x2;x++) {
      if(x>=0&&x<MAP_S&&y>=0&&y<MAP_S) m[y*MAP_S+x]=t;
    }
  };
  fill(1,1,MAP_S-2,7,T_BIZ);
  fill(0,9,5,17,T_VAULT);
  fill(7,9,16,17,T_PLAZA);
  fill(17,9,MAP_S-1,17,T_TRADE);
  fill(1,19,MAP_S-2,MAP_S-2,T_ACAD);
  fill(0,8,MAP_S-1,8,T_ROAD);
  fill(0,18,MAP_S-1,18,T_ROAD);
  fill(6,0,6,MAP_S-1,T_ROAD);
  fill(17,0,17,MAP_S-1,T_ROAD);
  fill(10,11,11,12,T_WATER);
  return m;
}
const MAP = makeMap();

// ── Building definitions ───────────────────────────────────────────────────────
interface IsoBldg {
  id:string; name:string; emoji:string;
  bx:number; by:number; bw:number; bd:number; bh:number;
  topHue:number; leftHue:number; rightHue:number; sat:number; lit:number;
  glowColor:string; action:string; desc:string;
}
const BLDGS: IsoBldg[] = [
  // Business District (y 1-7)
  { id:'b2b',        name:'B2B Hub',         emoji:'🏢', bx:1,  by:1,  bw:3,bd:2,bh:5, topHue:210,leftHue:210,rightHue:215,sat:75,lit:22, glowColor:'#38bdf8', action:'b2b',        desc:'Enterprise automation · B2B networks' },
  { id:'tax',        name:'Tax Office',      emoji:'📋', bx:6,  by:1,  bw:3,bd:2,bh:4, topHue:140,leftHue:140,rightHue:145,sat:70,lit:18, glowColor:'#22c55e', action:'tax',        desc:'AI tax suite & VAT' },
  { id:'legal',      name:'Legal Suite',     emoji:'⚖️', bx:11, by:1,  bw:3,bd:2,bh:4, topHue:25, leftHue:25, rightHue:30, sat:80,lit:20, glowColor:'#fb923c', action:'legal',      desc:'AI legal documents' },
  { id:'accounting', name:'Accounting',      emoji:'📊', bx:16, by:1,  bw:3,bd:2,bh:4, topHue:195,leftHue:195,rightHue:200,sat:75,lit:18, glowColor:'#60a5fa', action:'accounting', desc:'Autonomous accounting AI' },
  // Secure Vault (left)
  { id:'chat',       name:'SecureChat',      emoji:'🔒', bx:0,  by:9,  bw:2,bd:3,bh:3, topHue:0,  leftHue:0,  rightHue:5,  sat:70,lit:18, glowColor:'#ef4444', action:'securechat', desc:'E2EE encrypted messaging' },
  { id:'docvault',   name:'Doc Vault',       emoji:'🗄️', bx:0,  by:13, bw:2,bd:3,bh:3, topHue:350,leftHue:350,rightHue:355,sat:65,lit:15, glowColor:'#f87171', action:'docvault',   desc:'Private document storage' },
  // Plaza center
  { id:'games',      name:'Game Arena',      emoji:'🎮', bx:8,  by:9,  bw:3,bd:2,bh:3, topHue:50, leftHue:50, rightHue:55, sat:85,lit:25, glowColor:'#fcd34d', action:'games',      desc:'5 games · Earn APC' },
  { id:'wallet',     name:'APC Bank',        emoji:'💰', bx:12, by:9,  bw:2,bd:2,bh:4, topHue:135,leftHue:135,rightHue:140,sat:80,lit:22, glowColor:'#4ade80', action:'wallet',     desc:'Wallet · transfers · earn' },
  { id:'morning',    name:'Daily Brief',     emoji:'☀️', bx:15, by:9,  bw:2,bd:2,bh:3, topHue:45, leftHue:45, rightHue:50, sat:90,lit:28, glowColor:'#fbbf24', action:'morning',    desc:'AI morning briefing' },
  { id:'mail',       name:'Shield Mail',     emoji:'✉️', bx:8,  by:12, bw:2,bd:2,bh:3, topHue:215,leftHue:215,rightHue:220,sat:75,lit:18, glowColor:'#60a5fa', action:'aippiemail', desc:'Encrypted email system' },
  { id:'assistant',  name:'AI Assistant',    emoji:'🤖', bx:11, by:12, bw:2,bd:2,bh:3, topHue:280,leftHue:280,rightHue:285,sat:70,lit:18, glowColor:'#c084fc', action:'assistant',  desc:'AI voice assistant' },
  { id:'radar',      name:'Signal Radar',    emoji:'📡', bx:14, by:12, bw:2,bd:2,bh:3, topHue:195,leftHue:195,rightHue:200,sat:80,lit:20, glowColor:'#38bdf8', action:'signalradar',desc:'Live market signals' },
  // Trading Quarter (right) – tallest buildings
  { id:'trading',    name:'Trading Floor',   emoji:'📈', bx:18, by:9,  bw:4,bd:3,bh:7, topHue:45, leftHue:42, rightHue:47, sat:90,lit:28, glowColor:'#f59e0b', action:'alphatrade', desc:'Crypto & stocks live · 4× APC' },
  { id:'portfolio',  name:'Portfolio',       emoji:'💹', bx:18, by:13, bw:3,bd:2,bh:3, topHue:50, leftHue:50, rightHue:55, sat:85,lit:22, glowColor:'#fcd34d', action:'trading',    desc:'Portfolio management & analysis' },
  { id:'tournament', name:'Championship',    emoji:'🏆', bx:18, by:16, bw:3,bd:2,bh:3, topHue:25, leftHue:25, rightHue:30, sat:80,lit:22, glowColor:'#fb923c', action:'tournament', desc:'AI trading championship' },
  // Academy (bottom)
  { id:'academy',    name:'Academy',         emoji:'🎓', bx:2,  by:19, bw:3,bd:2,bh:3, topHue:270,leftHue:270,rightHue:275,sat:70,lit:18, glowColor:'#a78bfa', action:'academy',    desc:'AI learning & certificates' },
  { id:'videovault', name:'Video Vault',     emoji:'🎬', bx:7,  by:19, bw:3,bd:2,bh:3, topHue:250,leftHue:250,rightHue:255,sat:65,lit:15, glowColor:'#818cf8', action:'videovault', desc:'Private video library' },
  { id:'realestate', name:'Real Estate',     emoji:'🏗️', bx:12, by:19, bw:3,bd:2,bh:3, topHue:340,leftHue:340,rightHue:345,sat:70,lit:20, glowColor:'#fb7185', action:'realestate', desc:'Virtual & real estate' },
  { id:'reunion',    name:'Meeting Room',    emoji:'🤝', bx:17, by:19, bw:3,bd:2,bh:3, topHue:155,leftHue:155,rightHue:160,sat:70,lit:18, glowColor:'#34d399', action:'reunion',    desc:'Meeting & conference AI' },
];

// Which tiles each building occupies (for collision)
const BLDG_TILES = new Set<string>();
BLDGS.forEach(b => {
  for(let x=b.bx;x<b.bx+b.bw;x++) for(let y=b.by;y<b.by+b.bd;y++) BLDG_TILES.add(`${x},${y}`);
});

// Zone data
const ZONES = [
  { id:'plaza',    name:'Central Plaza',    tiles: (x:number,y:number) => x>=7&&x<=16&&y>=9&&y<=17, glow:'#22c55e', earnRate:1, bgHue:140 },
  { id:'business', name:'Business District',tiles: (x:number,y:number) => x>=1&&x<=22&&y>=1&&y<=7,  glow:'#38bdf8', earnRate:2, bgHue:210 },
  { id:'trading',  name:'Trading Quarter',  tiles: (x:number,y:number) => x>=17&&x<=23&&y>=9&&y<=17,glow:'#f59e0b', earnRate:4, bgHue:45  },
  { id:'academy',  name:'Academy Hall',     tiles: (x:number,y:number) => x>=1&&x<=23&&y>=19&&y<=22,glow:'#a78bfa', earnRate:1, bgHue:270 },
  { id:'vault',    name:'Secure Vault',     tiles: (x:number,y:number) => x>=0&&x<=5&&y>=9&&y<=17,  glow:'#ef4444', earnRate:2, bgHue:0   },
];

const getZone = (wx:number,wy:number) =>
  ZONES.find(z => z.tiles(Math.floor(wx), Math.floor(wy))) || null;

// ── Helpers ────────────────────────────────────────────────────────────────────
const clamp = (v:number,lo:number,hi:number) => Math.max(lo,Math.min(hi,v));
const dist2 = (ax:number,ay:number,bx:number,by:number) => (ax-bx)**2+(ay-by)**2;

// ── Particle ───────────────────────────────────────────────────────────────────
interface Particle { x:number;y:number;z:number;vx:number;vy:number;vz:number;life:number;maxLife:number;color:string;size:number; }

// ── Props ──────────────────────────────────────────────────────────────────────
interface Props {
  onClose:()=>void; onNavigate:(action:string)=>void;
  displayName:string; avatarColor:string; badge?:'none'|'gold'|'platinum';
}

export default function AippieOpenWorldView({ onClose, onNavigate, displayName, avatarColor, badge='none' }: Props) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const rafRef    = useRef(0);

  // Player iso-world position
  const px = useRef(11); const py = useRef(13);
  // Camera (origin offset from world to screen)
  const ox = useRef(0); const oy = useRef(0);
  // Input
  const keys = useRef({up:false,down:false,left:false,right:false});
  const joyRef = useRef<{dx:number;dy:number}|null>(null);
  const joyOrigin = useRef<{x:number;y:number}|null>(null);
  // Sofia
  const sofiaX = useRef(11); const sofiaY = useRef(11);
  const sofiaWp = useRef(0);
  const sofiaTip = useRef<{text:string;life:number}|null>(null);
  const sofiaTipTick = useRef(0);
  // Coins
  const coins = useRef<{id:number;x:number;y:number;val:number;age:number}[]>([]);
  const coinId = useRef(0);
  // Particles
  const particles = useRef<Particle[]>([]);
  // Other players
  const others = useRef<{id:string;x:number;y:number;name:string;color:string;badge:string}[]>([]);
  // Chat bubbles
  const bubbles = useRef<{text:string;x:number;y:number;z:number;life:number;color:string}[]>([]);
  // Drones
  const drones = useRef<{x:number;y:number;z:number;vx:number;vy:number;color:string}[]>([
    {x:5,y:3,z:4,vx:0.015,vy:0.005,color:'#38bdf8'},
    {x:18,y:5,z:5,vx:-0.012,vy:0.008,color:'#f59e0b'},
    {x:12,y:20,z:3.5,vx:0.010,vy:-0.010,color:'#a78bfa'},
  ]);

  const [zone, setZone] = useState<typeof ZONES[number]|null>(null);
  const [nearBldg, setNearBldg] = useState<IsoBldg|null>(null);
  const [apc, setApc] = useState(0);
  const [onlineCnt, setOnlineCnt] = useState(1);
  const [selPlayer, setSelPlayer] = useState<typeof others.current[number]|null>(null);
  const vw = useRef(0); const vh = useRef(0);

  const creditApc = useCallback(async (amount:number) => {
    const { data:{user} } = await supabase.auth.getUser();
    if (!user) return;
    await supabase.rpc('credit_apc', { p_user_id:user.id, p_amount:amount });
    setApc(a => a + amount);
  }, []);

  const spawnParticle = useCallback((wx:number,wy:number,wz:number,color:string,count=3) => {
    for(let i=0;i<count;i++) {
      particles.current.push({
        x:wx+(Math.random()-.5)*.5, y:wy+(Math.random()-.5)*.5, z:wz,
        vx:(Math.random()-.5)*.02, vy:(Math.random()-.5)*.02, vz:0.04+Math.random()*.06,
        life:60+Math.random()*60, maxLife:120, color, size:2+Math.random()*3,
      });
    }
  }, []);

  // Load data
  useEffect(() => {
    supabase.auth.getUser().then(({data:{user}}) => {
      if (!user) return;
      supabase.from('apc_wallets').select('balance_apc').eq('user_id',user.id).maybeSingle()
        .then(({data}) => { if (data) setApc(Math.floor(data.balance_apc)); });
    });
    supabase.from('workspace_3d_sessions').select('user_id,display_name,avatar_color,verified_type').limit(15)
      .then(({data}) => {
        if (!data) return;
        const o = data.map((r,i) => ({
          id:r.user_id, name:r.display_name||'User', color:r.avatar_color||'#38bdf8',
          badge:r.verified_type||'none',
          x: 7+Math.cos(i*(Math.PI*2/data.length))*4,
          y: 13+Math.sin(i*(Math.PI*2/data.length))*4,
        }));
        others.current = o;
        setOnlineCnt(o.length+1);
      });
    // Spawn initial coins
    for(let i=0;i<5;i++) spawnCoin();
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const spawnCoin = useCallback(() => {
    const cx = 7+Math.random()*10, cy = 9+Math.random()*8;
    if (BLDG_TILES.has(`${Math.floor(cx)},${Math.floor(cy)}`)) return;
    coins.current.push({id:++coinId.current, x:cx, y:cy, val:Math.random()<0.1?5:1, age:0});
    if (coins.current.length>10) coins.current.shift();
  }, []);

  useEffect(() => { const t=setInterval(spawnCoin,5000); return ()=>clearInterval(t); }, [spawnCoin]);

  useEffect(() => {
    const t = setInterval(() => {
      const z = getZone(px.current, py.current);
      if (z) creditApc(z.earnRate);
    }, 12000);
    return () => clearInterval(t);
  }, [creditApc]);

  // Keyboard
  useEffect(() => {
    const dn = (e:KeyboardEvent) => {
      if (e.key==='ArrowUp'||e.key==='w')    keys.current.up=true;
      if (e.key==='ArrowDown'||e.key==='s')  keys.current.down=true;
      if (e.key==='ArrowLeft'||e.key==='a')  keys.current.left=true;
      if (e.key==='ArrowRight'||e.key==='d') keys.current.right=true;
      if ((e.key==='Enter'||e.key==='e') && nearBldg) onNavigate(nearBldg.action);
    };
    const up = (e:KeyboardEvent) => {
      if (e.key==='ArrowUp'||e.key==='w')    keys.current.up=false;
      if (e.key==='ArrowDown'||e.key==='s')  keys.current.down=false;
      if (e.key==='ArrowLeft'||e.key==='a')  keys.current.left=false;
      if (e.key==='ArrowRight'||e.key==='d') keys.current.right=false;
    };
    window.addEventListener('keydown',dn); window.addEventListener('keyup',up);
    return () => { window.removeEventListener('keydown',dn); window.removeEventListener('keyup',up); };
  }, [nearBldg, onNavigate]);

  const onTouchStart = useCallback((e:React.TouchEvent) => {
    const r = canvasRef.current?.getBoundingClientRect(); if(!r) return;
    const t = e.touches[0];
    const cx=t.clientX-r.left, cy=t.clientY-r.top;
    if (cx < r.width*0.45 && cy > r.height*0.55) {
      joyOrigin.current = {x:cx,y:cy}; joyRef.current = {dx:0,dy:0};
    }
  }, []);
  const onTouchMove = useCallback((e:React.TouchEvent) => {
    e.preventDefault();
    if (!joyOrigin.current) return;
    const r=canvasRef.current?.getBoundingClientRect(); if(!r) return;
    const t=e.touches[0], cx=t.clientX-r.left, cy=t.clientY-r.top;
    const dx=cx-joyOrigin.current.x, dy=cy-joyOrigin.current.y;
    const mag=Math.hypot(dx,dy), MAX=45;
    joyRef.current = mag>MAX ? {dx:dx/mag*MAX,dy:dy/mag*MAX} : {dx,dy};
  }, []);
  const onTouchEnd = useCallback(() => { joyRef.current=null; joyOrigin.current=null; }, []);

  const onCanvasClick = useCallback((e:React.MouseEvent<HTMLCanvasElement>) => {
    const r=canvasRef.current?.getBoundingClientRect(); if(!r) return;
    const mx=e.clientX-r.left, my=e.clientY-r.top;
    for(const b of BLDGS) {
      const center = ws(b.bx+b.bw/2, b.by+b.bd/2, b.bh, ox.current, oy.current);
      if (Math.hypot(mx-center.x, my-center.y) < 40) { onNavigate(b.action); return; }
    }
    for(const o of others.current) {
      const os = ws(o.x,o.y,0,ox.current,oy.current);
      if (Math.hypot(mx-os.x, my-(os.y-20)) < 18) { setSelPlayer(o); return; }
    }
    setSelPlayer(null);
  }, [onNavigate]);

  // ── Main render loop ──────────────────────────────────────────────────────────
  useEffect(() => {
    const canvas = canvasRef.current; if(!canvas) return;
    const ctx = canvas.getContext('2d')!;
    const ro = new ResizeObserver(() => {
      const p = canvas.parentElement; if(!p) return;
      canvas.width=p.clientWidth; canvas.height=p.clientHeight;
      vw.current=canvas.width; vh.current=canvas.height;
    });
    if(canvas.parentElement) ro.observe(canvas.parentElement);
    canvas.width=canvas.parentElement?.clientWidth||400;
    canvas.height=canvas.parentElement?.clientHeight||600;
    vw.current=canvas.width; vh.current=canvas.height;

    // Init camera
    ox.current = vw.current/2-(px.current-py.current)*HW;
    oy.current = vh.current/2-(px.current+py.current)*HH + 60;

    const SOFIA_WPS = [{x:10,y:11},{x:5,y:4},{x:18,y:5},{x:20,y:13},{x:11,y:20},{x:2,y:13},{x:11,y:11}];
    const SOFIA_TIPS = [
      'Trading Quarter gives 4× more APC!',
      'Walk over 🪙 coins for free APC.',
      'Secure Vault = automatic E2EE active.',
      'Tap a building or press [E] to enter.',
      'Business District gives 2× APC passive.',
      'Tap a player for their business card.',
      'Every 12 seconds you automatically earn APC!',
    ];

    let tick = 0;
    const loop = () => {
      tick++;
      const W = vw.current, H = vh.current;
      if (!W || !H) { rafRef.current=requestAnimationFrame(loop); return; }

      // ── Move player ──────────────────────────────────────────────────────────
      let dx=0, dy=0;
      // iso movement: W=northwest, S=southeast, A=southwest, D=northeast
      if(keys.current.up)    { dx-=P_SPEED; dy-=P_SPEED; }
      if(keys.current.down)  { dx+=P_SPEED; dy+=P_SPEED; }
      if(keys.current.left)  { dx-=P_SPEED; dy+=P_SPEED; }
      if(keys.current.right) { dx+=P_SPEED; dy-=P_SPEED; }
      if(joyRef.current) {
        const MAX=45, jx=joyRef.current.dx, jy=joyRef.current.dy;
        // Convert joystick screen direction to iso world direction
        dx += (jx+jy)/MAX*P_SPEED*0.7;
        dy += (jy-jx)/MAX*P_SPEED*0.7;
      }
      if(dx&&dy){ dx*=0.707; dy*=0.707; }
      let npx = clamp(px.current+dx, 0.5, MAP_S-1.5);
      let npy = clamp(py.current+dy, 0.5, MAP_S-1.5);
      // Collision vs buildings
      for(const b of BLDGS) {
        const margin = 0.3;
        if(npx>b.bx-margin&&npx<b.bx+b.bw+margin&&npy>b.by-margin&&npy<b.by+b.bd+margin) {
          if(!(px.current>b.bx-margin&&px.current<b.bx+b.bw+margin&&npy>b.by-margin&&npy<b.by+b.bd+margin))
            npy=py.current;
          else if(!(npx>b.bx-margin&&npx<b.bx+b.bw+margin&&py.current>b.by-margin&&py.current<b.by+b.bd+margin))
            npx=px.current;
          else { npx=px.current; npy=py.current; }
        }
      }
      px.current=npx; py.current=npy;

      // ── Camera lerp ──────────────────────────────────────────────────────────
      const tox = W/2-(px.current-py.current)*HW;
      const toy = H/2-(px.current+py.current)*HH+60;
      ox.current += (tox-ox.current)*CAM_LERP;
      oy.current += (toy-oy.current)*CAM_LERP;
      const O = {x:ox.current, y:oy.current};

      // ── SOFIA movement ───────────────────────────────────────────────────────
      const wp = SOFIA_WPS[sofiaWp.current];
      const sd = Math.hypot(sofiaX.current-wp.x, sofiaY.current-wp.y);
      if(sd<0.15) sofiaWp.current=(sofiaWp.current+1)%SOFIA_WPS.length;
      else {
        sofiaX.current+=(wp.x-sofiaX.current)/sd*0.04;
        sofiaY.current+=(wp.y-sofiaY.current)/sd*0.04;
      }
      sofiaTipTick.current++;
      if(sofiaTipTick.current>480) {
        sofiaTipTick.current=0;
        sofiaTip.current={text:SOFIA_TIPS[Math.floor(Math.random()*SOFIA_TIPS.length)],life:280};
      }
      if(sofiaTip.current) { sofiaTip.current.life--; if(sofiaTip.current.life<=0) sofiaTip.current=null; }

      // ── Coins ────────────────────────────────────────────────────────────────
      const uncollected: typeof coins.current = [];
      for(const c of coins.current) {
        c.age++;
        if(dist2(px.current,py.current,c.x,c.y)<0.25) {
          creditApc(c.val);
          spawnParticle(c.x,c.y,0,'#fcd34d',6);
          bubbles.current.push({text:`+${c.val} APC`,x:c.x,y:c.y,z:1.5,life:60,color:'#fcd34d'});
        } else uncollected.push(c);
      }
      coins.current=uncollected;

      // ── Particles ────────────────────────────────────────────────────────────
      const z2 = getZone(px.current,py.current);
      setZone(z2);
      if(tick%20===0 && z2) spawnParticle(px.current+(Math.random()-.5)*2, py.current+(Math.random()-.5)*2, 0, z2.glow, 2);
      particles.current = particles.current.filter(p => {
        p.x+=p.vx; p.y+=p.vy; p.z+=p.vz; p.life--;
        return p.life>0 && p.z<10;
      });

      // ── Drones ───────────────────────────────────────────────────────────────
      drones.current.forEach(d => {
        d.x+=d.vx; d.y+=d.vy;
        if(d.x<0||d.x>MAP_S) d.vx*=-1;
        if(d.y<0||d.y>MAP_S) d.vy*=-1;
      });

      // ── Near building ─────────────────────────────────────────────────────────
      let near: IsoBldg|null = null;
      for(const b of BLDGS) {
        const cx=b.bx+b.bw/2, cy=b.by+b.bd/2;
        if(dist2(px.current,py.current,cx,cy)<2.5) { near=b; break; }
      }
      setNearBldg(near);

      // ── Bubble decay ─────────────────────────────────────────────────────────
      bubbles.current.forEach(b=>{b.life--;b.z+=0.01;});
      bubbles.current=bubbles.current.filter(b=>b.life>0);

      // ══════════════════════════════════════════════════════════════════════════
      //  DRAW
      // ══════════════════════════════════════════════════════════════════════════
      ctx.clearRect(0,0,W,H);

      // ── Sky bg ────────────────────────────────────────────────────────────────
      const nightPhase = (Math.sin(tick*0.0004)+1)/2; // 0=day, 1=night
      const skyL1 = `hsl(220,60%,${2+nightPhase*2}%)`;
      const skyL2 = `hsl(240,50%,${4+nightPhase*3}%)`;
      const skyGrad = ctx.createLinearGradient(0,0,W,H);
      skyGrad.addColorStop(0,skyL1); skyGrad.addColorStop(1,skyL2);
      ctx.fillStyle=skyGrad; ctx.fillRect(0,0,W,H);

      // Stars at night
      if(nightPhase>0.3) {
        ctx.fillStyle=`rgba(255,255,255,${(nightPhase-0.3)*0.6})`;
        for(let i=0;i<80;i++) {
          const sx=(Math.sin(i*137.5)*W+W)%W, sy=(Math.cos(i*97.3)*H*0.5+H*0.1)%( H*0.4);
          const tw=0.5+Math.sin(tick*0.02+i)*0.5;
          ctx.globalAlpha=tw*nightPhase; ctx.beginPath();
          ctx.arc(sx,sy,0.8,0,Math.PI*2); ctx.fill();
        }
        ctx.globalAlpha=1;
      }

      // ── Render tiles (diagonal painter's algo) ────────────────────────────────
      for(let diagSum=0;diagSum<MAP_S*2-1;diagSum++) {
        const xMin=Math.max(0,diagSum-MAP_S+1), xMax=Math.min(MAP_S-1,diagSum);
        for(let wtx=xMin;wtx<=xMax;wtx++) {
          const wty=diagSum-wtx;
          const type=MAP[wty*MAP_S+wtx];
          const {x:sx,y:sy}=ws(wtx,wty,0,O.x,O.y);

          // Cull off-screen
          if(sx+HW<-10||sx-HW>W+10||sy+TILE_H<-10||sy>H+10) continue;

          // Tile fill
          let h=120,s=50,l=8;
          switch(type) {
            case T_GRASS: h=135;s=55;l=6+Math.sin(wtx*2.1+wty*1.7)*1; break;
            case T_BIZ:   h=210;s=65;l=8+Math.sin(wtx+wty)*1; break;
            case T_TRADE: h=45; s=70;l=9+Math.sin(wtx+wty)*1; break;
            case T_VAULT: h=0;  s=60;l=8+Math.sin(wtx+wty)*1; break;
            case T_PLAZA: h=150;s=40;l=9+Math.sin(wtx+wty)*1; break;
            case T_ACAD:  h=270;s=55;l=8+Math.sin(wtx+wty)*1; break;
            case T_ROAD:  h=220;s=20;l=5; break;
            case T_WATER: {
              const w=Math.sin(tick*0.04+wtx*0.9+wty*0.7);
              h=195;s=80;l=18+w*6; break;
            }
          }
          ctx.fillStyle=`hsl(${h},${s}%,${l}%)`;
          ctx.beginPath();
          ctx.moveTo(sx,sy); ctx.lineTo(sx+HW,sy+HH);
          ctx.lineTo(sx,sy+TILE_H); ctx.lineTo(sx-HW,sy+HH);
          ctx.closePath(); ctx.fill();

          // Tile grid lines (subtle)
          ctx.strokeStyle=`rgba(255,255,255,.025)`;
          ctx.lineWidth=0.5; ctx.stroke();

          // Water sparkle
          if(type===T_WATER && tick%3===0) {
            const w2=Math.sin(tick*0.05+wtx*1.2+wty*0.8);
            ctx.fillStyle=`rgba(125,211,252,${0.15+w2*0.1})`;
            ctx.fillRect(sx-5+Math.sin(tick*.1+wtx)*8,sy+HH-3,4,2);
          }
        }

        // ── Buildings at this diagonal depth ────────────────────────────────────
        for(const b of BLDGS) {
          // Render building at diagonal = bx + bw + by + bd - 2
          if(b.bx+b.bw-1+b.by+b.bd-1 !== diagSum) continue;

          const base = ws(b.bx,b.by,0,O.x,O.y);
          if(base.x+b.bw*HW<-20||base.x-b.bd*HW>W+20) continue;

          const isNear = near?.id===b.id;
          const glowAmt = isNear ? 12+Math.sin(tick*0.1)*4 : 4;

          // Building corners (elevated)
          const tl=ws(b.bx,      b.by,      b.bh,O.x,O.y);
          const tr=ws(b.bx+b.bw, b.by,      b.bh,O.x,O.y);
          const br=ws(b.bx+b.bw, b.by+b.bd, b.bh,O.x,O.y);
          const bl=ws(b.bx,      b.by+b.bd, b.bh,O.x,O.y);
          const tr0=ws(b.bx+b.bw,b.by,      0,O.x,O.y);
          const br0=ws(b.bx+b.bw,b.by+b.bd, 0,O.x,O.y);
          const bl0=ws(b.bx,     b.by+b.bd, 0,O.x,O.y);

          ctx.shadowColor=b.glowColor; ctx.shadowBlur=glowAmt;

          // RIGHT face (east – darker)
          const rGrad=ctx.createLinearGradient(tr.x,tr.y,br0.x,br0.y);
          rGrad.addColorStop(0,`hsl(${b.rightHue},${b.sat}%,${b.lit+4}%)`);
          rGrad.addColorStop(1,`hsl(${b.rightHue},${b.sat}%,${b.lit-2}%)`);
          ctx.fillStyle=rGrad;
          ctx.beginPath(); ctx.moveTo(tr.x,tr.y); ctx.lineTo(br.x,br.y);
          ctx.lineTo(br0.x,br0.y); ctx.lineTo(tr0.x,tr0.y); ctx.closePath(); ctx.fill();

          // LEFT face (south – medium)
          const lGrad=ctx.createLinearGradient(bl.x,bl.y,br0.x,br0.y);
          lGrad.addColorStop(0,`hsl(${b.leftHue},${b.sat}%,${b.lit+2}%)`);
          lGrad.addColorStop(1,`hsl(${b.leftHue},${b.sat}%,${b.lit-3}%)`);
          ctx.fillStyle=lGrad;
          ctx.beginPath(); ctx.moveTo(bl.x,bl.y); ctx.lineTo(br.x,br.y);
          ctx.lineTo(br0.x,br0.y); ctx.lineTo(bl0.x,bl0.y); ctx.closePath(); ctx.fill();

          // TOP face (lightest)
          const tGrad=ctx.createLinearGradient(tl.x,tl.y,br.x,br.y);
          tGrad.addColorStop(0,`hsl(${b.topHue},${b.sat}%,${b.lit+8}%)`);
          tGrad.addColorStop(1,`hsl(${b.topHue},${b.sat}%,${b.lit+4}%)`);
          ctx.fillStyle=tGrad;
          ctx.beginPath(); ctx.moveTo(tl.x,tl.y); ctx.lineTo(tr.x,tr.y);
          ctx.lineTo(br.x,br.y); ctx.lineTo(bl.x,bl.y); ctx.closePath(); ctx.fill();

          ctx.shadowBlur=0;

          // Building edge outlines
          ctx.strokeStyle=isNear?b.glowColor:`${b.glowColor}44`;
          ctx.lineWidth=isNear?1.2:0.6;
          // Vertical edges
          [[tr,tr0],[br,br0],[bl,bl0],[tl,ws(b.bx,b.by,0,O.x,O.y)]].forEach(([a,c])=>{
            ctx.beginPath(); ctx.moveTo(a.x,a.y); ctx.lineTo(c.x,c.y); ctx.stroke();
          });
          // Top face outline
          ctx.beginPath(); ctx.moveTo(tl.x,tl.y); ctx.lineTo(tr.x,tr.y);
          ctx.lineTo(br.x,br.y); ctx.lineTo(bl.x,bl.y); ctx.closePath(); ctx.stroke();

          // Window lights on right face
          const winRows = Math.max(1,b.bh-1), winCols = Math.max(1,b.bw);
          for(let wr=0;wr<winRows;wr++) for(let wc=0;wc<winCols;wc++) {
            const flicker = Math.sin(tick*0.03+b.bx*7+b.by*11+wr*3+wc*5)>0.2;
            if (!flicker) continue;
            const frac = (wr+0.6)/b.bh, cfrac=(wc+0.3)/b.bw;
            const wx2=tr.x*(1-frac)+tr0.x*frac, wy2=tr.y*(1-frac)+tr0.y*frac;
            const wx3=br.x*(1-frac)+br0.x*frac, wy3=br.y*(1-frac)+br0.y*frac;
            const winX=(wx2*(1-cfrac)+wx3*cfrac);
            const winY=(wy2*(1-cfrac)+wy3*cfrac);
            ctx.fillStyle=`rgba(255,240,200,${0.5+Math.sin(tick*0.07+wr+wc)*0.3})`;
            ctx.fillRect(winX-2,winY-2,4,3);
          }

          // Neon sign on top face
          if(isNear || dist2(px.current,py.current,b.bx+b.bw/2,b.by+b.bd/2)<5) {
            const signPos=ws(b.bx+b.bw/2, b.by+b.bd*.35, b.bh+0.2, O.x,O.y);
            ctx.font=`bold ${Math.min(11,8+b.bh)}px "SF Mono",monospace`;
            ctx.textAlign='center';
            ctx.shadowColor=b.glowColor; ctx.shadowBlur=8;
            ctx.fillStyle=b.glowColor;
            ctx.fillText(b.emoji+' '+b.name, signPos.x, signPos.y);
            ctx.shadowBlur=0;
          }

          // ENTER hint
          if(isNear) {
            const hintPos=ws(b.bx+b.bw/2, b.by+b.bd/2, b.bh+1, O.x,O.y);
            ctx.font='bold 9px monospace'; ctx.textAlign='center';
            const hint='[ E ] Enter';
            const tw=ctx.measureText(hint).width;
            ctx.fillStyle='rgba(0,0,0,.7)';
            ctx.beginPath(); ctx.roundRect(hintPos.x-tw/2-5,hintPos.y-13,tw+10,17,4); ctx.fill();
            ctx.shadowColor='#fff'; ctx.shadowBlur=4;
            ctx.fillStyle='#fcd34d'; ctx.fillText(hint, hintPos.x, hintPos.y);
            ctx.shadowBlur=0;
          }
        }
      }

      // ── Particles ──────────────────────────────────────────────────────────────
      particles.current.forEach(p => {
        const ps=ws(p.x,p.y,p.z,O.x,O.y);
        const alpha=p.life/p.maxLife;
        ctx.globalAlpha=alpha;
        ctx.shadowColor=p.color; ctx.shadowBlur=6;
        ctx.fillStyle=p.color;
        ctx.beginPath(); ctx.arc(ps.x,ps.y,p.size*alpha,0,Math.PI*2); ctx.fill();
        ctx.shadowBlur=0;
      });
      ctx.globalAlpha=1;

      // ── Drones ────────────────────────────────────────────────────────────────
      drones.current.forEach(d => {
        const ds=ws(d.x,d.y,d.z,O.x,O.y);
        ctx.shadowColor=d.color; ctx.shadowBlur=8;
        ctx.fillStyle=d.color;
        ctx.beginPath(); ctx.ellipse(ds.x,ds.y,6,3,Math.atan2(d.vy,d.vx),0,Math.PI*2); ctx.fill();
        // Light beam
        ctx.globalAlpha=0.2;
        ctx.fillStyle=d.color;
        const gndS=ws(d.x,d.y,0,O.x,O.y);
        ctx.beginPath(); ctx.ellipse(gndS.x,gndS.y,4,2,0,0,Math.PI*2); ctx.fill();
        ctx.globalAlpha=1; ctx.shadowBlur=0;
      });

      // ── Coins ─────────────────────────────────────────────────────────────────
      coins.current.forEach(c => {
        const cs=ws(c.x,c.y,0.15+Math.sin(c.age*0.08)*0.05,O.x,O.y);
        ctx.shadowColor='#fcd34d'; ctx.shadowBlur=8;
        ctx.font=c.val>1?'16px sans-serif':'12px sans-serif';
        ctx.textAlign='center'; ctx.textBaseline='middle';
        ctx.fillText('🪙',cs.x,cs.y);
        ctx.shadowBlur=0; ctx.textBaseline='alphabetic';
      });

      // ── Other players ──────────────────────────────────────────────────────────
      others.current.forEach(o => {
        // Wander gently
        o.x+=Math.sin(tick*0.008+o.x)*0.008; o.y+=Math.cos(tick*0.006+o.y)*0.008;
        o.x=clamp(o.x,1,MAP_S-2); o.y=clamp(o.y,1,MAP_S-2);
        const os=ws(o.x,o.y,0,O.x,O.y);
        // Shadow
        ctx.fillStyle='rgba(0,0,0,.25)'; ctx.beginPath();
        ctx.ellipse(os.x,os.y+6,10,5,0,0,Math.PI*2); ctx.fill();
        // Body
        const op=ws(o.x,o.y,0.5,O.x,O.y);
        ctx.shadowColor=o.color; ctx.shadowBlur=6;
        ctx.fillStyle=o.color;
        ctx.beginPath(); ctx.arc(op.x,op.y,11,0,Math.PI*2); ctx.fill();
        ctx.shadowBlur=0;
        if(o.badge!=='none') {
          ctx.strokeStyle=o.badge==='platinum'?'#e2e8f0':'#fcd34d';
          ctx.lineWidth=2; ctx.stroke();
        }
        ctx.font='bold 8px "SF Mono",monospace'; ctx.fillStyle='#e2e8f0';
        ctx.textAlign='center'; ctx.fillText(o.name.slice(0,8),op.x,op.y-15);
      });

      // ── SOFIA NPC ─────────────────────────────────────────────────────────────
      {
        const ss=ws(sofiaX.current,sofiaY.current,0,O.x,O.y);
        ctx.fillStyle='rgba(0,0,0,.2)'; ctx.beginPath();
        ctx.ellipse(ss.x,ss.y+6,11,5,0,0,Math.PI*2); ctx.fill();
        const sp=ws(sofiaX.current,sofiaY.current,0.6,O.x,O.y);
        const pulse=Math.sin(tick*0.06)*0.15+1;
        ctx.shadowColor='#a78bfa'; ctx.shadowBlur=12+pulse*4;
        const sg=ctx.createRadialGradient(sp.x,sp.y,2,sp.x,sp.y,13);
        sg.addColorStop(0,'#ddd6fe'); sg.addColorStop(1,'#7c3aed');
        ctx.fillStyle=sg; ctx.beginPath(); ctx.arc(sp.x,sp.y,13*pulse,0,Math.PI*2); ctx.fill();
        ctx.shadowBlur=0;
        ctx.font='bold 9px "SF Mono",monospace'; ctx.fillStyle='#ddd6fe';
        ctx.textAlign='center'; ctx.fillText('SOFIA AI',sp.x,sp.y-18);

        const tip=sofiaTip.current;
        if(tip) {
          const tp=ws(sofiaX.current,sofiaY.current,2.5,O.x,O.y);
          const words=tip.text.split(' ');
          const maxW=180; ctx.font='10px "SF Mono",monospace';
          const lines:string[]=[]; let line='';
          for(const w of words) {
            const t=line+(line?' ':'')+w;
            if(ctx.measureText(t).width>maxW-12){if(line)lines.push(line);line=w;}else line=t;
          }
          if(line)lines.push(line);
          const bh2=lines.length*14+10, bw2=maxW;
          const alpha=Math.min(1,tip.life/40);
          ctx.globalAlpha=alpha;
          ctx.fillStyle='rgba(26,16,52,.95)';
          ctx.beginPath(); ctx.roundRect(tp.x-bw2/2,tp.y-bh2,bw2,bh2,8); ctx.fill();
          ctx.strokeStyle='rgba(167,139,250,.4)'; ctx.lineWidth=1; ctx.stroke();
          ctx.fillStyle='#ddd6fe'; ctx.textAlign='center';
          lines.forEach((l,i)=>ctx.fillText(l,tp.x,tp.y-bh2+16+i*14));
          ctx.globalAlpha=1;
        }
      }

      // ── Player avatar ──────────────────────────────────────────────────────────
      {
        const ps2=ws(px.current,py.current,0,O.x,O.y);
        ctx.fillStyle='rgba(0,0,0,.25)'; ctx.beginPath();
        ctx.ellipse(ps2.x,ps2.y+6,13,6,0,0,Math.PI*2); ctx.fill();
        const pp=ws(px.current,py.current,0.6,O.x,O.y);
        const pPulse=1+Math.sin(tick*0.08)*0.06;
        ctx.shadowColor=avatarColor; ctx.shadowBlur=14;
        const pg=ctx.createRadialGradient(pp.x,pp.y,2,pp.x,pp.y,14);
        pg.addColorStop(0,avatarColor); pg.addColorStop(1,avatarColor+'88');
        ctx.fillStyle=pg; ctx.beginPath(); ctx.arc(pp.x,pp.y,14*pPulse,0,Math.PI*2); ctx.fill();
        ctx.shadowBlur=0;
        if(badge!=='none') {
          ctx.strokeStyle=badge==='platinum'?'#e2e8f0':'#fcd34d'; ctx.lineWidth=2.5; ctx.stroke();
        }
        ctx.font='bold 10px "SF Mono",monospace'; ctx.fillStyle='#fff';
        ctx.textAlign='center'; ctx.textBaseline='middle';
        ctx.fillText(displayName.slice(0,2).toUpperCase(),pp.x,pp.y);
        ctx.textBaseline='alphabetic';
        ctx.font='bold 8px "SF Mono",monospace'; ctx.fillStyle='#e2e8f0';
        ctx.fillText(displayName.slice(0,10),pp.x,pp.y-19);
        ctx.font='7px monospace'; ctx.fillStyle='#64748b'; ctx.fillText('▼ YOU',pp.x,pp.y+28);
      }

      // ── Bubbles ───────────────────────────────────────────────────────────────
      bubbles.current.forEach(b => {
        const bs=ws(b.x,b.y,b.z,O.x,O.y);
        const alpha=Math.min(1,b.life/20);
        ctx.globalAlpha=alpha;
        ctx.shadowColor=b.color; ctx.shadowBlur=6;
        ctx.font='bold 11px "SF Mono",monospace'; ctx.fillStyle=b.color;
        ctx.textAlign='center'; ctx.fillText(b.text,bs.x,bs.y);
        ctx.shadowBlur=0;
      });
      ctx.globalAlpha=1;

      // ── Mini-map HUD ──────────────────────────────────────────────────────────
      {
        const MX=W-134,MY=10,MW=124,MH=100;
        const sx2=(x:number)=>MX+x/MAP_S*MW, sy2=(y:number)=>MY+y/MAP_S*MH;
        ctx.fillStyle='rgba(2,8,24,.88)';
        ctx.beginPath(); ctx.roundRect(MX,MY,MW,MH,6); ctx.fill();
        ctx.strokeStyle='rgba(56,189,248,.25)'; ctx.lineWidth=1; ctx.stroke();
        // Zone fills
        ctx.fillStyle='rgba(56,189,248,.15)'; ctx.fillRect(MX+sx2(1)-MX,MY+sy2(1)-MY,MW*21/24,MH*6/24);
        ctx.fillStyle='rgba(239,68,68,.12)';  ctx.fillRect(MX,MY+MH*9/24,MW*5/24,MH*8/24);
        ctx.fillStyle='rgba(34,197,94,.12)';  ctx.fillRect(MX+MW*7/24,MY+MH*9/24,MW*9/24,MH*8/24);
        ctx.fillStyle='rgba(245,158,11,.15)'; ctx.fillRect(MX+MW*17/24,MY+MH*9/24,MW*7/24,MH*8/24);
        ctx.fillStyle='rgba(167,139,250,.12)';ctx.fillRect(MX+MW/24,MY+MH*19/24,MW*22/24,MH*3/24);
        // Buildings
        BLDGS.forEach(b=>{
          ctx.fillStyle=b.glowColor+'99';
          ctx.fillRect(sx2(b.bx),sy2(b.by),Math.max(3,b.bw/MAP_S*MW),Math.max(3,b.bd/MAP_S*MH));
        });
        // Sofia
        ctx.fillStyle='#a78bfa'; ctx.shadowColor='#a78bfa'; ctx.shadowBlur=4;
        ctx.beginPath(); ctx.arc(sx2(sofiaX.current),sy2(sofiaY.current),2.5,0,Math.PI*2); ctx.fill();
        // Other players
        others.current.forEach(o=>{
          ctx.fillStyle=o.color; ctx.shadowColor=o.color; ctx.shadowBlur=3;
          ctx.beginPath(); ctx.arc(sx2(o.x),sy2(o.y),2,0,Math.PI*2); ctx.fill();
        });
        // Player
        ctx.fillStyle=avatarColor; ctx.shadowColor=avatarColor; ctx.shadowBlur=6;
        ctx.beginPath(); ctx.arc(sx2(px.current),sy2(py.current),3.5,0,Math.PI*2); ctx.fill();
        ctx.shadowBlur=0;
        ctx.font='7px monospace'; ctx.fillStyle='rgba(56,189,248,.5)';
        ctx.textAlign='left'; ctx.fillText('WORLD MAP',MX+4,MY+MH-4);
      }

      // ── Touch joystick visual ──────────────────────────────────────────────────
      if(joyOrigin.current) {
        const jo=joyOrigin.current;
        ctx.fillStyle='rgba(255,255,255,.06)'; ctx.strokeStyle='rgba(255,255,255,.18)'; ctx.lineWidth=1.5;
        ctx.beginPath(); ctx.arc(jo.x,jo.y,45,0,Math.PI*2); ctx.fill(); ctx.stroke();
        if(joyRef.current) {
          ctx.fillStyle='rgba(255,255,255,.25)';
          ctx.beginPath(); ctx.arc(jo.x+joyRef.current.dx,jo.y+joyRef.current.dy,18,0,Math.PI*2); ctx.fill();
        }
      }

      rafRef.current=requestAnimationFrame(loop);
    };
    rafRef.current=requestAnimationFrame(loop);
    return () => { cancelAnimationFrame(rafRef.current); ro.disconnect(); };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [avatarColor, badge, displayName]);

  return (
    <div className="ow-root">
      <div className="ow-header">
        <div className="ow-header__left">
          <span className="ow-logo">⬡ AIPPIE WORLD</span>
          <span className="ow-zone-badge" style={zone?{color:zone.glow,borderColor:zone.glow}:{}}>
            {zone?.name||'Open World'}
          </span>
          {zone && zone.earnRate>1 && (
            <span className="ow-earn-badge"><Zap size={9}/> {zone.earnRate}× APC</span>
          )}
          {zone?.id==='vault' && <span className="ow-shield-badge"><Lock size={9}/> E2EE</span>}
        </div>
        <div className="ow-header__right">
          <div className="ow-stat"><Coins size={11} style={{color:'#fcd34d'}}/>{apc} APC</div>
          <div className="ow-stat"><Users size={11} style={{color:'#38bdf8'}}/>{onlineCnt} online</div>
          <button className="ow-close-btn" onClick={onClose}><X size={16}/></button>
        </div>
      </div>

      <canvas ref={canvasRef} className="ow-canvas"
        onClick={onCanvasClick}
        onTouchStart={onTouchStart} onTouchMove={onTouchMove} onTouchEnd={onTouchEnd}
      />

      {nearBldg && (
        <div className="ow-building-hint">
          <span className="ow-building-hint__emoji">{nearBldg.emoji}</span>
          <div className="ow-building-hint__info">
            <div className="ow-building-hint__name" style={{color:nearBldg.glowColor}}>{nearBldg.name}</div>
            <div className="ow-building-hint__desc">{nearBldg.desc}</div>
          </div>
          <button className="ow-building-hint__btn" style={{background:`linear-gradient(135deg,${nearBldg.glowColor}cc,${nearBldg.glowColor}66)`}}
            onClick={()=>onNavigate(nearBldg.action)}>
            Enter →
          </button>
        </div>
      )}

      <div className="ow-dpad">
        <button className="ow-dpad__btn" style={{gridColumn:2,gridRow:1}}
          onPointerDown={()=>keys.current.up=true} onPointerUp={()=>keys.current.up=false}>▲</button>
        <button className="ow-dpad__btn" style={{gridColumn:1,gridRow:2}}
          onPointerDown={()=>keys.current.left=true} onPointerUp={()=>keys.current.left=false}>◀</button>
        <button className="ow-dpad__btn" style={{gridColumn:3,gridRow:2}}
          onPointerDown={()=>keys.current.right=true} onPointerUp={()=>keys.current.right=false}>▶</button>
        <button className="ow-dpad__btn" style={{gridColumn:2,gridRow:3}}
          onPointerDown={()=>keys.current.down=true} onPointerUp={()=>keys.current.down=false}>▼</button>
      </div>

      <div className="ow-hint-bar">
        WASD / arrow keys move &nbsp;·&nbsp; [E] or tap building to enter &nbsp;·&nbsp; Walk over 🪙 for APC &nbsp;·&nbsp; Isometric 2.5D · 19 working buildings
      </div>

      {selPlayer && (
        <div className="ow-profile-card" onClick={()=>setSelPlayer(null)}>
          <div className="ow-profile-card__inner" onClick={e=>e.stopPropagation()}>
            <button className="ow-profile-card__close" onClick={()=>setSelPlayer(null)}><X size={14}/></button>
            <div className="ow-profile-card__avatar" style={{background:selPlayer.color}}>
              {selPlayer.name.slice(0,2).toUpperCase()}
            </div>
            <div className="ow-profile-card__name">{selPlayer.name}</div>
            {selPlayer.badge!=='none'&&(
              <div className="ow-profile-card__badge" style={{color:selPlayer.badge==='platinum'?'#e2e8f0':'#fcd34d'}}>
                {selPlayer.badge==='platinum'?'⬡ Platinum':'★ Gold'} Verified
              </div>
            )}
            <button className="ow-profile-card__chat"
              onClick={()=>{onNavigate('securechat');setSelPlayer(null);}}>
              <MessageCircle size={12}/> Send message
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
