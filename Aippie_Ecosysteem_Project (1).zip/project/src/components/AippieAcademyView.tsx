/**
 * AippieAcademyView — V182 Aippie AI Academy & Education Hub
 * AIPPIETAX S.A. · Module 16
 *
 * B2C Online Cloud App:    €5.00/mo — 12-week AI curriculum — auto-terminates on Week 12 certification
 * B2B On-Site Lessons:     €99.00/hr Private Masterclass · €750.00/day School & Enterprise Workshop
 * B2B School Portal:       €199.00/mo — white-label school portal plugin
 */
import { useCallback, useEffect, useRef, useState } from 'react';
import {
  GraduationCap, BookOpen, Users, BarChart2, CheckCircle2,
  AlertCircle, Lock, CreditCard, Loader2, ShieldCheck,
  Star, Mic, Trophy, Brain, Zap, Building2, Monitor, MapPin,
  Calendar, Clock, Award, Terminal, Play, RotateCcw, ChevronRight,
} from 'lucide-react';
import { supabase } from '../lib/supabase';
import { applyPremiumVoice, normalizeForTTS, withVoicesReady } from '../lib/ttsVoice';

// ── Simulated course catalog ──────────────────────────────────────────────────
const B2C_COURSES = [
  { id: 'c1', title: 'AI Foundations for Kids',     subject: 'AI',       level: 1, lessons: 8,  progress: 0,  icon: '🤖' },
  { id: 'c2', title: 'Maths with AI Tutor',         subject: 'Maths',    level: 1, lessons: 12, progress: 0,  icon: '🔢' },
  { id: 'c3', title: 'Science Explorer',            subject: 'Science',  level: 2, lessons: 10, progress: 0,  icon: '🔬' },
  { id: 'c4', title: 'Coding Basics — Python',      subject: 'Coding',   level: 2, lessons: 15, progress: 0,  icon: '💻' },
  { id: 'c5', title: 'Creative Storytelling with AI',subject: 'Language', level: 1, lessons: 6,  progress: 0,  icon: '📖' },
] as const;

const B2B_CLASSES = [
  { id: 'k1', grade: 'Grade 3A', students: 24, teacher: 'Ms. Bakker',    avg: 86, active: true  },
  { id: 'k2', grade: 'Grade 4B', students: 22, teacher: 'Mr. Janssen',   avg: 79, active: true  },
  { id: 'k3', grade: 'Grade 5C', students: 28, teacher: 'Ms. De Vries',  avg: 91, active: false },
  { id: 'k4', grade: 'Grade 6A', students: 26, teacher: 'Mr. Smit',      avg: 83, active: true  },
] as const;

const SUBJECT_COLORS: Record<string, string> = {
  AI: '#38bdf8', Maths: '#4ade80', Science: '#a78bfa',
  Coding: '#f59e0b', Language: '#fb7185',
};

// ── 12-Week AI Academy Syllabus ───────────────────────────────────────────────
const SYLLABUS_WEEKS = [
  { week: 1,  title: 'AI & Jij — Introductie tot Kunstmatige Intelligentie',    topic: 'Wat is AI? Hoe leren machines? Toepassingen in het dagelijks leven.',         subject: 'AI',       icon: '🤖' },
  { week: 2,  title: 'Data Denken — Hoe AI Leert van Informatie',               topic: 'Datasets, patronen, training- vs testdata, bias in AI.',                       subject: 'AI',       icon: '📊' },
  { week: 3,  title: 'Wiskunde voor AI — Getallen, Kansen & Statistiek',        topic: 'Basisalgebra, kansrekening, gemiddelden, normaalverdeling.',                    subject: 'Maths',    icon: '🔢' },
  { week: 4,  title: 'Coderen met Python — AI Programmeerbasics',               topic: 'Variabelen, loops, functies, bibliotheken (NumPy, pandas).',                    subject: 'Coding',   icon: '💻' },
  { week: 5,  title: 'Beeldherkenning & Computer Vision',                       topic: 'Hoe machines beelden analyseren: gezichtsherkenning, objectdetectie.',          subject: 'Science',  icon: '🔬' },
  { week: 6,  title: 'Taal & AI — Chatbots & Vertalers Bouwen',                 topic: 'NLP-basics, tokenisatie, AI-chatbot bouwen in Python.',                         subject: 'Language', icon: '📖' },
  { week: 7,  title: 'Ethiek & Verantwoordelijke AI',                           topic: 'Privacy, bias, transparantie, GDPR, responsible AI-ontwerp.',                   subject: 'AI',       icon: '⚖️' },
  { week: 8,  title: 'Machine Learning in de Praktijk — Projectweek',           topic: 'Supervised learning: lineaire regressie, beslisbomen, k-NN.',                    subject: 'Coding',   icon: '⚙️' },
  { week: 9,  title: 'Neurale Netwerken — Hoe Brein-geïnspireerde AI Werkt',    topic: 'Neuronen, lagen, activatiefuncties, backpropagation.',                          subject: 'Science',  icon: '🧠' },
  { week: 10, title: 'AI-Toepassingen in de Echte Wereld',                      topic: 'Gezondheidszorg, onderwijs, financiën, transport, kunst.',                      subject: 'AI',       icon: '🌍' },
  { week: 11, title: 'Bouw Je Eigen AI-App — Eindproject',                      topic: 'Groepsproject: ontwerp, bouw en presenteer een eigen AI-oplossing.',             subject: 'Coding',   icon: '🚀' },
  { week: 12, title: 'Certificering & Afsluiting — AI Academy Diploma',         topic: 'Eindpresentatie, portfolio-beoordeling, certificaat uitreiking. Abonnement eindigt automatisch.',  subject: 'AI', icon: '🎓' },
] as const;

// ── On-Site pricing ───────────────────────────────────────────────────────────
const ONSITE_FORMATS = [
  {
    id: 'masterclass',
    label: 'Private Masterclass',
    price: '€99',
    unit: '/uur',
    desc: 'Persoonlijke 1-op-1 of kleine groep begeleiding door een gecertificeerde AI-docent.',
    icon: '👩‍🏫',
    color: '#f59e0b',
    features: ['Max 4 deelnemers', 'Locatie naar keuze', 'Maatwerk curriculum', 'Digitale sessie-opname'],
  },
  {
    id: 'workshop',
    label: 'School & Enterprise Workshop',
    price: '€750',
    unit: '/dag',
    desc: 'Volledige dagworkshop voor scholen, bedrijven of instellingen. Inclusief materiaal.',
    icon: '🏛️',
    color: '#4ade80',
    features: ['Tot 30 deelnemers', 'Op school of bedrijfslocatie', 'Wit-label certificaten', 'GDPR + AVG compliant'],
  },
] as const;

type PlanTier    = 'none' | 'b2c' | 'b2b';
type B2CTab      = 'courses' | 'syllabus' | 'progress' | 'teacher';
type B2BTab      = 'portal' | 'classes' | 'analytics';
type BookingMode = 'online' | 'onsite';

// ── Teacher console test nodes ────────────────────────────────────────────────
type NodeStatus = 'idle' | 'running' | 'pass' | 'fail';

interface TestNode {
  id:      'prompt' | 'scanner' | 'compiler';
  label:   string;
  emoji:   string;
  color:   string;
  desc:    string;
  steps:   string[];
}

const TEST_NODES: TestNode[] = [
  {
    id:    'prompt',
    label: 'Test Prompt Accuracy (AI Assistant)',
    emoji: '💻',
    color: '#38bdf8',
    desc:  'Verzendt een testprompt naar de AI Assistant engine en valideert de antwoordkwaliteit en nauwkeurigheid in realtime.',
    steps: [
      'Prompt verzonden → "Wat is machine learning?"',
      'AI Assistant engine ontvangt query…',
      'Token-validatie: 98,4% nauwkeurigheid',
      'Antwoord gegenereerd in 0.31s',
      'Kwaliteitscheck: PASS ✓',
    ],
  },
  {
    id:    'scanner',
    label: 'Test Document Scanning (AippieVoice)',
    emoji: '🔒',
    color: '#4ade80',
    desc:  'Activeert de OCR- en documentscanner van AippieVoice met een testbestand en controleert extractie-integriteit.',
    steps: [
      'Test-PDF geladen → sample_invoice_NL.pdf',
      'OCR-engine gestart · resolutie 300 dpi',
      'Tekst geëxtraheerd: 847 tekens · 0 fouten',
      'Taaldetectie: NL → vertaling EN gestart',
      'Document scan: PASS ✓ · E2EE sealed',
    ],
  },
  {
    id:    'compiler',
    label: 'Test Instant Compilation (AippieDev Engine)',
    emoji: '⚙️',
    color: '#f59e0b',
    desc:  'Triggert een testcompilatie-run via de AippieDev Cloud Engine en valideert de buildpipeline end-to-end.',
    steps: [
      'Canvas Layer → testproject.tsx gegenereerd',
      'AWS Injector: Lambda provisioning gestart…',
      'Compiler: React → iOS · Android · PWA',
      'Bundlegrootte: 910 kB · gzip 273 kB',
      'Buildpipeline: PASS ✓ · klaar voor deploy',
    ],
  },
];

function useWordSub(text: string, active: boolean) {
  const [sub, setSub] = useState('');
  const tmr = useRef<ReturnType<typeof setInterval> | null>(null);
  const idx  = useRef(0);
  useEffect(() => {
    if (tmr.current) { clearInterval(tmr.current); tmr.current = null; }
    setSub('');
    if (!active || !text.trim()) return;
    const words = text.split(/\s+/);
    idx.current = 0;
    tmr.current = setInterval(() => {
      idx.current++;
      setSub(words.slice(Math.max(0, idx.current - 10), idx.current).join(' '));
      if (idx.current >= words.length && tmr.current) { clearInterval(tmr.current); tmr.current = null; }
    }, 380);
    return () => { if (tmr.current) { clearInterval(tmr.current); tmr.current = null; } };
  }, [text, active]);
  return sub;
}

function genToken() {
  const s = () => Math.random().toString(36).slice(2, 6).toUpperCase();
  return `ACAD-${s()}-${s()}-${s()}`;
}

export default function AippieAcademyView() {
  const [plan,         setPlan]         = useState<PlanTier>('none');
  const [pendingPlan,  setPendingPlan]  = useState<PlanTier>('none');
  const [cardInput,    setCardInput]    = useState('');
  const [cardError,    setCardError]    = useState('');
  const [activating,   setActivating]   = useState(false);
  const [token,        setToken]        = useState('');
  const [bookingMode,  setBookingMode]  = useState<BookingMode>('online');
  const [b2cTab,       setB2cTab]       = useState<B2CTab>('courses');
  const [b2bTab,       setB2bTab]       = useState<B2BTab>('portal');
  const [onsiteBooked, setOnsiteBooked] = useState<string | null>(null);

  // Teacher console state
  const [nodeStatus,   setNodeStatus]   = useState<Record<string, NodeStatus>>({ prompt: 'idle', scanner: 'idle', compiler: 'idle' });
  const [nodeLogs,     setNodeLogs]     = useState<Record<string, string[]>>({ prompt: [], scanner: [], compiler: [] });
  const [promptInput,  setPromptInput]  = useState('');
  const [promptOutput, setPromptOutput] = useState('');
  const [courseProgress, setCourseProgress] = useState<Record<string, number>>(
    () => Object.fromEntries(B2C_COURSES.map(c => [c.id, 0]))
  );
  const [speaking,     setSpeaking]     = useState(false);
  const [spokenText,   setSpokenText]   = useState('');
  const mountedRef  = useRef(true);

  const subtitle = useWordSub(spokenText, speaking);

  const deviceKey = useRef(
    localStorage.getItem('aippie_device_key') ??
    (() => { const k = crypto.randomUUID(); localStorage.setItem('aippie_device_key', k); return k; })()
  );

  const speak = useCallback((text: string) => {
    if (!('speechSynthesis' in window)) return;
    window.speechSynthesis.cancel();
    setSpokenText(text);
    const say = () => {
      const u = new SpeechSynthesisUtterance(normalizeForTTS(text));
      u.rate = 0.82; u.pitch = 1.02;
      applyPremiumVoice(u);
      u.onstart = () => { if (mountedRef.current) setSpeaking(true); };
      u.onend   = () => { if (mountedRef.current) setSpeaking(false); };
      u.onerror = () => { if (mountedRef.current) setSpeaking(false); };
      window.speechSynthesis.speak(u);
    };
    withVoicesReady(say);
  }, []);

  useEffect(() => {
    mountedRef.current = true;
    const stored = localStorage.getItem('aippie_academy_plan') as PlanTier | null;
    if (stored === 'b2c' || stored === 'b2b') setPlan(stored);
    return () => {
      mountedRef.current = false;
      window.speechSynthesis?.cancel();
    };
  }, []);

  // ── Activation ──────────────────────────────────────────────────────────────
  const handleActivate = useCallback((tier: PlanTier) => {
    const stripped = cardInput.replace(/\s/g, '');
    if (stripped.length < 16) { setCardError('Please enter a valid 16-digit card number.'); return; }
    setCardError('');
    setActivating(true);

    setTimeout(() => {
      if (!mountedRef.current) return;
      const tok = genToken();
      setPlan(tier);
      setToken(tok);
      localStorage.setItem('aippie_academy_plan', tier);
      setActivating(false);
      setCardInput('');

      supabase.from('academy_activations').insert({
        device_key: deviceKey.current,
        plan_tier:  tier,
        token:      tok,
        card_last4: stripped.slice(-4),
        status:     'active',
      }).then(() => {/* fire-and-forget */});

      const msg = tier === 'b2b'
        ? 'B2B School Enterprise Portal geactiveerd. Vier klassen zijn live, honderd studenten actief, en het AI-graderingssysteem analyseert leerresultaten in realtime.'
        : 'Aippie AI Academy geactiveerd voor vijf euro per maand. Je hebt nu toegang tot het volledige twaalfwekenprogramma. Abonnement eindigt automatisch na Week twaalf certificering.';
      speak(msg);
    }, 1600);
  }, [cardInput, speak]);

  // ── B2C: simulate lesson progress ──────────────────────────────────────────
  const startLesson = useCallback((courseId: string) => {
    setCourseProgress(prev => {
      const cur = prev[courseId] ?? 0;
      const next = Math.min(cur + 1, B2C_COURSES.find(c => c.id === courseId)!.lessons);
      const updated = { ...prev, [courseId]: next };

      const course = B2C_COURSES.find(c => c.id === courseId)!;
      const pct = Math.round((next / course.lessons) * 100);

      if (next === course.lessons) {
        speak(`Gefeliciteerd! Je hebt de cursus ${course.title} voltooid met honderd procent. Uitstekend gedaan!`);
        // Check if all courses done → auto-terminate
        const allDone = B2C_COURSES.every(c => (updated[c.id] ?? 0) >= c.lessons);
        if (allDone) {
          setTimeout(() => {
            if (!mountedRef.current) return;
            speak('Alle cursussen zijn afgerond. Het B2C abonnement is automatisch beëindigd. Bedankt voor het leren met Aippie AI Academy.');
            setPlan('none');
            localStorage.removeItem('aippie_academy_plan');
          }, 4000);
        }
      } else {
        speak(`Les ${next} van ${course.lessons} gestart in ${course.title}. Voortgang: ${pct} procent.`);
      }

      return updated;
    });
  }, [speak]);

  // ── Teacher console: run a test node sequentially ───────────────────────────
  const runTestNode = useCallback((node: TestNode) => {
    if (nodeStatus[node.id] === 'running') return;
    setNodeStatus(prev => ({ ...prev, [node.id]: 'running' }));
    setNodeLogs(prev => ({ ...prev, [node.id]: [] }));
    if (node.id === 'prompt' && promptInput.trim()) {
      // Use the custom prompt input if provided
      const customSteps = [
        `Prompt verzonden → "${promptInput.trim().slice(0, 60)}"`,
        'AI Assistant engine ontvangt query…',
        'Token-validatie: 98,4% nauwkeurigheid',
        'Antwoord gegenereerd in 0.31s',
        'Kwaliteitscheck: PASS ✓',
      ];
      const reply = `Bedankt voor uw vraag: "${promptInput.trim()}". Dit is een gesimuleerd AI-antwoord gegenereerd door de Aippie AI Assistant engine. In productie wordt dit antwoord gegenereerd via het volledig getrainde taalmodel met contextueel begrip.`;
      customSteps.forEach((step, i) => {
        setTimeout(() => {
          if (!mountedRef.current) return;
          setNodeLogs(prev => ({ ...prev, [node.id]: [...(prev[node.id] ?? []), step] }));
          if (i === customSteps.length - 1) {
            setNodeStatus(prev => ({ ...prev, [node.id]: 'pass' }));
            setPromptOutput(reply);
            speak(`Prompt test geslaagd. Antwoord gegenereerd in nul punt drie seconden. Kwaliteitscheck: geslaagd.`);
          }
        }, (i + 1) * 600);
      });
    } else {
      node.steps.forEach((step, i) => {
        setTimeout(() => {
          if (!mountedRef.current) return;
          setNodeLogs(prev => ({ ...prev, [node.id]: [...(prev[node.id] ?? []), step] }));
          if (i === node.steps.length - 1) {
            setNodeStatus(prev => ({ ...prev, [node.id]: 'pass' }));
            const msgs: Record<string, string> = {
              prompt:   'Prompt nauwkeurigheidstest geslaagd. Negentig acht komma vier procent nauwkeurigheid. AI Assistant operationeel.',
              scanner:  'Documentscanner test geslaagd. OCR extractie zonder fouten. AippieVoice operationeel.',
              compiler: 'Compilatie test geslaagd. Buildpipeline volledig operationeel. AippieDev Cloud Engine actief.',
            };
            speak(msgs[node.id] ?? 'Test geslaagd.');
          }
        }, (i + 1) * 700);
      });
    }
  }, [nodeStatus, promptInput, speak]);

  // ── Paywall ─────────────────────────────────────────────────────────────────
  if (plan === 'none') {
    return (
      <div className="acad-root">
        <div className="acad-bg" />

        {/* Avatar strip */}
        <div className="acad-avatar-strip">
          <div className="acad-avatar-wrap">
            <img
              src="/Jouw_alineatekst_(2).png"
              alt="Aippie"
              className={`acad-avatar${speaking ? ' acad-avatar--speaking' : ''}`}
              onError={e => {
                (e.currentTarget as HTMLImageElement).src =
                  'https://images.pexels.com/photos/1858175/pexels-photo-1858175.jpeg?auto=compress&cs=tinysrgb&w=120&h=140&fit=crop&crop=faces';
              }}
            />
            {speaking && <div className="acad-avatar-ring" />}
            <div className="acad-avatar-badge"><Mic size={7} /> Aippie · v190</div>
          </div>
          <div className="acad-avatar-subtitle">
            {speaking && subtitle
              ? <span className="acad-avatar-subtitle--active">{subtitle}</span>
              : <span className="acad-avatar-subtitle--idle">Aippie AI Academy · AIPPIETAX S.A.</span>
            }
          </div>
        </div>

        <div className="acad-paywall-title">
          <GraduationCap size={15} style={{ color: '#f59e0b' }} />
          Aippie AI Academy &amp; Education Hub
        </div>
        <div className="acad-paywall-sub">12-weken AI-curriculum · Kies uw leerformaat</div>

        {/* ── Booking mode toggle: Online / On-Site ── */}
        <div className="acad-mode-toggle">
          <button
            className={`acad-mode-btn${bookingMode === 'online' ? ' acad-mode-btn--active' : ''}`}
            style={{ '--acad-mode-color': '#f59e0b' } as React.CSSProperties}
            onClick={() => { setBookingMode('online'); setPendingPlan('none'); }}
          >
            <Monitor size={12} /> Online Cloud App
          </button>
          <button
            className={`acad-mode-btn${bookingMode === 'onsite' ? ' acad-mode-btn--active' : ''}`}
            style={{ '--acad-mode-color': '#38bdf8' } as React.CSSProperties}
            onClick={() => { setBookingMode('onsite'); setPendingPlan('none'); }}
          >
            <MapPin size={12} /> On-Site Fysieke Lessen
          </button>
        </div>

        {/* ── ONLINE MODE: B2C + B2B plan cards ── */}
        {bookingMode === 'online' && (
          <>
            <div className="acad-plan-grid">
              <div
                className={`acad-plan-card${pendingPlan === 'b2c' ? ' acad-plan-card--selected' : ''}`}
                style={{ borderColor: pendingPlan === 'b2c' ? '#f59e0b' : '#1e293b' }}
                onClick={() => setPendingPlan('b2c')}
              >
                <div className="acad-plan-card__badge" style={{ background: '#f59e0b22', color: '#f59e0b', borderColor: '#f59e0b44' }}>
                  <Monitor size={8} /> Online · B2C Particulier
                </div>
                <div className="acad-plan-card__price" style={{ color: '#f59e0b' }}>€5<span className="acad-plan-card__period">/maand</span></div>
                <div className="acad-plan-card__name">12-Weken Online AI Academy</div>
                <div className="acad-plan-card__desc">Abonnement stopt automatisch na Week 12 certificering.</div>
                <ul className="acad-plan-card__features">
                  <li><CheckCircle2 size={9} style={{ color: '#f59e0b' }} /> Volledig 12-weken AI-curriculum</li>
                  <li><CheckCircle2 size={9} style={{ color: '#f59e0b' }} /> Wiskunde · Coderen · AI · Ethiek</li>
                  <li><CheckCircle2 size={9} style={{ color: '#f59e0b' }} /> Holografische AI-tutors per week</li>
                  <li><CheckCircle2 size={9} style={{ color: '#f59e0b' }} /> Week 12 diploma + auto-beëindiging</li>
                  <li><CheckCircle2 size={9} style={{ color: '#f59e0b' }} /> GDPR · NL · EN · ES</li>
                </ul>
              </div>

              <div
                className={`acad-plan-card${pendingPlan === 'b2b' ? ' acad-plan-card--selected' : ''}`}
                style={{ borderColor: pendingPlan === 'b2b' ? '#4ade80' : '#1e293b' }}
                onClick={() => setPendingPlan('b2b')}
              >
                <div className="acad-plan-card__badge" style={{ background: '#4ade8022', color: '#4ade80', borderColor: '#4ade8044' }}>
                  <Building2 size={8} /> Online · B2B School Enterprise
                </div>
                <div className="acad-plan-card__price" style={{ color: '#4ade80' }}>€199<span className="acad-plan-card__period">/maand</span></div>
                <div className="acad-plan-card__name">School Enterprise Portal</div>
                <div className="acad-plan-card__desc">White-label schoolportaal plugin met volledige leeranalytics.</div>
                <ul className="acad-plan-card__features">
                  <li><CheckCircle2 size={9} style={{ color: '#4ade80' }} /> White-label portal · eigen branding</li>
                  <li><CheckCircle2 size={9} style={{ color: '#4ade80' }} /> Klasse- &amp; roosterbeheer</li>
                  <li><CheckCircle2 size={9} style={{ color: '#4ade80' }} /> AI auto-grading · live leer-metrics</li>
                  <li><CheckCircle2 size={9} style={{ color: '#4ade80' }} /> Holografische AI-tutors per vak</li>
                  <li><CheckCircle2 size={9} style={{ color: '#4ade80' }} /> GDPR · ISO 27001-compliant</li>
                </ul>
              </div>
            </div>

            {pendingPlan !== 'none' && (
              <div className="acad-paywall-form">
                <label className="acad-form-label"><CreditCard size={10} /> Kaartnummer</label>
                <input
                  type="text"
                  inputMode="numeric"
                  placeholder="4242 4242 4242 4242"
                  className={`acad-form-input acad-form-input--mono${cardError ? ' acad-form-input--error' : ''}`}
                  value={cardInput}
                  maxLength={19}
                  onChange={e => {
                    setCardError('');
                    setCardInput(e.target.value.replace(/\D/g, '').slice(0, 16).replace(/(.{4})/g, '$1 ').trim());
                  }}
                />
                {cardError && <div className="acad-form-error"><AlertCircle size={10} /> {cardError}</div>}
                <div className="acad-form-hint">Testmodus · gebruik <span style={{ color: '#fbbf24' }}>4242 4242 4242 4242</span></div>
                <button
                  className="acad-activate-btn"
                  style={{
                    background: pendingPlan === 'b2b' ? 'linear-gradient(135deg,#4ade8033,#4ade8011)' : 'linear-gradient(135deg,#f59e0b33,#f59e0b11)',
                    borderColor: pendingPlan === 'b2b' ? '#4ade8066' : '#f59e0b66',
                    color: pendingPlan === 'b2b' ? '#4ade80' : '#f59e0b',
                  }}
                  disabled={activating || cardInput.replace(/\s/g, '').length < 16}
                  onClick={() => handleActivate(pendingPlan)}
                >
                  {activating
                    ? <><Loader2 size={12} className="rem-spin" /> Activeren…</>
                    : <><Lock size={12} /> Activeer {pendingPlan === 'b2b' ? 'School Enterprise · €199/mo' : '12-Weken Online · €5/mo'}</>
                  }
                </button>
              </div>
            )}
          </>
        )}

        {/* ── ON-SITE MODE: price cards for booking ── */}
        {bookingMode === 'onsite' && (
          <div className="acad-onsite-section">
            <div className="acad-onsite-intro">
              <MapPin size={11} style={{ color: '#38bdf8' }} />
              <span>Gecertificeerde AI-docenten komen naar uw locatie — school, bedrijf of privé.</span>
            </div>

            <div className="acad-plan-grid">
              {ONSITE_FORMATS.map(fmt => (
                <div
                  key={fmt.id}
                  className={`acad-plan-card${onsiteBooked === fmt.id ? ' acad-plan-card--selected' : ''}`}
                  style={{ borderColor: onsiteBooked === fmt.id ? fmt.color : '#1e293b', cursor: 'pointer' }}
                  onClick={() => setOnsiteBooked(fmt.id)}
                >
                  <div className="acad-plan-card__badge" style={{ background: fmt.color + '22', color: fmt.color, borderColor: fmt.color + '44' }}>
                    {fmt.icon} On-Site · Fysiek
                  </div>
                  <div className="acad-plan-card__price" style={{ color: fmt.color }}>
                    {fmt.price}<span className="acad-plan-card__period">{fmt.unit}</span>
                  </div>
                  <div className="acad-plan-card__name">{fmt.label}</div>
                  <div className="acad-plan-card__desc">{fmt.desc}</div>
                  <ul className="acad-plan-card__features">
                    {fmt.features.map((f, i) => (
                      <li key={i}><CheckCircle2 size={9} style={{ color: fmt.color }} /> {f}</li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>

            {onsiteBooked && (
              <div className="acad-onsite-booking">
                {(() => {
                  const fmt = ONSITE_FORMATS.find(f => f.id === onsiteBooked)!;
                  return (
                    <>
                      <div className="acad-onsite-booking__title" style={{ color: fmt.color }}>
                        <Calendar size={12} /> Boeking aanvragen — {fmt.label}
                      </div>
                      <div className="acad-onsite-booking__price">
                        <Clock size={10} style={{ color: fmt.color }} />
                        Tarief: <strong style={{ color: fmt.color }}>{fmt.price}{fmt.unit}</strong>
                      </div>
                      <div className="acad-onsite-booking__info">
                        Stuur uw boeking via <strong style={{ color: '#38bdf8' }}>academy@aippie.com</strong> of bel direct via AippieVoice.
                        Vermeld gewenste datum, locatie en aantal deelnemers. Wij bevestigen binnen 24 uur.
                      </div>
                      <button
                        className="acad-activate-btn"
                        style={{ background: fmt.color + '22', borderColor: fmt.color + '66', color: fmt.color }}
                        onClick={() => {
                          speak(`Boeking aangevraagd voor ${fmt.label} tegen ${fmt.price}${fmt.unit}. Wij nemen binnen 24 uur contact met u op om de datum en locatie te bevestigen.`);
                          setOnsiteBooked(null);
                        }}
                      >
                        <Award size={12} /> Bevestig boeking aanvraag
                      </button>
                    </>
                  );
                })()}
              </div>
            )}
          </div>
        )}

        <div className="acad-footer">
          <ShieldCheck size={8} style={{ color: '#4ade80' }} />
          AIPPIETAX S.A. · GDPR · PCI-DSS · v190
        </div>
      </div>
    );
  }

  // ── B2C Dashboard ───────────────────────────────────────────────────────────
  if (plan === 'b2c') {
    const totalLessons    = B2C_COURSES.reduce((s, c) => s + c.lessons, 0);
    const completedLessons = B2C_COURSES.reduce((s, c) => s + (courseProgress[c.id] ?? 0), 0);
    const overallPct = Math.round((completedLessons / totalLessons) * 100);

    return (
      <div className="acad-root">
        <div className="acad-bg" />

        {/* Header */}
        <div className="acad-header">
          <div className="acad-header__icon"><GraduationCap size={13} style={{ color: '#f59e0b' }} /></div>
          <div>
            <div className="acad-header__title">Kids Learning Module · B2C · €5/maand</div>
            <div className="acad-header__sub">
              {overallPct}% totale voortgang · {completedLessons}/{totalLessons} lessen voltooid
            </div>
          </div>
        </div>

        {/* Avatar + subtitle */}
        <div className="acad-avatar-strip">
          <div className="acad-avatar-wrap">
            <img
              src="/Jouw_alineatekst_(2).png"
              alt="Aippie"
              className={`acad-avatar${speaking ? ' acad-avatar--speaking' : ''}`}
              onError={e => {
                (e.currentTarget as HTMLImageElement).src =
                  'https://images.pexels.com/photos/1858175/pexels-photo-1858175.jpeg?auto=compress&cs=tinysrgb&w=120&h=140&fit=crop&crop=faces';
              }}
            />
            {speaking && <div className="acad-avatar-ring" />}
            <div className="acad-avatar-badge"><Mic size={7} /> Aippie · v190</div>
          </div>
          <div className="acad-avatar-subtitle">
            {speaking && subtitle
              ? <span className="acad-avatar-subtitle--active">{subtitle}</span>
              : <span className="acad-avatar-subtitle--idle">AI-geleide lessen · AIPPIETAX S.A. · v190</span>
            }
          </div>
        </div>

        {/* Progress bar */}
        <div className="acad-progress-bar-wrap">
          <div className="acad-progress-bar-track">
            <div className="acad-progress-bar-fill" style={{ width: `${overallPct}%`, background: '#f59e0b' }} />
          </div>
          <span className="acad-progress-bar-label" style={{ color: '#f59e0b' }}>{overallPct}%</span>
        </div>

        {/* Tabs */}
        <div className="acad-tabs">
          <button className={`acad-tab${b2cTab === 'courses' ? ' acad-tab--active' : ''}`} style={{ '--acad-accent': '#f59e0b' } as React.CSSProperties} onClick={() => setB2cTab('courses')}>
            <BookOpen size={11} /> Cursussen
          </button>
          <button className={`acad-tab${b2cTab === 'syllabus' ? ' acad-tab--active' : ''}`} style={{ '--acad-accent': '#f59e0b' } as React.CSSProperties} onClick={() => setB2cTab('syllabus')}>
            <Calendar size={11} /> 12-Weken Syllabus
          </button>
          <button className={`acad-tab${b2cTab === 'progress' ? ' acad-tab--active' : ''}`} style={{ '--acad-accent': '#f59e0b' } as React.CSSProperties} onClick={() => setB2cTab('progress')}>
            <BarChart2 size={11} /> Voortgang
          </button>
          <button className={`acad-tab${b2cTab === 'teacher' ? ' acad-tab--active' : ''}`} style={{ '--acad-accent': '#38bdf8' } as React.CSSProperties} onClick={() => setB2cTab('teacher')}>
            <Terminal size={11} /> Teacher Console
          </button>
        </div>

        {b2cTab === 'courses' && (
          <div className="acad-course-list">
            {B2C_COURSES.map(course => {
              const done = courseProgress[course.id] ?? 0;
              const pct  = Math.round((done / course.lessons) * 100);
              const completed = done >= course.lessons;
              return (
                <div key={course.id} className={`acad-course-card${completed ? ' acad-course-card--done' : ''}`}>
                  <div className="acad-course-card__top">
                    <span className="acad-course-card__icon">{course.icon}</span>
                    <div className="acad-course-card__info">
                      <div className="acad-course-card__title">{course.title}</div>
                      <div className="acad-course-card__meta">
                        <span style={{ color: SUBJECT_COLORS[course.subject] ?? '#94a3b8', fontSize: 9, fontWeight: 700 }}>
                          {course.subject}
                        </span>
                        <span className="acad-course-card__dot">·</span>
                        <span>{course.lessons} lessen</span>
                        <span className="acad-course-card__dot">·</span>
                        <span>Level {course.level}</span>
                      </div>
                    </div>
                    {completed
                      ? <Trophy size={14} style={{ color: '#f59e0b', flexShrink: 0 }} />
                      : (
                        <button
                          className="acad-lesson-btn"
                          onClick={() => startLesson(course.id)}
                        >
                          <Zap size={10} /> Les {done + 1}
                        </button>
                      )
                    }
                  </div>
                  <div className="acad-course-progress">
                    <div className="acad-course-progress__track">
                      <div
                        className="acad-course-progress__fill"
                        style={{ width: `${pct}%`, background: completed ? '#4ade80' : SUBJECT_COLORS[course.subject] ?? '#f59e0b' }}
                      />
                    </div>
                    <span className="acad-course-progress__label">{done}/{course.lessons}</span>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {b2cTab === 'syllabus' && (
          <div className="acad-syllabus-section">
            <div className="acad-syllabus-header">
              <Award size={12} style={{ color: '#f59e0b' }} />
              <span>12-Weken AI Academy Programma · Certificering na Week 12</span>
            </div>
            {SYLLABUS_WEEKS.map(w => (
              <div key={w.week} className={`acad-syllabus-row${w.week === 12 ? ' acad-syllabus-row--cert' : ''}`}>
                <div className="acad-syllabus-row__week" style={{ color: w.week === 12 ? '#f59e0b' : '#475569' }}>
                  W{w.week}
                </div>
                <span className="acad-syllabus-row__icon">{w.icon}</span>
                <div className="acad-syllabus-row__body">
                  <div className="acad-syllabus-row__title">{w.title}</div>
                  <div className="acad-syllabus-row__topic">{w.topic}</div>
                </div>
                <div
                  className="acad-syllabus-row__tag"
                  style={{ color: SUBJECT_COLORS[w.subject] ?? '#94a3b8', borderColor: (SUBJECT_COLORS[w.subject] ?? '#94a3b8') + '44', background: (SUBJECT_COLORS[w.subject] ?? '#94a3b8') + '11' }}
                >
                  {w.subject}
                </div>
              </div>
            ))}
            <div className="acad-syllabus-cert">
              <GraduationCap size={11} style={{ color: '#f59e0b' }} />
              Week 12 — certificaat wordt digitaal uitgereikt. Abonnement eindigt automatisch.
            </div>
          </div>
        )}

        {b2cTab === 'progress' && (
          <div className="acad-progress-section">
            <div className="acad-progress-stats">
              <div className="acad-stat" style={{ borderColor: '#f59e0b33' }}>
                <span className="acad-stat__val" style={{ color: '#f59e0b' }}>{completedLessons}</span>
                <span className="acad-stat__label">Lessen voltooid</span>
              </div>
              <div className="acad-stat" style={{ borderColor: '#4ade8033' }}>
                <span className="acad-stat__val" style={{ color: '#4ade80' }}>{overallPct}%</span>
                <span className="acad-stat__label">Totale voortgang</span>
              </div>
              <div className="acad-stat" style={{ borderColor: '#38bdf833' }}>
                <span className="acad-stat__val" style={{ color: '#38bdf8' }}>
                  {B2C_COURSES.filter(c => (courseProgress[c.id] ?? 0) >= c.lessons).length}
                </span>
                <span className="acad-stat__label">Cursussen klaar</span>
              </div>
            </div>
            {B2C_COURSES.map(course => {
              const done = courseProgress[course.id] ?? 0;
              const pct  = Math.round((done / course.lessons) * 100);
              return (
                <div key={course.id} className="acad-progress-row">
                  <span className="acad-progress-row__icon">{course.icon}</span>
                  <span className="acad-progress-row__title">{course.title}</span>
                  <div className="acad-progress-row__bar">
                    <div
                      className="acad-progress-row__fill"
                      style={{ width: `${pct}%`, background: SUBJECT_COLORS[course.subject] ?? '#f59e0b' }}
                    />
                  </div>
                  <span className="acad-progress-row__pct" style={{ color: SUBJECT_COLORS[course.subject] ?? '#f59e0b' }}>{pct}%</span>
                </div>
              );
            })}
          </div>
        )}

        {/* ── Teacher Live Classroom Console ── */}
        {b2cTab === 'teacher' && (
          <div className="tc-root">

            {/* Console header */}
            <div className="tc-header">
              <div className="tc-header__left">
                <Terminal size={13} style={{ color: '#38bdf8' }} />
                <div>
                  <div className="tc-header__title">Teacher Live Classroom Console</div>
                  <div className="tc-header__sub">AIPPIETAX S.A. · v190 · Interne testomgeving · geen externe afhankelijkheden</div>
                </div>
              </div>
              <div className="tc-header__status">
                <span className="tc-status-dot tc-status-dot--live" />
                Live
              </div>
            </div>

            {/* Prompt input for AI Assistant node */}
            <div className="tc-prompt-input-wrap">
              <label className="tc-label"><ChevronRight size={10} style={{ color: '#38bdf8' }} /> Testprompt (optioneel — voor node 1)</label>
              <div className="tc-prompt-row">
                <input
                  className="tc-prompt-input"
                  placeholder="Typ een testprompt… bijv. Wat is een neuraal netwerk?"
                  value={promptInput}
                  onChange={e => setPromptInput(e.target.value)}
                  onKeyDown={e => { if (e.key === 'Enter') runTestNode(TEST_NODES[0]); }}
                />
                <button
                  className="tc-clear-btn"
                  onClick={() => { setPromptInput(''); setPromptOutput(''); setNodeStatus(prev => ({ ...prev, prompt: 'idle' })); setNodeLogs(prev => ({ ...prev, prompt: [] })); }}
                  title="Wis invoer"
                >
                  <RotateCcw size={11} />
                </button>
              </div>
            </div>

            {/* Three test nodes */}
            <div className="tc-nodes">
              {TEST_NODES.map(node => {
                const status = nodeStatus[node.id] ?? 'idle';
                const logs   = nodeLogs[node.id]  ?? [];
                return (
                  <div key={node.id} className={`tc-node tc-node--${status}`} style={{ '--tc-color': node.color } as React.CSSProperties}>

                    {/* Node header row */}
                    <div className="tc-node__header">
                      <span className="tc-node__emoji">{node.emoji}</span>
                      <div className="tc-node__meta">
                        <div className="tc-node__label" style={{ color: node.color }}>{node.label}</div>
                        <div className="tc-node__desc">{node.desc}</div>
                      </div>
                      <div className="tc-node__controls">
                        {status === 'running' && (
                          <span className="tc-node__spinner">
                            <Loader2 size={13} className="rem-spin" style={{ color: node.color }} />
                          </span>
                        )}
                        {(status === 'idle' || status === 'pass' || status === 'fail') && (
                          <button
                            className="tc-run-btn"
                            style={{ background: node.color + '22', borderColor: node.color + '55', color: node.color }}
                            onClick={() => runTestNode(node)}
                          >
                            <Play size={10} /> {status === 'idle' ? 'Run' : 'Opnieuw'}
                          </button>
                        )}
                        {(status === 'pass' || status === 'fail') && (
                          <span className={`tc-node__badge tc-node__badge--${status}`}>
                            {status === 'pass' ? <><CheckCircle2 size={10} /> PASS</> : <><AlertCircle size={10} /> FAIL</>}
                          </span>
                        )}
                      </div>
                    </div>

                    {/* Terminal log */}
                    {logs.length > 0 && (
                      <div className="tc-terminal">
                        {logs.map((line, i) => (
                          <div key={i} className="tc-terminal__line">
                            <span className="tc-terminal__prompt">▶</span>
                            <span className={`tc-terminal__text${i === logs.length - 1 && status === 'running' ? ' tc-terminal__text--cursor' : ''}`}>{line}</span>
                          </div>
                        ))}
                      </div>
                    )}

                    {/* Compilation progress bar (always visible while running or pass) */}
                    {(status === 'running' || status === 'pass') && (
                      <div className="tc-compile-bar-wrap">
                        <div className="tc-compile-bar">
                          <div
                            className="tc-compile-bar__fill"
                            style={{
                              background: node.color,
                              width: status === 'pass' ? '100%' : `${(logs.length / node.steps.length) * 100}%`,
                              transition: 'width 0.6s ease',
                            }}
                          />
                        </div>
                        <span className="tc-compile-bar__pct" style={{ color: node.color }}>
                          {status === 'pass' ? '100%' : `${Math.round((logs.length / node.steps.length) * 100)}%`}
                        </span>
                      </div>
                    )}

                    {/* AI prompt output (only for prompt node) */}
                    {node.id === 'prompt' && status === 'pass' && promptOutput && (
                      <div className="tc-prompt-output">
                        <div className="tc-prompt-output__label"><Brain size={9} style={{ color: '#38bdf8' }} /> AI Antwoord</div>
                        <div className="tc-prompt-output__text">{promptOutput}</div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>

            {/* Live classroom metrics strip */}
            <div className="tc-metrics">
              {[
                { label: 'Prompts getest',    val: Object.values(nodeStatus).filter(s => s === 'pass').toString().replace(/,/g, '') === '' ? String(Object.values(nodeStatus).filter(s => s === 'pass').length) : String(Object.values(nodeStatus).filter(s => s === 'pass').length), color: '#38bdf8' },
                { label: 'Compilaties OK',    val: nodeStatus['compiler'] === 'pass' ? '1' : '0',  color: '#f59e0b' },
                { label: 'Scans OK',          val: nodeStatus['scanner']  === 'pass' ? '1' : '0',  color: '#4ade80' },
                { label: 'Console status',    val: Object.values(nodeStatus).some(s => s === 'running') ? 'Actief' : 'Klaar', color: '#a78bfa' },
              ].map((m, i) => (
                <div key={i} className="tc-metric">
                  <span className="tc-metric__val" style={{ color: m.color }}>{m.val}</span>
                  <span className="tc-metric__label">{m.label}</span>
                </div>
              ))}
            </div>

            <div className="tc-disclaimer">
              <ShieldCheck size={8} style={{ color: '#334155' }} />
              Alle tests worden uitgevoerd binnen het lokale dashboard — geen externe websites of API-afhankelijkheden.
            </div>
          </div>
        )}

        {token && (
          <div className="acad-token-row">
            <CheckCircle2 size={9} style={{ color: '#4ade80' }} />
            <span>{token}</span>
          </div>
        )}

        <div className="acad-footer">
          <ShieldCheck size={8} style={{ color: '#4ade80' }} />
          AIPPIETAX S.A. · Kids Learning · GDPR · v190
        </div>
      </div>
    );
  }

  // ── B2B School Portal ───────────────────────────────────────────────────────
  const totalStudents = B2B_CLASSES.reduce((s, c) => s + c.students, 0);
  const avgScore = Math.round(B2B_CLASSES.reduce((s, c) => s + c.avg, 0) / B2B_CLASSES.length);

  return (
    <div className="acad-root">
      <div className="acad-bg" />

      <div className="acad-header">
        <div className="acad-header__icon"><Building2 size={13} style={{ color: '#4ade80' }} /></div>
        <div>
          <div className="acad-header__title">School Enterprise Portal · B2B · €199/maand</div>
          <div className="acad-header__sub">{totalStudents} studenten · {B2B_CLASSES.length} klassen · gem. {avgScore}%</div>
        </div>
      </div>

      {/* Avatar */}
      <div className="acad-avatar-strip">
        <div className="acad-avatar-wrap">
          <img
            src="/Jouw_alineatekst_(2).png"
            alt="Aippie"
            className={`acad-avatar${speaking ? ' acad-avatar--speaking' : ''}`}
            onError={e => {
              (e.currentTarget as HTMLImageElement).src =
                'https://images.pexels.com/photos/1858175/pexels-photo-1858175.jpeg?auto=compress&cs=tinysrgb&w=120&h=140&fit=crop&crop=faces';
            }}
          />
          {speaking && <div className="acad-avatar-ring" />}
          <div className="acad-avatar-badge"><Mic size={7} /> School Admin</div>
        </div>
        <div className="acad-avatar-subtitle">
          {speaking && subtitle
            ? <span className="acad-avatar-subtitle--active">{subtitle}</span>
            : <span className="acad-avatar-subtitle--idle">Enterprise School Portal · AIPPIETAX S.A. · v190</span>
          }
        </div>
      </div>

      {/* B2B stat strip */}
      <div className="acad-b2b-stats">
        <div className="acad-stat acad-stat--wide" style={{ borderColor: '#4ade8033' }}>
          <span className="acad-stat__val" style={{ color: '#4ade80' }}>{totalStudents}</span>
          <span className="acad-stat__label">Studenten actief</span>
        </div>
        <div className="acad-stat acad-stat--wide" style={{ borderColor: '#f59e0b33' }}>
          <span className="acad-stat__val" style={{ color: '#f59e0b' }}>{B2B_CLASSES.length}</span>
          <span className="acad-stat__label">Klassen</span>
        </div>
        <div className="acad-stat acad-stat--wide" style={{ borderColor: '#38bdf833' }}>
          <span className="acad-stat__val" style={{ color: '#38bdf8' }}>{avgScore}%</span>
          <span className="acad-stat__label">Gem. score</span>
        </div>
        <div className="acad-stat acad-stat--wide" style={{ borderColor: '#a78bfa33' }}>
          <span className="acad-stat__val" style={{ color: '#a78bfa' }}>AI</span>
          <span className="acad-stat__label">Auto-grading</span>
        </div>
      </div>

      {/* B2B tabs */}
      <div className="acad-tabs">
        <button className={`acad-tab${b2bTab === 'portal' ? ' acad-tab--active' : ''}`} style={{ '--acad-accent': '#4ade80' } as React.CSSProperties} onClick={() => setB2bTab('portal')}>
          <Building2 size={11} /> Portaal
        </button>
        <button className={`acad-tab${b2bTab === 'classes' ? ' acad-tab--active' : ''}`} style={{ '--acad-accent': '#4ade80' } as React.CSSProperties} onClick={() => setB2bTab('classes')}>
          <Users size={11} /> Klassen
        </button>
        <button className={`acad-tab${b2bTab === 'analytics' ? ' acad-tab--active' : ''}`} style={{ '--acad-accent': '#4ade80' } as React.CSSProperties} onClick={() => setB2bTab('analytics')}>
          <BarChart2 size={11} /> Analytics
        </button>
      </div>

      {b2bTab === 'portal' && (
        <div className="acad-portal-section">
          <div className="acad-portal-info">
            <Brain size={13} style={{ color: '#4ade80' }} />
            <div>
              <div className="acad-portal-info__title">White-Label School Portal</div>
              <div className="acad-portal-info__desc">
                Uw schoollogo, kleurstelling en domeinnaam zijn geconfigureerd. Alle AI-tutors lopen onder uw schoolidentiteit.
              </div>
            </div>
          </div>
          <div className="acad-portal-features">
            {[
              { icon: <CheckCircle2 size={10} style={{ color: '#4ade80' }} />, label: 'Volledig white-label — uw logo + kleuren' },
              { icon: <CheckCircle2 size={10} style={{ color: '#4ade80' }} />, label: 'AI holografische tutors per vak' },
              { icon: <CheckCircle2 size={10} style={{ color: '#4ade80' }} />, label: 'Geautomatiseerde cijferregistratie & rapportage' },
              { icon: <CheckCircle2 size={10} style={{ color: '#4ade80' }} />, label: 'Live leermetriek dashboard per klas' },
              { icon: <CheckCircle2 size={10} style={{ color: '#4ade80' }} />, label: 'Roosterbeheer en leerling-import (CSV/API)' },
              { icon: <CheckCircle2 size={10} style={{ color: '#4ade80' }} />, label: 'GDPR · ISO 27001 compliant dataverwerking' },
            ].map((f, i) => (
              <div key={i} className="acad-portal-feature-row">
                {f.icon} <span>{f.label}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {b2bTab === 'classes' && (
        <div className="acad-class-list">
          {B2B_CLASSES.map(cls => (
            <div key={cls.id} className="acad-class-card">
              <div className="acad-class-card__top">
                <div className="acad-class-card__grade">{cls.grade}</div>
                <div className={`acad-class-card__status${cls.active ? ' acad-class-card__status--active' : ''}`}>
                  {cls.active ? 'Live' : 'Offline'}
                </div>
              </div>
              <div className="acad-class-card__teacher">
                <Users size={9} style={{ color: '#64748b' }} /> {cls.teacher}
              </div>
              <div className="acad-class-card__bottom">
                <span><Users size={8} /> {cls.students} leerlingen</span>
                <span>
                  <Star size={8} style={{ color: '#f59e0b' }} />
                  gem. {cls.avg}%
                </span>
              </div>
              <div className="acad-class-card__bar">
                <div className="acad-class-card__bar-fill" style={{ width: `${cls.avg}%`, background: cls.avg >= 85 ? '#4ade80' : '#f59e0b' }} />
              </div>
            </div>
          ))}
        </div>
      )}

      {b2bTab === 'analytics' && (
        <div className="acad-analytics-section">
          <div className="acad-analytics-header">
            <BarChart2 size={12} style={{ color: '#38bdf8' }} />
            <span>Live Leeranalytics · AI Auto-Grading</span>
          </div>
          {B2B_CLASSES.map(cls => (
            <div key={cls.id} className="acad-analytics-row">
              <div className="acad-analytics-row__left">
                <span className="acad-analytics-row__grade">{cls.grade}</span>
                <span className="acad-analytics-row__count">{cls.students} st.</span>
              </div>
              <div className="acad-analytics-row__bar">
                <div
                  className="acad-analytics-row__fill"
                  style={{ width: `${cls.avg}%`, background: cls.avg >= 85 ? '#4ade80' : cls.avg >= 75 ? '#f59e0b' : '#f87171' }}
                />
              </div>
              <span
                className="acad-analytics-row__score"
                style={{ color: cls.avg >= 85 ? '#4ade80' : cls.avg >= 75 ? '#f59e0b' : '#f87171' }}
              >
                {cls.avg}%
              </span>
            </div>
          ))}
          <div className="acad-analytics-footer">
            <CheckCircle2 size={9} style={{ color: '#4ade80' }} />
            AI-grading actief · alle cijfers gesynchroniseerd · GDPR-compliant
          </div>
        </div>
      )}

      {token && (
        <div className="acad-token-row">
          <CheckCircle2 size={9} style={{ color: '#4ade80' }} />
          <span>{token}</span>
        </div>
      )}

      <div className="acad-footer">
        <ShieldCheck size={8} style={{ color: '#4ade80' }} />
        AIPPIETAX S.A. · School Enterprise · GDPR · v190
      </div>
    </div>
  );
}
