/**
 * GlobalLeadRadarPanel — V171 Global Real Estate Radar
 * AIPPIETAX S.A. · Real Estate AI
 *
 * B2C track: €5.00/mo — 5 broker listings from global markets (US · EMEA · UAE)
 * B2B track: €199.00/mo — warm buyer lead intercept radar with avatar alerts
 */
import { useCallback, useEffect, useRef, useState } from 'react';
import {
  Globe, Radar, TrendingUp, User, Phone, Link2,
  AlertCircle, CheckCircle2, Loader2, ShieldCheck,
  Mic, ChevronRight, Bell, BellRing, CreditCard, Lock,
  Building2, Star, Zap, RefreshCw,
} from 'lucide-react';
import { supabase } from '../lib/supabase';
import { applyPremiumVoice, normalizeForTTS, withVoicesReady } from '../lib/ttsVoice';

// ── Simulated lead data pools ──────────────────────────────────────────────────
// NOTE: All names, handles and phone numbers are entirely fictional demo data.
const LEAD_POOL = [
  { name: 'James Harrington',   market: 'UAE',  channel: 'LinkedIn',   intent: 92, budget: '€1M–€3M',       type: 'villa',       handle: '@j.harrington_dubai',    phone: '+971 5 *** ** 14', context: 'Posting about relocating to Dubai · seeking 4BR villa Palm Jumeirah area' },
  { name: 'Sofia Reinholt',     market: 'EMEA', channel: 'Instagram',  intent: 88, budget: '€500K–€900K',   type: 'penthouse',   handle: '@sofia.reinholt',        phone: '+31 6 *** ** 88', context: 'Story: "Looking for luxury penthouse Amsterdam or Rotterdam Q3"' },
  { name: 'Marcus Webb',        market: 'US',   channel: 'Facebook',   intent: 85, budget: '$800K–$1.4M',   type: 'townhouse',   handle: 'Marcus Webb',            phone: '+1 917 *** **72', context: 'Group post in Miami Real Estate Buyers: "Ready to buy, pre-approved"' },
  { name: 'Aisha Al-Fahad',     market: 'UAE',  channel: 'X',          intent: 91, budget: '€2M–€5M',       type: 'villa',       handle: '@aisha_alfahad',         phone: '+971 4 *** ** 33', context: 'Tweet: "Any agents for off-plan villa projects DIFC / Downtown Dubai?"' },
  { name: 'Lena Grunewald',     market: 'EMEA', channel: 'LinkedIn',   intent: 79, budget: '€300K–€600K',   type: 'apartment',   handle: '@lena.grunewald',        phone: '+49 176 *** **01', context: 'Post: Relocating to Barcelona for new tech role · apartment budget 500K' },
  { name: 'Ryan Castellano',    market: 'US',   channel: 'TikTok',     intent: 74, budget: '$500K–$750K',   type: 'apartment',   handle: '@ryancastellano.re',     phone: '+1 305 *** **58', context: 'TikTok: "Looking to buy my first condo Miami Beach — DM me agents!"' },
  { name: 'Charlotte Dupont',   market: 'EMEA', channel: 'Instagram',  intent: 83, budget: '€700K–€1.2M',  type: 'townhouse',   handle: '@charlotte.dupont.immo', phone: '+33 6 *** ** 47', context: 'Saved multiple Paris 7e listings · DM enquiry about viewing schedule' },
  { name: 'Omar Al-Rashidi',    market: 'UAE',  channel: 'LinkedIn',   intent: 95, budget: '€3M–€8M',       type: 'commercial',  handle: '@omar.alrashidi',        phone: '+971 5 *** ** 62', context: 'LinkedIn: "Seeking commercial real estate partners for Abu Dhabi expansion"' },
  { name: 'Nina Pettersson',    market: 'EMEA', channel: 'Facebook',   intent: 68, budget: '€200K–€400K',   type: 'apartment',   handle: 'Nina Pettersson',        phone: '+46 70 *** **39', context: 'Facebook group: "Moving to Malaga · budget 350K · any good agents?"' },
  { name: 'David Okafor',       market: 'US',   channel: 'X',          intent: 81, budget: '$1.2M–$2M',     type: 'villa',       handle: '@davidokafor_atl',       phone: '+1 404 *** **21', context: 'X thread: "Atlanta suburbs, serious buyer, closing by September"' },
  { name: 'Ingrid Solversen',   market: 'EMEA', channel: 'TikTok',     intent: 72, budget: '€400K–€700K',   type: 'finca',       handle: '@ingrid.solversen',      phone: '+47 40 *** **55', context: 'TikTok: touring rural Spanish finca properties — tagged 3 Malaga listings' },
  { name: 'Hassan Al-Mansouri', market: 'UAE',  channel: 'Instagram',  intent: 89, budget: '€1.5M–€4M',    type: 'penthouse',   handle: '@hassan.almansouri',     phone: '+971 5 *** ** 77', context: 'Story poll: "Which Dubai district for penthouse purchase — Jumeirah or Marina?"' },
] as const;

// Simulated B2C broker listings
const B2C_LISTINGS = [
  { id: 'b1', name: 'Sotheby\'s International Realty — Dubai', market: 'UAE',  specialty: 'Luxury villas & penthouses', rating: 4.9, phone: '+971 4 388 9999', verified: true },
  { id: 'b2', name: 'CBRE Netherlands',                        market: 'EMEA', specialty: 'Commercial & residential portfolio', rating: 4.7, phone: '+31 20 626 2666', verified: true },
  { id: 'b3', name: 'Coldwell Banker — Miami Beach',           market: 'US',   specialty: 'Luxury waterfront properties', rating: 4.8, phone: '+1 305 674 9200', verified: true },
  { id: 'b4', name: 'Knight Frank Spain',                      market: 'EMEA', specialty: 'Costa del Sol & Barcelona', rating: 4.6, phone: '+34 91 595 2020', verified: true },
  { id: 'b5', name: 'Betterhomes — Abu Dhabi',                 market: 'UAE',  specialty: 'Off-plan & investment properties', rating: 4.5, phone: '+971 2 626 2626', verified: true },
] as const;

const MARKET_COLORS: Record<string, string> = {
  UAE: '#fbbf24', US: '#38bdf8', EMEA: '#4ade80',
};
const CHANNEL_COLORS: Record<string, string> = {
  LinkedIn: '#0077b5', Facebook: '#1877f2', Instagram: '#e1306c',
  TikTok: '#69c9d0', X: '#1da1f2',
};

type PlanTier = 'none' | 'b2c' | 'b2b';
type AlertLead = typeof LEAD_POOL[number];

function useWordSub(text: string, active: boolean) {
  const [sub, setSub] = useState('');
  const tmr = useRef<ReturnType<typeof setInterval> | null>(null);
  const idx  = useRef(0);
  useEffect(() => {
    if (tmr.current) { clearInterval(tmr.current); tmr.current = null; }
    setSub('');
    if (!active || !text.trim()) return;
    const words = text.split(/\s+/);
    idx.current = 0;
    tmr.current = setInterval(() => {
      idx.current++;
      setSub(words.slice(Math.max(0, idx.current - 10), idx.current).join(' '));
      if (idx.current >= words.length && tmr.current) { clearInterval(tmr.current); tmr.current = null; }
    }, 380);
    return () => { if (tmr.current) { clearInterval(tmr.current); tmr.current = null; } };
  }, [text, active]);
  return sub;
}

interface Props {
  deviceKey: string;
}

export default function GlobalLeadRadarPanel({ deviceKey }: Props) {
  const [plan,         setPlan]         = useState<PlanTier>('none');
  const [cardInput,    setCardInput]    = useState('');
  const [cardError,    setCardError]    = useState('');
  const [activating,   setActivating]   = useState(false);
  const [pendingPlan,  setPendingPlan]  = useState<PlanTier>('none');
  const [scanning,     setScanning]     = useState(false);
  const [scanCount,    setScanCount]    = useState(0);
  const [leads,        setLeads]        = useState<typeof LEAD_POOL[number][]>([]);
  const [alertLead,    setAlertLead]    = useState<AlertLead | null>(null);
  const [alertVisible, setAlertVisible] = useState(false);
  const [alertIdx,     setAlertIdx]     = useState(0);
  const [speaking,     setSpeaking]     = useState(false);
  const [spokenText,   setSpokenText]   = useState('');
  const [viewedIds,    setViewedIds]    = useState<Set<string>>(new Set());
  const mountedRef  = useRef(true);
  const scanTmrRef  = useRef<ReturnType<typeof setInterval> | null>(null);
  const alertTmrRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const subtitle = useWordSub(spokenText, speaking);

  const speak = useCallback((text: string) => {
    if (!('speechSynthesis' in window)) return;
    window.speechSynthesis.cancel();
    setSpokenText(text);
    setSpeaking(true);
    const say = () => {
      const u = new SpeechSynthesisUtterance(normalizeForTTS(text));
      u.rate = 0.82; u.pitch = 1.02;
      applyPremiumVoice(u);
      u.onend   = () => { if (mountedRef.current) setSpeaking(false); };
      u.onerror = () => { if (mountedRef.current) setSpeaking(false); };
      window.speechSynthesis.speak(u);
    };
    withVoicesReady(say);
  }, []);

  useEffect(() => {
    mountedRef.current = true;
    // Check for existing plan in localStorage
    const stored = localStorage.getItem('aippie_re_radar_plan') as PlanTier | null;
    if (stored === 'b2c' || stored === 'b2b') setPlan(stored);
    return () => {
      mountedRef.current = false;
      if (scanTmrRef.current) clearInterval(scanTmrRef.current);
      if (alertTmrRef.current) clearTimeout(alertTmrRef.current);
      window.speechSynthesis?.cancel();
    };
  }, []);

  // ── Activation ─────────────────────────────────────────────────────────────
  const handleActivate = useCallback((tier: PlanTier) => {
    const stripped = cardInput.replace(/\s/g, '');
    if (stripped.length < 16) { setCardError('Please enter a valid 16-digit card number.'); return; }
    setCardError('');
    setActivating(true);

    setTimeout(() => {
      if (!mountedRef.current) return;
      setPlan(tier);
      localStorage.setItem('aippie_re_radar_plan', tier);
      setActivating(false);
      setCardInput('');

      // Persist activation lead to Supabase
      supabase.from('re_radar_leads').insert({
        device_key:    deviceKey,
        lead_name:     `Plan activated: ${tier.toUpperCase()}`,
        market:        'SYSTEM',
        source_channel:'activation',
        post_context:  `Radar plan ${tier} activated`,
        intent_score:  100,
        budget_range:  tier === 'b2b' ? '€199/mo' : '€5/mo',
        property_type: 'system',
        status:        'new',
        plan_tier:     tier,
      });

      const msg = tier === 'b2b'
        ? 'B2B Lead Intercept Radar geactiveerd. Ik scan nu Facebook, Instagram, LinkedIn, TikTok en X op koopintentie-signalen in de VS, EMEA en de VAE. Je ontvangt live pop-up meldingen bij elke warme lead.'
        : 'B2C Makelaar Zoekmodule geactiveerd. Ik heb vijf geverifieerde makelaars gevonden voor jouw geselecteerde markten. Klik op een makelaar voor directe contactgegevens.';
      speak(msg);

      if (tier === 'b2b') startScan();
    }, 1600);
  }, [cardInput, deviceKey, speak]); // eslint-disable-line react-hooks/exhaustive-deps

  // ── B2B scan simulation ────────────────────────────────────────────────────
  const startScan = useCallback(() => {
    setScanning(true);
    setScanCount(0);
    setLeads([]);
    let count = 0;
    scanTmrRef.current = setInterval(() => {
      count++;
      setScanCount(count);
      if (count >= LEAD_POOL.length) {
        clearInterval(scanTmrRef.current!);
        setLeads([...LEAD_POOL]);
        setScanning(false);
        // Fire first alert after scan completes
        triggerAlert([...LEAD_POOL][0], 0);
      }
    }, 220);
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const triggerAlert = useCallback((lead: AlertLead, idx: number) => {
    if (!mountedRef.current) return;
    setAlertLead(lead);
    setAlertIdx(idx);
    setAlertVisible(true);

    // Persist to Supabase
    supabase.from('re_radar_leads').insert({
      device_key:    deviceKey,
      lead_name:     lead.name,
      market:        lead.market,
      source_channel:lead.channel,
      post_context:  lead.context,
      intent_score:  lead.intent,
      budget_range:  lead.budget,
      property_type: lead.type,
      social_handle: lead.handle,
      phone_masked:  lead.phone,
      status:        'new',
      plan_tier:     'b2b',
    });

    const alertText =
      `Nieuwe warme lead onderschept. Naam: ${lead.name}. ` +
      `Markt: ${lead.market}. ` +
      `Kanaal: ${lead.channel}. ` +
      `Budget: ${lead.budget}. ` +
      `Intent score: ${lead.intent} procent. ` +
      `Zal ik deze lead nu direct contact opnemen?`;
    speak(alertText);

    // Auto-dismiss alert after 14 seconds, then fire next one
    alertTmrRef.current = setTimeout(() => {
      if (!mountedRef.current) return;
      setAlertVisible(false);
      const nextIdx = (idx + 1) % LEAD_POOL.length;
      if (nextIdx > 0 && nextIdx < 4) {
        alertTmrRef.current = setTimeout(() => triggerAlert([...LEAD_POOL][nextIdx], nextIdx), 8000);
      }
    }, 14000);
  }, [deviceKey, speak]); // eslint-disable-line react-hooks/exhaustive-deps

  const dismissAlert = useCallback(() => {
    setAlertVisible(false);
    if (alertTmrRef.current) clearTimeout(alertTmrRef.current);
    window.speechSynthesis?.cancel();
    setSpeaking(false);
  }, []);

  const markViewed = useCallback((name: string) => {
    setViewedIds(prev => new Set([...prev, name]));
    supabase.from('re_radar_leads')
      .update({ status: 'viewed' })
      .eq('device_key', deviceKey)
      .eq('lead_name', name);
  }, [deviceKey]);

  const rescan = useCallback(() => {
    if (scanTmrRef.current) clearInterval(scanTmrRef.current);
    startScan();
  }, [startScan]);

  // ── Paywall gate ───────────────────────────────────────────────────────────
  if (plan === 'none') {
    return (
      <div className="v171-root">
        <div className="v171-paywall__header">
          <div className="v171-paywall__icon-wrap">
            <Globe size={18} style={{ color: '#38bdf8' }} />
          </div>
          <div>
            <div className="v171-paywall__title">Global Real Estate Lead Radar</div>
            <div className="v171-paywall__sub">US · EMEA · UAE · Facebook · Instagram · LinkedIn · TikTok · X</div>
          </div>
        </div>

        <div className="v171-plan-grid">
          {/* B2C */}
          <div
            className={`v171-plan-card${pendingPlan === 'b2c' ? ' v171-plan-card--selected' : ''}`}
            style={{ borderColor: pendingPlan === 'b2c' ? '#38bdf8' : '#1e293b' }}
            onClick={() => setPendingPlan('b2c')}
          >
            <div className="v171-plan-card__badge" style={{ background: '#38bdf822', color: '#38bdf8', borderColor: '#38bdf844' }}>B2C · Particulier</div>
            <div className="v171-plan-card__price" style={{ color: '#38bdf8' }}>€5<span className="v171-plan-card__period">/maand</span></div>
            <div className="v171-plan-card__name">Makelaar Zoekmodule</div>
            <div className="v171-plan-card__desc">Automatisch beëindigd na 5 makelaarsvermeldingen. Geen verlenging.</div>
            <ul className="v171-plan-card__features">
              <li><CheckCircle2 size={9} style={{ color: '#38bdf8' }} /> 5 geverifieerde makelaars · Global</li>
              <li><CheckCircle2 size={9} style={{ color: '#38bdf8' }} /> US · EMEA · UAE marktselectie</li>
              <li><CheckCircle2 size={9} style={{ color: '#38bdf8' }} /> Direct contactgegevens</li>
              <li><CheckCircle2 size={9} style={{ color: '#38bdf8' }} /> Auto-beëindigt na 5 resultaten</li>
            </ul>
          </div>

          {/* B2B */}
          <div
            className={`v171-plan-card${pendingPlan === 'b2b' ? ' v171-plan-card--selected' : ''}`}
            style={{ borderColor: pendingPlan === 'b2b' ? '#4ade80' : '#1e293b' }}
            onClick={() => setPendingPlan('b2b')}
          >
            <div className="v171-plan-card__badge" style={{ background: '#4ade8022', color: '#4ade80', borderColor: '#4ade8044' }}>B2B · Makelaar</div>
            <div className="v171-plan-card__price" style={{ color: '#4ade80' }}>€199<span className="v171-plan-card__period">/maand</span></div>
            <div className="v171-plan-card__name">Lead Intercept Radar</div>
            <div className="v171-plan-card__desc">Enterprise. Warme kopersdata rechtstreeks naar uw makelaarsdashboard.</div>
            <ul className="v171-plan-card__features">
              <li><CheckCircle2 size={9} style={{ color: '#4ade80' }} /> Live koop-intent signalen · Facebook · Instagram · LinkedIn · TikTok · X</li>
              <li><CheckCircle2 size={9} style={{ color: '#4ade80' }} /> Avatar pop-up alerts bij elke warme lead</li>
              <li><CheckCircle2 size={9} style={{ color: '#4ade80' }} /> Intent score 0–100 per lead</li>
              <li><CheckCircle2 size={9} style={{ color: '#4ade80' }} /> Budget range · markt · kanaal · type</li>
              <li><CheckCircle2 size={9} style={{ color: '#4ade80' }} /> Supabase lead-pipeline sync</li>
            </ul>
          </div>
        </div>

        {pendingPlan !== 'none' && (
          <div className="v171-paywall__form">
            <label className="v171-form-label"><CreditCard size={10} /> Kaartnummer</label>
            <input
              type="text"
              inputMode="numeric"
              placeholder="4242 4242 4242 4242"
              className={`v171-form-input v171-form-input--mono${cardError ? ' v171-form-input--error' : ''}`}
              value={cardInput}
              maxLength={19}
              onChange={e => {
                setCardError('');
                setCardInput(e.target.value.replace(/\D/g, '').slice(0, 16).replace(/(.{4})/g, '$1 ').trim());
              }}
            />
            {cardError && <div className="v171-form-error"><AlertCircle size={10} /> {cardError}</div>}
            <div className="v171-form-hint">Testmodus · gebruik <span style={{ color: '#fbbf24' }}>4242 4242 4242 4242</span></div>

            <button
              className="v171-activate-btn"
              style={{
                background: pendingPlan === 'b2b'
                  ? 'linear-gradient(135deg,#4ade8033,#4ade8011)'
                  : 'linear-gradient(135deg,#38bdf833,#38bdf811)',
                borderColor: pendingPlan === 'b2b' ? '#4ade8066' : '#38bdf866',
                color: pendingPlan === 'b2b' ? '#4ade80' : '#38bdf8',
              }}
              disabled={activating || cardInput.replace(/\s/g, '').length < 16}
              onClick={() => handleActivate(pendingPlan)}
            >
              {activating
                ? <><Loader2 size={12} className="rem-spin" /> Activeren…</>
                : <><Lock size={12} /> Activeer {pendingPlan === 'b2b' ? 'B2B Lead Radar · €199/mo' : 'B2C Zoekmodule · €5/mo'}</>
              }
            </button>
          </div>
        )}

        <div className="v171-footer">
          <ShieldCheck size={8} style={{ color: '#4ade80' }} />
          AIPPIETAX S.A. · GDPR · Demo data only · v171
        </div>
      </div>
    );
  }

  // ── B2C — 5 broker listings ─────────────────────────────────────────────
  if (plan === 'b2c') {
    return (
      <div className="v171-root">
        <div className="v171-b2c-header">
          <CheckCircle2 size={13} style={{ color: '#38bdf8' }} />
          <span>Makelaar Zoekmodule · B2C · €5/maand</span>
          <span className="v171-b2c-count">5 / 5 vermeldingen</span>
        </div>
        <div className="v171-broker-list">
          {B2C_LISTINGS.map(b => (
            <div key={b.id} className="v171-broker-card">
              <div className="v171-broker-card__top">
                <div
                  className="v171-broker-card__market"
                  style={{ color: MARKET_COLORS[b.market], background: MARKET_COLORS[b.market] + '18', borderColor: MARKET_COLORS[b.market] + '44' }}
                >
                  {b.market}
                </div>
                <div className="v171-broker-card__name">{b.name}</div>
                {b.verified && <CheckCircle2 size={10} style={{ color: '#4ade80', flexShrink: 0 }} />}
              </div>
              <div className="v171-broker-card__specialty">{b.specialty}</div>
              <div className="v171-broker-card__bottom">
                <div className="v171-broker-card__stars">
                  {Array.from({ length: 5 }).map((_, i) => (
                    <Star key={i} size={9} style={{ fill: i < Math.floor(b.rating) ? '#fbbf24' : 'none', color: '#fbbf24' }} />
                  ))}
                  <span>{b.rating}</span>
                </div>
                <a className="v171-broker-card__phone" href={`tel:${b.phone.replace(/\s/g, '')}`}>
                  <Phone size={9} /> {b.phone}
                </a>
              </div>
            </div>
          ))}
        </div>
        <div className="v171-footer">
          <ShieldCheck size={8} style={{ color: '#4ade80' }} />
          AIPPIETAX S.A. · B2C · 5 vermeldingen actief · v171
        </div>
      </div>
    );
  }

  // ── B2B — Lead Intercept Radar ─────────────────────────────────────────────
  return (
    <div className="v171-root v171-root--b2b">

      {/* Avatar alert pop-up */}
      {alertVisible && alertLead && (
        <div className="v171-alert-overlay" onClick={dismissAlert}>
          <div className="v171-alert-popup" onClick={e => e.stopPropagation()}>
            <div className="v171-alert-popup__header">
              <BellRing size={12} style={{ color: '#fbbf24' }} />
              <span>Warme Lead Gedetecteerd</span>
              <button className="v171-alert-popup__close" onClick={dismissAlert}>✕</button>
            </div>

            {/* Avatar + subtitle */}
            <div className="v171-alert-popup__avatar-row">
              <div className="v171-alert-avatar-wrap">
                <img
                  src="/Jouw_alineatekst_(2).png"
                  alt="Aippie"
                  className={`v171-alert-avatar${speaking ? ' v171-alert-avatar--speaking' : ''}`}
                  onError={e => {
                    (e.currentTarget as HTMLImageElement).src =
                      'https://images.pexels.com/photos/1858175/pexels-photo-1858175.jpeg?auto=compress&cs=tinysrgb&w=120&h=140&fit=crop&crop=faces';
                  }}
                />
                {speaking && <div className="v171-alert-avatar-ring" />}
                <div className="v171-alert-avatar-badge"><Mic size={7} /> {alertIdx + 1}/{LEAD_POOL.length}</div>
              </div>
              <div className="v171-alert-popup__sub">
                {speaking && subtitle
                  ? <span className="v171-alert-popup__sub--active">{subtitle}</span>
                  : <span className="v171-alert-popup__sub--idle">Aippie AI Lead Radar · AIPPIETAX S.A.</span>
                }
              </div>
            </div>

            {/* Lead details */}
            <div className="v171-alert-lead">
              <div className="v171-alert-lead__name">{alertLead.name}</div>
              <div className="v171-alert-lead__context">"{alertLead.context}"</div>
              <div className="v171-alert-lead__meta">
                <div
                  className="v171-alert-lead__market"
                  style={{ color: MARKET_COLORS[alertLead.market], background: MARKET_COLORS[alertLead.market] + '18', borderColor: MARKET_COLORS[alertLead.market] + '44' }}
                >
                  {alertLead.market}
                </div>
                <div
                  className="v171-alert-lead__channel"
                  style={{ color: CHANNEL_COLORS[alertLead.channel] ?? '#94a3b8', background: (CHANNEL_COLORS[alertLead.channel] ?? '#94a3b8') + '18', borderColor: (CHANNEL_COLORS[alertLead.channel] ?? '#94a3b8') + '44' }}
                >
                  {alertLead.channel}
                </div>
                <div className="v171-alert-lead__score" style={{ color: alertLead.intent >= 85 ? '#4ade80' : '#fbbf24' }}>
                  {alertLead.intent}% intent
                </div>
              </div>
              <div className="v171-alert-lead__info">
                <span><TrendingUp size={9} /> {alertLead.budget}</span>
                <span><Building2 size={9} /> {alertLead.type}</span>
                <span><Link2 size={9} /> {alertLead.handle}</span>
                <span><Phone size={9} /> {alertLead.phone}</span>
              </div>
            </div>

            <div className="v171-alert-popup__actions">
              <button
                className="v171-alert-action-btn v171-alert-action-btn--primary"
                onClick={() => {
                  markViewed(alertLead.name);
                  dismissAlert();
                  speak(`Lead ${alertLead.name} has been marked as viewed and saved to your pipeline.`);
                }}
              >
                <CheckCircle2 size={11} /> Lead opslaan
              </button>
              <button className="v171-alert-action-btn v171-alert-action-btn--ghost" onClick={dismissAlert}>
                Sluiten
              </button>
            </div>
          </div>
        </div>
      )}

      {/* B2B dashboard header */}
      <div className="v171-b2b-header">
        <div className="v171-b2b-header__left">
          <div className="v171-b2b-header__icon">
            <Radar size={13} style={{ color: '#4ade80' }} />
          </div>
          <div>
            <div className="v171-b2b-header__title">B2B Lead Intercept Radar · €199/maand</div>
            <div className="v171-b2b-header__sub">
              {scanning
                ? `Scannen… ${scanCount} / ${LEAD_POOL.length} signalen verwerkt`
                : `${leads.length} leads in pipeline · US · EMEA · UAE`
              }
            </div>
          </div>
        </div>
        <button className="v171-rescan-btn" onClick={rescan} disabled={scanning}>
          {scanning ? <Loader2 size={10} className="rem-spin" /> : <RefreshCw size={10} />}
          {scanning ? 'Scannen…' : 'Rescan'}
        </button>
      </div>

      {/* Channel scan bar */}
      <div className="v171-channel-bar">
        {(['Facebook', 'Instagram', 'LinkedIn', 'TikTok', 'X'] as const).map(ch => (
          <div key={ch} className="v171-channel-item" style={{ color: CHANNEL_COLORS[ch] }}>
            <div
              className={`v171-channel-dot${scanning ? ' v171-channel-dot--pulse' : ''}`}
              style={{ background: CHANNEL_COLORS[ch] }}
            />
            {ch}
          </div>
        ))}
        <div className="v171-channel-item" style={{ color: '#334155', marginLeft: 'auto' }}>
          {scanning ? <Loader2 size={9} className="rem-spin" /> : <CheckCircle2 size={9} style={{ color: '#4ade80' }} />}
          {scanning ? `${scanCount} / ${LEAD_POOL.length}` : `${LEAD_POOL.length} live`}
        </div>
      </div>

      {/* Lead pipeline */}
      {leads.length === 0 && scanning && (
        <div className="v171-scan-progress">
          <Loader2 size={20} className="rem-spin" style={{ color: '#4ade80' }} />
          <span>Koop-intentie signalen intercepteren…</span>
        </div>
      )}

      {leads.length > 0 && (
        <div className="v171-lead-list">
          {leads.map((lead, i) => {
            const isViewed = viewedIds.has(lead.name);
            return (
              <div
                key={lead.name}
                className={`v171-lead-row${isViewed ? ' v171-lead-row--viewed' : ''}`}
                style={{ animationDelay: `${i * 40}ms` }}
                onClick={() => {
                  markViewed(lead.name);
                  triggerAlert(lead, i);
                }}
              >
                <div className="v171-lead-row__score-col">
                  <div
                    className="v171-lead-row__score"
                    style={{ color: lead.intent >= 85 ? '#4ade80' : lead.intent >= 70 ? '#fbbf24' : '#94a3b8' }}
                  >
                    {lead.intent}
                  </div>
                  <div className="v171-lead-row__score-label">score</div>
                </div>
                <div className="v171-lead-row__body">
                  <div className="v171-lead-row__name">
                    <User size={9} style={{ color: '#64748b' }} /> {lead.name}
                    {isViewed && <CheckCircle2 size={9} style={{ color: '#4ade80' }} />}
                  </div>
                  <div className="v171-lead-row__context">{lead.context}</div>
                  <div className="v171-lead-row__tags">
                    <span style={{ color: MARKET_COLORS[lead.market], background: MARKET_COLORS[lead.market] + '18', borderColor: MARKET_COLORS[lead.market] + '33' }} className="v171-tag">
                      {lead.market}
                    </span>
                    <span style={{ color: CHANNEL_COLORS[lead.channel] ?? '#94a3b8', background: (CHANNEL_COLORS[lead.channel] ?? '#94a3b8') + '18', borderColor: (CHANNEL_COLORS[lead.channel] ?? '#94a3b8') + '33' }} className="v171-tag">
                      {lead.channel}
                    </span>
                    <span className="v171-tag v171-tag--neutral">{lead.budget}</span>
                    <span className="v171-tag v171-tag--neutral">{lead.type}</span>
                  </div>
                  <div className="v171-lead-row__contact">
                    <Phone size={8} style={{ color: '#475569' }} /> {lead.phone}
                    <span className="v171-lead-row__sep">·</span>
                    <Link2 size={8} style={{ color: '#475569' }} /> {lead.handle}
                  </div>
                </div>
                <button
                  className="v171-lead-row__alert-btn"
                  title="Trigger avatar alert"
                  onClick={e => { e.stopPropagation(); triggerAlert(lead, i); }}
                >
                  <Bell size={10} />
                </button>
              </div>
            );
          })}
        </div>
      )}

      <div className="v171-footer">
        <ShieldCheck size={8} style={{ color: '#4ade80' }} />
        AIPPIETAX S.A. · B2B Lead Radar · Demo data · GDPR · v171
      </div>
    </div>
  );
}
