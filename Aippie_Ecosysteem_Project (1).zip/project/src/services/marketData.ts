export interface MarketAsset {
  symbol: string;
  name: string;
  price: number;
  change: number;
  changePercent: number;
  volume: number;
  high: number;
  low: number;
  marketValue: number;
  totalOutstandingShares: number;
}

export const aippieIpoTicker: MarketAsset = {
  symbol: "AIPI.MC",
  name: "AIPPIE S.A.",
  price: 1.00,
  change: 0.00,
  changePercent: 0.00,
  volume: 0,
  high: 1.00,
  low: 1.00,
  marketValue: 3000000.00,
  totalOutstandingShares: 3000000,
};

export const BME_SCALEUP_WATCHLIST = [
  "PHM.MC", "AMRK.MC", "CLNX.MC", "LOGN.MC", "SCTS.MC",
  "BKIA.MC", "SOLB.MC", "VIS.MC", "CVCO.MC", "EYNG.MC",
];

export interface BmeTicker {
  symbol: string;
  name: string;
  suffix: ".MC";
  segment: "BME Scaleup" | "Mercado Continuo" | "MAB";
}

export const BME_SCALEUP_SEGMENT: BmeTicker[] = [
  { symbol: "AIPI.MC",  name: "AIPPIE S.A.",          suffix: ".MC", segment: "BME Scaleup" },
  { symbol: "MGAS.MC",  name: "Masmovil",              suffix: ".MC", segment: "BME Scaleup" },
  { symbol: "CLNX.MC",  name: "Cellnex Telecom",       suffix: ".MC", segment: "Mercado Continuo" },
  { symbol: "VIS.MC",   name: "Viscofan",               suffix: ".MC", segment: "Mercado Continuo" },
  { symbol: "NTGY.MC",  name: "Naturgy",                suffix: ".MC", segment: "Mercado Continuo" },
];

export function formatMarketCap(value: number): string {
  if (value >= 1_000_000_000) return `€${(value / 1_000_000_000).toFixed(2)}B`;
  if (value >= 1_000_000)     return `€${(value / 1_000_000).toFixed(2)}M`;
  if (value >= 1_000)         return `€${(value / 1_000).toFixed(2)}K`;
  return `€${value.toFixed(2)}`;
}

export function formatVolume(volume: number): string {
  if (volume >= 1_000_000) return `${(volume / 1_000_000).toFixed(1)}M`;
  if (volume >= 1_000)     return `${(volume / 1_000).toFixed(0)}K`;
  return String(volume);
}
