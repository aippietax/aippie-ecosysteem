import { supabase } from '../lib/supabase';

export type AIOSModule =
  | 'tax'
  | 'legal'
  | 'life-assistant'
  | 'doctor'
  | 'trading'
  | 'accounting'
  | 'verifactu'
  | 'real-estate'
  | 'energy'
  | 'boardroom'
  | 'general';

export interface AIOSPayload {
  activeModule: AIOSModule;
  userPrompt: string;
  context?: Record<string, unknown>;
  lang?: string;
  jurisdiction?: string;
}

export interface AIOSResponse {
  success: boolean;
  aiResponse: string;
  meta?: Record<string, unknown>;
}

export async function handleAippieAIOSRouter(payload: AIOSPayload): Promise<AIOSResponse> {
  const { data, error } = await supabase.functions.invoke('aippie-aios-router', {
    body: payload,
  });
  if (error) throw new Error(error.message);
  return data as AIOSResponse;
}

// ─── Shared Context ───────────────────────────────────────────────────────────

export async function writeSharedContext(patch: Record<string, unknown>): Promise<void> {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return;

  const { data: existing } = await supabase
    .from('aippie_shared_context')
    .select('meta_context')
    .eq('user_id', user.id)
    .maybeSingle();

  const merged = { ...(existing?.meta_context as Record<string, unknown> ?? {}), ...patch };

  await supabase
    .from('aippie_shared_context')
    .upsert({ user_id: user.id, meta_context: merged }, { onConflict: 'user_id' });
}

export async function readSharedContext(): Promise<Record<string, unknown>> {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return {};
  const { data } = await supabase
    .from('aippie_shared_context')
    .select('meta_context')
    .eq('user_id', user.id)
    .maybeSingle();
  return (data?.meta_context as Record<string, unknown>) ?? {};
}

// ─── Boardroom Engine ─────────────────────────────────────────────────────────

export type BoardroomDepartment = 'tax' | 'commerce' | 'defense' | 'health';

export interface BoardroomMeeting {
  id: string;
  user_id: string;
  meeting_date: string;
  title: string;
  department: BoardroomDepartment;
  status: 'active' | 'completed' | 'scheduled';
  discussion_transcript: string | null;
  approved_actions: Array<{ action: string; approved: boolean; timestamp: string }>;
  created_at: string;
}

export interface EmperorBriefing {
  id: string;
  user_id: string;
  briefing_month: string;
  bruto_balance_eur: number;
  net_surplus_eur: number;
  tax_summary: string | null;
  commerce_summary: string | null;
  defense_summary: string | null;
  health_summary: string | null;
  master_directive: string | null;
  created_at: string;
}

export async function executeAutonomousCabinetMeeting(
  department: BoardroomDepartment,
  agendaItems: string[],
): Promise<BoardroomMeeting | null> {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return null;

  const sharedCtx = await readSharedContext();

  const prompt = `You are the AI Secretary of ${department.toUpperCase()} in the AIPPIE Autonomous Boardroom Cabinet.
Convene a formal cabinet meeting with the following agenda items:
${agendaItems.map((item, i) => `${i + 1}. ${item}`).join('\n')}

User context: ${JSON.stringify(sharedCtx)}

Produce a formal meeting transcript in the style of a government cabinet minutes document. Include:
- Opening statement from the Secretary of ${department}
- Discussion of each agenda item with analysis
- Approved actions voted on by the cabinet
- Closing directive

Format: structured paragraphs, under 400 words.`;

  const aiRes = await handleAippieAIOSRouter({
    activeModule: 'boardroom',
    userPrompt: prompt,
    lang: 'en',
  });

  const deptLabels: Record<BoardroomDepartment, string> = {
    tax:      'Tax & Fiscal Policy Council',
    commerce: 'Commerce & Enterprise Council',
    defense:  'Cybersecurity & Defense Council',
    health:   'Health & Wellness Council',
  };

  const { data, error } = await supabase
    .from('aippie_boardroom_meetings')
    .insert({
      user_id: user.id,
      title: `${deptLabels[department]} — ${new Date().toLocaleDateString('en-GB', { month: 'long', year: 'numeric' })}`,
      department,
      status: 'completed',
      discussion_transcript: aiRes.success ? aiRes.aiResponse : 'AI service unavailable.',
      approved_actions: agendaItems.map(item => ({
        action: item,
        approved: true,
        timestamp: new Date().toISOString(),
      })),
    })
    .select('*')
    .maybeSingle();

  if (error) console.error('[Boardroom] Insert error:', error.message);
  return data as BoardroomMeeting | null;
}

export async function generateMonthlyEmperorBriefing(
  financials: { bruto: number; net: number },
): Promise<EmperorBriefing | null> {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return null;

  const month = new Date().toISOString().slice(0, 7);
  const sharedCtx = await readSharedContext();

  const prompt = `Generate a supreme monthly intelligence briefing for the AIPPIE Emperor Cockpit.
Month: ${month}
Bruto Balance: €${financials.bruto.toFixed(2)}
Net Surplus: €${financials.net.toFixed(2)}
User context: ${JSON.stringify(sharedCtx)}

Produce a concise briefing for each of the 4 departments (Tax, Commerce, Defense, Health) plus a one-sentence master directive.
Format as JSON: { tax_summary, commerce_summary, defense_summary, health_summary, master_directive }
Each summary under 80 words. Master directive one sentence.`;

  const aiRes = await handleAippieAIOSRouter({
    activeModule: 'boardroom',
    userPrompt: prompt,
    lang: 'en',
  });

  let parsed: Record<string, string> = {};
  try {
    const jsonMatch = aiRes.aiResponse.match(/\{[\s\S]*\}/);
    if (jsonMatch) parsed = JSON.parse(jsonMatch[0]);
  } catch { /* fallback to raw */ }

  const month_str = new Date().toISOString().slice(0, 7);

  const { data, error } = await supabase
    .from('aippie_emperor_briefings')
    .upsert({
      user_id: user.id,
      briefing_month: month_str,
      bruto_balance_eur: financials.bruto,
      net_surplus_eur: financials.net,
      tax_summary:      parsed.tax_summary      || aiRes.aiResponse.slice(0, 200),
      commerce_summary: parsed.commerce_summary || null,
      defense_summary:  parsed.defense_summary  || null,
      health_summary:   parsed.health_summary   || null,
      master_directive: parsed.master_directive || 'All departments running autonomously under your master vision.',
    }, { onConflict: 'user_id,briefing_month' })
    .select('*')
    .maybeSingle();

  if (error) console.error('[Emperor] Upsert error:', error.message);
  return data as EmperorBriefing | null;
}

// ─── Enterprise / Company Context ─────────────────────────────────────────────

export interface AippieCompany {
  id: string;
  company_name: string;
  duns_number: string | null;
  country_code: string;
  vat_number: string | null;
  onboarding_step: number;
  onboarding_complete: boolean;
  created_at: string;
  updated_at: string;
}

export interface CompanyMember {
  id: string;
  company_id: string;
  user_id: string;
  role: 'admin' | 'member' | 'viewer';
  created_at: string;
}

export async function getActiveCompany(): Promise<AippieCompany | null> {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return null;
  const { data: membership } = await supabase
    .from('aippie_company_members')
    .select('company_id')
    .eq('user_id', user.id)
    .order('created_at', { ascending: true })
    .limit(1)
    .maybeSingle();
  if (!membership) return null;
  const { data: company } = await supabase
    .from('aippie_companies')
    .select('*')
    .eq('id', membership.company_id)
    .maybeSingle();
  return company as AippieCompany | null;
}

export async function getUserCompanies(): Promise<AippieCompany[]> {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return [];
  const { data: memberships } = await supabase
    .from('aippie_company_members')
    .select('company_id')
    .eq('user_id', user.id);
  if (!memberships?.length) return [];
  const ids = memberships.map(m => m.company_id);
  const { data: companies } = await supabase
    .from('aippie_companies')
    .select('*')
    .in('id', ids)
    .order('created_at', { ascending: true });
  return (companies ?? []) as AippieCompany[];
}

