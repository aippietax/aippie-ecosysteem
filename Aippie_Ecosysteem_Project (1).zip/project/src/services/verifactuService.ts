// VERI*FACTU service — AEAT electronic invoicing (mandatory Spain July 2025)

export type TipoFactura = 'F1' | 'F2' | 'R1' | 'R2' | 'R3' | 'R4' | 'R5';
export type AEATStatus  = 'PENDIENTE' | 'ENVIADO' | 'RECHAZADO' | 'ERROR' | 'BORRADOR';

export interface LineaFactura {
  descripcion:    string;
  cantidad:       number;
  precio_unitario: number;
  tipo_iva:       0 | 4 | 10 | 21;
  importe:        number;
}

export interface RegistroFacturacion {
  IDVersion: '1.0';
  IDEmisorFactura: {
    NIF:                string;
    NombreRazonSocial:  string;
  };
  NumSerieFactura:                   string;
  FechaExpedicionFacturaEmisor:      string; // DD-MM-YYYY
  TipoFactura:                       TipoFactura;
  DescripcionOperacion:              string;
  Destinatarios?: {
    IDDestinatario: {
      NIF?:                string;
      IDOtro?: { CodigoPais: string; IDType: string; ID: string };
      NombreRazonSocial:   string;
    };
  }[];
  Desglose: {
    DetalleIVA: {
      TipoImpositivo:                     string;
      BaseImponibleOImporteNoSujeto:      string;
      CuotaRepercutida:                   string;
    }[];
  };
  CuotaTotal:    string;
  ImporteTotal:  string;
}

export interface AEATResponse {
  CSV?:          string;
  EstadoRegistro?: string;
  CodigoErrorRegistro?: string;
  DescripcionErrorRegistro?: string;
  raw?:          unknown;
}

export interface InvoiceData {
  id?:                   string;
  device_key:            string;
  numero_serie:          string;
  fecha_expedicion:      string; // YYYY-MM-DD
  tipo_factura:          TipoFactura;
  nif_emisor:            string;
  nombre_emisor:         string;
  nif_destinatario?:     string;
  nombre_destinatario?:  string;
  direccion_destinatario?: string;
  pais_destinatario:     string;
  descripcion:           string;
  lineas:                LineaFactura[];
  base_imponible:        number;
  cuota_iva:             number;
  importe_total:         number;
  hash_huella?:          string;
  qr_code?:              string;
  aeat_status:           AEATStatus;
  aeat_response?:        AEATResponse;
  aeat_timestamp?:       string;
  user_id?:              string | null;
}

// ── Endpoints ────────────────────────────────────────────────────────────────
const AEAT_PROD = 'https://www1.agenciatributaria.gob.es/wlpl/AVIT-CORE/rest/verifactu/RegistroFacturacion';
const AEAT_TEST = 'https://prewww1.aeat.es/wlpl/AVIT-CORE/rest/verifactu/RegistroFacturacion';

// ── Date helpers ─────────────────────────────────────────────────────────────
export function toAEATDate(isoDate: string): string {
  // YYYY-MM-DD → DD-MM-YYYY
  const [y, m, d] = isoDate.split('-');
  return `${d}-${m}-${y}`;
}

export function todayISO(): string {
  return new Date().toISOString().slice(0, 10);
}

// ── NIF validator ─────────────────────────────────────────────────────────────
export function isValidNIF(nif: string): boolean {
  const clean = nif.trim().toUpperCase().replace(/[\s\-\.]/g, '');
  if (/^[ABCDEFGHJKLMNPQRSUVW]\d{7}[0-9A-J]$/.test(clean)) return true; // Spain CIF
  if (/^\d{8}[TRWAGMYFPDXBNJZSQVHLCKE]$/.test(clean)) return true;        // Spain DNI
  if (/^[XYZ]\d{7}[TRWAGMYFPDXBNJZSQVHLCKE]$/.test(clean)) return true;  // Spain NIE
  if (/^\d{8}$/.test(clean)) return true;                                  // Netherlands KVK
  if (/^DE\d{9}$/.test(clean)) return true;                                // Germany USt
  if (/^FR[A-Z0-9]{2}\d{9}$/.test(clean)) return true;                    // France SIRET
  if (/^BE\d{10}$/.test(clean)) return true;                               // Belgium BTW
  if (/^GB\d{9}$/.test(clean)) return true;                                // UK VAT
  if (/^\d{2}-?\d{7}$/.test(clean)) return true;                          // USA EIN
  if (/^[A-Z]{2}[A-Z0-9]{2,12}$/.test(clean)) return true;               // Generic EU VAT
  if (/^[A-Z0-9]{6,20}$/.test(clean)) return true;
  return false;
}

// ── Hash chain (SHA-256) ─────────────────────────────────────────────────────
export async function generateHashChain(
  invoice: Pick<InvoiceData, 'nif_emisor' | 'numero_serie' | 'fecha_expedicion' | 'importe_total'>,
  previousHash: string,
): Promise<string> {
  const raw = [
    invoice.nif_emisor,
    invoice.numero_serie,
    toAEATDate(invoice.fecha_expedicion),
    invoice.importe_total.toFixed(2),
    previousHash,
  ].join('&');

  const buffer = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(raw));
  const hex = Array.from(new Uint8Array(buffer))
    .map(b => b.toString(16).padStart(2, '0'))
    .join('');
  return hex.toUpperCase();
}

// ── QR code URL (AEAT format) ─────────────────────────────────────────────────
export function generateQRUrl(invoice: InvoiceData, hash: string): string {
  const base = 'https://www2.agenciatributaria.gob.es/wlpl/AVIT-CORE/rest/verifactu/qr';
  const params = new URLSearchParams({
    nif:    invoice.nif_emisor,
    numserie: invoice.numero_serie,
    fecha:  toAEATDate(invoice.fecha_expedicion),
    importe: invoice.importe_total.toFixed(2),
    huella: hash.slice(0, 64),
  });
  return `${base}?${params.toString()}`;
}

// ── Build RegistroFacturacion ─────────────────────────────────────────────────
export function buildRegistro(invoice: InvoiceData): RegistroFacturacion {
  // Group lines by IVA rate for Desglose
  const ivaGroups: Record<number, { base: number; cuota: number }> = {};
  for (const line of invoice.lineas) {
    if (!ivaGroups[line.tipo_iva]) ivaGroups[line.tipo_iva] = { base: 0, cuota: 0 };
    const base = line.cantidad * line.precio_unitario;
    ivaGroups[line.tipo_iva].base  += base;
    ivaGroups[line.tipo_iva].cuota += base * line.tipo_iva / 100;
  }

  const registro: RegistroFacturacion = {
    IDVersion: '1.0',
    IDEmisorFactura: {
      NIF:               invoice.nif_emisor,
      NombreRazonSocial: invoice.nombre_emisor,
    },
    NumSerieFactura:                  invoice.numero_serie,
    FechaExpedicionFacturaEmisor:     toAEATDate(invoice.fecha_expedicion),
    TipoFactura:                      invoice.tipo_factura,
    DescripcionOperacion:             invoice.descripcion,
    Desglose: {
      DetalleIVA: Object.entries(ivaGroups).map(([rate, vals]) => ({
        TipoImpositivo:                 parseFloat(rate).toFixed(2),
        BaseImponibleOImporteNoSujeto:  vals.base.toFixed(2),
        CuotaRepercutida:               vals.cuota.toFixed(2),
      })),
    },
    CuotaTotal:   invoice.cuota_iva.toFixed(2),
    ImporteTotal: invoice.importe_total.toFixed(2),
  };

  if (invoice.nombre_destinatario) {
    const dest: RegistroFacturacion['Destinatarios'] = [{
      IDDestinatario: {
        NombreRazonSocial: invoice.nombre_destinatario,
      },
    }];
    if (invoice.nif_destinatario) {
      if (invoice.pais_destinatario === 'ES') {
        dest[0].IDDestinatario.NIF = invoice.nif_destinatario;
      } else {
        dest[0].IDDestinatario.IDOtro = {
          CodigoPais: invoice.pais_destinatario,
          IDType:     '04',
          ID:         invoice.nif_destinatario,
        };
      }
    }
    registro.Destinatarios = dest;
  }

  return registro;
}

// ── Send to AEAT ─────────────────────────────────────────────────────────────
export async function sendToAEAT(
  registro: RegistroFacturacion,
  entorno: 'PRODUCCION' | 'PRUEBAS' = 'PRUEBAS',
): Promise<AEATResponse> {
  const url = entorno === 'PRODUCCION' ? AEAT_PROD : AEAT_TEST;
  try {
    const res = await fetch(url, {
      method:  'POST',
      headers: { 'Content-Type': 'application/json' },
      body:    JSON.stringify({ RegistroFacturacion: registro }),
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) {
      return {
        EstadoRegistro:               'RECHAZADO',
        CodigoErrorRegistro:          String(res.status),
        DescripcionErrorRegistro:     data?.message ?? `HTTP ${res.status}`,
        raw:                          data,
      };
    }
    return { EstadoRegistro: 'ENVIADO', CSV: data?.CSV, raw: data };
  } catch (err) {
    return {
      EstadoRegistro:           'ERROR',
      DescripcionErrorRegistro: err instanceof Error ? err.message : 'Network error',
    };
  }
}

// ── Calcular totales ──────────────────────────────────────────────────────────
export function calcularTotales(lineas: LineaFactura[]): {
  base_imponible: number; cuota_iva: number; importe_total: number;
} {
  let base = 0, cuota = 0;
  for (const l of lineas) {
    const b = l.cantidad * l.precio_unitario;
    base  += b;
    cuota += b * l.tipo_iva / 100;
  }
  return {
    base_imponible: Math.round(base  * 100) / 100,
    cuota_iva:      Math.round(cuota * 100) / 100,
    importe_total:  Math.round((base + cuota) * 100) / 100,
  };
}

// ── Human-readable AEAT error codes ──────────────────────────────────────────
const ERROR_CODES: Record<string, string> = {
  '1101': 'NIF del emisor no encontrado en AEAT',
  '1102': 'NIF del destinatario no válido',
  '1103': 'Número de factura duplicado',
  '1104': 'Fecha de expedición fuera de rango permitido',
  '1105': 'Formato de XML/JSON incorrecto',
  '1106': 'Firma digital inválida o ausente',
  '1107': 'Importe total no coincide con la suma de líneas',
  '1201': 'Certificado digital caducado',
  '1202': 'Certificado digital no reconocido por AEAT',
  '400':  'Petición incorrecta — revisa el formato del registro',
  '401':  'No autorizado — certificado digital requerido',
  '403':  'Acceso denegado',
  '429':  'Límite de peticiones superado — espera 60 segundos',
  '500':  'Error interno de AEAT — reinténtalo más tarde',
};

export function getErrorDescription(code: string): string {
  return ERROR_CODES[code] ?? `Error AEAT: ${code}`;
}

// ── Suggested descriptions by IVA ────────────────────────────────────────────
export function suggestIVA(descripcion: string): 0 | 4 | 10 | 21 {
  const d = descripcion.toLowerCase();
  if (/aliment|fruta|verdura|pan|leche|huevo|agua/.test(d)) return 4;
  if (/hostal|hotel|restaurante|cine|teatro|deporte|transport|taxi|autobús/.test(d)) return 10;
  if (/médic|médico|sanidad|educaci|libro|perio|maga|farmac/.test(d)) return 4;
  return 21;
}
