import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  server: {
    hmr: {
      overlay: false,
    },
  },
  build: {
    chunkSizeWarningLimit: 1000,
    rollupOptions: {
      input: {
        main: 'index.html',
        world: 'public/world.html',
      },
      output: {
        manualChunks(id) {
          if (id.includes('face-api')) return 'face-api';
          if (id.includes('@supabase')) return 'supabase';
          if (id.includes('lucide-react')) return 'lucide';
          if (id.includes('@capacitor')) return 'capacitor';
          if (id.includes('node_modules/react') || id.includes('node_modules/react-dom')) return 'react';
          if (id.includes('node_modules')) return 'vendor';
        },
      },
    },
  },
});
