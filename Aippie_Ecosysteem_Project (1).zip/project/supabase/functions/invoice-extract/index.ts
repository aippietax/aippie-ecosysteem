import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "jsr:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

interface ExtractedInvoice {
  series?: string;
  invoice_number?: string;
  issue_date?: string;
  issuer_nif?: string;
  issuer_name?: string;
  recipient_nif?: string;
  recipient_name?: string;
  base_amount?: number;
  vat_rate?: number;
  vat_amount?: number;
  total_amount?: number;
  raw_text: string;
}

function extractInvoiceFields(text: string): ExtractedInvoice {
  const clean = text.replace(/\s+/g, " ").trim();

  const nifPattern = /\b([A-Z]\d{7}[A-Z0-9]|\d{8}[A-Z])\b/g;
  const nifs = [...clean.matchAll(nifPattern)].map((m) => m[1]);

  const dateMatch = clean.match(
    /(\d{1,2})[\/\-\.](\d{1,2})[\/\-\.](\d{2,4})/
  );
  let issue_date: string | undefined;
  if (dateMatch) {
    const [, d, m, y] = dateMatch;
    const year = y.length === 2 ? `20${y}` : y;
    issue_date = `${year}-${m.padStart(2, "0")}-${d.padStart(2, "0")}`;
  }

  const invoiceNumMatch = clean.match(
    /(?:factura|n[uú]mero|n[oº°]\.?\s*)[\s:#]*([\w\-\/]+)/i
  );

  const totalMatch = clean.match(/total\s*[:\s]\s*([\d.,]+)\s*€?/i);
  const baseMatch = clean.match(
    /(?:base\s*imponible|importe\s*neto|subtotal)\s*[:\s]\s*([\d.,]+)\s*€?/i
  );
  const vatRateMatch = clean.match(/IVA\s*([\d.,]+)\s*%/i);
  const vatAmountMatch = clean.match(
    /(?:cuota\s*IVA|IVA\s*[:\s])\s*([\d.,]+)\s*€?/i
  );

  const parseAmount = (s: string | undefined): number | undefined => {
    if (!s) return undefined;
    return parseFloat(s.replace(/\./g, "").replace(",", "."));
  };

  return {
    invoice_number: invoiceNumMatch?.[1],
    issue_date,
    issuer_nif: nifs[0],
    recipient_nif: nifs[1],
    base_amount: parseAmount(baseMatch?.[1]),
    vat_rate: vatRateMatch ? parseFloat(vatRateMatch[1].replace(",", ".")) : 21,
    vat_amount: parseAmount(vatAmountMatch?.[1]),
    total_amount: parseAmount(totalMatch?.[1]),
    raw_text: text,
  };
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_ANON_KEY")!,
      { global: { headers: { Authorization: authHeader } } }
    );

    const { data: { user }, error: authError } = await supabase.auth.getUser();
    if (authError || !user) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const contentType = req.headers.get("content-type") || "";
    let rawText = "";

    if (contentType.includes("application/json")) {
      const body = await req.json();
      rawText = body.text ?? "";
    } else if (contentType.includes("text/plain")) {
      rawText = await req.text();
    } else {
      return new Response(
        JSON.stringify({ error: "Unsupported content type. Send text/plain or application/json with {text}" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    if (!rawText.trim()) {
      return new Response(JSON.stringify({ error: "Empty text payload" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const extracted = extractInvoiceFields(rawText);

    return new Response(JSON.stringify({ success: true, extracted }), {
      status: 200,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (err) {
    return new Response(JSON.stringify({ error: String(err) }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
