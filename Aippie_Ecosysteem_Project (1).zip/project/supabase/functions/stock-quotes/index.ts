import "jsr:@supabase/functions-js/edge-runtime.d.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

const STOCK_SYMBOLS  = ["AAPL", "NVDA", "MSFT", "TSLA", "SPY", "QQQ"];
const INDEX_SYMBOLS  = ["%5ENDX", "%5EGSPC", "%5EVIX"];  // URL-encoded ^ prefix

async function fetchQuotes(symbols: string[]): Promise<Record<string, { price: number; change: number }>> {
  const url = `https://query1.finance.yahoo.com/v7/finance/quote?symbols=${symbols.join(",")}&fields=regularMarketPrice,regularMarketChangePercent`;
  const res = await fetch(url, {
    headers: { "User-Agent": "Mozilla/5.0", "Accept": "application/json" },
    signal: AbortSignal.timeout(8000),
  });
  if (!res.ok) return {};
  const raw = await res.json();
  const quotes = raw?.quoteResponse?.result ?? [];
  const result: Record<string, { price: number; change: number }> = {};
  for (const q of quotes) {
    result[q.symbol] = {
      price:  q.regularMarketPrice ?? 0,
      change: q.regularMarketChangePercent ?? 0,
    };
  }
  return result;
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    // Fetch stocks and indices concurrently; indices may fail silently
    const [stocks, indices] = await Promise.all([
      fetchQuotes(STOCK_SYMBOLS),
      fetchQuotes(INDEX_SYMBOLS).catch(() => ({})),
    ]);

    const result = { ...stocks, ...indices };

    return new Response(JSON.stringify(result), {
      status: 200,
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json",
        "Cache-Control": "public, max-age=58",
      },
    });
  } catch (err) {
    return new Response(JSON.stringify({ error: String(err) }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
