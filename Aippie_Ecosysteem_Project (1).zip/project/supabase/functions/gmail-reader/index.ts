import "jsr:@supabase/functions-js/edge-runtime.d.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const accessToken = Deno.env.get("GMAIL_ACCESS_TOKEN");
    if (!accessToken) {
      return new Response(JSON.stringify({
        error: "GMAIL_ACCESS_TOKEN not configured. Add it as an Edge Function secret.",
        setup: "Go to https://console.cloud.google.com → create OAuth2 credentials → authorize Gmail readonly scope → paste the access token as GMAIL_ACCESS_TOKEN secret.",
      }), { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    // Fetch last 10 unread inbox messages
    const listRes = await fetch(
      "https://gmail.googleapis.com/gmail/v1/users/me/messages?labelIds=INBOX&q=is:unread&maxResults=10",
      { headers: { Authorization: `Bearer ${accessToken}` } }
    );

    if (!listRes.ok) {
      const err = await listRes.json();
      return new Response(JSON.stringify({ error: err }), {
        status: listRes.status, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const listData = await listRes.json();
    const messageIds: string[] = (listData.messages ?? []).map((m: { id: string }) => m.id);

    const emails = await Promise.all(
      messageIds.map(async (id) => {
        const r = await fetch(
          `https://gmail.googleapis.com/gmail/v1/users/me/messages/${id}?format=metadata&metadataHeaders=From&metadataHeaders=Subject&metadataHeaders=Date`,
          { headers: { Authorization: `Bearer ${accessToken}` } }
        );
        if (!r.ok) return null;
        const d = await r.json();
        const headers: { name: string; value: string }[] = d.payload?.headers ?? [];
        const get = (name: string) => headers.find(h => h.name === name)?.value ?? "";
        return {
          id,
          from:    get("From"),
          subject: get("Subject"),
          date:    get("Date"),
          snippet: d.snippet ?? "",
          unread:  true,
        };
      })
    );

    return new Response(JSON.stringify({ emails: emails.filter(Boolean) }), {
      status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (err) {
    return new Response(JSON.stringify({ error: String(err) }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
