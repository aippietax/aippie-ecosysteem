import "jsr:@supabase/functions-js/edge-runtime.d.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const apiKey = Deno.env.get("HOLLED_API_KEY");
    if (!apiKey) {
      return new Response(JSON.stringify({
        error: "HOLLED_API_KEY not configured.",
        setup: "Go to your Holled account → Settings → Integrations → API → copy your API key → add it as HOLLED_API_KEY secret.",
      }), { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    // Fetch unpaid invoices from Holled API
    const res = await fetch("https://api.holded.com/api/invoicing/v1/documents/invoice?status=unpaid", {
      headers: {
        key: apiKey,
        "Content-Type": "application/json",
      },
    });

    if (!res.ok) {
      const err = await res.text();
      return new Response(JSON.stringify({ error: err }), {
        status: res.status, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const data = await res.json();

    // Normalize invoices
    const invoices = (Array.isArray(data) ? data : data.data ?? []).map((inv: {
      docNumber?: string; contact?: string; total?: number; currency?: string;
      dueDate?: number; status?: string;
    }) => ({
      number:   inv.docNumber ?? "—",
      client:   inv.contact ?? "Unknown",
      amount:   inv.total ?? 0,
      currency: inv.currency ?? "EUR",
      due_date: inv.dueDate ? new Date(inv.dueDate * 1000).toLocaleDateString("en-GB") : "—",
      status:   inv.status ?? "unpaid",
    }));

    const totalOpen = invoices.reduce((s: number, i: { amount: number }) => s + i.amount, 0);

    return new Response(JSON.stringify({ invoices, total_open: totalOpen, count: invoices.length }), {
      status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (err) {
    return new Response(JSON.stringify({ error: String(err) }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
