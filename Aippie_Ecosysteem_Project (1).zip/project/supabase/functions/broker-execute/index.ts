import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

// ─── Binance ──────────────────────────────────────────────────────────────────

async function hmacSha256(secret: string, data: string): Promise<string> {
  const key = await crypto.subtle.importKey(
    "raw", new TextEncoder().encode(secret),
    { name: "HMAC", hash: "SHA-256" }, false, ["sign"]
  );
  const sig = await crypto.subtle.sign("HMAC", key, new TextEncoder().encode(data));
  return Array.from(new Uint8Array(sig)).map(b => b.toString(16).padStart(2, "0")).join("");
}

const BINANCE_SYMBOL_MAP: Record<string, string> = {
  "BTC/USD": "BTCUSDT",
  "ETH/USD": "ETHUSDT",
  "SOL/USD": "SOLUSDT",
  "BNB/USD": "BNBUSDT",
};

async function binanceOrder(
  apiKey: string, apiSecret: string,
  symbol: string, side: "BUY" | "SELL", qty: number
): Promise<Record<string, unknown>> {
  const bnSym = BINANCE_SYMBOL_MAP[symbol] ?? symbol.replace("/", "").replace("USD", "USDT");

  // Binance lot size rules (conservative minimums)
  const lotSizes: Record<string, number> = {
    BTCUSDT: 5, ETHUSDT: 4, SOLUSDT: 2, BNBUSDT: 3,
  };
  const precision = lotSizes[bnSym] ?? 4;
  const qtyStr = qty.toFixed(precision);

  const timestamp = Date.now();
  const params = `symbol=${bnSym}&side=${side}&type=MARKET&quantity=${qtyStr}&timestamp=${timestamp}&recvWindow=10000`;
  const signature = await hmacSha256(apiSecret, params);

  const res = await fetch(`https://api.binance.com/api/v3/order?${params}&signature=${signature}`, {
    method: "POST",
    headers: {
      "X-MBX-APIKEY": apiKey,
      "Content-Type": "application/x-www-form-urlencoded",
    },
    signal: AbortSignal.timeout(12_000),
  });

  const data = await res.json() as Record<string, unknown>;
  if (!res.ok) throw new Error(`Binance error: ${JSON.stringify(data)}`);
  return data;
}

// ─── Alpaca ───────────────────────────────────────────────────────────────────

async function alpacaOrder(
  apiKey: string, apiSecret: string,
  symbol: string, side: "buy" | "sell", qty: number, mode: "paper" | "live"
): Promise<Record<string, unknown>> {
  const baseUrl = mode === "live"
    ? "https://api.alpaca.markets"
    : "https://paper-api.alpaca.markets";

  // Use fractional qty (2 decimal places) so small amounts work
  const qtyStr = qty.toFixed(2);

  const res = await fetch(`${baseUrl}/v2/orders`, {
    method: "POST",
    headers: {
      "APCA-API-KEY-ID": apiKey,
      "APCA-API-SECRET-KEY": apiSecret,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      symbol,
      qty: qtyStr,
      side,
      type: "market",
      time_in_force: "day",
    }),
    signal: AbortSignal.timeout(12_000),
  });

  const data = await res.json() as Record<string, unknown>;
  if (!res.ok) throw new Error(`Alpaca error: ${JSON.stringify(data)}`);
  return data;
}

// ─── Handler ──────────────────────────────────────────────────────────────────

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  const respond = (body: unknown, status = 200) =>
    new Response(JSON.stringify(body), {
      status, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });

  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) return respond({ error: "Unauthorized" }, 401);

    // Verify requesting user via JWT
    const anonClient = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_ANON_KEY")!,
      { global: { headers: { Authorization: authHeader } } }
    );
    const { data: { user }, error: authErr } = await anonClient.auth.getUser();
    if (authErr || !user) return respond({ error: "Invalid token" }, 401);

    const body = await req.json() as { broker?: string; symbol?: string; side?: string; qty?: number };
    const { broker, symbol, side, qty } = body;

    if (!broker || !symbol || !side || !qty) {
      return respond({ error: "Required: broker, symbol, side, qty" }, 400);
    }

    // Service-role client to read secrets (bypasses RLS)
    const svcClient = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
    );

    const { data: secret, error: sErr } = await svcClient
      .from("broker_secrets")
      .select("api_key, api_secret, mode")
      .eq("user_id", user.id)
      .eq("broker", broker)
      .single();

    if (sErr || !secret) return respond({ error: "No active connection found for this broker" }, 404);

    let result: Record<string, unknown>;

    if (broker === "binance" || broker === "bybit") {
      if (broker === "bybit") return respond({ error: "Bybit execution coming soon — use Binance for now" }, 400);
      result = await binanceOrder(secret.api_key, secret.api_secret, symbol, side.toUpperCase() as "BUY" | "SELL", Number(qty));
    } else if (broker === "alpaca") {
      result = await alpacaOrder(secret.api_key, secret.api_secret, symbol, side.toLowerCase() as "buy" | "sell", Number(qty), secret.mode);
    } else {
      return respond({ error: `Broker '${broker}' not yet supported for live execution` }, 400);
    }

    return respond({ ok: true, broker, symbol, side, qty, mode: secret.mode, result });

  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    return respond({ error: msg }, 500);
  }
});
