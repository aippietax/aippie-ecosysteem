import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "jsr:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

const VAT_DEDUCTIBLE_CATEGORIES = new Set([
  "software", "it_and_electronics", "office_supply", "professional_service",
  "legal_and_accounting", "travel_and_lodging", "transport", "advertising",
  "telecommunication", "training",
]);

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_ANON_KEY")!,
      { global: { headers: { Authorization: authHeader } } }
    );

    const { data: { user }, error: authError } = await supabase.auth.getUser();
    if (authError || !user) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const qontoLogin = Deno.env.get("QONTO_LOGIN");
    const qontoSecret = Deno.env.get("QONTO_SECRET_KEY");

    if (!qontoLogin || !qontoSecret) {
      return new Response(
        JSON.stringify({ error: "Qonto credentials not configured. Set QONTO_LOGIN and QONTO_SECRET_KEY secrets." }),
        { status: 503, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const body = await req.json().catch(() => ({}));
    const iban: string | undefined = body.iban;
    const perPage = Math.min(Number(body.per_page ?? 100), 100);

    // Fetch organization to get IBAN list if not provided
    const orgRes = await fetch("https://thirdparty.qonto.com/v2/organization", {
      headers: { Authorization: `${qontoLogin}:${qontoSecret}` },
    });

    if (!orgRes.ok) {
      const text = await orgRes.text();
      return new Response(
        JSON.stringify({ error: `Qonto API error: ${orgRes.status} ${text}` }),
        { status: 502, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const orgData = await orgRes.json();
    const bankAccounts: Array<{ iban: string; slug: string }> =
      orgData.organization?.bank_accounts ?? [];

    const targetSlug = iban
      ? bankAccounts.find((a) => a.iban === iban)?.slug
      : bankAccounts[0]?.slug;

    if (!targetSlug) {
      return new Response(
        JSON.stringify({ error: "No matching bank account found" }),
        { status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Fetch transactions
    const txUrl = `https://thirdparty.qonto.com/v2/transactions?iban=${targetSlug}&per_page=${perPage}&current_page=1`;
    const txRes = await fetch(txUrl, {
      headers: { Authorization: `${qontoLogin}:${qontoSecret}` },
    });

    if (!txRes.ok) {
      const text = await txRes.text();
      return new Response(
        JSON.stringify({ error: `Qonto transactions error: ${txRes.status} ${text}` }),
        { status: 502, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const txData = await txRes.json();
    const transactions: Array<Record<string, unknown>> = txData.transactions ?? [];

    if (transactions.length === 0) {
      return new Response(
        JSON.stringify({ success: true, synced: 0, message: "No transactions to sync" }),
        { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const rows = transactions.map((tx) => {
      const category = String(tx.category ?? "");
      const vatRate = category === "software" || category === "it_and_electronics" ? 21 : null;
      const amount = Math.abs(Number(tx.amount ?? 0));
      const vatAmount = vatRate ? parseFloat((amount - amount / (1 + vatRate / 100)).toFixed(2)) : null;

      return {
        user_id: user.id,
        qonto_transaction_id: String(tx.transaction_id ?? tx.id ?? ""),
        label: String(tx.label ?? ""),
        amount,
        currency: String(tx.currency ?? "EUR"),
        side: String(tx.side ?? "debit"),
        settled_at: tx.settled_at ? String(tx.settled_at) : null,
        emitted_at: tx.emitted_at ? String(tx.emitted_at) : null,
        status: String(tx.status ?? "pending"),
        category: category || null,
        vat_amount: vatAmount,
        vat_rate: vatRate,
        is_vat_deductible: VAT_DEDUCTIBLE_CATEGORIES.has(category),
        attachment_ids: Array.isArray(tx.attachment_ids) ? tx.attachment_ids.map(String) : [],
        raw_payload: tx,
        synced_at: new Date().toISOString(),
      };
    });

    const { error: upsertErr, count } = await supabase
      .from("qonto_transactions")
      .upsert(rows, { onConflict: "user_id,qonto_transaction_id", ignoreDuplicates: false })
      .select("id", { count: "exact", head: true });

    if (upsertErr) throw new Error(upsertErr.message);

    return new Response(
      JSON.stringify({ success: true, synced: rows.length, upserted: count }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (err) {
    return new Response(JSON.stringify({ error: String(err) }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
