import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "jsr:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

async function sha256Hex(input: string): Promise<string> {
  const encoder = new TextEncoder();
  const data = encoder.encode(input);
  const hashBuffer = await crypto.subtle.digest("SHA-256", data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map((b) => b.toString(16).padStart(2, "0")).join("");
}

function buildVerifactuXml(invoice: Record<string, unknown>, chainHash: string): string {
  const now = new Date().toISOString().replace("T", " ").slice(0, 19);
  return `<?xml version="1.0" encoding="UTF-8"?>
<T:RegFactuSistemaFacturacion xmlns:T="https://www2.agenciatributaria.gob.es/static_files/common/internet/dep/aplicaciones/es/aeat/tike/cont/ws/SistemaFacturacion.xsd">
  <T:Cabecera>
    <T:ObligadoEmision>
      <T:NombreRazon>${invoice.issuer_name ?? ""}</T:NombreRazon>
      <T:NIF>${invoice.issuer_nif ?? ""}</T:NIF>
    </T:ObligadoEmision>
  </T:Cabecera>
  <T:RegistroFactura>
    <T:RegistroAlta>
      <T:IDVersion>1.0</T:IDVersion>
      <T:IDFactura>
        <T:IDEmisorFactura>${invoice.issuer_nif ?? ""}</T:IDEmisorFactura>
        <T:NumSerieFactura>${invoice.series ?? ""}${invoice.invoice_number ?? ""}</T:NumSerieFactura>
        <T:FechaExpedicionFactura>${String(invoice.issue_date ?? "").replace(/-/g, "-")}</T:FechaExpedicionFactura>
      </T:IDFactura>
      <T:NombreRazonEmisor>${invoice.issuer_name ?? ""}</T:NombreRazonEmisor>
      <T:TipoFactura>F1</T:TipoFactura>
      <T:CuotaTotal>${Number(invoice.vat_amount ?? 0).toFixed(2)}</T:CuotaTotal>
      <T:ImporteTotal>${Number(invoice.total_amount ?? 0).toFixed(2)}</T:ImporteTotal>
      <T:Huella>${chainHash}</T:Huella>
      <T:FechaHoraHusoGenRegistro>${now}</T:FechaHoraHusoGenRegistro>
    </T:RegistroAlta>
  </T:RegistroFactura>
</T:RegFactuSistemaFacturacion>`;
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_ANON_KEY")!,
      { global: { headers: { Authorization: authHeader } } }
    );

    const { data: { user }, error: authError } = await supabase.auth.getUser();
    if (authError || !user) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const invoice = await req.json();

    // Fetch the latest chain block for this user
    const { data: lastBlock } = await supabase
      .from("verifactu_chain")
      .select("block_index, block_hash")
      .eq("user_id", user.id)
      .order("block_index", { ascending: false })
      .limit(1)
      .maybeSingle();

    const prevHash = lastBlock?.block_hash ??
      "0000000000000000000000000000000000000000000000000000000000000000";
    const blockIndex = (lastBlock?.block_index ?? -1) + 1;

    // Build hash input matching AEAT Verifactu spec
    const hashInput = [
      invoice.issuer_nif ?? "",
      `${invoice.series ?? ""}${invoice.invoice_number ?? ""}`,
      invoice.issue_date ?? "",
      Number(invoice.total_amount ?? 0).toFixed(2),
      prevHash,
    ].join("|");

    const blockHash = await sha256Hex(hashInput);

    // Build QR verification URL
    const qrParams = new URLSearchParams({
      nif: String(invoice.issuer_nif ?? ""),
      numserie: `${invoice.series ?? ""}${invoice.invoice_number ?? ""}`,
      fecha: String(invoice.issue_date ?? ""),
      importe: Number(invoice.total_amount ?? 0).toFixed(2),
      huella: blockHash,
    });
    const qr_code = `https://prewww2.aeat.es/wlpl/TIKE-CONT/ValidarQR?${qrParams.toString()}`;

    const xml_payload = buildVerifactuXml(invoice, blockHash);

    // Persist invoice record
    const { data: invoiceRow, error: invoiceErr } = await supabase
      .from("verifactu_invoices")
      .insert({
        user_id: user.id,
        series: invoice.series ?? "",
        invoice_number: invoice.invoice_number ?? "",
        issue_date: invoice.issue_date,
        issuer_nif: invoice.issuer_nif ?? "",
        issuer_name: invoice.issuer_name ?? "",
        recipient_nif: invoice.recipient_nif,
        recipient_name: invoice.recipient_name,
        base_amount: invoice.base_amount ?? 0,
        vat_rate: invoice.vat_rate ?? 21,
        vat_amount: invoice.vat_amount ?? 0,
        total_amount: invoice.total_amount ?? 0,
        qr_code,
        xml_payload,
        chain_hash: blockHash,
        submission_status: "pending",
        raw_pdf_text: invoice.raw_pdf_text,
      })
      .select("id")
      .single();

    if (invoiceErr) throw new Error(invoiceErr.message);

    // Persist chain block
    const { error: chainErr } = await supabase.from("verifactu_chain").insert({
      user_id: user.id,
      block_index: blockIndex,
      prev_hash: prevHash,
      block_hash: blockHash,
      invoice_id: invoiceRow.id,
    });

    if (chainErr) throw new Error(chainErr.message);

    return new Response(
      JSON.stringify({ success: true, invoice_id: invoiceRow.id, block_index: blockIndex, block_hash: blockHash, qr_code, xml_payload }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (err) {
    return new Response(JSON.stringify({ error: String(err) }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
