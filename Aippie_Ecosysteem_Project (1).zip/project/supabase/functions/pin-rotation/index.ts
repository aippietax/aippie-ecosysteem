import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "jsr:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

function generatePin(): string {
  return String(Math.floor(10000 + Math.random() * 90000));
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  const supabase = createClient(
    Deno.env.get("SUPABASE_URL")!,
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
  );

  // Find all pins whose pin_expires_at has passed
  const now = new Date().toISOString();
  const { data: expiredPins, error } = await supabase
    .from("secure_chat_pins")
    .select("id, pin_code, user_id")
    .lt("pin_expires_at", now);

  if (error) {
    return new Response(JSON.stringify({ error: error.message }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }

  if (!expiredPins?.length) {
    return new Response(JSON.stringify({ rotated: 0, message: "No expired PINs" }), {
      status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }

  let rotated = 0;
  for (const row of expiredPins) {
    // Generate a unique new PIN
    let newPin: string;
    let attempts = 0;
    do {
      newPin = generatePin();
      attempts++;
      const { data: conflict } = await supabase
        .from("secure_chat_pins")
        .select("pin_code")
        .eq("pin_code", newPin)
        .maybeSingle();
      if (!conflict) break;
    } while (attempts < 10);

    const newExpiry = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString();

    // Update pin in secure_chat_pins
    const { error: updateErr } = await supabase
      .from("secure_chat_pins")
      .update({
        pin_code: newPin,
        pin_rotated_at: now,
        pin_expires_at: newExpiry,
        failed_attempts: 0,
        is_locked: false,
        locked_until: null,
      })
      .eq("id", row.id);

    if (updateErr) continue;

    // Update all contacts that reference the old PIN as contact_pin
    await supabase
      .from("secure_chat_contacts")
      .update({ contact_pin: newPin })
      .eq("contact_pin", row.pin_code);

    // Update all contacts that reference the old PIN as owner_pin
    await supabase
      .from("secure_chat_contacts")
      .update({ owner_pin: newPin })
      .eq("owner_pin", row.pin_code);

    // Cascade to aippie_mail — keep in-flight mail routable after rotation
    await supabase
      .from("aippie_mail")
      .update({ from_pin: newPin })
      .eq("from_pin", row.pin_code)
      .eq("is_deleted", false);

    await supabase
      .from("aippie_mail")
      .update({ to_pin: newPin })
      .eq("to_pin", row.pin_code)
      .eq("is_deleted", false);

    rotated++;
  }

  return new Response(JSON.stringify({ rotated, total: expiredPins.length }), {
    status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
});
