import "jsr:@supabase/functions-js/edge-runtime.d.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

const HEYGEN_BASE        = "https://api.heygen.com";
// "aippie1" is a talking photo, not a standard avatar — use talking_photo_id
const TALKING_PHOTO_ID   = "fb682f09c62b428c9e336b1d50808996";
const VOICE_NAME         = "Jessica Anne Bogart";

// Look up voice_id by name
async function lookupVoiceId(apiKey: string): Promise<string | undefined> {
  try {
    const res = await fetch(`${HEYGEN_BASE}/v1/voices`, {
      headers: { "X-Api-Key": apiKey },
    });
    if (!res.ok) return undefined;
    const json = await res.json();
    const voices: Array<{ voice_id: string; name: string }> =
      json?.data?.voices ?? json?.voices ?? [];
    const match = voices.find(v =>
      v.name?.toLowerCase().includes("jessica") ||
      v.name?.toLowerCase().includes("bogart") ||
      v.name?.toLowerCase() === VOICE_NAME.toLowerCase()
    );
    return match?.voice_id;
  } catch {
    return undefined;
  }
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  const apiKey = Deno.env.get("HEYGEN_API_KEY");
  if (!apiKey) {
    return new Response(
      JSON.stringify({ error: "HEYGEN_API_KEY not configured" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } },
    );
  }

  let body: Record<string, unknown>;
  try {
    body = await req.json();
  } catch {
    return new Response(
      JSON.stringify({ error: "Invalid JSON" }),
      { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } },
    );
  }

  const { action } = body;

  try {
    let endpoint: string;
    let payload: Record<string, unknown>;

    switch (action) {
      case "create": {
        const voiceId = await lookupVoiceId(apiKey);
        // HeyGen Streaming API v3 — "aippie1" is a talking photo, use talking_photo_id
        endpoint = `${HEYGEN_BASE}/v3/streaming.new`;
        payload = {
          talking_photo_id: TALKING_PHOTO_ID,
          voice:       voiceId
            ? { voice_id: voiceId, rate: 0.95, emotion: "Friendly" }
            : { rate: 0.95 },
          quality:     "high",
          video_encoding: "H264",
        };
        break;
      }

      case "start":
        endpoint = `${HEYGEN_BASE}/v3/streaming.start`;
        payload  = { session_id: body.session_id, sdp: body.sdp };
        break;

      case "ice":
        endpoint = `${HEYGEN_BASE}/v3/streaming.ice`;
        payload  = { session_id: body.session_id, candidate: body.candidate };
        break;

      case "speak":
        endpoint = `${HEYGEN_BASE}/v3/streaming.task`;
        payload  = {
          session_id: body.session_id,
          text:       body.text,
          task_type:  "repeat",
        };
        break;

      case "stop":
        endpoint = `${HEYGEN_BASE}/v3/streaming.stop`;
        payload  = { session_id: body.session_id };
        break;

      case "video": {
        const videoId = String(body.video_id ?? "");
        if (!videoId) {
          return new Response(
            JSON.stringify({ error: "video_id required" }),
            { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } },
          );
        }
        const videoRes = await fetch(
          `${HEYGEN_BASE}/v1/video_status.get?video_id=${encodeURIComponent(videoId)}`,
          { headers: { "Authorization": `Bearer ${apiKey}`, "X-Api-Key": apiKey } },
        );
        const videoData = await videoRes.json();
        return new Response(
          JSON.stringify(videoData),
          { status: videoRes.ok ? 200 : videoRes.status, headers: { ...corsHeaders, "Content-Type": "application/json" } },
        );
      }

      case "list_avatars": {
        const r = await fetch(`${HEYGEN_BASE}/v2/avatars`, {
          headers: { "X-Api-Key": apiKey },
        });
        const data = await r.json();
        return new Response(
          JSON.stringify(data),
          { status: r.ok ? 200 : r.status, headers: { ...corsHeaders, "Content-Type": "application/json" } },
        );
      }

      case "list_videos": {
        const limit = Number(body.limit ?? 20);
        const r = await fetch(`${HEYGEN_BASE}/v1/video.list?limit=${limit}`, {
          headers: { "X-Api-Key": apiKey },
        });
        const data = await r.json();
        return new Response(
          JSON.stringify(data),
          { status: r.ok ? 200 : r.status, headers: { ...corsHeaders, "Content-Type": "application/json" } },
        );
      }

      default:
        return new Response(
          JSON.stringify({ error: `Unknown action: ${String(action)}` }),
          { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } },
        );
    }

    const res = await fetch(endpoint, {
      method:  "POST",
      headers: { "Content-Type": "application/json", "X-Api-Key": apiKey },
      body:    JSON.stringify(payload),
    });

    const data = await res.json();
    return new Response(
      JSON.stringify(data),
      { status: res.ok ? 200 : res.status, headers: { ...corsHeaders, "Content-Type": "application/json" } },
    );
  } catch (err) {
    return new Response(
      JSON.stringify({ error: String(err) }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } },
    );
  }
});
