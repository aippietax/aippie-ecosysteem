import "jsr:@supabase/functions-js/edge-runtime.d.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

interface WeatherData {
  temp: number;
  feels_like: number;
  description: string;
  city: string;
  icon: string;
  humidity: number;
  wind_speed: number;
}

interface NewsItem {
  title: string;
  source: string;
}

interface IntelligenceReport {
  weather: WeatherData | null;
  news: NewsItem[];
  time_context: string;
  spoken_briefing: string;
  short_alert: string | null;
}

function getTimeContext(): string {
  const h = new Date().getUTCHours() + 2; // CET
  if (h >= 5 && h < 11) return "morning";
  if (h >= 11 && h < 14) return "noon";
  if (h >= 14 && h < 18) return "afternoon";
  if (h >= 18 && h < 22) return "evening";
  return "night";
}

function getGreeting(ctx: string): string {
  if (ctx === "morning") return "Good morning";
  if (ctx === "noon" || ctx === "afternoon") return "Good afternoon";
  if (ctx === "evening") return "Good evening";
  return "Good night";
}

async function fetchWeather(lat: number, lon: number): Promise<WeatherData | null> {
  try {
    // open-meteo.com — completely free, no API key needed
    const weatherRes = await fetch(
      `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&current=temperature_2m,apparent_temperature,relative_humidity_2m,wind_speed_10m,weather_code&timezone=auto`
    );
    if (!weatherRes.ok) return null;
    const w = await weatherRes.json();
    const c = w.current;

    // Reverse geocode city name from a free API
    let city = `${lat.toFixed(1)}, ${lon.toFixed(1)}`;
    try {
      const geoRes = await fetch(
        `https://nominatim.openstreetmap.org/reverse?lat=${lat}&lon=${lon}&format=json`,
        { headers: { "User-Agent": "Aippie/2.0" } }
      );
      if (geoRes.ok) {
        const geo = await geoRes.json();
        city = geo.address?.city ?? geo.address?.town ?? geo.address?.village ?? city;
      }
    } catch { /* use coordinates */ }

    // Map WMO weather code to description
    const code: number = c.weather_code ?? 0;
    const desc =
      code === 0 ? "clear sky" :
      code <= 3  ? "partly cloudy" :
      code <= 49 ? "foggy" :
      code <= 67 ? "rainy" :
      code <= 77 ? "snowy" :
      code <= 82 ? "rain showers" :
      code <= 99 ? "thunderstorm" : "cloudy";

    return {
      temp:        Math.round(c.temperature_2m),
      feels_like:  Math.round(c.apparent_temperature),
      description: desc,
      city,
      icon:        "",
      humidity:    c.relative_humidity_2m,
      wind_speed:  Math.round(c.wind_speed_10m),
    };
  } catch {
    return null;
  }
}

async function fetchNews(): Promise<NewsItem[]> {
  const key = Deno.env.get("NEWS_API_KEY");

  // Try NewsAPI first
  if (key) {
    try {
      const res = await fetch(
        `https://newsapi.org/v2/top-headlines?language=en&pageSize=5&apiKey=${key}`
      );
      if (res.ok) {
        const d = await res.json();
        return (d.articles ?? []).slice(0, 5).map((a: { title: string; source?: { name?: string } }) => ({
          title: a.title,
          source: a.source?.name ?? "",
        }));
      }
    } catch { /* fall through */ }
  }

  // Fallback: free RSS via public API
  try {
    const res = await fetch(
      "https://feeds.bbci.co.uk/news/world/rss.xml",
      { headers: { "User-Agent": "Aippie/2.0" } }
    );
    if (res.ok) {
      const text = await res.text();
      const items: NewsItem[] = [];
      const regex = /<item>[\s\S]*?<title><!\[CDATA\[(.*?)\]\]><\/title>[\s\S]*?<\/item>/g;
      let match;
      while ((match = regex.exec(text)) !== null && items.length < 4) {
        items.push({ title: match[1], source: "BBC News" });
      }
      return items;
    }
  } catch { /* ignore */ }

  return [];
}

function buildBriefing(weather: WeatherData | null, news: NewsItem[], ctx: string): string {
  const greeting = getGreeting(ctx);
  const parts: string[] = [];

  parts.push(`${greeting}.`);

  if (weather) {
    const desc = weather.description;
    if (ctx === "morning") {
      parts.push(`Outside it is ${weather.temp} degrees with ${desc}. It feels like ${weather.feels_like} degrees — dress accordingly.`);
    } else {
      parts.push(`The current temperature is ${weather.temp} degrees, ${desc}.`);
    }
  }

  if (news.length > 0) {
    if (ctx === "morning") {
      parts.push(`Here are your top news headlines.`);
      news.slice(0, 3).forEach((n) => parts.push(`${n.source}: ${n.title}.`));
    } else {
      parts.push(`A quick update: ${news[0].title}.`);
    }
  }

  return parts.join(" ");
}

function buildShortAlert(weather: WeatherData | null): string | null {
  if (!weather) return null;
  if (weather.temp < 5) return `It is only ${weather.temp} degrees outside. Dress warmly.`;
  if (weather.temp > 30) return `It is ${weather.temp} degrees outside. Stay hydrated.`;
  if (weather.description.toLowerCase().includes("rain")) return `Rain expected today. Take an umbrella.`;
  return null;
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const url = new URL(req.url);
    const lat = parseFloat(url.searchParams.get("lat") ?? "0");
    const lon = parseFloat(url.searchParams.get("lon") ?? "0");

    const hasLocation = lat !== 0 || lon !== 0;

    const [weather, news] = await Promise.all([
      hasLocation ? fetchWeather(lat, lon) : Promise.resolve(null),
      fetchNews(),
    ]);

    const ctx = getTimeContext();
    const spoken_briefing = buildBriefing(weather, news, ctx);
    const short_alert = buildShortAlert(weather);

    const report: IntelligenceReport = {
      weather,
      news,
      time_context: ctx,
      spoken_briefing,
      short_alert,
    };

    return new Response(JSON.stringify(report), {
      status: 200,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (err) {
    return new Response(JSON.stringify({ error: String(err) }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
