import "jsr:@supabase/functions-js/edge-runtime.d.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

// ElevenLabs voice IDs
const VOICES = {
  // Charlotte — multilingual (EN + NL + ES + FR + DE)
  multilingual: "XB0fDUnXU5powFXDhCwa",
  // Rachel — warm US English female
  english: "21m00Tcm4TlvDq8ikWAM",
};

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  const apiKey = Deno.env.get("ELEVENLABS_API_KEY");
  if (!apiKey) {
    return new Response(JSON.stringify({ error: "ELEVENLABS_API_KEY not configured" }), {
      status: 503,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }

  let text = "";
  let lang = "en";

  try {
    const body = await req.json();
    text = (body.text ?? "").slice(0, 2500); // safety cap
    lang = body.lang ?? "en";
  } catch {
    return new Response(JSON.stringify({ error: "Invalid JSON body" }), {
      status: 400,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }

  if (!text.trim()) {
    return new Response(JSON.stringify({ error: "text is required" }), {
      status: 400,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }

  // Use multilingual voice for Dutch/Spanish, English voice for pure EN
  const isEnglishOnly = /^en/i.test(lang);
  const voiceId = isEnglishOnly ? VOICES.english : VOICES.multilingual;
  const modelId = isEnglishOnly ? "eleven_turbo_v2_5" : "eleven_multilingual_v2";

  const elUrl = `https://api.elevenlabs.io/v1/text-to-speech/${voiceId}/stream`;

  const elRes = await fetch(elUrl, {
    method: "POST",
    headers: {
      "xi-api-key": apiKey,
      "Content-Type": "application/json",
      "Accept": "audio/mpeg",
    },
    body: JSON.stringify({
      text,
      model_id: modelId,
      voice_settings: {
        stability: 0.50,
        similarity_boost: 0.80,
        style: 0.20,
        use_speaker_boost: true,
      },
    }),
  });

  if (!elRes.ok) {
    const err = await elRes.text();
    return new Response(JSON.stringify({ error: `ElevenLabs error: ${elRes.status}`, detail: err }), {
      status: 502,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }

  // Stream the MP3 audio directly back to the client
  return new Response(elRes.body, {
    status: 200,
    headers: {
      ...corsHeaders,
      "Content-Type": "audio/mpeg",
      "Cache-Control": "no-store",
    },
  });
});
