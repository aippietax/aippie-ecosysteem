import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "jsr:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

function buildCertificateHtml(
  trustName: string,
  aptId: string,
  activationDate: string,
  certRef: string,
  fullName?: string,
): string {
  return `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8" />
<title>Digital Trust Certificate — ${aptId}</title>
<style>
  body { margin:0; padding:0; background:#030508; font-family:'Inter',Arial,sans-serif; color:#e2e8f0; }
  .cert { max-width:600px; margin:40px auto; background:linear-gradient(160deg,#020d0a,#041a12); border:1px solid rgba(16,185,129,0.3); border-radius:20px; padding:40px; }
  .logo { font-size:22px; font-weight:900; color:#10b981; letter-spacing:-0.02em; margin-bottom:8px; }
  .logo span { color:#4ade80; }
  .divider { height:1px; background:rgba(16,185,129,0.2); margin:24px 0; }
  h1 { font-size:26px; font-weight:800; color:#4ade80; margin:0 0 6px; }
  .sub { font-size:13px; color:#475569; margin:0 0 28px; }
  .row { display:flex; justify-content:space-between; padding:10px 0; border-bottom:1px solid rgba(255,255,255,0.05); font-size:13px; }
  .label { color:#334155; text-transform:uppercase; letter-spacing:0.06em; font-size:10px; }
  .value { color:#e2e8f0; font-weight:600; }
  .value.mono { font-family:monospace; color:#4ade80; letter-spacing:0.05em; }
  .badge { display:inline-block; background:rgba(16,185,129,0.12); border:1px solid rgba(16,185,129,0.3); border-radius:20px; padding:4px 14px; font-size:11px; font-weight:700; color:#4ade80; letter-spacing:0.08em; }
  .footer { font-size:10px; color:#334155; text-align:center; margin-top:28px; line-height:1.6; }
</style>
</head>
<body>
<div class="cert">
  <div class="logo">AIPPIETAX<span>.ai</span></div>
  <div style="font-size:10px;color:#334155;letter-spacing:0.1em;text-transform:uppercase;margin-bottom:24px;">Advanced Private Trust Platform</div>
  <div class="divider"></div>
  <h1>Digital Trust Certificate</h1>
  <p class="sub">This document certifies the successful activation of a Digital Trust Fund entity on the AIPPIETAX platform.</p>
  <div class="row"><span class="label">Trust Name</span><span class="value">${trustName}</span></div>
  ${fullName ? `<div class="row"><span class="label">Beneficiary</span><span class="value">${fullName}</span></div>` : ''}
  <div class="row"><span class="label">APT Registry ID</span><span class="value mono">${aptId}</span></div>
  <div class="row"><span class="label">Certificate Ref</span><span class="value mono">${certRef}</span></div>
  <div class="row"><span class="label">Activation Date</span><span class="value">${activationDate}</span></div>
  <div class="row"><span class="label">Compliance</span><span class="value">Verifactu B2B · 0% VAT · Directive 2006/112/CE</span></div>
  <div class="row"><span class="label">Status</span><span class="value"><span class="badge">ACTIVE</span></span></div>
  <div class="divider"></div>
  <div class="footer">
    AIPPIETAX S.A. · NIF A22944987 · Mijas, Málaga, España<br/>
    This is an administrative record. No financial balances are held by AIPPIETAX S.A.
  </div>
</div>
</body>
</html>`;
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  const authHeader = req.headers.get("Authorization");
  const supabase = createClient(
    Deno.env.get("SUPABASE_URL") ?? "",
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "",
  );

  // Resolve requesting user (best-effort — function may be called without auth during testing)
  let userId: string | null = null;
  let userEmail: string | null = null;
  if (authHeader) {
    const { data } = await supabase.auth.getUser(authHeader.replace("Bearer ", ""));
    if (data?.user) {
      userId = data.user.id;
      userEmail = data.user.email ?? null;
    }
  }

  let body: { trustName?: string; aptId?: string; activationDate?: string; fullName?: string };
  try {
    body = await req.json();
  } catch {
    return new Response(JSON.stringify({ error: "Invalid JSON" }), {
      status: 400,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }

  const { trustName, aptId, activationDate, fullName } = body;
  if (!trustName || !aptId) {
    return new Response(JSON.stringify({ error: "trustName and aptId are required" }), {
      status: 400,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }

  // Generate unique certificate reference
  const certRef = `CERT-${aptId.replace("AIPP-", "").slice(0, 8).toUpperCase()}`;
  const dateStr = activationDate ?? new Date().toLocaleDateString("nl-NL");

  // Store certificate record in database
  const { data: certRecord, error: insertErr } = await supabase
    .from("trust_certificates")
    .insert({
      user_id: userId,
      apt_id: aptId,
      trust_name: trustName,
      full_name: fullName ?? null,
      activation_date: dateStr,
      certificate_ref: certRef,
      email_status: userEmail ? "dispatched" : "no_email",
    })
    .select("id, certificate_ref")
    .single();

  if (insertErr) {
    console.error("Certificate insert error:", insertErr);
  }

  const certHtml = buildCertificateHtml(trustName, aptId, dateStr, certRef, fullName);

  // Attempt email dispatch via Resend if API key is configured
  const resendKey = Deno.env.get("RESEND_API_KEY");
  let emailSent = false;
  if (resendKey && userEmail) {
    try {
      const emailRes = await fetch("https://api.resend.com/emails", {
        method: "POST",
        headers: { "Authorization": `Bearer ${resendKey}`, "Content-Type": "application/json" },
        body: JSON.stringify({
          from: "AIPPIETAX <noreply@aippietax.ai>",
          to: [userEmail],
          subject: `Digital Trust Certificate — ${aptId}`,
          html: certHtml,
        }),
      });
      if (emailRes.ok) {
        emailSent = true;
        await supabase.from("trust_certificates")
          .update({ email_status: "sent" })
          .eq("id", certRecord?.id);
      }
    } catch (e) {
      console.error("Email dispatch error:", e);
    }
  }

  return new Response(
    JSON.stringify({
      ok: true,
      certificate_ref: certRef,
      apt_id: aptId,
      email_sent: emailSent,
      email_target: userEmail ? `${userEmail.slice(0, 3)}***` : null,
      message: "Certificate record created successfully",
    }),
    { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } },
  );
});
