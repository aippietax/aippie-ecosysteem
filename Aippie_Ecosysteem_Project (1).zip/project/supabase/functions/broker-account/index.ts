import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

async function hmacSha256(secret: string, data: string): Promise<string> {
  const key = await crypto.subtle.importKey(
    "raw", new TextEncoder().encode(secret),
    { name: "HMAC", hash: "SHA-256" }, false, ["sign"]
  );
  const sig = await crypto.subtle.sign("HMAC", key, new TextEncoder().encode(data));
  return Array.from(new Uint8Array(sig)).map(b => b.toString(16).padStart(2, "0")).join("");
}

async function getAlpacaAccount(apiKey: string, apiSecret: string, mode: string) {
  const base = mode === "live" ? "https://api.alpaca.markets" : "https://paper-api.alpaca.markets";
  const res = await fetch(`${base}/v2/account`, {
    headers: { "APCA-API-KEY-ID": apiKey, "APCA-API-SECRET-KEY": apiSecret },
    signal: AbortSignal.timeout(10_000),
  });
  if (!res.ok) throw new Error(`Alpaca account error: ${res.status}`);
  const d = await res.json() as Record<string, unknown>;
  return {
    broker: "alpaca",
    mode,
    equity: parseFloat(d.equity as string || "0"),
    cash: parseFloat(d.cash as string || "0"),
    buying_power: parseFloat(d.buying_power as string || "0"),
    portfolio_value: parseFloat(d.portfolio_value as string || "0"),
    currency: "USD",
  };
}

async function getBinanceAccount(apiKey: string, apiSecret: string) {
  const ts = Date.now();
  const params = `timestamp=${ts}&recvWindow=10000`;
  const sig = await hmacSha256(apiSecret, params);
  const res = await fetch(`https://api.binance.com/api/v3/account?${params}&signature=${sig}`, {
    headers: { "X-MBX-APIKEY": apiKey },
    signal: AbortSignal.timeout(10_000),
  });
  if (!res.ok) throw new Error(`Binance account error: ${res.status}`);
  const d = await res.json() as { balances?: Array<{ asset: string; free: string; locked: string }> };
  const balances = (d.balances ?? [])
    .map(b => ({ asset: b.asset, free: parseFloat(b.free), locked: parseFloat(b.locked) }))
    .filter(b => b.free > 0 || b.locked > 0)
    .slice(0, 20);
  const usdt = balances.find(b => b.asset === "USDT");
  return {
    broker: "binance",
    mode: "live",
    cash: usdt?.free ?? 0,
    buying_power: usdt?.free ?? 0,
    equity: 0,
    portfolio_value: 0,
    currency: "USDT",
    balances,
  };
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") return new Response(null, { status: 200, headers: corsHeaders });

  const respond = (body: unknown, status = 200) =>
    new Response(JSON.stringify(body), {
      status, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });

  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) return respond({ error: "Unauthorized" }, 401);

    const anonClient = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_ANON_KEY")!,
      { global: { headers: { Authorization: authHeader } } }
    );
    const { data: { user }, error: authErr } = await anonClient.auth.getUser();
    if (authErr || !user) return respond({ error: "Invalid token" }, 401);

    const { broker } = await req.json() as { broker?: string };
    if (!broker) return respond({ error: "Required: broker" }, 400);

    const svcClient = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
    );
    const { data: secret, error: sErr } = await svcClient
      .from("broker_secrets")
      .select("api_key, api_secret, mode")
      .eq("user_id", user.id)
      .eq("broker", broker)
      .single();

    if (sErr || !secret) return respond({ error: "No active connection for this broker" }, 404);

    if (broker === "alpaca") {
      return respond(await getAlpacaAccount(secret.api_key, secret.api_secret, secret.mode));
    } else if (broker === "binance") {
      return respond(await getBinanceAccount(secret.api_key, secret.api_secret));
    }
    return respond({ error: "Broker not supported" }, 400);
  } catch (err) {
    return respond({ error: err instanceof Error ? err.message : String(err) }, 500);
  }
});
