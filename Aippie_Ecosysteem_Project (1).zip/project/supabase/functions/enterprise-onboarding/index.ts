import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "jsr:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

/**
 * enterprise-onboarding v2 — uses public.companies (BYTEA pgcrypto) + public.company_members.
 *
 * POST body actions:
 *   create_company       — create company + link user as admin
 *   update_credentials   — encrypt IBAN / BIC / API config / PFX cert via pgp_sym_encrypt
 *   update_step          — advance onboarding wizard step
 *   get_company          — fetch active company for authenticated user
 *
 * Sensitive BYTEA columns are encrypted server-side with pgp_sym_encrypt
 * using the COMPANY_CREDENTIALS_KEY secret. Plaintext never leaves this function.
 */

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // User-scoped client for auth verification
    const supabaseUser = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_ANON_KEY") ?? "",
      { global: { headers: { Authorization: authHeader } } },
    );

    const { data: { user } } = await supabaseUser.auth.getUser();
    if (!user) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Service-role client — bypasses RLS for privileged inserts
    const supabaseAdmin = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "",
    );

    const credKey = Deno.env.get("COMPANY_CREDENTIALS_KEY") ?? "aippie-default-dev-key-change-in-prod";

    const body = await req.json() as {
      action: string;
      company_id?: string;
      company_name?: string;
      nif?: string;
      bank_name?: string;
      iban?: string;
      bic_swift?: string;
      bank_api_config?: Record<string, unknown>;
      pfx_certificate_b64?: string;
      pfx_password?: string;
      operational_goals?: unknown[];
      onboarding_step?: number;
      onboarding_complete?: boolean;
    };

    // ── create_company ────────────────────────────────────────────────────────
    if (body.action === "create_company") {
      if (!body.company_name?.trim()) {
        return new Response(JSON.stringify({ error: "company_name required" }), {
          status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      const { data: company, error: compErr } = await supabaseAdmin
        .from("companies")
        .insert({
          name: body.company_name.trim(),
          nif: body.nif?.trim() || null,
          bank_name: body.bank_name?.trim() || null,
          operational_goals: body.operational_goals ?? [],
          onboarding_step: 1,
        })
        .select("id, name, nif, bank_name, onboarding_step, onboarding_complete, created_at")
        .single();

      if (compErr || !company) {
        return new Response(JSON.stringify({ error: compErr?.message ?? "Failed to create company" }), {
          status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      // Link user as admin member in public.company_members
      const { error: memberErr } = await supabaseAdmin.from("company_members").insert({
        company_id: company.id,
        user_id:    user.id,
        role:       "admin",
      });

      if (memberErr) {
        return new Response(JSON.stringify({ error: memberErr.message }), {
          status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      return new Response(JSON.stringify({ success: true, company }), {
        status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // ── update_credentials — pgcrypto BYTEA encryption ────────────────────────
    if (body.action === "update_credentials") {
      if (!body.company_id) {
        return new Response(JSON.stringify({ error: "company_id required" }), {
          status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      // Verify user is admin of this company
      const { data: membership } = await supabaseAdmin
        .from("company_members")
        .select("role")
        .eq("company_id", body.company_id)
        .eq("user_id", user.id)
        .maybeSingle();

      if (!membership || membership.role !== "admin") {
        return new Response(JSON.stringify({ error: "Forbidden — admin role required" }), {
          status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      // Encrypt sensitive fields via pgp_sym_encrypt using direct SQL
      // We execute separate UPDATE calls per encrypted field to avoid parameter binding
      // complexity with pgcrypto's binary output in JS
      const encryptUpdates: Array<[string, string]> = [];

      if (body.iban)                encryptUpdates.push(["iban_encrypted",            body.iban.trim()]);
      if (body.bic_swift)           encryptUpdates.push(["bic_swift_encrypted",        body.bic_swift.trim()]);
      if (body.bank_api_config)     encryptUpdates.push(["bank_api_config_encrypted",  JSON.stringify(body.bank_api_config)]);
      if (body.pfx_certificate_b64) encryptUpdates.push(["pfx_certificate_encrypted",  body.pfx_certificate_b64]);
      if (body.pfx_password)        encryptUpdates.push(["pfx_password_encrypted",     body.pfx_password]);

      for (const [col, plaintext] of encryptUpdates) {
        // Use execute_sql-compatible approach via supabase admin
        await supabaseAdmin.rpc("update_company_encrypted_field", {
          p_company_id: body.company_id,
          p_column:     col,
          p_plaintext:  plaintext,
          p_passphrase: credKey,
        }).maybeSingle().catch(() => null);
      }

      // Update non-encrypted fields
      const plainUpdate: Record<string, unknown> = { updated_at: new Date().toISOString() };
      if (body.bank_name)   plainUpdate.bank_name     = body.bank_name.trim();
      if (body.iban)        plainUpdate.onboarding_step = 2;
      if (body.pfx_certificate_b64) plainUpdate.onboarding_step = 3;
      if (body.onboarding_step !== undefined) {
        plainUpdate.onboarding_step = body.onboarding_step;
      }

      await supabaseAdmin.from("companies").update(plainUpdate).eq("id", body.company_id);

      return new Response(JSON.stringify({ success: true }), {
        status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // ── update_step ───────────────────────────────────────────────────────────
    if (body.action === "update_step") {
      if (!body.company_id) {
        return new Response(JSON.stringify({ error: "company_id required" }), {
          status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      await supabaseAdmin.from("companies").update({
        onboarding_step:     body.onboarding_step     ?? 0,
        onboarding_complete: body.onboarding_complete ?? false,
        updated_at: new Date().toISOString(),
      }).eq("id", body.company_id);

      return new Response(JSON.stringify({ success: true }), {
        status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // ── get_company ───────────────────────────────────────────────────────────
    if (body.action === "get_company") {
      const { data: membership } = await supabaseAdmin
        .from("company_members")
        .select("company_id, role")
        .eq("user_id", user.id)
        .order("created_at", { ascending: true })
        .limit(1)
        .maybeSingle();

      if (!membership) {
        return new Response(JSON.stringify({ success: true, company: null }), {
          status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      const { data: company } = await supabaseAdmin
        .from("companies")
        .select("id, name, nif, bank_name, operational_goals, onboarding_step, onboarding_complete, created_at")
        .eq("id", membership.company_id)
        .maybeSingle();

      return new Response(JSON.stringify({ success: true, company, role: membership.role }), {
        status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    return new Response(JSON.stringify({ error: "Unknown action" }), {
      status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });

  } catch (err) {
    return new Response(JSON.stringify({ error: String(err) }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
