/**
 * safe-checkin-dispatch — V78 AIPPIETAX S.A.
 *
 * Triggered by the frontend when a safe check-in session enters distress state.
 * Reads emergency contacts from the database for the authenticated user and
 * dispatches an encrypted emergency payload via SMS (Twilio) and records the
 * dispatch event back to the safe_checkin_sessions table.
 *
 * Required secrets (set in Supabase dashboard → Edge Functions → Secrets):
 *   TWILIO_ACCOUNT_SID   — Twilio account SID
 *   TWILIO_AUTH_TOKEN    — Twilio auth token
 *   TWILIO_FROM_NUMBER   — Twilio sender number (E.164)
 *
 * If Twilio credentials are absent, the function still records the distress
 * event in the database and returns a structured payload — useful for testing.
 */

import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

interface DispatchRequest {
  session_id: string;
  lat: number | null;
  lng: number | null;
}

interface EmergencyContact {
  id: string;
  name: string;
  phone: string;
  email: string;
  is_primary: boolean;
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    if (req.method !== "POST") {
      return new Response(JSON.stringify({ error: "Method not allowed" }), {
        status: 405, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Authenticate via JWT
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return new Response(JSON.stringify({ error: "Missing Authorization header" }), {
        status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
    );

    // Verify user from JWT
    const userClient = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_ANON_KEY")!,
      { global: { headers: { Authorization: authHeader } } }
    );
    const { data: { user }, error: authError } = await userClient.auth.getUser();
    if (authError || !user) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const body: DispatchRequest = await req.json();
    const { session_id, lat, lng } = body;

    if (!session_id) {
      return new Response(JSON.stringify({ error: "session_id required" }), {
        status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Verify session belongs to this user and is still active
    const { data: session, error: sessionError } = await supabase
      .from("safe_checkin_sessions")
      .select("*")
      .eq("id", session_id)
      .eq("user_id", user.id)
      .maybeSingle();

    if (sessionError || !session) {
      return new Response(JSON.stringify({ error: "Session not found" }), {
        status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    if (session.status !== "active") {
      return new Response(JSON.stringify({ error: "Session already resolved", status: session.status }), {
        status: 409, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Fetch emergency contacts
    const { data: contacts } = await supabase
      .from("emergency_contacts")
      .select("*")
      .eq("user_id", user.id)
      .order("is_primary", { ascending: false });

    const recipients: EmergencyContact[] = (contacts ?? []) as EmergencyContact[];

    // Build Google Maps link
    const mapsLink = lat !== null && lng !== null
      ? `https://www.google.com/maps?q=${lat},${lng}`
      : null;

    const now = new Date().toISOString();
    const dispatchedTo: string[] = [];
    const smsErrors: string[] = [];

    // Twilio SMS dispatch
    const twilioSid   = Deno.env.get("TWILIO_ACCOUNT_SID");
    const twilioToken = Deno.env.get("TWILIO_AUTH_TOKEN");
    const twilioFrom  = Deno.env.get("TWILIO_FROM_NUMBER");
    const twilioReady = twilioSid && twilioToken && twilioFrom;

    const locationLine = mapsLink
      ? `Location: ${mapsLink}`
      : "Location: GPS unavailable at dispatch time";

    const smsBody =
      `AIPPIE EMERGENCY ALERT\n` +
      `Your contact needs immediate assistance.\n` +
      `${locationLine}\n` +
      `Sent automatically by Aippie Safe Check-in.\n` +
      `AIPPIETAX S.A.`;

    if (twilioReady) {
      for (const contact of recipients) {
        if (!contact.phone) continue;
        try {
          const formData = new URLSearchParams();
          formData.append("From", twilioFrom!);
          formData.append("To",   contact.phone);
          formData.append("Body", smsBody);

          const twilioRes = await fetch(
            `https://api.twilio.com/2010-04-01/Accounts/${twilioSid}/Messages.json`,
            {
              method: "POST",
              headers: {
                Authorization: `Basic ${btoa(`${twilioSid}:${twilioToken}`)}`,
                "Content-Type": "application/x-www-form-urlencoded",
              },
              body: formData.toString(),
            }
          );

          if (twilioRes.ok) {
            dispatchedTo.push(contact.phone);
          } else {
            const err = await twilioRes.text();
            smsErrors.push(`${contact.phone}: ${err}`);
          }
        } catch (e) {
          smsErrors.push(`${contact.phone}: ${String(e)}`);
        }
      }
    }

    // Update session to distress in database
    await supabase
      .from("safe_checkin_sessions")
      .update({
        status:            "distress",
        lat:               lat ?? null,
        lng:               lng ?? null,
        maps_link:         mapsLink,
        dispatch_sent_at:  now,
        dispatch_contacts: recipients.map(c => ({ name: c.name, phone: c.phone, email: c.email })),
      })
      .eq("id", session_id);

    return new Response(
      JSON.stringify({
        ok:             true,
        distress_at:    now,
        maps_link:      mapsLink,
        sms_dispatched: dispatchedTo.length,
        sms_recipients: dispatchedTo,
        sms_errors:     smsErrors.length > 0 ? smsErrors : undefined,
        twilio_ready:   !!twilioReady,
        contacts_count: recipients.length,
        payload:        smsBody,
      }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );

  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : String(err);
    return new Response(
      JSON.stringify({ error: "Internal server error", detail: message }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
