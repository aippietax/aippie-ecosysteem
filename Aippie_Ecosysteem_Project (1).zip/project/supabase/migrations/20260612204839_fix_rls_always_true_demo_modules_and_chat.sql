-- ─────────────────────────────────────────────────────────────────────────────
-- Fix: RLS policies with always-true USING / WITH CHECK clauses
-- Tables: aippietax_chat_messages, cybersuit_configs, live_stage_events,
--         live_stage_tickets, morning_briefing_alerts, morning_briefing_cache,
--         robotics_telemetry, signal_radar_items, tournament_events,
--         tournament_traders, voip_script_history, webrtc_rooms
-- ─────────────────────────────────────────────────────────────────────────────

-- Helper alias used throughout
-- device_key from request header: coalesce(current_setting('request.headers',true)::json->>'x-device-key','')

-- ── aippietax_chat_messages ───────────────────────────────────────────────────
DROP POLICY IF EXISTS "insert_chat_any"  ON aippietax_chat_messages;
DROP POLICY IF EXISTS "update_chat_any"  ON aippietax_chat_messages;
DROP POLICY IF EXISTS "delete_chat_any"  ON aippietax_chat_messages;

CREATE POLICY "insert_chat_own" ON aippietax_chat_messages
  FOR INSERT TO anon, authenticated
  WITH CHECK (device_key = coalesce(current_setting('request.headers', true)::json->>'x-device-key', ''));

CREATE POLICY "update_chat_own" ON aippietax_chat_messages
  FOR UPDATE TO anon, authenticated
  USING  (device_key = coalesce(current_setting('request.headers', true)::json->>'x-device-key', ''))
  WITH CHECK (device_key = coalesce(current_setting('request.headers', true)::json->>'x-device-key', ''));

CREATE POLICY "delete_chat_own" ON aippietax_chat_messages
  FOR DELETE TO anon, authenticated
  USING (device_key = coalesce(current_setting('request.headers', true)::json->>'x-device-key', ''));

-- ── cybersuit_configs ─────────────────────────────────────────────────────────
DROP POLICY IF EXISTS "insert_suit_any"  ON cybersuit_configs;
DROP POLICY IF EXISTS "update_suit_any"  ON cybersuit_configs;
DROP POLICY IF EXISTS "delete_suit_any"  ON cybersuit_configs;

CREATE POLICY "insert_suit_own" ON cybersuit_configs
  FOR INSERT TO anon, authenticated
  WITH CHECK (device_key = coalesce(current_setting('request.headers', true)::json->>'x-device-key', ''));

CREATE POLICY "update_suit_own" ON cybersuit_configs
  FOR UPDATE TO anon, authenticated
  USING  (device_key = coalesce(current_setting('request.headers', true)::json->>'x-device-key', ''))
  WITH CHECK (device_key = coalesce(current_setting('request.headers', true)::json->>'x-device-key', ''));

CREATE POLICY "delete_suit_own" ON cybersuit_configs
  FOR DELETE TO anon, authenticated
  USING (device_key = coalesce(current_setting('request.headers', true)::json->>'x-device-key', ''));

-- ── live_stage_events (admin/system table — drop all write policies) ──────────
DROP POLICY IF EXISTS "insert_events_auth2"  ON live_stage_events;
DROP POLICY IF EXISTS "update_events_auth2"  ON live_stage_events;
DROP POLICY IF EXISTS "delete_events_auth2"  ON live_stage_events;
-- Only service_role can write; authenticated users can only SELECT (existing select policy retained).

-- ── live_stage_tickets ────────────────────────────────────────────────────────
DROP POLICY IF EXISTS "insert_tickets_any"  ON live_stage_tickets;
DROP POLICY IF EXISTS "update_tickets_any"  ON live_stage_tickets;
DROP POLICY IF EXISTS "delete_tickets_any"  ON live_stage_tickets;
-- INSERT: service_role only (no user-facing insert needed; tickets are seeded)
-- UPDATE: allow claiming an unclaimed ticket or updating your own
CREATE POLICY "update_tickets_claim" ON live_stage_tickets
  FOR UPDATE TO anon, authenticated
  USING  (device_key IS NULL OR device_key = coalesce(current_setting('request.headers', true)::json->>'x-device-key', ''))
  WITH CHECK (device_key = coalesce(current_setting('request.headers', true)::json->>'x-device-key', ''));
-- DELETE: service_role only

-- ── morning_briefing_cache (system/seeded table — drop all write policies) ───
DROP POLICY IF EXISTS "insert_briefing_auth"  ON morning_briefing_cache;
DROP POLICY IF EXISTS "update_briefing_auth"  ON morning_briefing_cache;
DROP POLICY IF EXISTS "delete_briefing_auth"  ON morning_briefing_cache;

-- ── morning_briefing_alerts (system/seeded table — drop all write policies) ──
DROP POLICY IF EXISTS "insert_alerts_auth"  ON morning_briefing_alerts;
DROP POLICY IF EXISTS "update_alerts_auth"  ON morning_briefing_alerts;
DROP POLICY IF EXISTS "delete_alerts_auth"  ON morning_briefing_alerts;

-- ── robotics_telemetry (system telemetry — drop all write policies) ───────────
DROP POLICY IF EXISTS "insert_telemetry_any"  ON robotics_telemetry;
DROP POLICY IF EXISTS "update_telemetry_any"  ON robotics_telemetry;
DROP POLICY IF EXISTS "delete_telemetry_any"  ON robotics_telemetry;

-- ── signal_radar_items (system/seeded table — drop all write policies) ────────
DROP POLICY IF EXISTS "insert_signals_auth"  ON signal_radar_items;
DROP POLICY IF EXISTS "update_signals_auth"  ON signal_radar_items;
DROP POLICY IF EXISTS "delete_signals_auth"  ON signal_radar_items;

-- ── tournament_traders ────────────────────────────────────────────────────────
DROP POLICY IF EXISTS "insert_traders_any"  ON tournament_traders;
DROP POLICY IF EXISTS "update_traders_any"  ON tournament_traders;
DROP POLICY IF EXISTS "delete_traders_own"  ON tournament_traders;

-- INSERT: only if device_key matches (user registers their own trader row)
CREATE POLICY "insert_traders_own" ON tournament_traders
  FOR INSERT TO anon, authenticated
  WITH CHECK (device_key = coalesce(current_setting('request.headers', true)::json->>'x-device-key', ''));

-- UPDATE: only the device that owns the row may update it
CREATE POLICY "update_traders_own" ON tournament_traders
  FOR UPDATE TO anon, authenticated
  USING  (device_key = coalesce(current_setting('request.headers', true)::json->>'x-device-key', ''))
  WITH CHECK (device_key = coalesce(current_setting('request.headers', true)::json->>'x-device-key', ''));

-- DELETE: only the device that owns the row may delete it
CREATE POLICY "delete_traders_own2" ON tournament_traders
  FOR DELETE TO anon, authenticated
  USING (device_key = coalesce(current_setting('request.headers', true)::json->>'x-device-key', ''));

-- ── tournament_events ─────────────────────────────────────────────────────────
DROP POLICY IF EXISTS "insert_events_any"  ON tournament_events;
DROP POLICY IF EXISTS "update_events_any"  ON tournament_events;
DROP POLICY IF EXISTS "delete_events_any"  ON tournament_events;

-- INSERT: only if the referenced trader belongs to the requesting device
CREATE POLICY "insert_events_own" ON tournament_events
  FOR INSERT TO anon, authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM tournament_traders tt
      WHERE tt.id = trader_id
        AND tt.device_key = coalesce(current_setting('request.headers', true)::json->>'x-device-key', '')
    )
  );

-- UPDATE: same ownership check via trader
CREATE POLICY "update_events_own" ON tournament_events
  FOR UPDATE TO anon, authenticated
  USING (
    EXISTS (
      SELECT 1 FROM tournament_traders tt
      WHERE tt.id = trader_id
        AND tt.device_key = coalesce(current_setting('request.headers', true)::json->>'x-device-key', '')
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM tournament_traders tt
      WHERE tt.id = trader_id
        AND tt.device_key = coalesce(current_setting('request.headers', true)::json->>'x-device-key', '')
    )
  );

-- DELETE: same ownership check
CREATE POLICY "delete_events_own" ON tournament_events
  FOR DELETE TO anon, authenticated
  USING (
    EXISTS (
      SELECT 1 FROM tournament_traders tt
      WHERE tt.id = trader_id
        AND tt.device_key = coalesce(current_setting('request.headers', true)::json->>'x-device-key', '')
    )
  );

-- ── voip_script_history ───────────────────────────────────────────────────────
DROP POLICY IF EXISTS "insert_voip_any"   ON voip_script_history;
DROP POLICY IF EXISTS "update_voip_own"   ON voip_script_history;
DROP POLICY IF EXISTS "delete_voip_own"   ON voip_script_history;

CREATE POLICY "insert_voip_own" ON voip_script_history
  FOR INSERT TO anon, authenticated
  WITH CHECK (device_key = coalesce(current_setting('request.headers', true)::json->>'x-device-key', ''));

CREATE POLICY "update_voip_own2" ON voip_script_history
  FOR UPDATE TO anon, authenticated
  USING  (device_key = coalesce(current_setting('request.headers', true)::json->>'x-device-key', ''))
  WITH CHECK (device_key = coalesce(current_setting('request.headers', true)::json->>'x-device-key', ''));

CREATE POLICY "delete_voip_own2" ON voip_script_history
  FOR DELETE TO anon, authenticated
  USING (device_key = coalesce(current_setting('request.headers', true)::json->>'x-device-key', ''));

-- ── webrtc_rooms ──────────────────────────────────────────────────────────────
DROP POLICY IF EXISTS "update_rooms" ON webrtc_rooms;

CREATE POLICY "update_rooms" ON webrtc_rooms
  FOR UPDATE TO authenticated
  USING (
    initiator_pin = (SELECT pin_code FROM secure_chat_pins WHERE user_id = auth.uid())
  )
  WITH CHECK (
    initiator_pin = (SELECT pin_code FROM secure_chat_pins WHERE user_id = auth.uid())
  );
