/*
  # Legal Family Reunification & Missing Persons System — AippieTax S.A.

  ## Overview
  Consent-based legal dossier management system for official family reunification
  and missing persons cases. All data is user-submitted, opt-in, and routed through
  verified legal authorities. No covert tracking. No third-party data collection.

  ## New Tables

  ### 1. `aippie_legal_reunion_cases`
  User-owned legal case dossiers for family reunification or official missing persons.
  - `case_id` (uuid, PK)
  - `user_id` (uuid, FK → auth.users)
  - `subject_full_name` (varchar) — name of the person being searched for
  - `case_type` (varchar) — FAMILY_REUNIFICATION | OFFICIAL_MISSING_PERSON
  - `years_of_separation` (int)
  - `case_chronology_details` (text) — user-written narrative
  - `is_dossier_ready_for_legal_authorities` (bool)
  - `created_at` (timestamptz)

  ### 2. `aippie_verified_registry`
  Opt-in self-submitted registry. A user registers their own name to be findable
  by others who are searching for them. Consent is explicit and user-controlled.
  - `registry_id` (uuid, PK)
  - `user_id` (uuid, FK → auth.users)
  - `registered_search_name` (varchar)
  - `is_identity_verified` (bool)
  - `consent_to_match_shared` (bool) — user can revoke at any time
  - `created_at` (timestamptz)

  ### 3. `aippie_authority_dispatches`
  Tracks dossier submissions to official legal counsel or authorities.
  - `dispatch_id` (uuid, PK)
  - `case_id` (uuid, FK → aippie_legal_reunion_cases)
  - `authorized_agency_name` (varchar)
  - `dispatch_status` (varchar) — DOSSIER_SENT | UNDER_REVIEW | INVESTIGATION_ACTIVE
  - `created_at` (timestamptz)

  ### 4. `aippie_reunion_billing`
  Enterprise billing ledger for case activation and success fees.
  - `billing_id` (uuid, PK)
  - `case_id` (uuid, FK → aippie_legal_reunion_cases)
  - `initial_activation_fee_eur` (numeric, default 1850.00)
  - `success_delivery_fee_eur` (numeric, default 5000.00)
  - `payment_status` (varchar)
  - `created_at` (timestamptz)

  ## Security
  - RLS enabled on ALL four tables
  - Users can only read/write their own cases, registry entries, and billing records
  - Authority dispatches: only the case owner can read dispatches for their cases
  - Verified registry: authenticated users can search names with consent=true (read-only)
  - No table allows access to another user's personal case data
*/

-- ── 1. Legal reunion cases ────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS public.aippie_legal_reunion_cases (
  case_id                              uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id                              uuid        NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  subject_full_name                    varchar(100) NOT NULL,
  case_type                            varchar(20)  NOT NULL
    CHECK (case_type IN ('FAMILY_REUNIFICATION', 'OFFICIAL_MISSING_PERSON')),
  years_of_separation                  int          NOT NULL DEFAULT 0 CHECK (years_of_separation >= 0),
  case_chronology_details              text         NOT NULL DEFAULT '',
  is_dossier_ready_for_legal_authorities boolean   NOT NULL DEFAULT true,
  created_at                           timestamptz  NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_reunion_cases_user_id
  ON public.aippie_legal_reunion_cases (user_id);

CREATE INDEX IF NOT EXISTS idx_reunion_cases_type
  ON public.aippie_legal_reunion_cases (case_type, is_dossier_ready_for_legal_authorities);

ALTER TABLE public.aippie_legal_reunion_cases ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own reunion cases"
  ON public.aippie_legal_reunion_cases FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create own reunion cases"
  ON public.aippie_legal_reunion_cases FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own reunion cases"
  ON public.aippie_legal_reunion_cases FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- ── 2. Opt-in verified self-submitted registry ────────────────────────────────
CREATE TABLE IF NOT EXISTS public.aippie_verified_registry (
  registry_id              uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id                  uuid        NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  registered_search_name   varchar(100) NOT NULL,
  is_identity_verified     boolean      NOT NULL DEFAULT true,
  consent_to_match_shared  boolean      NOT NULL DEFAULT true,
  created_at               timestamptz  NOT NULL DEFAULT now(),
  CONSTRAINT aippie_verified_registry_user_unique UNIQUE (user_id)
);

CREATE INDEX IF NOT EXISTS idx_registry_name
  ON public.aippie_verified_registry (registered_search_name)
  WHERE consent_to_match_shared = true;

ALTER TABLE public.aippie_verified_registry ENABLE ROW LEVEL SECURITY;

-- Any authenticated user can search the opt-in registry (consent=true entries only)
CREATE POLICY "Authenticated users can search consented registry entries"
  ON public.aippie_verified_registry FOR SELECT
  TO authenticated
  USING (consent_to_match_shared = true AND is_identity_verified = true);

-- Users manage their own registry entry
CREATE POLICY "Users can register own entry"
  ON public.aippie_verified_registry FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own registry entry"
  ON public.aippie_verified_registry FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own registry entry"
  ON public.aippie_verified_registry FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- ── 3. Authority dispatch log ─────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS public.aippie_authority_dispatches (
  dispatch_id              uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
  case_id                  uuid        NOT NULL REFERENCES public.aippie_legal_reunion_cases(case_id) ON DELETE CASCADE,
  authorized_agency_name   varchar(100) NOT NULL DEFAULT 'OFFICIAL_LEGAL_COUNSEL',
  dispatch_status          varchar(25)  NOT NULL DEFAULT 'DOSSIER_SENT'
    CHECK (dispatch_status IN ('DOSSIER_SENT', 'UNDER_REVIEW', 'INVESTIGATION_ACTIVE')),
  notes                    text         NOT NULL DEFAULT '',
  created_at               timestamptz  NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_dispatches_case_id
  ON public.aippie_authority_dispatches (case_id);

ALTER TABLE public.aippie_authority_dispatches ENABLE ROW LEVEL SECURITY;

-- Only the case owner can read dispatch records for their case
CREATE POLICY "Case owners can view own dispatches"
  ON public.aippie_authority_dispatches FOR SELECT
  TO authenticated
  USING (
    case_id IN (
      SELECT case_id FROM public.aippie_legal_reunion_cases
      WHERE user_id = auth.uid()
    )
  );

CREATE POLICY "Case owners can create dispatches"
  ON public.aippie_authority_dispatches FOR INSERT
  TO authenticated
  WITH CHECK (
    case_id IN (
      SELECT case_id FROM public.aippie_legal_reunion_cases
      WHERE user_id = auth.uid()
    )
  );

-- ── 4. Reunion billing ledger ─────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS public.aippie_reunion_billing (
  billing_id                uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
  case_id                   uuid        NOT NULL REFERENCES public.aippie_legal_reunion_cases(case_id) ON DELETE CASCADE,
  initial_activation_fee_eur numeric(8,2) NOT NULL DEFAULT 1850.00,
  success_delivery_fee_eur  numeric(8,2) NOT NULL DEFAULT 5000.00,
  payment_status            varchar(20)  NOT NULL DEFAULT 'INITIAL_PAID'
    CHECK (payment_status IN ('INITIAL_PAID', 'SUCCESS_PENDING', 'FULLY_CLOSED')),
  created_at                timestamptz  NOT NULL DEFAULT now(),
  CONSTRAINT aippie_reunion_billing_case_unique UNIQUE (case_id)
);

CREATE INDEX IF NOT EXISTS idx_reunion_billing_case_id
  ON public.aippie_reunion_billing (case_id);

ALTER TABLE public.aippie_reunion_billing ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Case owners can view own billing"
  ON public.aippie_reunion_billing FOR SELECT
  TO authenticated
  USING (
    case_id IN (
      SELECT case_id FROM public.aippie_legal_reunion_cases
      WHERE user_id = auth.uid()
    )
  );

CREATE POLICY "Case owners can insert billing record"
  ON public.aippie_reunion_billing FOR INSERT
  TO authenticated
  WITH CHECK (
    case_id IN (
      SELECT case_id FROM public.aippie_legal_reunion_cases
      WHERE user_id = auth.uid()
    )
  );
