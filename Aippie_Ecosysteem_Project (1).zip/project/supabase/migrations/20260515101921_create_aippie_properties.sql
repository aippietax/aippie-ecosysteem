/*
  # AippieRealEstate — Property Listings Table

  ## Summary
  Creates the `aippie_properties` table to store real estate listings across
  the Costa del Sol (Marbella, Fuengirola, Mijas) for the AippieRealEstate module.

  ## New Tables
  - `aippie_properties`
    - `id`            — UUID primary key
    - `title`         — Short listing headline
    - `description`   — Full property description
    - `location`      — Municipality (Marbella / Fuengirola / Mijas / etc.)
    - `address`       — Street-level address or urbanisation name
    - `price_eur`     — Asking price in euros (integer)
    - `bedrooms`      — Number of bedrooms
    - `bathrooms`     — Number of bathrooms
    - `size_m2`       — Built area in square metres
    - `property_type` — villa | apartment | penthouse | townhouse | finca
    - `photo_urls`    — Array of image URLs (Pexels stock photos for mock listings)
    - `features`      — Array of feature tags (pool, sea view, garage, etc.)
    - `is_featured`   — Boolean flag for curated/featured listings
    - `status`        — available | reserved | sold
    - `created_at`    — Row creation timestamp

  ## Security
  - RLS enabled; public read access for available/featured listings
  - Only authenticated users (admins via service role in practice) may insert/update/delete

  ## Notes
  - Photo URLs point to valid Pexels images — no downloads needed
  - Mock seed data inserted below for immediate demo functionality
*/

CREATE TABLE IF NOT EXISTS aippie_properties (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title         text NOT NULL DEFAULT '',
  description   text NOT NULL DEFAULT '',
  location      text NOT NULL DEFAULT '',
  address       text NOT NULL DEFAULT '',
  price_eur     integer NOT NULL DEFAULT 0,
  bedrooms      smallint NOT NULL DEFAULT 0,
  bathrooms     smallint NOT NULL DEFAULT 0,
  size_m2       integer NOT NULL DEFAULT 0,
  property_type text NOT NULL DEFAULT 'apartment',
  photo_urls    text[] NOT NULL DEFAULT '{}',
  features      text[] NOT NULL DEFAULT '{}',
  is_featured   boolean NOT NULL DEFAULT false,
  status        text NOT NULL DEFAULT 'available',
  created_at    timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE aippie_properties ENABLE ROW LEVEL SECURITY;

-- Public can read available listings
CREATE POLICY "Anyone can view available properties"
  ON aippie_properties FOR SELECT
  USING (status = 'available');

-- Only authenticated users can insert listings
CREATE POLICY "Authenticated users can insert properties"
  ON aippie_properties FOR INSERT
  TO authenticated
  WITH CHECK (true);

-- Only authenticated users can update listings
CREATE POLICY "Authenticated users can update properties"
  ON aippie_properties FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- Only authenticated users can delete listings
CREATE POLICY "Authenticated users can delete properties"
  ON aippie_properties FOR DELETE
  TO authenticated
  USING (true);

-- Index for fast location + price queries
CREATE INDEX IF NOT EXISTS idx_aippie_properties_location ON aippie_properties (location);
CREATE INDEX IF NOT EXISTS idx_aippie_properties_price    ON aippie_properties (price_eur);
CREATE INDEX IF NOT EXISTS idx_aippie_properties_type     ON aippie_properties (property_type);

-- ── Seed mock listings ────────────────────────────────────────────────────────

INSERT INTO aippie_properties
  (title, description, location, address, price_eur, bedrooms, bathrooms, size_m2, property_type, photo_urls, features, is_featured, status)
VALUES

-- Marbella listings
(
  'Luxury Villa with Sea Views',
  'Stunning detached villa in the prestigious Golden Mile with panoramic Mediterranean views. Fully renovated with bespoke interiors, a chef''s kitchen, and a heated infinity pool.',
  'Marbella',
  'Urbanización Lomas del Mar, Golden Mile',
  2850000,
  5, 4, 420,
  'villa',
  ARRAY['https://images.pexels.com/photos/1396122/pexels-photo-1396122.jpeg?auto=compress&cs=tinysrgb&w=800',
        'https://images.pexels.com/photos/1396132/pexels-photo-1396132.jpeg?auto=compress&cs=tinysrgb&w=800'],
  ARRAY['pool','sea view','garage','garden','air conditioning','underfloor heating'],
  true, 'available'
),
(
  'Modern Penthouse, Puerto Banús',
  'Two-level penthouse in the heart of Puerto Banús. Private rooftop terrace with Jacuzzi, direct marina access, and concierge service included.',
  'Marbella',
  'Calle Ramón Areces, Puerto Banús',
  1450000,
  3, 3, 210,
  'penthouse',
  ARRAY['https://images.pexels.com/photos/2343465/pexels-photo-2343465.jpeg?auto=compress&cs=tinysrgb&w=800',
        'https://images.pexels.com/photos/1571460/pexels-photo-1571460.jpeg?auto=compress&cs=tinysrgb&w=800'],
  ARRAY['rooftop terrace','jacuzzi','marina view','concierge','gym','security'],
  true, 'available'
),
(
  'Contemporary Apartment, Nueva Andalucía',
  'Sleek ground-floor apartment in a gated complex. South-facing terrace, private garden, and shared pool. Walking distance to golf courses.',
  'Marbella',
  'Aloha Gardens, Nueva Andalucía',
  485000,
  2, 2, 115,
  'apartment',
  ARRAY['https://images.pexels.com/photos/1571453/pexels-photo-1571453.jpeg?auto=compress&cs=tinysrgb&w=800'],
  ARRAY['garden','pool','golf view','gated community','parking'],
  false, 'available'
),

-- Mijas listings
(
  'Charming Villa, Mijas Pueblo',
  'Traditional Andalusian villa with stunning views over the white village and the coast. Private pool, large terraces, and mature gardens.',
  'Mijas',
  'Calle Casería, Mijas Pueblo',
  495000,
  4, 3, 280,
  'villa',
  ARRAY['https://images.pexels.com/photos/1029599/pexels-photo-1029599.jpeg?auto=compress&cs=tinysrgb&w=800',
        'https://images.pexels.com/photos/259588/pexels-photo-259588.jpeg?auto=compress&cs=tinysrgb&w=800'],
  ARRAY['pool','mountain view','garden','terrace','fireplace'],
  true, 'available'
),
(
  'Golf Townhouse, La Cala Resort',
  'Immaculate three-bedroom townhouse on La Cala Golf Resort. Open-plan living, private patio, and shared pools. Perfect lock-and-leave.',
  'Mijas',
  'La Cala Golf Resort, Mijas Costa',
  385000,
  3, 2, 155,
  'townhouse',
  ARRAY['https://images.pexels.com/photos/323780/pexels-photo-323780.jpeg?auto=compress&cs=tinysrgb&w=800'],
  ARRAY['golf view','pool','terrace','parking','gym'],
  false, 'available'
),
(
  'Sea-View Apartment, Calahonda',
  'Bright corner apartment with uninterrupted sea views from every room. Recently refurbished kitchen and bathrooms. Communal pools and gardens.',
  'Mijas',
  'Urbanización Calahonda, Mijas Costa',
  298000,
  2, 1, 90,
  'apartment',
  ARRAY['https://images.pexels.com/photos/2102587/pexels-photo-2102587.jpeg?auto=compress&cs=tinysrgb&w=800'],
  ARRAY['sea view','pool','terrace','parking'],
  false, 'available'
),

-- Fuengirola listings
(
  'Beachside Penthouse, Los Boliches',
  'Spectacular rooftop penthouse 50m from the beach. Two large terraces with unobstructed sea and mountain views. Fully furnished.',
  'Fuengirola',
  'Paseo Marítimo, Los Boliches',
  620000,
  3, 2, 140,
  'penthouse',
  ARRAY['https://images.pexels.com/photos/1643384/pexels-photo-1643384.jpeg?auto=compress&cs=tinysrgb&w=800'],
  ARRAY['sea view','beach access','rooftop terrace','air conditioning','parking'],
  true, 'available'
),
(
  'Modern Apartment, Centro Fuengirola',
  'Turnkey apartment in central Fuengirola, minutes from the beach and all amenities. High-spec finishes and a sunny south-facing balcony.',
  'Fuengirola',
  'Calle Larga, Centro',
  195000,
  2, 1, 80,
  'apartment',
  ARRAY['https://images.pexels.com/photos/1918291/pexels-photo-1918291.jpeg?auto=compress&cs=tinysrgb&w=800'],
  ARRAY['balcony','air conditioning','beach nearby','community pool'],
  false, 'available'
),
(
  'Rustic Finca with Olive Grove',
  'Authentic Andalusian finca on 15,000m² of land with mature olive and almond trees. Completely private, with a converted barn and riding stable.',
  'Fuengirola',
  'Partido de Cañada, Hinterland',
  750000,
  4, 3, 350,
  'finca',
  ARRAY['https://images.pexels.com/photos/280232/pexels-photo-280232.jpeg?auto=compress&cs=tinysrgb&w=800'],
  ARRAY['land','pool','mountain view','garage','stables','privacy'],
  false, 'available'
);
