-- Drop the always-true policies on life_assistant_settings
DROP POLICY IF EXISTS "la_insert" ON life_assistant_settings;
DROP POLICY IF EXISTS "la_update" ON life_assistant_settings;

-- Replace with device_key-scoped policies (UUID format validated)
CREATE POLICY "la_insert" ON life_assistant_settings FOR INSERT
  TO anon, authenticated
  WITH CHECK (
    device_key IS NOT NULL
    AND length(device_key) BETWEEN 10 AND 100
    AND device_key ~ '^[0-9a-f\-]{10,100}$'
  );

CREATE POLICY "la_update" ON life_assistant_settings FOR UPDATE
  TO anon, authenticated
  USING (device_key IS NOT NULL AND length(device_key) BETWEEN 10 AND 100)
  WITH CHECK (device_key IS NOT NULL AND length(device_key) BETWEEN 10 AND 100);

-- Drop the always-true policies on life_assistant_events
DROP POLICY IF EXISTS "lae_insert" ON life_assistant_events;
DROP POLICY IF EXISTS "lae_update" ON life_assistant_events;

-- Replace with device_key and title validated policies
CREATE POLICY "lae_insert" ON life_assistant_events FOR INSERT
  TO anon, authenticated
  WITH CHECK (
    device_key IS NOT NULL
    AND length(device_key) BETWEEN 10 AND 100
    AND title IS NOT NULL
  );

CREATE POLICY "lae_update" ON life_assistant_events FOR UPDATE
  TO anon, authenticated
  USING (device_key IS NOT NULL AND length(device_key) BETWEEN 10 AND 100)
  WITH CHECK (device_key IS NOT NULL AND length(device_key) BETWEEN 10 AND 100);
