-- Add last_seen_at so contacts can see "last seen X ago" (hidden in ghost mode)
ALTER TABLE secure_chat_pins
  ADD COLUMN IF NOT EXISTS last_seen_at timestamptz DEFAULT now();

-- Update existing rows so they have a sensible initial value
UPDATE secure_chat_pins SET last_seen_at = now() WHERE last_seen_at IS NULL;
