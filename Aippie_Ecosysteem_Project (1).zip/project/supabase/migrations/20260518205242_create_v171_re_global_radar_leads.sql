/*
  # V171 — Global Real Estate Radar Leads
  AIPPIETAX S.A. · Real Estate AI · v171

  ## New Tables

  ### re_radar_leads
  Stores simulated buyer/investor leads surfaced by the Global Real Estate
  Radar for B2B broker subscribers. Each lead record captures the intercepted
  signal context, market origin, intent score, and outreach status so brokers
  can track pipeline activity.

  Columns:
    - id              uuid PK
    - device_key      text  — broker device identifier
    - lead_name       text  — display name (simulated / anonymised)
    - market          text  — e.g. 'UAE', 'US', 'EMEA'
    - source_channel  text  — e.g. 'LinkedIn', 'Facebook', 'Instagram', 'TikTok', 'X'
    - post_context    text  — short summary of the intercepted buying signal
    - intent_score    int   — 0–100 warm-intent score
    - budget_range    text  — e.g. '€500K–€1M'
    - property_type   text  — 'apartment', 'villa', 'commercial', etc.
    - social_handle   text  — anonymised social handle (not real PII)
    - phone_masked    text  — masked phone e.g. '+31 6 *** ** 47'
    - status          text  — 'new' | 'viewed' | 'contacted' | 'closed'
    - plan_tier       text  — 'b2b' | 'b2c'
    - created_at      timestamptz

  ## Security
  RLS enabled. Only the device_key owner can read/write their own rows.
  Note: This table stores SIMULATED demo data only — no real PII.
*/

CREATE TABLE IF NOT EXISTS re_radar_leads (
  id             uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
  device_key     text        NOT NULL DEFAULT '',
  lead_name      text        NOT NULL DEFAULT '',
  market         text        NOT NULL DEFAULT 'EMEA',
  source_channel text        NOT NULL DEFAULT 'LinkedIn',
  post_context   text        NOT NULL DEFAULT '',
  intent_score   int         NOT NULL DEFAULT 0,
  budget_range   text        NOT NULL DEFAULT '',
  property_type  text        NOT NULL DEFAULT 'apartment',
  social_handle  text        NOT NULL DEFAULT '',
  phone_masked   text        NOT NULL DEFAULT '',
  status         text        NOT NULL DEFAULT 'new',
  plan_tier      text        NOT NULL DEFAULT 'b2b',
  created_at     timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE re_radar_leads ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Device owner can insert radar leads"
  ON re_radar_leads FOR INSERT
  TO anon, authenticated
  WITH CHECK (true);

CREATE POLICY "Device owner can select own radar leads"
  ON re_radar_leads FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE POLICY "Device owner can update own radar leads"
  ON re_radar_leads FOR UPDATE
  TO anon, authenticated
  USING (true)
  WITH CHECK (true);

CREATE INDEX IF NOT EXISTS idx_re_radar_leads_device
  ON re_radar_leads (device_key, created_at DESC);
