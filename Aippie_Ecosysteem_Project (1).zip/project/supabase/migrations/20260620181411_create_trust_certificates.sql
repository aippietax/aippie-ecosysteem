
CREATE TABLE IF NOT EXISTS trust_certificates (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id         uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  apt_id          text NOT NULL,
  trust_name      text NOT NULL,
  full_name       text,
  activation_date text NOT NULL,
  certificate_ref text NOT NULL DEFAULT concat('CERT-', upper(substring(gen_random_uuid()::text, 1, 8))),
  dispatched_at   timestamptz NOT NULL DEFAULT now(),
  email_status    text NOT NULL DEFAULT 'queued'
);

ALTER TABLE trust_certificates ENABLE ROW LEVEL SECURITY;

CREATE POLICY "select_own_certificates" ON trust_certificates FOR SELECT
  TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "insert_own_certificates" ON trust_certificates FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "update_own_certificates" ON trust_certificates FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE POLICY "delete_own_certificates" ON trust_certificates FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

CREATE INDEX IF NOT EXISTS idx_trust_certs_apt_id ON trust_certificates(apt_id);
