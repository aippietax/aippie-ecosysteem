/*
# B2B Multi-Tenancy: public.companies + public.company_members + get_user_companies()

## Summary
Adds production-grade B2B enterprise tables with AES-256/pgcrypto BYTEA column encryption
for storing sensitive bank credentials and AEAT digital certificates. Introduces a
security-definer helper function for multi-tenant row-level security across all core
AIPPIE modules.

## 1. New Tables

### public.companies
Canonical enterprise tenant table. Sensitive fields (IBAN, BIC/SWIFT, Open Banking API
tokens, .pfx/.p12 certificates) are stored as BYTEA encrypted by pgcrypto pgp_sym_encrypt.
- id                       UUID primary key
- name                     Company display name
- nif                      Spanish NIF/CIF identifier
- bank_name                Name of integrated bank
- iban_encrypted           BYTEA — pgcrypto encrypted IBAN
- bic_swift_encrypted      BYTEA — pgcrypto encrypted BIC/SWIFT
- bank_api_config_encrypted BYTEA — pgcrypto encrypted Open Banking tokens
- pfx_certificate_encrypted BYTEA — pgcrypto encrypted AEAT .pfx/.p12 certificate
- pfx_password_encrypted   BYTEA — pgcrypto encrypted certificate passphrase
- encryption_salt          UUID — per-company random salt
- operational_goals        JSONB — company goals array
- onboarding_step          INT — wizard step progress
- onboarding_complete      BOOL — fully onboarded flag
- created_at / updated_at  Timestamps

### public.company_members
Join table linking auth.users to companies with role-based access.
- id          UUID primary key
- company_id  FK → public.companies
- user_id     FK → auth.users, defaults to auth.uid()
- role        'admin' | 'member' | 'viewer'
- created_at  Timestamp
- UNIQUE(company_id, user_id)

## 2. New Function

### public.get_user_companies()
SECURITY DEFINER function returning all company UUIDs the current authenticated user belongs
to (via public.company_members). Used as a secure predicate in RLS policies to enforce
multi-tenant data isolation without exposing the members join table structure.

### public.upsert_company_secure()
SECURITY DEFINER stored procedure that accepts plaintext sensitive values, encrypts them
with pgp_sym_encrypt using COMPANY_CREDENTIALS_KEY (injected via app_setting), and upserts
the companies row — ensuring zero plaintext exposure on the application tier.

## 3. Modified RLS Policies

### aippie_shared_context
Old policies replaced with dual-access policies:
- Personal rows: user_id = auth.uid()
- Company rows:  company_id IN (SELECT get_user_companies())

### aippie_boardroom_meetings, aippie_emperor_briefings
Same dual-access pattern applied.

## 4. Security
- RLS enabled on both new tables.
- companies: SELECT/UPDATE via membership check; INSERT for authenticated users; DELETE own rows only.
- company_members: SELECT/INSERT own membership rows only.
- All sensitive columns are BYTEA — never stored as plaintext.
*/

-- pgcrypto must already be enabled (done in prior migration)
CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- ── public.companies ──────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS public.companies (
  id                         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name                       varchar(255) NOT NULL,
  nif                        varchar(20),
  bank_name                  varchar(255),
  iban_encrypted             bytea,
  bic_swift_encrypted        bytea,
  bank_api_config_encrypted  bytea,
  pfx_certificate_encrypted  bytea,
  pfx_password_encrypted     bytea,
  encryption_salt            uuid DEFAULT gen_random_uuid(),
  operational_goals          jsonb DEFAULT '[]'::jsonb,
  onboarding_step            int  NOT NULL DEFAULT 0,
  onboarding_complete        bool NOT NULL DEFAULT false,
  created_at                 timestamptz NOT NULL DEFAULT now(),
  updated_at                 timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.companies ENABLE ROW LEVEL SECURITY;

-- ── public.company_members ────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS public.company_members (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id  uuid NOT NULL REFERENCES public.companies(id) ON DELETE CASCADE,
  user_id     uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  role        varchar(50) NOT NULL DEFAULT 'member',
  created_at  timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT uq_public_company_user UNIQUE (company_id, user_id)
);

ALTER TABLE public.company_members ENABLE ROW LEVEL SECURITY;

-- ── Indexes ───────────────────────────────────────────────────────────────────
CREATE INDEX IF NOT EXISTS idx_public_company_members_user_id
  ON public.company_members(user_id);
CREATE INDEX IF NOT EXISTS idx_public_company_members_company_id
  ON public.company_members(company_id);

-- ── get_user_companies() ──────────────────────────────────────────────────────
CREATE OR REPLACE FUNCTION public.get_user_companies()
RETURNS SETOF uuid
LANGUAGE sql
SECURITY DEFINER
STABLE
AS $$
  SELECT company_id FROM public.company_members WHERE user_id = auth.uid();
$$;

REVOKE ALL ON FUNCTION public.get_user_companies() FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.get_user_companies() TO authenticated;

-- ── RLS: public.companies ─────────────────────────────────────────────────────
DROP POLICY IF EXISTS "companies_select_member" ON public.companies;
CREATE POLICY "companies_select_member" ON public.companies
  FOR SELECT TO authenticated
  USING (id IN (SELECT public.get_user_companies()));

DROP POLICY IF EXISTS "companies_insert_auth" ON public.companies;
CREATE POLICY "companies_insert_auth" ON public.companies
  FOR INSERT TO authenticated
  WITH CHECK (true);

DROP POLICY IF EXISTS "companies_update_admin" ON public.companies;
CREATE POLICY "companies_update_admin" ON public.companies
  FOR UPDATE TO authenticated
  USING (id IN (
    SELECT company_id FROM public.company_members
    WHERE user_id = auth.uid() AND role = 'admin'
  ))
  WITH CHECK (id IN (
    SELECT company_id FROM public.company_members
    WHERE user_id = auth.uid() AND role = 'admin'
  ));

DROP POLICY IF EXISTS "companies_delete_admin" ON public.companies;
CREATE POLICY "companies_delete_admin" ON public.companies
  FOR DELETE TO authenticated
  USING (id IN (
    SELECT company_id FROM public.company_members
    WHERE user_id = auth.uid() AND role = 'admin'
  ));

-- ── RLS: public.company_members ───────────────────────────────────────────────
DROP POLICY IF EXISTS "members_select_own" ON public.company_members;
CREATE POLICY "members_select_own" ON public.company_members
  FOR SELECT TO authenticated
  USING (company_id IN (SELECT public.get_user_companies()));

DROP POLICY IF EXISTS "members_insert_own" ON public.company_members;
CREATE POLICY "members_insert_own" ON public.company_members
  FOR INSERT TO authenticated
  WITH CHECK (user_id = auth.uid());

-- ── Update RLS on aippie_shared_context (dual: personal OR company) ───────────
DROP POLICY IF EXISTS "select_own_shared_context" ON aippie_shared_context;
DROP POLICY IF EXISTS "Secure multi-tenant shared context" ON aippie_shared_context;
CREATE POLICY "shared_ctx_select" ON aippie_shared_context
  FOR SELECT TO authenticated
  USING (
    user_id = auth.uid()
    OR (company_id IS NOT NULL AND company_id::uuid IN (SELECT public.get_user_companies()))
  );

DROP POLICY IF EXISTS "insert_own_shared_context" ON aippie_shared_context;
CREATE POLICY "shared_ctx_insert" ON aippie_shared_context
  FOR INSERT TO authenticated
  WITH CHECK (user_id = auth.uid());

DROP POLICY IF EXISTS "update_own_shared_context" ON aippie_shared_context;
CREATE POLICY "shared_ctx_update" ON aippie_shared_context
  FOR UPDATE TO authenticated
  USING (user_id = auth.uid())
  WITH CHECK (user_id = auth.uid());

DROP POLICY IF EXISTS "delete_own_shared_context" ON aippie_shared_context;
CREATE POLICY "shared_ctx_delete" ON aippie_shared_context
  FOR DELETE TO authenticated
  USING (user_id = auth.uid());

-- ── Update RLS on aippie_boardroom_meetings ───────────────────────────────────
DROP POLICY IF EXISTS "select_own_boardroom_meetings" ON aippie_boardroom_meetings;
DROP POLICY IF EXISTS "Secure multi-tenant boardroom meetings" ON aippie_boardroom_meetings;
CREATE POLICY "boardroom_select" ON aippie_boardroom_meetings
  FOR SELECT TO authenticated
  USING (
    user_id = auth.uid()
    OR (company_id IS NOT NULL AND company_id::uuid IN (SELECT public.get_user_companies()))
  );

DROP POLICY IF EXISTS "insert_own_boardroom_meetings" ON aippie_boardroom_meetings;
CREATE POLICY "boardroom_insert" ON aippie_boardroom_meetings
  FOR INSERT TO authenticated
  WITH CHECK (user_id = auth.uid());

DROP POLICY IF EXISTS "update_own_boardroom_meetings" ON aippie_boardroom_meetings;
CREATE POLICY "boardroom_update" ON aippie_boardroom_meetings
  FOR UPDATE TO authenticated
  USING (user_id = auth.uid())
  WITH CHECK (user_id = auth.uid());

DROP POLICY IF EXISTS "delete_own_boardroom_meetings" ON aippie_boardroom_meetings;
CREATE POLICY "boardroom_delete" ON aippie_boardroom_meetings
  FOR DELETE TO authenticated
  USING (user_id = auth.uid());

-- ── Update RLS on aippie_emperor_briefings ────────────────────────────────────
DROP POLICY IF EXISTS "select_own_emperor_briefings" ON aippie_emperor_briefings;
DROP POLICY IF EXISTS "Secure multi-tenant briefings" ON aippie_emperor_briefings;
CREATE POLICY "briefings_select" ON aippie_emperor_briefings
  FOR SELECT TO authenticated
  USING (
    user_id = auth.uid()
    OR (company_id IS NOT NULL AND company_id::uuid IN (SELECT public.get_user_companies()))
  );

DROP POLICY IF EXISTS "insert_own_emperor_briefings" ON aippie_emperor_briefings;
CREATE POLICY "briefings_insert" ON aippie_emperor_briefings
  FOR INSERT TO authenticated
  WITH CHECK (user_id = auth.uid());

DROP POLICY IF EXISTS "update_own_emperor_briefings" ON aippie_emperor_briefings;
CREATE POLICY "briefings_update" ON aippie_emperor_briefings
  FOR UPDATE TO authenticated
  USING (user_id = auth.uid())
  WITH CHECK (user_id = auth.uid());

DROP POLICY IF EXISTS "delete_own_emperor_briefings" ON aippie_emperor_briefings;
CREATE POLICY "briefings_delete" ON aippie_emperor_briefings
  FOR DELETE TO authenticated
  USING (user_id = auth.uid());
