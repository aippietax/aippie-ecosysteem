-- ── ai_paper_positions ───────────────────────────────────────────────────────
-- Restrict INSERT/UPDATE to rows whose session_key is a non-empty string
-- (prevents anonymous write to arbitrary / blank session keys).
DROP POLICY IF EXISTS "insert_own_paper" ON ai_paper_positions;
DROP POLICY IF EXISTS "update_own_paper" ON ai_paper_positions;

CREATE POLICY "insert_own_paper" ON ai_paper_positions
  FOR INSERT TO anon, authenticated
  WITH CHECK (
    session_key IS NOT NULL AND length(trim(session_key)) > 0
  );

CREATE POLICY "update_own_paper" ON ai_paper_positions
  FOR UPDATE TO anon, authenticated
  USING  (session_key IS NOT NULL AND length(trim(session_key)) > 0)
  WITH CHECK (session_key IS NOT NULL AND length(trim(session_key)) > 0);

-- ── care_board_events ────────────────────────────────────────────────────────
-- Require a non-empty device_key on insert (supplied by the client app).
DROP POLICY IF EXISTS "insert_care_board_events" ON care_board_events;

CREATE POLICY "insert_care_board_events" ON care_board_events
  FOR INSERT TO anon, authenticated
  WITH CHECK (
    device_key IS NOT NULL AND length(trim(device_key)) > 0
  );

-- ── pulse_readings ───────────────────────────────────────────────────────────
-- Require a non-empty device_key on insert.
DROP POLICY IF EXISTS "insert_pulse_readings" ON pulse_readings;

CREATE POLICY "insert_pulse_readings" ON pulse_readings
  FOR INSERT TO anon, authenticated
  WITH CHECK (
    device_key IS NOT NULL AND length(trim(device_key)) > 0
  );

-- ── aippietax_active_licenses ─────────────────────────────────────────────────
-- Checkout INSERT: require license_key and owner_email to be non-empty.
DROP POLICY IF EXISTS "Anyone can insert license via checkout" ON aippietax_active_licenses;

CREATE POLICY "Anyone can insert license via checkout" ON aippietax_active_licenses
  FOR INSERT TO anon, authenticated
  WITH CHECK (
    license_key IS NOT NULL AND length(trim(license_key)) > 0
    AND owner_email IS NOT NULL AND length(trim(owner_email)) > 0
  );

-- Checkout UPDATE: only allow updating used_seats (seats counting during activation).
-- Scope to rows with a valid license_key to prevent blind full-table updates.
DROP POLICY IF EXISTS "Anyone can update own license used_seats" ON aippietax_active_licenses;

CREATE POLICY "Anyone can update own license used_seats" ON aippietax_active_licenses
  FOR UPDATE TO anon, authenticated
  USING  (license_key IS NOT NULL AND length(trim(license_key)) > 0)
  WITH CHECK (license_key IS NOT NULL AND length(trim(license_key)) > 0);
