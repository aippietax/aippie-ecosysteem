/*
  # Safe Check-in Timer Emergency Core — AIPPIETAX S.A.

  ## Summary
  Implements the autonomous Safe Check-in Timer and Emergency Dispatch system.

  ## New Tables

  ### 1. emergency_contacts
  Stores pre-configured primary family/trusted emergency contacts per user.
  - id (uuid PK)
  - user_id (uuid FK → auth.users)
  - name (text) — display name of the contact
  - phone (text) — E.164 international phone number (+34...)
  - email (text, optional) — backup email address
  - is_primary (bool) — whether this is the first-priority dispatch target
  - created_at (timestamptz)

  ### 2. safe_checkin_sessions
  Records every check-in timer activation and its outcome.
  - id (uuid PK)
  - user_id (uuid FK → auth.users)
  - duration_minutes (int) — timer window chosen by user (5 / 10 / 15 / custom)
  - started_at (timestamptz) — when user activated the timer
  - expires_at (timestamptz) — when authentication challenge fires
  - grace_ends_at (timestamptz) — 60 s after expires_at; distress triggers here
  - status (text) — 'active' | 'safe' | 'distress' | 'cancelled'
  - lat (double precision, nullable) — GPS latitude at distress trigger
  - lng (double precision, nullable) — GPS longitude at distress trigger
  - dispatch_sent_at (timestamptz, nullable) — when emergency payload was sent
  - dispatch_contacts (jsonb, nullable) — snapshot of recipients at dispatch time
  - maps_link (text, nullable) — Google Maps deep-link for live location
  - pin_attempts (int) — number of failed PIN attempts during grace window
  - created_at (timestamptz)

  ## Security
  - RLS enabled on both tables
  - Users can only read/write their own rows
  - INSERT requires authenticated user, WITH CHECK enforces user_id = auth.uid()
  - No public read access
*/

-- ── emergency_contacts ───────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS emergency_contacts (
  id          uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id     uuid        NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  name        text        NOT NULL DEFAULT '',
  phone       text        NOT NULL DEFAULT '',
  email       text        NOT NULL DEFAULT '',
  is_primary  boolean     NOT NULL DEFAULT false,
  created_at  timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE emergency_contacts ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can select own emergency contacts"
  ON emergency_contacts FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own emergency contacts"
  ON emergency_contacts FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own emergency contacts"
  ON emergency_contacts FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own emergency contacts"
  ON emergency_contacts FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- ── safe_checkin_sessions ────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS safe_checkin_sessions (
  id                uuid            PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id           uuid            NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  duration_minutes  integer         NOT NULL DEFAULT 10,
  started_at        timestamptz     NOT NULL DEFAULT now(),
  expires_at        timestamptz     NOT NULL,
  grace_ends_at     timestamptz     NOT NULL,
  status            text            NOT NULL DEFAULT 'active'
                                    CHECK (status IN ('active','safe','distress','cancelled')),
  lat               double precision,
  lng               double precision,
  dispatch_sent_at  timestamptz,
  dispatch_contacts jsonb,
  maps_link         text,
  pin_attempts      integer         NOT NULL DEFAULT 0,
  created_at        timestamptz     NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_safe_checkin_user_status
  ON safe_checkin_sessions (user_id, status);

ALTER TABLE safe_checkin_sessions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can select own checkin sessions"
  ON safe_checkin_sessions FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own checkin sessions"
  ON safe_checkin_sessions FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own checkin sessions"
  ON safe_checkin_sessions FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);
