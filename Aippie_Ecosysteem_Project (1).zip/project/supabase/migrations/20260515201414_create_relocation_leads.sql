/*
  # Create aippie_relocation_leads table

  ## Summary
  Captures leads from the AippieConnect Relocation module when a user taps
  the "Get the Gold Bridge Roadmap – €499" checkout card. Each row records
  the device key, selected language, chosen relocation domain, and checkout
  intent timestamp. Stripe payment confirmation is handled externally and
  can update the `paid_at` column via a webhook.

  ## New Table: aippie_relocation_leads
  - `id`           uuid PK
  - `device_key`   text — anonymous device identifier
  - `lang_code`    text — user's selected language
  - `domain`       text — 'housing_nie' | 'education_health' | 'business_wealth' | 'full_package'
  - `amount_eur`   numeric DEFAULT 499 — price captured at lead creation
  - `status`       text DEFAULT 'pending' — 'pending' | 'paid' | 'cancelled'
  - `paid_at`      timestamptz nullable — set by Stripe webhook on confirmation
  - `created_at`   timestamptz DEFAULT now()

  ## Security
  - RLS enabled
  - Anonymous inserts allowed (device-key based, no auth required)
  - Authenticated reads only (admin review)
*/

CREATE TABLE IF NOT EXISTS aippie_relocation_leads (
  id          uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
  device_key  text        NOT NULL DEFAULT '',
  lang_code   text        NOT NULL DEFAULT 'en',
  domain      text        NOT NULL DEFAULT 'full_package',
  amount_eur  numeric     NOT NULL DEFAULT 499,
  status      text        NOT NULL DEFAULT 'pending'
                          CHECK (status IN ('pending', 'paid', 'cancelled')),
  paid_at     timestamptz,
  created_at  timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE aippie_relocation_leads ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can insert relocation lead"
  ON aippie_relocation_leads FOR INSERT
  TO anon, authenticated
  WITH CHECK (true);

CREATE POLICY "Authenticated users can read relocation leads"
  ON aippie_relocation_leads FOR SELECT
  TO authenticated
  USING (true);
