/*
  # Add language preference to client_profiles

  1. Changes
    - Add `language` column (text, default 'en') to `client_profiles`
    - Stores the ISO language code selected during onboarding (nl, en, de, fr, sv)

  2. Notes
    - Non-destructive: existing rows receive 'en' as the default value
*/

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'client_profiles' AND column_name = 'language'
  ) THEN
    ALTER TABLE client_profiles ADD COLUMN language text NOT NULL DEFAULT 'en';
  END IF;
END $$;
