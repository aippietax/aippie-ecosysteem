-- Parent contacts per device — stores mama/papa phone numbers for notifications
CREATE TABLE IF NOT EXISTS parent_contacts (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  device_key  text NOT NULL,
  label       text NOT NULL DEFAULT 'Mama',   -- 'Mama', 'Papa', 'Verzorger'
  phone       text NOT NULL,                  -- international format e.g. +31612345678
  is_primary  boolean NOT NULL DEFAULT true,
  created_at  timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS parent_contacts_device_key_idx ON parent_contacts (device_key);

ALTER TABLE parent_contacts ENABLE ROW LEVEL SECURITY;

CREATE POLICY "insert_own_contacts" ON parent_contacts
  FOR INSERT TO anon, authenticated
  WITH CHECK (device_key IS NOT NULL AND length(trim(device_key)) > 0);

CREATE POLICY "select_own_contacts" ON parent_contacts
  FOR SELECT TO anon, authenticated
  USING (device_key IS NOT NULL AND length(trim(device_key)) > 0);

CREATE POLICY "update_own_contacts" ON parent_contacts
  FOR UPDATE TO anon, authenticated
  USING (device_key IS NOT NULL AND length(trim(device_key)) > 0)
  WITH CHECK (device_key IS NOT NULL AND length(trim(device_key)) > 0);

CREATE POLICY "delete_own_contacts" ON parent_contacts
  FOR DELETE TO anon, authenticated
  USING (device_key IS NOT NULL AND length(trim(device_key)) > 0);

-- Add parent_notified flag to care_board_events for tracking
ALTER TABLE care_board_events
  ADD COLUMN IF NOT EXISTS is_emergency boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS parent_notified_at timestamptz;
