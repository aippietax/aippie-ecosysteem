/*
  # V201 — Intellectual Property & Compliance Registry

  Creates the `ip_asset_registry` table for AIPPIETAX S.A. admin use.

  ## New Tables
  - `ip_asset_registry`
    - `id` (uuid, primary key)
    - `owner_user_id` (uuid, FK to auth.users — the admin who created the record)
    - `doc_reference` (text) — internal document reference number
    - `effective_date` (date) — contract / assignment effective date
    - `target_app_id` (text) — e.g. App Store numeric ID
    - `target_bundle_id` (text) — e.g. com.example.app
    - `check_legal_title` (boolean) — Legal Title Assignment verified
    - `check_code_audit` (boolean) — Technical Code Audit verified
    - `check_regulatory` (boolean) — Platform Regulatory Compliance verified
    - `notes` (text) — free-form admin notes
    - `created_at` (timestamptz)
    - `updated_at` (timestamptz)

  ## Security
  - RLS enabled, restrictive
  - Only the creating admin (matched by auth.uid()) can SELECT / INSERT / UPDATE
  - No public read; data is internal admin-only
*/

CREATE TABLE IF NOT EXISTS ip_asset_registry (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  owner_user_id   uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  doc_reference   text NOT NULL DEFAULT '',
  effective_date  date,
  target_app_id   text NOT NULL DEFAULT '',
  target_bundle_id text NOT NULL DEFAULT '',
  check_legal_title  boolean NOT NULL DEFAULT false,
  check_code_audit   boolean NOT NULL DEFAULT false,
  check_regulatory   boolean NOT NULL DEFAULT false,
  notes           text NOT NULL DEFAULT '',
  created_at      timestamptz NOT NULL DEFAULT now(),
  updated_at      timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE ip_asset_registry ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admin can view own IP records"
  ON ip_asset_registry FOR SELECT
  TO authenticated
  USING (auth.uid() = owner_user_id);

CREATE POLICY "Admin can insert own IP records"
  ON ip_asset_registry FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = owner_user_id);

CREATE POLICY "Admin can update own IP records"
  ON ip_asset_registry FOR UPDATE
  TO authenticated
  USING  (auth.uid() = owner_user_id)
  WITH CHECK (auth.uid() = owner_user_id);

CREATE INDEX IF NOT EXISTS ip_asset_registry_owner_idx ON ip_asset_registry(owner_user_id);
