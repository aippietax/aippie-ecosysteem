/*
  # Create Doctor Vitals Logs Table — V92 Camera Biometrics Engine
  AIPPIETAX S.A.

  ## Summary
  Creates the `doctor_vitals_logs` table used by the Aippie Doctor Module to
  persist PPG-based biometric scan results from the device camera.

  ## New Tables
  - `doctor_vitals_logs`
    - `id` (uuid, PK) — auto-generated
    - `user_id` (uuid, nullable) — links to auth.users if logged in; null for
      anonymous sessions (device-only scan, no account required)
    - `bpm` (integer) — heart rate in beats per minute
    - `hrv` (integer) — HRV stress index in milliseconds
    - `spo2` (integer) — blood oxygen saturation percentage
    - `scanned_at` (timestamptz) — client-reported scan timestamp
    - `created_at` (timestamptz) — server insertion timestamp

  ## Security
  - RLS enabled — table is locked by default
  - INSERT policy: any authenticated user can insert their own row
  - INSERT policy (anon): anonymous users may also insert (device-only scans)
  - SELECT policy: authenticated users can only read their own rows
  - No UPDATE or DELETE policies — vitals logs are append-only
*/

CREATE TABLE IF NOT EXISTS doctor_vitals_logs (
  id          uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id     uuid        REFERENCES auth.users(id) ON DELETE SET NULL,
  bpm         integer     NOT NULL DEFAULT 0,
  hrv         integer     NOT NULL DEFAULT 0,
  spo2        integer     NOT NULL DEFAULT 0,
  scanned_at  timestamptz NOT NULL DEFAULT now(),
  created_at  timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE doctor_vitals_logs ENABLE ROW LEVEL SECURITY;

-- Authenticated users can insert their own vitals
CREATE POLICY "Authenticated users can insert own vitals"
  ON doctor_vitals_logs
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id OR user_id IS NULL);

-- Anonymous/unauthenticated users can insert device-only scans (user_id = null)
CREATE POLICY "Anon users can insert anonymous vitals"
  ON doctor_vitals_logs
  FOR INSERT
  TO anon
  WITH CHECK (user_id IS NULL);

-- Authenticated users can read only their own vitals rows
CREATE POLICY "Users can read own vitals"
  ON doctor_vitals_logs
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

-- Index for fast per-user retrieval
CREATE INDEX IF NOT EXISTS idx_doctor_vitals_logs_user_id
  ON doctor_vitals_logs (user_id, scanned_at DESC);
