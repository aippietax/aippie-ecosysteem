/*
  # V147 Partner Affiliate Matrix — Trading Alpha

  1. New Tables
    - `trading_partner_affiliates`
      - `id` (uuid, primary key)
      - `device_key` (text) — anonymous device identifier
      - `affiliate_name` (text)
      - `affiliate_email` (text)
      - `iban` (text)
      - `active_seats` (integer) — number of active subscriber seats
      - `monthly_commission_eur` (numeric) — 20% of €499 × seats
      - `total_paid_out_eur` (numeric)
      - `status` (text) — 'active' | 'pending'
      - `created_at` (timestamptz)

    - `trading_affiliate_payouts`
      - `id` (uuid, primary key)
      - `device_key` (text)
      - `affiliate_id` (uuid, references trading_partner_affiliates)
      - `amount_eur` (numeric)
      - `invoice_ref` (text)
      - `status` (text) — 'queued' | 'completed'
      - `created_at` (timestamptz)

  2. Security
    - RLS enabled on both tables
    - INSERT / SELECT / UPDATE for anon + authenticated
*/

CREATE TABLE IF NOT EXISTS trading_partner_affiliates (
  id                   uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  device_key           text NOT NULL DEFAULT '',
  affiliate_name       text NOT NULL DEFAULT '',
  affiliate_email      text NOT NULL DEFAULT '',
  iban                 text NOT NULL DEFAULT '',
  active_seats         integer NOT NULL DEFAULT 0,
  monthly_commission_eur numeric(10,2) NOT NULL DEFAULT 0.00,
  total_paid_out_eur   numeric(10,2) NOT NULL DEFAULT 0.00,
  status               text NOT NULL DEFAULT 'pending',
  created_at           timestamptz DEFAULT now()
);

ALTER TABLE trading_partner_affiliates ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anon insert trading affiliate"
  ON trading_partner_affiliates FOR INSERT TO anon WITH CHECK (true);

CREATE POLICY "Authenticated insert trading affiliate"
  ON trading_partner_affiliates FOR INSERT TO authenticated WITH CHECK (true);

CREATE POLICY "Anon select trading affiliate"
  ON trading_partner_affiliates FOR SELECT TO anon USING (true);

CREATE POLICY "Authenticated select trading affiliate"
  ON trading_partner_affiliates FOR SELECT TO authenticated USING (true);

CREATE POLICY "Anon update trading affiliate"
  ON trading_partner_affiliates FOR UPDATE TO anon USING (true) WITH CHECK (true);

CREATE POLICY "Authenticated update trading affiliate"
  ON trading_partner_affiliates FOR UPDATE TO authenticated USING (true) WITH CHECK (true);


CREATE TABLE IF NOT EXISTS trading_affiliate_payouts (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  device_key   text NOT NULL DEFAULT '',
  affiliate_id uuid REFERENCES trading_partner_affiliates(id) ON DELETE CASCADE,
  amount_eur   numeric(10,2) NOT NULL DEFAULT 0.00,
  invoice_ref  text NOT NULL DEFAULT '',
  status       text NOT NULL DEFAULT 'queued',
  created_at   timestamptz DEFAULT now()
);

ALTER TABLE trading_affiliate_payouts ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anon insert trading payout"
  ON trading_affiliate_payouts FOR INSERT TO anon WITH CHECK (true);

CREATE POLICY "Authenticated insert trading payout"
  ON trading_affiliate_payouts FOR INSERT TO authenticated WITH CHECK (true);

CREATE POLICY "Anon select trading payout"
  ON trading_affiliate_payouts FOR SELECT TO anon USING (true);

CREATE POLICY "Authenticated select trading payout"
  ON trading_affiliate_payouts FOR SELECT TO authenticated USING (true);

CREATE POLICY "Anon update trading payout"
  ON trading_affiliate_payouts FOR UPDATE TO anon USING (true) WITH CHECK (true);

CREATE POLICY "Authenticated update trading payout"
  ON trading_affiliate_payouts FOR UPDATE TO authenticated USING (true) WITH CHECK (true);
