
CREATE TABLE IF NOT EXISTS lifetime_deal_slots (
  id          int PRIMARY KEY DEFAULT 1,
  sold_count  int NOT NULL DEFAULT 12,
  updated_at  timestamptz NOT NULL DEFAULT now()
);

INSERT INTO lifetime_deal_slots (id, sold_count) VALUES (1, 12)
  ON CONFLICT (id) DO NOTHING;

ALTER TABLE lifetime_deal_slots ENABLE ROW LEVEL SECURITY;

CREATE POLICY "select_lifetime_slots" ON lifetime_deal_slots FOR SELECT
  TO anon, authenticated USING (true);

CREATE POLICY "update_lifetime_slots" ON lifetime_deal_slots FOR UPDATE
  TO authenticated USING (true) WITH CHECK (true);
