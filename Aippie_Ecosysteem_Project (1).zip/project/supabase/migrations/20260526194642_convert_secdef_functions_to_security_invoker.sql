/*
  # Convert SECURITY DEFINER functions to SECURITY INVOKER

  ## Summary

  Both `aivp_dispatch_payout` and `claim_smart_home_license` were flagged because
  authenticated users can call SECURITY DEFINER functions, which run with elevated
  (postgres-role) privileges. Converting to SECURITY INVOKER means the functions
  run under the caller's own privileges and RLS policies, eliminating the privilege
  escalation risk.

  ## Changes

  ### New RLS Policies
  Two write policies were missing, which is why SECURITY DEFINER was needed:

  1. `aivp_payout_dispatches` — INSERT policy for authenticated producers
     (previously only SELECT existed; the SECURITY DEFINER function inserted as postgres)

  2. `aippie_licenses` — UPDATE policy for authenticated users
     (previously only SELECT existed; the SECURITY DEFINER function updated as postgres)

  ### Modified Functions
  Both functions rebuilt as SECURITY INVOKER with search_path locked:
  - `public.aivp_dispatch_payout(p_producer_id uuid)`
  - `public.claim_smart_home_license(p_key text)`

  ### Security Model After Fix
  - Functions run as the calling authenticated user
  - RLS enforces all data access boundaries
  - No postgres-level privilege escalation possible
*/

-- ── 1. Add missing INSERT policy on aivp_payout_dispatches ───────────────────
-- Producers can insert a dispatch only for their own producer record
CREATE POLICY "Producers can insert own payout dispatch"
  ON public.aivp_payout_dispatches
  FOR INSERT
  TO authenticated
  WITH CHECK (
    producer_id IN (
      SELECT id FROM public.aivp_producers WHERE user_id = auth.uid()
    )
  );

-- ── 2. Add missing UPDATE policy on aippie_licenses ──────────────────────────
-- Authenticated users can claim an unclaimed license (client_id IS NULL → their uid)
-- or update a license they already own
CREATE POLICY "Authenticated users can claim or update own license"
  ON public.aippie_licenses
  FOR UPDATE
  TO authenticated
  USING (
    client_id IS NULL OR client_id = auth.uid()
  )
  WITH CHECK (
    client_id = auth.uid()
  );

-- ── 3. Rebuild aivp_dispatch_payout as SECURITY INVOKER ──────────────────────
CREATE OR REPLACE FUNCTION public.aivp_dispatch_payout(p_producer_id uuid)
  RETURNS jsonb
  LANGUAGE plpgsql
  SECURITY INVOKER
  SET search_path = 'public'
AS $$
DECLARE
  v_producer      aivp_producers%ROWTYPE;
  v_stream_mins   float8 := 0;
  v_gross         float8 := 0;
  v_platform_fee  float8 := 0;
  v_net           float8 := 0;
  v_transfer_id   text;
  v_dispatch_id   uuid;
BEGIN
  -- Validate caller is the producer (RLS also enforces this on the SELECT)
  SELECT * INTO v_producer
  FROM public.aivp_producers
  WHERE id = p_producer_id AND user_id = auth.uid();

  IF NOT FOUND THEN
    RETURN jsonb_build_object('success', false, 'error', 'unauthorized');
  END IF;

  -- Sum unpaid stream minutes across all live assets
  SELECT COALESCE(SUM(se.minutes_watched), 0)
  INTO v_stream_mins
  FROM public.aivp_stream_events se
  JOIN public.aivp_media_assets am ON am.id = se.asset_id
  WHERE am.producer_id = p_producer_id
    AND se.created_at > COALESCE(
      (SELECT MAX(created_at) FROM public.aivp_payout_dispatches
       WHERE producer_id = p_producer_id AND status = 'dispatched'),
      '1970-01-01'::timestamptz
    );

  -- Compute earnings: €0.002 per minute, 30% platform fee, 70% net
  v_gross        := v_stream_mins * 0.002;
  v_platform_fee := ROUND((v_gross * 0.30)::numeric, 4);
  v_net          := ROUND((v_gross * 0.70)::numeric, 4);

  IF v_net < 0.01 THEN
    RETURN jsonb_build_object('success', false, 'error', 'insufficient_balance', 'net_eur', v_net);
  END IF;

  -- Simulate Stripe Connect transfer ID
  v_transfer_id := 'tr_sim_' || encode(gen_random_bytes(8), 'hex');

  -- Insert dispatch record (INSERT RLS policy now allows this for authenticated producers)
  INSERT INTO public.aivp_payout_dispatches (
    producer_id, period_start, period_end,
    stream_minutes, gross_revenue_eur, platform_fee_eur, net_payout_eur,
    stripe_transfer_id, status, dispatched_at
  ) VALUES (
    p_producer_id,
    CURRENT_DATE - 30, CURRENT_DATE,
    v_stream_mins, v_gross, v_platform_fee, v_net,
    v_transfer_id, 'dispatched', now()
  ) RETURNING id INTO v_dispatch_id;

  -- Update producer totals (UPDATE RLS policy already allows auth.uid() = user_id)
  UPDATE public.aivp_producers
  SET total_earnings_eur = total_earnings_eur + v_net,
      pending_payout_eur = 0
  WHERE id = p_producer_id;

  RETURN jsonb_build_object(
    'success',        true,
    'dispatch_id',    v_dispatch_id,
    'stream_minutes', v_stream_mins,
    'gross_eur',      v_gross,
    'platform_fee',   v_platform_fee,
    'net_payout_eur', v_net,
    'transfer_id',    v_transfer_id
  );
END;
$$;

-- ── 4. Rebuild claim_smart_home_license as SECURITY INVOKER ──────────────────
CREATE OR REPLACE FUNCTION public.claim_smart_home_license(p_key text)
  RETURNS jsonb
  LANGUAGE plpgsql
  SECURITY INVOKER
  SET search_path = 'public'
AS $$
DECLARE
  v_rec  public.aippie_licenses%ROWTYPE;
  v_uid  uuid := auth.uid();
BEGIN
  IF v_uid IS NULL THEN
    RETURN jsonb_build_object('ok', false, 'error', 'Not authenticated');
  END IF;

  SELECT * INTO v_rec
  FROM public.aippie_licenses
  WHERE license_key = upper(trim(p_key))
  FOR UPDATE;

  IF NOT FOUND THEN
    RETURN jsonb_build_object('ok', false, 'error', 'License key not found');
  END IF;

  IF v_rec.status = 'suspended' THEN
    RETURN jsonb_build_object('ok', false, 'error', 'License is suspended');
  END IF;

  IF v_rec.status = 'expired' THEN
    RETURN jsonb_build_object('ok', false, 'error', 'License has expired');
  END IF;

  IF v_rec.expiration_date IS NOT NULL AND v_rec.expiration_date < now() THEN
    UPDATE public.aippie_licenses SET status = 'expired' WHERE id = v_rec.id;
    RETURN jsonb_build_object('ok', false, 'error', 'License has expired');
  END IF;

  -- Already claimed by this user — idempotent re-login
  IF v_rec.client_id = v_uid THEN
    RETURN jsonb_build_object(
      'ok', true,
      'license_id',    v_rec.id,
      'package_type',  v_rec.package_type,
      'owner_name',    v_rec.owner_name
    );
  END IF;

  -- Claimed by a different user — blocked
  IF v_rec.client_id IS NOT NULL AND v_rec.client_id <> v_uid THEN
    RETURN jsonb_build_object('ok', false, 'error', 'License already activated by another account');
  END IF;

  -- Claim it (UPDATE RLS policy now allows: client_id IS NULL → auth.uid())
  UPDATE public.aippie_licenses
  SET client_id = v_uid, activated_at = now()
  WHERE id = v_rec.id;

  -- Seed default memory params (INSERT RLS policy allows auth.uid() = client_id)
  INSERT INTO public.smart_home_memory_params (client_id)
  VALUES (v_uid)
  ON CONFLICT (client_id) DO NOTHING;

  RETURN jsonb_build_object(
    'ok', true,
    'license_id',    v_rec.id,
    'package_type',  v_rec.package_type,
    'owner_name',    v_rec.owner_name
  );
END;
$$;

-- ── 5. Ensure EXECUTE grants are correct for SECURITY INVOKER functions ───────
-- SECURITY INVOKER functions do not need the same EXECUTE restrictions since
-- they no longer escalate privileges, but we keep anon blocked as a best practice.
REVOKE ALL ON FUNCTION public.aivp_dispatch_payout(uuid) FROM PUBLIC;
REVOKE ALL ON FUNCTION public.aivp_dispatch_payout(uuid) FROM anon;
GRANT EXECUTE ON FUNCTION public.aivp_dispatch_payout(uuid) TO authenticated;

REVOKE ALL ON FUNCTION public.claim_smart_home_license(text) FROM PUBLIC;
REVOKE ALL ON FUNCTION public.claim_smart_home_license(text) FROM anon;
GRANT EXECUTE ON FUNCTION public.claim_smart_home_license(text) TO authenticated;
