/*
  # V148 LLC & Irrevocable Spendthrift Trust Integration Orders

  1. New Tables
    - `re_llc_trust_orders`
      - `id` (uuid, primary key)
      - `device_key` (text) — anonymous device identifier
      - `product` (text) — 'llc_api' | 'trust_setup' | 'trust_maintenance'
      - `label` (text) — human-readable product label
      - `amount_usd` (numeric) — price paid
      - `company_name` (text) — optional LLC / trust entity name
      - `contact_email` (text)
      - `card_last4` (text)
      - `session_token` (text) — unlock token
      - `status` (text) — 'active' | 'pending'
      - `created_at` (timestamptz)

  2. Security
    - RLS enabled, device_key-scoped INSERT/UPDATE (non-empty key required)
    - SELECT open to anon + authenticated for own-device lookups
*/

CREATE TABLE IF NOT EXISTS re_llc_trust_orders (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  device_key    text NOT NULL DEFAULT '',
  product       text NOT NULL DEFAULT '',
  label         text NOT NULL DEFAULT '',
  amount_usd    numeric(10,2) NOT NULL DEFAULT 0.00,
  company_name  text NOT NULL DEFAULT '',
  contact_email text NOT NULL DEFAULT '',
  card_last4    text NOT NULL DEFAULT '',
  session_token text NOT NULL DEFAULT '',
  status        text NOT NULL DEFAULT 'pending',
  created_at    timestamptz DEFAULT now()
);

ALTER TABLE re_llc_trust_orders ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Device insert LLC trust order"
  ON re_llc_trust_orders FOR INSERT
  TO anon, authenticated
  WITH CHECK (device_key <> '' AND device_key IS NOT NULL);

CREATE POLICY "Device select LLC trust order"
  ON re_llc_trust_orders FOR SELECT
  TO anon, authenticated
  USING (device_key <> '' AND device_key IS NOT NULL);

CREATE POLICY "Device update LLC trust order"
  ON re_llc_trust_orders FOR UPDATE
  TO anon, authenticated
  USING  (device_key <> '' AND device_key IS NOT NULL)
  WITH CHECK (device_key <> '' AND device_key IS NOT NULL);
