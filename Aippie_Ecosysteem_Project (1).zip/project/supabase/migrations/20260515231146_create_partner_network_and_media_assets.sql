/*
  # Create aippie_partner_network and aippie_media_assets tables

  ## Summary
  Version 43 introduces two new tables:

  1. **aippie_partner_network** — B2B SaaS partner ledger.
     Tracks external agents/companies leasing the Aippie infrastructure.
     Each row represents one partner with their client payment status,
     earned commission balance, and a flag distinguishing internal AIPPIETAX
     agents (free access) from external enterprise licensees (€199.99/month).

  2. **aippie_media_assets** — Zero-weight cloud media pointer table.
     Stores external secure asset URLs (AWS S3 / Google Cloud) instead of raw
     media buffers. Includes a payment-gate flag so the CEO admin can paste a
     video URL for a paid client and the download activates only when
     `client_paid = true`.

  ## New Tables

  ### aippie_partner_network
  - `id`                        uuid PK
  - `partner_token`             text UNIQUE NOT NULL — secure login token (hashed in production)
  - `company_name`              text NOT NULL
  - `contact_email`             text NOT NULL
  - `is_aippietax_internal_agent` boolean DEFAULT false — true = free access, false = must pay €199.99/mo
  - `client_paid`               boolean DEFAULT false — current client invoice paid status
  - `commission_eur`            numeric DEFAULT 0 — accumulated commission balance
  - `active_lead_description`   text DEFAULT '' — description of active lead/client
  - `b2b_billing_active`        boolean DEFAULT false — external billing subscription status
  - `created_at`                timestamptz DEFAULT now()
  - `updated_at`                timestamptz DEFAULT now()

  ### aippie_media_assets
  - `id`                uuid PK
  - `client_email`      text NOT NULL — identifies which paid client owns this asset
  - `asset_title`       text NOT NULL
  - `cloud_storage_url` text — external S3/GCS URL pasted by admin; NULL until uploaded
  - `asset_type`        text DEFAULT 'video' — 'video' | 'image' | 'document'
  - `client_paid`       boolean DEFAULT false — download only enabled when true
  - `watermark_enabled` boolean DEFAULT true — Aippie Media watermark wrapper
  - `uploaded_by_admin` boolean DEFAULT false — set true when CEO pastes URL
  - `created_at`        timestamptz DEFAULT now()
  - `updated_at`        timestamptz DEFAULT now()

  ## Security
  - RLS enabled on both tables
  - aippie_partner_network: partners authenticate via token (SELECT by token match)
  - aippie_media_assets: authenticated admin SELECT + client SELECT by email
*/

-- ── aippie_partner_network ───────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS aippie_partner_network (
  id                          uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
  partner_token               text        UNIQUE NOT NULL,
  company_name                text        NOT NULL DEFAULT '',
  contact_email               text        NOT NULL DEFAULT '',
  is_aippietax_internal_agent boolean     NOT NULL DEFAULT false,
  client_paid                 boolean     NOT NULL DEFAULT false,
  commission_eur              numeric     NOT NULL DEFAULT 0,
  active_lead_description     text        NOT NULL DEFAULT '',
  b2b_billing_active          boolean     NOT NULL DEFAULT false,
  created_at                  timestamptz NOT NULL DEFAULT now(),
  updated_at                  timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE aippie_partner_network ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Partners can read own record by token"
  ON aippie_partner_network FOR SELECT
  TO anon, authenticated
  USING (
    partner_token IS NOT NULL
    AND length(trim(partner_token)) >= 8
  );

CREATE POLICY "Authenticated users can update own partner record"
  ON aippie_partner_network FOR UPDATE
  TO authenticated
  USING   (partner_token IS NOT NULL AND length(trim(partner_token)) >= 8)
  WITH CHECK (partner_token IS NOT NULL AND length(trim(partner_token)) >= 8);

-- ── aippie_media_assets ──────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS aippie_media_assets (
  id                uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
  client_email      text        NOT NULL DEFAULT '',
  asset_title       text        NOT NULL DEFAULT '',
  cloud_storage_url text,
  asset_type        text        NOT NULL DEFAULT 'video'
                                CHECK (asset_type IN ('video', 'image', 'document')),
  client_paid       boolean     NOT NULL DEFAULT false,
  watermark_enabled boolean     NOT NULL DEFAULT true,
  uploaded_by_admin boolean     NOT NULL DEFAULT false,
  created_at        timestamptz NOT NULL DEFAULT now(),
  updated_at        timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE aippie_media_assets ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated users can read media assets"
  ON aippie_media_assets FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Anon can read own paid media asset by email"
  ON aippie_media_assets FOR SELECT
  TO anon
  USING (
    client_paid = true
    AND cloud_storage_url IS NOT NULL
    AND client_email IS NOT NULL
    AND length(trim(client_email)) > 3
  );

CREATE POLICY "Authenticated users can insert media assets"
  ON aippie_media_assets FOR INSERT
  TO authenticated
  WITH CHECK (
    client_email IS NOT NULL
    AND length(trim(client_email)) > 3
  );

CREATE POLICY "Authenticated users can update media assets"
  ON aippie_media_assets FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (
    client_email IS NOT NULL
    AND length(trim(client_email)) > 3
  );

-- ── Seed one demo partner for testing ────────────────────────────────────────
INSERT INTO aippie_partner_network
  (partner_token, company_name, contact_email, is_aippietax_internal_agent, client_paid, commission_eur, active_lead_description)
VALUES
  ('AIPPIE-INTERNAL-2024', 'AIPPIETAX S.A.', 'admin@aippietax.com', true, true, 1247.50, 'Costa del Sol Relocation Package — €499 Gold Bridge Roadmap'),
  ('PARTNER-DEMO-EXTERNAL', 'Nexum Real Estate B.V.', 'info@nexum.nl', false, false, 0.00, 'Relocation lead — Pending Stripe verification')
ON CONFLICT (partner_token) DO NOTHING;
