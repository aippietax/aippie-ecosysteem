-- Developer lifetime access bypass for elvin@aippietax.com and aippieai@gmail.com
-- Updates auth.users metadata directly so isSubscribed evaluates true in all components

UPDATE auth.users
SET raw_user_meta_data = raw_user_meta_data || jsonb_build_object(
  'is_subscribed', true,
  'subscription_type', 'lifetime',
  'subscription_status', 'active',
  'subscribed_until', '2099-12-31'
)
WHERE email IN ('elvin@aippietax.com', 'aippieai@gmail.com');
