/*
  # V178 — Aippie AI Academy Activations
  AIPPIETAX S.A. · Module 16 · Education Hub

  ## New Tables

  ### academy_activations
  Stores plan activation records for the Aippie AI Academy module.
  One row per activation event (B2C or B2B).

  Columns:
    - id           uuid PK
    - device_key   text — anonymous device identifier
    - plan_tier    text — 'b2c' | 'b2b'
    - token        text — generated session token (ACAD-XXXX-XXXX-XXXX)
    - card_last4   text — last 4 digits of payment card (masked)
    - status       text — 'active' | 'completed' | 'cancelled'
    - created_at   timestamptz

  ## Security
  RLS enabled with device_key ownership checks.
  Non-empty device_key required on all writes.
*/

CREATE TABLE IF NOT EXISTS academy_activations (
  id          uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
  device_key  text        NOT NULL DEFAULT '',
  plan_tier   text        NOT NULL DEFAULT 'b2c',
  token       text        NOT NULL DEFAULT '',
  card_last4  text        NOT NULL DEFAULT '',
  status      text        NOT NULL DEFAULT 'active',
  created_at  timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE academy_activations ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Require non-empty device_key on insert"
  ON academy_activations FOR INSERT
  TO anon, authenticated
  WITH CHECK (device_key IS NOT NULL AND device_key != '');

CREATE POLICY "Select own device_key rows"
  ON academy_activations FOR SELECT
  TO anon, authenticated
  USING (device_key IS NOT NULL AND device_key != '');

CREATE POLICY "Update own device_key rows"
  ON academy_activations FOR UPDATE
  TO anon, authenticated
  USING (device_key IS NOT NULL AND device_key != '')
  WITH CHECK (device_key IS NOT NULL AND device_key != '');

CREATE INDEX IF NOT EXISTS idx_academy_activations_device
  ON academy_activations (device_key, created_at DESC);
