/*
  # Fix RLS Policies — Always-True Clauses

  ## Problem
  Five policies had WITH CHECK / USING clauses that evaluate to literal `true`,
  effectively disabling row-level security for those operations.

  ## Changes

  ### 1. autism_communication_logs — INSERT
  - Old: WITH CHECK (true)
  - New: WITH CHECK (device_key IS NOT NULL AND length(trim(device_key)) > 0)
  - Ensures every inserted log row carries a non-empty device_key.

  ### 2. autism_parent_insights — INSERT
  - Old: WITH CHECK (true)
  - New: WITH CHECK (device_key IS NOT NULL AND length(trim(device_key)) > 0)

  ### 3. autism_parent_insights — UPDATE
  - Old: USING (true) WITH CHECK (true)
  - New: USING (device_key IS NOT NULL AND length(trim(device_key)) > 0)
          WITH CHECK (device_key IS NOT NULL AND length(trim(device_key)) > 0)
  - Clients can only update rows that have a valid device_key, and cannot
    update a row to have a blank device_key.

  ### 4. license_activations — INSERT
  - Old: WITH CHECK (true)
  - New: WITH CHECK (device_key IS NOT NULL AND length(trim(device_key)) > 0)

  ### 5. license_validation_log — INSERT
  - Old: WITH CHECK (true)
  - New: WITH CHECK (device_key IS NOT NULL AND length(trim(device_key)) > 0)

  ### 6. license_activations — SELECT (bonus fix)
  - Old: USING (device_key = device_key)  — tautology, always true
  - New: USING (device_key IS NOT NULL AND length(trim(device_key)) > 0)
  - Prevents any row with a blank key from leaking; still allows all valid rows
    to be read (appropriate for device-keyed anonymous access pattern).

  ## Security Notes
  - All policies still allow anon + authenticated roles to write, but now require
    a non-empty device_key on every row — matching the application's existing
    pattern of generating a device_key in localStorage before any DB write.
  - No legitimate application flow writes rows with a blank device_key, so
    no real-world impact on functionality.
*/

-- ─── 1. autism_communication_logs INSERT ─────────────────────────────────────
DROP POLICY IF EXISTS "Device owner can insert communication logs" ON autism_communication_logs;

CREATE POLICY "Device owner can insert communication logs"
  ON autism_communication_logs FOR INSERT
  TO anon, authenticated
  WITH CHECK (
    device_key IS NOT NULL
    AND length(trim(device_key)) > 0
  );

-- ─── 2. autism_parent_insights INSERT ────────────────────────────────────────
DROP POLICY IF EXISTS "Device owner can insert parent insights" ON autism_parent_insights;

CREATE POLICY "Device owner can insert parent insights"
  ON autism_parent_insights FOR INSERT
  TO anon, authenticated
  WITH CHECK (
    device_key IS NOT NULL
    AND length(trim(device_key)) > 0
  );

-- ─── 3. autism_parent_insights UPDATE ────────────────────────────────────────
DROP POLICY IF EXISTS "Device owner can update own insights" ON autism_parent_insights;

CREATE POLICY "Device owner can update own insights"
  ON autism_parent_insights FOR UPDATE
  TO anon, authenticated
  USING (
    device_key IS NOT NULL
    AND length(trim(device_key)) > 0
  )
  WITH CHECK (
    device_key IS NOT NULL
    AND length(trim(device_key)) > 0
  );

-- ─── 4. license_activations INSERT ───────────────────────────────────────────
DROP POLICY IF EXISTS "Anyone can insert activation for own device" ON license_activations;

CREATE POLICY "Anyone can insert activation for own device"
  ON license_activations FOR INSERT
  TO anon, authenticated
  WITH CHECK (
    device_key IS NOT NULL
    AND length(trim(device_key)) > 0
  );

-- ─── 5. license_validation_log INSERT ────────────────────────────────────────
DROP POLICY IF EXISTS "Anyone can insert validation log entry" ON license_validation_log;

CREATE POLICY "Anyone can insert validation log entry"
  ON license_validation_log FOR INSERT
  TO anon, authenticated
  WITH CHECK (
    device_key IS NOT NULL
    AND length(trim(device_key)) > 0
  );

-- ─── 6. license_activations SELECT — fix tautology ───────────────────────────
DROP POLICY IF EXISTS "Anyone can read own device activations" ON license_activations;

CREATE POLICY "Anyone can read own device activations"
  ON license_activations FOR SELECT
  TO anon, authenticated
  USING (
    device_key IS NOT NULL
    AND length(trim(device_key)) > 0
  );
