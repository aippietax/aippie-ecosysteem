-- Drop the overly permissive update policy that allowed any authenticated user
-- to update the lifetime_deal_slots counter row.
-- Updates are admin-only (service_role bypasses RLS), so no authenticated policy is needed.
DROP POLICY IF EXISTS "update_lifetime_slots" ON lifetime_deal_slots;
