/*
  # AippieTax Corporate Profile Manager — V85
  AIPPIETAX S.A.

  1. New Table: `aippietax_corporate_profiles`
     Stores the core corporate identity fields entered by each authenticated
     user in the AippieTax Client Portal. One row per user (upsert pattern).

     Columns:
       - id              (uuid, PK)
       - user_id         (uuid, FK → auth.users, UNIQUE)
       - business_name   (text) — legal registered company name
       - kvk_number      (text) — Dutch Chamber of Commerce / KVK number
       - btw_nif_number  (text) — VAT / BTW (NL) / NIF (ES) / EIN (US) identifier
       - iban             (text) — corporate IBAN for payroll & invoicing
       - updated_at      (timestamptz) — last profile save timestamp
       - created_at      (timestamptz)

  2. Security
     - RLS enabled: authenticated users can only read and write their own row.
     - Four separate policies (SELECT, INSERT, UPDATE, DELETE).

  3. Notes
     - Uses ON CONFLICT (user_id) DO UPDATE pattern for upserts from the UI.
     - No sensitive secrets are stored here — IBAN is for display / reference only.
*/

CREATE TABLE IF NOT EXISTS aippietax_corporate_profiles (
  id              uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id         uuid        NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  business_name   text        NOT NULL DEFAULT '',
  kvk_number      text        NOT NULL DEFAULT '',
  btw_nif_number  text        NOT NULL DEFAULT '',
  iban            text        NOT NULL DEFAULT '',
  updated_at      timestamptz NOT NULL DEFAULT now(),
  created_at      timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id)
);

ALTER TABLE aippietax_corporate_profiles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Owner can select own corporate profile"
  ON aippietax_corporate_profiles FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Owner can insert own corporate profile"
  ON aippietax_corporate_profiles FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Owner can update own corporate profile"
  ON aippietax_corporate_profiles FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Owner can delete own corporate profile"
  ON aippietax_corporate_profiles FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

CREATE INDEX IF NOT EXISTS idx_aippietax_corporate_profiles_user_id
  ON aippietax_corporate_profiles (user_id);
