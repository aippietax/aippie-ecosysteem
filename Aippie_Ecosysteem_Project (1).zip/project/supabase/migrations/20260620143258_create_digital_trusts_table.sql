CREATE TABLE IF NOT EXISTS digital_trusts (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id     uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  trust_name  text NOT NULL,
  apt_id      text UNIQUE NOT NULL,
  phone       text,
  full_name   text,
  country     text,
  vat_number  text,
  status      text DEFAULT 'active' CHECK (status IN ('active','suspended','expired')),
  created_at  timestamptz DEFAULT now(),
  expires_at  timestamptz
);

ALTER TABLE digital_trusts ENABLE ROW LEVEL SECURITY;

CREATE POLICY "select_own_trusts" ON digital_trusts FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

CREATE POLICY "insert_own_trusts" ON digital_trusts FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

CREATE POLICY "update_own_trusts" ON digital_trusts FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

CREATE POLICY "delete_own_trusts" ON digital_trusts FOR DELETE
  TO authenticated USING (auth.uid() = user_id);
