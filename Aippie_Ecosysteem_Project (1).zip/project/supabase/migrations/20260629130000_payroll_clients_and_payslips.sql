/*
  # Payroll clients + NL-specific employee fields + payslips

  ## Why
  AIPPIETAX acts as the payroll processor FOR other companies (e.g. Maria
  Electric B.V.), not just for itself. The existing payroll_employees table
  only linked an employee to the AIPPIETAX user_id — there was no concept of
  "which client company does this employee work for". This migration adds
  that missing layer plus the fields needed for a real, compliant Dutch
  loonstrook (BSN, loonheffingskorting toggle, IBAN for payout) and a table
  to store the generated payslip records themselves.

  ## New tables
  - `payroll_clients` — the company AIPPIETAX processes payroll for (e.g.
    Maria Electric B.V.). Owned by the AIPPIETAX user (accountant).
  - `payslips` — one row per employee per period, the actual generated
    payslip record (amounts + a reference to the rendered PDF if stored)

  ## Changes to payroll_employees
  - Add `client_id` (which client company this employee belongs to)
  - Add `bsn` (Dutch social security number — encrypted at rest is out of
    scope of SQL, handled at the application/storage layer; column is
    nullable since not all jurisdictions use BSN)
  - Add `apply_loonheffingskorting` (boolean, NL only — whether the general
    + labor tax credits apply at this employer; normally true for the main/
    only employer, false for a second job)
  - Add `iban` was already present in some variants — added IF NOT EXISTS
    to be safe

  ## Security
  - All new tables use RLS scoped to the AIPPIETAX accountant's auth.uid()
  - Employees never get their own login in this version — they receive
    their payslip by PDF/email, they don't query Supabase directly
*/

CREATE TABLE IF NOT EXISTS payroll_clients (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id      uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  company_name text NOT NULL,
  jurisdiction text NOT NULL DEFAULT 'NL' CHECK (jurisdiction IN ('ES','NL','US')),
  tax_id       text,              -- e.g. KVK/BTW number for NL, NIF for ES
  contact_email text,
  active       boolean DEFAULT true,
  created_at   timestamptz DEFAULT now()
);

ALTER TABLE payroll_clients ENABLE ROW LEVEL SECURITY;

CREATE POLICY "select_own_clients" ON payroll_clients
  FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "insert_own_clients" ON payroll_clients
  FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "update_own_clients" ON payroll_clients
  FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE POLICY "delete_own_clients" ON payroll_clients
  FOR DELETE TO authenticated USING (auth.uid() = user_id);

-- ── Extend payroll_employees with client link + NL-specific fields ──────────
ALTER TABLE payroll_employees
  ADD COLUMN IF NOT EXISTS client_id uuid REFERENCES payroll_clients(id) ON DELETE CASCADE,
  ADD COLUMN IF NOT EXISTS bsn text,
  ADD COLUMN IF NOT EXISTS apply_loonheffingskorting boolean DEFAULT true,
  ADD COLUMN IF NOT EXISTS iban text;

CREATE INDEX IF NOT EXISTS payroll_employees_client_id_idx ON payroll_employees (client_id);

-- ── Payslips: the actual generated record per employee per period ──────────
CREATE TABLE IF NOT EXISTS payslips (
  id                  uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id             uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  client_id           uuid REFERENCES payroll_clients(id) ON DELETE CASCADE,
  employee_id         uuid REFERENCES payroll_employees(id) ON DELETE CASCADE,
  period              text NOT NULL,         -- e.g. '2026-06'
  gross_salary        numeric(12,2) NOT NULL,
  loonheffing_pct     numeric(6,4) NOT NULL,
  loonheffing_amount  numeric(12,2) NOT NULL,
  aof_premium_amount  numeric(12,2) NOT NULL,
  pension_amount      numeric(12,2) NOT NULL,
  net_salary          numeric(12,2) NOT NULL,
  currency            text DEFAULT 'EUR',
  pdf_path            text,                  -- storage path once a PDF is generated
  status              text DEFAULT 'draft' CHECK (status IN ('draft','finalized','paid')),
  created_at          timestamptz DEFAULT now(),
  UNIQUE (employee_id, period)
);

ALTER TABLE payslips ENABLE ROW LEVEL SECURITY;

CREATE POLICY "select_own_payslips" ON payslips
  FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "insert_own_payslips" ON payslips
  FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "update_own_payslips" ON payslips
  FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE POLICY "delete_own_payslips" ON payslips
  FOR DELETE TO authenticated USING (auth.uid() = user_id);
