/*
  # Upgrade subscriptions to multi-tier plan system

  ## Summary
  Upgrades the existing subscriptions table to support three distinct client tiers
  and adds a client_usage table for real-time minute tracking and overage billing.

  ## Plan tiers
  - TURISTA_BASIC:    €14.99/mo — 40 included minutes, €0.50/min overage
  - CORPORATE_B2B:   €79.99/mo — 200 included minutes, €0.50/min overage
  - PREMIUM_JURADO:  €29.99/mo — 60 included minutes, certified court/notary, €0.50/min overage

  ## Changes to subscriptions
  - Add `plan_tier` column: 'turista_basic' | 'corporate_b2b' | 'premium_jurado'
  - Add `included_minutes` column: minutes bundled in the plan
  - Add `overage_rate` column: cost per minute beyond included (€0.50)
  - Existing rows default to 'turista_basic'

  ## New table: client_usage
  Tracks per-user minute consumption per month for overage calculation.
    - `id` (uuid, PK)
    - `user_id` (uuid, FK auth.users)
    - `month_start` (date)
    - `minutes_used` (numeric) — cumulative minutes this month
    - `overage_minutes` (numeric, generated) — max(0, minutes_used - included_minutes)
    - `updated_at` (timestamptz)

  ## Security
  - RLS on client_usage: users can only read/write their own rows
*/

-- ── Add tier columns to subscriptions ────────────────────────────────────────

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'subscriptions' AND column_name = 'plan_tier'
  ) THEN
    ALTER TABLE subscriptions
      ADD COLUMN plan_tier       text NOT NULL DEFAULT 'turista_basic'
                                   CHECK (plan_tier IN ('turista_basic','corporate_b2b','premium_jurado')),
      ADD COLUMN included_minutes integer NOT NULL DEFAULT 40,
      ADD COLUMN overage_rate    numeric(6,4) NOT NULL DEFAULT 0.50;
  END IF;
END $$;

-- ── client_usage ──────────────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS client_usage (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id         uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  month_start     date NOT NULL DEFAULT date_trunc('month', now())::date,
  minutes_used    numeric(10,4) NOT NULL DEFAULT 0,
  updated_at      timestamptz DEFAULT now(),
  UNIQUE(user_id, month_start)
);

ALTER TABLE client_usage ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own usage"
  ON client_usage FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own usage"
  ON client_usage FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own usage"
  ON client_usage FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE INDEX IF NOT EXISTS idx_client_usage_user_month
  ON client_usage(user_id, month_start);
