/*
  # Create admin_config table

  1. New Tables
    - `admin_config`
      - `key` (text, primary key) — config key name
      - `value` (text) — encrypted/opaque value
      - `description` (text) — human-readable note for operators
      - `updated_at` (timestamptz)

  2. Security
    - Enable RLS on `admin_config`
    - NO policies for authenticated or anon roles — only service_role
      can read or write this table (service_role bypasses RLS entirely)
    - This means no client-side code can ever query this table directly

  3. Seed
    - Insert the admin_phone routing key with a placeholder value.
      The real value must be set server-side via the service_role client
      or a secure migration script — never through the frontend.

  4. Important notes
    - VITE_ env vars are baked into the client bundle at build time.
      For the phone number we accept this for the routing hint that is
      sent to the WebRTC edge function, but the canonical source of
      truth for the number lives here, read only by server-side code.
    - Rotate the value here when the number changes; no redeploy needed.
*/

CREATE TABLE IF NOT EXISTS admin_config (
  key         text PRIMARY KEY,
  value       text NOT NULL DEFAULT '',
  description text NOT NULL DEFAULT '',
  updated_at  timestamptz DEFAULT now()
);

ALTER TABLE admin_config ENABLE ROW LEVEL SECURITY;

-- Intentionally no SELECT/INSERT/UPDATE/DELETE policies.
-- Only service_role (used by Edge Functions) can access this table.

INSERT INTO admin_config (key, value, description)
VALUES (
  'admin_routing_phone',
  'SET_VIA_SERVICE_ROLE',
  'Primary admin phone for WebRTC call routing. Update value via service_role only — never from the client.'
)
ON CONFLICT (key) DO NOTHING;
