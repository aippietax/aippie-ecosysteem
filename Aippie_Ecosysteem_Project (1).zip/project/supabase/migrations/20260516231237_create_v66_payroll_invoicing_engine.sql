/*
  # V66 — Multi-Jurisdiction Payroll & Invoicing Engine
  ## AIPPIETAX S.A.

  ### New Tables

  1. **payroll_entries**
     - Full multi-jurisdiction salary matrix (Spain IRPF, Netherlands Loonheffing, USA Federal/State)
     - Gross / net calculation columns, employer + employee contribution breakdowns
     - `jurisdiction` column with CHECK constraint: 'ES' | 'NL' | 'US' | 'GLOBAL'
     - `pay_frequency`: 'monthly' | 'bi-weekly' | 'weekly'
     - `compliance_type`: 'nomina_es' | 'payslip_nl' | 'w2_us' | '1099_us'
     - Persisted to `aippietax_receipt_ledger` via application logic

  2. **invoices**
     - Global multi-currency invoice ledger (EUR, USD, GBP, CHF, SEK, CAD, AUD)
     - Verifactu cryptographic chaining fields: `chain_hash`, `prev_hash`, `qr_code_payload`
     - Sequential invoice numbering per jurisdiction
     - Exchange rate snapshot at issuance
     - `invoice_status`: 'draft' | 'issued' | 'sent' | 'paid' | 'overdue' | 'cancelled'

  ### Security
  - RLS enabled on both tables
  - Policies keyed on `device_key` for anonymous access (matches existing pattern)

  ### Indexes
  - `payroll_entries(device_key, jurisdiction, pay_period_end)` — monthly payroll queries
  - `invoices(device_key, jurisdiction, issued_at)` — invoice history queries
  - `invoices(chain_hash)` — Verifactu chain integrity lookups
*/

-- ── payroll_entries ─────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS payroll_entries (
  id                        uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  device_key                text NOT NULL,
  user_id                   uuid REFERENCES auth.users(id) ON DELETE SET NULL,

  -- Identity
  employee_name             text NOT NULL DEFAULT '',
  employee_id_ref           text NOT NULL DEFAULT '',
  company_name              text NOT NULL DEFAULT '',
  company_tax_id            text NOT NULL DEFAULT '',   -- NIF/CUIT/EIN/CoC

  -- Jurisdiction
  jurisdiction              text NOT NULL DEFAULT 'ES'
                              CHECK (jurisdiction IN ('ES','NL','US','GLOBAL')),
  compliance_type           text NOT NULL DEFAULT 'nomina_es'
                              CHECK (compliance_type IN ('nomina_es','payslip_nl','w2_us','1099_us','global')),

  -- Salary
  pay_period_start          date NOT NULL,
  pay_period_end            date NOT NULL,
  pay_frequency             text NOT NULL DEFAULT 'monthly'
                              CHECK (pay_frequency IN ('monthly','bi-weekly','weekly')),
  gross_salary              numeric(14,2) NOT NULL DEFAULT 0,
  currency                  text NOT NULL DEFAULT 'EUR',
  exchange_rate_to_eur      numeric(14,6) NOT NULL DEFAULT 1.0,

  -- Spain IRPF tier
  irpf_pct                  numeric(6,4) DEFAULT 0,
  irpf_withheld             numeric(14,2) DEFAULT 0,
  ss_employee_pct           numeric(6,4) DEFAULT 0.0628,   -- 6.28%
  ss_employee_amount        numeric(14,2) DEFAULT 0,
  ss_employer_pct           numeric(6,4) DEFAULT 0.2360,   -- 23.60%
  ss_employer_amount        numeric(14,2) DEFAULT 0,

  -- Netherlands Loonheffing tier
  loonheffing_pct           numeric(6,4) DEFAULT 0,
  loonheffing_amount        numeric(14,2) DEFAULT 0,
  aof_premium_pct           numeric(6,4) DEFAULT 0.0056,   -- AOF 0.56%
  aof_premium_amount        numeric(14,2) DEFAULT 0,
  pension_pct               numeric(6,4) DEFAULT 0.055,    -- 5.5% employee
  pension_amount            numeric(14,2) DEFAULT 0,

  -- USA Federal/State tier
  federal_income_tax_pct    numeric(6,4) DEFAULT 0,
  federal_income_tax        numeric(14,2) DEFAULT 0,
  state_income_tax_pct      numeric(6,4) DEFAULT 0,
  state_income_tax          numeric(14,2) DEFAULT 0,
  fica_ss_pct               numeric(6,4) DEFAULT 0.062,    -- 6.2% Social Security
  fica_ss_amount            numeric(14,2) DEFAULT 0,
  fica_medicare_pct         numeric(6,4) DEFAULT 0.0145,   -- 1.45% Medicare
  fica_medicare_amount      numeric(14,2) DEFAULT 0,
  state_code                text DEFAULT '',               -- e.g. 'CA','TX','NY'

  -- Net
  total_deductions          numeric(14,2) NOT NULL DEFAULT 0,
  net_salary                numeric(14,2) NOT NULL DEFAULT 0,

  -- Metadata
  notes                     text DEFAULT '',
  e2ee_encrypted            boolean DEFAULT true,
  created_at                timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_payroll_entries_device_key
  ON payroll_entries(device_key, jurisdiction, pay_period_end DESC);

ALTER TABLE payroll_entries ENABLE ROW LEVEL SECURITY;

CREATE POLICY "payroll_entries_select"
  ON payroll_entries FOR SELECT
  TO anon, authenticated
  USING (device_key = current_setting('app.device_key', true));

CREATE POLICY "payroll_entries_insert"
  ON payroll_entries FOR INSERT
  TO anon, authenticated
  WITH CHECK (device_key = current_setting('app.device_key', true));

CREATE POLICY "payroll_entries_update"
  ON payroll_entries FOR UPDATE
  TO anon, authenticated
  USING (device_key = current_setting('app.device_key', true))
  WITH CHECK (device_key = current_setting('app.device_key', true));


-- ── invoices ────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS invoices (
  id                        uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  device_key                text NOT NULL,
  user_id                   uuid REFERENCES auth.users(id) ON DELETE SET NULL,

  -- Sequential numbering per jurisdiction
  invoice_number            text NOT NULL DEFAULT '',
  jurisdiction              text NOT NULL DEFAULT 'ES'
                              CHECK (jurisdiction IN ('ES','NL','US','GLOBAL')),

  -- Parties
  issuer_name               text NOT NULL DEFAULT '',
  issuer_tax_id             text NOT NULL DEFAULT '',
  client_name               text NOT NULL DEFAULT '',
  client_tax_id             text NOT NULL DEFAULT '',
  client_country            text NOT NULL DEFAULT 'ES',

  -- Currency & amounts
  currency                  text NOT NULL DEFAULT 'EUR'
                              CHECK (currency IN ('EUR','USD','GBP','CHF','SEK','CAD','AUD','JPY')),
  exchange_rate_to_eur      numeric(14,6) NOT NULL DEFAULT 1.0,
  subtotal                  numeric(14,2) NOT NULL DEFAULT 0,
  vat_pct                   numeric(6,4) NOT NULL DEFAULT 0.21,
  vat_amount                numeric(14,2) NOT NULL DEFAULT 0,
  total_amount              numeric(14,2) NOT NULL DEFAULT 0,
  total_eur                 numeric(14,2) NOT NULL DEFAULT 0,

  -- Line items snapshot (JSONB)
  line_items                jsonb DEFAULT '[]'::jsonb,

  -- Status
  invoice_status            text NOT NULL DEFAULT 'draft'
                              CHECK (invoice_status IN ('draft','issued','sent','paid','overdue','cancelled')),
  issued_at                 timestamptz,
  due_date                  date,
  paid_at                   timestamptz,

  -- Verifactu cryptographic chain (Spain)
  verifactu_enabled         boolean DEFAULT false,
  chain_hash                text DEFAULT '',
  prev_hash                 text DEFAULT '',
  qr_code_payload           text DEFAULT '',
  hacienda_transmitted      boolean DEFAULT false,
  hacienda_ref              text DEFAULT '',

  -- Metadata
  notes                     text DEFAULT '',
  e2ee_encrypted            boolean DEFAULT true,
  created_at                timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_invoices_device_key
  ON invoices(device_key, jurisdiction, issued_at DESC);

CREATE INDEX IF NOT EXISTS idx_invoices_chain_hash
  ON invoices(chain_hash) WHERE chain_hash != '';

ALTER TABLE invoices ENABLE ROW LEVEL SECURITY;

CREATE POLICY "invoices_select"
  ON invoices FOR SELECT
  TO anon, authenticated
  USING (device_key = current_setting('app.device_key', true));

CREATE POLICY "invoices_insert"
  ON invoices FOR INSERT
  TO anon, authenticated
  WITH CHECK (device_key = current_setting('app.device_key', true));

CREATE POLICY "invoices_update"
  ON invoices FOR UPDATE
  TO anon, authenticated
  USING (device_key = current_setting('app.device_key', true))
  WITH CHECK (device_key = current_setting('app.device_key', true));
