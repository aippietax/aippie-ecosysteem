/*
  # Create aippie_silent_voice_channels table

  ## Summary
  MedTech assistive communication ledger for the AippieSilentVoice module.
  Each row records a gesture detection event: the recognized gesture label,
  confidence score, synthesized speech output, language, and session metadata.
  Used to log all computer-vision gesture translation events from non-verbal users.

  ## New Table: aippie_silent_voice_channels
  - `id`              uuid PK
  - `session_id`      text — client-generated session UUID grouping events
  - `device_key`      text — anonymous device identifier (no PII)
  - `gesture_label`   text — recognized gesture name e.g. "Open Palm", "Peace Sign"
  - `confidence_pct`  numeric — match confidence 0.0–100.0
  - `speech_output`   text — synthesized phrase fired to device speaker
  - `lang_code`       text — language token e.g. 'en', 'nl', 'de'
  - `landmark_hash`   text nullable — serialized 21-point skeleton vector hash
  - `created_at`      timestamptz

  ## Security
  - RLS enabled
  - Anonymous inserts allowed (assistive tech — no auth required for logging)
  - Reads restricted to authenticated users only (admin review)
*/

CREATE TABLE IF NOT EXISTS aippie_silent_voice_channels (
  id             uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
  session_id     text        NOT NULL DEFAULT '',
  device_key     text        NOT NULL DEFAULT '',
  gesture_label  text        NOT NULL DEFAULT '',
  confidence_pct numeric     NOT NULL DEFAULT 0 CHECK (confidence_pct >= 0 AND confidence_pct <= 100),
  speech_output  text        NOT NULL DEFAULT '',
  lang_code      text        NOT NULL DEFAULT 'en',
  landmark_hash  text,
  created_at     timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE aippie_silent_voice_channels ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can insert gesture log"
  ON aippie_silent_voice_channels FOR INSERT
  TO anon, authenticated
  WITH CHECK (true);

CREATE POLICY "Authenticated users can read gesture logs"
  ON aippie_silent_voice_channels FOR SELECT
  TO authenticated
  USING (true);
