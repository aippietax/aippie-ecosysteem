-- Profile picture (base64 stored in DB, only viewable with PIN)
ALTER TABLE secure_chat_pins
  ADD COLUMN IF NOT EXISTS avatar_url   TEXT DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS country_code TEXT DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS country_name TEXT DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS ad_text      TEXT DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS ad_enabled   BOOLEAN NOT NULL DEFAULT FALSE;

-- RLS: allow authenticated users to update their own avatar/ad/location
CREATE POLICY "update_own_pin_profile" ON secure_chat_pins
  FOR UPDATE TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);
