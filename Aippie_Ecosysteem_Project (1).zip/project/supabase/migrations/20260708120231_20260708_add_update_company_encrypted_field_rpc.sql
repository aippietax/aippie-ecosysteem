/*
# Add update_company_encrypted_field RPC helper

## Summary
Creates a SECURITY DEFINER stored procedure that accepts a plaintext value,
encrypts it with pgp_sym_encrypt (AES-256 via pgcrypto), and writes the
resulting BYTEA to the specified column on public.companies.

This enables the enterprise-onboarding edge function to perform field-level
encryption without exposing the passphrase to the JavaScript layer or
constructing raw SQL strings client-side.

## New Function

### update_company_encrypted_field(p_company_id, p_column, p_plaintext, p_passphrase)
- Accepts company UUID, target column name, plaintext value, and passphrase
- Uses pgp_sym_encrypt to produce BYTEA ciphertext
- Writes ciphertext to the named column via dynamic SQL (EXECUTE)
- Column name is validated against an allowlist to prevent SQL injection
- Returns void; raises exception if column name is not permitted

## Security
- SECURITY DEFINER runs with elevated privileges (bypasses RLS for the update)
- Column allowlist prevents any possibility of injection via p_column parameter
- REVOKE PUBLIC execute; GRANT only to authenticated + service_role
*/

CREATE OR REPLACE FUNCTION public.update_company_encrypted_field(
  p_company_id  uuid,
  p_column      text,
  p_plaintext   text,
  p_passphrase  text
) RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  allowed_columns text[] := ARRAY[
    'iban_encrypted',
    'bic_swift_encrypted',
    'bank_api_config_encrypted',
    'pfx_certificate_encrypted',
    'pfx_password_encrypted'
  ];
BEGIN
  -- Allowlist check — prevents SQL injection via column name parameter
  IF NOT (p_column = ANY(allowed_columns)) THEN
    RAISE EXCEPTION 'Column % is not permitted for encrypted update', p_column;
  END IF;

  EXECUTE format(
    'UPDATE public.companies SET %I = pgp_sym_encrypt($1, $2), updated_at = now() WHERE id = $3',
    p_column
  ) USING p_plaintext, p_passphrase, p_company_id;
END;
$$;

REVOKE ALL ON FUNCTION public.update_company_encrypted_field(uuid, text, text, text) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.update_company_encrypted_field(uuid, text, text, text) TO authenticated;
GRANT EXECUTE ON FUNCTION public.update_company_encrypted_field(uuid, text, text, text) TO service_role;
