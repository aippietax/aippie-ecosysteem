/*
  # Translator profiles, KYC verification, and earnings tracking

  1. New Tables

    ## translator_profiles
    Stores KYC status and bank payout details for each interpreter.
    Sensitive fields (IBAN, BIC) are stored here; only the owning user
    and service_role can read them.
      - `id` (uuid, PK)
      - `user_id` (uuid, unique FK → auth.users)
      - `full_name` (text)
      - `iban` (text)
      - `bic` (text)
      - `country` (text)
      - `kyc_status` (text) — 'pending' | 'verified' | 'rejected'
      - `submitted_at` (timestamptz, nullable)
      - `verified_at` (timestamptz, nullable)
      - `created_at` (timestamptz)

    ## call_minutes
    One row per completed call segment; used to calculate earnings.
      - `id` (uuid, PK)
      - `call_request_id` (uuid, FK → call_requests)
      - `translator_user_id` (uuid, FK → auth.users)
      - `minutes` (numeric) — fractional minutes spoken
      - `rate_per_minute` (numeric) — locked at time of call (€0.25)
      - `earned` (numeric, generated) — minutes × rate_per_minute
      - `month_start` (date) — first day of the call month, for grouping
      - `created_at` (timestamptz)

  2. Security (RLS)

    translator_profiles:
      - Translators can INSERT and SELECT their own row
      - Translators can UPDATE their own row (to resubmit)
      - No other roles can read (not even other authenticated users)

    call_minutes:
      - Translators can INSERT their own rows
      - Translators can SELECT their own rows (earnings dashboard)

  3. Important notes
    - kyc_status starts as 'pending' on first submit; an admin (service_role)
      flips it to 'verified'. For this MVP we auto-verify on submit.
    - Next payout date is always the 1st of the following month, computed
      in the frontend.
    - rate_per_minute is stored per-row so future rate changes don't
      retroactively affect historical earnings.
*/

-- ── translator_profiles ───────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS translator_profiles (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id      uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name    text NOT NULL DEFAULT '',
  iban         text NOT NULL DEFAULT '',
  bic          text NOT NULL DEFAULT '',
  country      text NOT NULL DEFAULT '',
  kyc_status   text NOT NULL DEFAULT 'pending'
                 CHECK (kyc_status IN ('pending','verified','rejected')),
  submitted_at timestamptz,
  verified_at  timestamptz,
  created_at   timestamptz DEFAULT now(),
  UNIQUE(user_id)
);

ALTER TABLE translator_profiles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Translators can view own profile"
  ON translator_profiles FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Translators can insert own profile"
  ON translator_profiles FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Translators can update own profile"
  ON translator_profiles FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- ── call_minutes ──────────────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS call_minutes (
  id                  uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  call_request_id     uuid REFERENCES call_requests(id) ON DELETE SET NULL,
  translator_user_id  uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  minutes             numeric(10,4) NOT NULL DEFAULT 0,
  rate_per_minute     numeric(10,4) NOT NULL DEFAULT 0.25,
  earned              numeric(10,4) GENERATED ALWAYS AS (minutes * rate_per_minute) STORED,
  month_start         date NOT NULL DEFAULT date_trunc('month', now())::date,
  created_at          timestamptz DEFAULT now()
);

ALTER TABLE call_minutes ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Translators can insert own minutes"
  ON call_minutes FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = translator_user_id);

CREATE POLICY "Translators can view own minutes"
  ON call_minutes FOR SELECT
  TO authenticated
  USING (auth.uid() = translator_user_id);

-- ── indexes ───────────────────────────────────────────────────────────────────

CREATE INDEX IF NOT EXISTS idx_call_minutes_translator_month
  ON call_minutes(translator_user_id, month_start);

CREATE INDEX IF NOT EXISTS idx_translator_profiles_user
  ON translator_profiles(user_id);
