
-- Add alpaca to allowed brokers
ALTER TABLE trading_broker_connections
  DROP CONSTRAINT IF EXISTS trading_broker_connections_broker_check;

ALTER TABLE trading_broker_connections
  ADD CONSTRAINT trading_broker_connections_broker_check
  CHECK (broker IN (
    'binance','bybit','alpaca',
    'interactive_brokers','degiro','trade_republic','revolut'
  ));

-- Secure secrets vault: stores actual API keys, only readable by service_role
CREATE TABLE IF NOT EXISTS broker_secrets (
  id           UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id      UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  broker       TEXT NOT NULL CHECK (broker IN ('binance','bybit','alpaca')),
  api_key      TEXT NOT NULL,
  api_secret   TEXT NOT NULL,
  mode         TEXT NOT NULL DEFAULT 'paper' CHECK (mode IN ('paper','live')),
  created_at   TIMESTAMPTZ DEFAULT NOW(),
  updated_at   TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE (user_id, broker)
);

ALTER TABLE broker_secrets ENABLE ROW LEVEL SECURITY;

-- Users can insert/update/delete their own secrets
CREATE POLICY "broker_secrets_insert" ON broker_secrets
  FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);

CREATE POLICY "broker_secrets_update" ON broker_secrets
  FOR UPDATE TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "broker_secrets_delete" ON broker_secrets
  FOR DELETE TO authenticated USING (auth.uid() = user_id);

-- No SELECT policy for authenticated role — only service_role (edge function) can read full secrets
-- Users verify connection status via trading_broker_connections (which has api_key_hint)
