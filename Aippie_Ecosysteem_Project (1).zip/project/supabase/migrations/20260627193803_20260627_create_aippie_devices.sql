CREATE TABLE IF NOT EXISTS aippie_devices (
  device_id            text PRIMARY KEY,
  user_id              text NOT NULL,
  battery_level        integer NOT NULL DEFAULT 100,
  is_kiosk_locked      boolean NOT NULL DEFAULT true,
  system_version       text NOT NULL DEFAULT '',
  last_seen            timestamptz NOT NULL DEFAULT now(),
  dead_hand_triggered  boolean NOT NULL DEFAULT false,
  dead_hand_reason     text NULL,
  dead_hand_at         timestamptz NULL
);

ALTER TABLE aippie_devices ENABLE ROW LEVEL SECURITY;

CREATE POLICY "select_own_devices" ON aippie_devices FOR SELECT
  TO authenticated USING (auth.uid()::text = user_id);

CREATE POLICY "insert_own_devices" ON aippie_devices FOR INSERT
  TO authenticated WITH CHECK (auth.uid()::text = user_id);

CREATE POLICY "update_own_devices" ON aippie_devices FOR UPDATE
  TO authenticated USING (auth.uid()::text = user_id) WITH CHECK (auth.uid()::text = user_id);

CREATE POLICY "delete_own_devices" ON aippie_devices FOR DELETE
  TO authenticated USING (auth.uid()::text = user_id);
