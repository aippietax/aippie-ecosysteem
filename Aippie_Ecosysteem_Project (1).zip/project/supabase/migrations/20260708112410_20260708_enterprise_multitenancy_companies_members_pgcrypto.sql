/*
# Enterprise Multi-Tenancy — Companies, Members, and Encrypted Credentials

## Summary
Adds full B2B multi-tenancy support to AIPPIE AIOS. A single authenticated user
can belong to one or more companies, with strict tenant isolation enforced at the
database level via Row Level Security. Sensitive credentials (bank API tokens,
digital certificates) are stored as pgcrypto-encrypted ciphertext — the plaintext
never leaves the server-side edge function.

## New Extensions
- `pgcrypto` — enables `pgp_sym_encrypt` / `pgp_sym_decrypt` for symmetric
  AES/Blowfish encryption of sensitive credential fields.

## New Tables

### aippie_companies
Central registry for B2B corporate tenants.
- `id` (uuid, PK)
- `company_name` (varchar 255, not null)
- `duns_number` (varchar 9, nullable) — 9-digit Dun & Bradstreet identifier
- `encrypted_bank_credentials` (text) — pgcrypto-encrypted bank API config JSON
- `encrypted_aeat_certificate` (text) — pgcrypto-encrypted .pfx/.p12 base64 blob
- `country_code` (char 2, default 'ES') — ISO 3166-1 alpha-2
- `vat_number` (text) — EU VAT / NIF / BTW number
- `onboarding_step` (int, default 0) — wizard progress (0–4)
- `onboarding_complete` (bool, default false)
- `created_at` (timestamptz)
- `updated_at` (timestamptz)

### aippie_company_members
Maps authenticated users to companies with a role.
Used as the trust anchor for all RLS membership checks.
- `id` (uuid, PK)
- `company_id` (uuid, FK aippie_companies, CASCADE)
- `user_id` (uuid, FK auth.users, CASCADE) — DEFAULT auth.uid()
- `role` (text) — 'admin' | 'member' | 'viewer'
- `created_at` (timestamptz)
- UNIQUE(company_id, user_id) — one membership row per pair

## Modified Tables
- `aippie_shared_context` — adds `company_id` (nullable FK → aippie_companies)
- `aippie_boardroom_meetings` — adds `company_id` (nullable FK → aippie_companies)
- `aippie_emperor_briefings` — adds `company_id` (nullable FK → aippie_companies)

## Security
- RLS enabled on `aippie_companies` and `aippie_company_members`.
- Companies: users can only SELECT/UPDATE companies they are members of
  (checked via aippie_company_members). Any authenticated user can INSERT
  a new company (they become the owner/admin).
- Members: users can SELECT their own membership rows; INSERT limited to
  authenticated users creating a membership for themselves; no client-side DELETE.
- The `profiles` table referenced in the prompt spec does not exist in this
  schema — `aippie_company_members` is the correct join table for membership checks.
- Encryption key is stored ONLY as the Supabase secret COMPANY_CREDENTIALS_KEY
  and is never exposed client-side. pgcrypto symmetric encryption happens
  exclusively inside the enterprise-onboarding edge function.

## Important Notes
1. The `company_id` columns on shared_context, boardroom_meetings, and
   emperor_briefings are NULLABLE so existing personal (non-company) rows
   are unaffected. Corporate rows will have company_id set.
2. Cross-tenant isolation: RLS on aippie_companies uses EXISTS on
   aippie_company_members so users in company A can NEVER read company B data.
3. Encryption passphrase rotation requires re-encrypting all ciphertext rows —
   plan a key rotation procedure before going to production.
*/

-- ─── Extensions ──────────────────────────────────────────────────────────────
CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- ─── aippie_companies ────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS aippie_companies (
  id                        uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_name              varchar(255) NOT NULL,
  duns_number               varchar(9),
  encrypted_bank_credentials text,
  encrypted_aeat_certificate  text,
  country_code              char(2)  NOT NULL DEFAULT 'ES',
  vat_number                text,
  onboarding_step           int      NOT NULL DEFAULT 0,
  onboarding_complete       boolean  NOT NULL DEFAULT false,
  created_at                timestamptz DEFAULT now(),
  updated_at                timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_companies_name ON aippie_companies(company_name);

ALTER TABLE aippie_companies ENABLE ROW LEVEL SECURITY;

-- Updated_at trigger
CREATE OR REPLACE FUNCTION update_company_timestamp()
RETURNS TRIGGER LANGUAGE plpgsql SECURITY INVOKER SET search_path = ''
AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END;
$$;

DROP TRIGGER IF EXISTS trg_company_updated_at ON aippie_companies;
CREATE TRIGGER trg_company_updated_at
  BEFORE UPDATE ON aippie_companies
  FOR EACH ROW EXECUTE FUNCTION update_company_timestamp();

-- ─── aippie_company_members ───────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS aippie_company_members (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id  uuid NOT NULL REFERENCES aippie_companies(id) ON DELETE CASCADE,
  user_id     uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  role        text NOT NULL DEFAULT 'admin'
                CHECK (role IN ('admin','member','viewer')),
  created_at  timestamptz DEFAULT now(),
  UNIQUE(company_id, user_id)
);

CREATE INDEX IF NOT EXISTS idx_company_members_user_id    ON aippie_company_members(user_id);
CREATE INDEX IF NOT EXISTS idx_company_members_company_id ON aippie_company_members(company_id);

ALTER TABLE aippie_company_members ENABLE ROW LEVEL SECURITY;

-- ─── RLS: aippie_companies ────────────────────────────────────────────────────
DROP POLICY IF EXISTS "select_member_companies"  ON aippie_companies;
CREATE POLICY "select_member_companies" ON aippie_companies FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM aippie_company_members m
      WHERE m.company_id = id AND m.user_id = auth.uid()
    )
  );

DROP POLICY IF EXISTS "insert_new_company" ON aippie_companies;
CREATE POLICY "insert_new_company" ON aippie_companies FOR INSERT
  TO authenticated
  WITH CHECK (true);

DROP POLICY IF EXISTS "update_admin_company" ON aippie_companies;
CREATE POLICY "update_admin_company" ON aippie_companies FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM aippie_company_members m
      WHERE m.company_id = id AND m.user_id = auth.uid()
        AND m.role = 'admin'
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM aippie_company_members m
      WHERE m.company_id = id AND m.user_id = auth.uid()
        AND m.role = 'admin'
    )
  );

-- ─── RLS: aippie_company_members ─────────────────────────────────────────────
DROP POLICY IF EXISTS "select_own_membership"  ON aippie_company_members;
CREATE POLICY "select_own_membership" ON aippie_company_members FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

DROP POLICY IF EXISTS "insert_own_membership" ON aippie_company_members;
CREATE POLICY "insert_own_membership" ON aippie_company_members FOR INSERT
  TO authenticated
  WITH CHECK (user_id = auth.uid());

-- ─── Alter existing tables: add company_id column ────────────────────────────
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema = 'public'
      AND table_name   = 'aippie_shared_context'
      AND column_name  = 'company_id'
  ) THEN
    ALTER TABLE aippie_shared_context
      ADD COLUMN company_id uuid REFERENCES aippie_companies(id) ON DELETE CASCADE;
  END IF;
END $$;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema = 'public'
      AND table_name   = 'aippie_boardroom_meetings'
      AND column_name  = 'company_id'
  ) THEN
    ALTER TABLE aippie_boardroom_meetings
      ADD COLUMN company_id uuid REFERENCES aippie_companies(id) ON DELETE CASCADE;
  END IF;
END $$;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema = 'public'
      AND table_name   = 'aippie_emperor_briefings'
      AND column_name  = 'company_id'
  ) THEN
    ALTER TABLE aippie_emperor_briefings
      ADD COLUMN company_id uuid REFERENCES aippie_companies(id) ON DELETE CASCADE;
  END IF;
END $$;
