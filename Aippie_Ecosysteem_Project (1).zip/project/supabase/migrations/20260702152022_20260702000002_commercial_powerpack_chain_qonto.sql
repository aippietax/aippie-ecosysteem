
-- Verifactu chain (CREATE IF NOT EXISTS, skip policies if exist)
CREATE TABLE IF NOT EXISTS public.verifactu_chain (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id       uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  block_index   bigint NOT NULL,
  prev_hash     text NOT NULL DEFAULT '0000000000000000000000000000000000000000000000000000000000000000',
  block_hash    text NOT NULL,
  invoice_id    uuid,
  created_at    timestamptz NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX IF NOT EXISTS verifactu_chain_user_block ON public.verifactu_chain(user_id, block_index);

ALTER TABLE public.verifactu_chain ENABLE ROW LEVEL SECURITY;

DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename='verifactu_chain' AND policyname='select_own_verifactu_chain') THEN
    CREATE POLICY "select_own_verifactu_chain" ON public.verifactu_chain FOR SELECT TO authenticated USING (auth.uid() = user_id);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename='verifactu_chain' AND policyname='insert_own_verifactu_chain') THEN
    CREATE POLICY "insert_own_verifactu_chain" ON public.verifactu_chain FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename='verifactu_chain' AND policyname='update_own_verifactu_chain') THEN
    CREATE POLICY "update_own_verifactu_chain" ON public.verifactu_chain FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename='verifactu_chain' AND policyname='delete_own_verifactu_chain') THEN
    CREATE POLICY "delete_own_verifactu_chain" ON public.verifactu_chain FOR DELETE TO authenticated USING (auth.uid() = user_id);
  END IF;
END $$;

-- Qonto bank transaction cache
CREATE TABLE IF NOT EXISTS public.qonto_transactions (
  id                    uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id               uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  qonto_transaction_id  text NOT NULL,
  label                 text,
  amount                numeric(12,2) NOT NULL DEFAULT 0,
  currency              text NOT NULL DEFAULT 'EUR',
  side                  text NOT NULL CHECK (side IN ('debit','credit')),
  settled_at            timestamptz,
  emitted_at            timestamptz,
  status                text NOT NULL DEFAULT 'pending',
  category              text,
  vat_amount            numeric(12,2),
  vat_rate              numeric(5,2),
  is_vat_deductible     boolean NOT NULL DEFAULT false,
  attachment_ids        text[],
  raw_payload           jsonb,
  synced_at             timestamptz NOT NULL DEFAULT now(),
  created_at            timestamptz NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX IF NOT EXISTS qonto_transactions_user_ext ON public.qonto_transactions(user_id, qonto_transaction_id);

ALTER TABLE public.qonto_transactions ENABLE ROW LEVEL SECURITY;

DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename='qonto_transactions' AND policyname='select_own_qonto_transactions') THEN
    CREATE POLICY "select_own_qonto_transactions" ON public.qonto_transactions FOR SELECT TO authenticated USING (auth.uid() = user_id);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename='qonto_transactions' AND policyname='insert_own_qonto_transactions') THEN
    CREATE POLICY "insert_own_qonto_transactions" ON public.qonto_transactions FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename='qonto_transactions' AND policyname='update_own_qonto_transactions') THEN
    CREATE POLICY "update_own_qonto_transactions" ON public.qonto_transactions FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename='qonto_transactions' AND policyname='delete_own_qonto_transactions') THEN
    CREATE POLICY "delete_own_qonto_transactions" ON public.qonto_transactions FOR DELETE TO authenticated USING (auth.uid() = user_id);
  END IF;
END $$;
