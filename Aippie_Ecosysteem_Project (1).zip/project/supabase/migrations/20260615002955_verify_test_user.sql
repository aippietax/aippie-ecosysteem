-- Verify test user and subscription exist
DO $$
DECLARE
  v_user_id uuid;
  v_plan text;
  v_status text;
BEGIN
  SELECT id INTO v_user_id FROM auth.users WHERE email = 'test@aippietax.com';
  IF v_user_id IS NULL THEN
    RAISE EXCEPTION 'Test user not found!';
  END IF;

  SELECT plan, status INTO v_plan, v_status
  FROM subscriptions WHERE user_id = v_user_id LIMIT 1;

  IF v_plan IS NULL THEN
    RAISE EXCEPTION 'Subscription not found for test user!';
  END IF;

  RAISE NOTICE 'OK: user_id=%, plan=%, status=%', v_user_id, v_plan, v_status;
END $$;
