
-- V216: Update broker constraint to support Trade Republic, Revolut + existing
ALTER TABLE trading_broker_connections
  DROP CONSTRAINT IF EXISTS trading_broker_connections_broker_check;

ALTER TABLE trading_broker_connections
  ADD CONSTRAINT trading_broker_connections_broker_check
  CHECK (broker IN (
    'binance','bybit','interactive_brokers','degiro',
    'trade_republic','revolut'
  ));
