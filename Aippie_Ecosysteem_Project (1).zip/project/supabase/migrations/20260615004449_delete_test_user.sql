DO $$
DECLARE
  v_user_id uuid;
BEGIN
  SELECT id INTO v_user_id FROM auth.users WHERE email = 'test@aippietax.com';

  IF v_user_id IS NOT NULL THEN
    DELETE FROM subscriptions WHERE user_id = v_user_id;
    DELETE FROM auth.identities WHERE user_id = v_user_id;
    DELETE FROM auth.users WHERE id = v_user_id;
    RAISE NOTICE 'Deleted user test@aippietax.com (%)', v_user_id;
  ELSE
    RAISE NOTICE 'User test@aippietax.com not found.';
  END IF;
END $$;
