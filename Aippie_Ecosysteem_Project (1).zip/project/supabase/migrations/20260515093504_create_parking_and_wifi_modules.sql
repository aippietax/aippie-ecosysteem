/*
  # AippieParking and AippieWiFi module tables

  ## New Tables

  ### aippie_parking_slots
  Live parking slot ledger for Costa del Sol (Mijas, Fuengirola, Marbella).
  - `id` (uuid, PK)
  - `name` (text) — parking structure or street name
  - `location` (text) — municipality: Mijas | Fuengirola | Marbella
  - `slot_type` (text) — 'garage' | 'street'
  - `total_spots` (int) — capacity (null for street spots)
  - `vacant_spots` (int) — current free spots (null for street)
  - `status` (text) — 'available' | 'full' | 'reporting' (street: broadcasting free for 10min)
  - `reported_free_at` (timestamptz) — when a user logged they're leaving a street spot
  - `reported_by` (uuid, nullable) — user who triggered the street broadcast
  - `lat` (numeric) — latitude
  - `lng` (numeric) — longitude
  - `updated_at` (timestamptz)
  - `created_at` (timestamptz)

  ### aippiewifi_data_ledger
  Decentralized bandwidth share ledger tracking node usage and revenue splits.
  - `id` (uuid, PK)
  - `node_id` (text) — unique hotspot identifier
  - `node_name` (text) — display name (e.g., "Cafeteria Sol Mijas")
  - `owner_user_id` (uuid, nullable) — FK to auth.users
  - `owner_iban` (text) — owner's IBAN for payout
  - `location` (text) — municipality
  - `status` (text) — 'online' | 'offline'
  - `total_gb_served` (numeric) — cumulative GB served
  - `session_gb` (numeric) — GB served in current active session
  - `owner_earnings` (numeric) — cumulative owner earnings (€0.03/GB = 60%)
  - `platform_margin` (numeric) — cumulative platform cut (€0.02/GB = 40%)
  - `connected_users` (int) — active connections right now
  - `signal_strength` (int) — 0-100
  - `updated_at` (timestamptz)
  - `created_at` (timestamptz)

  ## Security
  - RLS enabled on both tables
  - Public SELECT allowed for parking (live map is publicly visible)
  - Public SELECT allowed for wifi nodes (discovery)
  - Only authenticated users can INSERT street parking reports
  - Only authenticated users can update their own wifi nodes
*/

-- ── aippie_parking_slots ──────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS aippie_parking_slots (
  id                uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
  name              text        NOT NULL,
  location          text        NOT NULL CHECK (location IN ('Mijas','Fuengirola','Marbella')),
  slot_type         text        NOT NULL DEFAULT 'garage' CHECK (slot_type IN ('garage','street')),
  total_spots       integer,
  vacant_spots      integer,
  status            text        NOT NULL DEFAULT 'available' CHECK (status IN ('available','full','reporting')),
  reported_free_at  timestamptz,
  reported_by       uuid        REFERENCES auth.users(id) ON DELETE SET NULL,
  lat               numeric(10,7) NOT NULL DEFAULT 0,
  lng               numeric(10,7) NOT NULL DEFAULT 0,
  updated_at        timestamptz DEFAULT now(),
  created_at        timestamptz DEFAULT now()
);

ALTER TABLE aippie_parking_slots ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view parking slots"
  ON aippie_parking_slots FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE POLICY "Authenticated users can report street spots"
  ON aippie_parking_slots FOR UPDATE
  TO authenticated
  USING (slot_type = 'street')
  WITH CHECK (slot_type = 'street');

-- ── Seed Costa del Sol parking data ──────────────────────────────────────────

INSERT INTO aippie_parking_slots (name, location, slot_type, total_spots, vacant_spots, status, lat, lng) VALUES
  -- Fuengirola garages
  ('Parking Centro Fuengirola',      'Fuengirola', 'garage', 420, 87,  'available', 36.5397, -4.6246),
  ('Parking Miramar Centro',         'Fuengirola', 'garage', 310, 0,   'full',      36.5389, -4.6209),
  ('Parking Plaza España',           'Fuengirola', 'garage', 180, 44,  'available', 36.5403, -4.6271),
  -- Marbella garages
  ('Parking Plaza de la Victoria',   'Marbella',   'garage', 550, 112, 'available', 36.5101, -4.8830),
  ('Parking Puerto Banús',           'Marbella',   'garage', 800, 203, 'available', 36.4849, -4.9634),
  ('Parking Casco Antiguo',          'Marbella',   'garage', 240, 0,   'full',      36.5099, -4.8821),
  -- Mijas garages
  ('Parking Pueblo Blanco Mijas',    'Mijas',      'garage', 160, 38,  'available', 36.5957, -4.6366),
  ('Parking La Cala de Mijas',       'Mijas',      'garage', 120, 9,   'available', 36.4983, -4.7230),
  -- Street spots Costa del Sol
  ('Calle Larios Street',            'Fuengirola', 'street', NULL, NULL, 'available', 36.5401, -4.6252),
  ('Paseo Marítimo Fuengirola',      'Fuengirola', 'street', NULL, NULL, 'full',      36.5336, -4.6286),
  ('Avenida del Mar Marbella',       'Marbella',   'street', NULL, NULL, 'available', 36.5100, -4.8847),
  ('Puerto Banús Boulevard',         'Marbella',   'street', NULL, NULL, 'full',      36.4860, -4.9620),
  ('Calle San Sebastián Mijas',      'Mijas',      'street', NULL, NULL, 'available', 36.5960, -4.6370)
ON CONFLICT DO NOTHING;

-- ── aippiewifi_data_ledger ────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS aippiewifi_data_ledger (
  id                uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
  node_id           text        NOT NULL UNIQUE,
  node_name         text        NOT NULL,
  owner_user_id     uuid        REFERENCES auth.users(id) ON DELETE SET NULL,
  owner_iban        text        NOT NULL DEFAULT '',
  location          text        NOT NULL CHECK (location IN ('Mijas','Fuengirola','Marbella')),
  status            text        NOT NULL DEFAULT 'online' CHECK (status IN ('online','offline')),
  total_gb_served   numeric(12,4) NOT NULL DEFAULT 0,
  session_gb        numeric(12,4) NOT NULL DEFAULT 0,
  owner_earnings    numeric(10,4) NOT NULL DEFAULT 0,
  platform_margin   numeric(10,4) NOT NULL DEFAULT 0,
  connected_users   integer     NOT NULL DEFAULT 0,
  signal_strength   integer     NOT NULL DEFAULT 85 CHECK (signal_strength BETWEEN 0 AND 100),
  updated_at        timestamptz DEFAULT now(),
  created_at        timestamptz DEFAULT now()
);

ALTER TABLE aippiewifi_data_ledger ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view wifi nodes"
  ON aippiewifi_data_ledger FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE POLICY "Owners can update their node"
  ON aippiewifi_data_ledger FOR UPDATE
  TO authenticated
  USING (auth.uid() = owner_user_id)
  WITH CHECK (auth.uid() = owner_user_id);

-- ── Seed wifi nodes ───────────────────────────────────────────────────────────

INSERT INTO aippiewifi_data_ledger
  (node_id, node_name, owner_iban, location, status, total_gb_served, session_gb, owner_earnings, platform_margin, connected_users, signal_strength)
VALUES
  ('node-fuen-001', 'Cafetería Sol Fuengirola',    'ES7921000813610123456789', 'Fuengirola', 'online',  142.5, 3.2,  4.28,  2.85, 7,  92),
  ('node-fuen-002', 'Hostal Playa Centro',          'ES9000246912501234567891', 'Fuengirola', 'online',   87.1, 1.8,  2.61,  1.74, 3,  78),
  ('node-fuen-003', 'Bar La Farola',                'ES6700751234587654321098', 'Fuengirola', 'offline',  34.0, 0.0,  1.02,  0.68, 0,  0),
  ('node-marb-001', 'Puerto Banús Lounge',          'ES2415001234567890123456', 'Marbella',   'online',  310.8, 8.4,  9.32,  6.22, 12, 98),
  ('node-marb-002', 'Hotel Costa del Sol Marbella', 'ES9121001234560123456789', 'Marbella',   'online',  520.3, 12.1, 15.61, 10.41, 19, 95),
  ('node-marb-003', 'Farmacia Nueva Marbella',      'ES8020851234560098765432', 'Marbella',   'offline',  22.4, 0.0,  0.67,  0.45, 0,  0),
  ('node-mija-001', 'Pueblo Blanco WiFi Mijas',     'ES6200491234560987654321', 'Mijas',      'online',   65.2, 2.1,  1.96,  1.30, 4,  88),
  ('node-mija-002', 'La Cala Beach Café',           'ES7720802400000012345678', 'Mijas',      'online',   98.7, 4.5,  2.96,  1.97, 6,  82)
ON CONFLICT DO NOTHING;
