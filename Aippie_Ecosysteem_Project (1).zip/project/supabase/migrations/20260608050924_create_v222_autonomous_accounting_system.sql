-- ═══════════════════════════════════════════════════════════════
--  V222  Autonomous Accounting & Payroll System  — AippieTax S.A.
-- ═══════════════════════════════════════════════════════════════

-- ── Accounting transactions ledger ──────────────────────────────────────────
CREATE TABLE IF NOT EXISTS accounting_transactions (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id         uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  tx_date         date NOT NULL DEFAULT CURRENT_DATE,
  description     text NOT NULL,
  category        text NOT NULL CHECK (category IN (
                    'revenue','cogs','payroll','rent','software','marketing',
                    'legal','travel','bank_charge','tax_reserve','other'
                  )),
  debit           numeric(14,2) DEFAULT 0,
  credit          numeric(14,2) DEFAULT 0,
  currency        text DEFAULT 'EUR',
  jurisdiction    text DEFAULT 'ES' CHECK (jurisdiction IN ('ES','NL','US','GLOBAL')),
  auto_categorized boolean DEFAULT true,
  reconciled      boolean DEFAULT false,
  created_at      timestamptz DEFAULT now()
);

ALTER TABLE accounting_transactions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "select_own_acctx" ON accounting_transactions
  FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "insert_own_acctx" ON accounting_transactions
  FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "update_own_acctx" ON accounting_transactions
  FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE POLICY "delete_own_acctx" ON accounting_transactions
  FOR DELETE TO authenticated USING (auth.uid() = user_id);

-- ── Payroll employees ────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS payroll_employees (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id         uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name       text NOT NULL,
  role            text NOT NULL,
  jurisdiction    text NOT NULL DEFAULT 'ES' CHECK (jurisdiction IN ('ES','NL','US')),
  gross_annual    numeric(12,2) NOT NULL,
  currency        text DEFAULT 'EUR',
  start_date      date DEFAULT CURRENT_DATE,
  iban            text,
  tax_id          text,
  active          boolean DEFAULT true,
  created_at      timestamptz DEFAULT now()
);

ALTER TABLE payroll_employees ENABLE ROW LEVEL SECURITY;

CREATE POLICY "select_own_emp" ON payroll_employees
  FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "insert_own_emp" ON payroll_employees
  FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "update_own_emp" ON payroll_employees
  FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE POLICY "delete_own_emp" ON payroll_employees
  FOR DELETE TO authenticated USING (auth.uid() = user_id);

-- ── Payroll runs ─────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS payroll_runs (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id         uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  employee_id     uuid REFERENCES payroll_employees(id) ON DELETE CASCADE,
  period          text NOT NULL,   -- e.g. '2026-06'
  gross           numeric(12,2) NOT NULL,
  tax_withheld    numeric(12,2) NOT NULL,
  ss_employee     numeric(12,2) NOT NULL,
  ss_employer     numeric(12,2) NOT NULL,
  net_pay         numeric(12,2) NOT NULL,
  currency        text DEFAULT 'EUR',
  status          text DEFAULT 'pending' CHECK (status IN ('pending','processed','paid','filed')),
  paid_at         timestamptz,
  filed_at        timestamptz,
  created_at      timestamptz DEFAULT now()
);

ALTER TABLE payroll_runs ENABLE ROW LEVEL SECURITY;

CREATE POLICY "select_own_runs" ON payroll_runs
  FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "insert_own_runs" ON payroll_runs
  FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "update_own_runs" ON payroll_runs
  FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE POLICY "delete_own_runs" ON payroll_runs
  FOR DELETE TO authenticated USING (auth.uid() = user_id);

-- ── Government tax submissions ───────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS tax_submissions (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id         uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  authority       text NOT NULL CHECK (authority IN ('AEAT','Belastingdienst','IRS','EC_VAT')),
  form_type       text NOT NULL,   -- e.g. 'Modelo 111', 'OB', '941'
  period          text NOT NULL,
  amount          numeric(14,2) DEFAULT 0,
  currency        text DEFAULT 'EUR',
  status          text DEFAULT 'pending' CHECK (status IN ('pending','transmitting','accepted','rejected','paid')),
  reference       text,
  submitted_at    timestamptz,
  created_at      timestamptz DEFAULT now()
);

ALTER TABLE tax_submissions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "select_own_subs" ON tax_submissions
  FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "insert_own_subs" ON tax_submissions
  FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "update_own_subs" ON tax_submissions
  FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE POLICY "delete_own_subs" ON tax_submissions
  FOR DELETE TO authenticated USING (auth.uid() = user_id);
