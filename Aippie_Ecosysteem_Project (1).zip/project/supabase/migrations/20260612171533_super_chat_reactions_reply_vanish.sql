-- Quoted reply support
ALTER TABLE secure_chat_messages
  ADD COLUMN IF NOT EXISTS reply_to_id   uuid REFERENCES secure_chat_messages(id) ON DELETE SET NULL,
  ADD COLUMN IF NOT EXISTS reply_preview text;

-- Custom vanish timer per contact relationship (seconds; 0 = no auto-vanish)
ALTER TABLE secure_chat_contacts
  ADD COLUMN IF NOT EXISTS vanish_timer integer NOT NULL DEFAULT 32;

-- Emoji reactions
CREATE TABLE IF NOT EXISTS secure_chat_reactions (
  id         uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
  message_id uuid        NOT NULL REFERENCES secure_chat_messages(id) ON DELETE CASCADE,
  from_pin   text        NOT NULL,
  emoji      text        NOT NULL,
  created_at timestamptz DEFAULT now(),
  UNIQUE(message_id, from_pin)
);

ALTER TABLE secure_chat_reactions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "select_reactions" ON secure_chat_reactions FOR SELECT
  TO authenticated USING (true);

CREATE POLICY "insert_reaction" ON secure_chat_reactions FOR INSERT
  TO authenticated
  WITH CHECK (from_pin = (SELECT pin_code FROM secure_chat_pins WHERE user_id = auth.uid()));

CREATE POLICY "update_reaction" ON secure_chat_reactions FOR UPDATE
  TO authenticated
  USING  (from_pin = (SELECT pin_code FROM secure_chat_pins WHERE user_id = auth.uid()))
  WITH CHECK (from_pin = (SELECT pin_code FROM secure_chat_pins WHERE user_id = auth.uid()));

CREATE POLICY "delete_reaction" ON secure_chat_reactions FOR DELETE
  TO authenticated
  USING (from_pin = (SELECT pin_code FROM secure_chat_pins WHERE user_id = auth.uid()));
