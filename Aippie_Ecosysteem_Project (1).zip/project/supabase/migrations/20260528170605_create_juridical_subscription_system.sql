/*
  # Juridical Subscription System — AippieTax S.A.

  ## Overview
  Extends the APC wallet system with legal subscription flags and creates the
  full juridical infrastructure: verified lawyers directory, AI document scan
  ledger, and live lawyer session channels with APC escrow payments.

  ## Changes

  ### 1. Modified Tables
  - `apc_wallets` — two new boolean columns for subscription status:
    - `consumer_legal_sub_active` (bool, default false) — €5/mo consumer legal plan
    - `lawyer_premium_sub_active` (bool, default false) — premium lawyer subscription

  ### 2. New Tables
  - `aippie_lawyers` — verified lawyers directory with green badge scoring system
  - `aippie_legal_scans` — AI document analysis ledger (encrypted URLs + summaries)
  - `aippie_lawyer_sessions` — live session channels (call/chat/message) with APC escrow

  ### 3. Security
  - RLS enabled on all three new tables
  - Lawyers can manage their own profile; clients can read active/verified lawyers
  - Legal scans are private to the owning user
  - Sessions visible only to the client or lawyer involved
  - Indexes for performance at scale (green badge filter, client lookup)

  ### 4. Important Notes
  - All session payments use Aippie Coins (APC) with 1% fee applied at transaction time
  - `disclaimer_accepted` on scans enforces the "AI is not a lawyer" disclosure
  - `has_green_verified_badge` is the elite verification gate for lawyer visibility
*/

-- ── 1. Extend apc_wallets with subscription flags ─────────────────────────────
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'apc_wallets' AND column_name = 'consumer_legal_sub_active'
  ) THEN
    ALTER TABLE public.apc_wallets
      ADD COLUMN consumer_legal_sub_active boolean NOT NULL DEFAULT false;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'apc_wallets' AND column_name = 'lawyer_premium_sub_active'
  ) THEN
    ALTER TABLE public.apc_wallets
      ADD COLUMN lawyer_premium_sub_active boolean NOT NULL DEFAULT false;
  END IF;
END $$;

-- ── 2. Lawyers directory ──────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS public.aippie_lawyers (
  lawyer_id                   uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id                     uuid        REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name                   varchar(100) NOT NULL,
  bar_registration_number     varchar(50)  NOT NULL UNIQUE,
  specialization_tags         text[]       NOT NULL DEFAULT '{}',
  performance_score           numeric(3,2) NOT NULL DEFAULT 5.00
                                CHECK (performance_score BETWEEN 0.00 AND 5.00),
  has_green_verified_badge    boolean      NOT NULL DEFAULT true,
  monthly_subscription_fee_eur numeric(5,2) NOT NULL DEFAULT 5.00,
  is_available_live           boolean      NOT NULL DEFAULT true,
  created_at                  timestamptz  NOT NULL DEFAULT now(),
  updated_at                  timestamptz  NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_lawyers_score
  ON public.aippie_lawyers (performance_score DESC)
  WHERE has_green_verified_badge = true;

CREATE INDEX IF NOT EXISTS idx_lawyers_user_id
  ON public.aippie_lawyers (user_id);

ALTER TABLE public.aippie_lawyers ENABLE ROW LEVEL SECURITY;

-- Authenticated users can browse verified, available lawyers
CREATE POLICY "Anyone authenticated can view active verified lawyers"
  ON public.aippie_lawyers FOR SELECT
  TO authenticated
  USING (has_green_verified_badge = true AND is_available_live = true);

-- Lawyers can insert their own profile
CREATE POLICY "Lawyers can register own profile"
  ON public.aippie_lawyers FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- Lawyers can update their own profile
CREATE POLICY "Lawyers can update own profile"
  ON public.aippie_lawyers FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- ── 3. AI juridical scan & document ledger ───────────────────────────────────
CREATE TABLE IF NOT EXISTS public.aippie_legal_scans (
  scan_id                  uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id                  uuid        NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  document_url_encrypted   text        NOT NULL,
  ai_analysis_summary      text        NOT NULL DEFAULT '',
  disclaimer_accepted      boolean     NOT NULL DEFAULT true,
  created_at               timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_legal_scans_user_id
  ON public.aippie_legal_scans (user_id);

CREATE INDEX IF NOT EXISTS idx_legal_scans_created_at
  ON public.aippie_legal_scans (created_at DESC);

ALTER TABLE public.aippie_legal_scans ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own legal scans"
  ON public.aippie_legal_scans FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own legal scans"
  ON public.aippie_legal_scans FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- ── 4. Live lawyer session channel ───────────────────────────────────────────
CREATE TABLE IF NOT EXISTS public.aippie_lawyer_sessions (
  session_id         uuid         PRIMARY KEY DEFAULT gen_random_uuid(),
  client_id          uuid         REFERENCES auth.users(id) ON DELETE SET NULL,
  lawyer_id          uuid         REFERENCES public.aippie_lawyers(lawyer_id) ON DELETE SET NULL,
  session_type       varchar(15)  NOT NULL CHECK (session_type IN ('LIVE_CALL','CHAT_STREAM','SECURE_MESSAGE')),
  session_status     varchar(15)  NOT NULL DEFAULT 'CONNECTED'
                                  CHECK (session_status IN ('CONNECTED','COMPLETED','MISSED')),
  escrow_payment_apc numeric(12,4) NOT NULL DEFAULT 0.0000
                                  CHECK (escrow_payment_apc >= 0),
  created_at         timestamptz  NOT NULL DEFAULT now(),
  ended_at           timestamptz
);

CREATE INDEX IF NOT EXISTS idx_sessions_client
  ON public.aippie_lawyer_sessions (client_id);

CREATE INDEX IF NOT EXISTS idx_sessions_lawyer
  ON public.aippie_lawyer_sessions (lawyer_id);

CREATE INDEX IF NOT EXISTS idx_sessions_created_at
  ON public.aippie_lawyer_sessions (created_at DESC);

ALTER TABLE public.aippie_lawyer_sessions ENABLE ROW LEVEL SECURITY;

-- Clients can see their own sessions
CREATE POLICY "Clients can view own sessions"
  ON public.aippie_lawyer_sessions FOR SELECT
  TO authenticated
  USING (auth.uid() = client_id);

-- Lawyers can see sessions assigned to them via their lawyer profile
CREATE POLICY "Lawyers can view own sessions"
  ON public.aippie_lawyer_sessions FOR SELECT
  TO authenticated
  USING (
    lawyer_id IN (
      SELECT lawyer_id FROM public.aippie_lawyers WHERE user_id = auth.uid()
    )
  );

-- Clients can open (insert) a session
CREATE POLICY "Clients can open sessions"
  ON public.aippie_lawyer_sessions FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = client_id);

-- Either party can update session status (complete/close)
CREATE POLICY "Participants can update session status"
  ON public.aippie_lawyer_sessions FOR UPDATE
  TO authenticated
  USING (
    auth.uid() = client_id
    OR lawyer_id IN (
      SELECT lawyer_id FROM public.aippie_lawyers WHERE user_id = auth.uid()
    )
  )
  WITH CHECK (
    auth.uid() = client_id
    OR lawyer_id IN (
      SELECT lawyer_id FROM public.aippie_lawyers WHERE user_id = auth.uid()
    )
  );
