/*
  # Create aippie_user_portfolio table

  ## Summary
  Stores mock trade execution logs recommended by the Aippie Trading Analyst engine.
  Each row represents one signal-triggered trade action recorded per user session.

  ## New Tables
  - `aippie_user_portfolio`
    - `id` (uuid, primary key)
    - `user_id` (uuid, nullable — links to auth.users if authenticated; NULL for demo session)
    - `ticker` (text) — stock symbol e.g. AAPL
    - `direction` (text) — BUY or SELL
    - `entry_price` (numeric) — price at signal fire
    - `target_price` (numeric) — Aippie target price
    - `probability` (numeric) — signal confidence 0–1
    - `outcome` (text) — 'win' | 'loss' | 'pending'
    - `pnl_eur` (numeric) — simulated P&L in EUR
    - `executed_at` (timestamptz)
    - `broker_stub` (text, nullable) — which broker button was tapped

  ## Security
  - RLS enabled
  - Authenticated users can insert and select their own rows
  - Anonymous reads blocked
*/

CREATE TABLE IF NOT EXISTS aippie_user_portfolio (
  id           uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id      uuid        REFERENCES auth.users(id) ON DELETE CASCADE,
  ticker       text        NOT NULL DEFAULT '',
  direction    text        NOT NULL DEFAULT 'BUY' CHECK (direction IN ('BUY','SELL')),
  entry_price  numeric     NOT NULL DEFAULT 0,
  target_price numeric     NOT NULL DEFAULT 0,
  probability  numeric     NOT NULL DEFAULT 0,
  outcome      text        NOT NULL DEFAULT 'pending' CHECK (outcome IN ('win','loss','pending')),
  pnl_eur      numeric     NOT NULL DEFAULT 0,
  broker_stub  text,
  executed_at  timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE aippie_user_portfolio ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can insert own portfolio rows"
  ON aippie_user_portfolio FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can view own portfolio rows"
  ON aippie_user_portfolio FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

-- Seed aggregate demo stats row (no user_id — used for the live leaderboard widget only)
INSERT INTO aippie_user_portfolio
  (user_id, ticker, direction, entry_price, target_price, probability, outcome, pnl_eur, broker_stub, executed_at)
VALUES
  (NULL, 'NVDA', 'BUY',  421.30, 489.60, 0.91, 'win',  +312.40, 'traderepublic', now() - interval '6 days'),
  (NULL, 'AAPL', 'BUY',  176.50, 192.80, 0.88, 'win',  +198.60, 'revolut',       now() - interval '5 days'),
  (NULL, 'MSFT', 'SELL', 418.20, 401.50, 0.87, 'win',  +210.50, 'degiro',        now() - interval '4 days'),
  (NULL, 'TSLA', 'BUY',  228.40, 252.10, 0.89, 'win',  +284.70, 'traderepublic', now() - interval '3 days'),
  (NULL, 'AAPL', 'SELL', 195.30, 186.20, 0.86, 'win',  +182.90, 'revolut',       now() - interval '2 days'),
  (NULL, 'AMZN', 'BUY',  171.60, 183.40, 0.85, 'loss', -108.60, 'degiro',        now() - interval '1 day'),
  (NULL, 'NVDA', 'BUY',  462.10, 498.70, 0.92, 'win',  +340.00, 'traderepublic', now() - interval '12 hours');
