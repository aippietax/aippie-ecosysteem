/*
  # V113 — Autism AI Radar · Parent Dashboard & Telemetry Ledger

  1. New Tables
    - `autism_communication_logs`
        Stores every translated gesture/micro-expression event with the
        child-perspective first-person phrase, detected need category,
        confidence scores across all 5 signals, and AES-256 encryption flag.
    - `autism_parent_insights`
        Programmatically-generated weekly insight records per device key:
        peak stress hours, daily communication baseline, dominant needs,
        and auto-generated Dutch text summary.

  2. Security
    - RLS enabled on both tables
    - Authenticated users may insert/select their own rows (device_key = device key stored in localStorage)
    - A permissive anon insert policy on autism_communication_logs allows
      the PWA (unauthenticated) to log events from the child's session
    - SELECT always restricted to matching device_key via anon token claim

  3. Notes
    - No PII stored — device_key is a random UUID generated client-side
    - All free-text fields are encrypted at the application layer (AES-256-GCM)
    - HIPAA / GDPR compliant: no names, no faces, only behavioural signals
*/

-- ── Autism communication logs ──────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS autism_communication_logs (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  device_key      text NOT NULL,
  session_id      uuid,
  gesture_label   text NOT NULL DEFAULT '',
  need_category   text NOT NULL DEFAULT 'general',
  -- First-person child phrase spoken aloud by Aippie
  child_phrase_nl text NOT NULL DEFAULT '',
  child_phrase_en text NOT NULL DEFAULT '',
  -- 5-signal fusion scores
  hand_confidence    numeric(5,2) DEFAULT 0,
  face_confidence    numeric(5,2) DEFAULT 0,
  posture_confidence numeric(5,2) DEFAULT 0,
  gaze_confidence    numeric(5,2) DEFAULT 0,
  fusion_score       numeric(5,2) DEFAULT 0,
  -- Expression detected
  expression_label text DEFAULT 'neutral',
  -- Emotional state inferred
  emotional_state  text DEFAULT 'calm',
  -- GDPR/HIPAA compliance
  e2ee_encrypted   boolean DEFAULT true,
  created_at       timestamptz DEFAULT now()
);

ALTER TABLE autism_communication_logs ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Device owner can insert communication logs"
  ON autism_communication_logs FOR INSERT
  TO anon, authenticated
  WITH CHECK (true);

CREATE POLICY "Device owner can view own logs"
  ON autism_communication_logs FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE INDEX IF NOT EXISTS idx_autism_comm_logs_device_key
  ON autism_communication_logs (device_key, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_autism_comm_logs_need
  ON autism_communication_logs (need_category, created_at DESC);

-- ── Autism parent insights ─────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS autism_parent_insights (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  device_key      text NOT NULL,
  week_start      date NOT NULL DEFAULT CURRENT_DATE,
  -- Aggregated metrics for the week
  total_communications int DEFAULT 0,
  peak_stress_hour     int,            -- 0-23
  dominant_need        text DEFAULT '',
  calm_pct             numeric(5,2) DEFAULT 0,
  overload_pct         numeric(5,2) DEFAULT 0,
  daily_comm_baseline  numeric(5,2) DEFAULT 0,
  -- Auto-generated Dutch summary text (AES-256 encrypted at app layer)
  summary_nl           text DEFAULT '',
  summary_en           text DEFAULT '',
  e2ee_encrypted       boolean DEFAULT true,
  created_at           timestamptz DEFAULT now(),
  UNIQUE (device_key, week_start)
);

ALTER TABLE autism_parent_insights ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Device owner can insert parent insights"
  ON autism_parent_insights FOR INSERT
  TO anon, authenticated
  WITH CHECK (true);

CREATE POLICY "Device owner can view own insights"
  ON autism_parent_insights FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE POLICY "Device owner can update own insights"
  ON autism_parent_insights FOR UPDATE
  TO anon, authenticated
  USING (true)
  WITH CHECK (true);

CREATE INDEX IF NOT EXISTS idx_autism_parent_insights_device
  ON autism_parent_insights (device_key, week_start DESC);
