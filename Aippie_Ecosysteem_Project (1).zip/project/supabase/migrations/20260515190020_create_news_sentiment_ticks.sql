/*
  # Create aippie_news_sentiment_ticks table

  ## Summary
  Stores AI-scored global breaking news items with directional velocity indexes
  used by the Aippie Market Shifter engine inside the Trading Alpha tab.

  ## New Table: aippie_news_sentiment_ticks
  - `id`           uuid PK
  - `headline`     text — news headline text
  - `source`       text — e.g. Reuters, Bloomberg, FT
  - `ticker`       text nullable — related stock ticker if any
  - `direction`    text — BULLISH | BEARISH | NEUTRAL
  - `velocity`     numeric — directional strength 0.0–1.0
  - `region`       text — e.g. US, EU, GLOBAL
  - `created_at`   timestamptz

  ## Security
  - RLS enabled; public read-only (news is non-personal data)
  - No user-specific data — read by all authenticated and anonymous viewers

  ## Seed Data
  Pre-populated with 10 realistic demo news items spanning bullish/bearish signals.
*/

CREATE TABLE IF NOT EXISTS aippie_news_sentiment_ticks (
  id         uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
  headline   text        NOT NULL DEFAULT '',
  source     text        NOT NULL DEFAULT 'Reuters',
  ticker     text,
  direction  text        NOT NULL DEFAULT 'NEUTRAL' CHECK (direction IN ('BULLISH','BEARISH','NEUTRAL')),
  velocity   numeric     NOT NULL DEFAULT 0.5 CHECK (velocity >= 0 AND velocity <= 1),
  region     text        NOT NULL DEFAULT 'GLOBAL',
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE aippie_news_sentiment_ticks ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Public can read news sentiment ticks"
  ON aippie_news_sentiment_ticks FOR SELECT
  TO anon, authenticated
  USING (true);

-- Seed realistic news items
INSERT INTO aippie_news_sentiment_ticks (headline, source, ticker, direction, velocity, region, created_at) VALUES
  ('Fed signals pause on rate hikes as inflation cools to 2.1% — markets surge', 'Reuters', NULL, 'BULLISH', 0.94, 'US', now() - interval '3 minutes'),
  ('NVIDIA posts record Q3 earnings, data center revenue up 206% YoY', 'Bloomberg', 'NVDA', 'BULLISH', 0.97, 'US', now() - interval '7 minutes'),
  ('China property crisis deepens — Evergrande liquidation order confirmed', 'FT', NULL, 'BEARISH', 0.91, 'ASIA', now() - interval '12 minutes'),
  ('Apple supplier Foxconn expands Arizona plant — 6,000 jobs created', 'CNBC', 'AAPL', 'BULLISH', 0.88, 'US', now() - interval '18 minutes'),
  ('ECB emergency meeting called as euro drops to 1.02 against dollar', 'Reuters', NULL, 'BEARISH', 0.93, 'EU', now() - interval '25 minutes'),
  ('Microsoft Azure cloud revenue beats by $2.1B — Azure AI demand accelerating', 'Bloomberg', 'MSFT', 'BULLISH', 0.96, 'US', now() - interval '31 minutes'),
  ('Tesla faces SEC probe over Autopilot safety disclosures', 'FT', 'TSLA', 'BEARISH', 0.87, 'US', now() - interval '44 minutes'),
  ('Amazon AWS wins $10B Pentagon JEDI-2 cloud contract extension', 'Reuters', 'AMZN', 'BULLISH', 0.92, 'US', now() - interval '52 minutes'),
  ('Oil prices crash 8% on OPEC+ supply surprise — global energy rout', 'Bloomberg', NULL, 'BEARISH', 0.95, 'GLOBAL', now() - interval '58 minutes'),
  ('ECB rate cut imminent — Lagarde confirms 50bp reduction next Thursday', 'FT', NULL, 'BULLISH', 0.89, 'EU', now() - interval '67 minutes');
