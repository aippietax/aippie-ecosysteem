-- INSERT: new codes must start as 'pending' (cannot mint already-active/revoked codes)
DROP POLICY IF EXISTS anon_insert_access_codes ON aippie_access_codes;
CREATE POLICY anon_insert_access_codes ON aippie_access_codes
  FOR INSERT TO anon, authenticated
  WITH CHECK (status = 'pending');

-- UPDATE: only 'pending' rows can be touched, and the result must be 'active'
-- (enforces the pending -> active activation transition; blocks reactivating
-- revoked codes or tampering with already-active codes)
DROP POLICY IF EXISTS anon_update_access_codes ON aippie_access_codes;
CREATE POLICY anon_update_access_codes ON aippie_access_codes
  FOR UPDATE TO anon, authenticated
  USING (status = 'pending')
  WITH CHECK (status = 'active');