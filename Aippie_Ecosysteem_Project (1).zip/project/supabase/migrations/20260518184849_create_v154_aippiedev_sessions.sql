/*
  # V154 AippieDev Sessions

  1. New Tables
    - `aippiedev_sessions`
      - `id` (uuid, primary key)
      - `device_key` (text) — anonymous device identifier
      - `plan` (text) — subscription plan slug
      - `amount_usd` (numeric) — monthly charge
      - `billing` (text) — 'monthly'
      - `company_name` (text)
      - `contact_email` (text)
      - `card_last4` (text)
      - `session_token` (text) — unique unlock token
      - `status` (text) — 'active' | 'cancelled'
      - `created_at` (timestamptz)

  2. Security
    - RLS enabled, device_key-scoped (non-empty key required)
*/

CREATE TABLE IF NOT EXISTS aippiedev_sessions (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  device_key    text NOT NULL DEFAULT '',
  plan          text NOT NULL DEFAULT 'aippiedev_saas',
  amount_usd    numeric(10,2) NOT NULL DEFAULT 299.00,
  billing       text NOT NULL DEFAULT 'monthly',
  company_name  text NOT NULL DEFAULT '',
  contact_email text NOT NULL DEFAULT '',
  card_last4    text NOT NULL DEFAULT '',
  session_token text NOT NULL DEFAULT '',
  status        text NOT NULL DEFAULT 'active',
  created_at    timestamptz DEFAULT now()
);

ALTER TABLE aippiedev_sessions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Device insert aippiedev session"
  ON aippiedev_sessions FOR INSERT
  TO anon, authenticated
  WITH CHECK (device_key <> '' AND device_key IS NOT NULL);

CREATE POLICY "Device select aippiedev session"
  ON aippiedev_sessions FOR SELECT
  TO anon, authenticated
  USING (device_key <> '' AND device_key IS NOT NULL);

CREATE POLICY "Device update aippiedev session"
  ON aippiedev_sessions FOR UPDATE
  TO anon, authenticated
  USING  (device_key <> '' AND device_key IS NOT NULL)
  WITH CHECK (device_key <> '' AND device_key IS NOT NULL);
