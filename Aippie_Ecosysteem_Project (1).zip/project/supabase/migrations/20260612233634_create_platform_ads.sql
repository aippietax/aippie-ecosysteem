-- Platform-wide paid advertisement slots
-- €5/week — any user or company can submit an ad (text + optional image)
-- Ads appear in the rotating 3-second banner throughout the entire app

CREATE TABLE IF NOT EXISTS public.platform_ads (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id       UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  company_name  TEXT NOT NULL DEFAULT '',
  ad_text       TEXT NOT NULL DEFAULT '',
  image_url     TEXT,
  link_url      TEXT,
  paid_until    TIMESTAMPTZ,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
  approved      BOOLEAN NOT NULL DEFAULT true
);

ALTER TABLE public.platform_ads ENABLE ROW LEVEL SECURITY;

-- Anyone can read active/approved ads (needed for public banner)
CREATE POLICY "read_active_platform_ads" ON public.platform_ads
  FOR SELECT TO authenticated, anon
  USING (approved = true AND (paid_until IS NULL OR paid_until > now()));

-- Authenticated users can insert their own ads
CREATE POLICY "insert_own_platform_ad" ON public.platform_ads
  FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- Users can update their own ads
CREATE POLICY "update_own_platform_ad" ON public.platform_ads
  FOR UPDATE TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Users can delete their own ads
CREATE POLICY "delete_own_platform_ad" ON public.platform_ads
  FOR DELETE TO authenticated
  USING (auth.uid() = user_id);

-- Index for fast active-ad queries
CREATE INDEX IF NOT EXISTS idx_platform_ads_active
  ON public.platform_ads (paid_until, approved)
  WHERE approved = true;

-- Insert 3 demo seed ads so the banner is never empty on first load
INSERT INTO public.platform_ads (company_name, ad_text, image_url, link_url, approved)
VALUES
  ('Aippie', 'Adverteer hier voor slechts €5/week — bereik duizenden gebruikers', NULL, NULL, true),
  ('Aippie Tax', 'Laat AI jouw belastingaangifte doen — AippieTax vanaf €100', NULL, NULL, true),
  ('Aippie SecureChat', 'End-to-end versleuteld chatten · Deel bestanden veilig · SecureChat', NULL, NULL, true);
