-- VERI*FACTU: Spanish mandatory e-invoicing (AEAT) tables

CREATE TABLE IF NOT EXISTS verifactu_companies (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id      uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  device_key   text NOT NULL DEFAULT '',
  nif          text NOT NULL,
  nombre       text NOT NULL,
  direccion    text,
  entorno      text NOT NULL DEFAULT 'PRUEBAS' CHECK (entorno IN ('PRODUCCION','PRUEBAS')),
  auto_send    boolean NOT NULL DEFAULT false,
  webhook_url  text,
  created_at   timestamptz NOT NULL DEFAULT now(),
  updated_at   timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE verifactu_companies ENABLE ROW LEVEL SECURITY;

CREATE POLICY "select_own_verifactu_companies" ON verifactu_companies
  FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "insert_own_verifactu_companies" ON verifactu_companies
  FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "update_own_verifactu_companies" ON verifactu_companies
  FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE POLICY "delete_own_verifactu_companies" ON verifactu_companies
  FOR DELETE TO authenticated USING (auth.uid() = user_id);

-- Allow device_key access (for non-auth users)
CREATE POLICY "device_key_select_verifactu_companies" ON verifactu_companies
  FOR SELECT TO anon USING (device_key = current_setting('request.headers', true)::json->>'x-device-key');

-- ─── INVOICES ────────────────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS verifactu_invoices (
  id                    uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  device_key            text NOT NULL DEFAULT '',
  user_id               uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  numero_serie          text NOT NULL,
  fecha_expedicion      date NOT NULL DEFAULT CURRENT_DATE,
  tipo_factura          text NOT NULL DEFAULT 'F1'
                          CHECK (tipo_factura IN ('F1','F2','R1','R2','R3','R4','R5')),
  nif_emisor            text NOT NULL,
  nombre_emisor         text NOT NULL,
  nif_destinatario      text,
  nombre_destinatario   text,
  direccion_destinatario text,
  pais_destinatario     text DEFAULT 'ES',
  descripcion           text NOT NULL,
  lineas                jsonb NOT NULL DEFAULT '[]',
  base_imponible        numeric(14,2) NOT NULL DEFAULT 0,
  cuota_iva             numeric(14,2) NOT NULL DEFAULT 0,
  importe_total         numeric(14,2) NOT NULL DEFAULT 0,
  hash_huella           text,
  qr_code               text,
  aeat_status           text NOT NULL DEFAULT 'PENDIENTE'
                          CHECK (aeat_status IN ('PENDIENTE','ENVIADO','RECHAZADO','ERROR','BORRADOR')),
  aeat_response         jsonb,
  aeat_timestamp        timestamptz,
  raw_registro          jsonb,
  created_at            timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE verifactu_invoices ENABLE ROW LEVEL SECURITY;

CREATE POLICY "select_own_verifactu_invoices" ON verifactu_invoices
  FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "insert_own_verifactu_invoices" ON verifactu_invoices
  FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "update_own_verifactu_invoices" ON verifactu_invoices
  FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE POLICY "delete_own_verifactu_invoices" ON verifactu_invoices
  FOR DELETE TO authenticated USING (auth.uid() = user_id);

-- anon device-key access
CREATE POLICY "anon_select_verifactu_invoices" ON verifactu_invoices
  FOR SELECT TO anon USING (device_key != '');
CREATE POLICY "anon_insert_verifactu_invoices" ON verifactu_invoices
  FOR INSERT TO anon WITH CHECK (device_key != '');
CREATE POLICY "anon_update_verifactu_invoices" ON verifactu_invoices
  FOR UPDATE TO anon USING (device_key != '') WITH CHECK (device_key != '');

-- ─── HASH CHAIN ──────────────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS verifactu_hash_chain (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  device_key      text NOT NULL DEFAULT '',
  invoice_id      uuid REFERENCES verifactu_invoices(id) ON DELETE CASCADE,
  hash_anterior   text,
  hash_actual     text NOT NULL,
  created_at      timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE verifactu_hash_chain ENABLE ROW LEVEL SECURITY;

CREATE POLICY "select_verifactu_hash_chain" ON verifactu_hash_chain
  FOR SELECT TO authenticated USING (true);
CREATE POLICY "insert_verifactu_hash_chain" ON verifactu_hash_chain
  FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "update_verifactu_hash_chain" ON verifactu_hash_chain
  FOR UPDATE TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "delete_verifactu_hash_chain" ON verifactu_hash_chain
  FOR DELETE TO authenticated USING (true);

CREATE POLICY "anon_select_hash_chain" ON verifactu_hash_chain
  FOR SELECT TO anon USING (device_key != '');
CREATE POLICY "anon_insert_hash_chain" ON verifactu_hash_chain
  FOR INSERT TO anon WITH CHECK (device_key != '');
