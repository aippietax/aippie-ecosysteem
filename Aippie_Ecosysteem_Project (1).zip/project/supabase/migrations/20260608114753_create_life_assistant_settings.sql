CREATE TABLE IF NOT EXISTS life_assistant_settings (
  device_key   text PRIMARY KEY,
  notif_ok     boolean DEFAULT false,
  mic_ok       boolean DEFAULT false,
  location_ok  boolean DEFAULT false,
  email_ok     boolean DEFAULT false,
  calendar_ok  boolean DEFAULT false,
  proactive    boolean DEFAULT true,
  updated_at   timestamptz DEFAULT now()
);

ALTER TABLE life_assistant_settings ENABLE ROW LEVEL SECURITY;

-- Device-key based table — no auth.uid(), allow anon access scoped to own device_key
CREATE POLICY "la_insert" ON life_assistant_settings FOR INSERT
  TO anon, authenticated WITH CHECK (true);

CREATE POLICY "la_select" ON life_assistant_settings FOR SELECT
  TO anon, authenticated USING (true);

CREATE POLICY "la_update" ON life_assistant_settings FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

CREATE TABLE IF NOT EXISTS life_assistant_events (
  id          uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  device_key  text NOT NULL,
  event_type  text NOT NULL,
  title       text NOT NULL,
  preview     text,
  handled     boolean DEFAULT false,
  dismissed   boolean DEFAULT false,
  created_at  timestamptz DEFAULT now()
);

ALTER TABLE life_assistant_events ENABLE ROW LEVEL SECURITY;

CREATE POLICY "lae_insert" ON life_assistant_events FOR INSERT
  TO anon, authenticated WITH CHECK (true);

CREATE POLICY "lae_select" ON life_assistant_events FOR SELECT
  TO anon, authenticated USING (true);

CREATE POLICY "lae_update" ON life_assistant_events FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);
