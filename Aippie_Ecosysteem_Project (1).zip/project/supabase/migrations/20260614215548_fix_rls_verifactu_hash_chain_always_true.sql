-- Fix RLS always-true policies on verifactu_hash_chain

DROP POLICY IF EXISTS "insert_verifactu_hash_chain" ON verifactu_hash_chain;
DROP POLICY IF EXISTS "update_verifactu_hash_chain" ON verifactu_hash_chain;
DROP POLICY IF EXISTS "delete_verifactu_hash_chain" ON verifactu_hash_chain;

-- INSERT: only allowed when the linked invoice belongs to the authenticated user
CREATE POLICY "insert_verifactu_hash_chain" ON verifactu_hash_chain
  FOR INSERT TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM verifactu_invoices
      WHERE verifactu_invoices.id = invoice_id
        AND verifactu_invoices.user_id = auth.uid()
    )
  );

-- UPDATE: only allowed when the linked invoice belongs to the authenticated user
CREATE POLICY "update_verifactu_hash_chain" ON verifactu_hash_chain
  FOR UPDATE TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM verifactu_invoices
      WHERE verifactu_invoices.id = invoice_id
        AND verifactu_invoices.user_id = auth.uid()
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM verifactu_invoices
      WHERE verifactu_invoices.id = invoice_id
        AND verifactu_invoices.user_id = auth.uid()
    )
  );

-- DELETE: only allowed when the linked invoice belongs to the authenticated user
CREATE POLICY "delete_verifactu_hash_chain" ON verifactu_hash_chain
  FOR DELETE TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM verifactu_invoices
      WHERE verifactu_invoices.id = invoice_id
        AND verifactu_invoices.user_id = auth.uid()
    )
  );
