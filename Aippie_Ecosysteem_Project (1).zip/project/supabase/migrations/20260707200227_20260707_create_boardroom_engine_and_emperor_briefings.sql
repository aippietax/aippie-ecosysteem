/*
# AIPPIE Boardroom Engine — Cabinet Meetings & Emperor Briefings

## Summary
Creates the persistence layer for the Autonomous AI Boardroom Engine and
Emperor Briefing Cockpit. Two tables back the premium boardroom dashboard.

## New Tables

### aippie_boardroom_meetings
Stores autonomous cabinet meeting records. Each meeting has a title,
status, secretary department (Tax, Commerce, Defense, Health), the AI-
generated discussion transcript, and any approved actions.

Columns:
- `id` (uuid, PK)
- `user_id` (uuid, FK auth.users, owner-scoped)
- `meeting_date` (timestamptz)
- `title` (text) — e.g. "Q3 2026 Tax Optimization Council"
- `department` (text) — Secretary of: 'tax' | 'commerce' | 'defense' | 'health'
- `status` (text) — 'active' | 'completed' | 'scheduled'
- `discussion_transcript` (text) — AI-generated cabinet discussion
- `approved_actions` (jsonb) — list of action items voted on
- `created_at` (timestamptz)

### aippie_emperor_briefings
Monthly supreme intelligence briefings. Each row represents one month's
autonomous summary across all departments.

Columns:
- `id` (uuid, PK)
- `user_id` (uuid, FK auth.users, owner-scoped)
- `briefing_month` (text) — e.g. "2026-07"
- `bruto_balance_eur` (numeric) — gross portfolio/revenue balance
- `net_surplus_eur` (numeric) — net surplus after costs
- `tax_summary` (text)
- `commerce_summary` (text)
- `defense_summary` (text)
- `health_summary` (text)
- `master_directive` (text) — headline directive statement
- `created_at` (timestamptz)

## Security
RLS enabled on both tables, owner-scoped to auth.uid().
Each authenticated user can only see and write their own rows.
DEFAULT auth.uid() so inserts without user_id still pass WITH CHECK.
*/

-- ─── aippie_boardroom_meetings ────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS aippie_boardroom_meetings (
  id                    uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id               uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  meeting_date          timestamptz NOT NULL DEFAULT now(),
  title                 text NOT NULL DEFAULT 'Cabinet Session',
  department            text NOT NULL DEFAULT 'tax',
  status                text NOT NULL DEFAULT 'active'
                          CHECK (status IN ('active','completed','scheduled')),
  discussion_transcript text,
  approved_actions      jsonb DEFAULT '[]'::jsonb,
  created_at            timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_boardroom_user_id   ON aippie_boardroom_meetings(user_id);
CREATE INDEX IF NOT EXISTS idx_boardroom_status    ON aippie_boardroom_meetings(status);
CREATE INDEX IF NOT EXISTS idx_boardroom_dept      ON aippie_boardroom_meetings(department);

ALTER TABLE aippie_boardroom_meetings ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_boardroom" ON aippie_boardroom_meetings;
CREATE POLICY "select_own_boardroom" ON aippie_boardroom_meetings FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_boardroom" ON aippie_boardroom_meetings;
CREATE POLICY "insert_own_boardroom" ON aippie_boardroom_meetings FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_boardroom" ON aippie_boardroom_meetings;
CREATE POLICY "update_own_boardroom" ON aippie_boardroom_meetings FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_boardroom" ON aippie_boardroom_meetings;
CREATE POLICY "delete_own_boardroom" ON aippie_boardroom_meetings FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

-- ─── aippie_emperor_briefings ─────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS aippie_emperor_briefings (
  id                   uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id              uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  briefing_month       text NOT NULL DEFAULT to_char(now(), 'YYYY-MM'),
  bruto_balance_eur    numeric(14,2) DEFAULT 0,
  net_surplus_eur      numeric(14,2) DEFAULT 0,
  tax_summary          text,
  commerce_summary     text,
  defense_summary      text,
  health_summary       text,
  master_directive     text,
  created_at           timestamptz DEFAULT now(),
  UNIQUE(user_id, briefing_month)
);

CREATE INDEX IF NOT EXISTS idx_emperor_user_id ON aippie_emperor_briefings(user_id);
CREATE INDEX IF NOT EXISTS idx_emperor_month   ON aippie_emperor_briefings(briefing_month);

ALTER TABLE aippie_emperor_briefings ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_emperor" ON aippie_emperor_briefings;
CREATE POLICY "select_own_emperor" ON aippie_emperor_briefings FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_emperor" ON aippie_emperor_briefings;
CREATE POLICY "insert_own_emperor" ON aippie_emperor_briefings FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_emperor" ON aippie_emperor_briefings;
CREATE POLICY "update_own_emperor" ON aippie_emperor_briefings FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_emperor" ON aippie_emperor_briefings;
CREATE POLICY "delete_own_emperor" ON aippie_emperor_briefings FOR DELETE
  TO authenticated USING (auth.uid() = user_id);
