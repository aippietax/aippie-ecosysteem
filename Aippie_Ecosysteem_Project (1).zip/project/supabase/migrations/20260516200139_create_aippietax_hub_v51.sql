-- AippieTax AI Accountant Hub V51
-- Creates: tax_documents, voip_sessions, roadmap_phases with RLS and 10-Fasen seed data

-- tax_documents: corporate receipts/invoices with OCR results
CREATE TABLE IF NOT EXISTS tax_documents (
  id                uuid          PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id           uuid          REFERENCES auth.users(id) ON DELETE SET NULL,
  device_key        text          NOT NULL DEFAULT '',
  file_name         text          NOT NULL DEFAULT '',
  file_type         text          NOT NULL DEFAULT 'application/pdf',
  ocr_text          text          NOT NULL DEFAULT '',
  ocr_status        text          NOT NULL DEFAULT 'pending'
                                  CHECK (ocr_status IN ('pending','processing','complete','error')),
  tax_category      text          NOT NULL DEFAULT 'other'
                                  CHECK (tax_category IN ('expense','invoice','receipt','payroll','other')),
  amount_eur        numeric(12,2) NOT NULL DEFAULT 0,
  entity_type       text          NOT NULL DEFAULT 'SL'
                                  CHECK (entity_type IN ('SL','SRL','LLC','other')),
  quickbooks_synced boolean       NOT NULL DEFAULT false,
  created_at        timestamptz   NOT NULL DEFAULT now()
);

ALTER TABLE tax_documents ENABLE ROW LEVEL SECURITY;

CREATE POLICY "tax_documents_insert"
  ON tax_documents FOR INSERT
  TO anon, authenticated
  WITH CHECK (auth.uid() = user_id OR device_key != '');

CREATE POLICY "tax_documents_select"
  ON tax_documents FOR SELECT
  TO anon, authenticated
  USING (auth.uid() = user_id OR device_key != '');

CREATE POLICY "tax_documents_update"
  ON tax_documents FOR UPDATE
  TO anon, authenticated
  USING  (auth.uid() = user_id OR device_key != '')
  WITH CHECK (auth.uid() = user_id OR device_key != '');

CREATE POLICY "tax_documents_delete"
  ON tax_documents FOR DELETE
  TO anon, authenticated
  USING (auth.uid() = user_id OR device_key != '');

-- voip_sessions: encrypted VoIP call logs from the headset node
CREATE TABLE IF NOT EXISTS voip_sessions (
  id                 uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id            uuid        REFERENCES auth.users(id) ON DELETE SET NULL,
  device_key         text        NOT NULL DEFAULT '',
  client_name        text        NOT NULL DEFAULT '',
  destination_number text        NOT NULL DEFAULT '',
  session_status     text        NOT NULL DEFAULT 'dialing'
                                 CHECK (session_status IN ('dialing','connected','ended','failed')),
  duration_seconds   integer     NOT NULL DEFAULT 0,
  e2ee_fingerprint   text        NOT NULL DEFAULT '',
  created_at         timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE voip_sessions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "voip_sessions_insert"
  ON voip_sessions FOR INSERT
  TO anon, authenticated
  WITH CHECK (auth.uid() = user_id OR device_key != '');

CREATE POLICY "voip_sessions_select"
  ON voip_sessions FOR SELECT
  TO anon, authenticated
  USING (auth.uid() = user_id OR device_key != '');

-- roadmap_phases: 10-Fasen business evolution blueprint (read-only registry)
CREATE TABLE IF NOT EXISTS roadmap_phases (
  id             uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
  phase_number   integer     UNIQUE NOT NULL,
  title_nl       text        NOT NULL DEFAULT '',
  title_en       text        NOT NULL DEFAULT '',
  description_en text        NOT NULL DEFAULT '',
  status         text        NOT NULL DEFAULT 'planned'
                             CHECK (status IN ('active','planned','completed')),
  icon_key       text        NOT NULL DEFAULT 'zap',
  created_at     timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE roadmap_phases ENABLE ROW LEVEL SECURITY;

CREATE POLICY "roadmap_phases_select"
  ON roadmap_phases FOR SELECT
  TO anon, authenticated
  USING (true);

-- Seed 10-Fasen roadmap
INSERT INTO roadmap_phases (phase_number, title_nl, title_en, description_en, status, icon_key) VALUES
(1,  'Core AI Boekhouder',                  'Core AI Bookkeeper',              'Automated OCR expense parsing, receipt classification, and corporate ledger sync.',             'active',    'file-text'),
(2,  'Smart Home IoT',                      'Ambient Smart Home IoT',          'Smart home environment integration with push alerts to connected smart displays.',              'planned',   'home'),
(3,  'Beveiligd VoIP Netwerk',              'Secure Embedded VoIP',            'End-to-end encrypted peer-to-peer VoIP network with full call anonymity and privacy loops.',    'active',    'phone'),
(4,  'Autonome Campagne Generator',         'Campaign Generator',              'Autonomous ad campaign generator with cross-platform Google and Facebook Ads segmentation.',    'planned',   'megaphone'),
(5,  'B2B Partner Ledger',                  'B2B Partner Affiliate Ledger',    'Multi-agent commission tracking with automatic distribution to registered partner affiliates.', 'planned',   'users'),
(6,  'Live Conversational AI',              'Live Conversational AI',          'AI assistant executing database mutations natively via voice commands in real time.',            'active',    'mic'),
(7,  'Videoconferentie Suite',              'Encrypted Video Suite',           'In-app encrypted videoconferencing with native screensharing and session recording.',           'planned',   'video'),
(8,  'Multimedia Video Hub',                'Multimedia Video Hub',            'Cloud distribution connecting multimedia assets to external content delivery pointers.',         'planned',   'play-circle'),
(9,  'Daily Life Autopilot Hub',            'Daily Life Autopilot',            'Automated grocery ordering via Albert Heijn and Instacart APIs with smart scheduling.',         'planned',   'shopping-cart'),
(10, 'Gecertificeerde Autonome Accountant', 'Certified Autonomous Accountant', 'Real-time fiscal strategy auditing and automatic corporate tax filing declarations.',           'planned',   'shield-check')
ON CONFLICT (phase_number) DO NOTHING;
