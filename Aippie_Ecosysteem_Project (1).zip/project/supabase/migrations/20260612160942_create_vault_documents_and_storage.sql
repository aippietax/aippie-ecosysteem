-- ── Document Vault ─────────────────────────────────────────────────────────
CREATE TABLE vault_documents (
  id           uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id      uuid        NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  name         text        NOT NULL,
  size         bigint      NOT NULL DEFAULT 0,
  mime_type    text        NOT NULL DEFAULT 'application/octet-stream',
  storage_path text        NOT NULL,
  access_count int         NOT NULL DEFAULT 0,
  created_at   timestamptz DEFAULT now()
);

CREATE INDEX ON vault_documents (user_id);

ALTER TABLE vault_documents ENABLE ROW LEVEL SECURITY;

CREATE POLICY "select_own_vault_docs" ON vault_documents FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

CREATE POLICY "insert_own_vault_docs" ON vault_documents FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

CREATE POLICY "update_own_vault_docs" ON vault_documents FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

CREATE POLICY "delete_own_vault_docs" ON vault_documents FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

-- ── Storage bucket ───────────────────────────────────────────────────────────
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES (
  'vault_documents',
  'vault_documents',
  false,
  20971520,
  ARRAY[
    'application/pdf',
    'image/jpeg',
    'image/png',
    'image/webp',
    'image/gif',
    'text/plain'
  ]
)
ON CONFLICT (id) DO NOTHING;

-- Storage RLS: authenticated users can upload/read their own prefix
CREATE POLICY "vault_storage_select" ON storage.objects FOR SELECT
  TO authenticated USING (
    bucket_id = 'vault_documents' AND
    (storage.foldername(name))[1] = auth.uid()::text
  );

CREATE POLICY "vault_storage_insert" ON storage.objects FOR INSERT
  TO authenticated WITH CHECK (
    bucket_id = 'vault_documents' AND
    (storage.foldername(name))[1] = auth.uid()::text
  );

CREATE POLICY "vault_storage_delete" ON storage.objects FOR DELETE
  TO authenticated USING (
    bucket_id = 'vault_documents' AND
    (storage.foldername(name))[1] = auth.uid()::text
  );
