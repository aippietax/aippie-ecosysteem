CREATE TABLE IF NOT EXISTS pulse_readings (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  device_key   text NOT NULL DEFAULT 'anon',
  session_id   text NOT NULL DEFAULT 'anon',
  bpm          integer NOT NULL,
  spo2         integer NOT NULL,
  hrv_ms       integer,
  quality      text NOT NULL DEFAULT 'fair',
  created_at   timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE pulse_readings ENABLE ROW LEVEL SECURITY;

CREATE POLICY "insert_pulse_readings" ON pulse_readings
  FOR INSERT TO anon, authenticated WITH CHECK (true);

CREATE POLICY "select_pulse_readings" ON pulse_readings
  FOR SELECT TO anon, authenticated USING (true);
