/*
  # Add Trading Alpha Plan Tier

  ## Summary
  Extends the subscription system with a new premium plan tier for Aippie Trading Alpha,
  priced at €99.99/month.

  ## Changes
  - Adds 'trading_alpha' to the plan_tier check constraint on the subscriptions table
  - The new tier unlocks the live candlestick chart with AI signal overlays (BUY/SELL targets)

  ## Notes
  - Existing rows are unaffected
  - RLS policies remain unchanged — users can only see their own subscriptions
*/

DO $$
BEGIN
  -- Drop the old check constraint if it exists, then recreate with the new tier added
  IF EXISTS (
    SELECT 1 FROM information_schema.table_constraints
    WHERE table_name = 'subscriptions'
      AND constraint_name = 'subscriptions_plan_tier_check'
  ) THEN
    ALTER TABLE subscriptions DROP CONSTRAINT subscriptions_plan_tier_check;
  END IF;

  ALTER TABLE subscriptions
    ADD CONSTRAINT subscriptions_plan_tier_check
    CHECK (plan_tier IN ('turista_basic', 'corporate_b2b', 'premium_jurado', 'trading_alpha'));
END $$;
