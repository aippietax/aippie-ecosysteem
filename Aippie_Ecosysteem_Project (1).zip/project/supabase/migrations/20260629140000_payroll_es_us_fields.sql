/*
  # Add ES/US specific fields to payroll_employees

  ## Why
  payroll_employees originally only had NL-specific fields (bsn,
  apply_loonheffingskorting). Extending payroll to Spain and the US requires:
  - national_id: generic ID field for ES (DNI/NIE) and US (last 4 of SSN,
    stored partial by design — full SSN should never be stored in this table)
  - us_state: which US state's income tax table applies (states with no
    income tax, e.g. TX/FL/WA/NV, are valid and stored as such — 0% is a
    correct value here, not a missing one)

  ## Notes
  - jurisdiction column already exists and already supports 'ES'|'NL'|'US'
  - currency already exists; the application layer sets it to EUR or USD
    based on the client's jurisdiction
*/

ALTER TABLE payroll_employees
  ADD COLUMN IF NOT EXISTS national_id text,
  ADD COLUMN IF NOT EXISTS us_state text;
