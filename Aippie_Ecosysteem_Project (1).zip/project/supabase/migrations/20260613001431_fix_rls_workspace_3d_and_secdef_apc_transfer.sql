-- Fix 1 & 2: workspace_3d_sessions INSERT/UPDATE policies — scope to the session's host_pin
-- A user can only insert/update sessions where their own SecureChat PIN is the host.

DROP POLICY IF EXISTS "insert_workspace_session" ON public.workspace_3d_sessions;
DROP POLICY IF EXISTS "update_workspace_session" ON public.workspace_3d_sessions;

CREATE POLICY "insert_workspace_session" ON public.workspace_3d_sessions
  FOR INSERT TO authenticated
  WITH CHECK (
    host_pin = (
      SELECT pin_code FROM public.secure_chat_pins
      WHERE user_id = auth.uid()
      LIMIT 1
    )
  );

CREATE POLICY "update_workspace_session" ON public.workspace_3d_sessions
  FOR UPDATE TO authenticated
  USING (
    host_pin = (
      SELECT pin_code FROM public.secure_chat_pins
      WHERE user_id = auth.uid()
      LIMIT 1
    )
  )
  WITH CHECK (
    host_pin = (
      SELECT pin_code FROM public.secure_chat_pins
      WHERE user_id = auth.uid()
      LIMIT 1
    )
  );

-- Fix 3: apc_transfer_by_chat_pin — SECURITY DEFINER is intentional (needs cross-wallet write access)
-- but authenticated users should be the only callers. Revoke from PUBLIC to be explicit,
-- and convert to SECURITY INVOKER — the function already guards auth.uid() internally
-- so it does NOT need elevated privileges to bypass RLS.

CREATE OR REPLACE FUNCTION public.apc_transfer_by_chat_pin(
  p_to_pin   TEXT,
  p_amount   NUMERIC
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY INVOKER
SET search_path = public
AS $$
DECLARE
  v_from_id        UUID := auth.uid();
  v_to_id          UUID;
  v_sender_wallet  apc_wallets%ROWTYPE;
  v_recv_wallet    apc_wallets%ROWTYPE;
  v_fee            NUMERIC(18,4);
  v_net            NUMERIC(18,4);
  v_tx_out_id      UUID;
BEGIN
  IF v_from_id IS NULL THEN
    RETURN '{"ok":false,"error":"Niet ingelogd"}'::jsonb;
  END IF;

  -- Lookup recipient via SecureChat PIN
  SELECT user_id INTO v_to_id FROM secure_chat_pins WHERE pin_code = p_to_pin LIMIT 1;
  IF v_to_id IS NULL THEN
    RETURN '{"ok":false,"error":"SecureChat PIN niet gevonden"}'::jsonb;
  END IF;
  IF v_to_id = v_from_id THEN
    RETURN '{"ok":false,"error":"Kan niet naar jezelf sturen"}'::jsonb;
  END IF;
  IF p_amount <= 0 OR p_amount > 1000000 THEN
    RETURN '{"ok":false,"error":"Ongeldig bedrag"}'::jsonb;
  END IF;

  -- Get sender wallet
  SELECT * INTO v_sender_wallet FROM apc_wallets WHERE user_id = v_from_id FOR UPDATE;
  IF NOT FOUND THEN
    RETURN '{"ok":false,"error":"Jouw wallet niet gevonden"}'::jsonb;
  END IF;
  v_fee := ROUND(p_amount * 0.01, 4);
  v_net := p_amount - v_fee;
  IF v_sender_wallet.balance_apc < p_amount THEN
    RETURN '{"ok":false,"error":"Onvoldoende saldo"}'::jsonb;
  END IF;

  -- Deduct from sender
  UPDATE apc_wallets SET balance_apc = balance_apc - p_amount, updated_at = now() WHERE user_id = v_from_id;

  -- Credit receiver (create wallet if needed)
  INSERT INTO apc_wallets (user_id, balance_apc)
    VALUES (v_to_id, v_net)
    ON CONFLICT (user_id) DO UPDATE SET balance_apc = apc_wallets.balance_apc + v_net, updated_at = now()
    RETURNING * INTO v_recv_wallet;
  IF v_recv_wallet.id IS NULL THEN
    SELECT * INTO v_recv_wallet FROM apc_wallets WHERE user_id = v_to_id;
  END IF;

  -- Log sender debit
  INSERT INTO apc_transactions (wallet_id, user_id, type, amount_apc, fee_apc, counterpart_user_id, reference)
    VALUES (v_sender_wallet.id, v_from_id, 'transfer_out', -p_amount, v_fee, v_to_id,
            'SecureChat betaling naar PIN ' || p_to_pin)
    RETURNING id INTO v_tx_out_id;

  -- Log receiver credit
  INSERT INTO apc_transactions (wallet_id, user_id, type, amount_apc, fee_apc, counterpart_user_id, reference)
    VALUES (v_recv_wallet.id, v_to_id, 'transfer_in', v_net, 0, v_from_id,
            'SecureChat betaling ontvangen');

  -- Fee to treasury
  INSERT INTO apc_treasury_ledger (source_transaction_id, fee_type, amount_apc, from_user_id)
    VALUES (v_tx_out_id, 'p2p_fee_1pct', v_fee, v_from_id);

  RETURN jsonb_build_object('ok', true, 'sent', p_amount, 'net', v_net, 'fee', v_fee);
END;
$$;

REVOKE EXECUTE ON FUNCTION public.apc_transfer_by_chat_pin(TEXT, NUMERIC) FROM PUBLIC;
REVOKE EXECUTE ON FUNCTION public.apc_transfer_by_chat_pin(TEXT, NUMERIC) FROM anon;
GRANT  EXECUTE ON FUNCTION public.apc_transfer_by_chat_pin(TEXT, NUMERIC) TO authenticated;
