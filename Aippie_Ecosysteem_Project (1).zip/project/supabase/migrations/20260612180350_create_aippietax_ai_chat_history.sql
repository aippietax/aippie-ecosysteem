-- ── AippieTax AI Chat history ────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS aippietax_chat_messages (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  device_key  text NOT NULL,
  session_id  text NOT NULL,
  role        text NOT NULL CHECK (role IN ('user','assistant')),
  content     text NOT NULL,
  lang        text NOT NULL DEFAULT 'nl',
  created_at  timestamptz DEFAULT now()
);
ALTER TABLE aippietax_chat_messages ENABLE ROW LEVEL SECURITY;
CREATE POLICY "select_chat_own" ON aippietax_chat_messages FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "insert_chat_any" ON aippietax_chat_messages FOR INSERT TO anon, authenticated WITH CHECK (true);
CREATE POLICY "update_chat_any" ON aippietax_chat_messages FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
CREATE POLICY "delete_chat_any" ON aippietax_chat_messages FOR DELETE TO anon, authenticated USING (true);
