/*
  # V162 — Document Scanner & Investor Matchmaker tables
  AIPPIETAX S.A. · BANKEN-NIVEAU criteria

  ## New Tables

  ### doc_scanner_uploads
  Stores metadata for every document uploaded through the Sovereign Mail &
  Letter Document Scanner. The extracted OCR text is persisted so downstream
  processes (tax filing, corporate profiles) can consume it.
  Columns:
    - id               uuid PK
    - user_id          uuid → auth.users (owner)
    - file_name        text  — original filename
    - file_type        text  — 'pdf' | 'image' | 'camera'
    - page_count       int   — number of pages processed
    - ocr_text         text  — full extracted text
    - status           text  — 'uploading' | 'scanning' | 'complete' | 'error'
    - source_module    text  — 'aippiedev' | 'aippietax'
    - created_at       timestamptz

  ### investor_matchmaker_leads
  Stores investor leads discovered by the Autonomous AI Investor Matchmaker
  Radar, along with outreach status and generated pitch content.
  Columns:
    - id               uuid PK
    - user_id          uuid → auth.users (owner)
    - investor_name    text
    - fund_tier        text  — 'tier1_vc' | 'tier2_pe' | 'angel' | 'family_office'
    - focus_sectors    text[]
    - investment_range text
    - location         text
    - match_score      numeric(4,1)  — 0–100
    - pitch_letter     text          — AI-generated pitch text
    - outreach_status  text  — 'identified' | 'pitch_ready' | 'sent' | 'replied'
    - created_at       timestamptz

  ## Security
  Both tables enable RLS. Only the owning authenticated user can read/write
  their own rows.
*/

-- ── doc_scanner_uploads ────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS doc_scanner_uploads (
  id            uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id       uuid        NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  file_name     text        NOT NULL DEFAULT '',
  file_type     text        NOT NULL DEFAULT 'pdf',
  page_count    int         NOT NULL DEFAULT 1,
  ocr_text      text        NOT NULL DEFAULT '',
  status        text        NOT NULL DEFAULT 'uploading',
  source_module text        NOT NULL DEFAULT 'aippietax',
  created_at    timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE doc_scanner_uploads ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Owner can insert own scan uploads"
  ON doc_scanner_uploads FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Owner can select own scan uploads"
  ON doc_scanner_uploads FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Owner can update own scan uploads"
  ON doc_scanner_uploads FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- ── investor_matchmaker_leads ──────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS investor_matchmaker_leads (
  id               uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id          uuid        NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  investor_name    text        NOT NULL DEFAULT '',
  fund_tier        text        NOT NULL DEFAULT 'angel',
  focus_sectors    text[]      NOT NULL DEFAULT '{}',
  investment_range text        NOT NULL DEFAULT '',
  location         text        NOT NULL DEFAULT '',
  match_score      numeric(4,1) NOT NULL DEFAULT 0,
  pitch_letter     text        NOT NULL DEFAULT '',
  outreach_status  text        NOT NULL DEFAULT 'identified',
  created_at       timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE investor_matchmaker_leads ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Owner can insert own investor leads"
  ON investor_matchmaker_leads FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Owner can select own investor leads"
  ON investor_matchmaker_leads FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Owner can update own investor leads"
  ON investor_matchmaker_leads FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- ── Indexes ────────────────────────────────────────────────────────────────────
CREATE INDEX IF NOT EXISTS idx_doc_scanner_uploads_user
  ON doc_scanner_uploads (user_id, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_investor_leads_user
  ON investor_matchmaker_leads (user_id, match_score DESC);
