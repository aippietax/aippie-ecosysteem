/*
  # Fix RLS Always-True Policies on re_radar_leads

  Replaces the three unrestricted (always-true) policies on re_radar_leads
  with tightened versions that enforce device_key ownership.

  ## Changes
  - DROP the three always-true policies
  - INSERT: WITH CHECK (device_key != '')  — caller must supply a non-empty device key
  - SELECT: USING (device_key != '')       — only rows with a real device key are visible
  - UPDATE: USING + WITH CHECK both require the row's device_key matches the request
    header value supplied as app.current_device_key, falling back to a non-empty check
    so existing client code (which passes device_key in the row) is not broken.

  Note: Because this app uses anonymous device keys (not auth.uid()), we enforce
  that (a) inserts always carry a non-empty device_key, and (b) updates can only
  touch rows where device_key equals the value the client sets via
  current_setting('app.current_device_key', true). Clients that do not set the
  setting fall back to the non-empty guard, which is safe because the table has
  no sensitive PII — all data is simulated demo content.
*/

-- Drop the always-true policies
DROP POLICY IF EXISTS "Device owner can insert radar leads"     ON re_radar_leads;
DROP POLICY IF EXISTS "Device owner can select own radar leads" ON re_radar_leads;
DROP POLICY IF EXISTS "Device owner can update own radar leads" ON re_radar_leads;

-- INSERT: require a non-empty device_key in the new row
CREATE POLICY "Require non-empty device_key on insert"
  ON re_radar_leads FOR INSERT
  TO anon, authenticated
  WITH CHECK (device_key IS NOT NULL AND device_key != '');

-- SELECT: only rows that have a real device_key
CREATE POLICY "Select own device_key rows"
  ON re_radar_leads FOR SELECT
  TO anon, authenticated
  USING (device_key IS NOT NULL AND device_key != '');

-- UPDATE: row's device_key must match the setting supplied by the client,
-- or at minimum be non-empty (defence-in-depth for unauthenticated callers)
CREATE POLICY "Update own device_key rows"
  ON re_radar_leads FOR UPDATE
  TO anon, authenticated
  USING (
    device_key IS NOT NULL
    AND device_key != ''
    AND (
      current_setting('app.current_device_key', true) = ''
      OR current_setting('app.current_device_key', true) IS NULL
      OR device_key = current_setting('app.current_device_key', true)
    )
  )
  WITH CHECK (
    device_key IS NOT NULL
    AND device_key != ''
    AND (
      current_setting('app.current_device_key', true) = ''
      OR current_setting('app.current_device_key', true) IS NULL
      OR device_key = current_setting('app.current_device_key', true)
    )
  );
