
-- Aippie Energy Platform: realtime metering, CO2/ESG compliance, green certificate trading

CREATE TABLE energy_meter_readings (
  id             uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id        uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  meter_id       text NOT NULL,
  meter_name     text NOT NULL,
  location       text,
  kwh_reading    numeric(12,3) NOT NULL DEFAULT 0,
  peak_kw        numeric(10,3),
  power_factor   numeric(4,3),
  voltage        numeric(7,2),
  renewable_pct  numeric(5,2) DEFAULT 0,
  recorded_at    timestamptz DEFAULT now()
);

ALTER TABLE energy_meter_readings ENABLE ROW LEVEL SECURITY;
CREATE POLICY "select_own_energy_readings" ON energy_meter_readings FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "insert_own_energy_readings" ON energy_meter_readings FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "update_own_energy_readings" ON energy_meter_readings FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE POLICY "delete_own_energy_readings" ON energy_meter_readings FOR DELETE TO authenticated USING (auth.uid() = user_id);

CREATE TABLE co2_emissions_log (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id         uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  period_start    date NOT NULL,
  period_end      date NOT NULL,
  electricity_kwh numeric(12,3) DEFAULT 0,
  gas_m3          numeric(12,3) DEFAULT 0,
  logistics_km    numeric(12,3) DEFAULT 0,
  co2_tonnes      numeric(10,4) DEFAULT 0,
  scope1          numeric(10,4) DEFAULT 0,
  scope2          numeric(10,4) DEFAULT 0,
  scope3          numeric(10,4) DEFAULT 0,
  notes           text,
  created_at      timestamptz DEFAULT now()
);

ALTER TABLE co2_emissions_log ENABLE ROW LEVEL SECURITY;
CREATE POLICY "select_own_co2_log" ON co2_emissions_log FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "insert_own_co2_log" ON co2_emissions_log FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "update_own_co2_log" ON co2_emissions_log FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE POLICY "delete_own_co2_log" ON co2_emissions_log FOR DELETE TO authenticated USING (auth.uid() = user_id);

CREATE TABLE esg_reports (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id       uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  report_name   text NOT NULL,
  report_type   text NOT NULL DEFAULT 'annual',
  standard      text NOT NULL DEFAULT 'GRI',
  status        text NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','submitted','certified')),
  co2_total     numeric(10,4),
  renewable_pct numeric(5,2),
  report_data   jsonb DEFAULT '{}',
  generated_at  timestamptz DEFAULT now()
);

ALTER TABLE esg_reports ENABLE ROW LEVEL SECURITY;
CREATE POLICY "select_own_esg_reports" ON esg_reports FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "insert_own_esg_reports" ON esg_reports FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "update_own_esg_reports" ON esg_reports FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE POLICY "delete_own_esg_reports" ON esg_reports FOR DELETE TO authenticated USING (auth.uid() = user_id);

CREATE TABLE green_certificates (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id     uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  cert_type   text NOT NULL CHECK (cert_type IN ('GO','EUA','REGO','VCS')),
  quantity    numeric(12,3) NOT NULL,
  vintage_year integer,
  source_type text CHECK (source_type IN ('solar','wind','hydro','biomass')),
  registry_id text,
  status      text NOT NULL DEFAULT 'available' CHECK (status IN ('available','listed','sold')),
  cost_basis  numeric(10,4),
  created_at  timestamptz DEFAULT now()
);

ALTER TABLE green_certificates ENABLE ROW LEVEL SECURITY;
CREATE POLICY "select_own_green_certs" ON green_certificates FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "insert_own_green_certs" ON green_certificates FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "update_own_green_certs" ON green_certificates FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE POLICY "delete_own_green_certs" ON green_certificates FOR DELETE TO authenticated USING (auth.uid() = user_id);

CREATE TABLE certificate_trades (
  id             uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id        uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  cert_id        uuid REFERENCES green_certificates(id) ON DELETE SET NULL,
  trade_type     text NOT NULL CHECK (trade_type IN ('sell','buy')),
  quantity       numeric(12,3) NOT NULL,
  price_per_unit numeric(10,4) NOT NULL,
  total_eur      numeric(12,4),
  market         text NOT NULL DEFAULT 'EU-ETS' CHECK (market IN ('EU-ETS','REGO','VCS','GO')),
  status         text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','executed','cancelled')),
  executed_at    timestamptz
);

ALTER TABLE certificate_trades ENABLE ROW LEVEL SECURITY;
CREATE POLICY "select_own_cert_trades" ON certificate_trades FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "insert_own_cert_trades" ON certificate_trades FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "update_own_cert_trades" ON certificate_trades FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE POLICY "delete_own_cert_trades" ON certificate_trades FOR DELETE TO authenticated USING (auth.uid() = user_id);
