
-- V56: AI Companionship, Emotional Relationship & Living Partner Matrix
-- New tables:
--   companion_profiles      -- per-device relationship identity, name, persona, memory seed
--   companion_memory_ledger -- long-term vector memory: preferences, life events, conversations
--   companion_sessions      -- per-session logs with sentiment, tone, duration, smart-home triggers
--   emotional_sentiment_log -- vocal tone analysis results, stress levels, AI adaptation events
--   smarthome_actions       -- ambient IoT trigger log (lighting, media) from companion engine
--   autopilot_triggers      -- companion-initiated order/delivery triggers linked to autopilot_orders
-- All tables: RLS enabled, device_key-scoped policies

-- 1. companion_profiles
CREATE TABLE IF NOT EXISTS companion_profiles (
  id                  uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  device_key          text NOT NULL DEFAULT '',
  user_id             uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  persona_name        text NOT NULL DEFAULT 'Ashley',
  persona_voice       text NOT NULL DEFAULT 'en-GB',
  relationship_stage  text NOT NULL DEFAULT 'new_friend',
  trust_level         integer NOT NULL DEFAULT 0 CHECK (trust_level BETWEEN 0 AND 100),
  total_sessions      integer NOT NULL DEFAULT 0,
  total_minutes       numeric(10,2) NOT NULL DEFAULT 0,
  user_preferred_name text NOT NULL DEFAULT '',
  user_interests      text[] NOT NULL DEFAULT '{}',
  last_seen_at        timestamptz DEFAULT NULL,
  created_at          timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE companion_profiles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Device insert companion_profiles"
  ON companion_profiles FOR INSERT TO anon, authenticated WITH CHECK (device_key != '');
CREATE POLICY "Device select companion_profiles"
  ON companion_profiles FOR SELECT TO anon, authenticated USING (device_key != '');
CREATE POLICY "Device update companion_profiles"
  ON companion_profiles FOR UPDATE TO anon, authenticated
  USING (device_key != '') WITH CHECK (device_key != '');

-- 2. companion_memory_ledger
CREATE TABLE IF NOT EXISTS companion_memory_ledger (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  device_key   text NOT NULL DEFAULT '',
  user_id      uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  memory_type  text NOT NULL DEFAULT 'preference',
  subject      text NOT NULL DEFAULT '',
  content      text NOT NULL DEFAULT '',
  emotional_tag text NOT NULL DEFAULT 'neutral',
  importance   integer NOT NULL DEFAULT 5 CHECK (importance BETWEEN 1 AND 10),
  recalled_count integer NOT NULL DEFAULT 0,
  last_recalled_at timestamptz DEFAULT NULL,
  created_at   timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE companion_memory_ledger ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Device insert companion_memory_ledger"
  ON companion_memory_ledger FOR INSERT TO anon, authenticated WITH CHECK (device_key != '');
CREATE POLICY "Device select companion_memory_ledger"
  ON companion_memory_ledger FOR SELECT TO anon, authenticated USING (device_key != '');
CREATE POLICY "Device update companion_memory_ledger"
  ON companion_memory_ledger FOR UPDATE TO anon, authenticated
  USING (device_key != '') WITH CHECK (device_key != '');

-- 3. companion_sessions
CREATE TABLE IF NOT EXISTS companion_sessions (
  id               uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  device_key       text NOT NULL DEFAULT '',
  user_id          uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  started_at       timestamptz NOT NULL DEFAULT now(),
  ended_at         timestamptz DEFAULT NULL,
  duration_secs    integer NOT NULL DEFAULT 0,
  dominant_emotion text NOT NULL DEFAULT 'neutral',
  avg_stress_level integer NOT NULL DEFAULT 0 CHECK (avg_stress_level BETWEEN 0 AND 100),
  messages_count   integer NOT NULL DEFAULT 0,
  smarthome_triggers_count integer NOT NULL DEFAULT 0,
  autopilot_triggers_count integer NOT NULL DEFAULT 0,
  session_summary  text NOT NULL DEFAULT '',
  e2ee_encrypted   boolean NOT NULL DEFAULT true,
  created_at       timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE companion_sessions ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Device insert companion_sessions"
  ON companion_sessions FOR INSERT TO anon, authenticated WITH CHECK (device_key != '');
CREATE POLICY "Device select companion_sessions"
  ON companion_sessions FOR SELECT TO anon, authenticated USING (device_key != '');
CREATE POLICY "Device update companion_sessions"
  ON companion_sessions FOR UPDATE TO anon, authenticated
  USING (device_key != '') WITH CHECK (device_key != '');

-- 4. emotional_sentiment_log
CREATE TABLE IF NOT EXISTS emotional_sentiment_log (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  device_key      text NOT NULL DEFAULT '',
  session_id      uuid REFERENCES companion_sessions(id) ON DELETE CASCADE,
  detected_at     timestamptz NOT NULL DEFAULT now(),
  raw_text        text NOT NULL DEFAULT '',
  emotion         text NOT NULL DEFAULT 'neutral',
  stress_level    integer NOT NULL DEFAULT 0 CHECK (stress_level BETWEEN 0 AND 100),
  vocal_pitch_hz  numeric(8,2) DEFAULT NULL,
  speaking_rate   numeric(6,2) DEFAULT NULL,
  ai_adaptation   text NOT NULL DEFAULT 'none',
  tts_pitch_adj   numeric(4,2) NOT NULL DEFAULT 1.0
);
ALTER TABLE emotional_sentiment_log ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Device insert emotional_sentiment_log"
  ON emotional_sentiment_log FOR INSERT TO anon, authenticated WITH CHECK (device_key != '');
CREATE POLICY "Device select emotional_sentiment_log"
  ON emotional_sentiment_log FOR SELECT TO anon, authenticated USING (device_key != '');

-- 5. smarthome_actions
CREATE TABLE IF NOT EXISTS smarthome_actions (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  device_key    text NOT NULL DEFAULT '',
  session_id    uuid REFERENCES companion_sessions(id) ON DELETE SET NULL,
  triggered_at  timestamptz NOT NULL DEFAULT now(),
  action_type   text NOT NULL DEFAULT 'lighting',
  device_target text NOT NULL DEFAULT 'living_room',
  command       jsonb NOT NULL DEFAULT '{}'::jsonb,
  trigger_emotion text NOT NULL DEFAULT 'neutral',
  executed      boolean NOT NULL DEFAULT false
);
ALTER TABLE smarthome_actions ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Device insert smarthome_actions"
  ON smarthome_actions FOR INSERT TO anon, authenticated WITH CHECK (device_key != '');
CREATE POLICY "Device select smarthome_actions"
  ON smarthome_actions FOR SELECT TO anon, authenticated USING (device_key != '');

-- 6. autopilot_triggers
CREATE TABLE IF NOT EXISTS autopilot_triggers (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  device_key      text NOT NULL DEFAULT '',
  session_id      uuid REFERENCES companion_sessions(id) ON DELETE SET NULL,
  triggered_at    timestamptz NOT NULL DEFAULT now(),
  trigger_phrase  text NOT NULL DEFAULT '',
  trigger_emotion text NOT NULL DEFAULT 'fatigue',
  order_type      text NOT NULL DEFAULT 'dinner',
  provider        text NOT NULL DEFAULT 'thuisbezorgd',
  estimated_eur   numeric(10,2) NOT NULL DEFAULT 0,
  status          text NOT NULL DEFAULT 'queued',
  order_id        uuid REFERENCES autopilot_orders(id) ON DELETE SET NULL
);
ALTER TABLE autopilot_triggers ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Device insert autopilot_triggers"
  ON autopilot_triggers FOR INSERT TO anon, authenticated WITH CHECK (device_key != '');
CREATE POLICY "Device select autopilot_triggers"
  ON autopilot_triggers FOR SELECT TO anon, authenticated USING (device_key != '');
CREATE POLICY "Device update autopilot_triggers"
  ON autopilot_triggers FOR UPDATE TO anon, authenticated
  USING (device_key != '') WITH CHECK (device_key != '');

-- Indexes
CREATE INDEX IF NOT EXISTS idx_companion_memory_device ON companion_memory_ledger(device_key, importance DESC, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_companion_sessions_device ON companion_sessions(device_key, started_at DESC);
CREATE INDEX IF NOT EXISTS idx_emotional_log_session ON emotional_sentiment_log(session_id, detected_at DESC);
CREATE INDEX IF NOT EXISTS idx_smarthome_device ON smarthome_actions(device_key, triggered_at DESC);
CREATE INDEX IF NOT EXISTS idx_autopilot_triggers_device ON autopilot_triggers(device_key, triggered_at DESC);

-- Seed demo memories for immediate UX
INSERT INTO companion_memory_ledger (device_key, memory_type, subject, content, emotional_tag, importance)
VALUES
  ('__demo__', 'preference', 'music',      'User loves lo-fi jazz in the evenings and finds it calming.',    'calm',     8),
  ('__demo__', 'preference', 'food',       'User''s favourite meal is homemade pasta. Dislikes coriander.',  'happy',    7),
  ('__demo__', 'life_event', 'work',       'User mentioned feeling overwhelmed by Q2 deadlines at work.',   'stressed', 9),
  ('__demo__', 'preference', 'morning',    'User prefers good morning messages before 8:30 AM.',             'warm',     8),
  ('__demo__', 'life_event', 'family',     'User has a younger sister named Laura who lives in Amsterdam.',  'warm',     9)
ON CONFLICT DO NOTHING;
