/*
  # Create aippie_darkpool_liquidity table

  ## Summary
  Stores simulated institutional dark pool block trade observations used by the
  Aippie AI Front-Running Dispatch engine inside the Trading Alpha tab.
  Each row represents a detected hidden block order before public exchange settlement.

  ## New Table: aippie_darkpool_liquidity
  - `id`              uuid PK
  - `ticker`          text — stock symbol e.g. TSLA
  - `direction`       text — BUY | SELL
  - `block_size_usd`  numeric — estimated USD value of the hidden order
  - `momentum_pct`    numeric — dark pool momentum strength 0.0–100.0
  - `venue`           text — simulated dark pool venue name
  - `institution`     text — institutional actor label (anonymous)
  - `price_hint`      numeric — estimated fill price
  - `alert_fired`     boolean — whether a front-run alert has been dispatched
  - `created_at`      timestamptz

  ## Security
  - RLS enabled
  - Public read-only — dark pool data is non-personal market simulation data
  - No writes allowed from client (insert-only via service role / seed)

  ## Seed Data
  10 realistic dark pool block trade observations.
*/

CREATE TABLE IF NOT EXISTS aippie_darkpool_liquidity (
  id             uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
  ticker         text        NOT NULL DEFAULT '',
  direction      text        NOT NULL DEFAULT 'BUY' CHECK (direction IN ('BUY','SELL')),
  block_size_usd numeric     NOT NULL DEFAULT 0,
  momentum_pct   numeric     NOT NULL DEFAULT 0 CHECK (momentum_pct >= 0 AND momentum_pct <= 100),
  venue          text        NOT NULL DEFAULT 'CrossFinder',
  institution    text        NOT NULL DEFAULT 'Institutional Block A',
  price_hint     numeric     NOT NULL DEFAULT 0,
  alert_fired    boolean     NOT NULL DEFAULT false,
  created_at     timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE aippie_darkpool_liquidity ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Public can read dark pool ticks"
  ON aippie_darkpool_liquidity FOR SELECT
  TO anon, authenticated
  USING (true);

-- Seed realistic dark pool block observations
INSERT INTO aippie_darkpool_liquidity
  (ticker, direction, block_size_usd, momentum_pct, venue, institution, price_hint, alert_fired, created_at)
VALUES
  ('TSLA', 'BUY',  182400000, 94.7, 'CrossFinder',    'Vanguard Institutional',     182.10, true,  now() - interval '2 minutes'),
  ('NVDA', 'BUY',  340000000, 97.2, 'Liquidnet',      'BlackRock Alpha Fund',        489.40, true,  now() - interval '5 minutes'),
  ('AAPL', 'SELL', 210000000, 91.8, 'IEX Dark',       'JPMorgan Asset Mgmt',         191.80, false, now() - interval '9 minutes'),
  ('MSFT', 'BUY',  155000000, 88.4, 'CrossFinder',    'Fidelity Investments',        416.20, false, now() - interval '14 minutes'),
  ('AMZN', 'SELL', 97000000,  85.1, 'BATS Dark',      'Goldman Sachs Prop Desk',     179.60, false, now() - interval '21 minutes'),
  ('NVDA', 'BUY',  480000000, 98.1, 'Liquidnet',      'Norges Bank Investment Mgmt', 492.00, true,  now() - interval '28 minutes'),
  ('TSLA', 'SELL', 88000000,  86.3, 'IEX Dark',       'Citadel Securities',          244.70, false, now() - interval '35 minutes'),
  ('AAPL', 'BUY',  310000000, 93.5, 'CrossFinder',    'State Street Global',         188.90, true,  now() - interval '42 minutes'),
  ('MSFT', 'BUY',  220000000, 95.9, 'BATS Dark',      'Capital Group',               417.30, true,  now() - interval '51 minutes'),
  ('AMZN', 'BUY',  140000000, 89.7, 'Liquidnet',      'T. Rowe Price',               181.20, false, now() - interval '63 minutes');
