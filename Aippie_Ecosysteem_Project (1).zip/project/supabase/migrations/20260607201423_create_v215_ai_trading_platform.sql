
-- V215: Non-Custodial Multi-Asset AI Trading & Portfolio Advisor Platform

CREATE TABLE IF NOT EXISTS trading_broker_connections (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id       uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  broker        text NOT NULL CHECK (broker IN ('binance','bybit','interactive_brokers','degiro')),
  label         text NOT NULL DEFAULT '',
  api_key_hint  text NOT NULL DEFAULT '',  -- last 4 chars only, never store full key
  permissions   text[] NOT NULL DEFAULT ARRAY['read','trade'],
  withdraw_locked boolean NOT NULL DEFAULT true,
  is_active     boolean NOT NULL DEFAULT true,
  connected_at  timestamptz NOT NULL DEFAULT now(),
  UNIQUE(user_id, broker)
);

ALTER TABLE trading_broker_connections ENABLE ROW LEVEL SECURITY;

CREATE POLICY "select_own_connections" ON trading_broker_connections FOR SELECT
  TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "insert_own_connections" ON trading_broker_connections FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "update_own_connections" ON trading_broker_connections FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE POLICY "delete_own_connections" ON trading_broker_connections FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

-- Autonomous trade execution log
CREATE TABLE IF NOT EXISTS trading_execution_log (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id       uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  broker        text NOT NULL,
  asset         text NOT NULL,
  direction     text NOT NULL CHECK (direction IN ('BUY','SELL')),
  quantity      numeric(18,8) NOT NULL,
  price         numeric(18,4) NOT NULL,
  pnl           numeric(18,4),
  status        text NOT NULL DEFAULT 'FILLED' CHECK (status IN ('PENDING','FILLED','PARTIAL','CANCELLED')),
  loop_type     text NOT NULL DEFAULT 'IN' CHECK (loop_type IN ('IN','OUT','REBALANCE')),
  executed_at   timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE trading_execution_log ENABLE ROW LEVEL SECURITY;

CREATE POLICY "select_own_trades" ON trading_execution_log FOR SELECT
  TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "insert_own_trades" ON trading_execution_log FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "update_own_trades" ON trading_execution_log FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE POLICY "delete_own_trades" ON trading_execution_log FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

-- Portfolio snapshots
CREATE TABLE IF NOT EXISTS trading_portfolio_snapshots (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id       uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  total_value   numeric(18,2) NOT NULL,
  btc_pct       numeric(5,2),
  eth_pct       numeric(5,2),
  stocks_pct    numeric(5,2),
  cash_pct      numeric(5,2),
  daily_pnl     numeric(18,2),
  performance_fee numeric(18,2),
  snapshot_at   timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE trading_portfolio_snapshots ENABLE ROW LEVEL SECURITY;

CREATE POLICY "select_own_snapshots" ON trading_portfolio_snapshots FOR SELECT
  TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "insert_own_snapshots" ON trading_portfolio_snapshots FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "update_own_snapshots" ON trading_portfolio_snapshots FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE POLICY "delete_own_snapshots" ON trading_portfolio_snapshots FOR DELETE
  TO authenticated USING (auth.uid() = user_id);
