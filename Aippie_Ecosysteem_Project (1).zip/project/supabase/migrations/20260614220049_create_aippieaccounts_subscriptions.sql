-- AippieAccounts subscription system

CREATE TABLE IF NOT EXISTS aippieaccounts_subscriptions (
  id                     uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id                uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  plan                   text NOT NULL CHECK (plan IN ('starter','business','enterprise')),
  billing_cycle          text NOT NULL CHECK (billing_cycle IN ('monthly','yearly')),
  price_eur              numeric(10,2) NOT NULL,
  status                 text NOT NULL DEFAULT 'trial' CHECK (status IN ('trial','active','cancelled','expired')),
  trial_ends_at          timestamptz,
  current_period_end     timestamptz,
  stripe_customer_id     text,
  stripe_subscription_id text,
  created_at             timestamptz DEFAULT now()
);

ALTER TABLE aippieaccounts_subscriptions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "select_own_subscription" ON aippieaccounts_subscriptions
  FOR SELECT TO authenticated USING (auth.uid() = user_id);

CREATE POLICY "insert_own_subscription" ON aippieaccounts_subscriptions
  FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);

CREATE POLICY "update_own_subscription" ON aippieaccounts_subscriptions
  FOR UPDATE TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "delete_own_subscription" ON aippieaccounts_subscriptions
  FOR DELETE TO authenticated USING (auth.uid() = user_id);

-- Index for fast lookup
CREATE INDEX IF NOT EXISTS idx_aippieaccounts_subs_user ON aippieaccounts_subscriptions (user_id);
