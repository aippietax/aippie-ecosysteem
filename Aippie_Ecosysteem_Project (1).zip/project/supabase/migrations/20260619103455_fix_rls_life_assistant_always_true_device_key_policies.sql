-- Drop all always-true policies on the three life assistant tables

-- shopping_list
DROP POLICY IF EXISTS "insert_own_shopping"  ON shopping_list;
DROP POLICY IF EXISTS "update_own_shopping"  ON shopping_list;
DROP POLICY IF EXISTS "delete_own_shopping"  ON shopping_list;
DROP POLICY IF EXISTS "anon_insert_shopping" ON shopping_list;

-- health_log
DROP POLICY IF EXISTS "insert_own_health"  ON health_log;
DROP POLICY IF EXISTS "update_own_health"  ON health_log;
DROP POLICY IF EXISTS "delete_own_health"  ON health_log;
DROP POLICY IF EXISTS "anon_insert_health" ON health_log;

-- la_context_log
DROP POLICY IF EXISTS "insert_own_context"  ON la_context_log;
DROP POLICY IF EXISTS "anon_insert_context" ON la_context_log;

-- ─────────────────────────────────────────────────────────────────────────────
-- shopping_list — device_key scoped policies
-- ─────────────────────────────────────────────────────────────────────────────
CREATE POLICY "insert_own_shopping" ON shopping_list
  FOR INSERT TO authenticated
  WITH CHECK (device_key = (current_setting('request.headers', true)::json->>'x-device-key'));

CREATE POLICY "update_own_shopping" ON shopping_list
  FOR UPDATE TO authenticated
  USING  (device_key = (current_setting('request.headers', true)::json->>'x-device-key'))
  WITH CHECK (device_key = (current_setting('request.headers', true)::json->>'x-device-key'));

CREATE POLICY "delete_own_shopping" ON shopping_list
  FOR DELETE TO authenticated
  USING (device_key = (current_setting('request.headers', true)::json->>'x-device-key'));

-- anon insert: device_key must be present and non-empty
CREATE POLICY "anon_insert_shopping" ON shopping_list
  FOR INSERT TO anon
  WITH CHECK (
    device_key IS NOT NULL
    AND device_key <> ''
    AND device_key = (current_setting('request.headers', true)::json->>'x-device-key')
  );

-- ─────────────────────────────────────────────────────────────────────────────
-- health_log — device_key scoped policies
-- ─────────────────────────────────────────────────────────────────────────────
CREATE POLICY "insert_own_health" ON health_log
  FOR INSERT TO authenticated
  WITH CHECK (device_key = (current_setting('request.headers', true)::json->>'x-device-key'));

CREATE POLICY "update_own_health" ON health_log
  FOR UPDATE TO authenticated
  USING  (device_key = (current_setting('request.headers', true)::json->>'x-device-key'))
  WITH CHECK (device_key = (current_setting('request.headers', true)::json->>'x-device-key'));

CREATE POLICY "delete_own_health" ON health_log
  FOR DELETE TO authenticated
  USING (device_key = (current_setting('request.headers', true)::json->>'x-device-key'));

CREATE POLICY "anon_insert_health" ON health_log
  FOR INSERT TO anon
  WITH CHECK (
    device_key IS NOT NULL
    AND device_key <> ''
    AND device_key = (current_setting('request.headers', true)::json->>'x-device-key')
  );

-- ─────────────────────────────────────────────────────────────────────────────
-- la_context_log — device_key scoped policies
-- ─────────────────────────────────────────────────────────────────────────────
CREATE POLICY "insert_own_context" ON la_context_log
  FOR INSERT TO authenticated
  WITH CHECK (device_key = (current_setting('request.headers', true)::json->>'x-device-key'));

CREATE POLICY "anon_insert_context" ON la_context_log
  FOR INSERT TO anon
  WITH CHECK (
    device_key IS NOT NULL
    AND device_key <> ''
    AND device_key = (current_setting('request.headers', true)::json->>'x-device-key')
  );
