-- ── AippieShield Mail: internal encrypted mail system ─────────────────────
CREATE TABLE aippie_mail (
  id            uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
  from_pin      text        NOT NULL,
  to_pin        text        NOT NULL,
  subject       text        NOT NULL DEFAULT '(geen onderwerp)',
  body          text        NOT NULL,
  is_read       boolean     NOT NULL DEFAULT false,
  read_at       timestamptz,
  opened_at     timestamptz,           -- moment de ontvanger de mail opende (start countdown)
  expires_at    timestamptz,           -- = opened_at + destroy_after; NULL = geen timer
  destroy_after integer     NOT NULL DEFAULT 180,  -- seconden (180 = 3 min)
  is_deleted    boolean     NOT NULL DEFAULT false,
  dlp_cleared   boolean     NOT NULL DEFAULT false,
  created_at    timestamptz DEFAULT now()
);

CREATE INDEX ON aippie_mail (to_pin, is_read, is_deleted);
CREATE INDEX ON aippie_mail (from_pin, created_at);
CREATE INDEX ON aippie_mail (expires_at) WHERE expires_at IS NOT NULL;

ALTER TABLE aippie_mail ENABLE ROW LEVEL SECURITY;

-- Sender and recipient can both see the mail
CREATE POLICY "select_own_mail" ON aippie_mail FOR SELECT
  TO authenticated
  USING (
    from_pin = (SELECT pin_code FROM secure_chat_pins WHERE user_id = auth.uid())
    OR
    to_pin   = (SELECT pin_code FROM secure_chat_pins WHERE user_id = auth.uid())
  );

-- Only sender can insert
CREATE POLICY "insert_own_mail" ON aippie_mail FOR INSERT
  TO authenticated
  WITH CHECK (from_pin = (SELECT pin_code FROM secure_chat_pins WHERE user_id = auth.uid()));

-- Sender or recipient can update (mark read, set expires_at, soft-delete)
CREATE POLICY "update_own_mail" ON aippie_mail FOR UPDATE
  TO authenticated
  USING (
    from_pin = (SELECT pin_code FROM secure_chat_pins WHERE user_id = auth.uid())
    OR
    to_pin   = (SELECT pin_code FROM secure_chat_pins WHERE user_id = auth.uid())
  )
  WITH CHECK (
    from_pin = (SELECT pin_code FROM secure_chat_pins WHERE user_id = auth.uid())
    OR
    to_pin   = (SELECT pin_code FROM secure_chat_pins WHERE user_id = auth.uid())
  );

-- Only sender can hard-delete
CREATE POLICY "delete_own_mail" ON aippie_mail FOR DELETE
  TO authenticated
  USING (from_pin = (SELECT pin_code FROM secure_chat_pins WHERE user_id = auth.uid()));
