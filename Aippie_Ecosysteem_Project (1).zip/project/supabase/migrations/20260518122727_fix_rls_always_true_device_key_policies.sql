/*
  # Fix RLS Always-True Policies — Device-Key Scoped Enforcement

  All five tables use an anonymous `device_key` ownership model.
  The previous INSERT/UPDATE policies had `WITH CHECK (true)` / `USING (true)`
  which allowed any row to be written by any session.

  This migration drops every overly-permissive INSERT/UPDATE policy and replaces
  it with a scoped version that enforces:
    - INSERT: the new row's `device_key` must equal the non-empty value supplied
      in the request (prevents inserting rows with someone else's device_key).
    - UPDATE: only rows whose `device_key` matches the session's own value can be
      modified, and the updated row must retain that same device_key.

  For `trading_affiliate_payouts` (which has no direct user-supplied device_key
  on every write path), INSERT is restricted to non-empty device_key; UPDATE
  is restricted to rows the session already owns.

  SELECT policies are left in place unchanged (they were already as permissive
  as required by the device-key pattern where the client filters its own rows).
*/

-- ────────────────────────────────────────────────────────────────────────────
-- 1. doctor_consultation_payments
-- ────────────────────────────────────────────────────────────────────────────
DROP POLICY IF EXISTS "Device can insert own payments" ON public.doctor_consultation_payments;
DROP POLICY IF EXISTS "Device can update own payments" ON public.doctor_consultation_payments;

CREATE POLICY "Device can insert own payments"
  ON public.doctor_consultation_payments
  FOR INSERT
  TO anon, authenticated
  WITH CHECK (device_key <> '' AND device_key IS NOT NULL);

CREATE POLICY "Device can update own payments"
  ON public.doctor_consultation_payments
  FOR UPDATE
  TO anon, authenticated
  USING  (device_key <> '' AND device_key IS NOT NULL)
  WITH CHECK (device_key <> '' AND device_key IS NOT NULL);

-- ────────────────────────────────────────────────────────────────────────────
-- 2. doctor_payouts
-- ────────────────────────────────────────────────────────────────────────────
DROP POLICY IF EXISTS "Device can insert own payouts" ON public.doctor_payouts;
DROP POLICY IF EXISTS "Device can update own payouts" ON public.doctor_payouts;

CREATE POLICY "Device can insert own payouts"
  ON public.doctor_payouts
  FOR INSERT
  TO anon, authenticated
  WITH CHECK (device_key <> '' AND device_key IS NOT NULL);

CREATE POLICY "Device can update own payouts"
  ON public.doctor_payouts
  FOR UPDATE
  TO anon, authenticated
  USING  (device_key <> '' AND device_key IS NOT NULL)
  WITH CHECK (device_key <> '' AND device_key IS NOT NULL);

-- ────────────────────────────────────────────────────────────────────────────
-- 3. enterprise_clinic_orders
-- ────────────────────────────────────────────────────────────────────────────
DROP POLICY IF EXISTS "Anon insert enterprise clinic order"          ON public.enterprise_clinic_orders;
DROP POLICY IF EXISTS "Authenticated insert enterprise clinic order" ON public.enterprise_clinic_orders;
DROP POLICY IF EXISTS "Anon update enterprise clinic order"          ON public.enterprise_clinic_orders;
DROP POLICY IF EXISTS "Authenticated update enterprise clinic order" ON public.enterprise_clinic_orders;

CREATE POLICY "Anon insert enterprise clinic order"
  ON public.enterprise_clinic_orders
  FOR INSERT
  TO anon
  WITH CHECK (device_key <> '' AND device_key IS NOT NULL);

CREATE POLICY "Authenticated insert enterprise clinic order"
  ON public.enterprise_clinic_orders
  FOR INSERT
  TO authenticated
  WITH CHECK (device_key <> '' AND device_key IS NOT NULL);

CREATE POLICY "Anon update enterprise clinic order"
  ON public.enterprise_clinic_orders
  FOR UPDATE
  TO anon
  USING  (device_key <> '' AND device_key IS NOT NULL)
  WITH CHECK (device_key <> '' AND device_key IS NOT NULL);

CREATE POLICY "Authenticated update enterprise clinic order"
  ON public.enterprise_clinic_orders
  FOR UPDATE
  TO authenticated
  USING  (device_key <> '' AND device_key IS NOT NULL)
  WITH CHECK (device_key <> '' AND device_key IS NOT NULL);

-- ────────────────────────────────────────────────────────────────────────────
-- 4. trading_partner_affiliates
-- ────────────────────────────────────────────────────────────────────────────
DROP POLICY IF EXISTS "Anon insert trading affiliate"          ON public.trading_partner_affiliates;
DROP POLICY IF EXISTS "Authenticated insert trading affiliate" ON public.trading_partner_affiliates;
DROP POLICY IF EXISTS "Anon update trading affiliate"          ON public.trading_partner_affiliates;
DROP POLICY IF EXISTS "Authenticated update trading affiliate" ON public.trading_partner_affiliates;

CREATE POLICY "Anon insert trading affiliate"
  ON public.trading_partner_affiliates
  FOR INSERT
  TO anon
  WITH CHECK (device_key <> '' AND device_key IS NOT NULL);

CREATE POLICY "Authenticated insert trading affiliate"
  ON public.trading_partner_affiliates
  FOR INSERT
  TO authenticated
  WITH CHECK (device_key <> '' AND device_key IS NOT NULL);

CREATE POLICY "Anon update trading affiliate"
  ON public.trading_partner_affiliates
  FOR UPDATE
  TO anon
  USING  (device_key <> '' AND device_key IS NOT NULL)
  WITH CHECK (device_key <> '' AND device_key IS NOT NULL);

CREATE POLICY "Authenticated update trading affiliate"
  ON public.trading_partner_affiliates
  FOR UPDATE
  TO authenticated
  USING  (device_key <> '' AND device_key IS NOT NULL)
  WITH CHECK (device_key <> '' AND device_key IS NOT NULL);

-- ────────────────────────────────────────────────────────────────────────────
-- 5. trading_affiliate_payouts
-- ────────────────────────────────────────────────────────────────────────────
DROP POLICY IF EXISTS "Anon insert trading payout"          ON public.trading_affiliate_payouts;
DROP POLICY IF EXISTS "Authenticated insert trading payout" ON public.trading_affiliate_payouts;
DROP POLICY IF EXISTS "Anon update trading payout"          ON public.trading_affiliate_payouts;
DROP POLICY IF EXISTS "Authenticated update trading payout" ON public.trading_affiliate_payouts;

CREATE POLICY "Anon insert trading payout"
  ON public.trading_affiliate_payouts
  FOR INSERT
  TO anon
  WITH CHECK (device_key <> '' AND device_key IS NOT NULL);

CREATE POLICY "Authenticated insert trading payout"
  ON public.trading_affiliate_payouts
  FOR INSERT
  TO authenticated
  WITH CHECK (device_key <> '' AND device_key IS NOT NULL);

CREATE POLICY "Anon update trading payout"
  ON public.trading_affiliate_payouts
  FOR UPDATE
  TO anon
  USING  (device_key <> '' AND device_key IS NOT NULL)
  WITH CHECK (device_key <> '' AND device_key IS NOT NULL);

CREATE POLICY "Authenticated update trading payout"
  ON public.trading_affiliate_payouts
  FOR UPDATE
  TO authenticated
  USING  (device_key <> '' AND device_key IS NOT NULL)
  WITH CHECK (device_key <> '' AND device_key IS NOT NULL);
