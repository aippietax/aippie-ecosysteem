-- ── Upgrade secure_chat_pins with security features ────────────────────────
ALTER TABLE secure_chat_pins
  ADD COLUMN IF NOT EXISTS failed_attempts  int         NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS is_locked        boolean     NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS locked_until     timestamptz,
  ADD COLUMN IF NOT EXISTS pin_rotated_at   timestamptz DEFAULT now(),
  ADD COLUMN IF NOT EXISTS pin_expires_at   timestamptz DEFAULT now() + INTERVAL '7 days';

-- ── WebRTC rooms for signaling ────────────────────────────────────────────────
CREATE TABLE webrtc_rooms (
  id           uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
  room_code    text        UNIQUE NOT NULL,
  initiator_pin text       NOT NULL,
  status       text        NOT NULL DEFAULT 'waiting'
                           CHECK (status IN ('waiting','active','ended')),
  created_at   timestamptz DEFAULT now(),
  expires_at   timestamptz DEFAULT now() + INTERVAL '15 minutes'
);

ALTER TABLE webrtc_rooms ENABLE ROW LEVEL SECURITY;

CREATE POLICY "select_rooms" ON webrtc_rooms FOR SELECT
  TO authenticated USING (true);

CREATE POLICY "insert_rooms" ON webrtc_rooms FOR INSERT
  TO authenticated
  WITH CHECK (initiator_pin = (SELECT pin_code FROM secure_chat_pins WHERE user_id = auth.uid()));

CREATE POLICY "update_rooms" ON webrtc_rooms FOR UPDATE
  TO authenticated USING (true) WITH CHECK (true);

CREATE POLICY "delete_rooms" ON webrtc_rooms FOR DELETE
  TO authenticated USING (initiator_pin = (SELECT pin_code FROM secure_chat_pins WHERE user_id = auth.uid()));

-- Auto-cleanup expired rooms
CREATE INDEX ON webrtc_rooms (expires_at);
