-- Expand the plan check constraint to include all valid appTabs
ALTER TABLE aippietax_active_licenses
  DROP CONSTRAINT IF EXISTS aippietax_active_licenses_plan_check;

ALTER TABLE aippietax_active_licenses
  ADD CONSTRAINT aippietax_active_licenses_plan_check
  CHECK (plan = ANY (ARRAY[
    'tax', 'voice', 'trading', 'doctor', 'all',
    'silentvoice', 'realestate', 'aippiedev', 'academy',
    'companion', 'wearable', 'safecheckin', 'assistant',
    'voipscript', 'quantumcinema', 'robotics', 'cybersuit',
    'livestage', 'voicenav', 'wallet', 'legal', 'reunion',
    'b2b', 'alphatrade', 'parking', 'wifi'
  ]));