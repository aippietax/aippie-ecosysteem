-- Verified badge system for SecureChat profiles
-- Individuals who complete biometric (fingerprint + face) → GOLD
-- Businesses/companies → PLATINUM

ALTER TABLE public.secure_chat_pins
  ADD COLUMN IF NOT EXISTS verified_type TEXT DEFAULT 'none' CHECK (verified_type IN ('none', 'gold', 'platinum')),
  ADD COLUMN IF NOT EXISTS account_type TEXT DEFAULT 'personal' CHECK (account_type IN ('personal', 'business')),
  ADD COLUMN IF NOT EXISTS verified_at TIMESTAMPTZ;

-- 3D Workspace sessions (launched from SecureChat group)
CREATE TABLE IF NOT EXISTS public.workspace_3d_sessions (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  room_id       TEXT NOT NULL UNIQUE,
  host_pin      TEXT NOT NULL,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
  expires_at    TIMESTAMPTZ NOT NULL DEFAULT (now() + INTERVAL '3 hours'),
  is_active     BOOLEAN NOT NULL DEFAULT true,
  participant_pins TEXT[] NOT NULL DEFAULT '{}'
);

ALTER TABLE public.workspace_3d_sessions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "read_active_workspace_sessions" ON public.workspace_3d_sessions
  FOR SELECT TO authenticated
  USING (is_active = true AND expires_at > now());

CREATE POLICY "insert_workspace_session" ON public.workspace_3d_sessions
  FOR INSERT TO authenticated WITH CHECK (true);

CREATE POLICY "update_workspace_session" ON public.workspace_3d_sessions
  FOR UPDATE TO authenticated USING (true) WITH CHECK (true);

-- RLS for verified_type update — users update their own pin profile
CREATE POLICY "update_own_pin_verified" ON public.secure_chat_pins
  FOR UPDATE TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);
