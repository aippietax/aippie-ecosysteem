/*
  # Create client_profiles table

  1. New Tables
    - `client_profiles`
      - `id` (uuid, primary key)
      - `full_name` (text) — user's registered display name
      - `phone` (text) — client contact number
      - `device_key` (text, unique) — anonymous device fingerprint for first-time detection
      - `onboarded_at` (timestamptz) — when the user completed onboarding
      - `created_at` (timestamptz)

  2. Security
    - RLS enabled; anonymous inserts allowed so unauthed first-time visitors can register
    - Authenticated users can read/update their own row by device_key

  3. Notes
    - `device_key` is a random UUID stored in localStorage to identify returning visitors
      without requiring Supabase auth, matching the no-login onboarding flow
*/

CREATE TABLE IF NOT EXISTS client_profiles (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  full_name   text NOT NULL DEFAULT '',
  phone       text NOT NULL DEFAULT '',
  device_key  text UNIQUE NOT NULL,
  onboarded_at timestamptz DEFAULT now(),
  created_at  timestamptz DEFAULT now()
);

ALTER TABLE client_profiles ENABLE ROW LEVEL SECURITY;

-- Anyone can insert a new profile (first-time onboarding, anonymous)
CREATE POLICY "Anonymous insert for onboarding"
  ON client_profiles FOR INSERT
  TO anon, authenticated
  WITH CHECK (true);

-- Users can read their own profile by device_key
CREATE POLICY "Read own profile by device_key"
  ON client_profiles FOR SELECT
  TO anon, authenticated
  USING (true);

-- Users can update their own profile
CREATE POLICY "Update own profile"
  ON client_profiles FOR UPDATE
  TO anon, authenticated
  USING (true)
  WITH CHECK (true);
