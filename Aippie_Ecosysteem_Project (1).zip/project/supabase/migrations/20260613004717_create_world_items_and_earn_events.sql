-- World shop items catalog (static)
CREATE TABLE IF NOT EXISTS world_shop_items (
  id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  slug         TEXT UNIQUE NOT NULL,
  name         TEXT NOT NULL,
  description  TEXT,
  price_apc    NUMERIC(18,4) NOT NULL,
  category     TEXT NOT NULL CHECK (category IN ('avatar','boost','emote','title')),
  icon         TEXT,
  created_at   TIMESTAMPTZ DEFAULT now()
);

ALTER TABLE world_shop_items ENABLE ROW LEVEL SECURITY;
CREATE POLICY "shop_items_public_read" ON world_shop_items FOR SELECT TO anon, authenticated USING (true);

-- Insert default shop items
INSERT INTO world_shop_items (slug, name, description, price_apc, category, icon) VALUES
  ('glow_gold',      'Gouden Gloed',        'Jouw avatar gloeit goud in de wereld',   50,  'avatar', '✨'),
  ('glow_cyan',      'Cyaan Gloed',          'Neon cyaan aura rondom avatar',           35,  'avatar', '💠'),
  ('glow_pink',      'Roze Gloed',           'Roze energie-aura',                       35,  'avatar', '🌸'),
  ('title_trader',   'Elite Trader',         'Titel boven je naam in de wereld',        75,  'title',  '📈'),
  ('title_guardian', 'World Guardian',       'Beschermheer van de Aippie World',        100, 'title',  '🛡️'),
  ('title_oracle',   'Oracle Disciple',      'Leerling van de AI Oracle',               60,  'title',  '🔮'),
  ('boost_2x',       '2x APC Boost (1u)',    'Verdien dubbele APC voor 1 uur',          80,  'boost',  '⚡'),
  ('boost_zone',     'Zone King (30min)',    'Jij bent heer van de zone (30 min)',       40,  'boost',  '👑'),
  ('emote_celebrate','Confetti Emote',       'Gooi confetti in de lucht',               20,  'emote',  '🎊'),
  ('emote_fire',     'Vuurbal Emote',        'Gooi een vuurbal naar anderen',           25,  'emote',  '🔥')
ON CONFLICT (slug) DO NOTHING;

-- User purchased world items
CREATE TABLE IF NOT EXISTS world_owned_items (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id     UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  item_slug   TEXT NOT NULL REFERENCES world_shop_items(slug),
  equipped    BOOLEAN DEFAULT false,
  expires_at  TIMESTAMPTZ,
  purchased_at TIMESTAMPTZ DEFAULT now(),
  UNIQUE (user_id, item_slug)
);

ALTER TABLE world_owned_items ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own_items_select" ON world_owned_items FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "own_items_insert" ON world_owned_items FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "own_items_update" ON world_owned_items FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE POLICY "own_items_delete" ON world_owned_items FOR DELETE TO authenticated USING (auth.uid() = user_id);

-- Daily spin log (one spin per day per user)
CREATE TABLE IF NOT EXISTS world_daily_spins (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id     UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  spin_date   DATE NOT NULL DEFAULT CURRENT_DATE,
  apc_won     NUMERIC(18,4) NOT NULL,
  created_at  TIMESTAMPTZ DEFAULT now(),
  UNIQUE (user_id, spin_date)
);

ALTER TABLE world_daily_spins ENABLE ROW LEVEL SECURITY;
CREATE POLICY "spins_select" ON world_daily_spins FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "spins_insert" ON world_daily_spins FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);

-- World presence log (earn APC for time spent)
CREATE TABLE IF NOT EXISTS world_presence_log (
  id         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id    UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  zone_id    TEXT NOT NULL,
  apc_earned NUMERIC(18,4) NOT NULL DEFAULT 0,
  session_at TIMESTAMPTZ DEFAULT now()
);

ALTER TABLE world_presence_log ENABLE ROW LEVEL SECURITY;
CREATE POLICY "presence_insert" ON world_presence_log FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "presence_select" ON world_presence_log FOR SELECT TO authenticated USING (auth.uid() = user_id);
