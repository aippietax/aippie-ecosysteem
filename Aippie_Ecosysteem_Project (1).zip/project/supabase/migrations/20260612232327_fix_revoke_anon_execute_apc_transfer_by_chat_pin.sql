REVOKE EXECUTE ON FUNCTION public.apc_transfer_by_chat_pin(TEXT, NUMERIC) FROM PUBLIC;
REVOKE EXECUTE ON FUNCTION public.apc_transfer_by_chat_pin(TEXT, NUMERIC) FROM anon;
GRANT  EXECUTE ON FUNCTION public.apc_transfer_by_chat_pin(TEXT, NUMERIC) TO authenticated;
