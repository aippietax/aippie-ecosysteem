/*
  # Aippie Assistant Module

  ## New Tables

  ### aippie_conversations
  Persistent chat history per user.
  - `id` (uuid, PK)
  - `user_id` (uuid, FK auth.users)
  - `role` (text) — 'user' | 'assistant'
  - `content` (text) — message body
  - `created_at` (timestamptz)

  ### aippie_agent_reminders
  Scheduled task/reminder ledger. Users create reminders; the app
  reads upcoming ones on load and flags overdue ones.
  - `id` (uuid, PK)
  - `user_id` (uuid, FK auth.users)
  - `title` (text)
  - `description` (text)
  - `scheduled_for` (timestamptz)
  - `status` (text) — 'pending' | 'fired' | 'dismissed'
  - `category` (text) — 'reminder' | 'task' | 'appointment'
  - `created_at` (timestamptz)

  ## Security
  - RLS enabled on both tables
  - Users can only access their own rows
*/

-- ── aippie_conversations ──────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS aippie_conversations (
  id          uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id     uuid        NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  role        text        NOT NULL CHECK (role IN ('user', 'assistant')),
  content     text        NOT NULL DEFAULT '',
  created_at  timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS aippie_conversations_user_id_idx
  ON aippie_conversations (user_id, created_at DESC);

ALTER TABLE aippie_conversations ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own messages"
  ON aippie_conversations FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own messages"
  ON aippie_conversations FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own messages"
  ON aippie_conversations FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- ── aippie_agent_reminders ────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS aippie_agent_reminders (
  id             uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id        uuid        NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  title          text        NOT NULL DEFAULT '',
  description    text        NOT NULL DEFAULT '',
  scheduled_for  timestamptz NOT NULL,
  status         text        NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','fired','dismissed')),
  category       text        NOT NULL DEFAULT 'reminder' CHECK (category IN ('reminder','task','appointment')),
  created_at     timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS aippie_agent_reminders_user_id_idx
  ON aippie_agent_reminders (user_id, scheduled_for ASC);

ALTER TABLE aippie_agent_reminders ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own reminders"
  ON aippie_agent_reminders FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own reminders"
  ON aippie_agent_reminders FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own reminders"
  ON aippie_agent_reminders FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own reminders"
  ON aippie_agent_reminders FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);
