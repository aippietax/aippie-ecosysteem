
-- V52: AippieTax Fiscal Filing Suite
-- New tables:
--   aippietax_receipt_ledger  — 24/7 ledger entries with tax optimization flags
--   tax_filings               — Direct filing submissions to Belastingdienst / Hacienda
--   tax_alerts                — Smart push notifications / alert dispatch
--   fiscal_optimization_log   — Tax minimization engine audit log
-- All tables: RLS enabled, per-user or per-device_key policies

-- 1. aippietax_receipt_ledger
CREATE TABLE IF NOT EXISTS aippietax_receipt_ledger (
  id                 uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  device_key         text NOT NULL DEFAULT '',
  user_id            uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  entry_date         date NOT NULL DEFAULT CURRENT_DATE,
  description        text NOT NULL DEFAULT '',
  counterparty       text NOT NULL DEFAULT '',
  amount_eur         numeric(12,2) NOT NULL DEFAULT 0,
  vat_rate           numeric(5,2) NOT NULL DEFAULT 21,
  vat_amount         numeric(12,2) GENERATED ALWAYS AS (amount_eur * vat_rate / 100) STORED,
  category           text NOT NULL DEFAULT 'expense',
  entity_type        text NOT NULL DEFAULT 'SL',
  deductible         boolean NOT NULL DEFAULT false,
  optimization_flag  text DEFAULT NULL,
  bank_api_source    text DEFAULT NULL,
  synced_at          timestamptz DEFAULT NULL,
  created_at         timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE aippietax_receipt_ledger ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Device can insert own ledger entries"
  ON aippietax_receipt_ledger FOR INSERT
  TO anon, authenticated
  WITH CHECK (device_key != '');

CREATE POLICY "Device can read own ledger entries"
  ON aippietax_receipt_ledger FOR SELECT
  TO anon, authenticated
  USING (device_key != '' AND device_key = device_key);

CREATE POLICY "Authenticated users can read own ledger entries"
  ON aippietax_receipt_ledger FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

-- 2. tax_filings — direct e-filing to government agencies
CREATE TABLE IF NOT EXISTS tax_filings (
  id                 uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  device_key         text NOT NULL DEFAULT '',
  user_id            uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  fiscal_year        smallint NOT NULL DEFAULT EXTRACT(YEAR FROM CURRENT_DATE)::smallint,
  agency             text NOT NULL DEFAULT 'Hacienda',
  entity_type        text NOT NULL DEFAULT 'SL',
  total_revenue_eur  numeric(14,2) NOT NULL DEFAULT 0,
  total_expenses_eur numeric(14,2) NOT NULL DEFAULT 0,
  taxable_income_eur numeric(14,2) GENERATED ALWAYS AS (total_revenue_eur - total_expenses_eur) STORED,
  tax_liability_eur  numeric(14,2) NOT NULL DEFAULT 0,
  optimized_liability_eur numeric(14,2) NOT NULL DEFAULT 0,
  savings_eur        numeric(14,2) GENERATED ALWAYS AS (tax_liability_eur - optimized_liability_eur) STORED,
  filing_status      text NOT NULL DEFAULT 'draft',
  submitted_at       timestamptz DEFAULT NULL,
  confirmation_ref   text DEFAULT NULL,
  report_payload     jsonb DEFAULT NULL,
  created_at         timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE tax_filings ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Device can insert own filings"
  ON tax_filings FOR INSERT
  TO anon, authenticated
  WITH CHECK (device_key != '');

CREATE POLICY "Device can read own filings"
  ON tax_filings FOR SELECT
  TO anon, authenticated
  USING (device_key != '');

CREATE POLICY "Device can update own filings"
  ON tax_filings FOR UPDATE
  TO anon, authenticated
  USING (device_key != '')
  WITH CHECK (device_key != '');

CREATE POLICY "Authenticated users can read own filings"
  ON tax_filings FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

-- 3. tax_alerts — smart notification dispatch
CREATE TABLE IF NOT EXISTS tax_alerts (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  device_key   text NOT NULL DEFAULT '',
  user_id      uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  alert_type   text NOT NULL DEFAULT 'deadline',
  severity     text NOT NULL DEFAULT 'info',
  title        text NOT NULL DEFAULT '',
  body         text NOT NULL DEFAULT '',
  due_date     date DEFAULT NULL,
  is_read      boolean NOT NULL DEFAULT false,
  is_spoken    boolean NOT NULL DEFAULT false,
  created_at   timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE tax_alerts ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Device can insert own alerts"
  ON tax_alerts FOR INSERT
  TO anon, authenticated
  WITH CHECK (device_key != '');

CREATE POLICY "Device can read own alerts"
  ON tax_alerts FOR SELECT
  TO anon, authenticated
  USING (device_key != '');

CREATE POLICY "Device can update own alerts"
  ON tax_alerts FOR UPDATE
  TO anon, authenticated
  USING (device_key != '')
  WITH CHECK (device_key != '');

-- 4. fiscal_optimization_log — tax minimization engine audit trail
CREATE TABLE IF NOT EXISTS fiscal_optimization_log (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  device_key      text NOT NULL DEFAULT '',
  user_id         uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  run_at          timestamptz NOT NULL DEFAULT now(),
  entity_type     text NOT NULL DEFAULT 'SL',
  period          text NOT NULL DEFAULT '',
  gross_liability numeric(14,2) NOT NULL DEFAULT 0,
  net_liability   numeric(14,2) NOT NULL DEFAULT 0,
  savings         numeric(14,2) GENERATED ALWAYS AS (gross_liability - net_liability) STORED,
  strategies      jsonb DEFAULT '[]'::jsonb,
  applied         boolean NOT NULL DEFAULT false
);

ALTER TABLE fiscal_optimization_log ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Device can insert own optimization logs"
  ON fiscal_optimization_log FOR INSERT
  TO anon, authenticated
  WITH CHECK (device_key != '');

CREATE POLICY "Device can read own optimization logs"
  ON fiscal_optimization_log FOR SELECT
  TO anon, authenticated
  USING (device_key != '');

-- Indexes for query performance
CREATE INDEX IF NOT EXISTS idx_receipt_ledger_device ON aippietax_receipt_ledger(device_key, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_tax_filings_device ON tax_filings(device_key, fiscal_year DESC);
CREATE INDEX IF NOT EXISTS idx_tax_alerts_device ON tax_alerts(device_key, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_fiscal_opt_device ON fiscal_optimization_log(device_key, run_at DESC);

-- Seed default tax alerts for demo
INSERT INTO tax_alerts (device_key, alert_type, severity, title, body, due_date)
VALUES
  ('__demo__', 'deadline', 'critical', 'Q2 VAT Declaration Due', 'Your Q2 IVA return for Hacienda is due on 20 July 2026. Estimated liability: €4,280.', '2026-07-20'),
  ('__demo__', 'optimization', 'success', 'Tax Saving Opportunity', 'Aippie detected €1,840 in deductible home-office costs not yet applied to your SL entity.', NULL),
  ('__demo__', 'budget', 'warning', 'Expense Budget Alert', 'Marketing spend is 87% of monthly budget with 11 days remaining.', NULL)
ON CONFLICT DO NOTHING;
