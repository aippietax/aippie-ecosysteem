ALTER TABLE secure_chat_pins
  ADD COLUMN IF NOT EXISTS passkey_credential_id text DEFAULT NULL;
