-- V219: AI Paper Trading Positions — tracks autonomous AI trades per session/user

CREATE TABLE IF NOT EXISTS ai_paper_positions (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  session_key   text NOT NULL,                        -- device key or user id
  asset         text NOT NULL,
  side          text NOT NULL CHECK (side IN ('LONG','SHORT')),
  entry_price   numeric(18,6) NOT NULL,
  qty           numeric(18,8) NOT NULL DEFAULT 1,
  stop_loss     numeric(18,6) NOT NULL,
  take_profit   numeric(18,6) NOT NULL,
  strategy      text NOT NULL DEFAULT 'MA_CROSSOVER',  -- which AI strategy opened this
  status        text NOT NULL DEFAULT 'OPEN' CHECK (status IN ('OPEN','CLOSED_TP','CLOSED_SL','CLOSED_AI')),
  close_price   numeric(18,6),
  pnl_pct       numeric(10,4),
  opened_at     timestamptz NOT NULL DEFAULT now(),
  closed_at     timestamptz
);

ALTER TABLE ai_paper_positions ENABLE ROW LEVEL SECURITY;

-- Anyone with the session key can read/write their own positions
CREATE POLICY "select_own_paper" ON ai_paper_positions FOR SELECT
  TO anon, authenticated USING (true);
CREATE POLICY "insert_own_paper" ON ai_paper_positions FOR INSERT
  TO anon, authenticated WITH CHECK (true);
CREATE POLICY "update_own_paper" ON ai_paper_positions FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);
