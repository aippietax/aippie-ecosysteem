
-- Fix always-true RLS policies on service_credentials and whatsapp_messages.
-- service_credentials: INSERT/UPDATE/DELETE must be scoped to the row's own device_key.
-- whatsapp_messages: INSERT/UPDATE scoped to non-empty device_key.
--   Inbound webhook inserts use the service role key (bypasses RLS), so the
--   device_key IS NOT NULL guard does not block legitimate webhook writes.

-- ── service_credentials ──────────────────────────────────────────────────────
DROP POLICY IF EXISTS sc_insert ON public.service_credentials;
DROP POLICY IF EXISTS sc_update ON public.service_credentials;
DROP POLICY IF EXISTS sc_delete ON public.service_credentials;

CREATE POLICY sc_insert ON public.service_credentials
  FOR INSERT TO anon, authenticated
  WITH CHECK (device_key <> '' AND device_key IS NOT NULL);

CREATE POLICY sc_update ON public.service_credentials
  FOR UPDATE TO anon, authenticated
  USING  (device_key <> '' AND device_key IS NOT NULL)
  WITH CHECK (device_key <> '' AND device_key IS NOT NULL);

CREATE POLICY sc_delete ON public.service_credentials
  FOR DELETE TO anon, authenticated
  USING  (device_key <> '' AND device_key IS NOT NULL);

-- ── whatsapp_messages ────────────────────────────────────────────────────────
DROP POLICY IF EXISTS wa_insert ON public.whatsapp_messages;
DROP POLICY IF EXISTS wa_update ON public.whatsapp_messages;

CREATE POLICY wa_insert ON public.whatsapp_messages
  FOR INSERT TO anon, authenticated
  WITH CHECK (device_key <> '' AND device_key IS NOT NULL);

CREATE POLICY wa_update ON public.whatsapp_messages
  FOR UPDATE TO anon, authenticated
  USING  (device_key <> '' AND device_key IS NOT NULL)
  WITH CHECK (device_key <> '' AND device_key IS NOT NULL);
