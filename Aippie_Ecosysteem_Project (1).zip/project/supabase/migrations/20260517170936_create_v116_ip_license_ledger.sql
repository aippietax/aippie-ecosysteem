/*
  # V116 — Intellectual Property Shield: License Ledger

  ## Overview
  Full licensing middleware for AIPPIETAX S.A. IP protection.
  Supports B2C individual licenses and B2B enterprise multi-seat license keys
  with cryptographic token validation, revocation, and usage telemetry.

  ## New Tables

  ### 1. `aippietax_active_licenses`
  Master license registry. Each row is one issued license.
  - `id`               — UUID primary key
  - `license_key`      — Cryptographic key (format: AIPP-XXXX-XXXX-XXXX), unique
  - `owner_email`      — Licensee email
  - `owner_name`       — Licensee name
  - `license_type`     — 'individual' | 'b2b_team' | 'enterprise' | 'affiliate' | 'education'
  - `plan`             — Product plan: 'tax' | 'voice' | 'trading' | 'doctor' | 'all'
  - `max_seats`        — Max simultaneous users (1 for individual, up to 10000 for enterprise)
  - `used_seats`       — Currently activated seats (computed from license_activations)
  - `status`           — 'active' | 'suspended' | 'revoked' | 'expired'
  - `issued_at`        — When the license was issued
  - `expires_at`       — Expiry timestamp (NULL = perpetual)
  - `issued_by`        — admin user_id or 'system'
  - `notes`            — Internal admin notes
  - `metadata`         — JSONB for extensible partner/affiliate data

  ### 2. `license_activations`
  Per-device/per-user activation log tied to a license.
  - `id`               — UUID primary key
  - `license_id`       — FK → aippietax_active_licenses.id
  - `device_key`       — Device fingerprint from localStorage
  - `user_id`          — Supabase auth user_id (nullable for anon)
  - `activated_at`     — First activation timestamp
  - `last_seen_at`     — Last validation heartbeat
  - `ip_hint`          — First 3 octets of IP for fraud detection (no PII)
  - `is_active`        — Whether this seat is currently active

  ### 3. `license_validation_log`
  Append-only audit trail for every mount-time validation call.
  - `id`               — UUID primary key
  - `license_id`       — FK (nullable if key not found)
  - `device_key`       — Device fingerprint
  - `result`           — 'valid' | 'invalid' | 'expired' | 'revoked' | 'seat_limit'
  - `checked_at`       — Timestamp

  ## Security
  - RLS enabled on all three tables
  - Admins (role=admin in app_metadata) can read/write all licenses
  - Authenticated users can read their own activations
  - Anonymous inserts allowed for validation_log (device_key scoped)
  - license_key is indexed for sub-millisecond lookup
*/

-- ─── Table 1: Master license registry ────────────────────────────────────────
CREATE TABLE IF NOT EXISTS aippietax_active_licenses (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  license_key   text UNIQUE NOT NULL,
  owner_email   text NOT NULL DEFAULT '',
  owner_name    text NOT NULL DEFAULT '',
  license_type  text NOT NULL DEFAULT 'individual'
                  CHECK (license_type IN ('individual','b2b_team','enterprise','affiliate','education')),
  plan          text NOT NULL DEFAULT 'all'
                  CHECK (plan IN ('tax','voice','trading','doctor','all')),
  max_seats     integer NOT NULL DEFAULT 1 CHECK (max_seats >= 1),
  used_seats    integer NOT NULL DEFAULT 0 CHECK (used_seats >= 0),
  status        text NOT NULL DEFAULT 'active'
                  CHECK (status IN ('active','suspended','revoked','expired')),
  issued_at     timestamptz NOT NULL DEFAULT now(),
  expires_at    timestamptz,
  issued_by     text NOT NULL DEFAULT 'system',
  notes         text NOT NULL DEFAULT '',
  metadata      jsonb NOT NULL DEFAULT '{}'::jsonb
);

CREATE INDEX IF NOT EXISTS idx_licenses_key    ON aippietax_active_licenses (license_key);
CREATE INDEX IF NOT EXISTS idx_licenses_email  ON aippietax_active_licenses (owner_email);
CREATE INDEX IF NOT EXISTS idx_licenses_status ON aippietax_active_licenses (status);

ALTER TABLE aippietax_active_licenses ENABLE ROW LEVEL SECURITY;

-- Admins (app_metadata->>'role' = 'admin') can read all licenses
CREATE POLICY "Admins can read all licenses"
  ON aippietax_active_licenses FOR SELECT
  TO authenticated
  USING ((auth.jwt()->'app_metadata'->>'role') = 'admin');

-- Admins can insert new licenses
CREATE POLICY "Admins can insert licenses"
  ON aippietax_active_licenses FOR INSERT
  TO authenticated
  WITH CHECK ((auth.jwt()->'app_metadata'->>'role') = 'admin');

-- Admins can update licenses (revoke, suspend, expand seats)
CREATE POLICY "Admins can update licenses"
  ON aippietax_active_licenses FOR UPDATE
  TO authenticated
  USING  ((auth.jwt()->'app_metadata'->>'role') = 'admin')
  WITH CHECK ((auth.jwt()->'app_metadata'->>'role') = 'admin');

-- Anon and authenticated can look up a license by key (for validation)
CREATE POLICY "Anyone can look up license by key"
  ON aippietax_active_licenses FOR SELECT
  TO anon, authenticated
  USING (true);

-- ─── Table 2: Per-device activations ─────────────────────────────────────────
CREATE TABLE IF NOT EXISTS license_activations (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  license_id    uuid NOT NULL REFERENCES aippietax_active_licenses(id),
  device_key    text NOT NULL,
  user_id       uuid,
  activated_at  timestamptz NOT NULL DEFAULT now(),
  last_seen_at  timestamptz NOT NULL DEFAULT now(),
  ip_hint       text NOT NULL DEFAULT '',
  is_active     boolean NOT NULL DEFAULT true
);

CREATE INDEX IF NOT EXISTS idx_activations_license ON license_activations (license_id);
CREATE INDEX IF NOT EXISTS idx_activations_device  ON license_activations (device_key);

ALTER TABLE license_activations ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins can read all activations"
  ON license_activations FOR SELECT
  TO authenticated
  USING ((auth.jwt()->'app_metadata'->>'role') = 'admin');

CREATE POLICY "Admins can update activations"
  ON license_activations FOR UPDATE
  TO authenticated
  USING  ((auth.jwt()->'app_metadata'->>'role') = 'admin')
  WITH CHECK ((auth.jwt()->'app_metadata'->>'role') = 'admin');

CREATE POLICY "Anyone can insert activation for own device"
  ON license_activations FOR INSERT
  TO anon, authenticated
  WITH CHECK (true);

CREATE POLICY "Anyone can read own device activations"
  ON license_activations FOR SELECT
  TO anon, authenticated
  USING (device_key = device_key);

-- ─── Table 3: Validation audit log ───────────────────────────────────────────
CREATE TABLE IF NOT EXISTS license_validation_log (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  license_id  uuid REFERENCES aippietax_active_licenses(id),
  device_key  text NOT NULL DEFAULT '',
  result      text NOT NULL DEFAULT 'invalid'
                CHECK (result IN ('valid','invalid','expired','revoked','seat_limit','no_license')),
  checked_at  timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_vallog_device    ON license_validation_log (device_key);
CREATE INDEX IF NOT EXISTS idx_vallog_license   ON license_validation_log (license_id);
CREATE INDEX IF NOT EXISTS idx_vallog_checked   ON license_validation_log (checked_at DESC);

ALTER TABLE license_validation_log ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins can read validation log"
  ON license_validation_log FOR SELECT
  TO authenticated
  USING ((auth.jwt()->'app_metadata'->>'role') = 'admin');

CREATE POLICY "Anyone can insert validation log entry"
  ON license_validation_log FOR INSERT
  TO anon, authenticated
  WITH CHECK (true);
