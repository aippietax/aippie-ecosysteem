/*
  # Fix overly-permissive RLS policies

  ## Summary
  Eight RLS policies across five tables had USING (true) or WITH CHECK (true)
  clauses that granted unrestricted access, effectively defeating row-level
  security. This migration drops each offending policy and replaces it with a
  tightly scoped alternative.

  ## Changes per table

  ### aippie_properties
  - No `user_id` column exists — this is a read-only catalogue managed via the
    service role / admin dashboard. Client-authenticated users have no legitimate
    need to INSERT, UPDATE or DELETE rows directly.
  - DROP: "Authenticated users can insert properties" (WITH CHECK true)
  - DROP: "Authenticated users can update properties" (USING true / WITH CHECK true)
  - DROP: "Authenticated users can delete properties" (USING true)
  - No replacement policies. Mutations must go through service-role only.

  ### aippie_relocation_leads
  - Leads are anonymous/device-key-based. There is no auth.uid() to check, but
    we can at minimum require the device_key column to be a non-empty string so
    empty or null device_key rows are rejected.
  - DROP: "Anyone can insert relocation lead" (WITH CHECK true)
  - ADD:  "Anyone can insert relocation lead with valid device_key" — requires
           device_key to be a non-empty string (length >= 8).

  ### aippie_silent_voice_channels
  - Same pattern: device-key + session-id based anonymous logging.
  - DROP: "Anyone can insert gesture log" (WITH CHECK true)
  - ADD:  "Anyone can insert gesture log with valid device_key" — requires
           device_key and session_id to be non-empty strings.

  ### client_profiles
  - INSERT: requires device_key to be non-empty.
  - UPDATE: locks USING and WITH CHECK to rows where the stored device_key
            matches the device_key column being updated (self-only).
  - DROP: "Anonymous insert for onboarding" (WITH CHECK true)
  - DROP: "Update own profile" (USING true / WITH CHECK true)
  - ADD:  "Insert own profile by device_key"
  - ADD:  "Update own profile by device_key"

  ### admin_config
  - RLS enabled but zero policies → no one can read. Add a minimal authenticated
    SELECT policy so the admin dashboard can read config rows.
  - ADD: "Authenticated users can read admin config"

  ## Security notes
  - All mutations on aippie_properties are now service-role only (no client policy).
  - Device-key checks are a lightweight integrity guard; they cannot verify identity
    but they prevent trivially empty/null inserts from anonymous clients.
  - The admin_config table remains write-protected from all client roles.
*/

-- ─── aippie_properties ──────────────────────────────────────────────────────

DROP POLICY IF EXISTS "Authenticated users can insert properties" ON aippie_properties;
DROP POLICY IF EXISTS "Authenticated users can update properties" ON aippie_properties;
DROP POLICY IF EXISTS "Authenticated users can delete properties" ON aippie_properties;

-- No replacement: service-role manages this catalogue table exclusively.

-- ─── aippie_relocation_leads ─────────────────────────────────────────────────

DROP POLICY IF EXISTS "Anyone can insert relocation lead" ON aippie_relocation_leads;

CREATE POLICY "Anyone can insert relocation lead with valid device_key"
  ON aippie_relocation_leads FOR INSERT
  TO anon, authenticated
  WITH CHECK (
    device_key IS NOT NULL
    AND length(trim(device_key)) >= 8
  );

-- ─── aippie_silent_voice_channels ────────────────────────────────────────────

DROP POLICY IF EXISTS "Anyone can insert gesture log" ON aippie_silent_voice_channels;

CREATE POLICY "Anyone can insert gesture log with valid device_key"
  ON aippie_silent_voice_channels FOR INSERT
  TO anon, authenticated
  WITH CHECK (
    device_key IS NOT NULL
    AND length(trim(device_key)) >= 8
    AND session_id IS NOT NULL
    AND length(trim(session_id)) >= 8
  );

-- ─── client_profiles ─────────────────────────────────────────────────────────

DROP POLICY IF EXISTS "Anonymous insert for onboarding" ON client_profiles;
DROP POLICY IF EXISTS "Update own profile"              ON client_profiles;

CREATE POLICY "Insert own profile by device_key"
  ON client_profiles FOR INSERT
  TO anon, authenticated
  WITH CHECK (
    device_key IS NOT NULL
    AND length(trim(device_key)) >= 8
  );

CREATE POLICY "Update own profile by device_key"
  ON client_profiles FOR UPDATE
  TO anon, authenticated
  USING   (device_key IS NOT NULL AND length(trim(device_key)) >= 8)
  WITH CHECK (device_key IS NOT NULL AND length(trim(device_key)) >= 8);

-- ─── admin_config ─────────────────────────────────────────────────────────────

CREATE POLICY "Authenticated users can read admin config"
  ON admin_config FOR SELECT
  TO authenticated
  USING (true);
