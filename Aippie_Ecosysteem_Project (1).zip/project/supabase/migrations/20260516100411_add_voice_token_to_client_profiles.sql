/*
  # Add voice_token to client_profiles

  ## Summary
  Adds a `voice_token` boolean column to `client_profiles` with a hard default
  of FALSE. This is the billing gate column for the AippieVoice / Interpreter
  tab (Tab 1).

  ## Changes
  ### Modified Tables
  - `client_profiles`
    - `voice_token` (boolean, DEFAULT false, NOT NULL) — set to true only after
      a verified successful checkout session activates the subscription. Controls
      whether the real-time audio interpretation interface, language selectors,
      and microphone channels are rendered or replaced with the paywall.

  ## Notes
  - Column defaults false for all existing and new rows.
  - Only set to true by the subscription activation flow (Stripe webhook or
    manual checkout confirmation in SubscriptionModal).
  - Existing rows are backfilled to false automatically by the DEFAULT.
*/

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'client_profiles' AND column_name = 'voice_token'
  ) THEN
    ALTER TABLE client_profiles
      ADD COLUMN voice_token boolean NOT NULL DEFAULT false;
  END IF;
END $$;
