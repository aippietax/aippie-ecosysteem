/*
  # Real Estate Portfolio Manager — V93
  AIPPIETAX S.A.

  ## Summary
  Creates two tables for the Aippie Real Estate Portfolio Manager module
  (€149/month subscription). Tracks registered asset portfolios and monthly
  rental income entries. Rental income rows are also mirrored to
  aippietax_receipt_ledger for unified fiscal reporting.

  ## New Tables

  ### re_portfolios
  Represents a single owned property asset registered by a user.
  - `id` (uuid, PK)
  - `user_id` (uuid, nullable) — links to auth.users; null = device session
  - `device_key` (text) — anonymous session key
  - `property_name` (text) — e.g. "Villa Los Pinos, Marbella"
  - `address` (text) — full street address
  - `property_type` (text) — villa | apartment | penthouse | townhouse | finca | commercial
  - `size_m2` (integer)
  - `purchase_price_eur` (numeric) — original acquisition cost
  - `current_valuation_eur` (numeric) — AI-simulated current market valuation
  - `monthly_rent_eur` (numeric) — monthly rent charged to tenant
  - `tenant_name` (text)
  - `lease_start` (date)
  - `lease_end` (date)
  - `status` (text) — active | vacant | for_sale
  - `created_at` (timestamptz)

  ### re_rental_income_ledger
  Individual monthly rental income entries for each portfolio property.
  - `id` (uuid, PK)
  - `portfolio_id` (uuid, FK → re_portfolios.id)
  - `user_id` (uuid, nullable)
  - `device_key` (text)
  - `period_month` (text) — e.g. "2026-05"
  - `amount_eur` (numeric) — rent received
  - `description` (text)
  - `synced_to_ledger` (boolean) — true once mirrored to aippietax_receipt_ledger
  - `created_at` (timestamptz)

  ## Security
  - RLS enabled on both tables
  - Users/devices can only read and write their own rows
  - No public read access
*/

-- ── re_portfolios ──────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS re_portfolios (
  id                    uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id               uuid        REFERENCES auth.users(id) ON DELETE SET NULL,
  device_key            text        NOT NULL DEFAULT '',
  property_name         text        NOT NULL DEFAULT '',
  address               text        NOT NULL DEFAULT '',
  property_type         text        NOT NULL DEFAULT 'apartment',
  size_m2               integer     NOT NULL DEFAULT 0,
  purchase_price_eur    numeric(14,2) NOT NULL DEFAULT 0,
  current_valuation_eur numeric(14,2) NOT NULL DEFAULT 0,
  monthly_rent_eur      numeric(10,2) NOT NULL DEFAULT 0,
  tenant_name           text        NOT NULL DEFAULT '',
  lease_start           date,
  lease_end             date,
  status                text        NOT NULL DEFAULT 'active',
  created_at            timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE re_portfolios ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Device can insert own portfolio"
  ON re_portfolios FOR INSERT
  TO anon, authenticated
  WITH CHECK (device_key != '');

CREATE POLICY "Device can read own portfolio"
  ON re_portfolios FOR SELECT
  TO anon, authenticated
  USING (device_key != '' AND device_key = device_key);

CREATE POLICY "Authenticated users can read own portfolio"
  ON re_portfolios FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Authenticated users can update own portfolio"
  ON re_portfolios FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE INDEX IF NOT EXISTS idx_re_portfolios_device_key ON re_portfolios (device_key);
CREATE INDEX IF NOT EXISTS idx_re_portfolios_user_id    ON re_portfolios (user_id);

-- ── re_rental_income_ledger ────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS re_rental_income_ledger (
  id                uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
  portfolio_id      uuid        REFERENCES re_portfolios(id) ON DELETE CASCADE,
  user_id           uuid        REFERENCES auth.users(id) ON DELETE SET NULL,
  device_key        text        NOT NULL DEFAULT '',
  period_month      text        NOT NULL DEFAULT '',
  amount_eur        numeric(10,2) NOT NULL DEFAULT 0,
  description       text        NOT NULL DEFAULT '',
  synced_to_ledger  boolean     NOT NULL DEFAULT false,
  created_at        timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE re_rental_income_ledger ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Device can insert own rental income"
  ON re_rental_income_ledger FOR INSERT
  TO anon, authenticated
  WITH CHECK (device_key != '');

CREATE POLICY "Device can read own rental income"
  ON re_rental_income_ledger FOR SELECT
  TO anon, authenticated
  USING (device_key != '' AND device_key = device_key);

CREATE POLICY "Authenticated users can read own rental income"
  ON re_rental_income_ledger FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Authenticated users can update own rental income"
  ON re_rental_income_ledger FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE INDEX IF NOT EXISTS idx_re_rental_portfolio_id ON re_rental_income_ledger (portfolio_id);
CREATE INDEX IF NOT EXISTS idx_re_rental_device_key   ON re_rental_income_ledger (device_key);
