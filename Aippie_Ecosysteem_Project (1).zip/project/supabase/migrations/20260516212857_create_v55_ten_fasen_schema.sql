
-- V55: AippieTax Operations Hub — Full 10-Fasen Schema
-- New tables covering all 10 business phases with RLS.

-- FASE 2: Smart Home IoT budget alerts
CREATE TABLE IF NOT EXISTS iot_budget_alerts (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  device_key   text NOT NULL DEFAULT '',
  user_id      uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  alert_title  text NOT NULL DEFAULT '',
  alert_body   text NOT NULL DEFAULT '',
  budget_limit numeric(12,2) NOT NULL DEFAULT 0,
  current_spend numeric(12,2) NOT NULL DEFAULT 0,
  channel      text NOT NULL DEFAULT 'dashboard',
  is_pushed    boolean NOT NULL DEFAULT false,
  created_at   timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE iot_budget_alerts ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Device insert iot_budget_alerts"
  ON iot_budget_alerts FOR INSERT TO anon, authenticated WITH CHECK (device_key != '');
CREATE POLICY "Device select iot_budget_alerts"
  ON iot_budget_alerts FOR SELECT TO anon, authenticated USING (device_key != '');

-- FASE 3: VoIP call sessions (already voip_sessions — extend with summary)
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'voip_sessions' AND column_name = 'ai_summary'
  ) THEN
    ALTER TABLE voip_sessions ADD COLUMN ai_summary text DEFAULT NULL;
    ALTER TABLE voip_sessions ADD COLUMN duration_secs integer NOT NULL DEFAULT 0;
  END IF;
END $$;

-- FASE 4: Autonomous campaign generator
CREATE TABLE IF NOT EXISTS marketing_campaigns (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  device_key      text NOT NULL DEFAULT '',
  user_id         uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  campaign_name   text NOT NULL DEFAULT '',
  platform        text NOT NULL DEFAULT 'google',
  target_audience text NOT NULL DEFAULT '',
  ad_copy         text NOT NULL DEFAULT '',
  budget_eur      numeric(10,2) NOT NULL DEFAULT 0,
  status          text NOT NULL DEFAULT 'draft',
  impressions     integer NOT NULL DEFAULT 0,
  clicks          integer NOT NULL DEFAULT 0,
  conversions     integer NOT NULL DEFAULT 0,
  created_at      timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE marketing_campaigns ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Device insert marketing_campaigns"
  ON marketing_campaigns FOR INSERT TO anon, authenticated WITH CHECK (device_key != '');
CREATE POLICY "Device select marketing_campaigns"
  ON marketing_campaigns FOR SELECT TO anon, authenticated USING (device_key != '');
CREATE POLICY "Device update marketing_campaigns"
  ON marketing_campaigns FOR UPDATE TO anon, authenticated
  USING (device_key != '') WITH CHECK (device_key != '');

-- FASE 5: B2B affiliate partner network
CREATE TABLE IF NOT EXISTS affiliate_partners (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  device_key      text NOT NULL DEFAULT '',
  user_id         uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  partner_name    text NOT NULL DEFAULT '',
  partner_token   text NOT NULL DEFAULT 'AIPPIE-INTERNAL-2024',
  commission_pct  numeric(5,2) NOT NULL DEFAULT 10,
  total_referred  integer NOT NULL DEFAULT 0,
  total_earned_eur numeric(12,2) NOT NULL DEFAULT 0,
  status          text NOT NULL DEFAULT 'active',
  joined_at       timestamptz NOT NULL DEFAULT now(),
  created_at      timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE affiliate_partners ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Device insert affiliate_partners"
  ON affiliate_partners FOR INSERT TO anon, authenticated WITH CHECK (device_key != '');
CREATE POLICY "Device select affiliate_partners"
  ON affiliate_partners FOR SELECT TO anon, authenticated USING (device_key != '');
CREATE POLICY "Device update affiliate_partners"
  ON affiliate_partners FOR UPDATE TO anon, authenticated
  USING (device_key != '') WITH CHECK (device_key != '');

-- FASE 7: Videoconferencing sessions
CREATE TABLE IF NOT EXISTS conference_sessions (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  device_key      text NOT NULL DEFAULT '',
  user_id         uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  room_name       text NOT NULL DEFAULT '',
  host_name       text NOT NULL DEFAULT '',
  session_type    text NOT NULL DEFAULT '1on1',
  participant_count integer NOT NULL DEFAULT 1,
  started_at      timestamptz DEFAULT NULL,
  ended_at        timestamptz DEFAULT NULL,
  duration_secs   integer NOT NULL DEFAULT 0,
  screenshare_used boolean NOT NULL DEFAULT false,
  recording_url   text DEFAULT NULL,
  created_at      timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE conference_sessions ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Device insert conference_sessions"
  ON conference_sessions FOR INSERT TO anon, authenticated WITH CHECK (device_key != '');
CREATE POLICY "Device select conference_sessions"
  ON conference_sessions FOR SELECT TO anon, authenticated USING (device_key != '');
CREATE POLICY "Device update conference_sessions"
  ON conference_sessions FOR UPDATE TO anon, authenticated
  USING (device_key != '') WITH CHECK (device_key != '');

-- FASE 7: Calendar appointments
CREATE TABLE IF NOT EXISTS calendar_appointments (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  device_key    text NOT NULL DEFAULT '',
  user_id       uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  title         text NOT NULL DEFAULT '',
  description   text NOT NULL DEFAULT '',
  attendees     text[] NOT NULL DEFAULT '{}',
  start_time    timestamptz NOT NULL DEFAULT now(),
  end_time      timestamptz NOT NULL DEFAULT now(),
  location      text NOT NULL DEFAULT 'Virtual',
  meeting_link  text DEFAULT NULL,
  status        text NOT NULL DEFAULT 'scheduled',
  created_at    timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE calendar_appointments ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Device insert calendar_appointments"
  ON calendar_appointments FOR INSERT TO anon, authenticated WITH CHECK (device_key != '');
CREATE POLICY "Device select calendar_appointments"
  ON calendar_appointments FOR SELECT TO anon, authenticated USING (device_key != '');
CREATE POLICY "Device update calendar_appointments"
  ON calendar_appointments FOR UPDATE TO anon, authenticated
  USING (device_key != '') WITH CHECK (device_key != '');
CREATE POLICY "Device delete calendar_appointments"
  ON calendar_appointments FOR DELETE TO anon, authenticated USING (device_key != '');

-- FASE 8: Media video hub
CREATE TABLE IF NOT EXISTS media_assets_v2 (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  device_key    text NOT NULL DEFAULT '',
  user_id       uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  asset_name    text NOT NULL DEFAULT '',
  asset_type    text NOT NULL DEFAULT 'video',
  provider      text NOT NULL DEFAULT 's3',
  pointer_url   text NOT NULL DEFAULT '',
  size_mb       numeric(10,2) NOT NULL DEFAULT 0,
  duration_secs integer NOT NULL DEFAULT 0,
  access_role   text NOT NULL DEFAULT 'owner',
  tags          text[] NOT NULL DEFAULT '{}',
  created_at    timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE media_assets_v2 ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Device insert media_assets_v2"
  ON media_assets_v2 FOR INSERT TO anon, authenticated WITH CHECK (device_key != '');
CREATE POLICY "Device select media_assets_v2"
  ON media_assets_v2 FOR SELECT TO anon, authenticated USING (device_key != '');

-- FASE 9: Daily life autopilot / grocery orders
CREATE TABLE IF NOT EXISTS autopilot_orders (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  device_key      text NOT NULL DEFAULT '',
  user_id         uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  order_type      text NOT NULL DEFAULT 'grocery',
  provider        text NOT NULL DEFAULT 'albert_heijn',
  items           jsonb NOT NULL DEFAULT '[]'::jsonb,
  total_eur       numeric(10,2) NOT NULL DEFAULT 0,
  budget_limit_eur numeric(10,2) NOT NULL DEFAULT 150,
  status          text NOT NULL DEFAULT 'pending',
  scheduled_for   timestamptz DEFAULT NULL,
  dispatched_at   timestamptz DEFAULT NULL,
  created_at      timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE autopilot_orders ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Device insert autopilot_orders"
  ON autopilot_orders FOR INSERT TO anon, authenticated WITH CHECK (device_key != '');
CREATE POLICY "Device select autopilot_orders"
  ON autopilot_orders FOR SELECT TO anon, authenticated USING (device_key != '');
CREATE POLICY "Device update autopilot_orders"
  ON autopilot_orders FOR UPDATE TO anon, authenticated
  USING (device_key != '') WITH CHECK (device_key != '');

-- Update roadmap_phases with detailed V55 10-Fasen data
DELETE FROM roadmap_phases WHERE phase_number BETWEEN 1 AND 10;

INSERT INTO roadmap_phases (phase_number, title_en, title_nl, description_en, status, icon_key) VALUES
(1,  'Core AI Bookkeeper',           'Kernmodule AI Boekhouder',         'Automatic OCR expense scraping, real-time ledger mutations, QuickBooks Enterprise sync, and direct Hacienda/Belastingdienst filing via authorized EDI endpoints.', 'active', 'file-text'),
(2,  'Smart Home IoT Hub',            'Slim Thuis IoT Omgeving',          'Ambient Smart Home IoT environment with budget limit alerts pushed to smart displays, Smart TV corporate dashboards, and real-time spend monitoring across all connected devices.', 'planned', 'home'),
(3,  'Encrypted VoIP Network',        'Versleuteld VoIP Netwerk',         'Secure embedded VoIP calling network with E2EE privacy loops, automatic call audio summarization AI triggers, and sovereign peer-to-peer tunnels isolated from state surveillance.', 'active', 'phone'),
(4,  'Autonomous Campaign Generator','Autonome Campagne Generator',       'Autonomous social media marketing ad generation, cross-platform Google/Facebook Ads segmentations, A/B copy testing, and automated budget allocation per campaign KPI.', 'planned', 'megaphone'),
(5,  'B2B Affiliate Partner Network','B2B Affiliate Partnernetwerk',      'Multi-agent affiliate partner network with partner tokens (AIPPIE-INTERNAL-2024), automated commission balances, real-time referral tracking, and payout reconciliation.', 'planned', 'users'),
(6,  'Live AI Voice Command Engine', 'Live AI Stemcommando Engine',       'Conversational AI virtual assistant executing database mutations natively via voice commands, with active video rendering, Whisper-1 transcription, and real-time ledger inserts mid-call.', 'active', 'mic'),
(7,  'Videoconferencing Suite',       'Videoconferentie Suite',           'In-app encrypted videoconferencing with native screensharing engines, group and 1-on-1 sessions, calendar management integrations, and appointment scheduling linked to client profiles.', 'active', 'video'),
(8,  'Multimedia Video Hub',          'Multimedia Video Hub',             'Hosted video structure connecting recordings to zero-weight cloud pointers (AWS S3, Google Drive, Dropbox) with strict role-based data access controls and asset tagging.', 'planned', 'play-circle'),
(9,  'Daily Life Autopilot',          'Dagelijks Leven Autopiloot',       'Automated grocery order dispatching linked via API to Albert Heijn and Instacart networks with budget limit warning triggers and smart recurring order management.', 'planned', 'shopping-cart'),
(10, 'Certified Autonomous Accountant','Gecertificeerde Autonome Accountant','Real-time fiscal strategy auditing, automatic corporate tax filing declarations, 24/7 proactive ledger smart alerts, and full compliance with Spanish LIS, Dutch VPB, and OECD BEPS nexus rules.', 'active', 'shield-check');

-- Indexes
CREATE INDEX IF NOT EXISTS idx_iot_alerts_device ON iot_budget_alerts(device_key, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_campaigns_device ON marketing_campaigns(device_key, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_affiliates_device ON affiliate_partners(device_key, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_conferences_device ON conference_sessions(device_key, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_calendar_device ON calendar_appointments(device_key, start_time ASC);
CREATE INDEX IF NOT EXISTS idx_media_device ON media_assets_v2(device_key, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_autopilot_device ON autopilot_orders(device_key, created_at DESC);
