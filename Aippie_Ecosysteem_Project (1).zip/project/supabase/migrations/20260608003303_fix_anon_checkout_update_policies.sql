-- Allow anon/authenticated to update used_seats on a license they just created via checkout
CREATE POLICY "Anyone can update own license used_seats"
  ON aippietax_active_licenses
  FOR UPDATE
  TO anon, authenticated
  USING (true)
  WITH CHECK (true);

-- Allow anon/authenticated to update their own activation heartbeat
CREATE POLICY "Anyone can update own activation heartbeat"
  ON license_activations
  FOR UPDATE
  TO anon, authenticated
  USING ((device_key IS NOT NULL) AND (length(trim(device_key)) > 0))
  WITH CHECK ((device_key IS NOT NULL) AND (length(trim(device_key)) > 0));