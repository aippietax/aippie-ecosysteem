CREATE TABLE IF NOT EXISTS whatsapp_messages (
  id             uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  wa_message_id  text UNIQUE,
  from_number    text NOT NULL,
  from_name      text,
  to_number      text,
  message_text   text,
  direction      text NOT NULL CHECK (direction IN ('inbound', 'outbound')),
  received_at    timestamptz DEFAULT now(),
  is_read        boolean DEFAULT false,
  device_key     text,
  created_at     timestamptz DEFAULT now()
);

ALTER TABLE whatsapp_messages ENABLE ROW LEVEL SECURITY;

CREATE POLICY "wa_select" ON whatsapp_messages FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "wa_insert" ON whatsapp_messages FOR INSERT TO anon, authenticated WITH CHECK (true);
CREATE POLICY "wa_update" ON whatsapp_messages FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);

CREATE TABLE IF NOT EXISTS service_credentials (
  id          uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  device_key  text NOT NULL,
  service     text NOT NULL,
  label       text NOT NULL,
  value       text NOT NULL,
  created_at  timestamptz DEFAULT now(),
  UNIQUE (device_key, service, label)
);

ALTER TABLE service_credentials ENABLE ROW LEVEL SECURITY;

CREATE POLICY "sc_select" ON service_credentials FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "sc_insert" ON service_credentials FOR INSERT TO anon, authenticated WITH CHECK (true);
CREATE POLICY "sc_update" ON service_credentials FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
CREATE POLICY "sc_delete" ON service_credentials FOR DELETE TO anon, authenticated USING (true);
