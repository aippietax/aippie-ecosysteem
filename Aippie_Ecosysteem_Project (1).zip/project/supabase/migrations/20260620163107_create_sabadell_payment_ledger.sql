
-- Add ledger balance to digital_trusts
ALTER TABLE digital_trusts ADD COLUMN IF NOT EXISTS ledger_balance numeric(12,2) NOT NULL DEFAULT 0;

-- Immutable hash-chain payment log (administrative audit trail)
CREATE TABLE IF NOT EXISTS sabadell_payment_log (
  id               uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  apt_id           text NOT NULL,
  trust_id         uuid REFERENCES digital_trusts(id) ON DELETE SET NULL,
  amount           numeric(12,2) NOT NULL,
  reference        text NOT NULL,
  transaction_date timestamptz NOT NULL,
  status           text NOT NULL DEFAULT 'confirmed',
  raw_payload      jsonb,
  payload_hash     text NOT NULL,
  prev_hash        text NOT NULL DEFAULT '0000000000000000',
  created_at       timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE sabadell_payment_log ENABLE ROW LEVEL SECURITY;

-- Service role only — webhook writes with service key, no direct user access
CREATE POLICY "no_user_select_payment_log" ON sabadell_payment_log FOR SELECT
  TO authenticated USING (false);
CREATE POLICY "no_user_insert_payment_log" ON sabadell_payment_log FOR INSERT
  TO authenticated WITH CHECK (false);
CREATE POLICY "no_user_update_payment_log" ON sabadell_payment_log FOR UPDATE
  TO authenticated USING (false);
CREATE POLICY "no_user_delete_payment_log" ON sabadell_payment_log FOR DELETE
  TO authenticated USING (false);

-- Index for fast reference lookups
CREATE INDEX IF NOT EXISTS idx_sabadell_log_reference ON sabadell_payment_log(reference);
CREATE INDEX IF NOT EXISTS idx_sabadell_log_apt_id    ON sabadell_payment_log(apt_id);
