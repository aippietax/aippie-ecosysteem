/*
  # Call dispatch system — dual-role architecture

  1. New Tables

    ## translator_sessions
    Tracks each translator's online/offline status and current assignment.
      - `id` (uuid, PK)
      - `user_id` (uuid, FK → auth.users) — the translator's auth identity
      - `corridor` (text) — 'en-es' | 'nl-es'
      - `status` (text) — 'online' | 'offline' | 'busy'
      - `updated_at` (timestamptz)

    ## call_requests
    Represents a client's dispatch broadcast waiting for a translator.
      - `id` (uuid, PK)
      - `client_user_id` (uuid, FK → auth.users)
      - `corridor` (text) — 'en-es' | 'nl-es'
      - `status` (text) — 'pending' | 'accepted' | 'fallback' | 'ended'
      - `translator_user_id` (uuid, nullable) — set when a translator accepts
      - `accepted_at` (timestamptz, nullable)
      - `fallback_at` (timestamptz, nullable)
      - `created_at` (timestamptz)

  2. Security (RLS)

    translator_sessions:
      - Translators can read all online sessions (needed to show count)
      - Translators can INSERT and UPDATE their own row only
      - Clients can SELECT to get online translator count

    call_requests:
      - Clients can INSERT their own requests
      - Clients can SELECT their own requests (to watch status)
      - Translators can SELECT pending requests for their corridor
      - Translators can UPDATE a request to 'accepted' (once, their own claim)

  3. Realtime
    Both tables use Supabase Realtime (enabled via replica identity).
*/

-- ── translator_sessions ──────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS translator_sessions (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id     uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  corridor    text NOT NULL DEFAULT 'en-es',
  status      text NOT NULL DEFAULT 'offline'
                CHECK (status IN ('online','offline','busy')),
  updated_at  timestamptz DEFAULT now(),
  UNIQUE(user_id)
);

ALTER TABLE translator_sessions ENABLE ROW LEVEL SECURITY;

ALTER TABLE translator_sessions REPLICA IDENTITY FULL;

CREATE POLICY "Anyone authenticated can view translator sessions"
  ON translator_sessions FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Translators can insert own session"
  ON translator_sessions FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Translators can update own session"
  ON translator_sessions FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- ── call_requests ────────────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS call_requests (
  id                   uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  client_user_id       uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  corridor             text NOT NULL DEFAULT 'en-es',
  status               text NOT NULL DEFAULT 'pending'
                         CHECK (status IN ('pending','accepted','fallback','ended')),
  translator_user_id   uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  accepted_at          timestamptz,
  fallback_at          timestamptz,
  created_at           timestamptz DEFAULT now()
);

ALTER TABLE call_requests ENABLE ROW LEVEL SECURITY;

ALTER TABLE call_requests REPLICA IDENTITY FULL;

CREATE POLICY "Clients can insert own requests"
  ON call_requests FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = client_user_id);

CREATE POLICY "Clients can view own requests"
  ON call_requests FOR SELECT
  TO authenticated
  USING (auth.uid() = client_user_id);

CREATE POLICY "Translators can view pending requests"
  ON call_requests FOR SELECT
  TO authenticated
  USING (
    status = 'pending'
    AND EXISTS (
      SELECT 1 FROM translator_sessions ts
      WHERE ts.user_id = auth.uid()
      AND ts.corridor = call_requests.corridor
      AND ts.status = 'online'
    )
  );

CREATE POLICY "Translators can accept a pending request"
  ON call_requests FOR UPDATE
  TO authenticated
  USING (
    status = 'pending'
    AND translator_user_id IS NULL
    AND EXISTS (
      SELECT 1 FROM translator_sessions ts
      WHERE ts.user_id = auth.uid()
      AND ts.corridor = call_requests.corridor
      AND ts.status = 'online'
    )
  )
  WITH CHECK (
    translator_user_id = auth.uid()
    AND status IN ('accepted', 'ended', 'fallback')
  );

CREATE POLICY "Clients can update own request status"
  ON call_requests FOR UPDATE
  TO authenticated
  USING (auth.uid() = client_user_id)
  WITH CHECK (auth.uid() = client_user_id);

-- ── indexes ──────────────────────────────────────────────────────────────────

CREATE INDEX IF NOT EXISTS idx_call_requests_status   ON call_requests(status);
CREATE INDEX IF NOT EXISTS idx_call_requests_corridor ON call_requests(corridor, status);
CREATE INDEX IF NOT EXISTS idx_translator_sessions_status ON translator_sessions(status, corridor);
