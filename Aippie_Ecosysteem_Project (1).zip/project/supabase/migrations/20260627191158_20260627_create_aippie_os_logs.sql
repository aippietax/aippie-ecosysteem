CREATE TABLE aippie_os_logs (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id     text NOT NULL,
  raw_text    text NOT NULL,
  intent      text NOT NULL,
  confidence  float NOT NULL,
  status      text NOT NULL,
  action_taken text NOT NULL,
  created_at  timestamptz DEFAULT now()
);

ALTER TABLE aippie_os_logs ENABLE ROW LEVEL SECURITY;

CREATE POLICY "select_own_os_logs" ON aippie_os_logs FOR SELECT
  TO authenticated USING (auth.uid()::text = user_id);

CREATE POLICY "insert_own_os_logs" ON aippie_os_logs FOR INSERT
  TO authenticated WITH CHECK (auth.uid()::text = user_id);

CREATE POLICY "update_own_os_logs" ON aippie_os_logs FOR UPDATE
  TO authenticated USING (auth.uid()::text = user_id) WITH CHECK (auth.uid()::text = user_id);

CREATE POLICY "delete_own_os_logs" ON aippie_os_logs FOR DELETE
  TO authenticated USING (auth.uid()::text = user_id);
