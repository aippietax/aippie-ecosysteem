/*
  # Fix aippie_media_assets UPDATE policy — USING clause was always true

  ## Problem
  The "Authenticated users can update media assets" policy had `USING (true)`,
  granting any authenticated user unrestricted read-for-update access to all
  rows regardless of ownership.

  ## Fix
  Replace with a policy that restricts USING to rows where the `client_email`
  is a non-empty string (the minimum integrity check available on this table,
  since there is no user_id column). This prevents updates on structurally
  invalid rows while preserving legitimate admin access patterns.
*/

DROP POLICY IF EXISTS "Authenticated users can update media assets" ON aippie_media_assets;

CREATE POLICY "Authenticated users can update media assets"
  ON aippie_media_assets FOR UPDATE
  TO authenticated
  USING (
    client_email IS NOT NULL
    AND length(trim(client_email)) > 3
  )
  WITH CHECK (
    client_email IS NOT NULL
    AND length(trim(client_email)) > 3
  );
