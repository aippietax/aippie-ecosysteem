-- ── Secure Chat: PIN profiles ───────────────────────────────────────────────
CREATE TABLE secure_chat_pins (
  id            uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id       uuid        UNIQUE REFERENCES auth.users(id) ON DELETE CASCADE,
  pin_code      text        UNIQUE NOT NULL CHECK (length(pin_code) = 5 AND pin_code ~ '^\d+$'),
  display_name  text        NOT NULL,
  avatar_color  text        NOT NULL DEFAULT '#3B82F6',
  ghost_mode    boolean     NOT NULL DEFAULT false,
  last_seen_at  timestamptz DEFAULT now(),
  created_at    timestamptz DEFAULT now()
);

ALTER TABLE secure_chat_pins ENABLE ROW LEVEL SECURITY;

-- Any authenticated user can read pins (needed for contact lookup by PIN)
CREATE POLICY "select_pins" ON secure_chat_pins FOR SELECT
  TO authenticated USING (true);

CREATE POLICY "insert_own_pin" ON secure_chat_pins FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

CREATE POLICY "update_own_pin" ON secure_chat_pins FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "delete_own_pin" ON secure_chat_pins FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

-- ── Secure Chat: Contact list ────────────────────────────────────────────────
CREATE TABLE secure_chat_contacts (
  id                uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
  owner_pin         text        NOT NULL,
  contact_pin       text        NOT NULL,
  nickname          text,
  appear_offline_to boolean     NOT NULL DEFAULT false,
  is_blocked        boolean     NOT NULL DEFAULT false,
  added_at          timestamptz DEFAULT now(),
  UNIQUE(owner_pin, contact_pin)
);

ALTER TABLE secure_chat_contacts ENABLE ROW LEVEL SECURITY;

CREATE POLICY "select_own_contacts" ON secure_chat_contacts FOR SELECT
  TO authenticated
  USING (owner_pin = (SELECT pin_code FROM secure_chat_pins WHERE user_id = auth.uid()));

CREATE POLICY "insert_own_contacts" ON secure_chat_contacts FOR INSERT
  TO authenticated
  WITH CHECK (owner_pin = (SELECT pin_code FROM secure_chat_pins WHERE user_id = auth.uid()));

CREATE POLICY "update_own_contacts" ON secure_chat_contacts FOR UPDATE
  TO authenticated
  USING  (owner_pin = (SELECT pin_code FROM secure_chat_pins WHERE user_id = auth.uid()))
  WITH CHECK (owner_pin = (SELECT pin_code FROM secure_chat_pins WHERE user_id = auth.uid()));

CREATE POLICY "delete_own_contacts" ON secure_chat_contacts FOR DELETE
  TO authenticated
  USING (owner_pin = (SELECT pin_code FROM secure_chat_pins WHERE user_id = auth.uid()));

-- ── Secure Chat: Messages ────────────────────────────────────────────────────
CREATE TABLE secure_chat_messages (
  id            uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
  from_pin      text        NOT NULL,
  to_pin        text        NOT NULL,
  content       text        NOT NULL,
  detected_lang text,
  is_read       boolean     NOT NULL DEFAULT false,
  read_at       timestamptz,
  expires_at    timestamptz,
  is_deleted    boolean     NOT NULL DEFAULT false,
  created_at    timestamptz DEFAULT now()
);

CREATE INDEX ON secure_chat_messages (from_pin, to_pin, created_at);
CREATE INDEX ON secure_chat_messages (to_pin, is_read);

ALTER TABLE secure_chat_messages ENABLE ROW LEVEL SECURITY;

CREATE POLICY "select_own_messages" ON secure_chat_messages FOR SELECT
  TO authenticated
  USING (
    from_pin = (SELECT pin_code FROM secure_chat_pins WHERE user_id = auth.uid())
    OR
    to_pin   = (SELECT pin_code FROM secure_chat_pins WHERE user_id = auth.uid())
  );

CREATE POLICY "insert_own_messages" ON secure_chat_messages FOR INSERT
  TO authenticated
  WITH CHECK (from_pin = (SELECT pin_code FROM secure_chat_pins WHERE user_id = auth.uid()));

CREATE POLICY "update_own_messages" ON secure_chat_messages FOR UPDATE
  TO authenticated
  USING (
    from_pin = (SELECT pin_code FROM secure_chat_pins WHERE user_id = auth.uid())
    OR
    to_pin   = (SELECT pin_code FROM secure_chat_pins WHERE user_id = auth.uid())
  )
  WITH CHECK (
    from_pin = (SELECT pin_code FROM secure_chat_pins WHERE user_id = auth.uid())
    OR
    to_pin   = (SELECT pin_code FROM secure_chat_pins WHERE user_id = auth.uid())
  );

CREATE POLICY "delete_own_messages" ON secure_chat_messages FOR DELETE
  TO authenticated
  USING (from_pin = (SELECT pin_code FROM secure_chat_pins WHERE user_id = auth.uid()));
