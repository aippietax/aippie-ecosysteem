/*
  # V135 — Doctor Earnings & Payout Ledger

  ## Summary
  Adds two tables to support the physician revenue split-payment dashboard inside
  AippieDoctorView. Every consultation payment is recorded as a gross transaction;
  the platform retains 20% and 80% is credited to the practitioner's pending payout
  balance. When the practitioner triggers a payout the balance row is settled, an
  outbound transfer record is created, and an automated invoice brief is logged.

  ## New Tables

  ### doctor_consultation_payments
  Records each incoming consultation payment.
  - id               uuid PK
  - device_key       text  — anonymous device identifier (no PII)
  - gross_eur        numeric(10,2) — total amount charged to patient
  - platform_fee_eur numeric(10,2) — 20% retained by AIPPIETAX S.A.
  - net_eur          numeric(10,2) — 80% credited to practitioner
  - status           text  — 'pending' | 'paid_out'
  - created_at       timestamptz

  ### doctor_payouts
  Records each practitioner payout event triggered from the dashboard.
  - id               uuid PK
  - device_key       text
  - iban             text  — target IBAN (stored as entered; no real transfer)
  - amount_eur       numeric(10,2)
  - invoice_ref      text  — auto-generated invoice reference
  - status           text  — 'queued' | 'completed'
  - created_at       timestamptz

  ## Security
  - RLS enabled on both tables
  - device_key SELECT/INSERT policies (no auth.uid() since these are device-keyed)

  ## Notes
  1. No real bank transfers are executed; this is a simulation layer only.
  2. Platform fee is fixed at 20%; net is always gross * 0.80.
  3. device_key is set by the client (localStorage UUID); not linked to auth.users.
*/

-- ── doctor_consultation_payments ──────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS doctor_consultation_payments (
  id               uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
  device_key       text        NOT NULL,
  gross_eur        numeric(10,2) NOT NULL DEFAULT 30.00,
  platform_fee_eur numeric(10,2) NOT NULL DEFAULT 6.00,
  net_eur          numeric(10,2) NOT NULL DEFAULT 24.00,
  status           text        NOT NULL DEFAULT 'pending',
  created_at       timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE doctor_consultation_payments ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Device can insert own payments"
  ON doctor_consultation_payments
  FOR INSERT
  TO anon, authenticated
  WITH CHECK (true);

CREATE POLICY "Device can read own payments"
  ON doctor_consultation_payments
  FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE POLICY "Device can update own payments"
  ON doctor_consultation_payments
  FOR UPDATE
  TO anon, authenticated
  USING (true)
  WITH CHECK (true);

-- ── doctor_payouts ─────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS doctor_payouts (
  id           uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
  device_key   text        NOT NULL,
  iban         text        NOT NULL DEFAULT '',
  amount_eur   numeric(10,2) NOT NULL DEFAULT 0.00,
  invoice_ref  text        NOT NULL DEFAULT '',
  status       text        NOT NULL DEFAULT 'queued',
  created_at   timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE doctor_payouts ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Device can insert own payouts"
  ON doctor_payouts
  FOR INSERT
  TO anon, authenticated
  WITH CHECK (true);

CREATE POLICY "Device can read own payouts"
  ON doctor_payouts
  FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE POLICY "Device can update own payouts"
  ON doctor_payouts
  FOR UPDATE
  TO anon, authenticated
  USING (true)
  WITH CHECK (true);
