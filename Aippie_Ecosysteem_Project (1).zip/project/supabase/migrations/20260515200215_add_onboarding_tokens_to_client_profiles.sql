/*
  # Add onboarding activation tokens to client_profiles

  ## Summary
  Version 34 introduces a three-tier onboarding activation model.
  During first-load onboarding, users can:
    1. Activate AippieVoice (€14.99/mo) — sets voice_token = true
    2. Activate Trading Alpha (€99.99/mo) — sets trading_token = true
    3. Activate Silent Voice FREE for children — sets free_silent_voice = true (no payment)

  This migration adds three boolean columns to client_profiles to track these
  activation states per device. All default to false until explicitly activated.

  ## Modified Table: client_profiles
  - `voice_token`         boolean DEFAULT false — AippieVoice activated from onboarding
  - `trading_token`       boolean DEFAULT false — Trading Alpha activated from onboarding
  - `free_silent_voice`   boolean DEFAULT false — Silent Voice free child access permanently granted

  ## Notes
  - Uses IF NOT EXISTS guard so re-running is safe
  - No RLS policy changes needed — existing client_profiles policies cover these columns
*/

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'client_profiles' AND column_name = 'voice_token'
  ) THEN
    ALTER TABLE client_profiles ADD COLUMN voice_token boolean NOT NULL DEFAULT false;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'client_profiles' AND column_name = 'trading_token'
  ) THEN
    ALTER TABLE client_profiles ADD COLUMN trading_token boolean NOT NULL DEFAULT false;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'client_profiles' AND column_name = 'free_silent_voice'
  ) THEN
    ALTER TABLE client_profiles ADD COLUMN free_silent_voice boolean NOT NULL DEFAULT false;
  END IF;
END $$;
