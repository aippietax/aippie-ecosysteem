CREATE TABLE IF NOT EXISTS care_board_events (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  device_key  text NOT NULL DEFAULT 'anon',
  session_id  text NOT NULL DEFAULT 'anon',
  category    text NOT NULL,
  item_id     text NOT NULL,
  label       text NOT NULL,
  phrase_nl   text,
  phrase_en   text,
  lang_code   text NOT NULL DEFAULT 'nl',
  created_at  timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE care_board_events ENABLE ROW LEVEL SECURITY;

CREATE POLICY "insert_care_board_events" ON care_board_events
  FOR INSERT TO anon, authenticated WITH CHECK (true);

CREATE POLICY "select_own_care_board_events" ON care_board_events
  FOR SELECT TO anon, authenticated USING (true);
