
-- Shopping list
CREATE TABLE IF NOT EXISTS shopping_list (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  device_key text NOT NULL,
  item text NOT NULL,
  done boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);
ALTER TABLE shopping_list ENABLE ROW LEVEL SECURITY;
CREATE POLICY "select_own_shopping" ON shopping_list FOR SELECT TO authenticated USING (true);
CREATE POLICY "insert_own_shopping" ON shopping_list FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "update_own_shopping" ON shopping_list FOR UPDATE TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "delete_own_shopping" ON shopping_list FOR DELETE TO authenticated USING (true);
-- Allow anon for device-key based access
CREATE POLICY "anon_select_shopping" ON shopping_list FOR SELECT TO anon USING (true);
CREATE POLICY "anon_insert_shopping" ON shopping_list FOR INSERT TO anon WITH CHECK (true);

-- Health log
CREATE TABLE IF NOT EXISTS health_log (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  device_key text NOT NULL,
  energy_level int,
  note text,
  logged_at timestamptz DEFAULT now()
);
ALTER TABLE health_log ENABLE ROW LEVEL SECURITY;
CREATE POLICY "select_own_health" ON health_log FOR SELECT TO authenticated USING (true);
CREATE POLICY "insert_own_health" ON health_log FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "update_own_health" ON health_log FOR UPDATE TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "delete_own_health" ON health_log FOR DELETE TO authenticated USING (true);
CREATE POLICY "anon_insert_health" ON health_log FOR INSERT TO anon WITH CHECK (true);

-- User context tracking (Part 11)
CREATE TABLE IF NOT EXISTS la_context_log (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  device_key text NOT NULL,
  feature text NOT NULL,
  logged_at timestamptz DEFAULT now()
);
ALTER TABLE la_context_log ENABLE ROW LEVEL SECURITY;
CREATE POLICY "select_own_context" ON la_context_log FOR SELECT TO authenticated USING (true);
CREATE POLICY "insert_own_context" ON la_context_log FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "anon_insert_context" ON la_context_log FOR INSERT TO anon WITH CHECK (true);
