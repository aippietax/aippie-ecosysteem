CREATE POLICY "Anyone can insert license via checkout"
  ON aippietax_active_licenses
  FOR INSERT
  TO anon, authenticated
  WITH CHECK (true);