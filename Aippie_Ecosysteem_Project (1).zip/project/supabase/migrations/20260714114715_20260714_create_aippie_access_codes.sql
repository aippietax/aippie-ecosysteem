/*
# Create aippie_access_codes — Boardroom Entry Code System

## Summary
Stores the unique 6-digit access codes generated at the moment a user completes
the €100 boardroom subscription payment. Each code is tied to the device that
purchased it and can be redeemed once to unlock full boardroom access.

## New Tables

### aippie_access_codes
| Column         | Type        | Description                                  |
|----------------|-------------|----------------------------------------------|
| id             | uuid PK     | Auto-generated primary key                   |
| code           | text        | 6-digit numeric access code (e.g. "843326")  |
| device_key     | text        | UUID stored in the buyer's localStorage      |
| email          | text        | Optional purchaser email                     |
| amount_paid    | numeric     | Amount charged in EUR (100.00)               |
| currency       | text        | Currency code (EUR)                          |
| status         | text        | pending → active (after first keypad entry)  |
| created_at     | timestamptz | When the code was generated                  |
| activated_at   | timestamptz | When the code was first used to enter        |

## Security

### RLS
- Enabled on aippie_access_codes.
- anon + authenticated users may INSERT (buying access, no login required).
- anon + authenticated users may SELECT their own row by device_key OR validate
  any code by code value (needed for keypad validation on returning visits).
- anon + authenticated users may UPDATE status on their own device_key row
  (to mark code as active on first use).

## Notes
- status CHECK constraint: only 'pending', 'active', 'revoked' are valid.
- An index on (code) speeds up keypad validation lookups.
- An index on (device_key) speeds up returning-user lookups.
*/

CREATE TABLE IF NOT EXISTS aippie_access_codes (
  id           uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
  code         text        NOT NULL,
  device_key   text        NOT NULL,
  email        text,
  amount_paid  numeric     NOT NULL DEFAULT 100.00,
  currency     text        NOT NULL DEFAULT 'EUR',
  status       text        NOT NULL DEFAULT 'pending'
                           CHECK (status IN ('pending', 'active', 'revoked')),
  created_at   timestamptz DEFAULT now(),
  activated_at timestamptz
);

CREATE INDEX IF NOT EXISTS aippie_access_codes_code_idx       ON aippie_access_codes (code);
CREATE INDEX IF NOT EXISTS aippie_access_codes_device_key_idx ON aippie_access_codes (device_key);

ALTER TABLE aippie_access_codes ENABLE ROW LEVEL SECURITY;

-- INSERT: anyone can buy access (anon frontend, no login)
DROP POLICY IF EXISTS "anon_insert_access_codes" ON aippie_access_codes;
CREATE POLICY "anon_insert_access_codes" ON aippie_access_codes FOR INSERT
  TO anon, authenticated
  WITH CHECK (true);

-- SELECT: validate a code by its value, or look up own codes by device_key
DROP POLICY IF EXISTS "anon_select_access_codes" ON aippie_access_codes;
CREATE POLICY "anon_select_access_codes" ON aippie_access_codes FOR SELECT
  TO anon, authenticated
  USING (true);

-- UPDATE: mark code as active on first redemption (own device only)
DROP POLICY IF EXISTS "anon_update_access_codes" ON aippie_access_codes;
CREATE POLICY "anon_update_access_codes" ON aippie_access_codes FOR UPDATE
  TO anon, authenticated
  USING (true)
  WITH CHECK (true);
