-- Create test user with Business plan subscription
DO $$
DECLARE
  v_user_id uuid;
BEGIN
  -- Check if user already exists
  SELECT id INTO v_user_id FROM auth.users WHERE email = 'test@aippietax.com';

  IF v_user_id IS NULL THEN
    v_user_id := gen_random_uuid();

    INSERT INTO auth.users (
      id,
      instance_id,
      email,
      encrypted_password,
      email_confirmed_at,
      raw_app_meta_data,
      raw_user_meta_data,
      aud,
      role,
      created_at,
      updated_at,
      confirmation_token,
      recovery_token,
      email_change_token_new,
      email_change
    ) VALUES (
      v_user_id,
      '00000000-0000-0000-0000-000000000000',
      'test@aippietax.com',
      crypt('Test1234!', gen_salt('bf')),
      now(),
      '{"provider":"email","providers":["email"]}',
      '{"full_name":"Test User"}',
      'authenticated',
      'authenticated',
      now(),
      now(),
      '',
      '',
      '',
      ''
    );

    INSERT INTO auth.identities (
      id,
      user_id,
      identity_data,
      provider,
      provider_id,
      last_sign_in_at,
      created_at,
      updated_at
    ) VALUES (
      gen_random_uuid(),
      v_user_id,
      jsonb_build_object('sub', v_user_id::text, 'email', 'test@aippietax.com'),
      'email',
      'test@aippietax.com',
      now(),
      now(),
      now()
    );
  END IF;

  -- Upsert Business plan subscription
  INSERT INTO subscriptions (
    user_id,
    email,
    status,
    plan,
    plan_tier,
    amount,
    currency,
    included_minutes,
    overage_rate,
    started_at,
    expires_at
  ) VALUES (
    v_user_id,
    'test@aippietax.com',
    'active',
    'business',
    'corporate_b2b',
    79.99,
    'EUR',
    200,
    0.50,
    now(),
    now() + interval '1 year'
  )
  ON CONFLICT DO NOTHING;

END $$;
