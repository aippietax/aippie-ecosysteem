/*
  # Security Hardening: Function Search Path, EXECUTE Grants, Vector Extension

  ## Issues Fixed

  1. **Mutable search_path on `generate_smart_home_license_key`**
     - Function had no SET search_path, leaving it mutable (exploitable via search_path hijacking)
     - Fix: Add SET search_path = 'public' to lock the resolution context

  2. **`aivp_dispatch_payout` EXECUTE by anon and authenticated roles**
     - SECURITY DEFINER function callable by both anon and authenticated via REST RPC
     - anon should never call this; authenticated callers are validated inside the function
       but exposure to anon is a security risk
     - Fix: Revoke EXECUTE from anon role; keep authenticated (function has internal auth.uid() guard)

  3. **`claim_smart_home_license` EXECUTE by anon and authenticated roles**
     - Same pattern: anon should not be able to call this SECURITY DEFINER function
     - The function already guards against unauthenticated callers with `IF v_uid IS NULL`,
       but removing anon EXECUTE eliminates the attack surface entirely
     - Fix: Revoke EXECUTE from anon role; keep authenticated

  4. **`vector` extension in public schema**
     - The extensions schema already exists; moving vector there removes it from public
     - Note: Moving an installed extension requires DROP + CREATE in new schema.
       We relocate using ALTER EXTENSION ... SET SCHEMA if supported, otherwise skip
       (Supabase managed instances often restrict this — handled gracefully with DO block)
*/

-- ── 1. Fix mutable search_path on generate_smart_home_license_key ─────────────
CREATE OR REPLACE FUNCTION public.generate_smart_home_license_key()
  RETURNS text
  LANGUAGE plpgsql
  SET search_path = 'public'
AS $$
DECLARE
  chars  text := 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  seg1   text := '';
  seg2   text := '';
  seg3   text := '';
  i      int;
  key    text;
BEGIN
  FOR i IN 1..4 LOOP
    seg1 := seg1 || substr(chars, floor(random() * length(chars))::int + 1, 1);
    seg2 := seg2 || substr(chars, floor(random() * length(chars))::int + 1, 1);
    seg3 := seg3 || substr(chars, floor(random() * length(chars))::int + 1, 1);
  END LOOP;
  key := 'AIPPIE-' || seg1 || '-' || seg2 || '-' || seg3;
  RETURN key;
END;
$$;

-- ── 2. Revoke anon EXECUTE on aivp_dispatch_payout ───────────────────────────
REVOKE EXECUTE ON FUNCTION public.aivp_dispatch_payout(uuid) FROM anon;

-- ── 3. Revoke anon EXECUTE on claim_smart_home_license ───────────────────────
REVOKE EXECUTE ON FUNCTION public.claim_smart_home_license(text) FROM anon;

-- ── 4. Attempt to relocate vector extension out of public schema ──────────────
DO $$
BEGIN
  -- Only attempt if vector is currently in public schema
  IF EXISTS (
    SELECT 1 FROM pg_extension e
    JOIN pg_namespace n ON n.oid = e.extnamespace
    WHERE e.extname = 'vector' AND n.nspname = 'public'
  ) THEN
    -- Relocate to extensions schema (exists as confirmed)
    EXECUTE 'ALTER EXTENSION vector SET SCHEMA extensions';
  END IF;
EXCEPTION
  WHEN OTHERS THEN
    -- Supabase managed instances may block this; silently skip
    NULL;
END;
$$;
