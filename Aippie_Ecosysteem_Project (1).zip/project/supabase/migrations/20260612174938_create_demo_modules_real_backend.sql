
-- ── Morning Briefing ──────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS morning_briefing_cache (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  date        date NOT NULL DEFAULT CURRENT_DATE,
  asset_class text NOT NULL, -- stocks | crypto | forex | commodities
  symbol      text NOT NULL,
  name        text NOT NULL,
  price       numeric(18,4) NOT NULL,
  change_pct  numeric(8,4) NOT NULL,
  volume_b    numeric(10,2),
  sparkline   numeric[] DEFAULT '{}',
  created_at  timestamptz DEFAULT now()
);
ALTER TABLE morning_briefing_cache ENABLE ROW LEVEL SECURITY;
CREATE POLICY "select_briefing_all" ON morning_briefing_cache FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "insert_briefing_auth" ON morning_briefing_cache FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "update_briefing_auth" ON morning_briefing_cache FOR UPDATE TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "delete_briefing_auth" ON morning_briefing_cache FOR DELETE TO authenticated USING (true);

CREATE TABLE IF NOT EXISTS morning_briefing_alerts (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  date        date NOT NULL DEFAULT CURRENT_DATE,
  severity    text NOT NULL CHECK (severity IN ('critical','high','medium','low')),
  asset       text NOT NULL,
  message     text NOT NULL,
  source      text NOT NULL DEFAULT 'AI',
  created_at  timestamptz DEFAULT now()
);
ALTER TABLE morning_briefing_alerts ENABLE ROW LEVEL SECURITY;
CREATE POLICY "select_alerts_all" ON morning_briefing_alerts FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "insert_alerts_auth" ON morning_briefing_alerts FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "update_alerts_auth" ON morning_briefing_alerts FOR UPDATE TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "delete_alerts_auth" ON morning_briefing_alerts FOR DELETE TO authenticated USING (true);

-- ── VoIP Script History ───────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS voip_script_history (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  device_key  text NOT NULL,
  script_type text NOT NULL CHECK (script_type IN ('hotel','restaurant','doctor','service')),
  language    text NOT NULL DEFAULT 'nl',
  user_name   text,
  target_name text,
  date_str    text,
  time_str    text,
  guests      text,
  notes       text,
  completed   boolean DEFAULT false,
  created_at  timestamptz DEFAULT now()
);
ALTER TABLE voip_script_history ENABLE ROW LEVEL SECURITY;
CREATE POLICY "select_voip_own" ON voip_script_history FOR SELECT TO anon, authenticated USING (device_key = coalesce(current_setting('request.headers', true)::json->>'x-device-key', ''));
CREATE POLICY "insert_voip_any" ON voip_script_history FOR INSERT TO anon, authenticated WITH CHECK (true);
CREATE POLICY "update_voip_own" ON voip_script_history FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
CREATE POLICY "delete_voip_own" ON voip_script_history FOR DELETE TO anon, authenticated USING (true);

-- ── Signal Radar ──────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS signal_radar_items (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  type         text NOT NULL CHECK (type IN ('news','signal')),
  source       text NOT NULL,
  headline     text NOT NULL,
  sentiment    text CHECK (sentiment IN ('bullish','bearish','neutral')),
  sentiment_score numeric(4,2),
  asset        text,
  direction    text CHECK (direction IN ('BUY','SELL','HOLD')),
  confidence   integer CHECK (confidence BETWEEN 0 AND 100),
  status       text DEFAULT 'pending' CHECK (status IN ('pending','executing','completed','cancelled')),
  pnl          numeric(10,2),
  created_at   timestamptz DEFAULT now()
);
ALTER TABLE signal_radar_items ENABLE ROW LEVEL SECURITY;
CREATE POLICY "select_signals_all" ON signal_radar_items FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "insert_signals_auth" ON signal_radar_items FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "update_signals_auth" ON signal_radar_items FOR UPDATE TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "delete_signals_auth" ON signal_radar_items FOR DELETE TO authenticated USING (true);

-- ── Tournament ────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS tournament_traders (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  display_name text NOT NULL,
  avatar_color text NOT NULL DEFAULT '#38bdf8',
  strategy    text NOT NULL CHECK (strategy IN ('MOMENTUM','MEAN-REV','BREAKOUT','SCALP','SWING','AI-HYBRID')),
  portfolio   numeric(14,2) NOT NULL DEFAULT 10000,
  pnl         numeric(12,2) NOT NULL DEFAULT 0,
  win_rate    numeric(5,2) NOT NULL DEFAULT 50,
  trades      integer NOT NULL DEFAULT 0,
  rank        integer,
  is_user     boolean DEFAULT false,
  device_key  text,
  created_at  timestamptz DEFAULT now()
);
ALTER TABLE tournament_traders ENABLE ROW LEVEL SECURITY;
CREATE POLICY "select_traders_all" ON tournament_traders FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "insert_traders_any" ON tournament_traders FOR INSERT TO anon, authenticated WITH CHECK (true);
CREATE POLICY "update_traders_any" ON tournament_traders FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
CREATE POLICY "delete_traders_own" ON tournament_traders FOR DELETE TO anon, authenticated USING (true);

CREATE TABLE IF NOT EXISTS tournament_events (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  trader_id   uuid REFERENCES tournament_traders(id) ON DELETE CASCADE,
  trader_name text NOT NULL,
  action      text NOT NULL CHECK (action IN ('BUY','SELL','SHORT','COVER')),
  asset       text NOT NULL,
  price       numeric(14,4) NOT NULL,
  qty         numeric(14,4) NOT NULL,
  pnl         numeric(10,2),
  created_at  timestamptz DEFAULT now()
);
ALTER TABLE tournament_events ENABLE ROW LEVEL SECURITY;
CREATE POLICY "select_events_all" ON tournament_events FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "insert_events_any" ON tournament_events FOR INSERT TO anon, authenticated WITH CHECK (true);
CREATE POLICY "update_events_any" ON tournament_events FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
CREATE POLICY "delete_events_any" ON tournament_events FOR DELETE TO anon, authenticated USING (true);

-- ── Live Stage Tickets ────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS live_stage_events (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title       text NOT NULL,
  artist      text NOT NULL,
  date_str    text NOT NULL,
  is_live     boolean DEFAULT false,
  stream_url  text,
  created_at  timestamptz DEFAULT now()
);
ALTER TABLE live_stage_events ENABLE ROW LEVEL SECURITY;
CREATE POLICY "select_events_all2" ON live_stage_events FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "insert_events_auth2" ON live_stage_events FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "update_events_auth2" ON live_stage_events FOR UPDATE TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "delete_events_auth2" ON live_stage_events FOR DELETE TO authenticated USING (true);

CREATE TABLE IF NOT EXISTS live_stage_tickets (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  event_id    uuid REFERENCES live_stage_events(id) ON DELETE CASCADE,
  ticket_code text NOT NULL UNIQUE,
  device_key  text,
  redeemed    boolean DEFAULT false,
  redeemed_at timestamptz,
  created_at  timestamptz DEFAULT now()
);
ALTER TABLE live_stage_tickets ENABLE ROW LEVEL SECURITY;
CREATE POLICY "select_tickets_all" ON live_stage_tickets FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "insert_tickets_any" ON live_stage_tickets FOR INSERT TO anon, authenticated WITH CHECK (true);
CREATE POLICY "update_tickets_any" ON live_stage_tickets FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
CREATE POLICY "delete_tickets_any" ON live_stage_tickets FOR DELETE TO anon, authenticated USING (true);

-- ── Robotics Telemetry ────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS robotics_telemetry (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  unit_id     text NOT NULL DEFAULT 'UNIT-001',
  system      text NOT NULL,
  status      text NOT NULL CHECK (status IN ('ONLINE','STANDBY','ALERT','OFFLINE')),
  value       numeric(10,4),
  unit        text,
  note        text,
  created_at  timestamptz DEFAULT now()
);
ALTER TABLE robotics_telemetry ENABLE ROW LEVEL SECURITY;
CREATE POLICY "select_telemetry_all" ON robotics_telemetry FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "insert_telemetry_any" ON robotics_telemetry FOR INSERT TO anon, authenticated WITH CHECK (true);
CREATE POLICY "update_telemetry_any" ON robotics_telemetry FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
CREATE POLICY "delete_telemetry_any" ON robotics_telemetry FOR DELETE TO anon, authenticated USING (true);

-- ── CyberSuit Config ──────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS cybersuit_configs (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  device_key  text NOT NULL UNIQUE,
  suit_name   text DEFAULT 'AIPPIE-SUIT-01',
  phase       integer DEFAULT 3,
  bio_filter  boolean DEFAULT true,
  neural_sync boolean DEFAULT false,
  temp_target numeric(4,1) DEFAULT 37.0,
  power_mode  text DEFAULT 'ECO' CHECK (power_mode IN ('ECO','NORMAL','PERFORMANCE','MAX')),
  notes       text,
  created_at  timestamptz DEFAULT now(),
  updated_at  timestamptz DEFAULT now()
);
ALTER TABLE cybersuit_configs ENABLE ROW LEVEL SECURITY;
CREATE POLICY "select_suit_all" ON cybersuit_configs FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "insert_suit_any" ON cybersuit_configs FOR INSERT TO anon, authenticated WITH CHECK (true);
CREATE POLICY "update_suit_any" ON cybersuit_configs FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
CREATE POLICY "delete_suit_any" ON cybersuit_configs FOR DELETE TO anon, authenticated USING (true);

-- Seed default live stage event + demo tickets
INSERT INTO live_stage_events (title, artist, date_str, is_live)
VALUES ('Aippie Launch Concert', 'DJ Aippie', '2026-07-01', true)
ON CONFLICT DO NOTHING;

INSERT INTO live_stage_tickets (ticket_code, event_id)
SELECT t.code, e.id
FROM (VALUES ('AIPPIE-VIP'),('STAGE-001'),('STAGE-002'),('VIP-2024'),('DEMO-PASS')) AS t(code)
CROSS JOIN live_stage_events e
WHERE e.title = 'Aippie Launch Concert'
ON CONFLICT (ticket_code) DO NOTHING;

-- Seed 10 tournament traders
INSERT INTO tournament_traders (display_name, avatar_color, strategy, portfolio, pnl, win_rate, trades, rank)
VALUES
  ('AlphaWolf_7',   '#f59e0b', 'MOMENTUM',  185432.50, 85432.50, 78.4, 1247, 1),
  ('NeuralEdge',    '#4ade80', 'AI-HYBRID',  162847.30, 62847.30, 74.1, 983,  2),
  ('QuantBot_X',    '#38bdf8', 'BREAKOUT',   154392.10, 54392.10, 71.8, 1102, 3),
  ('DarkPool_Pro',  '#a78bfa', 'SCALP',      147231.80, 47231.80, 69.3, 2341, 4),
  ('MomentumKing',  '#fb7185', 'MEAN-REV',   138475.20, 38475.20, 67.5, 876,  5),
  ('TechSurfer',    '#34d399', 'SWING',      127834.60, 27834.60, 65.9, 654,  6),
  ('CryptoNinja',   '#f97316', 'SCALP',      118293.40, 18293.40, 63.2, 1893, 7),
  ('StatArbBot',    '#60a5fa', 'MEAN-REV',   109472.90,  9472.90, 61.4, 743,  8),
  ('BlackSwan_9',   '#e879f9', 'BREAKOUT',    98341.20, -1658.80, 58.7, 567,  9),
  ('RiskZero',      '#94a3b8', 'MOMENTUM',    87293.50,-12706.50, 54.2, 432,  10)
ON CONFLICT DO NOTHING;

-- Seed signal radar items
INSERT INTO signal_radar_items (type, source, headline, sentiment, sentiment_score, asset, direction, confidence, status)
VALUES
  ('news',   'REUTERS',   'Fed signals two more rate cuts in 2026 as inflation cools to 2.1%', 'bullish', 0.82, 'SPY',  'BUY',  91, 'completed'),
  ('news',   'BLOOMBERG', 'Bitcoin ETF inflows hit record $2.3B in single day', 'bullish', 0.91, 'BTC',  'BUY',  88, 'completed'),
  ('news',   'CNBC',      'Tech earnings beat estimates by 12% — AI spend accelerating', 'bullish', 0.76, 'QQQ',  'BUY',  85, 'executing'),
  ('news',   'WSJ',       'Oil drops 4% on surprise OPEC+ output increase', 'bearish', -0.68, 'OIL',  'SELL', 83, 'pending'),
  ('news',   'FT',        'European PMI contracts for third consecutive month', 'bearish', -0.55, 'EUR',  'SELL', 79, 'pending'),
  ('signal', 'AI-CORE',   'Momentum breakout confirmed on 4H chart with volume spike', 'bullish', 0.88, 'NVDA', 'BUY',  94, 'executing'),
  ('signal', 'DARKPOOL',  'Institutional accumulation detected — 47M block trade', 'bullish', 0.79, 'AAPL', 'BUY',  87, 'pending'),
  ('signal', 'AI-CORE',   'RSI divergence bearish — overbought on daily timeframe', 'bearish', -0.72, 'ETH',  'SELL', 81, 'pending')
ON CONFLICT DO NOTHING;

-- Seed morning briefing cache with today's data
INSERT INTO morning_briefing_cache (asset_class, symbol, name, price, change_pct, sparkline)
VALUES
  ('stocks',      'SPY',  'S&P 500 ETF',   531.42,  0.87,  ARRAY[527.1,528.3,529.0,530.2,531.4]),
  ('stocks',      'QQQ',  'NASDAQ 100',    463.18,  1.24,  ARRAY[457.2,459.1,461.3,462.8,463.2]),
  ('stocks',      'NVDA', 'NVIDIA Corp',   897.34,  3.12,  ARRAY[870.0,878.2,885.5,893.1,897.3]),
  ('stocks',      'AAPL', 'Apple Inc',     213.47,  0.54,  ARRAY[212.1,212.5,213.0,213.2,213.5]),
  ('crypto',      'BTC',  'Bitcoin',       67842.50, 2.31, ARRAY[66300,66800,67100,67500,67843]),
  ('crypto',      'ETH',  'Ethereum',       3847.20, 1.87, ARRAY[3780,3800,3821,3839,3847]),
  ('crypto',      'SOL',  'Solana',          168.43, 4.21, ARRAY[161.2,163.5,165.8,167.1,168.4]),
  ('forex',       'EURUSD','EUR/USD',         1.0847, 0.12, ARRAY[1.082,1.083,1.084,1.084,1.085]),
  ('forex',       'GBPUSD','GBP/USD',         1.2734, -0.08,ARRAY[1.275,1.274,1.274,1.273,1.273]),
  ('commodities', 'GOLD', 'Gold',          2341.80, -0.32, ARRAY[2352,2348,2345,2343,2342]),
  ('commodities', 'OIL',  'Crude Oil WTI',   78.34, -1.24, ARRAY[79.8,79.2,78.9,78.6,78.3])
ON CONFLICT DO NOTHING;

INSERT INTO morning_briefing_alerts (severity, asset, message, source)
VALUES
  ('critical', 'BTC',  'Bitcoin breaks $67K resistance — next target $72K', 'AI'),
  ('high',     'SPY',  'S&P 500 approaching all-time high — watch for reversal', 'AI'),
  ('high',     'OIL',  'Oil slides on OPEC surprise — energy stocks at risk', 'Reuters'),
  ('medium',   'NVDA', 'NVIDIA earnings beat — AI capex spending confirmed', 'CNBC'),
  ('low',      'EUR',  'ECB policy meeting next Thursday — EUR/USD range-bound', 'Bloomberg')
ON CONFLICT DO NOTHING;
