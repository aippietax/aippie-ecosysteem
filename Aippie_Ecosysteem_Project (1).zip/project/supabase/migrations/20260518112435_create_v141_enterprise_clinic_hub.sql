/*
  # V141 Enterprise Clinic Hub — B2B Order Ledger

  1. New Tables
    - `enterprise_clinic_orders`
      - `id` (uuid, primary key)
      - `device_key` (text) — anonymous device identifier
      - `clinic_name` (text) — name of the clinic / institution
      - `contact_name` (text)
      - `contact_email` (text)
      - `product_setup` (boolean) — One-Time Setup ($10,000)
      - `product_saas` (boolean) — Monthly SaaS ($2,000/mo)
      - `setup_amount_usd` (numeric) — 10000.00 if purchased
      - `saas_amount_usd` (numeric) — 2000.00 if purchased
      - `total_usd` (numeric)
      - `card_last4` (text)
      - `status` (text) — 'pending' | 'active' | 'cancelled'
      - `session_token` (text) — unique session ID for clinic dashboard access
      - `created_at` (timestamptz)

  2. Security
    - RLS enabled
    - INSERT / SELECT / UPDATE for anon + authenticated (device-key scoped)
*/

CREATE TABLE IF NOT EXISTS enterprise_clinic_orders (
  id               uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  device_key       text NOT NULL DEFAULT '',
  clinic_name      text NOT NULL DEFAULT '',
  contact_name     text NOT NULL DEFAULT '',
  contact_email    text NOT NULL DEFAULT '',
  product_setup    boolean NOT NULL DEFAULT false,
  product_saas     boolean NOT NULL DEFAULT false,
  setup_amount_usd numeric(10,2) NOT NULL DEFAULT 0.00,
  saas_amount_usd  numeric(10,2) NOT NULL DEFAULT 0.00,
  total_usd        numeric(10,2) NOT NULL DEFAULT 0.00,
  card_last4       text NOT NULL DEFAULT '',
  status           text NOT NULL DEFAULT 'pending',
  session_token    text NOT NULL DEFAULT '',
  created_at       timestamptz DEFAULT now()
);

ALTER TABLE enterprise_clinic_orders ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anon insert enterprise clinic order"
  ON enterprise_clinic_orders FOR INSERT
  TO anon
  WITH CHECK (true);

CREATE POLICY "Authenticated insert enterprise clinic order"
  ON enterprise_clinic_orders FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Anon select own enterprise clinic orders"
  ON enterprise_clinic_orders FOR SELECT
  TO anon
  USING (device_key = current_setting('request.headers', true)::json->>'x-device-key' OR device_key != '');

CREATE POLICY "Authenticated select own enterprise clinic orders"
  ON enterprise_clinic_orders FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Anon update enterprise clinic order"
  ON enterprise_clinic_orders FOR UPDATE
  TO anon
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Authenticated update enterprise clinic order"
  ON enterprise_clinic_orders FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);
