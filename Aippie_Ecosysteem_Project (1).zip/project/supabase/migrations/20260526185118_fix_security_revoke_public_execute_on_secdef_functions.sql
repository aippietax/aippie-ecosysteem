/*
  # Fix SECURITY DEFINER Execute Grants — Revoke PUBLIC, re-grant authenticated only

  The previous migration revoked from `anon` directly, but the grant exists on the
  PUBLIC pseudo-role, which covers both anon and authenticated. The correct fix is:
    1. REVOKE EXECUTE ... FROM PUBLIC  — removes implicit grant from all roles
    2. GRANT EXECUTE ... TO authenticated — restore only to authenticated callers
    3. Do NOT grant to anon — anonymous users must never call these functions

  This applies to both aivp_dispatch_payout and claim_smart_home_license.
*/

-- ── aivp_dispatch_payout ──────────────────────────────────────────────────────
REVOKE ALL ON FUNCTION public.aivp_dispatch_payout(uuid) FROM PUBLIC;
REVOKE ALL ON FUNCTION public.aivp_dispatch_payout(uuid) FROM anon;
GRANT EXECUTE ON FUNCTION public.aivp_dispatch_payout(uuid) TO authenticated;

-- ── claim_smart_home_license ──────────────────────────────────────────────────
REVOKE ALL ON FUNCTION public.claim_smart_home_license(text) FROM PUBLIC;
REVOKE ALL ON FUNCTION public.claim_smart_home_license(text) FROM anon;
GRANT EXECUTE ON FUNCTION public.claim_smart_home_license(text) TO authenticated;
