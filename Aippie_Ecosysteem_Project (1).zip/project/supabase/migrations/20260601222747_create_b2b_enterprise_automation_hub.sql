/*
  # B2B Enterprise Automation Hub — AippieTax S.A.

  ## Overview
  Standalone schema supporting the Aippie B2B Enterprise Automation Module.
  Four tables cover: multi-language lead telemetry, API license key management,
  client greeting session logs, and bi-weekly invoicing with 48-hour lockout cycles.

  ## New Tables

  ### 1. `b2b_leads`
  Inbound business leads tracked per language and sector.
  - `lead_id` (uuid, PK)
  - `user_id` (uuid, FK → auth.users) — owning enterprise account
  - `language` (varchar) — ES | EN | DE | NL
  - `sector` (varchar) — REAL_ESTATE | LEGAL | MEDICAL | OTHER
  - `company_name` (varchar)
  - `contact_email` (varchar)
  - `status` (varchar) — NEW | CONTACTED | QUALIFIED | CLOSED
  - `automation_saved_minutes` (numeric) — minutes saved by AI follow-up
  - `created_at` (timestamptz)

  ### 2. `b2b_license_keys`
  API token / software license keys per tenant.
  - `key_id` (uuid, PK)
  - `user_id` (uuid, FK → auth.users)
  - `license_key` (varchar, unique) — AIPPIE-XXXX-XXXX-XXXX format
  - `sector` (varchar)
  - `domain` (varchar) — embed target domain
  - `is_active` (bool)
  - `validated_at` (timestamptz)
  - `expires_at` (timestamptz)
  - `created_at` (timestamptz)

  ### 3. `b2b_greeting_sessions`
  Inbound audio/video greeting events logged per client arrival.
  - `session_id` (uuid, PK)
  - `user_id` (uuid, FK → auth.users)
  - `client_company` (varchar)
  - `greeting_language` (varchar)
  - `greeting_triggered_at` (timestamptz)

  ### 4. `b2b_invoices`
  Bi-weekly €1,550 billing cycles with 48-hour grace period lockout.
  - `invoice_id` (uuid, PK)
  - `user_id` (uuid, FK → auth.users)
  - `amount_eur` (numeric, default 1550.00)
  - `cycle_label` (varchar) — e.g. "2026-W22"
  - `due_at` (timestamptz)
  - `paid_at` (timestamptz, nullable)
  - `lockout_at` (timestamptz) — due_at + 48 hours
  - `is_locked` (bool)
  - `payment_status` (varchar) — PENDING | PAID | LOCKED
  - `created_at` (timestamptz)

  ## Security
  - RLS enabled on all four tables
  - Each table is strictly scoped to the owning user_id
*/

-- ── 1. B2B leads ──────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS public.b2b_leads (
  lead_id                  uuid         PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id                  uuid         NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  language                 varchar(5)   NOT NULL DEFAULT 'EN'
    CHECK (language IN ('ES','EN','DE','NL')),
  sector                   varchar(20)  NOT NULL DEFAULT 'OTHER'
    CHECK (sector IN ('REAL_ESTATE','LEGAL','MEDICAL','OTHER')),
  company_name             varchar(120) NOT NULL DEFAULT '',
  contact_email            varchar(200) NOT NULL DEFAULT '',
  status                   varchar(15)  NOT NULL DEFAULT 'NEW'
    CHECK (status IN ('NEW','CONTACTED','QUALIFIED','CLOSED')),
  automation_saved_minutes numeric(8,2) NOT NULL DEFAULT 0,
  created_at               timestamptz  NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_b2b_leads_user_id   ON public.b2b_leads (user_id);
CREATE INDEX IF NOT EXISTS idx_b2b_leads_language  ON public.b2b_leads (language);
CREATE INDEX IF NOT EXISTS idx_b2b_leads_status    ON public.b2b_leads (status);

ALTER TABLE public.b2b_leads ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own leads"
  ON public.b2b_leads FOR SELECT TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create own leads"
  ON public.b2b_leads FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own leads"
  ON public.b2b_leads FOR UPDATE TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- ── 2. License keys ───────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS public.b2b_license_keys (
  key_id        uuid         PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id       uuid         NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  license_key   varchar(30)  NOT NULL UNIQUE,
  sector        varchar(20)  NOT NULL DEFAULT 'OTHER'
    CHECK (sector IN ('REAL_ESTATE','LEGAL','MEDICAL','OTHER')),
  domain        varchar(200) NOT NULL DEFAULT '',
  is_active     boolean      NOT NULL DEFAULT true,
  validated_at  timestamptz,
  expires_at    timestamptz  NOT NULL DEFAULT (now() + interval '1 year'),
  created_at    timestamptz  NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_b2b_license_keys_user_id ON public.b2b_license_keys (user_id);
CREATE INDEX IF NOT EXISTS idx_b2b_license_keys_key     ON public.b2b_license_keys (license_key);

ALTER TABLE public.b2b_license_keys ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own license keys"
  ON public.b2b_license_keys FOR SELECT TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create own license keys"
  ON public.b2b_license_keys FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own license keys"
  ON public.b2b_license_keys FOR UPDATE TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- ── 3. Greeting sessions ──────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS public.b2b_greeting_sessions (
  session_id           uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id              uuid        NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  client_company       varchar(120) NOT NULL DEFAULT '',
  greeting_language    varchar(5)  NOT NULL DEFAULT 'EN'
    CHECK (greeting_language IN ('ES','EN','DE','NL')),
  greeting_triggered_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_b2b_greetings_user_id ON public.b2b_greeting_sessions (user_id);

ALTER TABLE public.b2b_greeting_sessions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own greeting sessions"
  ON public.b2b_greeting_sessions FOR SELECT TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create own greeting sessions"
  ON public.b2b_greeting_sessions FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- ── 4. Invoices ───────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS public.b2b_invoices (
  invoice_id     uuid         PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id        uuid         NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  amount_eur     numeric(8,2) NOT NULL DEFAULT 1550.00,
  cycle_label    varchar(20)  NOT NULL DEFAULT '',
  due_at         timestamptz  NOT NULL DEFAULT (now() + interval '14 days'),
  paid_at        timestamptz,
  lockout_at     timestamptz  NOT NULL DEFAULT (now() + interval '16 days'),
  is_locked      boolean      NOT NULL DEFAULT false,
  payment_status varchar(10)  NOT NULL DEFAULT 'PENDING'
    CHECK (payment_status IN ('PENDING','PAID','LOCKED')),
  created_at     timestamptz  NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_b2b_invoices_user_id ON public.b2b_invoices (user_id);
CREATE INDEX IF NOT EXISTS idx_b2b_invoices_status  ON public.b2b_invoices (payment_status);

ALTER TABLE public.b2b_invoices ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own invoices"
  ON public.b2b_invoices FOR SELECT TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create own invoices"
  ON public.b2b_invoices FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own invoices"
  ON public.b2b_invoices FOR UPDATE TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);
