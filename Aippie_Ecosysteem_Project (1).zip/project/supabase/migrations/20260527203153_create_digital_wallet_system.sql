/*
  # Digital Wallet System — AippieTax S.A.

  ## Overview
  Complete financial wallet infrastructure for 50k+ users with Aippie Coins (APC),
  virtual prepaid cards, peer-to-peer transfers, and fee routing to treasury.

  ## New Tables

  ### 1. `apc_wallets`
  Each user has exactly one wallet storing their APC balance (pegged 1:1 to EUR).
  - `id` (uuid, PK)
  - `user_id` (uuid, FK → auth.users, UNIQUE — one wallet per user)
  - `balance_apc` (numeric, default 0.00, non-negative)
  - `created_at`, `updated_at`

  ### 2. `apc_virtual_cards`
  Deterministically generated virtual prepaid card linked to each wallet.
  - `id` (uuid, PK)
  - `wallet_id` (uuid, FK → apc_wallets)
  - `user_id` (uuid, FK → auth.users)
  - `card_number` (text, 16 digits masked)
  - `expiry_month`, `expiry_year` (int)
  - `cvc_hash` (text — stored hashed, displayed via function)
  - `card_display_cvc` (text — cleartext CVC for display, set once on creation)
  - `status` (text: active | frozen | cancelled)
  - `created_at`

  ### 3. `apc_transactions`
  Immutable ledger of every financial event (deposit, transfer_out, transfer_in, fee).
  - `id` (uuid, PK)
  - `wallet_id` (uuid, FK → apc_wallets)
  - `user_id` (uuid)
  - `type` (text: deposit | transfer_out | transfer_in | fee_debit | fee_credit)
  - `amount_apc` (numeric — positive for credits, negative for debits)
  - `fee_apc` (numeric, default 0)
  - `counterpart_user_id` (uuid, nullable — for P2P transfers)
  - `counterpart_phone` (text, nullable)
  - `reference` (text — human-readable description)
  - `status` (text: completed | pending | failed)
  - `created_at`

  ### 4. `apc_treasury_ledger`
  All fees collected by AIPPIETAX S.A. corporate treasury.
  - `id` (uuid, PK)
  - `source_transaction_id` (uuid, FK → apc_transactions)
  - `fee_type` (text: p2p_fee_1pct | deposit_fee_7pct)
  - `amount_apc` (numeric)
  - `from_user_id` (uuid)
  - `created_at`

  ## Security
  - RLS enabled on all tables
  - Users can only read/update their own wallet
  - Users can only read their own transactions and cards
  - Treasury ledger: no user read access (admin only via service role)
  - Indexes on user_id, wallet_id, created_at for 50k+ scale

  ## Functions
  - `apc_deposit(p_amount numeric)` — SECURITY INVOKER, deducts 7% fee, credits net
  - `apc_transfer(p_to_phone text, p_amount numeric)` — SECURITY INVOKER, deducts 1% fee
*/

-- ── Wallets ───────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS public.apc_wallets (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id      uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  balance_apc  numeric(18,4) NOT NULL DEFAULT 0.0000 CHECK (balance_apc >= 0),
  created_at   timestamptz NOT NULL DEFAULT now(),
  updated_at   timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT apc_wallets_user_unique UNIQUE (user_id)
);

CREATE INDEX IF NOT EXISTS apc_wallets_user_id_idx ON public.apc_wallets (user_id);

ALTER TABLE public.apc_wallets ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own wallet"
  ON public.apc_wallets FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can update own wallet balance"
  ON public.apc_wallets FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can insert own wallet"
  ON public.apc_wallets FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- ── Virtual Cards ─────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS public.apc_virtual_cards (
  id               uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  wallet_id        uuid NOT NULL REFERENCES public.apc_wallets(id) ON DELETE CASCADE,
  user_id          uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  card_number      text NOT NULL,
  expiry_month     int  NOT NULL CHECK (expiry_month BETWEEN 1 AND 12),
  expiry_year      int  NOT NULL,
  card_display_cvc text NOT NULL,
  status           text NOT NULL DEFAULT 'active' CHECK (status IN ('active','frozen','cancelled')),
  created_at       timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT apc_virtual_cards_wallet_unique UNIQUE (wallet_id)
);

CREATE INDEX IF NOT EXISTS apc_virtual_cards_user_id_idx ON public.apc_virtual_cards (user_id);

ALTER TABLE public.apc_virtual_cards ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own card"
  ON public.apc_virtual_cards FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own card"
  ON public.apc_virtual_cards FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own card status"
  ON public.apc_virtual_cards FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- ── Transactions ──────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS public.apc_transactions (
  id                   uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  wallet_id            uuid NOT NULL REFERENCES public.apc_wallets(id) ON DELETE CASCADE,
  user_id              uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  type                 text NOT NULL CHECK (type IN ('deposit','transfer_out','transfer_in','fee_debit','fee_credit')),
  amount_apc           numeric(18,4) NOT NULL,
  fee_apc              numeric(18,4) NOT NULL DEFAULT 0.0000,
  counterpart_user_id  uuid,
  counterpart_phone    text,
  reference            text NOT NULL DEFAULT '',
  status               text NOT NULL DEFAULT 'completed' CHECK (status IN ('completed','pending','failed')),
  created_at           timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS apc_transactions_wallet_id_idx  ON public.apc_transactions (wallet_id);
CREATE INDEX IF NOT EXISTS apc_transactions_user_id_idx    ON public.apc_transactions (user_id);
CREATE INDEX IF NOT EXISTS apc_transactions_created_at_idx ON public.apc_transactions (created_at DESC);

ALTER TABLE public.apc_transactions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own transactions"
  ON public.apc_transactions FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own transactions"
  ON public.apc_transactions FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- ── Treasury Ledger ───────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS public.apc_treasury_ledger (
  id                    uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  source_transaction_id uuid REFERENCES public.apc_transactions(id),
  fee_type              text NOT NULL CHECK (fee_type IN ('p2p_fee_1pct','deposit_fee_7pct')),
  amount_apc            numeric(18,4) NOT NULL,
  from_user_id          uuid NOT NULL,
  created_at            timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS apc_treasury_from_user_idx  ON public.apc_treasury_ledger (from_user_id);
CREATE INDEX IF NOT EXISTS apc_treasury_created_at_idx ON public.apc_treasury_ledger (created_at DESC);

ALTER TABLE public.apc_treasury_ledger ENABLE ROW LEVEL SECURITY;

-- Treasury is write-only from authenticated; no user can read it (service role only)
CREATE POLICY "Authenticated can insert treasury entries"
  ON public.apc_treasury_ledger FOR INSERT
  TO authenticated
  WITH CHECK (from_user_id = auth.uid());

-- ── Helper: ensure wallet exists for caller ───────────────────────────────────
CREATE OR REPLACE FUNCTION public.apc_ensure_wallet()
  RETURNS public.apc_wallets
  LANGUAGE plpgsql
  SECURITY INVOKER
  SET search_path = 'public'
AS $$
DECLARE
  v_wallet public.apc_wallets;
BEGIN
  SELECT * INTO v_wallet FROM public.apc_wallets WHERE user_id = auth.uid();
  IF NOT FOUND THEN
    INSERT INTO public.apc_wallets (user_id)
    VALUES (auth.uid())
    RETURNING * INTO v_wallet;
    -- Auto-generate virtual card
    INSERT INTO public.apc_virtual_cards (
      wallet_id, user_id, card_number, expiry_month, expiry_year, card_display_cvc
    ) VALUES (
      v_wallet.id,
      auth.uid(),
      '4' || lpad((floor(random()*999999999999999)::bigint)::text, 15, '0'),
      ((EXTRACT(MONTH FROM now())::int % 12) + 1),
      EXTRACT(YEAR FROM now())::int + 4,
      lpad((floor(random()*899 + 100)::int)::text, 3, '0')
    );
  END IF;
  RETURN v_wallet;
END;
$$;

-- ── Deposit function (7% inbound fee) ─────────────────────────────────────────
CREATE OR REPLACE FUNCTION public.apc_deposit(p_amount numeric)
  RETURNS jsonb
  LANGUAGE plpgsql
  SECURITY INVOKER
  SET search_path = 'public'
AS $$
DECLARE
  v_wallet      public.apc_wallets;
  v_fee         numeric(18,4);
  v_net         numeric(18,4);
  v_tx_id       uuid;
BEGIN
  IF auth.uid() IS NULL THEN
    RETURN jsonb_build_object('ok', false, 'error', 'Not authenticated');
  END IF;
  IF p_amount <= 0 THEN
    RETURN jsonb_build_object('ok', false, 'error', 'Amount must be positive');
  END IF;

  v_wallet := public.apc_ensure_wallet();
  v_fee    := ROUND((p_amount * 0.07)::numeric, 4);
  v_net    := ROUND((p_amount - v_fee)::numeric, 4);

  -- Credit net amount to wallet
  UPDATE public.apc_wallets
  SET balance_apc = balance_apc + v_net,
      updated_at  = now()
  WHERE id = v_wallet.id;

  -- Record deposit transaction
  INSERT INTO public.apc_transactions (
    wallet_id, user_id, type, amount_apc, fee_apc, reference
  ) VALUES (
    v_wallet.id, auth.uid(), 'deposit', v_net, v_fee,
    'Fiat deposit · 7% processing fee applied'
  ) RETURNING id INTO v_tx_id;

  -- Route fee to treasury
  INSERT INTO public.apc_treasury_ledger (source_transaction_id, fee_type, amount_apc, from_user_id)
  VALUES (v_tx_id, 'deposit_fee_7pct', v_fee, auth.uid());

  RETURN jsonb_build_object(
    'ok',         true,
    'deposited',  v_net,
    'fee',        v_fee,
    'gross',      p_amount,
    'tx_id',      v_tx_id
  );
END;
$$;

REVOKE ALL ON FUNCTION public.apc_deposit(numeric) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.apc_deposit(numeric) TO authenticated;

-- ── Transfer function (1% P2P fee) ────────────────────────────────────────────
CREATE OR REPLACE FUNCTION public.apc_transfer(p_to_phone text, p_amount numeric)
  RETURNS jsonb
  LANGUAGE plpgsql
  SECURITY INVOKER
  SET search_path = 'public'
AS $$
DECLARE
  v_sender_wallet   public.apc_wallets;
  v_receiver_wallet public.apc_wallets;
  v_receiver_uid    uuid;
  v_fee             numeric(18,4);
  v_total_debit     numeric(18,4);
  v_tx_out_id       uuid;
BEGIN
  IF auth.uid() IS NULL THEN
    RETURN jsonb_build_object('ok', false, 'error', 'Not authenticated');
  END IF;
  IF p_amount <= 0 THEN
    RETURN jsonb_build_object('ok', false, 'error', 'Amount must be positive');
  END IF;

  v_fee        := ROUND((p_amount * 0.01)::numeric, 4);
  v_total_debit := ROUND((p_amount + v_fee)::numeric, 4);

  -- Load sender wallet
  SELECT * INTO v_sender_wallet FROM public.apc_wallets WHERE user_id = auth.uid();
  IF NOT FOUND THEN
    v_sender_wallet := public.apc_ensure_wallet();
    SELECT * INTO v_sender_wallet FROM public.apc_wallets WHERE user_id = auth.uid();
  END IF;

  IF v_sender_wallet.balance_apc < v_total_debit THEN
    RETURN jsonb_build_object(
      'ok', false,
      'error', 'Insufficient balance',
      'required', v_total_debit,
      'available', v_sender_wallet.balance_apc
    );
  END IF;

  -- Look up receiver by phone via client_profiles
  SELECT cp.user_id INTO v_receiver_uid
  FROM public.client_profiles cp
  WHERE cp.phone = p_to_phone
  LIMIT 1;

  IF v_receiver_uid IS NULL THEN
    RETURN jsonb_build_object('ok', false, 'error', 'Recipient not found for that phone number');
  END IF;

  IF v_receiver_uid = auth.uid() THEN
    RETURN jsonb_build_object('ok', false, 'error', 'Cannot transfer to yourself');
  END IF;

  -- Ensure receiver has a wallet
  SELECT * INTO v_receiver_wallet FROM public.apc_wallets WHERE user_id = v_receiver_uid;
  IF NOT FOUND THEN
    -- Insert receiver wallet directly (service-level operation within same tx)
    INSERT INTO public.apc_wallets (user_id)
    VALUES (v_receiver_uid)
    ON CONFLICT (user_id) DO NOTHING
    RETURNING * INTO v_receiver_wallet;
    -- Re-fetch if ON CONFLICT silently won
    IF v_receiver_wallet.id IS NULL THEN
      SELECT * INTO v_receiver_wallet FROM public.apc_wallets WHERE user_id = v_receiver_uid;
    END IF;
  END IF;

  -- Debit sender (amount + fee)
  UPDATE public.apc_wallets
  SET balance_apc = balance_apc - v_total_debit,
      updated_at  = now()
  WHERE id = v_sender_wallet.id;

  -- Record sender debit transaction
  INSERT INTO public.apc_transactions (
    wallet_id, user_id, type, amount_apc, fee_apc,
    counterpart_user_id, counterpart_phone, reference
  ) VALUES (
    v_sender_wallet.id, auth.uid(), 'transfer_out',
    -p_amount, v_fee,
    v_receiver_uid, p_to_phone,
    'P2P transfer to ' || p_to_phone || ' · 1% fee'
  ) RETURNING id INTO v_tx_out_id;

  -- Credit receiver
  UPDATE public.apc_wallets
  SET balance_apc = balance_apc + p_amount,
      updated_at  = now()
  WHERE id = v_receiver_wallet.id;

  -- Record receiver credit transaction
  INSERT INTO public.apc_transactions (
    wallet_id, user_id, type, amount_apc, fee_apc,
    counterpart_user_id, counterpart_phone, reference
  ) VALUES (
    v_receiver_wallet.id, v_receiver_uid, 'transfer_in',
    p_amount, 0,
    auth.uid(), p_to_phone,
    'P2P received from ' || p_to_phone
  );

  -- Route fee to treasury
  INSERT INTO public.apc_treasury_ledger (source_transaction_id, fee_type, amount_apc, from_user_id)
  VALUES (v_tx_out_id, 'p2p_fee_1pct', v_fee, auth.uid());

  RETURN jsonb_build_object(
    'ok',       true,
    'sent',     p_amount,
    'fee',      v_fee,
    'debited',  v_total_debit,
    'to_phone', p_to_phone,
    'tx_id',    v_tx_out_id
  );
END;
$$;

REVOKE ALL ON FUNCTION public.apc_transfer(text, numeric) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.apc_transfer(text, numeric) TO authenticated;

-- REVOKE / GRANT apc_ensure_wallet — internal helper, no direct RPC access
REVOKE ALL ON FUNCTION public.apc_ensure_wallet() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.apc_ensure_wallet() TO authenticated;
