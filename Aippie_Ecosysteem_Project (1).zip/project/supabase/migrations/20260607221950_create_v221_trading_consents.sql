
-- Trading disclaimer/consent log
CREATE TABLE IF NOT EXISTS trading_consents (
  id           UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id      UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  device_key   TEXT,                         -- fallback for non-auth users
  consented_at TIMESTAMPTZ DEFAULT NOW(),
  ip_hint      TEXT,                         -- first 2 octets only, for audit
  version      TEXT NOT NULL DEFAULT 'v1',   -- bump when disclaimer text changes
  UNIQUE (user_id, version)
);

ALTER TABLE trading_consents ENABLE ROW LEVEL SECURITY;

CREATE POLICY "consent_insert_own" ON trading_consents
  FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);

CREATE POLICY "consent_select_own" ON trading_consents
  FOR SELECT TO authenticated USING (auth.uid() = user_id);

-- Allow anon inserts with device_key (no user_id) for guests
CREATE POLICY "consent_insert_anon" ON trading_consents
  FOR INSERT TO anon WITH CHECK (user_id IS NULL AND device_key IS NOT NULL);
