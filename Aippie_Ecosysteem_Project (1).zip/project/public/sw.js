// v4 — force cache eviction on all devices
const CACHE = 'aippie-v4';

self.addEventListener('install', e => {
  // Skip waiting immediately so the new SW activates right away
  self.skipWaiting();
  e.waitUntil(
    caches.open(CACHE).then(c => c.addAll([]))
  );
});

self.addEventListener('activate', e => {
  // Delete ALL old caches so stale assets are gone
  e.waitUntil(
    caches.keys().then(keys =>
      Promise.all(keys.map(k => caches.delete(k)))
    ).then(() => self.clients.claim())
  );
});

// Network-first for everything — ensures updates always get through
self.addEventListener('fetch', e => {
  if (e.request.method !== 'GET') return;

  e.respondWith(
    fetch(e.request, { cache: 'no-store' })
      .then(res => {
        // Only cache successful responses for static assets (JS/CSS)
        if (res.ok && (e.request.url.includes('/assets/'))) {
          const clone = res.clone();
          caches.open(CACHE).then(c => c.put(e.request, clone));
        }
        return res;
      })
      .catch(() => caches.match(e.request))
  );
});
