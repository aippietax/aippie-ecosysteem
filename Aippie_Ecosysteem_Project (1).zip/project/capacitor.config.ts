import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.aippietax.aippieos',
  appName: 'AippieOS',
  webDir: 'dist',
  android: {
    allowMixedContent: false,
    backgroundColor: '#0a0f1e',
    hardwareAccelerated: true,
  },
  ios: {
    backgroundColor: '#0a0f1e',
    contentInset: 'always',
    scrollEnabled: false,
  },
  plugins: {
    SplashScreen: {
      launchAutoHide: true,
      launchFadeOutDuration: 600,
      backgroundColor: '#0a0f1e',
      androidSplashResourceName: 'splash',
      androidScaleType: 'CENTER_CROP',
      showSpinner: false,
      splashFullScreen: true,
      splashImmersive: true,
    },
    StatusBar: {
      style: 'DARK',
      backgroundColor: '#0a0f1e',
      overlaysWebView: false,
    },
    Keyboard: {
      resize: 'body',
      style: 'DARK',
      resizeOnFullScreen: true,
    },
  },
  server: {
    androidScheme: 'https',
    cleartext: false,
    url: 'https://aippietax.com',
    // Allow Supabase auth endpoints — critical for iOS localStorage session persistence
    allowNavigation: ['*.supabase.co', 'aippietax.com'],
  },
};

export default config;
